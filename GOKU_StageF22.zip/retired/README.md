action_machine.py (Stage F11 early draft) is RETIRED: it was never wired and had no tests. Its job is done by brain/orchestrator.py (state machine, evidence-gated COMPLETED)
and brain/recovery.py (failure diagnosis, uncertain-action read-back). The file is kept as action_machine.py.txt for reference only; it is not importable.
