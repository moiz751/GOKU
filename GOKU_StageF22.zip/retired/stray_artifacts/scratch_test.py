from command_layer.decomposer import decompose_compound_command
from command_layer.router import route_command
from command_layer.context import session_context

cmd1 = 'calculator kholo, usme 46 multiply by 9 karo, phir notepad khol kar likho "CALC_OK" aur calculator band kardo'
clauses = decompose_compound_command(cmd1)
print("DECOMPOSED CLAUSES:")
for c in clauses:
    p = route_command(c, session_context, is_compound_root=False)
    print("   CLAUSE:", c)
    print("   PLAN:", [(s.tool, s.args) for s in p.steps] if p else None)
