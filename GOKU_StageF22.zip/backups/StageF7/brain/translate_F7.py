"""Translation (stage F7), honest about what it can and cannot do offline.

  1. phrasebook  - Roman Urdu <-> English: sentence patterns + a word list. Used only when EVERY word is covered; numbers and names are copied unchanged.
  2. model       - optional `llm(prompt)` callable (the local 0.5B model). Its output is accepted only if every number and every capitalised name of the source
                   appears in it, and is always labelled 'unverified draft'.
  3. otherwise   - says plainly that this language/text needs a model or internet, and still returns the original untouched.
The original text is ALWAYS returned next to the translation. Meaning-preservation checks are mechanical (numbers, names, length ratio), not a judge of quality.
"""
from __future__ import annotations

import re
from typing import Any, Callable, Dict, List, Optional

_R2E_WORDS = {"mujhe": "me", "pani": "water", "chahiye": "need", "kahan": "where", "hai": "is", "kya": "what", "naam": "name", "aap": "you", "ka": "of", "ki": "of", "main": "I", "hoon": "am", "hun": "am", "khana": "food", "chai": "tea",
              "ghar": "home", "kitab": "book", "paisa": "money", "paise": "money", "dost": "friend", "kal": "tomorrow", "aaj": "today", "bohat": "very", "acha": "good", "achha": "good", "theek": "fine", "shukriya": "thank you", "salam": "hello",
              "madad": "help", "samay": "time", "waqt": "time", "kitna": "how much", "kitne": "how many", "yeh": "this", "woh": "that", "hum": "we", "tum": "you", "nahi": "not", "han": "yes", "haan": "yes", "or": "and", "aur": "and",
              "file": "file", "folder": "folder", "kaam": "work", "computer": "computer", "laptop": "laptop", "chahiyen": "need", "ho": "are", "hain": "are", "mein": "in", "me": "in", "se": "from", "ko": "to", "par": "on"}
_E2R_WORDS = {"the": "", "a": "", "an": "", "water": "pani", "food": "khana", "tea": "chai", "home": "ghar", "book": "kitab", "money": "paisa", "friend": "dost", "tomorrow": "kal", "today": "aaj", "very": "bohat", "good": "acha", "fine": "theek", "hello": "salam", "help": "madad",
              "time": "waqt", "file": "file", "folder": "folder", "work": "kaam", "computer": "computer", "laptop": "laptop", "yes": "haan", "no": "nahi", "and": "aur", "thanks": "shukriya", "thank": "shukriya"}
_R2E_PAT = [
    (r"^mujhe (.+) chahiye$", "I need {0}"), (r"^(.+) kahan hai$", "where is {0}"), (r"^aap ka naam kya hai$", "what is your name"), (r"^main (.+) hoon?$", "I am {0}"), (r"^shukriya$", "thank you"),
    (r"^(.+) kitna hai$", "how much is {0}"), (r"^mujhe (.+) chahiyen$", "I need {0}"), (r"^mujhe madad chahiye$", "I need help"), (r"^salam$", "hello"),
]
_E2R_PAT = [
    (r"^i need (.+)$", "mujhe {0} chahiye"), (r"^where is (.+)$", "{0} kahan hai"), (r"^what is your name$", "aap ka naam kya hai"), (r"^i am (.+)$", "main {0} hoon"), (r"^thank you$", "shukriya"), (r"^hello$", "salam"),
    (r"^i need help$", "mujhe madad chahiye"), (r"^how much is (.+)$", "{0} kitna hai"),
]


def source_language(text: str) -> str:
    if re.search(r"[؀-ۿ]", text):
        return "urdu_script"
    low = re.findall(r"[a-z']+", text.lower())
    ur = sum(1 for w in low if w in _R2E_WORDS and w not in ("me", "file", "folder", "computer", "laptop", "or", "hum", "main", "par", "se", "ko", "ho", "hai", "ka", "ki"))
    en = sum(1 for w in low if w in _E2R_WORDS or w in ("the", "is", "are", "i", "you", "my", "to", "of", "what", "where", "how", "need"))
    return "roman_urdu" if ur > en else "english"


def _tokens_protected(text: str) -> List[str]:
    nums = re.findall(r"\d[\d,.:]*", text)
    names = [w for w in re.findall(r"\b[A-Z][a-z]{2,}\b", text)]
    return nums + names


def _words(sentence: str, table: Dict[str, str]) -> Optional[str]:
    out = []
    for w in re.findall(r"[\w']+|[^\w\s]", sentence):
        lw = w.lower()
        if re.fullmatch(r"\d[\d,.:]*", w) or (w[:1].isupper() and not re.match(r"^(I)$", w) and lw not in table):
            out.append(w)                                         # numbers and names are copied, never translated
        elif lw in table:
            if table[lw]:
                out.append(table[lw])
        elif re.fullmatch(r"[^\w\s]", w):
            out.append(w)
        else:
            return None                                           # a word the phrasebook does not know -> do not guess
    return " ".join(out).replace(" ,", ",").replace(" .", ".").replace(" ?", "?")


def _phrasebook(text: str, src: str) -> Optional[str]:
    parts = [p.strip() for p in re.split(r"(?<=[.!?])\s+|\n", text) if p.strip()]
    outs: List[str] = []
    for p in parts:
        core = p.rstrip(".!? ").strip()
        low = core.lower()
        pats, table = (_R2E_PAT, _R2E_WORDS) if src == "roman_urdu" else (_E2R_PAT, _E2R_WORDS)
        done = None
        for pat, tpl in pats:
            m = re.match(pat, low)
            if m:
                inner = []
                for g in m.groups():
                    tr = _words(core[low.index(g):low.index(g) + len(g)], table) if g else ""
                    if tr is None:
                        inner = None
                        break
                    inner.append(tr)
                if inner is not None:
                    done = tpl.format(*inner)
                    break
        if done is None and len(core.split()) <= 2:                 # free word-by-word output is only trustworthy for 1-2 words
            done = _words(core, table)
        if done is None:
            return None
        outs.append(done[:1].upper() + done[1:] + (p[len(core):] or ""))
    return " ".join(outs)


def translate(text: str, target: str = "english", llm: Optional[Callable[[str], str]] = None) -> Dict[str, Any]:
    t = str(text or "").strip()
    tgt = target.lower().replace(" ", "_")
    tgt = {"urdu": "roman_urdu", "romanurdu": "roman_urdu"}.get(tgt, tgt)
    res: Dict[str, Any] = {"original": t, "target": tgt, "translation": "", "method": "", "status": "unsupported", "checks": {}, "notes": []}
    if not t:
        return dict(res, status="clarify", notes=["nothing to translate"])
    src = source_language(t)
    res["source"] = src
    if src == tgt:
        return dict(res, translation=t, method="none", status="answered", notes=["text is already in the target language"])
    if (src, tgt) in (("roman_urdu", "english"), ("english", "roman_urdu")):
        pb = _phrasebook(t, src)
        if pb:
            ok = all(p in pb for p in _tokens_protected(t))
            return dict(res, translation=pb, method="phrasebook", status="answered", checks={"numbers_and_names_preserved": ok}, notes=["word/pattern level: grammar may be simple; only used because every word was known"])
    if llm is not None:
        try:
            out = str(llm(f"Translate the following text from {src.replace('_', ' ')} to {tgt.replace('_', ' ')}. Keep every number and name exactly. Output only the translation.\n\n{t}")).strip()
        except Exception as e:
            out = ""
            res["notes"].append(f"model failed: {e}")
        prot = _tokens_protected(t)
        kept = {p: (p in out) for p in prot}
        if out and all(kept.values()):
            ratio = len(out) / max(1, len(t))
            return dict(res, translation=out, method="local_model", status="unverified", checks={"numbers_and_names_preserved": True, "length_ratio": round(ratio, 2)},
                        notes=["draft from the small local model: numbers/names were checked mechanically, MEANING was not verified - have it reviewed"])
        if out:
            res["notes"].append("model output dropped or changed: " + ", ".join(k for k, v in kept.items() if not v) + " - rejected")
    res["notes"].append(f"I cannot translate {src.replace('_', ' ')} to {tgt.replace('_', ' ')} reliably offline: it needs a translation model or internet service. Your original text is unchanged above.")
    return res


def handle_command(text: str, llm: Optional[Callable[[str], str]] = None) -> Optional[str]:
    m = re.match(r"(?is)^\s*translate\b(?:\s+this)?\s*(?:(?:roman\s+urdu|urdu|english|arabic)\s+(?:text|sentence|paragraph|message)\s*)?(?:from\s+[a-z ]+?\s+)?(?:into|to)\s+(roman urdu|english|urdu|arabic)\s*[:\-]\s*(.+)$", text.strip())
    if not m:
        return None
    r = translate(m.group(2).strip(), m.group(1), llm)
    head = f"Original: {r['original']}\n"
    if r["translation"]:
        return head + f"Translation ({r['method']}, {r['status']}): {r['translation']}\n" + "\n".join("note: " + n for n in r["notes"]) + (f"\nchecks: {r['checks']}" if r["checks"] else "")
    return head + "\n".join(r["notes"])
