"""
Central tool registry with auto-discovery.

Any tool module placed in tools/ that uses the @tool decorator is
automatically picked up at startup — you never edit this file to add
a new tool. Just create tools/whatever.py, decorate your functions,
and discover_tools() finds them.
"""
import importlib
import pkgutil
from pathlib import Path
import sys

from enum import IntEnum

TOOLS = {}  # name -> {"func": callable, "schema": {...}, "module": str, "func_name": str, "metadata": dict}
_DISCOVERED = False


class DisruptionLevel(IntEnum):
    READ_ONLY = 0
    ACTIVE_INSPECTION = 1
    BENIGN_STATE_CHANGE = 2
    MUTATIVE = 3
    DESTRUCTIVE = 4


# Known destructive, mutative, benign state-changing, and active inspection tools
DESTRUCTIVE_TOOLS = {"delete_file", "delete_folder", "replace_file", "kill_process", "terminate_process"}
MUTATIVE_TOOLS = {
    "create_file", "create_folder", "move_file", "move_folder", "rename_file", "rename_folder",
    "copy_file", "copy_folder", "set_clipboard_text", "clear_clipboard", "close_app", "close_browser",
    "extract_archive", "write_file", "smart_cleanup_app", "record_task_evidence_and_report"
}
ACTIVE_INSPECTION_TOOLS = {
    "test_internet_connectivity", "ping_host", "diagnose_system", "diagnose_performance",
    "diagnose_cpu", "diagnose_ram", "diagnose_storage", "diagnose_network", "diagnose_application",
    "diagnose_browser", "diagnose_app_hang", "get_app_hang_details", "capture_screen_context",
    "capture_screen", "mouse_click", "mouse_move", "send_keyboard_input",
    "find_text_on_screen", "click_element_by_text", "get_installed_apps", "wait_for_ui_settle",
    "pick_best_on_screen_item", "focus_app_window", "diagnose_network_health",
    "deep_scan_wifi_spectrum", "audit_wifi_hardware_and_services",
    "analyze_multi_adapter_and_bands", "copy_selection_to_clipboard", "paste_clipboard_into_target",
    "wait_delay", "extract_metric", "scroll_and_inspect", "scroll_active_window", "engage_continuous_game_loop", "run_autonomous_agent"
}
STATE_CHANGING_TOOLS = {
    "launch_app", "focus_app", "restart_app", "open_file", "open_folder", "open_file_with",
    "open_url", "new_tab", "open_browser_profile", "click_mouse", "type_text", "press_hotkey",
    "drag_mouse", "move_mouse", "mouse_scroll", "mouse_down", "mouse_up", "hold_mouse",
    "move_mouse_pattern", "drag_window_border", "snap_window_drag", "move_window", "resize_window",
    "manage_window", "focus_window", "click_ui_element", "drag_element_to_element",
    "interact_form_element", "navigate_context_menu", "save_file_dialog", "gui_navigate_folder",
    "select_text_range", "select_file_range", "find_and_interact", "type_desktop_text",
    "remediate_wifi_stack", "save_active_document", "audit_and_reclaim_ram",
    "prepare_target_environment", "smart_cleanup_app", "record_task_evidence_and_report",
    "scroll_and_inspect", "scroll_active_window", "engage_continuous_game_loop", "run_autonomous_agent"
} | MUTATIVE_TOOLS


# O(1) Indexed Lookups for sub-second latency and zero-allocation queries
_TOOL_SCHEMA_INDEX: dict[str, dict] = {}
_TOOL_REQUIRED_PARAMS: dict[str, set[str]] = {}
_TOOL_DISRUPTION_MAP: dict[str, DisruptionLevel] = {}
_ALL_SCHEMAS_CACHE: list[dict] = []

# Pre-populate disruption map at module load time
for _t in DESTRUCTIVE_TOOLS:
    _TOOL_DISRUPTION_MAP[_t] = DisruptionLevel.DESTRUCTIVE
for _t in MUTATIVE_TOOLS:
    _TOOL_DISRUPTION_MAP[_t] = DisruptionLevel.MUTATIVE
for _t in STATE_CHANGING_TOOLS:
    if _t not in _TOOL_DISRUPTION_MAP:
        _TOOL_DISRUPTION_MAP[_t] = DisruptionLevel.BENIGN_STATE_CHANGE
for _t in ACTIVE_INSPECTION_TOOLS:
    _TOOL_DISRUPTION_MAP[_t] = DisruptionLevel.ACTIVE_INSPECTION


_TOOL_DISRUPTION_INT_MAP: dict[str, int] = {k: int(v) for k, v in _TOOL_DISRUPTION_MAP.items()}


def get_tool_disruption_level(name: str) -> DisruptionLevel:
    """Returns the DisruptionLevel enum value for a tool (O(1) lookup)."""
    return _TOOL_DISRUPTION_MAP.get(name, DisruptionLevel.READ_ONLY)


def disruption_cost(name: str) -> int:
    """Returns integer disruption cost (0-4) according to the Least-Disruptive Action Principle (O(1))."""
    return _TOOL_DISRUPTION_INT_MAP.get(name, 0)


def _infer_risk_level(name: str, explicit_risk: str | None = None) -> str:
    """Infers risk level ('read_only', 'state_changing', 'destructive') for a tool."""
    if explicit_risk:
        return explicit_risk.lower()
    if name in DESTRUCTIVE_TOOLS:
        return "destructive"
    if name in STATE_CHANGING_TOOLS:
        return "state_changing"
    return "read_only"



_TOOL_RAM_CONFIG_PATH = Path(__file__).resolve().parent.parent / "config" / "tool_ram.json"
_DEFAULT_TOOL_RAM: dict[str, dict] = {}


def _load_tool_ram_config() -> dict[str, dict]:
    global _DEFAULT_TOOL_RAM
    if not _DEFAULT_TOOL_RAM and _TOOL_RAM_CONFIG_PATH.exists():
        try:
            import json
            with open(_TOOL_RAM_CONFIG_PATH, "r", encoding="utf-8") as f:
                _DEFAULT_TOOL_RAM = json.load(f)
        except Exception:
            _DEFAULT_TOOL_RAM = {}
    return _DEFAULT_TOOL_RAM


def tool(
    name: str,
    description: str,
    parameters: dict,
    risk_level: str | None = None,
    category: str | None = None,
    preconditions: list[str] | None = None,
    ram_mb: int | None = None,
    cpu_class: str | None = None
):
    """
    Decorator to register a function as an agent tool with complete semantic contract metadata.
    Backward-compatible: ram_mb and cpu_class are optional, defaulting to config/tool_ram.json or light.
    """
    def decorator(func):
        inferred_risk = _infer_risk_level(name, risk_level)
        mod_name = func.__module__
        cat = category or (mod_name.split(".")[-1] if "." in mod_name else "general")
        
        level = get_tool_disruption_level(name)
        tool_schema = {
            "type": "function",
            "function": {
                "name": name,
                "description": description,
                "parameters": parameters,
            },
        }
        req_set = set(parameters.get("required", [])) if isinstance(parameters, dict) else set()
        
        # Pre-index for O(1) retrieval
        _TOOL_SCHEMA_INDEX[name] = tool_schema
        _TOOL_REQUIRED_PARAMS[name] = req_set
        _TOOL_DISRUPTION_MAP[name] = level

        # Resolve RAM and CPU resource metadata
        cfg = _load_tool_ram_config().get(name, {})
        final_ram_mb = int(ram_mb) if ram_mb is not None else int(cfg.get("ram_mb", 5))
        final_cpu_class = str(cpu_class or cfg.get("cpu_class", "light")).lower()
        cost_source = "code" if (ram_mb is not None or cpu_class is not None) else cfg.get("source", "estimate")
        cost_dict = {
            "ram_mb": final_ram_mb,
            "cpu_class": final_cpu_class,
            "source": cost_source
        }

        TOOLS[name] = {
            "func": func,
            "module": mod_name,
            "func_name": func.__name__,
            "schema": tool_schema,
            "metadata": {
                "name": name,
                "description": description,
                "category": cat,
                "risk_level": inferred_risk,
                "disruption_level": level,
                "disruption_cost": int(level),
                "is_read_only": inferred_risk == "read_only",
                "is_destructive": inferred_risk == "destructive",
                "is_state_changing": inferred_risk in ("state_changing", "destructive"),
                "preconditions": preconditions or [],
                "parameters": parameters,
                "ram_mb": final_ram_mb,
                "cpu_class": final_cpu_class,
                "cost_source": cost_source,
                "cost": cost_dict,
            }
        }
        return func
    return decorator


def discover_tools(force: bool = False):
    """
    Import every module inside tools/ so their @tool decorators run and
    self-register. Call this at startup or to refresh registered tools.
    """
    global _DISCOVERED, _ALL_SCHEMAS_CACHE
    if _DISCOVERED and not force:
        return
    if force:
        _ALL_SCHEMAS_CACHE.clear()
        _TOOL_SCHEMA_INDEX.clear()
        _TOOL_REQUIRED_PARAMS.clear()

    package_dir = Path(__file__).parent
    for _, module_name, is_pkg in pkgutil.iter_modules([str(package_dir)]):
        if module_name in ("registry", "utils", "upgrade_cognitive_engine") or is_pkg:
            continue
        full_name = f"tools.{module_name}"
        if full_name in sys.modules:
            if force:
                importlib.reload(sys.modules[full_name])
        else:
            importlib.import_module(full_name)
    # Discover autonomous cognitive engine tools
    try:
        if "brain.autonomous_agent" in sys.modules and force:
            importlib.reload(sys.modules["brain.autonomous_agent"])
        else:
            importlib.import_module("brain.autonomous_agent")
    except Exception:
        pass

    # Register read_file_text alias targeting read_file
    if "read_file" in TOOLS and "read_file_text" not in TOOLS:
        read_entry = dict(TOOLS["read_file"])
        alias_schema = {
            "type": "function",
            "function": {
                "name": "read_file_text",
                "description": read_entry.get("schema", {}).get("function", {}).get("description", "Read content of a text file"),
                "parameters": read_entry.get("schema", {}).get("function", {}).get("parameters", {}),
            },
        }
        alias_meta = dict(read_entry.get("metadata", {}))
        alias_meta["name"] = "read_file_text"
        TOOLS["read_file_text"] = {
            "func": read_entry["func"],
            "module": read_entry.get("module"),
            "func_name": read_entry.get("func_name"),
            "schema": alias_schema,
            "metadata": alias_meta,
        }

    # Re-sync O(1) indexes
    for name, entry in TOOLS.items():
        if name not in _TOOL_SCHEMA_INDEX:
            _TOOL_SCHEMA_INDEX[name] = entry["schema"]
        if name not in _TOOL_REQUIRED_PARAMS:
            params = entry.get("schema", {}).get("function", {}).get("parameters", {})
            _TOOL_REQUIRED_PARAMS[name] = set(params.get("required", [])) if isinstance(params, dict) else set()
        if name not in _TOOL_DISRUPTION_MAP:
            _TOOL_DISRUPTION_MAP[name] = get_tool_disruption_level(name)
        _TOOL_DISRUPTION_INT_MAP[name] = int(_TOOL_DISRUPTION_MAP[name])

    _ALL_SCHEMAS_CACHE = [entry["schema"] for entry in TOOLS.values()]
    _DISCOVERED = True


def get_all_schemas():
    """Returns the list of tool schemas to hand to the LLM (cached for O(1) performance)."""
    global _ALL_SCHEMAS_CACHE
    if not _DISCOVERED:
        discover_tools()
    if not _ALL_SCHEMAS_CACHE:
        _ALL_SCHEMAS_CACHE = [entry["schema"] for entry in TOOLS.values()]
    return _ALL_SCHEMAS_CACHE


def get_tool_schema(name: str) -> dict | None:
    """Returns tool schema dictionary via O(1) lookup."""
    if not _DISCOVERED or name not in _TOOL_SCHEMA_INDEX:
        discover_tools()
    if name == "read_file_text" and name not in _TOOL_SCHEMA_INDEX and "read_file" in _TOOL_SCHEMA_INDEX:
        return _TOOL_SCHEMA_INDEX.get("read_file")
    return _TOOL_SCHEMA_INDEX.get(name)


def generate_tool_registry_json_schema(tools_subset: list[str] | None = None) -> dict:
    """
    Generates a unified JSON schema for structured output validation (Level 1),
    enforcing that model responses adhere strictly to tool names and arguments
    from the real tool registry, or to chat/clarify responses.
    """
    if not _DISCOVERED:
        discover_tools()

    schemas = get_all_schemas()
    tool_names = []
    for s in schemas:
        fn = s.get("function", {})
        name = fn.get("name")
        if name and (tools_subset is None or name in tools_subset):
            tool_names.append(name)

    return {
        "type": "object",
        "properties": {
            "type": {
                "type": "string",
                "enum": ["tool_call", "chat", "clarify", "refuse"]
            },
            "tool": {
                "type": "string",
                "enum": tool_names if tool_names else ["launch_app", "execute_command"]
            },
            "arguments": {
                "type": "object"
            },
            "message": {
                "type": "string"
            },
            "question": {
                "type": "string"
            }
        },
        "required": ["type"]
    }


def get_tool(name: str):
    if not _DISCOVERED or name not in TOOLS:
        discover_tools()
    entry = TOOLS.get(name)
    if not entry and name == "read_file_text" and "read_file" in TOOLS:
        entry = TOOLS.get("read_file")
    if entry:
        mod_name = entry.get("module")
        func_name = entry.get("func_name")
        if mod_name and func_name and mod_name in sys.modules:
            mod = sys.modules[mod_name]
            return getattr(mod, func_name, entry["func"])
        return entry["func"]
    return None


def get_tool_metadata(name: str) -> dict | None:
    """Returns complete semantic contract metadata for a registered tool."""
    if not _DISCOVERED or name not in TOOLS:
        discover_tools()
    entry = TOOLS.get(name)
    return entry.get("metadata") if entry else None


def get_tool_cost(name: str) -> dict:
    """
    Returns resource cost metadata for a tool:
    {"ram_mb": int, "cpu_class": "light" | "medium" | "heavy", "source": "code" | "estimate"}
    """
    if not _DISCOVERED or name not in TOOLS:
        discover_tools()
    meta = get_tool_metadata(name)
    if meta and "cost" in meta:
        return meta["cost"]
    if meta and "ram_mb" in meta and "cpu_class" in meta:
        return {
            "ram_mb": int(meta["ram_mb"]),
            "cpu_class": str(meta["cpu_class"]).lower(),
            "source": meta.get("cost_source", "estimate"),
        }
    cfg = _load_tool_ram_config().get(name)
    if not cfg:
        return {
            "ram_mb": 30,
            "cpu_class": "medium",
            "source": "unknown-default",
        }
    return {
        "ram_mb": int(cfg.get("ram_mb", 30)),
        "cpu_class": str(cfg.get("cpu_class", "medium")).lower(),
        "source": cfg.get("source", "estimate"),
    }


def get_tool_risk(name: str) -> str:
    """Returns the risk level of a tool ('read_only', 'state_changing', 'destructive')."""
    meta = get_tool_metadata(name)
    return meta["risk_level"] if meta else "read_only"


def is_read_only(name: str) -> bool:
    """Checks if a tool is strictly read-only inspection."""
    meta = get_tool_metadata(name)
    return meta["is_read_only"] if meta else True


def is_destructive(name: str) -> bool:
    """Checks if a tool is destructive (requires confirmation)."""
    meta = get_tool_metadata(name)
    return meta["is_destructive"] if meta else False


def get_all_capabilities() -> dict[str, dict]:
    """Returns a dictionary of all registered tools and their capability contracts."""
    if not _DISCOVERED:
        discover_tools()
    return {name: entry.get("metadata", {}) for name, entry in TOOLS.items()}


def check_parameter_feasibility(tool_name: str, args: dict | None) -> tuple[bool, list[str]]:
    """
    Validates whether the required arguments for `tool_name` are present and non-empty.
    Returns (is_feasible, missing_parameters) using O(1) indexed set operations.
    """
    if not _DISCOVERED or tool_name not in _TOOL_REQUIRED_PARAMS:
        discover_tools()

    required = _TOOL_REQUIRED_PARAMS.get(tool_name)
    if required is None:
        entry = TOOLS.get(tool_name)
        if not entry:
            return True, []
        req_list = entry.get("schema", {}).get("function", {}).get("parameters", {}).get("required", [])
        required = set(req_list)
        _TOOL_REQUIRED_PARAMS[tool_name] = required

    if not required:
        return True, []

    if args is None:
        return False, list(required)

    missing = []
    for req in required:
        val = args.get(req)
        if val is None:
            if req == "source" and "src" in args:
                val = args["src"]
            elif req == "destination" and "dest" in args:
                val = args["dest"]
            elif req == "target_query" and "query" in args:
                val = args["query"]
            elif req == "query" and ("target_query" in args or "element_name" in args):
                val = args.get("target_query") or args.get("element_name")
            elif req == "element_name" and ("query" in args or "target_query" in args):
                val = args.get("query") or args.get("target_query")
            elif req == "app_name" and "target_window" in args:
                val = args["target_window"]
            elif req == "target_window" and "app_name" in args:
                val = args["app_name"]
            elif req == "name" and ("name_or_pid" in args or "app_name" in args):
                val = args.get("name_or_pid") or args.get("app_name")
            elif req == "name_or_pid" and ("name" in args or "app_name" in args):
                val = args.get("name") or args.get("app_name")
        if val is None:
            missing.append(req)
        elif isinstance(val, str) and not val.strip():
            missing.append(req)

    return (len(missing) == 0), missing


def calculate_semantic_affinity(
    tool_name: str,
    action: str,
    domain: str,
    target_type: str = "",
    args: dict | None = None,
    prefer_read_only: bool = False
) -> float:
    """
    Calculates semantic affinity score (0.0 to 1.0+) between intent and tool capability contract.
    Penalizes keyword collisions, parameter infeasibility, and high disruption cost when safer
    alternatives exist.
    """
    if not _DISCOVERED or tool_name not in TOOLS:
        discover_tools()
    meta = get_tool_metadata(tool_name)
    if not meta:
        return 0.0

    score = 0.5
    tool_lower = tool_name.lower()
    cat_lower = meta.get("category", "").lower()
    desc_lower = meta.get("description", "").lower()
    act_lower = action.lower()
    dom_lower = domain.lower()
    tgt_lower = target_type.lower()

    # 1. Domain alignment
    if dom_lower:
        if dom_lower in cat_lower or cat_lower in dom_lower:
            score += 0.25
        elif dom_lower in desc_lower:
            score += 0.15

    # 2. Action alignment
    if act_lower:
        if act_lower in tool_lower:
            score += 0.3
        elif act_lower in desc_lower:
            score += 0.15

    # 3. Target type affinity & confusable routing
    if tgt_lower in ("url", "website", "web"):
        if tool_name in ("open_url", "new_tab", "navigate_browser"):
            score += 0.4
        elif tool_name in ("launch_app", "search_files", "open_file"):
            score -= 0.6
    elif tgt_lower in ("folder", "directory"):
        if tool_name in ("list_folder", "open_folder"):
            score += 0.4
        elif tool_name in ("search_files", "launch_app"):
            score -= 0.3
    elif tgt_lower in ("file", "document"):
        if tool_name in ("open_file", "read_file", "read_file_text", "search_files", "find_file"):
            score += 0.35
        elif tool_name in ("launch_app", "list_folder"):
            score -= 0.25
    elif tgt_lower in ("application", "app"):
        if tool_name in ("launch_app", "focus_app", "close_app", "get_application_status", "is_app_running"):
            score += 0.35
        elif tool_name in ("open_url",):
            score -= 0.5
    elif tgt_lower in ("process",):
        if tool_name in ("kill_process", "find_process", "get_process_cpu"):
            score += 0.35

    # 4. Action Specific Hardening (Graceful close vs brutal kill)
    if act_lower in ("close", "band"):
        if tool_name in ("close_app", "manage_window"):
            score += 0.3
        elif tool_name in ("kill_process", "terminate_process"):
            score -= 0.4
    elif act_lower in ("kill", "force_close", "terminate"):
        if tool_name in ("kill_process", "terminate_process"):
            score += 0.4
        elif tool_name in ("close_app",):
            score -= 0.1

    # 5. Granularity: fine-grained telemetry vs broad diagnostic
    if act_lower in ("query_space", "free_space", "disk_space"):
        if tool_name == "get_free_space":
            score += 0.5
        elif tool_name in ("diagnose_system", "diagnose_storage"):
            score -= 0.2
    elif act_lower in ("query_cpu", "cpu_status"):
        if tool_name == "get_cpu_status":
            score += 0.5
        elif tool_name in ("diagnose_system", "diagnose_performance"):
            score -= 0.2
    elif act_lower in ("query_memory", "ram_status"):
        if tool_name == "get_memory_status":
            score += 0.5
        elif tool_name in ("diagnose_system", "diagnose_performance"):
            score -= 0.2

    # 6. Disruption Level / Least-Disruptive Principle
    level = get_tool_disruption_level(tool_name)
    if prefer_read_only or act_lower in ("inspect", "query", "check", "status", "list", "read", "view"):
        if level == DisruptionLevel.READ_ONLY:
            score += 0.2
        elif level == DisruptionLevel.ACTIVE_INSPECTION:
            score += 0.05
        elif level == DisruptionLevel.BENIGN_STATE_CHANGE:
            score -= 0.3
        elif level == DisruptionLevel.MUTATIVE:
            score -= 0.6
        elif level == DisruptionLevel.DESTRUCTIVE:
            score -= 1.0

    # 7. Parameter feasibility check
    if args is not None:
        feasible, missing = check_parameter_feasibility(tool_name, args)
        if not feasible:
            score -= 0.5

    return round(score, 4)


def resolve_optimal_tool(
    candidate_tools: list[str],
    action: str,
    domain: str,
    target_type: str = "",
    args: dict | None = None,
    prefer_read_only: bool = False
) -> tuple[str | None, float]:
    """
    Selects the optimal tool from candidate list using semantic affinity scoring and least-disruption ordering.
    Returns (best_tool_name, score).
    """
    if not candidate_tools:
        return None, 0.0

    scored = []
    for t in candidate_tools:
        aff = calculate_semantic_affinity(
            tool_name=t,
            action=action,
            domain=domain,
            target_type=target_type,
            args=args,
            prefer_read_only=prefer_read_only
        )
        cost = disruption_cost(t)
        scored.append((aff, -cost, t))

    scored.sort(reverse=True)
    best_aff, _, best_tool = scored[0]
    return best_tool, best_aff


# Auto-index GUI controller tools for sub-second O(1) latency
try:
    import tools.gui_controller  # noqa: F401
except Exception:
    pass


def run_autonomous_agent(*args, **kwargs):
    from brain.autonomous_agent import run_autonomous_agent as _raa
    return _raa(*args, **kwargs)




