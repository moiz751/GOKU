"""Repository catalog (stage F18): ONE decision per repository, used by the engines (what to probe) and by scripts/engine_inventory.py (what to report).
Roles follow the rule 'do not inject everything': core | adapter | skill | evaluator | optional. Nothing here imports, installs or downloads a repository:
python modules are only PROBED (importlib.util.find_spec) by the engine that lists them; every other class stays reference-only on purpose (see 'why').
Licences and URL liveness are not verified (the build sandbox cannot confirm GitHub)."""
from __future__ import annotations

from typing import Dict, List, Tuple

# repository slug (lower-case repo name) -> canonical slug, for the same project listed under an old/mirror owner
ALIASES: Dict[str, str] = {"ggerganov/llama.cpp": "ggml-org/llama.cpp", "joaomdmoura/crewai": "crewaiinc/crewai", "all-hands-ai/openhands": "openhands/openhands",
                           "kyamagu/faiss-wheels": "facebookresearch/faiss", "sqlite/sqlite": "sqlite/sqlite"}
SUSPECT_URLS = {"illuin-tech/colbert": "probably meant stanford-futuredata/ColBERT or illuin-tech/colpali", "sqlite/sqlite": "unofficial mirror of SQLite; GOKU uses the stdlib sqlite3",
                "microsoft/graphrag": "listed as 'GraphRAG'; real repo name is lower-case graphrag", "vibrantlabsai/ragas": "ragas is usually explodinggradients/ragas",
                "trulens/trulens": "trulens is usually truera/trulens", "deepchecks/deepchecks": "check owner capitalisation", "answerdotai/rerankers": "check owner/repo spelling"}

# slug -> (python module probed, engine that may use it, role)
PROBED: Dict[str, Tuple[str, str, str]] = {
    "transformers": ("transformers", "linguistic", "optional"), "optimum": ("optimum", "analytical", "optional"), "onnxruntime": ("onnxruntime", "visual", "optional"),
    "sentence-transformers": ("sentence_transformers", "linguistic", "optional"), "flagembedding": ("FlagEmbedding", "research", "optional"), "rerankers": ("rerankers", "research", "optional"),
    "bertopic": ("bertopic", "linguistic", "optional"), "faiss": ("faiss", "memory", "optional"), "chroma": ("chromadb", "memory", "optional"), "lancedb": ("lancedb", "memory", "optional"),
    "sqlite-vec": ("sqlite_vec", "memory", "optional"), "gptcache": ("gptcache", "memory", "optional"), "mem0": ("mem0", "memory", "optional"), "letta": ("letta", "memory", "optional"),
    "cognee": ("cognee", "memory", "optional"), "graphiti": ("graphiti_core", "memory", "optional"), "duckdb": ("duckdb", "analytical", "optional"), "dask": ("dask", "analytical", "optional"),
    "joblib": ("joblib", "analytical", "optional"), "networkx": ("networkx", "strategic", "optional"), "or-tools": ("ortools", "strategic", "optional"), "pyomo": ("pyomo", "decision", "optional"),
    "tenacity": ("tenacity", "execution", "adapter"), "python-sdk": ("mcp", "execution", "adapter"), "pytest": ("pytest", "programming", "evaluator"), "hypothesis": ("hypothesis", "programming", "evaluator"),
    "pydantic": ("pydantic", "programming", "adapter"), "semgrep": ("semgrep", "cybersecurity", "evaluator"), "deepeval": ("deepeval", "adaptive", "evaluator"), "ragas": ("ragas", "adaptive", "evaluator"),
    "guardrails": ("guardrails", "adaptive", "evaluator"), "lm-evaluation-harness": ("lm_eval", "adaptive", "evaluator"), "inspect_ai": ("inspect_ai", "adaptive", "evaluator"),
    "phoenix": ("phoenix", "adaptive", "evaluator"), "langfuse": ("langfuse", "adaptive", "evaluator"), "opik": ("opik", "adaptive", "evaluator"), "trulens": ("trulens", "adaptive", "evaluator"),
    "deepchecks": ("deepchecks", "adaptive", "evaluator"), "evidently": ("evidently", "adaptive", "evaluator"), "opentelemetry-python": ("opentelemetry", "adaptive", "adapter"),
    "dvc": ("dvc", "adaptive", "optional"), "dspy": ("dspy", "research", "optional"), "llmlingua": ("llmlingua", "linguistic", "optional"), "scikit-learn": ("sklearn", "analytical", "optional"),
    "sympy": ("sympy", "mathematical", "optional"), "z3": ("z3", "logical", "optional"), "spacy": ("spacy", "linguistic", "optional"), "shapely": ("shapely", "spatial", "optional"),
    "numpy": ("numpy", "analytical", "optional"), "playwright": ("playwright", "visual", "adapter"), "polars": ("polars", "analytical", "optional"), "docling": ("docling", "linguistic", "optional"),
    "easyocr": ("easyocr", "visual", "optional"), "paddleocr": ("paddleocr", "visual", "optional"), "biopython": ("Bio", "scientific", "optional"), "rdkit": ("rdkit", "scientific", "optional"),
    "optuna": ("optuna", "decision", "optional"), "simpy": ("simpy", "strategic", "optional"), "jax": ("jax", "mathematical", "optional"), "pymc": ("pymc", "analytical", "optional"),
    "stanza": ("stanza", "linguistic", "optional"), "argos-translate": ("argostranslate", "linguistic", "optional"), "openmm": ("openmm", "scientific", "optional"), "pysmt": ("pysmt", "logical", "optional"),
    "kanren": ("kanren", "logical", "optional"), "pyvista": ("pyvista", "spatial", "optional"), "open3d": ("open3d", "spatial", "optional"), "dowhy": ("dowhy", "analytical", "optional"),
    "econml": ("econml", "analytical", "optional"), "salib": ("SALib", "decision", "optional"), "presidio": ("presidio_analyzer", "cybersecurity", "evaluator"), "marker": ("marker", "linguistic", "optional"),
    "opencv": ("cv2", "visual", "optional"), "pandas": ("pandas", "analytical", "optional"), "scipy": ("scipy", "analytical", "optional"), "yara": ("yara", "cybersecurity", "evaluator"),
}
ALREADY = {"ollama": "GOKU already drives Ollama (brain/ollama_manager.py + ladder)", "llama.cpp": "GGUF runtime behind Ollama; no second runtime",
           "sqlite": "stdlib sqlite3 is GOKU's memory store (brain/memory_store.py)"}
OVERLAP = {s: "overlaps an existing GOKU module (orchestrator / planner_dag / doc_index / memory_store / skill_engine); GOKU stays the single decision-maker" for s in
           ("langchain", "langgraph", "crewai", "ag2", "autogen", "smolagents", "autogpt", "openhands", "camel", "metagpt", "taskweaver", "semantic-kernel", "pydantic-ai", "agno", "llama_index",
            "haystack", "flowise", "langflow", "dify", "browser-use", "open-interpreter", "agent-zero", "hermes-agent", "all-rag-techniques", "langmem", "graphrag", "lightrag", "ragflow",
            "quivr", "prefect", "temporal", "n8n", "dagster", "airflow", "luigi", "dispatch", "opentelemetry-collector")}
HEAVY = {s: "separate server/GPU/training stack, not a library an offline desktop agent should load; native path covers the need" for s in
         ("localai", "koboldcpp", "vllm", "sglang", "text-embeddings-inference", "mlx", "mlx-lm", "openvino", "tensorrt-llm", "server", "bitnet", "llamafile", "inference", "lmdeploy", "exo",
          "whisper.cpp", "unsloth", "autogptq", "gptq", "qlora", "peft", "bitsandbytes", "gptqmodel", "deepspeed", "megatron-lm", "flash-attention", "colbert", "qdrant", "neo4j", "redis",
          "pgvector", "weaviate", "milvus", "zep", "cuml", "ray", "promptfoo", "nemo-guardrails", "searxng", "comfyui", "scrapy", "tika", "lean4")}
EXCLUDED = {"litellm": "API router for cloud providers (offline rule)", "evals": "OpenAI evals need the OpenAI API (offline rule)"}


def classify(slug: str) -> Tuple[str, str, str, str]:
    """-> (decision, why, engine, role)"""
    s = slug.lower()
    if s.startswith("awesome-"):
        return "DISCOVERY_ONLY", "link list used to find more projects, never installed", "", "skill"
    if s in ALREADY:
        return "ALREADY_IN_GOKU", ALREADY[s], "", "core"
    if s in EXCLUDED:
        return "EXCLUDED_OFFLINE", EXCLUDED[s], "", ""
    if s in PROBED:
        mod, eng, role = PROBED[s]
        return "OPTIONAL_PROBED", f"engine '{eng}' uses module '{mod}' only if it is already installed; the native stdlib path always exists", eng, role
    if s in OVERLAP:
        return "NOT_INTEGRATED_OVERLAP", OVERLAP[s], "", ""
    if s in HEAVY:
        return "NOT_INTEGRATED_SERVER_OR_HEAVY", HEAVY[s], "", ""
    return "REFERENCE_ONLY", "not imported; no engine needs it, or it needs heavy/GPU/network components", "", ""


def probes_for(engine: str) -> List[str]:
    return sorted({m for m, e, _ in PROBED.values() if e == engine})
