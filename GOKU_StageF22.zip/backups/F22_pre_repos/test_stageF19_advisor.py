"""Stage F19: request advisor. Each case is a request the user actually typed (misspelt Roman Urdu included) and the honest answer GOKU must give."""

import pytest

from brain import request_advisor as ra
from brain.verifier import verify_advice


@pytest.fixture(autouse=True)
def _dirs(tmp_path, monkeypatch):
    monkeypatch.setenv("GOKU_ADAPTIVE_DIR", str(tmp_path))
    monkeypatch.delenv("GOKU_ONLINE", raising=False)


def A(t):
    r = ra.advise(t)
    assert verify_advice(r)["ok"], (t, r, verify_advice(r))
    return r


@pytest.mark.parametrize("text,status,intent", [
    ("mujhay Avenger end game download ker", "BLOCKED", "media_download"),
    ("Avengers Endgame torrent download", "BLOCKED", "media_download"),
    ("mujhe is chez ki image download ker k dikha pher del ker de", "PENDING_NEEDS_INTERNET", "image_download"),
    ("live essay likh mara samna", "CAN", "write_live"),
    ("is chat ko is time per massage ker di", "PENDING_NEEDS_SETUP", "message_chat"),
    ("mari health scan ker", "CLARIFY", "health"),
    ("mari video bana ker", "PARTIAL", "make_video"),
    ("mara runing or execerise ka sechudal design ker mara body k hesab say", "CAN", "exercise"),
    ("mujhay is range ma laptop lana h", "PARTIAL", "laptop"),
    ("yak glasses bana chata hu machinical ma mujhay is k structure bana", "PARTIAL", "glasses"),
    ("ma video editing kerna chata hu", "PARTIAL", "editing"),
    ("is mont ki full report bana", "CAN", "monthly_report"),
    ("voice command samajh sakta hai?", "CANNOT_YET", "voice"),
    ("doctor doom", "UNKNOWN", "unknown_entity"),
    ("kuch download kar", "CLARIFY", "download_unclear"),
    ("notepad kholo", "CAN", "standard_command"),
])
def test_user_requests_get_the_honest_status(text, status, intent):
    r = A(text)
    assert (r["status"], r["intent"]) == (status, intent)


def test_piracy_is_blocked_with_legal_options_and_never_planned():
    r = A("Avengers Endgame download kar")
    assert r["status"] == "BLOCKED" and r["alternatives"] and "steps" not in r and "pending_id" not in r
    assert A("free full movie hd print crack")["status"] == "BLOCKED"


def test_installer_download_is_official_source_with_approvals_only():
    r = A("chrome.exe installer download karo")
    assert r["intent"] == "file_download" and all(s["approval"] for s in r["steps"] if "download" in s["step"] or "chalana" in s["step"])
    assert "SmartScreen" in r["say"]


def test_image_download_plan_asks_approval_for_download_and_delete():
    r = A("is tasveer ko download karke dikhao phir delete kar do")
    assert [s["approval"] for s in r["steps"]] == [True, False, True]


def test_spelling_confident_fix_is_shown_and_doubtful_is_asked():
    r = A("mari galat speling dowload imge")
    assert r["intent"] == "image_download" and {f["to"] for f in r["spelling_fixed"]} == {"download", "image"} and "samjha" in r["say"]
    d = ra.advise("xqzv plmk")
    assert d["status"] == "UNKNOWN" and d["questions"]


def test_unknown_input_asks_instead_of_guessing():
    r = A("wo cheez jo kal wali thi karna")
    assert r["status"] == "CLARIFY" and r["questions"]


def test_pending_list_keeps_internet_tasks_and_tells_what_is_needed(monkeypatch):
    r = A("web search karo laptop prices")
    assert r["status"] == "PENDING_NEEDS_INTERNET" and r["pending_id"]
    again = ra.advise("web search karo laptop prices")
    assert again["pending_id"] == r["pending_id"]                      # not duplicated
    p = ra.pending_requests()
    assert len(p) == 1 and "internet" in p[0]["needs"]
    assert "pending" in ra.handle_command("advise pending") or "req" in ra.handle_command("advise pending")


def test_online_mode_changes_status_honestly(monkeypatch):
    monkeypatch.setenv("GOKU_ONLINE", "1")
    assert A("web search karo")["status"] == "PARTIAL" and A("web search karo")["online"] is True


def test_secret_is_redacted_in_request_log():
    ra.advise("message bhej chat password: hunter2secret")
    log = (ra._dir() / "request_log.jsonl").read_text(encoding="utf-8")
    assert "hunter2secret" not in log
    assert ra.stats()["requests"] == 1


def test_unhandled_requests_feed_skill_growth(tmp_path):
    for t in ("zorblax quantum", "zorblax quantum", "zorblax quantum"):
        r = ra.advise(t)
    assert r.get("skill_growth") == "PROPOSED"


def test_verify_advice_rejects_dishonest_answers():
    assert not verify_advice({"status": "PENDING_NEEDS_INTERNET", "say": "x", "needs": ["internet"]})["ok"]
    assert not verify_advice({"status": "BLOCKED", "say": "ho gaya, done"})["ok"]
    assert not verify_advice({"status": "CLARIFY", "say": "kya?"})["ok"]
    assert not verify_advice({"status": "MAYBE", "say": "x"})["ok"]


def test_capabilities_list_voice_is_honestly_not_present():
    caps = {c["area"]: c["status"] for c in ra.capabilities()}
    assert caps["voice"] == "CANNOT_YET" and caps["media_download"] == "BLOCKED" and caps["write_live"] == "CAN"


def test_route_and_command():
    from brain import f15_tasks
    assert f15_tasks.match("advise Avengers download") == "advise" and f15_tasks.match("capabilities") == "advise"
    assert f15_tasks.match("open notepad") != "advise"
    assert ra.handle_command("open notepad") is None
    assert "BLOCKED" in ra.handle_command("advise Avengers Endgame download")


def test_windows_check_script_exists_and_has_bat():
    from pathlib import Path
    root = Path(__file__).resolve().parent.parent
    assert (root / "scripts" / "windows_real_check.py").is_file() and (root / "RUN_WINDOWS_CHECK.bat").is_file()
    import ast
    ast.parse((root / "scripts" / "windows_real_check.py").read_text(encoding="utf-8"))


# ---- F20: hard / different tasks must get an honest, specific answer (not "not understood")
@pytest.mark.parametrize("text,status,intent", [
    ("3d model bana de", "PARTIAL", "model_3d"),
    ("mere papers aur syllabus parh kar sab seekh phir mujhay bata", "PARTIAL", "study_docs"),
    ("mera ye question hal kar papers dekh kar", "PARTIAL", "solve_question"),
    ("ek aisa game bana jo pehle kabhi nahi bana", "PARTIAL", "creative_build"),
    ("khud ko improve kar in kamo ke liye", "CAN", "self_improve"),
])
def test_hard_tasks_are_answered_honestly(tmp_path, monkeypatch, text, status, intent):
    monkeypatch.setenv("GOKU_ADAPTIVE_DIR", str(tmp_path))
    from brain import request_advisor as r
    a = r.advise(text, log=False)
    assert (a["status"], a["intent"]) == (status, intent)
    assert verify_advice(a)["ok"], verify_advice(a)
