"""
Screen Understanding Engine — ONE Eye for GOKU Autonomous Desktop Agent.
Single authoritative owner of screen perception, UI hierarchy observation,
multi-tier accessibility ground-truth, and dialog safety policy.

Tier Execution Order:
1. UIA (pywinauto / uiautomation lazy, falling back to native Win32/MSAA)
2. Win32 (native controls, top-level menus, Shell_TrayWnd, SysListView32 icons)
3. OCR (on-demand only, region-limited, lazy pytesseract, immediate memory cleanup)

Cache:
Per-window 1.0-second TTL cache to minimize CPU/RAM overhead on 4GB hardware.
"""
from __future__ import annotations

import ctypes
from ctypes import wintypes
import gc
import sys
import time
from typing import Any, Optional

# Per-Monitor-V2 DPI awareness: must be initialized before any GUI/Win32 APIs
if sys.platform == "win32":
    try:
        _u32 = ctypes.windll.user32
        if hasattr(_u32, "SetProcessDpiAwarenessContext"):
            _u32.SetProcessDpiAwarenessContext(ctypes.c_void_p(-4))
        elif hasattr(ctypes.windll, "shcore") and hasattr(ctypes.windll.shcore, "SetProcessDpiAwareness"):
            ctypes.windll.shcore.SetProcessDpiAwareness(2)
        else:
            _u32.SetProcessDPIAware()
    except Exception:
        pass

from tools.registry import tool
from tools.screen import get_screen_size, take_screenshot
from tools.vision.element_matcher import match_ui_element
from tools.vision.ui_inspector import UIElement, inspect_windows_hierarchy

# ---------------------------------------------------------------------------
# Global In-Memory Cache (1.0 second TTL per window scope)
# ---------------------------------------------------------------------------
_OBSERVE_CACHE: dict[tuple[Any, bool], tuple[float, dict[str, Any]]] = {}
CACHE_TTL_SECONDS: float = 1.0

# Named constants sized for 4 GB RAM target environment (Prompt I1b P3)
DEFAULT_MAX_ELEMENTS: int = 250
DEFAULT_UIA_TIMEOUT_SECONDS: float = 3.5
MAX_VERIFICATIONS_PER_OBSERVE: int = 40
MAX_VERIFICATION_TIME_MS: float = 120.0
OCR_NO_CONFIDENCE: float = 0.6  # policy value, backend provides none

# Priority roles and names for click point verification (Prompt I1b P2)
_VERIFICATION_PRIORITY_ROLES: frozenset[str] = frozenset([
    "window",
    "pane",
    "tool_bar",
    "status_bar",
    "tab",
    "group",
    "list_item",
])
_VERIFICATION_PRIORITY_NAMES: frozenset[str] = frozenset([
    "minimize",
    "maximize",
    "close",
])

# Dialog safety-critical buttons that require explicit user instructions
BLOCKED_DIALOG_BUTTONS: frozenset[str] = frozenset([
    "save",
    "don't save",
    "dont save",
    "save as",
    "replace",
    "delete",
    "yes",
    "overwrite",
    "discard",
    "remove",
])


def _ensure_desktop_access(target_pid: int | None = None) -> None:
    """Attaches background worker threads to interactive desktop window station."""
    if sys.platform == "win32":
        try:
            u32 = ctypes.windll.user32
            k32 = ctypes.windll.kernel32
            curr_th = k32.GetCurrentThreadId()
            curr_desk = u32.GetThreadDesktop(curr_th)
            if curr_desk:
                buf = ctypes.create_unicode_buffer(256)
                u32.GetUserObjectInformationW(curr_desk, 2, buf, 512, None)
                if buf.value.lower() == "default":
                    return

            if target_pid:
                try:
                    import psutil
                    p = psutil.Process(target_pid)
                    threads = p.threads()
                    if threads:
                        th_desk = u32.GetThreadDesktop(threads[0].id)
                        if th_desk and th_desk != curr_desk:
                            u32.SetThreadDesktop(th_desk)
                            return
                except Exception:
                    pass

            h_desk = u32.OpenDesktopW("default", 0, False, 0x01FF)
            if h_desk:
                u32.SetThreadDesktop(h_desk)
        except Exception:
            pass


def _get_system_dpi_info(hwnd: int = 0) -> dict[str, int]:
    """Retrieves ground-truth DPI and scaling factor for system or target window."""
    dpi = 96
    scale = 100
    if sys.platform == "win32":
        try:
            u32 = ctypes.windll.user32
            if hwnd and hasattr(u32, "GetDpiForWindow"):
                d = u32.GetDpiForWindow(hwnd)
                if d > 0:
                    dpi = d
            elif hasattr(u32, "GetDpiForSystem"):
                d = u32.GetDpiForSystem()
                if d > 0:
                    dpi = d
            scale = int(round((dpi / 96.0) * 100))
        except Exception:
            pass
    return {"dpi": dpi, "scale_pct": scale}


def _get_active_foreground_window() -> tuple[int, str]:
    """Returns foreground window HWND and title."""
    _ensure_desktop_access()
    hwnd = 0
    title = ""
    if sys.platform == "win32":
        try:
            u32 = ctypes.windll.user32
            hwnd = int(u32.GetForegroundWindow())
            if hwnd:
                length = u32.GetWindowTextLengthW(hwnd) + 1
                if length > 1:
                    buff = ctypes.create_unicode_buffer(length)
                    u32.GetWindowTextW(hwnd, buff, length)
                    title = buff.value.strip()
        except Exception:
            pass
    return hwnd, title


def _extract_menu_bar_elements(hwnd: int) -> list[dict[str, Any]]:
    """
    Extracts native Win32 top-level menu bar items (File, Edit, View, etc.)
    with precise bounding boxes via GetMenu and GetMenuItemRect.
    """
    if sys.platform != "win32" or not hwnd:
        return []
    items: list[dict[str, Any]] = []
    try:
        u32 = ctypes.windll.user32
        u32.GetMenu.restype = wintypes.HMENU
        u32.GetMenu.argtypes = [wintypes.HWND]
        u32.GetMenuItemRect.argtypes = [wintypes.HWND, wintypes.HMENU, wintypes.UINT, ctypes.POINTER(wintypes.RECT)]
        u32.GetMenuItemRect.restype = wintypes.BOOL

        menu = u32.GetMenu(hwnd)
        if not menu:
            return []
        count = u32.GetMenuItemCount(menu)
        for idx in range(count):
            buf = ctypes.create_unicode_buffer(128)
            u32.GetMenuStringW(menu, idx, buf, 128, 0x0400)
            raw_text = buf.value.replace("&", "").strip()
            rc = wintypes.RECT()
            m_res = u32.GetMenuItemRect(hwnd, menu, idx, ctypes.byref(rc))
            if not raw_text:
                continue
            if m_res:
                cx = (rc.left + rc.right) // 2
                cy = (rc.top + rc.bottom) // 2
                items.append({
                    "name": raw_text,
                    "role": "menu_item",
                    "element_type": "menu_item",
                    "bounds": {"left": rc.left, "top": rc.top, "right": rc.right, "bottom": rc.bottom},
                    "center": {"x": cx, "y": cy},
                    "bounds_center": {"x": cx, "y": cy},
                    "click_verified": False,
                    "center_source": "bounds_center",
                    "source": "win32",
                    "confidence": 1.0,
                    "hwnd": hwnd,
                })
    except Exception:
        pass
    return items


UIA_CONTROL_TYPES: dict[int, str] = {
    50000: "button", 50001: "calendar", 50002: "check_box", 50003: "combo_box",
    50004: "edit", 50005: "hyperlink", 50006: "image", 50007: "list_item",
    50008: "list", 50009: "menu", 50010: "menu_bar", 50011: "menu_item",
    50012: "progress_bar", 50013: "radio_button", 50014: "scroll_bar", 50015: "slider",
    50016: "spinner", 50017: "status_bar", 50018: "tab", 50019: "tab_item",
    50020: "text", 50021: "tool_bar", 50022: "tool_tip", 50023: "tree",
    50024: "tree_item", 50025: "custom", 50026: "group", 50027: "thumb",
    50028: "data_grid", 50029: "data_item", 50030: "document", 50031: "split_button",
    50032: "window", 50033: "pane", 50034: "header", 50035: "header_item",
    50036: "table", 50037: "title_bar", 50038: "separator"
}


def _generate_candidate_click_points(b: dict[str, int], role: str, name: str) -> list[tuple[int, int]]:
    """
    Generates up to 6 candidate click points inside the element bounding rect (P2).
    Includes geometric center and inset points away from likely child controls.
    """
    left = b.get("left", 0)
    top = b.get("top", 0)
    right = b.get("right", 0)
    bottom = b.get("bottom", 0)
    w = right - left
    h = bottom - top
    if w <= 0 or h <= 0:
        return []

    cx0 = (left + right) // 2
    cy0 = (top + bottom) // 2

    candidates: list[tuple[int, int]] = []
    r_lower = role.lower()
    n_lower = name.lower()

    if r_lower in ("window", "pane"):
        top_y = top + min(22, max(8, h // 10))
        candidates.append((left + min(80, max(20, w // 4)), top_y))
        candidates.append((cx0, top_y))
        candidates.append((cx0, cy0))
        candidates.append((left + max(10, min(30, w // 8)), cy0))
        candidates.append((right - max(15, min(40, w // 8)), top_y))
        candidates.append((cx0, bottom - min(15, max(6, h // 10))))
    elif any(btn in n_lower for btn in ("minimize", "maximize", "close")):
        dx = max(3, min(10, w // 4))
        dy = max(3, min(10, h // 4))
        candidates.append((cx0, cy0))
        candidates.append((cx0, top + dy))
        candidates.append((cx0, bottom - dy))
        candidates.append((left + dx, cy0))
        candidates.append((right - dx, cy0))
        candidates.append((left + dx, top + dy))
    elif r_lower == "list_item":
        dx = max(6, min(24, w // 4))
        dy = max(4, min(14, h // 4))
        candidates.append((left + dx, top + dy))
        candidates.append((left + dx, cy0))
        candidates.append((cx0, top + dy))
        candidates.append((cx0, cy0))
        candidates.append((left + dx, bottom - dy))
        candidates.append((right - dx, cy0))
    elif r_lower in ("tool_bar", "status_bar", "tab", "group"):
        dx = max(6, min(20, w // 4))
        dy = max(4, min(12, h // 4))
        candidates.append((left + dx, cy0))
        candidates.append((left + dx, top + dy))
        candidates.append((cx0, cy0))
        candidates.append((cx0, top + dy))
        candidates.append((right - dx, cy0))
        candidates.append((cx0, bottom - dy))
    else:
        dx = max(4, min(14, w // 4))
        dy = max(4, min(14, h // 4))
        candidates.append((cx0, cy0))
        candidates.append((left + dx, top + dy))
        candidates.append((cx0, top + dy))
        candidates.append((left + dx, cy0))
        candidates.append((right - dx, cy0))
        candidates.append((cx0, bottom - dy))

    unique_candidates: list[tuple[int, int]] = []
    seen = set()
    for px, py in candidates:
        if left <= px <= right and top <= py <= bottom and (px, py) not in seen:
            seen.add((px, py))
            unique_candidates.append((px, py))
            if len(unique_candidates) >= 6:
                break

    return unique_candidates


def _verify_candidate_point(
    elem: dict[str, Any],
    candidate_points: list[tuple[int, int]],
    uia_instance: Any,
    walker: Any,
) -> tuple[dict[str, int], bool, str]:
    orig_center = elem.get("center", {})
    cx0 = orig_center.get("x", 0)
    cy0 = orig_center.get("y", 0)

    target_name = (elem.get("name") or "").strip().lower()
    target_role = (elem.get("role") or "").strip().lower()
    if not target_name or not uia_instance:
        return {"x": cx0, "y": cy0}, False, "bounds_center"

    import ctypes
    from ctypes import wintypes

    for px, py in candidate_points:
        try:
            pt = wintypes.POINT(px, py)
            hit = uia_instance.ElementFromPoint(pt)
            if not hit:
                continue

            hit_name = (getattr(hit, "CurrentName", None) or "").strip().lower()
            hit_role_id = getattr(hit, "CurrentControlType", 0)
            hit_role = UIA_CONTROL_TYPES.get(hit_role_id, "").lower()

            # 1. Direct name match
            if hit_name:
                if hit_name == target_name:
                    return {"x": px, "y": py}, True, "verified_click_point"
                if len(target_name) >= 3 and target_name in hit_name:
                    return {"x": px, "y": py}, True, "verified_click_point"
                if len(hit_name) >= 3 and hit_name in target_name:
                    return {"x": px, "y": py}, True, "verified_click_point"

            # 2. Caption button match
            if target_role == "button" and hit_role == "button" and (not hit_name or hit_name == target_name):
                return {"x": px, "y": py}, True, "verified_click_point"

            # 3. Ancestor chain match (up to 3 levels)
            if walker:
                curr = walker.GetParentElement(hit)
                levels = 0
                while curr and levels < 3:
                    p_name = (getattr(curr, "CurrentName", None) or "").strip().lower()
                    if p_name:
                        if p_name == target_name:
                            return {"x": px, "y": py}, True, "verified_click_point"
                        if len(target_name) >= 3 and target_name in p_name:
                            return {"x": px, "y": py}, True, "verified_click_point"
                        if len(p_name) >= 3 and p_name in target_name:
                            return {"x": px, "y": py}, True, "verified_click_point"
                    curr = walker.GetParentElement(curr)
                    levels += 1
        except Exception:
            continue

    return {"x": cx0, "y": cy0}, False, "bounds_center"


def _scan_uia_tier(scope_hwnd: int, max_elements: int = DEFAULT_MAX_ELEMENTS) -> list[dict[str, Any]]:
    """
    Tier 1: Native Windows UI Automation (IUIAutomation) Scan.
    Uses comtypes to bind to UIAutomationCore.dll natively.
    Works for Win32, UWP, WPF, Chromium, and native controls.
    """
    elements: list[dict[str, Any]] = []

    def _uia_worker(hwnd_target: int, limit: int, out_list: list[dict[str, Any]]) -> None:
        try:
            import comtypes
            import comtypes.client
            comtypes.CoInitialize()
            try:
                comtypes.client.GetModule("UIAutomationCore.dll")
                from comtypes.gen.UIAutomationClient import (
                    CUIAutomation,
                    IUIAutomation,
                    TreeScope_Children,
                    TreeScope_Descendants,
                )
                uia = comtypes.client.CreateObject(CUIAutomation, interface=IUIAutomation)
                cond = uia.CreateTrueCondition()

                targets = []
                if hwnd_target:
                    el = uia.ElementFromHandle(hwnd_target)
                    if el:
                        targets.append(el)
                else:
                    root = uia.GetRootElement()
                    if root:
                        top_windows = root.FindAll(TreeScope_Children, cond)
                        for idx in range(top_windows.Length):
                            targets.append(top_windows.GetElement(idx))

                    # If current desktop has 0 top windows, try default desktop
                    if not targets and sys.platform == "win32":
                        try:
                            u32 = ctypes.windll.user32
                            h_desk = u32.OpenDesktopW("default", 0, False, 0x01FF)
                            if h_desk:
                                u32.SetThreadDesktop(h_desk)
                                root = uia.GetRootElement()
                                if root:
                                    top_windows = root.FindAll(TreeScope_Children, cond)
                                    for idx in range(top_windows.Length):
                                        targets.append(top_windows.GetElement(idx))
                        except Exception:
                            pass

                for t in targets:
                    try:
                        t_name = t.CurrentName or ""
                        t_rc = t.CurrentBoundingRectangle
                        t_hwnd = t.CurrentNativeWindowHandle or hwnd_target
                        if t_name and t_rc.right > t_rc.left and t_rc.bottom > t_rc.top:
                            cx = (t_rc.left + t_rc.right) // 2
                            cy = (t_rc.top + t_rc.bottom) // 2
                            role_str = UIA_CONTROL_TYPES.get(t.CurrentControlType, "window")
                            out_list.append({
                                "name": t_name.strip(),
                                "role": role_str,
                                "element_type": role_str,
                                "bounds": {"left": t_rc.left, "top": t_rc.top, "right": t_rc.right, "bottom": t_rc.bottom},
                                "center": {"x": cx, "y": cy},
                                "bounds_center": {"x": cx, "y": cy},
                                "click_verified": False,
                                "center_source": "bounds_center",
                                "source": "uia",
                                "confidence": 1.0,
                                "hwnd": t_hwnd,
                            })

                        desc = t.FindAll(TreeScope_Descendants, cond)
                        for j in range(desc.Length):
                            if len(out_list) >= limit:
                                break
                            d = desc.GetElement(j)
                            d_name = d.CurrentName or ""
                            d_rc = d.CurrentBoundingRectangle
                            if not d_name or d_rc.right <= d_rc.left or d_rc.bottom <= d_rc.top:
                                continue
                            if d.CurrentIsOffscreen:
                                continue
                            dcx = (d_rc.left + d_rc.right) // 2
                            dcy = (d_rc.top + d_rc.bottom) // 2
                            d_role = UIA_CONTROL_TYPES.get(d.CurrentControlType, "control")
                            out_list.append({
                                "name": d_name.strip(),
                                "role": d_role,
                                "element_type": d_role,
                                "bounds": {"left": d_rc.left, "top": d_rc.top, "right": d_rc.right, "bottom": d_rc.bottom},
                                "center": {"x": dcx, "y": dcy},
                                "bounds_center": {"x": dcx, "y": dcy},
                                "click_verified": False,
                                "center_source": "bounds_center",
                                "source": "uia",
                                "confidence": 0.95,
                                "hwnd": d.CurrentNativeWindowHandle or t_hwnd,
                            })
                    except Exception:
                        continue

                # P2: Verified Click Points within budget
                try:
                    walker = uia.ControlViewWalker
                    verifications_done = 0
                    t_verify_start = time.perf_counter()

                    for el in out_list:
                        orig_c = el.get("center", {})
                        b = el.get("bounds", {})
                        el["bounds_center"] = {"x": orig_c.get("x", 0), "y": orig_c.get("y", 0)}

                        r_str = el.get("role", "").lower()
                        n_str = (el.get("name") or "").strip().lower()

                        needs_verification = (
                            r_str in _VERIFICATION_PRIORITY_ROLES
                            or n_str in _VERIFICATION_PRIORITY_NAMES
                            or any(btn in n_str for btn in _VERIFICATION_PRIORITY_NAMES)
                        )

                        if not needs_verification:
                            el["click_verified"] = False
                            el["center_source"] = "bounds_center"
                            continue

                        elapsed_ms = (time.perf_counter() - t_verify_start) * 1000.0
                        if verifications_done >= MAX_VERIFICATIONS_PER_OBSERVE or elapsed_ms >= MAX_VERIFICATION_TIME_MS:
                            el["click_verified"] = False
                            el["center_source"] = "bounds_center"
                            continue

                        cands = _generate_candidate_click_points(b, r_str, n_str)
                        if not cands:
                            el["click_verified"] = False
                            el["center_source"] = "bounds_center"
                            continue

                        verifications_done += 1
                        best_center, verified, src = _verify_candidate_point(el, cands, uia, walker)
                        el["center"] = best_center
                        el["click_verified"] = verified
                        el["center_source"] = src
                except Exception:
                    pass

            finally:
                d = None
                desc = None
                t = None
                targets = None
                cond = None
                top_windows = None
                root = None
                el = None
                uia = None
        except Exception:
            pass

    import threading
    t = threading.Thread(target=_uia_worker, args=(scope_hwnd, max_elements, elements))
    t.start()
    t.join(timeout=DEFAULT_UIA_TIMEOUT_SECONDS)

    if elements:
        return elements

    # Fallback to ui_inspector Win32/MSAA hierarchy if COM had an issue
    raw = inspect_windows_hierarchy(max_elements=max_elements, target_hwnd=scope_hwnd or None)
    for el in raw:
        src = getattr(el, "source", "uia")
        cx = el.center.get("x", 0) if isinstance(el.center, dict) else 0
        cy = el.center.get("y", 0) if isinstance(el.center, dict) else 0
        elements.append({
            "name": el.name,
            "role": el.element_type,
            "element_type": el.element_type,
            "bounds": el.bounds,
            "center": el.center,
            "bounds_center": {"x": cx, "y": cy},
            "click_verified": False,
            "center_source": "bounds_center",
            "source": src if src != "heuristic" else "uia",
            "confidence": el.confidence,
            "hwnd": el.hwnd,
        })
    return elements


def _scan_win32_tier(scope_hwnd: int) -> list[dict[str, Any]]:
    """
    Tier 2: Native Win32 Scan.
    Includes top-level window menus, controls, and dialog components.
    """
    elements: list[dict[str, Any]] = []
    if scope_hwnd:
        menu_items = _extract_menu_bar_elements(scope_hwnd)
        elements.extend(menu_items)
    return elements


class OcrTierResult(tuple):
    """Result tuple (elements, status) carrying capture method, error, and upscale policy telemetry."""
    capture_method: str = "imagegrab"
    ocr_error: str = ""
    ocr_upscale: str = "always_2x"

    def __new__(cls, elements: list[dict[str, Any]], status: str, capture_method: str = "imagegrab", ocr_error: str = "", ocr_upscale: str = "always_2x"):
        obj = super().__new__(cls, (elements, status))
        obj.capture_method = capture_method
        obj.ocr_error = ocr_error
        obj.ocr_upscale = ocr_upscale
        return obj


def _capture_window_surface(hwnd: int) -> tuple[Any, str]:
    """Captures target window's own pixels using PrintWindow (PW_RENDERFULLCONTENT), falling back to ImageGrab."""
    if not hwnd or sys.platform != "win32" or not ctypes or not wintypes:
        return None, "none"
    u32 = ctypes.windll.user32
    g32 = ctypes.windll.gdi32
    if not u32.IsWindow(hwnd):
        return None, "none"

    rc = wintypes.RECT()
    u32.GetWindowRect(hwnd, ctypes.byref(rc))
    w = max(1, rc.right - rc.left)
    h = max(1, rc.bottom - rc.top)

    img = None
    try:
        from PIL import Image
        hdc_win = u32.GetWindowDC(hwnd)
        hdc_mem = g32.CreateCompatibleDC(hdc_win)
        hbmp = g32.CreateCompatibleBitmap(hdc_win, w, h)
        old = g32.SelectObject(hdc_mem, hbmp)
        # PW_RENDERFULLCONTENT = 2
        res = u32.PrintWindow(hwnd, hdc_mem, 2)
        if res:
            class BIH(ctypes.Structure):
                _fields_ = [
                    ('biSize', wintypes.DWORD), ('biWidth', wintypes.LONG), ('biHeight', wintypes.LONG),
                    ('biPlanes', wintypes.WORD), ('biBitCount', wintypes.WORD), ('biCompression', wintypes.DWORD),
                    ('biSizeImage', wintypes.DWORD), ('biXPelsPerMeter', wintypes.LONG), ('biYPelsPerMeter', wintypes.LONG),
                    ('biClrUsed', wintypes.DWORD), ('biClrImportant', wintypes.DWORD)
                ]
            bih = BIH()
            bih.biSize = ctypes.sizeof(BIH)
            bih.biWidth = w
            bih.biHeight = -h
            bih.biPlanes = 1
            bih.biBitCount = 32
            buf = ctypes.create_string_buffer(w * h * 4)
            g32.GetDIBits(hdc_mem, hbmp, 0, h, buf, ctypes.byref(bih), 0)
            img = Image.frombuffer('RGBA', (w, h), buf, 'raw', 'BGRA', 0, 1).convert('RGB')
        g32.SelectObject(hdc_mem, old)
        g32.DeleteObject(hbmp)
        g32.DeleteDC(hdc_mem)
        u32.ReleaseDC(hwnd, hdc_win)

        if img is not None and any(mx > 0 for mn, mx in img.getextrema()):
            return img, "printwindow"
    except Exception:
        pass

    # Fallback to ImageGrab with window bbox
    try:
        from PIL import ImageGrab
        fallback_bbox = (rc.left, rc.top, rc.right, rc.bottom)
        img = ImageGrab.grab(bbox=fallback_bbox)
        if img:
            return img, "imagegrab"
    except Exception:
        pass

    return None, "none"


def _merge_ocr_elements(existing_elements: list[dict[str, Any]], ocr_elements: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """
    Merges OCR words into existing element list.
    Drops an OCR word ONLY if an existing element with the same name contains the OCR word's center.
    """
    merged = list(existing_elements)
    for oe in ocr_elements:
        oe_name = str(oe.get("name", "")).strip().lower()
        if not oe_name:
            continue
        ocx = oe.get("center", {}).get("x", 0)
        ocy = oe.get("center", {}).get("y", 0)

        is_covered = False
        for el in existing_elements:
            if str(el.get("name", "")).strip().lower() == oe_name:
                b = el.get("bounds", {})
                left = b.get("left", 0)
                top = b.get("top", 0)
                right = b.get("right", 0)
                bottom = b.get("bottom", 0)
                if left <= ocx <= right and top <= ocy <= bottom:
                    is_covered = True
                    break
        if not is_covered:
            merged.append(oe)
    return merged


def _scan_ocr_tier(scope_hwnd: int, region: Optional[dict[str, int]] = None) -> OcrTierResult:
    """
    Tier 3: Region-limited OCR Scan.
    Only executed on explicit request.
    Uses native Windows.Media.Ocr backend via tools.vision.ocr_backend.
    """
    try:
        from tools.vision.ocr_backend import pick_backend, recognize
    except ImportError as e:
        return OcrTierResult([], "unavailable", capture_method="none", ocr_error=str(e))

    backend = pick_backend()
    if not backend:
        return OcrTierResult([], "unavailable", capture_method="none", ocr_error="No OCR backend available")

    img = None
    capture_method = "imagegrab"
    offset_x = 0
    offset_y = 0

    try:
        if region:
            from PIL import ImageGrab
            bbox = (region["left"], region["top"], region["right"], region["bottom"])
            img = ImageGrab.grab(bbox=bbox)
            capture_method = "imagegrab"
            offset_x = bbox[0]
            offset_y = bbox[1]
        elif scope_hwnd and sys.platform == "win32":
            img, capture_method = _capture_window_surface(scope_hwnd)
            rc = wintypes.RECT()
            ctypes.windll.user32.GetWindowRect(scope_hwnd, ctypes.byref(rc))
            offset_x = rc.left
            offset_y = rc.top
        else:
            from PIL import ImageGrab
            img = ImageGrab.grab()
            capture_method = "imagegrab"
            offset_x = 0
            offset_y = 0

        if img is None:
            return OcrTierResult([], "unavailable", capture_method=capture_method, ocr_error="Screen grab returned None", ocr_upscale="always_2x")

        # Policy P1: Always 2x upscale with LANCZOS
        from PIL import Image
        w, h = img.size
        upscaled_img = img.resize((w * 2, h * 2), Image.Resampling.LANCZOS)
        elements = recognize(
            upscaled_img,
            scope_hwnd=scope_hwnd,
            offset_x=offset_x,
            offset_y=offset_y,
            scale=2.0,
            backend=backend,
        )
        del upscaled_img

        for el in elements:
            el.pop("_raw_height", None)
            if el.get("source") == "ocr" and el.get("confidence") is None:
                el["confidence_known"] = False

        return OcrTierResult(elements, "available", capture_method=capture_method, ocr_error="", ocr_upscale="always_2x")
    except Exception as exc:
        return OcrTierResult([], "unavailable", capture_method=capture_method, ocr_error=str(exc), ocr_upscale="always_2x")
    finally:
        if img is not None:
            del img
        gc.collect()


def classify_dialog_buttons(dialog_info: dict[str, Any] | list[str]) -> dict[str, Any]:
    """
    Classifies a dialog's buttons to enforce safety blocking policies.
    Returns whether the dialog contains safety-critical action buttons.
    """
    buttons: list[str] = []
    if isinstance(dialog_info, dict):
        buttons = dialog_info.get("buttons", [])
    elif isinstance(dialog_info, (list, tuple)):
        buttons = list(dialog_info)

    clean_buttons = [b.lower().replace("&", "").strip() for b in buttons]
    has_critical = any(b in BLOCKED_DIALOG_BUTTONS for b in clean_buttons)
    return {
        "buttons": buttons,
        "clean_buttons": clean_buttons,
        "is_safety_critical": has_critical,
        "critical_buttons": [b for b in clean_buttons if b in BLOCKED_DIALOG_BUTTONS],
    }


def check_dialog_blocking_policy(
    target_action: str = "",
    allow_dialog_choice: bool = False,
    owner_pid: Optional[int] = None,
) -> dict[str, Any]:
    """
    Dialog policy: GOKU never presses Save / Don't Save / Replace / Delete / Yes automatically.
    If a blocking dialog is detected, returns blocked status and requires explicit user consent.
    """
    from executor.truth_oracle import check_dialog

    obs = check_dialog(owner_pid=owner_pid)
    if obs.status == "VERIFIED" and obs.evidence.get("dialogs"):
        dialogs = obs.evidence["dialogs"]
        for dlg in dialogs:
            classification = classify_dialog_buttons(dlg)
            title = dlg.get("title", "Dialog")
            btns_str = ", ".join(dlg.get("buttons", []))
            
            # If target action matches one of the critical buttons without explicit override
            clean_target = target_action.lower().replace("&", "").strip()
            if clean_target in BLOCKED_DIALOG_BUTTONS and not allow_dialog_choice:
                return {
                    "blocked": True,
                    "reason": f"blocked by dialog '{title}' (buttons: {btns_str})",
                    "dialog": dlg,
                    "classification": classification,
                }
            
            # If any safety critical dialog is in the foreground
            if classification["is_safety_critical"] and not allow_dialog_choice:
                return {
                    "blocked": True,
                    "reason": f"blocked by dialog '{title}' (buttons: {btns_str})",
                    "dialog": dlg,
                    "classification": classification,
                }
    return {"blocked": False, "reason": ""}


@tool(
    name="observe",
    description="Single authoritative screen observation API. Inspects visible UI elements and scene telemetry across UIA, Win32, and optional OCR tiers.",
    parameters={
        "type": "object",
        "properties": {
            "scope": {
                "description": "Inspection scope: 'foreground' (focused window), 'desktop' (entire desktop), or integer HWND.",
                "default": "foreground",
            },
            "include_ocr": {
                "type": "boolean",
                "description": "Whether to run optional region-limited OCR scan (default False).",
                "default": False,
            },
            "max_elements": {
                "type": "integer",
                "description": "Maximum number of UI elements to return (default 100).",
                "default": 100,
            },
            "force_refresh": {
                "type": "boolean",
                "description": "Bypass 1-second cache and force live hardware scan.",
                "default": False,
            },
        },
    },
    category="vision",
    risk_level="read_only",
)
def observe(
    scope: str | int = "foreground",
    include_ocr: bool = False,
    max_elements: int = DEFAULT_MAX_ELEMENTS,
    force_refresh: bool = False,
) -> dict[str, Any]:
    """
    ONE Eye API: Returns unified elements inventory and scene telemetry.
    Order: UIA -> Win32 -> OCR (lazy, region-limited, only on request).
    Caches results per window for 1.0 second.
    """
    _ensure_desktop_access()

    # Low-RAM mode inspection & throttling (Prompt P7 Item 4)
    from tools.system_sentry import is_low_ram_mode
    low_ram_active = is_low_ram_mode()
    if low_ram_active:
        max_elements = min(max_elements, 25)
        include_ocr = False

    # 1. Resolve scope HWND
    fg_hwnd, fg_title = _get_active_foreground_window()
    target_hwnd = 0
    if scope == "foreground":
        target_hwnd = fg_hwnd
    elif scope == "desktop":
        target_hwnd = 0
    elif isinstance(scope, int):
        target_hwnd = scope
    elif str(scope).isdigit():
        target_hwnd = int(scope)
    else:
        target_hwnd = fg_hwnd

    # 2. Check 1-second TTL cache
    cache_key = (target_hwnd, bool(include_ocr))
    now = time.time()
    if not force_refresh and cache_key in _OBSERVE_CACHE:
        cached_time, cached_data = _OBSERVE_CACHE[cache_key]
        if now - cached_time < CACHE_TTL_SECONDS:
            result = dict(cached_data)
            result["cached"] = True
            return result

    # 3. Scene context gathering
    screen_size = get_screen_size()
    dpi_info = _get_system_dpi_info(target_hwnd)

    from executor.truth_oracle import check_dialog
    dialog_obs = check_dialog()
    active_dialogs = dialog_obs.evidence.get("dialogs", []) if dialog_obs.status == "VERIFIED" else []

    scene = {
        "foreground_title": fg_title or "Desktop",
        "active_window": fg_title or "Desktop",
        "target_hwnd": target_hwnd,
        "dialogs": active_dialogs,
        "screen_size": screen_size,
        "dpi": dpi_info,
    }

    # 4. Multi-tier scan execution
    # Tier 1: UIA
    elements = _scan_uia_tier(target_hwnd, max_elements=max_elements)

    # Tier 2: Win32 (Menu bar items, buttons)
    win32_elements = _scan_win32_tier(target_hwnd)
    # Deduplicate menu items if already discovered, upgrading generic roles
    seen_names = {e["name"].lower() for e in elements}
    for we in win32_elements:
        if we["name"].lower() not in seen_names:
            elements.append(we)
            seen_names.add(we["name"].lower())
        else:
            for el in elements:
                if el["name"].lower() == we["name"].lower():
                    el["role"] = we.get("role", el.get("role"))
                    el["element_type"] = we.get("element_type", el.get("element_type"))
                    el["source"] = "win32"

    # Tier 3: OCR (only on request)
    ocr_status = "not_requested"
    capture_method = None
    ocr_error = None
    ocr_upscale = None
    if include_ocr:
        res = _scan_ocr_tier(target_hwnd)
        ocr_elements, raw_ocr_status = res[0], res[1]
        capture_method = getattr(res, "capture_method", "imagegrab" if not target_hwnd else "printwindow")
        ocr_error = getattr(res, "ocr_error", "") or None
        ocr_upscale = getattr(res, "ocr_upscale", "always_2x")
        ocr_status = "available" if raw_ocr_status == "available" else "OCR unavailable"
        elements = _merge_ocr_elements(elements, ocr_elements)
    scene["ocr_status"] = ocr_status
    if capture_method:
        scene["capture_method"] = capture_method
    if ocr_error:
        scene["ocr_error"] = ocr_error
    if ocr_upscale:
        scene["ocr_upscale"] = ocr_upscale

    # Explicit "cannot_see" field: records all unreadable, occluded, or unindexed regions
    cannot_see: list[str] = []
    if ocr_status == "OCR unavailable":
        cannot_see.append("Raster/image text unreadable: OCR unavailable")
    elif not include_ocr:
        cannot_see.append("Raster/image pixels unindexed: OCR not requested")

    if sys.platform == "win32":
        try:
            u32 = ctypes.windll.user32
            def enum_hidden_proc(hw: int, _: Any) -> bool:
                if u32.IsWindow(hw) and u32.IsIconic(hw):
                    t_len = u32.GetWindowTextLengthW(hw) + 1
                    if t_len > 1:
                        t_buf = ctypes.create_unicode_buffer(t_len)
                        u32.GetWindowTextW(hw, t_buf, t_len)
                        win_title = t_buf.value.strip()
                        if win_title:
                            cannot_see.append(f"Minimized window: '{win_title}' (HWND {hw})")
                return True
            WNDENUMPROC = ctypes.WINFUNCTYPE(ctypes.c_bool, wintypes.HWND, wintypes.LPARAM)
            u32.EnumWindows(WNDENUMPROC(enum_hidden_proc), 0)
        except Exception:
            pass

    scene["cannot_see"] = cannot_see

    # Truncate to max_elements
    elements = elements[:max_elements]

    payload = {
        "success": True,
        "status": "completed",
        "count": len(elements),
        "elements": elements,
        "scene": scene,
        "cannot_see": cannot_see,
        "cached": False,
        "low_ram_mode": low_ram_active,
        "throttled": low_ram_active,
        "timestamp": now,
    }

    # Bound cache size to prevent memory leaks (Prompt P7 Item 5)
    if len(_OBSERVE_CACHE) >= 20:
        oldest_k = min(_OBSERVE_CACHE.keys(), key=lambda k: _OBSERVE_CACHE[k][0])
        del _OBSERVE_CACHE[oldest_k]

    # Save to cache
    _OBSERVE_CACHE[cache_key] = (now, payload)
    return payload


def find_screen_element(
    query: str,
    element_type: str | None = None,
    scope: str | int = "foreground",
    rank: int = 1,
    **kwargs: Any,
) -> dict[str, Any]:
    """
    Locates a target UI element on screen using the ONE Eye API.
    Zero invented coordinates: returns honest 'unknown' with reason if not found.
    """
    el_type = element_type or kwargs.get("target_type")
    if not query:
        return {"success": False, "status": "failed", "found": False, "message": "Query string cannot be empty."}

    # 1. Observe active screen state
    force_ref = bool(kwargs.get("force_refresh", False))
    obs = observe(scope=scope, max_elements=100, force_refresh=force_ref)
    raw_elements = obs.get("elements", [])
    if not raw_elements:
        return {
            "success": False,
            "status": "unknown",
            "found": False,
            "query": query,
            "message": f"Could not detect any active UI elements within scope '{scope}'.",
            "reason": "zero_elements_detected",
        }

    # Convert dict elements into UIElement objects for matching
    ui_objects = []
    for e in raw_elements:
        if not e.get("name"):
            continue
        src = e.get("source", "uia")
        conf_val = e.get("confidence")
        if src == "ocr" and conf_val is None:
            conf = OCR_NO_CONFIDENCE
            conf_known = False
        else:
            conf = float(conf_val) if conf_val is not None else 1.0
            conf_known = e.get("confidence_known", True)
        ui_objects.append(
            UIElement(
                name=e["name"],
                element_type=e.get("role") or e.get("element_type", "element"),
                bounds=e.get("bounds", {}),
                center=e.get("center", {}),
                confidence=conf,
                source=src,
                hwnd=e.get("hwnd", 0),
                confidence_known=conf_known,
            )
        )

    best_match, is_ambiguous, candidates = match_ui_element(
        query, ui_objects, requested_type=el_type, rank=rank
    )

    if not best_match:
        return {
            "success": False,
            "status": "unknown",
            "found": False,
            "query": query,
            "message": f"Element '{query}' unknown: not found within scope '{scope}'.",
            "reason": "element_not_found_on_screen",
        }

    b = best_match.bounds
    bbox_list = [b.get("left", 0), b.get("top", 0), b.get("right", 0), b.get("bottom", 0)]

    if is_ambiguous:
        cand_names = [f"'{c.name}' ({c.element_type})" for c in candidates[:3]]
        return {
            "success": True,
            "status": "ambiguous",
            "found": True,
            "is_ambiguous": True,
            "target": best_match.name,
            "candidates_count": len(candidates),
            "best_match": best_match.to_dict(),
            "center": best_match.center,
            "bounds": best_match.bounds,
            "bbox": bbox_list,
            "confidence": best_match.confidence,
            "confidence_known": best_match.confidence_known,
            "source": best_match.source,
            "window": best_match.hwnd,
            "message": f"Ambiguous matches for '{query}'. Multiple elements found: {', '.join(cand_names)}.",
        }

    return {
        "success": True,
        "status": "located",
        "found": True,
        "is_ambiguous": False,
        "target": best_match.name,
        "name": best_match.name,
        "type": best_match.element_type,
        "center": best_match.center,
        "bounds": best_match.bounds,
        "bbox": bbox_list,
        "confidence": best_match.confidence,
        "confidence_known": best_match.confidence_known,
        "source": best_match.source,
        "window": best_match.hwnd,
        "message": f"Located '{best_match.name}' at center ({best_match.center['x']}, {best_match.center['y']}).",
    }


def inspect_current_screen(filter_type: str | None = None) -> dict[str, Any]:
    """
    Backwards-compatible wrapper around ONE Eye observe().
    Captures screenshot and analyzes UI elements.
    """
    shot_result = take_screenshot()
    obs = observe(scope="desktop", max_elements=80)
    raw_elements = obs.get("elements", [])

    filtered = raw_elements
    if filter_type:
        ft = filter_type.lower().strip()
        filtered = [e for e in raw_elements if e.get("role") == ft or ft in e.get("name", "").lower()]

    screen_info = obs.get("scene", {}).get("screen_size", {"width": 1920, "height": 1080})
    summary_names = [e["name"] for e in filtered if e.get("name")][:8]
    summary_str = f"Found {len(filtered)} UI element(s) on screen: {', '.join(summary_names)}."

    return {
        "success": True,
        "status": "completed",
        "elements_count": len(filtered),
        "elements": filtered,
        "screenshot_path": shot_result.get("path"),
        "screen_size": screen_info,
        "scene": obs.get("scene", {}),
        "message": summary_str,
    }


# Authoritative export of visual change detection
from tools.vision.state_observer import wait_for_screen_change
