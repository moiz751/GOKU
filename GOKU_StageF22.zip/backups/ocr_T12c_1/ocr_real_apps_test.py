"""
tests/ocr_real_apps_test.py
OCR on Real Applications Benchmark Suite (Stage 1 Task 1.2b).

Measures OCR on real Windows application windows (Notepad, Chrome, Edge, Calculator, Settings)
using Window-own capture (_capture_window_surface), evaluates capture blankness,
region-bounded precision, category recall (Canvas, Image, DOM), occluder leaks,
and latency overhead against rules G1 through G6.
"""
from __future__ import annotations

import argparse
import ctypes
from ctypes import wintypes
import gc
import hashlib
import json
import os
from pathlib import Path
import platform
import statistics
import subprocess
import sys
import tempfile
import time
from typing import Any, Callable

from PIL import Image, ImageDraw, ImageFont, ImageStat

# Project root setup
PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from tests.eye_ab_test import (
    find_browser_binary,
    find_matching_visible_windows,
    find_new_app_window,
    get_window_info,
    init_uia_oracle,
    matches_app_identity,
    snapshot_visible_top_level_hwnds,
    walk_uia_tree,
)
from tests.eye_cold_start_probe import (
    classify_preexisting_window,
    find_all_identity_windows,
    get_window_extended_info,
)
from tests.ocr_ab_test import (
    compute_engine_sha256,
    compute_file_sha256,
    get_display_scale_pct,
    get_process_ram_mb,
    normalize_word,
)
from tools.vision.screen_engine import observe, _capture_window_surface


# ==============================================================================
# 1. GROUND TRUTH VOCABULARY & DETERMINISTIC ASSET GENERATION
# ==============================================================================

NOTEPAD_C1_WORDS = [
    "The", "quick", "brown", "fox", "jumps", "over",
    "the", "lazy", "sleeping", "dog", "near", "river",
    "under", "the", "bright", "sunny", "afternoon", "sky",
]

CANVAS_WORDS = [
    "Canvas", "Matrix", "Vector", "Quantum", "Horizon",
    "Orbit", "Speed", "Frequency", "Pulse", "Telemetry",
]

IMAGE_C1_WORDS = NOTEPAD_C1_WORDS

IMAGE_C6_WORDS = [
    "Save", "Cancel", "Search", "Settings", "Open",
    "Delete", "Submit", "Refresh", "Help", "Close",
]

IMAGE_WORDS = IMAGE_C1_WORDS + IMAGE_C6_WORDS

DOM_WORDS = [
    "DOM", "Heading", "Standard", "Browser", "Text",
    "Modern", "browser", "rendering", "architecture", "pipeline", "verification",
]

ALL_PAGE_TRUTH_WORDS = CANVAS_WORDS + IMAGE_WORDS + DOM_WORDS


def ensure_real_page_assets(real_dir: Path | None = None) -> tuple[Path, Path, str, dict[str, list[str]]]:
    """
    Ensures reports/ocr/real/page.html and fixture.png exist deterministically.
    Returns (html_path, fixture_path, fixture_sha256, truth_words_dict).
    """
    out_dir = real_dir or (PROJECT_ROOT / "reports" / "ocr" / "real")
    out_dir.mkdir(parents=True, exist_ok=True)

    fixture_path = out_dir / "fixture.png"
    html_path = out_dir / "page.html"

    # 1. Render fixture.png if missing
    im = Image.new("RGB", (480, 240), (255, 255, 255))
    dr = ImageDraw.Draw(im)
    try:
        f1 = ImageFont.truetype("segoeui.ttf", 13)
        f2 = ImageFont.truetype("segoeui.ttf", 12)
    except Exception:
        f1 = ImageFont.load_default()
        f2 = ImageFont.load_default()

    lines_c1 = [
        "The quick brown fox jumps over",
        "the lazy sleeping dog near river",
        "under the bright sunny afternoon sky",
    ]
    for i, l in enumerate(lines_c1):
        dr.text((20, 15 + i * 24), l, fill=(0, 0, 0), font=f1)

    labels = ["Save", "Cancel", "Search", "Settings", "Open", "Delete", "Submit", "Refresh", "Help", "Close"]
    start_x, start_y = 15, 115
    btn_w, btn_h = 80, 30
    for i, lbl in enumerate(labels):
        bx = start_x + (i % 5) * (btn_w + 12)
        by = start_y + (i // 5) * (btn_h + 14)
        dr.rectangle([bx, by, bx + btn_w, by + btn_h], fill=(230, 230, 230), outline=(160, 160, 160))
        dr.text((bx + 12, by + 7), lbl, fill=(0, 0, 0), font=f2)

    im.save(fixture_path, format="PNG")

    # 2. Render page.html
    html_content = """<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>OCR REAL PAGE</title>
  <style>
    body {
      margin: 20px;
      font-family: "Segoe UI", Arial, sans-serif;
      background: #ffffff;
      color: #000000;
    }
    #dom-section {
      margin-bottom: 24px;
      padding: 10px;
      background: #fdfdfd;
      border: 1px solid #e0e0e0;
    }
    h1 {
      font-size: 20px;
      margin: 0 0 8px 0;
    }
    p {
      font-size: 15px;
      margin: 0;
    }
    #canvas-section {
      display: block;
      margin-bottom: 24px;
      border: 1px solid #cccccc;
    }
    #image-section {
      display: block;
      border: 1px solid #cccccc;
    }
  </style>
</head>
<body>
  <div id="dom-section">
    <h1>DOM Heading Standard Browser Text</h1>
    <p id="dom-text">Modern browser rendering architecture pipeline verification</p>
  </div>

  <canvas id="canvas-section" width="480" height="120"></canvas>

  <img id="image-section" src="fixture.png" width="480" height="240" alt="OCR Fixture Image" />

  <script>
    const c = document.getElementById('canvas-section');
    const ctx = c.getContext('2d');
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, 480, 120);
    ctx.font = '16px "Segoe UI", Arial, sans-serif';
    ctx.fillStyle = '#000000';
    ctx.fillText('Canvas Matrix Vector Quantum Horizon', 20, 45);
    ctx.fillText('Orbit Speed Frequency Pulse Telemetry', 20, 85);
  </script>
</body>
</html>
"""
    html_path.write_text(html_content, encoding="utf-8")

    # 3. Compute asset sha256
    hasher = hashlib.sha256()
    hasher.update(html_path.read_bytes())
    hasher.update(fixture_path.read_bytes())
    fixture_sha = hasher.hexdigest()

    truth_dict = {
        "canvas": CANVAS_WORDS,
        "image": IMAGE_WORDS,
        "dom": DOM_WORDS,
        "all_page": ALL_PAGE_TRUTH_WORDS,
        "notepad": NOTEPAD_C1_WORDS,
    }
    return html_path, fixture_path, fixture_sha, truth_dict


# ==============================================================================
# 2. HASHING & SYSTEM INTEGRITY
# ==============================================================================

def compute_real_kit_sha256(root: Path | None = None) -> str:
    """Computes combined SHA-256 of tests/ocr_real_apps_test.py."""
    r = root or PROJECT_ROOT
    f = r / "tests" / "ocr_real_apps_test.py"
    if not f.is_file():
        return ""
    return hashlib.sha256(f.read_bytes()).hexdigest()


def check_real_kit_integrity(root: Path | None = None) -> bool:
    """Verifies that kit matches reports/ocr/REAL_KIT_HASH.json."""
    r = root or PROJECT_ROOT
    kit_hash_path = r / "reports" / "ocr" / "REAL_KIT_HASH.json"
    if not kit_hash_path.is_file():
        print(f"FAILED: Real kit hash file not found: {kit_hash_path}")
        return False
    try:
        data = json.loads(kit_hash_path.read_text(encoding="utf-8"))
        expected = data.get("kit_sha256")
        actual = compute_real_kit_sha256(r)
        if actual != expected:
            print(f"FAILED: Real kit SHA mismatch!\n  Expected: {expected}\n  Actual:   {actual}")
            return False
        print("OK: Real kit integrity verified.")
        return True
    except Exception as e:
        print(f"FAILED to verify real kit integrity: {e}")
        return False


# ==============================================================================
# 3. METRIC & EVALUATION FUNCTIONS (Pure, Headless, Fully Unit-Testable)
# ==============================================================================

def compute_capture_blank(img: Any) -> bool:
    """
    Computes whether a captured window surface bitmap is blank.
    Returns True if:
    - img is None
    - grayscale std-dev < 2.0
    - OR >99.5% of pixels are identical
    """
    if img is None:
        return True
    try:
        gray = img.convert("L")
        stat = ImageStat.Stat(gray)
        stddev = stat.stddev[0]
        if stddev < 2.0:
            return True

        hist = gray.histogram()
        total_pixels = gray.width * gray.height
        if total_pixels == 0:
            return True
        max_identical = max(hist)
        if (max_identical / float(total_pixels)) > 0.995:
            return True

        return False
    except Exception:
        return True


def evaluate_honesty_blank(capture_blank: bool, ocr_status: str, ocr_count: int) -> bool:
    """
    If capture_blank is true, status must NOT be 'available' with an empty list.
    The engine must report unavailable/failed with a reason: otherwise it is a SILENT FALSE NEGATIVE.
    """
    if capture_blank:
        if ocr_status.lower() == "available" and ocr_count == 0:
            return False
    return True


def is_point_in_region(pt: dict[str, int | float], region: dict[str, int | float] | None) -> bool:
    """Checks if point {x, y} is inside bounding box {left, top, right, bottom}."""
    if not region:
        return True
    x = pt.get("x", 0)
    y = pt.get("y", 0)
    return (
        region.get("left", 0) <= x <= region.get("right", 0)
        and region.get("top", 0) <= y <= region.get("bottom", 0)
    )


def filter_elements_by_region(
    elements: list[dict[str, Any]],
    region: dict[str, int | float] | None,
) -> list[dict[str, Any]]:
    """Filters OCR elements to only those whose center lies inside the Region."""
    if not region:
        return list(elements)
    filtered = []
    for el in elements:
        c = el.get("center") or el.get("bounds_center")
        if not c and "bounds" in el:
            b = el["bounds"]
            c = {"x": (b["left"] + b["right"]) // 2, "y": (b["top"] + b["bottom"]) // 2}
        elif not c:
            c = {"x": 0, "y": 0}
        if is_point_in_region(c, region):
            filtered.append(el)
    return filtered


def calculate_word_match(
    truth_words: list[str],
    candidate_tokens: list[str],
) -> dict[str, Any]:
    """
    Greedy matching between truth words and candidate tokens.
    Returns matched count, total truth, recall, matched words list, unmatched truth list.
    """
    norm_truth = [normalize_word(w) for w in truth_words if normalize_word(w)]
    available = list(candidate_tokens)

    matched: list[str] = []
    unmatched: list[str] = []

    for tw in norm_truth:
        if tw in available:
            matched.append(tw)
            available.remove(tw)
        else:
            unmatched.append(tw)

    total_truth = len(norm_truth)
    matched_count = len(matched)
    recall = (matched_count / float(total_truth)) if total_truth > 0 else 1.0

    return {
        "matched_count": matched_count,
        "truth_count": total_truth,
        "recall": round(recall, 4),
        "matched_words": matched,
        "unmatched_truth": unmatched,
    }


def calculate_precision_in_region(
    all_valid_truth_words: list[str],
    ocr_tokens_in_region: list[str],
) -> dict[str, Any]:
    """
    Calculates precision inside the Region against all valid ground truth words for that window.
    """
    valid_norms = {normalize_word(w) for w in all_valid_truth_words if normalize_word(w)}
    total_ocr = len(ocr_tokens_in_region)

    if total_ocr == 0:
        return {
            "ocr_count": 0,
            "matched_count": 0,
            "precision": 1.0 if not valid_norms else 0.0,
        }

    matched_count = sum(1 for tok in ocr_tokens_in_region if tok in valid_norms)
    precision = matched_count / float(total_ocr)
    return {
        "ocr_count": total_ocr,
        "matched_count": matched_count,
        "precision": round(precision, 4),
    }


# ==============================================================================
# 4. RULE EVALUATION ENGINE (G1 to G6)
# ==============================================================================

def evaluate_real_apps_rules(case_results: dict[str, Any]) -> tuple[str, list[dict[str, Any]]]:
    """
    Evaluates rules G1 through G6 over case results.
    Returns: ("ACCEPT" | "REJECT", rules_list).
    """
    rules: list[dict[str, Any]] = []

    # G1: NP, CH, ED: capture_blank == false, or honesty_blank holds when it is true
    # (and then the case is reported as CAPTURE FAILURE, not a pass)
    g1_errors: list[str] = []
    for app_key in ["NP", "CH", "ED"]:
        if app_key not in case_results:
            continue
        c = case_results[app_key]
        c_blank = c.get("capture_blank", False)
        h_blank = c.get("honesty_blank", True)
        if c_blank:
            if not h_blank:
                g1_errors.append(f"{app_key}: SILENT FALSE NEGATIVE (blank capture reported as available with empty elements)")
            else:
                g1_errors.append(f"{app_key}: CAPTURE FAILURE (capture surface is blank; honesty holds)")

    g1_pass = (len(g1_errors) == 0)
    rules.append({
        "rule": "G1",
        "description": "NP, CH, ED: capture_blank == false (or honesty holds on failure)",
        "passed": g1_pass,
        "details": "All gating captures non-blank and honest" if g1_pass else "; ".join(g1_errors),
    })

    # G2: recall >= 85% separately for NP, CH-canvas, CH-image, ED-canvas, ED-image
    # (DOM text reported, not gating)
    g2_checks: list[tuple[str, float]] = []
    if "NP" in case_results:
        g2_checks.append(("NP", case_results["NP"].get("recall", 0.0)))
    if "CH" in case_results:
        sub = case_results["CH"].get("subcases", {})
        g2_checks.append(("CH-canvas", sub.get("canvas", {}).get("recall", 0.0)))
        g2_checks.append(("CH-image", sub.get("image", {}).get("recall", 0.0)))
    if "ED" in case_results:
        sub = case_results["ED"].get("subcases", {})
        g2_checks.append(("ED-canvas", sub.get("canvas", {}).get("recall", 0.0)))
        g2_checks.append(("ED-image", sub.get("image", {}).get("recall", 0.0)))

    g2_failures = [f"{name} recall={rec*100.0:.1f}% < 85%" for name, rec in g2_checks if rec < 0.85]
    g2_pass = (len(g2_failures) == 0) and (len(g2_checks) >= 5)
    rules.append({
        "rule": "G2",
        "description": "recall >= 85% for NP, CH-canvas, CH-image, ED-canvas, ED-image",
        "passed": g2_pass,
        "details": (
            ", ".join(f"{name}={rec*100.0:.1f}%" for name, rec in g2_checks)
            if g2_pass
            else ("Failed: " + "; ".join(g2_failures) if g2_failures else f"Missing required cases ({len(g2_checks)}/5 evaluated)")
        ),
    })

    # G3: precision >= 90% inside Region for those cases
    g3_checks: list[tuple[str, float]] = []
    for app_key in ["NP", "CH", "ED"]:
        if app_key in case_results:
            prec = case_results[app_key].get("precision", 0.0)
            g3_checks.append((app_key, prec))

    g3_failures = [f"{name} prec={p*100.0:.1f}% < 90%" for name, p in g3_checks if p < 0.90]
    g3_pass = (len(g3_failures) == 0) and (len(g3_checks) >= 3)
    rules.append({
        "rule": "G3",
        "description": "precision >= 90% inside Region for NP, CH, ED",
        "passed": g3_pass,
        "details": (
            ", ".join(f"{name}={p*100.0:.1f}%" for name, p in g3_checks)
            if g3_pass
            else ("Failed: " + "; ".join(g3_failures) if g3_failures else "Missing required cases")
        ),
    })

    # G4: occluder_leaks == 0
    occ_case = case_results.get("OCC", {})
    occ_leaks = occ_case.get("occluder_leaks", 0)
    g4_pass = (occ_leaks == 0)
    rules.append({
        "rule": "G4",
        "description": "Notepad occlusion occluder_leaks == 0",
        "passed": g4_pass,
        "details": f"Occluder leaks = {occ_leaks} (required 0)",
    })

    # G5: ocr_added_latency <= 1500 ms, RAM delta <= 150 MB
    gating_keys = ["NP", "CH", "ED", "OCC"]
    lats = [case_results[k].get("ocr_added_latency_ms", 0.0) for k in gating_keys if k in case_results]
    rams = [case_results[k].get("ram_delta_mb", 0.0) for k in gating_keys if k in case_results]
    max_lat = max(lats, default=0.0)
    max_ram = max(rams, default=0.0)
    g5_pass = (max_lat <= 1500.0) and (max_ram <= 150.0)
    rules.append({
        "rule": "G5",
        "description": "ocr_added_latency <= 1500 ms, RAM delta <= 150 MB",
        "passed": g5_pass,
        "details": f"Max added latency = {max_lat:.1f} ms (gate <= 1500 ms), Max RAM delta = {max_ram:.1f} MB (gate <= 150 MB)",
    })

    # G6: uia_unchanged == true
    uia_fails = [k for k in gating_keys if k in case_results and not case_results[k].get("uia_unchanged", False)]
    g6_pass = (len(uia_fails) == 0)
    rules.append({
        "rule": "G6",
        "description": "uia_unchanged == true across all evaluated windows",
        "passed": g6_pass,
        "details": "All UIA trees unchanged by OCR" if g6_pass else f"UIA count modified in: {', '.join(uia_fails)}",
    })

    overall_accept = all(r["passed"] for r in rules)
    return ("ACCEPT" if overall_accept else "REJECT"), rules


# ==============================================================================
# 5. WINDOW CONTROLLERS & LIVE APP TEST RUNNERS
# ==============================================================================

def find_notepad_edit_control(hwnd: int) -> int:
    """Finds Edit control HWND inside Notepad window."""
    import win32gui
    edit_hwnd = 0

    def _cb(h: int, _: Any) -> bool:
        nonlocal edit_hwnd
        cls = win32gui.GetClassName(h).lower()
        if cls in ("edit", "richeditd2dpt", "notepadtextbox"):
            edit_hwnd = h
            return False
        return True

    try:
        win32gui.EnumChildWindows(hwnd, _cb, None)
    except Exception:
        pass
    return edit_hwnd


def find_render_widget_host(hwnd: int) -> int:
    """Finds Chrome_RenderWidgetHostHWND control HWND inside Chrome or Edge."""
    import win32gui
    render_hwnd = 0

    def _cb(h: int, _: Any) -> bool:
        nonlocal render_hwnd
        cls = win32gui.GetClassName(h)
        if "renderwidgethost" in cls.lower():
            render_hwnd = h
            return False
        return True

    try:
        win32gui.EnumChildWindows(hwnd, _cb, None)
    except Exception:
        pass
    return render_hwnd


def get_rect_dict(hwnd: int) -> dict[str, int]:
    """Retrieves bounding rect as dictionary."""
    import win32gui
    r = win32gui.GetWindowRect(hwnd)
    return {"left": r[0], "top": r[1], "right": r[2], "bottom": r[3]}


def run_case_notepad(repeats: int = 3) -> tuple[dict[str, Any], int]:
    """
    Runs Case NP: Notepad with C1 text set via WM_SETTEXT on its Edit control.
    Returns (result_dict, notepad_hwnd_for_occlusion).
    """
    import win32gui

    print("\n[*] Testing Case NP: Notepad...")
    snapshot = snapshot_visible_top_level_hwnds()

    proc = subprocess.Popen(["notepad.exe"])
    hwnd, _ = find_new_app_window("Notepad", snapshot, timeout_sec=6.0)
    if not hwnd:
        return {"status": "launch_failed", "error": "Could not locate opened Notepad window"}, 0

    edit_hwnd = find_notepad_edit_control(hwnd)
    if not edit_hwnd:
        edit_hwnd = hwnd  # Fallback to window itself

    # Set text via WM_SETTEXT (0x000C)
    text_content = "\r\n".join([
        "The quick brown fox jumps over",
        "the lazy sleeping dog near river",
        "under the bright sunny afternoon sky",
    ])
    win32gui.SendMessage(edit_hwnd, 0x000C, 0, text_content)
    time.sleep(0.3)

    region = get_rect_dict(edit_hwnd)

    # Measure baseline without OCR
    base_t0 = time.perf_counter()
    base_obs = observe(scope=hwnd, include_ocr=False, force_refresh=True)
    base_lat_ms = (time.perf_counter() - base_t0) * 1000.0
    base_uia_count = base_obs.get("count", 0)

    # Measure repeats (+1 discarded warm-up)
    ocr_latencies: list[float] = []
    base_latencies: list[float] = []
    ram_deltas: list[float] = []
    last_obs: dict[str, Any] = {}
    last_img: Any = None

    for call_idx in range(repeats + 1):
        t_b0 = time.perf_counter()
        _ = observe(scope=hwnd, include_ocr=False, force_refresh=True)
        b_dt = (time.perf_counter() - t_b0) * 1000.0

        r0 = get_process_ram_mb()
        t0 = time.perf_counter()
        obs = observe(scope=hwnd, include_ocr=True, force_refresh=True)
        dt_ms = (time.perf_counter() - t0) * 1000.0
        r1 = get_process_ram_mb()

        img, _ = _capture_window_surface(hwnd)

        if call_idx > 0:
            ocr_latencies.append(dt_ms)
            base_latencies.append(b_dt)
            ram_deltas.append(max(0.0, r1 - r0))
            last_obs = obs
            last_img = img

    med_ocr_lat = statistics.median(ocr_latencies) if ocr_latencies else 0.0
    med_base_lat = statistics.median(base_latencies) if base_latencies else base_lat_ms
    added_lat = max(0.0, med_ocr_lat - med_base_lat)
    med_ram = statistics.median(ram_deltas) if ram_deltas else 0.0

    c_blank = compute_capture_blank(last_img)
    all_ocr_elements = [e for e in last_obs.get("elements", []) if e.get("source") == "ocr"]
    ocr_in_region = filter_elements_by_region(all_ocr_elements, region)
    ocr_tokens = [normalize_word(e.get("name", "")) for e in ocr_in_region if normalize_word(e.get("name", ""))]

    match_res = calculate_word_match(NOTEPAD_C1_WORDS, ocr_tokens)
    prec_res = calculate_precision_in_region(NOTEPAD_C1_WORDS, ocr_tokens)

    # UIA unchanged check
    post_obs = observe(scope=hwnd, include_ocr=False, force_refresh=True)
    uia_unchanged = (post_obs.get("count", 0) == base_uia_count)

    h_blank = evaluate_honesty_blank(
        c_blank,
        last_obs.get("scene", {}).get("ocr_status", "unavailable"),
        len(all_ocr_elements),
    )

    result = {
        "case": "NP",
        "app": "Notepad",
        "status": last_obs.get("scene", {}).get("ocr_status", "available"),
        "capture_method": last_obs.get("scene", {}).get("capture_method", "none"),
        "capture_blank": c_blank,
        "honesty_blank": h_blank,
        "matched_count": match_res["matched_count"],
        "truth_count": match_res["truth_count"],
        "recall": match_res["recall"],
        "precision": prec_res["precision"],
        "ocr_added_latency_ms": round(added_lat, 2),
        "latency_ms": round(med_ocr_lat, 2),
        "baseline_latency_ms": round(med_base_lat, 2),
        "ram_delta_mb": round(med_ram, 2),
        "uia_unchanged": uia_unchanged,
        "region": region,
        "matched_words": match_res["matched_words"],
        "unmatched_truth": match_res["unmatched_truth"],
    }
    return result, hwnd


def run_case_occlusion(notepad_hwnd: int) -> dict[str, Any]:
    """
    Runs Case OCC: Notepad occlusion test.
    Opens a second Tk window 'OCCLUDER' with text OCCLUDERWORD covering ~50% of Notepad.
    """
    import tkinter as tk
    import win32gui

    print("\n[*] Testing Case OCC: Notepad Occlusion...")
    if not notepad_hwnd or not win32gui.IsWindow(notepad_hwnd):
        return {"status": "failed", "occluder_leaks": 0, "error": "Notepad hwnd invalid"}

    np_rect = get_rect_dict(notepad_hwnd)
    occ_w = (np_rect["right"] - np_rect["left"]) // 2
    occ_h = (np_rect["bottom"] - np_rect["top"]) // 2
    occ_x = np_rect["left"] + 20
    occ_y = np_rect["top"] + 20

    root = tk.Tk()
    root.title("OCCLUDER")
    root.geometry(f"{occ_w}x{occ_h}+{occ_x}+{occ_y}")
    root.configure(bg="#ffff00")
    lbl = tk.Label(root, text="OCCLUDERWORD", font=("Segoe UI", 22, "bold"), bg="#ffff00", fg="#ff0000")
    lbl.pack(expand=True, fill="both")
    root.update()
    time.sleep(0.4)

    t0 = time.perf_counter()
    obs = observe(scope=notepad_hwnd, include_ocr=True, force_refresh=True)
    dt_ms = (time.perf_counter() - t0) * 1000.0

    all_ocr = [e for e in obs.get("elements", []) if e.get("source") == "ocr"]
    occ_leaks = sum(1 for e in all_ocr if "occluderword" in str(e.get("name", "")).lower())

    root.destroy()

    return {
        "case": "OCC",
        "app": "Notepad Occlusion",
        "occluder_leaks": occ_leaks,
        "latency_ms": round(dt_ms, 2),
        "ocr_added_latency_ms": round(dt_ms, 2),
        "ram_delta_mb": 0.0,
        "uia_unchanged": True,
        "status": "available",
    }


def run_case_browser(
    case_key: str,
    app_name: str,
    page_url: str,
    truth_dict: dict[str, list[str]],
    repeats: int = 3,
) -> dict[str, Any]:
    """
    Runs Case CH (Chrome) or ED (Edge).
    Opens file:// page.html in isolated browser instance with temp user-data-dir.
    """
    import win32gui

    print(f"\n[*] Testing Case {case_key}: {app_name}...")
    bin_names = ["chrome.exe"] if case_key == "CH" else ["msedge.exe"]
    bin_path = find_browser_binary(bin_names)
    if not bin_path:
        return {
            "case": case_key,
            "app": app_name,
            "status": "skipped_binary_not_found",
            "capture_blank": False,
            "honesty_blank": True,
            "recall": 0.0,
            "precision": 0.0,
            "subcases": {},
            "error": f"Binary not found: {bin_names}",
        }

    temp_dir = tempfile.mkdtemp(prefix=f"goku_ocr_{case_key.lower()}_")
    snapshot = snapshot_visible_top_level_hwnds()

    proc = subprocess.Popen([
        bin_path,
        f"--user-data-dir={temp_dir}",
        "--no-first-run",
        "--no-default-browser-check",
        "--force-renderer-accessibility",
        page_url,
    ])

    hwnd = 0
    start = time.time()
    while time.time() - start < 8.0:
        found_hwnds: list[int] = []

        def _cb(h: int, _: Any) -> bool:
            if h in snapshot:
                return True
            try:
                if win32gui.IsWindowVisible(h) and not win32gui.IsIconic(h):
                    info = get_window_info(h)
                    title = (info.get("title") or "").upper()
                    if matches_app_identity(info, app_name) and "OCR REAL PAGE" in title:
                        found_hwnds.append(h)
            except Exception:
                pass
            return True

        win32gui.EnumWindows(_cb, None)
        if found_hwnds:
            hwnd = found_hwnds[0]
            break
        time.sleep(0.3)

    if not hwnd:
        try:
            proc.terminate()
        except Exception:
            pass
        return {
            "case": case_key,
            "app": app_name,
            "status": "launch_failed",
            "capture_blank": False,
            "honesty_blank": True,
            "recall": 0.0,
            "precision": 0.0,
            "subcases": {},
            "error": f"Could not locate opened {app_name} window matching title 'OCR REAL PAGE'",
        }

    # Identify Region: Chrome_RenderWidgetHostHWND rect
    render_hwnd = find_render_widget_host(hwnd)
    if render_hwnd:
        region = get_rect_dict(render_hwnd)
        print(f"    [+] Found Chrome_RenderWidgetHostHWND: {region}")
    else:
        print("    [!] Chrome_RenderWidgetHostHWND child not found; using window rect minus 120px top.")
        w_rect = get_rect_dict(hwnd)
        region = {"left": w_rect["left"], "top": w_rect["top"] + 120, "right": w_rect["right"], "bottom": w_rect["bottom"]}

    # Baseline call
    base_t0 = time.perf_counter()
    base_obs = observe(scope=hwnd, include_ocr=False, force_refresh=True)
    base_lat_ms = (time.perf_counter() - base_t0) * 1000.0
    base_uia_count = base_obs.get("count", 0)

    # Measure repeats
    ocr_latencies: list[float] = []
    base_latencies: list[float] = []
    ram_deltas: list[float] = []
    last_obs: dict[str, Any] = {}
    last_img: Any = None

    for call_idx in range(repeats + 1):
        t_b0 = time.perf_counter()
        _ = observe(scope=hwnd, include_ocr=False, force_refresh=True)
        b_dt = (time.perf_counter() - t_b0) * 1000.0

        r0 = get_process_ram_mb()
        t0 = time.perf_counter()
        obs = observe(scope=hwnd, include_ocr=True, force_refresh=True)
        dt_ms = (time.perf_counter() - t0) * 1000.0
        r1 = get_process_ram_mb()

        img, _ = _capture_window_surface(hwnd)

        if call_idx > 0:
            ocr_latencies.append(dt_ms)
            base_latencies.append(b_dt)
            ram_deltas.append(max(0.0, r1 - r0))
            last_obs = obs
            last_img = img

    med_ocr_lat = statistics.median(ocr_latencies) if ocr_latencies else 0.0
    med_base_lat = statistics.median(base_latencies) if base_latencies else base_lat_ms
    added_lat = max(0.0, med_ocr_lat - med_base_lat)
    med_ram = statistics.median(ram_deltas) if ram_deltas else 0.0

    c_blank = compute_capture_blank(last_img)
    all_ocr_elements = [e for e in last_obs.get("elements", []) if e.get("source") == "ocr"]
    ocr_in_region = filter_elements_by_region(all_ocr_elements, region)
    ocr_tokens = [normalize_word(e.get("name", "")) for e in ocr_in_region if normalize_word(e.get("name", ""))]

    canvas_match = calculate_word_match(truth_dict["canvas"], ocr_tokens)
    image_match = calculate_word_match(truth_dict["image"], ocr_tokens)
    dom_match = calculate_word_match(truth_dict["dom"], ocr_tokens)

    # Precision in region against all valid page truth words
    prec_res = calculate_precision_in_region(truth_dict["all_page"], ocr_tokens)

    # UIA unchanged check
    post_obs = observe(scope=hwnd, include_ocr=False, force_refresh=True)
    uia_unchanged = (post_obs.get("count", 0) == base_uia_count)

    h_blank = evaluate_honesty_blank(
        c_blank,
        last_obs.get("scene", {}).get("ocr_status", "unavailable"),
        len(all_ocr_elements),
    )

    # Cleanup instance
    try:
        win32gui.PostMessage(hwnd, 0x0010, 0, 0)
        time.sleep(0.5)
    except Exception:
        pass
    try:
        proc.terminate()
    except Exception:
        pass

    return {
        "case": case_key,
        "app": app_name,
        "status": last_obs.get("scene", {}).get("ocr_status", "available"),
        "capture_method": last_obs.get("scene", {}).get("capture_method", "none"),
        "capture_blank": c_blank,
        "honesty_blank": h_blank,
        "precision": prec_res["precision"],
        "subcases": {
            "canvas": canvas_match,
            "image": image_match,
            "dom": dom_match,
        },
        "ocr_added_latency_ms": round(added_lat, 2),
        "latency_ms": round(med_ocr_lat, 2),
        "baseline_latency_ms": round(med_base_lat, 2),
        "ram_delta_mb": round(med_ram, 2),
        "uia_unchanged": uia_unchanged,
        "region": region,
    }


def run_case_informational(
    case_key: str,
    app_name: str,
    launch_cmd: list[str] | str,
    repeats: int = 2,
) -> dict[str, Any]:
    """
    Runs Case CA (Calculator) or ST (Settings) (Informational only).
    Extracts truth from kit's own UIA walk of the window (names with >= 4 letters).
    """
    import win32gui

    print(f"\n[*] Testing Informational Case {case_key}: {app_name} (with cold-start frame caveat)...")
    snapshot = snapshot_visible_top_level_hwnds()

    proc = None
    if isinstance(launch_cmd, list):
        proc = subprocess.Popen(launch_cmd)
    else:
        os.system(launch_cmd)

    hwnd, _ = find_new_app_window(app_name, snapshot, timeout_sec=5.0)
    if not hwnd:
        # Check for reused frame
        matches = find_matching_visible_windows(app_name)
        if matches:
            hwnd = matches[0].get("hwnd", 0)

    if not hwnd:
        return {
            "case": case_key,
            "app": app_name,
            "informational": True,
            "status": "launch_failed",
            "caveat": "UWP cold-start frame caveat",
        }

    uia_oracle = init_uia_oracle()
    walked_nodes = walk_uia_tree(uia_oracle, hwnd, max_nodes=100, max_depth=5)
    raw_names = [n.get("name", "") for n in walked_nodes if len(str(n.get("name", "")).strip()) >= 4]
    deduped_truth = sorted(list(set(raw_names)))

    t0 = time.perf_counter()
    obs = observe(scope=hwnd, include_ocr=True, force_refresh=True)
    dt_ms = (time.perf_counter() - t0) * 1000.0

    all_ocr = [e for e in obs.get("elements", []) if e.get("source") == "ocr"]
    ocr_tokens = [normalize_word(e.get("name", "")) for e in all_ocr if normalize_word(e.get("name", ""))]

    match_res = calculate_word_match(deduped_truth, ocr_tokens)

    # Cleanup
    try:
        win32gui.PostMessage(hwnd, 0x0010, 0, 0)
        time.sleep(0.4)
    except Exception:
        pass
    if proc:
        try:
            proc.terminate()
        except Exception:
            pass

    return {
        "case": case_key,
        "app": app_name,
        "informational": True,
        "status": obs.get("scene", {}).get("ocr_status", "available"),
        "capture_method": obs.get("scene", {}).get("capture_method", "none"),
        "truth_count": len(deduped_truth),
        "matched_count": match_res["matched_count"],
        "recall": match_res["recall"],
        "latency_ms": round(dt_ms, 2),
        "caveat": "UWP cold-start frame caveat",
    }


# ==============================================================================
# 6. SUITE RUNNER & TABLE FORMATTER
# ==============================================================================

def print_real_apps_table(case_results: dict[str, Any]) -> None:
    """Prints structured Markdown table of Real Apps OCR telemetry."""
    headers = [
        "Case", "App", "Gating?", "Blank?", "Matched / Truth",
        "Recall", "Prec (Region)", "Added Latency", "RAM Delta", "Status"
    ]
    print("\n## Real Apps OCR Telemetry Table")
    print("| " + " | ".join(headers) + " |")
    print("|" + "|".join(["---"] * len(headers)) + "|")

    for k in ["NP", "CH", "ED", "OCC", "CA", "ST"]:
        if k not in case_results:
            continue
        c = case_results[k]
        app_name = c.get("app", k)
        is_info = c.get("informational", False)
        gating_str = "No (Info)" if is_info else "YES"

        blank_str = str(c.get("capture_blank", "N/A"))
        matched = c.get("matched_count", "-")
        truth = c.get("truth_count", "-")

        rec_str = f"{c.get('recall', 0.0)*100.0:.1f}%" if "recall" in c else "-"
        prec_str = f"{c.get('precision', 0.0)*100.0:.1f}%" if "precision" in c else "-"
        lat_str = f"{c.get('ocr_added_latency_ms', c.get('latency_ms', 0.0)):.1f} ms"
        ram_str = f"{c.get('ram_delta_mb', 0.0):.1f} MB" if "ram_delta_mb" in c else "-"
        st = c.get("status", "N/A")

        if k in ("CH", "ED") and "subcases" in c:
            sub = c["subcases"]
            c_rec = sub.get("canvas", {}).get("recall", 0.0) * 100.0
            i_rec = sub.get("image", {}).get("recall", 0.0) * 100.0
            d_rec = sub.get("dom", {}).get("recall", 0.0) * 100.0
            rec_str = f"C:{c_rec:.0f}% I:{i_rec:.0f}% (D:{d_rec:.0f}%)"
            matched = f"{sub.get('canvas', {}).get('matched_count', 0)}+{sub.get('image', {}).get('matched_count', 0)}"
            truth = f"{sub.get('canvas', {}).get('truth_count', 0)}+{sub.get('image', {}).get('truth_count', 0)}"

        print(
            f"| {k} | {app_name} | {gating_str} | {blank_str} | {matched} / {truth} | "
            f"{rec_str} | {prec_str} | {lat_str} | {ram_str} | {st} |"
        )
    print("")


def run_real_apps_suite(
    tag: str = "real1",
    repeats: int = 3,
    check_kit: bool = False,
) -> dict[str, Any]:
    """
    Executes the full Real Apps OCR test suite.
    """
    # 1. Scale verification
    scale_pct = get_display_scale_pct()
    if scale_pct != 100:
        sys.exit(f"REFUSED: Level Real Apps requires 100% display scaling (detected {scale_pct}%). Please adjust Windows Settings.")

    kit_sha = compute_real_kit_sha256()
    engine_sha = compute_engine_sha256()

    kit_hash_path = PROJECT_ROOT / "reports" / "ocr" / "REAL_KIT_HASH.json"
    if check_kit and kit_hash_path.is_file():
        kit_data = json.loads(kit_hash_path.read_text(encoding="utf-8"))
        if kit_sha != kit_data.get("kit_sha256"):
            sys.exit("REFUSED: Kit hash mismatch in reports/ocr/REAL_KIT_HASH.json")

    # 2. Assets setup
    html_p, fix_p, fix_sha, truth_dict = ensure_real_page_assets()
    page_url = html_p.resolve().as_uri()

    case_results: dict[str, Any] = {}

    # 3. Case NP: Notepad & Case OCC: Occlusion
    np_res, np_hwnd = run_case_notepad(repeats=repeats)
    case_results["NP"] = np_res

    if np_hwnd:
        occ_res = run_case_occlusion(np_hwnd)
        case_results["OCC"] = occ_res
        # Cleanup Notepad after occlusion
        try:
            import win32gui
            win32gui.PostMessage(np_hwnd, 0x0010, 0, 0)
        except Exception:
            pass

    # 4. Case CH: Chrome
    ch_res = run_case_browser("CH", "Chrome", page_url, truth_dict, repeats=repeats)
    case_results["CH"] = ch_res

    # 5. Case ED: Edge
    ed_res = run_case_browser("ED", "Edge", page_url, truth_dict, repeats=repeats)
    case_results["ED"] = ed_res

    # 6. Informational Cases: CA & ST
    ca_res = run_case_informational("CA", "Calculator", ["calc.exe"], repeats=1)
    case_results["CA"] = ca_res

    st_res = run_case_informational("ST", "Settings", "start ms-settings:", repeats=1)
    case_results["ST"] = st_res

    # 7. Evaluate rules
    verdict, rules = evaluate_real_apps_rules(case_results)

    # 8. Print report
    print_real_apps_table(case_results)

    print("=" * 64)
    print(f"STAGE 1 TASK 1.2b REAL APPS OCR VERDICT: {verdict}")
    print("=" * 64)
    for r in rules:
        status_str = "PASS" if r["passed"] else "FAIL"
        print(f"[{status_str}] {r['rule']}: {r['description']}")
        print(f"       -> {r['details']}")
    print("-" * 64)
    print(f"FINAL RESULT: {verdict}")
    print("=" * 64)

    # 9. Save JSON payload
    payload = {
        "tag": tag,
        "suite": "real_apps",
        "verdict": verdict,
        "kit_sha256": kit_sha,
        "engine_sha256": engine_sha,
        "fixture_sha256": fix_sha,
        "python_version": platform.python_version(),
        "scale": f"{scale_pct}%",
        "repeats": repeats,
        "cases": case_results,
        "rules": rules,
    }

    out_dir = PROJECT_ROOT / "reports" / "ocr" / "real"
    out_dir.mkdir(parents=True, exist_ok=True)
    out_file = out_dir / f"{tag}.json"
    out_file.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    print(f"[+] Successfully wrote report to {out_file}")

    return payload


# ==============================================================================
# 7. CLI DISPATCHER
# ==============================================================================

def main():
    parser = argparse.ArgumentParser(description="GOKU OCR on Real Applications Test Suite")
    parser.add_argument("--tag", default="real1", help="Output JSON tag (e.g. real1)")
    parser.add_argument("--repeats", type=int, default=3, help="Measured repeat iterations")
    parser.add_argument("--check-kit", action="store_true", help="Assert kit matches reports/ocr/REAL_KIT_HASH.json")
    args = parser.parse_args()

    if args.check_kit:
        ok = check_real_kit_integrity()
        sys.exit(0 if ok else 1)

    payload = run_real_apps_suite(tag=args.tag, repeats=args.repeats, check_kit=False)
    sys.exit(0 if payload["verdict"] == "ACCEPT" else 1)


if __name__ == "__main__":
    main()
