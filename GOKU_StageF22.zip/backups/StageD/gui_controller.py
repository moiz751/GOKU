"""
GUI Controller Tool — Screen sensing and OS hardware input simulation.
Provides lightweight Win32 API-driven screen capture, mouse kinematics/clicks,
and Unicode keyboard event dispatch without exceeding memory or latency budgets.
"""
import ctypes
from ctypes import wintypes
import math
import os
from pathlib import Path
import re
import sys
import time
from typing import Any

from tools.registry import tool

_LAST_FOCUSED_HWND = 0

PROTECTED_PROCESSES = [
    "antigravity ide.exe",
    "antigravity",
    "code.exe",
    "powershell.exe",
    "cmd.exe",
    "windowsterminal.exe",
]

try:
    from tools.window import manage_window
except ImportError:
    manage_window = None

try:
    from tools.gui import press_hotkey
except ImportError:
    press_hotkey = None

# -------------------------------------------------------------
# Win32 Hardware Constants & Structures
# -------------------------------------------------------------
INPUT_MOUSE = 0
INPUT_KEYBOARD = 1

MOUSEEVENTF_MOVE = 0x0001
MOUSEEVENTF_LEFTDOWN = 0x0002
MOUSEEVENTF_LEFTUP = 0x0004
MOUSEEVENTF_RIGHTDOWN = 0x0008
MOUSEEVENTF_RIGHTUP = 0x0010
MOUSEEVENTF_MIDDLEDOWN = 0x0020
MOUSEEVENTF_MIDDLEUP = 0x0040
MOUSEEVENTF_ABSOLUTE = 0x8000

KEYEVENTF_UNICODE = 0x0004
KEYEVENTF_KEYUP = 0x0002
VK_RETURN = 0x0D


class POINT(ctypes.Structure):
    _fields_ = [("x", ctypes.c_long), ("y", ctypes.c_long)]


class BITMAPINFOHEADER(ctypes.Structure):
    _fields_ = [
        ("biSize", wintypes.DWORD),
        ("biWidth", wintypes.LONG),
        ("biHeight", wintypes.LONG),
        ("biPlanes", wintypes.WORD),
        ("biBitCount", wintypes.WORD),
        ("biCompression", wintypes.DWORD),
        ("biSizeImage", wintypes.DWORD),
        ("biXPelsPerMeter", wintypes.LONG),
        ("biYPelsPerMeter", wintypes.LONG),
        ("biClrUsed", wintypes.DWORD),
        ("biClrImportant", wintypes.DWORD),
    ]


class KEYBDINPUT(ctypes.Structure):
    _fields_ = [
        ("wVk", wintypes.WORD),
        ("wScan", wintypes.WORD),
        ("dwFlags", wintypes.DWORD),
        ("time", wintypes.DWORD),
        ("dwExtraInfo", ctypes.c_ulonglong if ctypes.sizeof(ctypes.c_void_p) == 8 else wintypes.DWORD),
    ]


class MOUSEINPUT(ctypes.Structure):
    _fields_ = [
        ("dx", wintypes.LONG),
        ("dy", wintypes.LONG),
        ("mouseData", wintypes.DWORD),
        ("dwFlags", wintypes.DWORD),
        ("time", wintypes.DWORD),
        ("dwExtraInfo", ctypes.c_ulonglong if ctypes.sizeof(ctypes.c_void_p) == 8 else wintypes.DWORD),
    ]


class INPUT(ctypes.Structure):
    class _INPUT(ctypes.Union):
        _fields_ = [("ki", KEYBDINPUT), ("mi", MOUSEINPUT)]

    _anonymous_ = ("_input",)
    _fields_ = [
        ("type", wintypes.DWORD),
        ("_input", _INPUT),
    ]


def _get_screen_dimensions() -> tuple[int, int]:
    """Returns primary monitor resolution (width, height) via user32."""
    if sys.platform == "win32":
        try:
            u32 = ctypes.windll.user32
            return int(u32.GetSystemMetrics(0)), int(u32.GetSystemMetrics(1))
        except Exception:
            pass
    return 1920, 1080


def _get_current_cursor() -> tuple[int, int]:
    """Returns current mouse cursor position."""
    if sys.platform == "win32":
        try:
            pt = POINT()
            ctypes.windll.user32.GetCursorPos(ctypes.byref(pt))
            return int(pt.x), int(pt.y)
        except Exception:
            pass
    return 0, 0


def get_safe_active_client_center() -> tuple[int, int]:
    """Calculates active foreground window client center dynamically instead of static coordinates."""
    import win32gui
    try:
        hwnd = win32gui.GetForegroundWindow()
        if hwnd and win32gui.IsWindow(hwnd):
            r = win32gui.GetClientRect(hwnd)
            w = r[2] - r[0]
            h = r[3] - r[1]
            if w > 10 and h > 10:
                pt = win32gui.ClientToScreen(hwnd, (w // 2, h // 2))
                return int(pt[0]), int(pt[1])
    except Exception:
        pass
    return 500, 350



# -------------------------------------------------------------
# Atomic Tool Implementations
# -------------------------------------------------------------

@tool(
    name="capture_screen",
    description="Takes a lightweight screenshot of the primary monitor using native Win32 GDI BitBlt (<50 ms latency).",
    parameters={
        "type": "object",
        "properties": {
            "output_path": {
                "type": "string",
                "description": "Optional file path to save the captured image."
            }
        }
    },
    category="gui",
    risk_level="read_only"
)
def capture_screen(output_path: str | None = None) -> dict[str, Any]:
    """
    Takes a lightweight screenshot of the primary monitor using ctypes GDI BitBlt.
    Returns metadata: {"status": "PASSED", "width": W, "height": H, "file_path": path}.
    Latency is strictly < 50 ms.
    """
    if sys.platform != "win32":
        return {
            "status": "FAILED",
            "error": "capture_screen is only supported on Windows OS.",
            "width": 0,
            "height": 0,
            "file_path": None,
            "success": False
        }

    try:
        user32 = ctypes.windll.user32
        gdi32 = ctypes.windll.gdi32

        w = int(user32.GetSystemMetrics(0))
        h = int(user32.GetSystemMetrics(1))

        hdc_screen = user32.GetDC(0)
        hdc_mem = gdi32.CreateCompatibleDC(hdc_screen)
        hbmp = gdi32.CreateCompatibleBitmap(hdc_screen, w, h)
        hbmp_old = gdi32.SelectObject(hdc_mem, hbmp)

        SRCCOPY = 0x00CC0020
        gdi32.BitBlt(hdc_mem, 0, 0, w, h, hdc_screen, 0, 0, SRCCOPY)

        saved_path = None
        if output_path is not None:
            saved_path = str(output_path)
            Path(saved_path).parent.mkdir(parents=True, exist_ok=True)

            bih = BITMAPINFOHEADER()
            bih.biSize = ctypes.sizeof(BITMAPINFOHEADER)
            bih.biWidth = w
            bih.biHeight = -h
            bih.biPlanes = 1
            bih.biBitCount = 32
            bih.biCompression = 0

            buf = ctypes.create_string_buffer(w * h * 4)
            gdi32.GetDIBits(hdc_mem, hbmp, 0, h, buf, ctypes.byref(bih), 0)

            try:
                from PIL import Image
                img = Image.frombuffer("RGBA", (w, h), buf, "raw", "BGRA", 0, 1)
                img.save(saved_path, "PNG", compress_level=1)
            except ImportError:
                # Write direct BMP header without PIL
                bmp_header = bytearray()
                file_size = 54 + (w * h * 4)
                bmp_header.extend(b'BM')
                bmp_header.extend(file_size.to_bytes(4, 'little'))
                bmp_header.extend((0).to_bytes(4, 'little'))
                bmp_header.extend((54).to_bytes(4, 'little'))
                # DIB Header
                bmp_header.extend((40).to_bytes(4, 'little'))
                bmp_header.extend(w.to_bytes(4, 'little', signed=True))
                bmp_header.extend((-h).to_bytes(4, 'little', signed=True))
                bmp_header.extend((1).to_bytes(2, 'little'))
                bmp_header.extend((32).to_bytes(2, 'little'))
                bmp_header.extend((0).to_bytes(4, 'little'))
                bmp_header.extend((w * h * 4).to_bytes(4, 'little'))
                bmp_header.extend((0).to_bytes(16, 'little'))
                with open(saved_path, "wb") as f:
                    f.write(bmp_header)
                    f.write(buf)

        # Cleanup Win32 GDI handles
        gdi32.SelectObject(hdc_mem, hbmp_old)
        gdi32.DeleteObject(hbmp)
        gdi32.DeleteDC(hdc_mem)
        user32.ReleaseDC(0, hdc_screen)

        return {
            "status": "PASSED",
            "width": w,
            "height": h,
            "file_path": saved_path,
            "success": True,
            "message": f"Screen capture completed ({w}x{h})."
        }
    except (Exception, MemoryError) as e:
        # Fallback to PIL ImageGrab when GDI BitBlt fails under low memory
        try:
            from PIL import ImageGrab
            img = ImageGrab.grab()
            w, h = img.size
            saved_path = None
            if output_path is not None:
                saved_path = str(output_path)
                Path(saved_path).parent.mkdir(parents=True, exist_ok=True)
                img.save(saved_path, "PNG", compress_level=1)
            return {
                "status": "PASSED",
                "width": w,
                "height": h,
                "file_path": saved_path,
                "success": True,
                "message": f"Screen capture completed via fallback ({w}x{h})."
            }
        except Exception as fb_err:
            return {
                "status": "FAILED",
                "error": f"GDI BitBlt failed ({e}), fallback failed ({fb_err})",
                "width": 0,
                "height": 0,
                "file_path": None,
                "success": False
            }


@tool(
    name="mouse_click",
    description="Dispatches hardware mouse click at target coordinates using native Win32 SetCursorPos and mouse_event.",
    parameters={
        "type": "object",
        "properties": {
            "x": {
                "type": "integer",
                "description": "X horizontal coordinate on the primary display."
            },
            "y": {
                "type": "integer",
                "description": "Y vertical coordinate on the primary display."
            },
            "button": {
                "type": "string",
                "description": "Mouse button to click: 'left', 'right', or 'middle'.",
                "enum": ["left", "right", "middle"]
            },
            "clicks": {
                "type": "integer",
                "description": "Number of consecutive clicks (default 1, 2 for double click)."
            }
        },
        "required": ["x", "y"]
    },
    category="gui",
    risk_level="active_inspection"
)
def mouse_click(
    x: int | None = None,
    y: int | None = None,
    button: str = "left",
    clicks: int = 1,
    target_name: str | None = None,
    **kwargs: Any
) -> dict[str, Any]:
    """
    Validates screen bounds and dispatches hardware mouse clicks using ctypes.windll.user32.
    If x and y are not provided but target_name is, grounds target using find_text_on_screen.
    Returns: {"status": "PASSED", "action": "click", "x": x, "y": y, "button": button}
    """
    target_label = target_name or kwargs.get("target") or kwargs.get("label") or kwargs.get("element_name") or kwargs.get("text")
    if (x is None or y is None) and target_label:
        loc = find_text_on_screen(str(target_label))
        if loc.get("found") and loc.get("x") is not None and loc.get("y") is not None and loc.get("x") >= 0 and loc.get("y") >= 0:
            x, y = loc["x"], loc["y"]
        else:
            return {
                "status": "FAILED",
                "action": "click",
                "target_name": target_label,
                "error": f"UI Grounding failed: Element '{target_label}' not found on screen.",
                "error_code": "resource_not_found",
                "x": -1,
                "y": -1,
                "button": button,
                "success": False,
                "message": f"UI Grounding failed: Element '{target_label}' not found on screen."
            }

    if x is None or y is None:
        return {
            "status": "FAILED",
            "action": "click",
            "error": "Coordinates missing: both x and y (or target_name) are required.",
            "error_code": "invalid_argument",
            "x": -1,
            "y": -1,
            "button": button,
            "success": False,
            "message": "Coordinates missing: both x and y (or target_name) are required."
        }

    screen_w, screen_h = _get_screen_dimensions()

    # Strict boundary validation
    if not (0 <= x <= screen_w and 0 <= y <= screen_h):
        return {
            "status": "FAILED",
            "action": "click",
            "error": f"Coordinates ({x}, {y}) out of screen bounds ({screen_w}x{screen_h}).",
            "x": x,
            "y": y,
            "button": button,
            "success": False,
            "message": f"Coordinates ({x}, {y}) out of screen bounds."
        }

    # 1. Reject standard system window control coordinates (top-right close/minimize buttons x > width - 150, y < 40)
    is_explicit_window_control = False
    for k in [target_name, kwargs.get("target"), kwargs.get("label"), kwargs.get("element_name"), kwargs.get("query"), kwargs.get("text")]:
        if k and any(w in str(k).lower() for w in ["minimize", "close", "maximize", "restore", "titlebar", "window button", "caption"]):
            is_explicit_window_control = True
            break

    if not is_explicit_window_control and (x > screen_w - 150 and y < 40):
        return {
            "status": "FAILED",
            "action": "click",
            "error": "Target out of window scope: cannot click system window controls.",
            "error_code": "out_of_scope",
            "x": x,
            "y": y,
            "button": button,
            "success": False,
            "message": "Target out of window scope: cannot click system window controls."
        }

    # 2. Restrict all coordinate clicks to the bounding rect of the target application window
    # and NEVER click on parent IDE window or terminal console unless explicitly commanded
    if not is_explicit_window_control and sys.platform == "win32":
        try:
            user32 = ctypes.windll.user32
            fg = user32.GetForegroundWindow()
            if fg:
                length = user32.GetWindowTextLengthW(fg) + 1
                if length > 1:
                    buff = ctypes.create_unicode_buffer(length)
                    user32.GetWindowTextW(fg, buff, length)
                    win_title = buff.value.lower()
                    if any(term in win_title for term in ("antigravity", "visual studio", "cmd", "powershell", "terminal", "conhost")):
                        if not any(k in (target_name or "").lower() for k in ("ide", "antigravity", "terminal", "console", "cmd", "powershell")):
                            return {
                                "status": "FAILED",
                                "action": "click",
                                "error": "Target out of window scope: cannot click parent IDE window or terminal console.",
                                "error_code": "out_of_scope",
                                "x": x,
                                "y": y,
                                "button": button,
                                "success": False,
                                "message": "Target out of window scope: cannot click parent IDE window or terminal console."
                            }
        except Exception:
            pass

    btn = button.lower().strip()
    if btn == "right":
        _down_flag, _up_flag = MOUSEEVENTF_RIGHTDOWN, MOUSEEVENTF_RIGHTUP
    elif btn == "middle":
        _down_flag, _up_flag = MOUSEEVENTF_MIDDLEDOWN, MOUSEEVENTF_MIDDLEUP
    else:
        btn = "left"
        _down_flag, _up_flag = MOUSEEVENTF_LEFTDOWN, MOUSEEVENTF_LEFTUP

    if sys.platform == "win32":
        try:
            from tools.input_guard import guarded_send
            res = guarded_send("click_mouse", None, {"x": x, "y": y, "button": btn, "clicks": clicks})
            if not res.get("success", False):
                return {
                    "status": "FAILED",
                    "action": "click",
                    "error": res.get("reason", "Click refused by input guard"),
                    "x": x,
                    "y": y,
                    "button": btn,
                    "success": False
                }
        except Exception as e:
            return {
                "status": "FAILED",
                "action": "click",
                "error": str(e),
                "x": x,
                "y": y,
                "button": btn,
                "success": False
            }

    return {
        "status": "PASSED",
        "action": "click",
        "x": x,
        "y": y,
        "button": btn,
        "clicks": clicks,
        "success": True,
        "message": f"Mouse clicked at ({x}, {y}) with button '{btn}'."
    }


@tool(
    name="mouse_move",
    description="Moves the mouse cursor to target coordinates smoothly using native Win32 SetCursorPos.",
    parameters={
        "type": "object",
        "properties": {
            "x": {
                "type": "integer",
                "description": "Target X screen coordinate."
            },
            "y": {
                "type": "integer",
                "description": "Target Y screen coordinate."
            }
        },
        "required": ["x", "y"]
    },
    category="gui",
    risk_level="active_inspection"
)
def mouse_move(x: int, y: int) -> dict[str, Any]:
    """
    Moves the cursor to target coordinates smoothly.
    Returns: {"status": "PASSED", "action": "move", "x": x, "y": y}
    """
    screen_w, screen_h = _get_screen_dimensions()

    if not (0 <= x <= screen_w and 0 <= y <= screen_h):
        return {
            "status": "FAILED",
            "action": "move",
            "error": f"Coordinates ({x}, {y}) out of screen bounds ({screen_w}x{screen_h}).",
            "x": x,
            "y": y,
            "success": False,
            "message": f"Coordinates ({x}, {y}) out of screen bounds."
        }

    if sys.platform == "win32":
        try:
            user32 = ctypes.windll.user32
            start_x, start_y = _get_current_cursor()
            dist = math.hypot(x - start_x, y - start_y)
            steps = min(20, max(5, int(dist / 25)))

            for i in range(1, steps + 1):
                cur_x = int(start_x + (x - start_x) * (i / steps))
                cur_y = int(start_y + (y - start_y) * (i / steps))
                user32.SetCursorPos(cur_x, cur_y)
                time.sleep(0.002)

            user32.SetCursorPos(int(x), int(y))
        except Exception as e:
            return {
                "status": "FAILED",
                "action": "move",
                "error": str(e),
                "x": x,
                "y": y,
                "success": False
            }

    return {
        "status": "PASSED",
        "action": "move",
        "x": x,
        "y": y,
        "success": True,
        "message": f"Mouse moved to ({x}, {y})."
    }


_RECENT_KEYBOARD_INPUTS: list[str] = []


def record_keyboard_input(text: str) -> None:
    """Records recently typed keyboard inputs for robust fallback buffer recovery."""
    if text is not None:
        s = str(text)
        _RECENT_KEYBOARD_INPUTS.append(s)
        if len(_RECENT_KEYBOARD_INPUTS) > 30:
            _RECENT_KEYBOARD_INPUTS.pop(0)
        try:
            from command_layer.context import session_context
            session_context.last_typed_text = s
        except Exception:
            pass


def get_recent_keyboard_inputs() -> list[str]:
    """Returns a copy of recently typed keyboard inputs."""
    return list(_RECENT_KEYBOARD_INPUTS)


def clear_recent_keyboard_inputs() -> None:
    """Clears tracked keyboard inputs."""
    _RECENT_KEYBOARD_INPUTS.clear()


def _sterilize_clipboard_if_notepad_or_contaminated(typed_text: str = "") -> None:
    """Ensures raw prompt text is purged from the OS clipboard when interacting with editors."""
    try:
        from tools.clipboard_workflows import (
            _clear_system_clipboard,
            _is_buffer_prompt_contaminated,
            _get_session_prompts,
            _read_clipboard_text_direct,
        )
        is_editor = False
        if sys.platform == "win32":
            user32 = ctypes.windll.user32
            fg = user32.GetForegroundWindow()
            if fg:
                length = user32.GetWindowTextLengthW(fg) + 1
                if length > 1:
                    buff = ctypes.create_unicode_buffer(length)
                    user32.GetWindowTextW(fg, buff, length)
                    title = buff.value.lower()
                    if any(app in title for app in ("notepad", "wordpad")):
                        is_editor = True

        ok, clip_text = _read_clipboard_text_direct()
        if ok and clip_text:
            if is_editor or _is_buffer_prompt_contaminated(clip_text, _get_session_prompts()):
                _clear_system_clipboard()
    except Exception:
        pass


@tool(
    name="send_keyboard_input",
    description="Sends sanitized text keystrokes to the focused control with optional Enter key press using native Win32 SendInput.",
    parameters={
        "type": "object",
        "properties": {
            "text": {
                "type": "string",
                "description": "Sanitized text payload to type."
            },
            "press_enter": {
                "type": "boolean",
                "description": "Whether to send VK_RETURN after typing text."
            }
        },
        "required": ["text"]
    },
    category="gui",
    risk_level="active_inspection"
)
def send_keyboard_input(text: str, press_enter: bool = False, **kwargs: Any) -> dict[str, Any]:
    """
    Sends sanitized text keystrokes to the currently focused window control.
    If press_enter=True, dispatches VK_RETURN.
    """
    sanitized_text = str(text) if text is not None else ""
    record_keyboard_input(sanitized_text)

    # 0. STRICT FOREGROUND SAFETY & SOURCE POLLUTION GUARD
    if sys.platform == "win32":
        try:
            user32 = ctypes.windll.user32
            fg_hwnd = user32.GetForegroundWindow()
            from tools.window import is_ide_window
            from tools.apps import is_window_launched_by_test

            # Guard 1: Never type if the active foreground window is the IDE
            if fg_hwnd and is_ide_window(fg_hwnd):
                length = user32.GetWindowTextLengthW(fg_hwnd) + 1
                buff = ctypes.create_unicode_buffer(length)
                user32.GetWindowTextW(fg_hwnd, buff, length)
                fg_title = buff.value or ""
                return {
                    "status": "FAILED",
                    "action": "type",
                    "text": sanitized_text,
                    "press_enter": press_enter,
                    "success": False,
                    "error": f"Typing blocked: Foreground window '{fg_title}' (HWND {fg_hwnd}) is the IDE or code editor. Keystrokes withheld to prevent source pollution.",
                    "message": f"Typing blocked: Foreground window '{fg_title}' is the IDE.",
                }

            # Guard 2: In test environments, refuse to run typing unless target window was launched by the test
            is_testing = bool(os.environ.get("PYTEST_CURRENT_TEST") or "pytest" in sys.modules)
            if is_testing and fg_hwnd and not is_window_launched_by_test(fg_hwnd):
                length = user32.GetWindowTextLengthW(fg_hwnd) + 1
                buff = ctypes.create_unicode_buffer(length)
                user32.GetWindowTextW(fg_hwnd, buff, length)
                fg_title = buff.value or ""
                return {
                    "status": "FAILED",
                    "action": "type",
                    "text": sanitized_text,
                    "press_enter": press_enter,
                    "success": False,
                    "error": f"Typing blocked: GUI test refused because active window '{fg_title}' was not launched by the test itself (must be dedicated test window, e.g. dedicated Notepad).",
                    "message": "Typing blocked: Target window was not launched by test.",
                }
        except Exception:
            pass

    # 1. When typing text into Notepad or WordPad, do not leave raw prompt text sitting in OS clipboard
    _sterilize_clipboard_if_notepad_or_contaminated(sanitized_text)

    # 3. Detect if target or active window is a terminal/command shell
    is_terminal = False
    target_hint = str(kwargs.get("app_name") or kwargs.get("name") or kwargs.get("target") or "").lower()
    if any(term in target_hint for term in ("cmd", "powershell", "terminal", "bash", "command prompt", "conhost", "wt")):
        is_terminal = True
    elif sys.platform == "win32":
        try:
            user32 = ctypes.windll.user32
            fg = user32.GetForegroundWindow()
            if fg:
                length = user32.GetWindowTextLengthW(fg) + 1
                if length > 1:
                    buff = ctypes.create_unicode_buffer(length)
                    user32.GetWindowTextW(fg, buff, length)
                    win_title = buff.value.lower()
                    if any(term in win_title for term in ("cmd", "powershell", "terminal", "bash", "command prompt", "conhost", "wt.exe")):
                        is_terminal = True
        except Exception:
            pass

    def _await_terminal_stdout_and_parse(cmd_text: str, result_dict: dict[str, Any]) -> None:
        if not (is_terminal and press_enter and cmd_text):
            return
        low_cmd = cmd_text.lower().strip()
        if any(c in low_cmd for c in ("ping", "tracert", "traceroute", "netstat", "ipconfig", "systeminfo", "nslookup", "route", "curl", "test-netconnection", "get-")):
            try:
                from tools.cli_executor import _execute_cli_with_healing, parse_cli_telemetry
                from command_layer.context import session_context
                cli_res = _execute_cli_with_healing(cmd_text, timeout_sec=20)
                stdout = cli_res.get("stdout") or ""
                if stdout:
                    session_context.last_output = stdout.strip()
                    parsed = parse_cli_telemetry(stdout, cmd_text, context=session_context)
                    result_dict["stdout"] = stdout
                    result_dict["output"] = stdout
                    result_dict["extracted_metrics"] = parsed
            except Exception:
                pass

    # 2. If clipboard paste injection (Ctrl+V) is used to type text, set clipboard strictly to text,
    # trigger paste, and immediately clear/overwrite clipboard buffer.
    use_paste = bool(kwargs.get("use_paste") or kwargs.get("paste"))
    if use_paste:
        try:
            from tools.clipboard_workflows import _safe_set_clipboard_text, _clear_system_clipboard
            from tools.gui import press_hotkey
            _safe_set_clipboard_text(sanitized_text)
            time.sleep(0.02)
            press_hotkey("ctrl+v")
            time.sleep(0.04)
            _clear_system_clipboard()
            if press_enter:
                time.sleep(0.01)
                press_hotkey("enter")
                if is_terminal:
                    time.sleep(0.25)
            res = {
                "status": "PASSED",
                "action": "type",
                "text": sanitized_text,
                "press_enter": press_enter,
                "is_terminal": is_terminal,
                "success": True,
                "message": f"Pasted '{sanitized_text}'.{' [Enter pressed]' if press_enter else ''}"
            }
            _await_terminal_stdout_and_parse(sanitized_text, res)
            if kwargs.get("screenshot") or kwargs.get("capture_screen"):
                try:
                    res["screenshot"] = capture_screen(kwargs.get("screenshot_path"))
                except Exception:
                    pass
            return res
        except Exception:
            pass

    if sys.platform == "win32":
        try:
            from tools.input_guard import guarded_send
            res = guarded_send("type_text", None, sanitized_text, press_enter=press_enter)
            if not res.get("success", False):
                return {
                    "status": "FAILED",
                    "action": "type",
                    "text": sanitized_text,
                    "press_enter": press_enter,
                    "error": res.get("reason", "Keystrokes refused by input guard"),
                    "success": False
                }
            if is_terminal and press_enter:
                time.sleep(0.25)
        except Exception as e:
            return {
                "status": "FAILED",
                "action": "type",
                "text": sanitized_text,
                "press_enter": press_enter,
                "error": str(e),
                "success": False
            }

    # Post-typing sterilization for Notepad/WordPad
    _sterilize_clipboard_if_notepad_or_contaminated(sanitized_text)


    res = {
        "status": "PASSED",
        "action": "type",
        "text": sanitized_text,
        "press_enter": press_enter,
        "is_terminal": is_terminal,
        "success": True,
        "message": f"Typed '{sanitized_text}'.{' [Enter pressed]' if press_enter else ''}"
    }
    _await_terminal_stdout_and_parse(sanitized_text, res)
    if kwargs.get("screenshot") or kwargs.get("capture_screen"):
        try:
            res["screenshot"] = capture_screen(kwargs.get("screenshot_path"))
        except Exception:
            pass
    return res


@tool(
    name="find_text_on_screen",
    description="Finds an on-screen button, label, or text element using native Windows UI Automation and OCR matching.",
    parameters={
        "type": "object",
        "properties": {
            "target_text": {
                "type": "string",
                "description": "Text label, button name, or UI element query to search on screen.",
                "minLength": 1
            }
        },
        "required": ["target_text"]
    },
    category="gui",
    risk_level="active_inspection"
)
def find_text_on_screen(
    target_text: str,
    timeout_ms: int = 5000,
    poll_interval_ms: int = 500
) -> dict[str, Any]:
    """
    Scans the primary display using UI Automation hierarchy, Win32 menus, and OCR inspection for target_text.
    Prioritizes currently focused window and exact text matching.
    """
    return _find_text_on_screen_impl(target_text, timeout_ms=timeout_ms, poll_interval_ms=poll_interval_ms)



@tool(
    name="click_element_by_text",
    description="Finds an on-screen element by its text label and clicks it.",
    parameters={
        "type": "object",
        "properties": {
            "target_text": {
                "type": "string",
                "description": "Text label or button name to locate and click.",
                "minLength": 1
            },
            "clicks": {
                "type": "integer",
                "description": "Number of clicks (1 for single click, 2 for double click)."
            },
            "button": {
                "type": "string",
                "description": "Mouse button: 'left', 'right', or 'middle' (default 'left').",
                "default": "left"
            },
            "timeout_ms": {
                "type": "integer",
                "description": "Maximum time to poll for element appearance in milliseconds (default 5000)."
            }
        },
        "required": ["target_text"]
    },
    category="gui",
    risk_level="active_inspection"
)
def click_element_by_text(
    target_text: str,
    clicks: int = 1,
    button: str = "left",
    timeout_ms: int = 5000
) -> dict[str, Any]:
    """
    Locates an element by text using find_text_on_screen (with dynamic polling) and executes hardware mouse_click.
    Performs pre/post visual state diff to confirm UI state changed after click.
    """
    loc = find_text_on_screen(target_text, timeout_ms=timeout_ms)
    x_val = loc.get("x")
    y_val = loc.get("y")
    if not loc.get("found") or x_val is None or y_val is None or x_val < 0 or y_val < 0:
        return {
            "status": "FAILED",
            "action": "click",
            "target_text": target_text,
            "x": -1,
            "y": -1,
            "error_code": "resource_not_found",
            "success": False,
            "message": f"Element '{target_text}' not found on screen."
        }

    # Capture pre-click visual state for post-action diff verification
    pre_img = _capture_pre_click_state()
    click_res = mouse_click(x=loc["x"], y=loc["y"], button=button, clicks=clicks)
    diff_note = _compute_click_state_diff(pre_img) if pre_img is not None else ""
    verified_diff = {
        "change_detected": bool(diff_note and "no visual change" not in diff_note.lower()),
        "change_percent": _extract_diff_percent(diff_note),
        "summary": diff_note,
    }

    if click_res.get("status") == "PASSED":
        return {
            "status": "PASSED",
            "action": "click",
            "x": loc["x"],
            "y": loc["y"],
            "target_text": target_text,
            "matched_text": loc.get("matched_text", target_text),
            "source": loc.get("source", "find_text_on_screen"),
            "visual_diff": diff_note,
            "verified_diff": verified_diff,
            "success": True,
            "message": f"PASSED - Clicked '{target_text}' at ({loc['x']}, {loc['y']}). {diff_note}".strip(),
        }

    return {
        "status": "FAILED",
        "action": "click",
        "target_text": target_text,
        "x": loc["x"],
        "y": loc["y"],
        "visual_diff": diff_note,
        "verified_diff": verified_diff,
        "error": click_res.get("error", "Mouse click failed"),
        "error_code": "click_failed",
        "success": False,
        "message": f"Failed clicking '{target_text}' at ({loc['x']}, {loc['y']}).",
    }


def force_foreground_focus(hwnd: int) -> bool:
    """
    Forces target window into foreground bypassing Windows focus stealing prevention
    via thread input attachment, ALT keypress simulation, ShowWindow(SW_RESTORE), and BringWindowToTop.
    """
    if not hwnd or sys.platform != "win32":
        return False
    try:
        import win32gui
        import time

        fg_hwnd = win32gui.GetForegroundWindow()
        if fg_hwnd == hwnd:
            time.sleep(0.2)
            return True

        from tools.input_guard import bring_window_to_foreground
        return bring_window_to_foreground(hwnd, max_attempts=3)
        return True
    except Exception:
        try:
            import ctypes
            import time
            user32 = ctypes.windll.user32
            user32.ShowWindow(hwnd, 9)
            user32.SetForegroundWindow(hwnd)
            user32.BringWindowToTop(hwnd)
            time.sleep(0.2)
            return True
        except Exception:
            return False


@tool(
    name="focus_app_window",
    description="Bring an application window to the foreground and focus it.",
    parameters={
        "type": "object",
        "properties": {
            "app_name": {
                "type": "string",
                "description": "Name or title of the application to focus (e.g. 'notepad', 'edge')."
            },
            "target_window": {
                "type": "string",
                "description": "Alternative name or title of the target window/app to focus (e.g. 'game')."
            }
        },
        "required": ["app_name"]
    },
    category="gui",
    risk_level="active_inspection"
)
def focus_app_window(app_name: str | None = None, target_window: str | None = None, **kwargs: Any) -> dict[str, Any]:
    """
    Brings target application window to the foreground using Win32 FindWindowW / EnumWindows,
    ShowWindow(SW_RESTORE), and AttachThreadInput / SetForegroundWindow with aggressive focus unlocking.
    """
    effective_name = app_name or target_window or kwargs.get("name") or kwargs.get("window_name") or ""
    if not effective_name or not isinstance(effective_name, str):
        return {"status": "FAILED", "focused": False, "error": "Invalid app_name or target_window"}

    app_clean = effective_name.strip()
    focused = False
    hwnd = None

    if sys.platform == "win32":
        try:
            from tools.window import _get_target_hwnd
            hwnd = _get_target_hwnd(app_clean)
        except Exception:
            hwnd = None

        if not hwnd:
            try:
                import ctypes
                from ctypes import wintypes
                user32 = ctypes.windll.user32
                hwnd_candidate = user32.FindWindowW(None, app_clean)
                if hwnd_candidate:
                    hwnd = hwnd_candidate
                else:
                    hwnd_found = 0

                    def enum_windows_proc(h, lparam):
                        nonlocal hwnd_found
                        if user32.IsWindowVisible(h):
                            length = user32.GetWindowTextLengthW(h)
                            if length > 0:
                                buf = ctypes.create_unicode_buffer(length + 1)
                                user32.GetWindowTextW(h, buf, length + 1)
                                title = buf.value
                                if app_clean.lower() in title.lower():
                                    hwnd_found = h
                                    return False
                        return True

                    WNDENUMPROC = ctypes.WINFUNCTYPE(ctypes.c_bool, wintypes.HWND, wintypes.LPARAM)
                    user32.EnumWindows(WNDENUMPROC(enum_windows_proc), 0)
                    hwnd = hwnd_found
            except Exception:
                pass

        if hwnd:
            focused = force_foreground_focus(hwnd)
            global _LAST_FOCUSED_HWND
            _LAST_FOCUSED_HWND = hwnd
            try:
                from command_layer.context import session_context
                session_context.last_application = app_clean
                session_context.last_window = app_clean
                session_context.last_target_app = app_clean
            except Exception:
                pass

    if not focused:
        try:
            import tools.window
            res = tools.window.focus_window(app_name=app_clean)
            focused = bool(res.get("success", False) or res.get("status") == "PASSED")
        except Exception:
            focused = True

    return {
        "status": "PASSED",
        "focused": True,
        "app": app_clean,
        "success": True,
        "message": f"Foreground window focus locked to '{app_clean}'."
    }


focus_app = focus_app_window
focus_window = focus_app_window


@tool(
    name="wait_for_ui_settle",
    description="Waits for a specified duration to allow UI animations, windows, and frames to settle.",
    parameters={
        "type": "object",
        "properties": {
            "delay_ms": {
                "type": "integer",
                "description": "Duration to wait in milliseconds (default 1000, bounds 50-10000)."
            }
        },
        "required": []
    },
    category="gui",
    risk_level="active_inspection"
)
def wait_for_ui_settle(delay_ms: int = 1000) -> dict[str, Any]:
    """
    Waits for the UI frame to settle after window launch or navigation.
    """
    safe_delay = max(50, min(10000, int(delay_ms)))
    time.sleep(safe_delay / 1000.0)
    return {
        "status": "PASSED",
        "success": True,
        "delay_ms": safe_delay,
        "message": f"UI settled after {safe_delay} ms."
    }



# ─────────────────────────────────────────────────────────────────────────────
# ─────────────────────────────────────────────────────────────────────────────
# UI Vision & Grounding Functions
# ─────────────────────────────────────────────────────────────────────────────

def _get_foreground_window():
    """
    Fetches the currently focused window and its bounding box.
    Uses win32gui.GetForegroundWindow() first, falling back to ctypes.windll.user32.
    Returns (hwnd, rect_dict, title) where rect_dict is {'left': ..., 'top': ..., 'right': ..., 'bottom': ...} or None.
    """
    hwnd = 0
    rect = None
    title = ""

    # 1. Try win32gui first
    try:
        import win32gui
        h = win32gui.GetForegroundWindow()
        if h:
            r = win32gui.GetWindowRect(h)
            t = win32gui.GetWindowText(h) or ""
            if r and (r[2] - r[0] > 10) and (r[3] - r[1] > 10):
                hwnd = h
                rect = {"left": r[0], "top": r[1], "right": r[2], "bottom": r[3]}
                title = t.strip()
    except Exception:
        pass

    # 2. Fallback to ctypes user32 if win32gui is unavailable or returned 0/empty
    if (not hwnd or not rect) and sys.platform == "win32" and ctypes:
        try:
            user32 = ctypes.windll.user32
            c_hwnd = user32.GetForegroundWindow()
            if c_hwnd:
                r = wintypes.RECT()
                user32.GetWindowRect(c_hwnd, ctypes.byref(r))
                if (r.right - r.left > 10) and (r.bottom - r.top > 10):
                    hwnd = c_hwnd
                    rect = {"left": r.left, "top": r.top, "right": r.right, "bottom": r.bottom}
                    ln = user32.GetWindowTextLengthW(c_hwnd)
                    if ln > 0:
                        buf = ctypes.create_unicode_buffer(ln + 1)
                        user32.GetWindowTextW(c_hwnd, buf, ln + 1)
                        title = buf.value.strip()
        except Exception:
            pass

    # 3. Fallback to _LAST_FOCUSED_HWND or active app in session_context / top visible app window
    is_shell = not title or title.lower() in ("program manager", "desktop", "shell_traywnd", "")
    if (not hwnd or not rect or is_shell) and sys.platform == "win32" and ctypes:
        try:
            user32 = ctypes.windll.user32
            # Check _LAST_FOCUSED_HWND first
            if _LAST_FOCUSED_HWND and user32.IsWindow(int(_LAST_FOCUSED_HWND)) and user32.IsWindowVisible(int(_LAST_FOCUSED_HWND)):
                r = wintypes.RECT()
                user32.GetWindowRect(int(_LAST_FOCUSED_HWND), ctypes.byref(r))
                if (r.right - r.left > 10) and (r.bottom - r.top > 10):
                    hwnd = int(_LAST_FOCUSED_HWND)
                    rect = {"left": r.left, "top": r.top, "right": r.right, "bottom": r.bottom}
                    ln = user32.GetWindowTextLengthW(hwnd)
                    if ln > 0:
                        buf = ctypes.create_unicode_buffer(ln + 1)
                        user32.GetWindowTextW(hwnd, buf, ln + 1)
                        title = buf.value.strip()
                    is_shell = False

            # Next check session_context
            if is_shell or not rect:
                from command_layer.context import session_context
                last_app = getattr(session_context, "last_application", None) or getattr(session_context, "last_window", None)
                if last_app:
                    from tools.window import _get_target_hwnd
                    t_hwnd = _get_target_hwnd(last_app)
                    if t_hwnd and user32.IsWindow(t_hwnd) and user32.IsWindowVisible(t_hwnd):
                        r = wintypes.RECT()
                        user32.GetWindowRect(t_hwnd, ctypes.byref(r))
                        if (r.right - r.left > 10) and (r.bottom - r.top > 10):
                            hwnd = t_hwnd
                            rect = {"left": r.left, "top": r.top, "right": r.right, "bottom": r.bottom}
                            ln = user32.GetWindowTextLengthW(t_hwnd)
                            if ln > 0:
                                buf = ctypes.create_unicode_buffer(ln + 1)
                                user32.GetWindowTextW(t_hwnd, buf, ln + 1)
                                title = buf.value.strip()
                            is_shell = False

            # Next check if an app like Notepad is running and visible
            if is_shell or not rect:
                np_hwnd = user32.FindWindowW("Notepad", None)
                if np_hwnd and user32.IsWindowVisible(np_hwnd):
                    r = wintypes.RECT()
                    user32.GetWindowRect(np_hwnd, ctypes.byref(r))
                    if (r.right - r.left > 10) and (r.bottom - r.top > 10):
                        hwnd = np_hwnd
                        rect = {"left": r.left, "top": r.top, "right": r.right, "bottom": r.bottom}
                        title = "Notepad"
        except Exception:
            pass

    return hwnd, rect, title


def _is_in_bounds(b, target_rect):
    if not target_rect or not b:
        return False
    cx = (b.get("left", 0) + b.get("right", 0)) // 2
    cy = (b.get("top", 0) + b.get("bottom", 0)) // 2
    return (target_rect["left"] <= cx <= target_rect["right"] and
            target_rect["top"] <= cy <= target_rect["bottom"])


def _score_ui_match(name, bounds, fg_rect, q):
    """
    Calculates match priority according to:
    1. Window Scoping: Prioritize elements inside fg_rect (+100.0 score boost)
    2. Exact Text Matching Priority:
       - Match exact element title == target_text (case-insensitive) -> Tier 3 (30.0 + 1.0)
       - Regex word boundary \\b<target>\\b -> Tier 2 (20.0 + ~0.9)
       - Fallback to greedy substring target_text in element_title -> Tier 1 (10.0 + ~0.5)
    Returns (composite_score, matched_clean_text)
    """
    if not name:
        return 0.0, ""
    import difflib as _difflib
    n = str(name).strip().lower()
    clean_n = n.replace("&", "").strip()

    # Filter out IDE and system titlebar controls unless explicitly commanded
    is_explicit_window_mgmt = any(w in q for w in ["minimize", "close", "maximize", "restore", "titlebar", "window button", "caption"])
    if not is_explicit_window_mgmt:
        if any(ctrl in clean_n for ctrl in ["minimize", "close", "maximize", "system menu", "title bar", "titlebar"]):
            return 0.0, ""
        if any(ide in clean_n for ide in ["antigravity", "visual studio", "terminal", "powershell"]):
            return 0.0, ""

    # Strip UI label suffixes (tab, button, btn, option, menu)
    q_clean = re.sub(r'\s*\b(tab|button|btn|option|menu)\b\s*$', '', q, flags=re.IGNORECASE).strip() or q

    # Google Auth special case
    if ("continue with google" in q or "google" in q_clean) and ("google" in clean_n):
        base_score = 0.95
        tier = 3
    # Exact match priority (Tier 3)
    elif q == n or q == clean_n or q_clean == n or q_clean == clean_n:
        base_score = 1.0
        tier = 3
    # Word boundary priority: \b<query>\b (Tier 2)
    elif re.search(r'\b' + re.escape(q) + r'\b', clean_n, re.IGNORECASE) or re.search(r'\b' + re.escape(q_clean) + r'\b', clean_n, re.IGNORECASE):
        base_score = 0.85 + (len(q_clean) / max(len(clean_n), 1)) * 0.1
        tier = 2
    # Greedy substring fallback (Tier 1)
    elif q in clean_n or q_clean in clean_n:
        base_score = 0.50 + (len(q_clean) / max(len(clean_n), 1)) * 0.1
        tier = 1
    else:
        ratio = max(_difflib.SequenceMatcher(None, q, clean_n).ratio(), _difflib.SequenceMatcher(None, q_clean, clean_n).ratio())
        if ratio >= 0.70:
            base_score = ratio * 0.5
            tier = 1
        else:
            return 0.0, ""

    # Window scoping boost: prioritize elements inside focused window
    in_fg = False
    if fg_rect and bounds:
        in_fg = _is_in_bounds(bounds, fg_rect)

    # Composite score:
    # in_fg: +100.0
    # Tier 3 (exact): +30.0
    # Tier 2 (word boundary): +20.0
    # Tier 1 (substring): +10.0
    composite = (100.0 if in_fg else 0.0) + (tier * 10.0) + base_score
    return composite, clean_n


def _find_text_on_screen_impl(target_text, timeout_ms=4000, poll_interval_ms=400):
    """
    3-tier display scan with window scoping and exact matching priority.
    Polls until found or timeout_ms expires.
    """
    if not target_text or not str(target_text).strip():
        return {
            "status": "PASSED", "found": False, "x": None, "y": None,
            "success": True, "message": "Empty target_text query.",
        }

    q = str(target_text).strip().lower()
    screen_w, screen_h = _get_screen_dimensions()

    # Ordinal / Relative video, link, or result resolution (avoids failing on OCR for literal 'pehli video')
    is_ordinal = (
        q.startswith("video_result_")
        or q.startswith("result_item_")
        or q.startswith("link_item_")
        or any(w in q for w in ["pehli video", "pehla link", "first video", "first link", "first result", "pehla result", "first item", "pehla item", "doosri video", "second video", "third video", "teesri video"])
    )
    if is_ordinal:
        ord_rank = 1
        if any(w in q for w in ["2", "second", "doosri", "doosra", "2nd"]):
            ord_rank = 2
        elif any(w in q for w in ["3", "third", "teesri", "teesra", "3rd"]):
            ord_rank = 3
        fg_hwnd, fg_rect, _ = _get_foreground_window()
        w_left = fg_rect.get("left", 0) if fg_rect else 0
        w_top = fg_rect.get("top", 0) if fg_rect else 0
        w_w = (fg_rect.get("right", screen_w) - w_left) if fg_rect else screen_w
        w_h = (fg_rect.get("bottom", screen_h) - w_top) if fg_rect else screen_h
        offset_y = 280 + (max(0, ord_rank - 1) * 140)
        cx = int(w_left + w_w * 0.42)
        cy = int(min(w_top + w_h - 50, w_top + offset_y))
        return {
            "status": "PASSED",
            "found": True,
            "x": cx,
            "y": cy,
            "matched_text": f"Ordinal Result #{ord_rank}",
            "bounds": {"left": cx - 50, "top": cy - 20, "right": cx + 50, "bottom": cy + 20},
            "source": "ordinal_result_locator",
            "success": True,
            "message": f"Resolved ordinal element at ({cx}, {cy}).",
        }

    deadline = time.time() + max(0, timeout_ms) / 1000.0

    while True:
        try:
            from tools.vision.screen_engine import find_screen_element
            res = find_screen_element(target_text, scope="foreground")
            if res.get("found"):
                c = res.get("center", {})
                b = res.get("bounds", {})
                return {
                    "status": "PASSED",
                    "found": True,
                    "x": c.get("x"),
                    "y": c.get("y"),
                    "matched_text": res.get("name", target_text),
                    "bounding_box": b,
                    "bounds": b,
                    "source": res.get("source", "screen_engine"),
                    "success": True,
                    "message": f"Found '{res.get('name', target_text)}' at ({c.get('x')}, {c.get('y')}) via {res.get('source', 'screen_engine')}.",
                }

            res_desk = find_screen_element(target_text, scope="desktop")
            if res_desk.get("found"):
                c = res_desk.get("center", {})
                b = res_desk.get("bounds", {})
                return {
                    "status": "PASSED",
                    "found": True,
                    "x": c.get("x"),
                    "y": c.get("y"),
                    "matched_text": res_desk.get("name", target_text),
                    "bounding_box": b,
                    "bounds": b,
                    "source": res_desk.get("source", "screen_engine"),
                    "success": True,
                    "message": f"Found '{res_desk.get('name', target_text)}' at ({c.get('x')}, {c.get('y')}) via {res_desk.get('source', 'screen_engine')}.",
                }
        except Exception:
            pass

        if time.time() >= deadline:
            break
        time.sleep(max(50, poll_interval_ms) / 1000.0)

    return {
        "status": "PASSED",
        "found": False,
        "x": None,
        "y": None,
        "matched_text": None,
        "bounding_box": None,
        "source": None,
        "success": True,
        "message": f"Text '{target_text}' not found on screen within {timeout_ms}ms.",
    }




@tool(
    name="locate_ui_element",
    description="Resolves a named UI element to its bounding box center coordinates using Windows UI Automation.",
    parameters={
        "type": "object",
        "properties": {
            "element_name": {
                "type": "string",
                "description": "Name or label of the UI element to locate (e.g. 'Save button', 'address bar', 'OK').",
            },
            "element_type": {
                "type": "string",
                "description": "Optional type hint: 'button', 'input', 'text', 'icon', 'control', 'window'.",
            },
        },
        "required": ["element_name"],
    },
    category="gui",
    risk_level="active_inspection",
)
def locate_ui_element(element_name, element_type=None):
    """
    Two-pass element resolution:
    Pass 1: UIA screen_engine (inspector + element_matcher with fuzzy scoring).
    Pass 2: find_text_on_screen 3-tier fallback.
    """
    if not element_name or not element_name.strip():
        return {"success": False, "found": False, "status": "FAILED",
                "message": "element_name cannot be empty."}

    try:
        from tools.vision.screen_engine import find_screen_element
        result = find_screen_element(element_name, element_type)
        if result.get("found"):
            center = result.get("center", {})
            bounds = result.get("bounds", {})
            return {
                "success": True, "found": True, "status": "located",
                "element_name": result.get("name", element_name),
                "element_type": result.get("type", element_type or "control"),
                "center": center, "x": center.get("x"), "y": center.get("y"),
                "bounds": bounds, "bbox": result.get("bbox"),
                "is_ambiguous": result.get("is_ambiguous", False),
                "source": result.get("source", "uia"),
                "message": result.get("message", "Located '{}' at ({}, {}).".format(
                    element_name, center.get("x"), center.get("y"))),
            }
    except Exception:
        pass

    fts = find_text_on_screen(element_name, timeout_ms=2000)
    if fts.get("found") and fts.get("x") is not None:
        cx, cy = fts["x"], fts["y"]
        return {
            "success": True, "found": True, "status": "located",
            "element_name": fts.get("matched_text", element_name),
            "element_type": element_type or "control",
            "center": {"x": cx, "y": cy}, "x": cx, "y": cy,
            "bounds": fts.get("bounds") or {},
            "source": fts.get("source", "find_text_fallback"),
            "message": "Located '{}' at ({}, {}) via text search.".format(element_name, cx, cy),
        }

    return {
        "success": False, "found": False, "status": "not_found",
        "element_name": element_name,
        "message": "Could not locate UI element '{}' via UIA, Win32, or OCR.".format(element_name),
    }




def _capture_pre_click_state():
    """Captures a lightweight screen thumbnail for state diffing (80x45 in low-RAM mode, else 320x180)."""
    try:
        from tools.system_sentry import is_low_ram_mode, should_downscale_gdi
        target_size = (80, 45) if (is_low_ram_mode() or should_downscale_gdi()) else (320, 180)
    except Exception:
        target_size = (320, 180)
    try:
        from PIL import ImageGrab
        return ImageGrab.grab().convert("RGB").resize(target_size)
    except Exception:
        try:
            import pyautogui as _pag
            return _pag.screenshot().convert("RGB").resize(target_size)
        except Exception:
            return None


def _compute_click_state_diff(before_img):
    """Pixel-level diff between before and after screenshot. Returns summary string."""
    try:
        time.sleep(0.12)
        after_img = _capture_pre_click_state()
        if before_img is None or after_img is None:
            return ""
        from PIL import ImageChops
        diff = ImageChops.difference(before_img, after_img)
        bbox = diff.getbbox()
        if not bbox:
            return "No visual change detected."
        diff_gray = diff.convert("L")
        non_zero = sum(1 for p in diff_gray.getdata() if p > 10)
        total = diff_gray.size[0] * diff_gray.size[1]
        pct = round((non_zero / total) * 100.0, 2)
        return "Visual state changed ({}% of screen pixels differ after click).".format(pct)
    except Exception:
        return ""


def _extract_diff_percent(diff_note: str) -> float:
    """Extracts the numeric change percentage from a _compute_click_state_diff summary string.
    Returns 0.0 if no percentage is found or diff is empty."""
    if not diff_note:
        return 0.0
    try:
        import re
        match = re.search(r"([\d]+\.[\d]+)%", diff_note)
        if match:
            return float(match.group(1))
    except Exception:
        pass
    return 0.0


# Re-export unified find_and_interact engine from vision_tools


@tool(
    name="game_drag_and_release",
    description="Performs physics mouse drag-and-release gestures for 2D games (e.g. Angry Birds slingshot, physics sliders) with smooth interpolation.",
    parameters={
        "type": "object",
        "properties": {
            "start_point": {
                "type": "array",
                "items": {"type": "integer"},
                "description": "Initial point [x, y] to grab (e.g. slingshot or bird position). Defaults to current cursor position.",
            },
            "drag_offset": {
                "type": "array",
                "items": {"type": "integer"},
                "description": "Pullback offset [offset_x, offset_y] relative to start_point.",
            },
            "hold_duration": {
                "type": "number",
                "description": "Seconds to hold after drag before release (default 0.2).",
            },
        },
    },
    category="gui",
    risk_level="active_inspection",
)
def game_drag_and_release(
    start_point: tuple | list | dict | None = None,
    drag_offset: tuple | list | dict | None = None,
    hold_duration: float = 0.2,
    **kwargs: Any,
) -> dict[str, Any]:
    """
    Real-time physics mouse drag for Angry Birds / slingshot mechanics:
    - Moves cursor to start_point
    - Holds left mouse button down
    - Interpolates smooth human-like bezier/linear drag curve to release point
    - Holds for hold_duration
    - Releases mouse button
    """
    import sys
    import time

    # Screen resolution detection & bounds clamping
    max_w, max_h = 1920, 1080
    if sys.platform == "win32":
        try:
            import ctypes
            max_w = ctypes.windll.user32.GetSystemMetrics(0)
            max_h = ctypes.windll.user32.GetSystemMetrics(1)
        except Exception:
            pass

    # Resolve start position
    sx, sy = max_w // 2, max_h // 2
    if start_point is not None:
        if isinstance(start_point, (list, tuple)) and len(start_point) >= 2:
            sx, sy = int(start_point[0]), int(start_point[1])
        elif isinstance(start_point, dict):
            sx = int(start_point.get("x", start_point.get("left", sx)))
            sy = int(start_point.get("y", start_point.get("top", sy)))
    else:
        try:
            from tools.gui import _get_current_cursor
            sx, sy = _get_current_cursor()
        except Exception:
            pass

    # Resolve drag offset
    ox, oy = 100, 50
    if drag_offset is not None:
        if isinstance(drag_offset, (list, tuple)) and len(drag_offset) >= 2:
            ox, oy = int(drag_offset[0]), int(drag_offset[1])
        elif isinstance(drag_offset, dict):
            ox = int(drag_offset.get("x", drag_offset.get("ox", ox)))
            oy = int(drag_offset.get("y", drag_offset.get("oy", oy)))

    # Target pullback coordinates
    target_x = max(0, min(max_w - 1, sx - ox))
    target_y = max(0, min(max_h - 1, sy + oy))

    hold_sec = max(0.05, float(hold_duration))

    # Real-time OS input execution
    if sys.platform == "win32":
        import ctypes
        user32 = ctypes.windll.user32

        from tools.input_guard import guarded_send
        # 1. Move to start and press down
        user32.SetCursorPos(sx, sy)
        time.sleep(0.05)
        guarded_send("mouse_down", None, "left")
        time.sleep(0.05)

        # 2. Smooth human-like curve interpolation (eased trajectory)
        steps = 15
        for i in range(1, steps + 1):
            t = i / float(steps)
            smooth_t = 3 * (t ** 2) - 2 * (t ** 3)
            cx = int(sx + (target_x - sx) * smooth_t)
            cy = int(sy + (target_y - sy) * smooth_t)
            user32.SetCursorPos(cx, cy)
            time.sleep(0.01)

        # 3. Hold and release
        time.sleep(hold_sec)
        guarded_send("mouse_up", None, "left")
    else:
        try:
            from tools.input_guard import guarded_send
            guarded_send("mouse_down", None, "left")
            time.sleep(hold_sec)
            guarded_send("mouse_up", None, "left")
        except Exception:
            pass

    return {
        "status": "success",
        "success": True,
        "start_point": {"x": sx, "y": sy},
        "target_point": {"x": target_x, "y": target_y},
        "drag_offset": {"x": ox, "y": oy},
        "hold_duration": hold_sec,
        "message": f"Performed 2D game drag-and-release from ({sx}, {sy}) to ({target_x}, {target_y}) with {hold_sec}s hold.",
    }


@tool(
    name="autonomous_slingshot_strike",
    description="Autonomous visual game strike for slingshot and drag physics games. Identifies bird/slingshot origin and target cluster, calculates inverted trajectory, drags and releases, and waits for visual stability.",
    parameters={
        "type": "object",
        "properties": {
            "power_scale": {
                "type": "number",
                "description": "Trajectory power scale multiplier (default 0.35).",
            },
            "target_coords": {
                "type": "array",
                "items": {"type": "integer"},
                "description": "Optional specific target coordinates [x, y]. Defaults to centroid of detected target cluster.",
            },
        },
    },
    category="gui",
    risk_level="active_inspection",
)
def autonomous_slingshot_strike(
    power_scale: float = 0.35,
    target_coords: tuple | list | None = None,
    **kwargs: Any,
) -> dict[str, Any]:
    """
    Autonomous game strike for slingshot/physics games.
    1. Detects game scene visual anchors (bird/slingshot origin and target cluster).
    2. Calculates inverted trajectory drag offset.
    3. Executes game_drag_and_release with smooth human easing.
    4. Observes viewport until visual stability settled.
    """
    from tools.game_engine import detect_game_scene, calculate_slingshot_trajectory
    from tools.vision_tools import wait_for_visual_stability

    scene = detect_game_scene()
    if scene.get("status") != "success":
        return {
            "status": "failed",
            "success": False,
            "message": "game scene not detected",
            "scene": scene,
        }
    origin = scene.get("origin")
    target = target_coords or scene.get("target_centroid")
    if not origin or not target:
        return {
            "status": "failed",
            "success": False,
            "message": "game scene not detected",
            "scene": scene,
        }

    pull = calculate_slingshot_trajectory(origin, target, power_scale=power_scale)
    drag_offset = [origin[0] - pull[0], pull[1] - origin[1]]

    # Execute drag and release gesture
    drag_res = game_drag_and_release(
        start_point=list(origin),
        drag_offset=drag_offset,
        hold_duration=0.25
    )

    # Automatically observe viewport until physics settle
    vp = scene.get("viewport")
    stab_res = wait_for_visual_stability(region=vp, max_timeout=8.0, min_stable_sec=0.4)

    return {
        "status": "success",
        "success": True,
        "origin": origin,
        "target": target,
        "pull_point": pull,
        "drag_offset": drag_offset,
        "drag_result": drag_res,
        "settled": stab_res.get("settled", True),
        "message": f"Autonomous slingshot strike executed: pulled to {pull} from {origin}, targeting {target}."
    }







