"""
Autonomous Game Physics & Trajectory Engine for Canvas, DirectX, and Web-based Games.
Detects game objects (bird, slingshot, target structures) via zero-latency GDI frame sampling
and computes launch vectors, parabolic release trajectories, and optimal release coords.
"""
from __future__ import annotations
import sys
import math
from typing import Any, Tuple

from tools.registry import tool
from tools.vision_tools import _capture_viewport_thumbnail


@tool(
    name="detect_game_scene",
    description="Grabs the viewport of the active game/canvas window and detects visual game anchors (bird/slingshot origin and target cluster centroids) using fast zero-latency pixel clustering.",
    parameters={
        "type": "object",
        "properties": {
            "hwnd": {
                "type": "integer",
                "description": "Optional window handle of the game window. If omitted, uses active foreground window.",
            },
        },
    },
    category="observation",
    risk_level="read_only",
)
def detect_game_scene(
    hwnd: int | None = None,
    buffer: bytes | None = None,
    window_title: str | None = None,
) -> dict[str, Any]:
    """
    Grabs the client viewport of the active game/canvas window.
    Scans for key visual anchors via fast color/luminance clustering using per-game profile if matched, else generic.
    Returns status 'success' only with real detections (origin & targets).
    Returns status 'not_detected' with no fake coordinates when anchors are missing.
    """
    from tools.game_profiles import load_game_profile, get_generic_profile

    # 1. Resolve window and viewport
    scr_w, scr_h = 1920, 1080
    rx, ry, rw, rh = 0, 0, scr_w, scr_h
    detected_title = window_title or ""

    if sys.platform == "win32":
        try:
            import win32gui
            import ctypes
            scr_w = ctypes.windll.user32.GetSystemMetrics(0)
            scr_h = ctypes.windll.user32.GetSystemMetrics(1)
            target_hwnd = hwnd or win32gui.GetForegroundWindow()
            if target_hwnd and win32gui.IsWindow(target_hwnd):
                cl_left, cl_top, cl_right, cl_bottom = win32gui.GetClientRect(target_hwnd)
                pt_left, pt_top = win32gui.ClientToScreen(target_hwnd, (cl_left, cl_top))
                w = cl_right - cl_left
                h = cl_bottom - cl_top
                if w > 100 and h > 100:
                    rx, ry, rw, rh = pt_left, pt_top, w, h
                if not detected_title:
                    detected_title = win32gui.GetWindowText(target_hwnd)
        except Exception:
            rx, ry, rw, rh = 0, 0, scr_w, scr_h

    # 2. Select profile (game-specific or generic)
    profile = load_game_profile(detected_title) if detected_title else None
    if not profile:
        profile = get_generic_profile()

    zones = profile.get("zones", {})
    origin_zone = zones.get("origin", [0.0, 0.0, 0.45, 1.0])
    target_zone = zones.get("target", [0.35, 0.0, 0.65, 1.0])
    colors = profile.get("colors", {})
    origin_rules = colors.get("origin", [])
    target_rules = colors.get("target", [])
    hud_regions = profile.get("hud_regions", [])

    # Standardize rule lists format
    if origin_rules and isinstance(origin_rules[0][0], (int, float)):
        origin_rules = [origin_rules]
    if target_rules and isinstance(target_rules[0][0], (int, float)):
        target_rules = [target_rules]

    # 3. Fast GDI thumbnail capture (memory efficient, zero disk I/O, < 50 KB buffer)
    thumb_w, thumb_h = 160, 90
    if buffer is not None and len(buffer) == thumb_w * thumb_h * 3:
        buf = buffer
    else:
        buf = _capture_viewport_thumbnail([rx, ry, rw, rh], thumb_w=thumb_w, thumb_h=thumb_h)

    bird_coords = []
    target_coords = []

    def in_box(px: int, py: int, box: list[float]) -> bool:
        bx, by, bw, bh = box
        return (int(bx * thumb_w) <= px <= int((bx + bw) * thumb_w) and
                int(by * thumb_h) <= py <= int((by + bh) * thumb_h))

    def matches_rules(r_val: int, g_val: int, b_val: int, rules: list) -> bool:
        for rule in rules:
            [rmin, rmax], [gmin, gmax], [bmin, bmax] = rule
            if rmin <= r_val <= rmax and gmin <= g_val <= gmax and bmin <= b_val <= bmax:
                return True
        return False

    if buf and len(buf) == thumb_w * thumb_h * 3:
        for y in range(thumb_h):
            for x in range(thumb_w):
                # Skip HUD exclusion regions
                if any(in_box(x, y, hud) for hud in hud_regions):
                    continue

                idx = (y * thumb_w + x) * 3
                b = buf[idx]
                g = buf[idx + 1]
                r = buf[idx + 2]

                # Check origin candidate
                if in_box(x, y, origin_zone):
                    if matches_rules(r, g, b, origin_rules):
                        bird_coords.append((x, y))

                # Check target candidate
                if in_box(x, y, target_zone):
                    if matches_rules(r, g, b, target_rules):
                        target_coords.append((x, y))

    # 4. Honesty Gate Evaluation
    MIN_PIXELS = 4
    has_origin = len(bird_coords) >= MIN_PIXELS
    has_targets = len(target_coords) >= MIN_PIXELS

    pixel_counts = {
        "origin_pixels": len(bird_coords),
        "target_pixels": len(target_coords),
    }

    if has_origin and has_targets:
        avg_bx = sum(pt[0] for pt in bird_coords) / len(bird_coords)
        avg_by = sum(pt[1] for pt in bird_coords) / len(bird_coords)
        ox = int(rx + (avg_bx * rw) / thumb_w)
        oy = int(ry + (avg_by * rh) / thumb_h)

        avg_tx = sum(pt[0] for pt in target_coords) / len(target_coords)
        avg_ty = sum(pt[1] for pt in target_coords) / len(target_coords)
        cx = int(rx + (avg_tx * rw) / thumb_w)
        cy = int(ry + (avg_ty * rh) / thumb_h)

        targets = []
        step = max(1, len(target_coords) // 5)
        for i in range(0, len(target_coords), step):
            tx_pt, ty_pt = target_coords[i]
            targets.append((int(rx + (tx_pt * rw) / thumb_w), int(ry + (ty_pt * rh) / thumb_h)))
        if not targets:
            targets = [(cx, cy)]

        confidence = round(min(1.0, (len(bird_coords) + len(target_coords)) / 40.0), 3)

        return {
            "status": "success",
            "detected_origin": True,
            "detected_targets": True,
            "confidence": confidence,
            "origin": (ox, oy),
            "targets": targets,
            "target_centroid": (cx, cy),
            "viewport": (rx, ry, rw, rh),
            "thumbnail_size": [thumb_w, thumb_h],
            "pixel_counts": pixel_counts,
            "profile_used": profile.get("name", "generic"),
        }

    # Not detected: Honest report with zero fake coordinates
    return {
        "status": "not_detected",
        "detected_origin": has_origin,
        "detected_targets": has_targets,
        "confidence": 0.0,
        "origin": None,
        "targets": [],
        "target_centroid": None,
        "viewport": (rx, ry, rw, rh),
        "thumbnail_size": [thumb_w, thumb_h],
        "pixel_counts": pixel_counts,
        "message": "game scene not detected",
        "profile_used": profile.get("name", "generic"),
    }


def calculate_slingshot_trajectory(origin: tuple[int, int], target: tuple[int, int], power_scale: float = 0.35) -> tuple[int, int]:
    """
    Calculates the inverted drag vector for slingshot release physics.
      dx = target[0] - origin[0]
      dy = target[1] - origin[1]
      pull_x = int(origin[0] - min(120, max(40, dx * power_scale)))
      pull_y = int(origin[1] + min(80, max(20, dy * power_scale * 0.5)))
    Returns release coordinates (pull_x, pull_y).
    """
    dx = target[0] - origin[0]
    dy = target[1] - origin[1]

    # Inverted drag vector: pull backward away from the target
    effective_dx = abs(dx) if dx != 0 else 100
    pull_x = int(origin[0] - min(120, max(40, effective_dx * power_scale)))
    pull_y = int(origin[1] + min(80, max(20, dy * power_scale * 0.5)))

    return (pull_x, pull_y)

import time
import sqlite3
import random
import ctypes
from ctypes import wintypes
import win32gui
from command_layer.context import session_context
from tools.gui_controller import game_drag_and_release

user32 = ctypes.windll.user32
gdi32 = ctypes.windll.gdi32

class ContinuousGameCognitiveEngine:
    def __init__(self, db_path: str = "agent_game_memory.db"):
        self.db_path = db_path
        self._init_memory_db()

    def _init_memory_db(self):
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS trial_memory (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    game_title TEXT,
                    origin_x INTEGER, origin_y INTEGER,
                    pull_dx INTEGER, pull_dy INTEGER,
                    angle REAL, power REAL,
                    visual_reward REAL,
                    outcome TEXT,
                    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
                )
            """)
            conn.commit()

    def request_user_observation_window(self, needed_seconds: int = 5) -> bool:
        print(f"\n[AGENT_OBSERVER] Observing environment for {needed_seconds} seconds. Do not touch mouse/keyboard.")
        session_context.observation_allowed_until = time.time() + needed_seconds
        time.sleep(needed_seconds)
        print("[AGENT_OBSERVER] Observation complete. Autonomous loop engaged.\n")
        return True

    def capture_viewport_diff(self, hwnd: int) -> float:
        rect = win32gui.GetClientRect(hwnd)
        w, h = rect[2] - rect[0], rect[3] - rect[1]
        if w <= 0 or h <= 0:
            return 0.0

        hdc_screen = user32.GetDC(hwnd)
        hdc_mem = gdi32.CreateCompatibleDC(hdc_screen)
        dw, dh = 120, 68
        hbmp = gdi32.CreateCompatibleBitmap(hdc_screen, dw, dh)
        old_bmp = gdi32.SelectObject(hdc_mem, hbmp)
        gdi32.SetStretchBltMode(hdc_mem, 3)
        gdi32.StretchBlt(hdc_mem, 0, 0, dw, dh, hdc_screen, 0, 0, w, h, 0x00CC0020)

        buf_size = dw * dh * 3
        buf = ctypes.create_string_buffer(buf_size)
        
        class BITMAPINFOHEADER(ctypes.Structure):
            _fields_ = [('biSize', wintypes.DWORD), ('biWidth', wintypes.LONG), ('biHeight', wintypes.LONG),
                        ('biPlanes', wintypes.WORD), ('biBitCount', wintypes.WORD), ('biCompression', wintypes.DWORD),
                        ('biSizeImage', wintypes.DWORD), ('biXPelsPerMeter', wintypes.LONG),
                        ('biYPelsPerMeter', wintypes.LONG), ('biClrUsed', wintypes.DWORD), ('biClrImportant', wintypes.DWORD)]

        bmi = BITMAPINFOHEADER()
        bmi.biSize = ctypes.sizeof(BITMAPINFOHEADER)
        bmi.biWidth = dw
        bmi.biHeight = -dh
        bmi.biPlanes = 1
        bmi.biBitCount = 24
        gdi32.GetDIBits(hdc_mem, hbmp, 0, dh, buf, ctypes.byref(bmi), 0)

        gdi32.SelectObject(hdc_mem, old_bmp)
        gdi32.DeleteObject(hbmp)
        gdi32.DeleteDC(hdc_mem)
        user32.ReleaseDC(hwnd, hdc_screen)
        raw = buf.raw
        return sum(raw[i] for i in range(0, len(raw), 15)) / (len(raw) / 15.0)

    def _select_next_action(self, trial: int) -> Tuple[int, int, float, float]:
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT pull_dx, pull_dy, angle, power FROM trial_memory WHERE outcome = 'HIT' ORDER BY visual_reward DESC LIMIT 1")
            row = cursor.fetchone()
            
        epsilon = max(0.15, 0.7 - (trial * 0.05))
        if row and random.random() > epsilon:
            best_dx, best_dy, best_ang, best_pwr = row
            dx = int(best_dx * random.uniform(0.95, 1.05))
            dy = int(best_dy * random.uniform(0.95, 1.05))
            return dx, dy, best_ang, best_pwr
        else:
            angle = random.uniform(30.0, 60.0)
            power = random.uniform(0.4, 0.9)
            rad = math.radians(angle)
            dx = int(120 * power * math.cos(rad))
            dy = int(120 * power * math.sin(rad))
            return dx, dy, angle, power

    def _save_trial_experience(self, ox, oy, dx, dy, ang, pwr, rwd, out):
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("""
                INSERT INTO trial_memory (game_title, origin_x, origin_y, pull_dx, pull_dy, angle, power, visual_reward, outcome)
                VALUES ('AngryBirds_Canvas', ?, ?, ?, ?, ?, ?, ?, ?)
            """, (ox, oy, dx, dy, ang, pwr, rwd, out))
            conn.commit()

    def continuous_learning_loop(self, hwnd: int, max_trials: int = 15) -> dict:
        self.request_user_observation_window(needed_seconds=5)
        trial = 1
        while trial <= max_trials:
            if sys.platform == "win32" and not win32gui.IsWindow(hwnd):
                return {
                    "status": "failed",
                    "message": f"game window {hwnd} not found or closed",
                    "trials_completed": trial - 1,
                }
            scene = detect_game_scene(hwnd)
            if scene.get("status") != "success":
                return {
                    "status": "failed",
                    "message": "game scene not detected",
                    "trials_completed": trial - 1,
                    "scene": scene,
                }
            origin_x, origin_y = scene["origin"]
            pull_dx, pull_dy, angle, power = self._select_next_action(trial)
            base_state = self.capture_viewport_diff(hwnd)
            game_drag_and_release((origin_x, origin_y), (pull_dx, pull_dy), hold_duration=0.25)
            time.sleep(1.0)
            current_state = self.capture_viewport_diff(hwnd)
            visual_reward = abs(current_state - base_state)
            outcome = "HIT" if visual_reward > 4.0 else "MISS"
            self._save_trial_experience(origin_x, origin_y, pull_dx, pull_dy, angle, power, visual_reward, outcome)
            trial += 1
            time.sleep(1.5)
        return {"status": "PASSED", "message": "Completed autonomous learning loop trials.", "trials_completed": trial - 1}

@tool(
    name="engage_continuous_game_loop",
    description="Engages continuous learning and trial loop for autonomous game playing with visual diff and trial memory.",
    parameters={
        "type": "object",
        "properties": {
            "game_hint": {
                "type": "string",
                "description": "Optional hint or title of the game window/canvas to focus and play.",
            },
        },
    },
    category="automation",
    risk_level="state_changing",
)
def engage_continuous_game_loop(game_hint: str = "") -> dict:
    hwnd = win32gui.GetForegroundWindow() if sys.platform == "win32" else 0
    engine = ContinuousGameCognitiveEngine()
    return engine.continuous_learning_loop(hwnd, max_trials=10)
