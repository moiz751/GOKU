import time
import math
import random
import ctypes
import gc
import win32gui
import win32process
import win32api
from tools.registry import tool
from tools.gui_controller import game_drag_and_release
from tools.visual_eye import VisualEye
from tools.system_control import trim_process_memory

user32 = ctypes.windll.user32
gdi32 = ctypes.windll.gdi32

def force_hardware_focus(hwnd: int):
    """Guarantees physical input latching directly onto game canvas."""
    if not hwnd or not win32gui.IsWindow(hwnd):
        return
    try:
        thread_target = win32process.GetWindowThreadProcessId(hwnd)[0]
        thread_current = win32api.GetCurrentThreadId()
        win32process.AttachThreadInput(thread_current, thread_target, True)
        win32gui.SetForegroundWindow(hwnd)
        win32gui.BringWindowToTop(hwnd)
        win32process.AttachThreadInput(thread_current, thread_target, False)
    except Exception:
        pass
    time.sleep(0.15)

class AutonomousVisualAgent:
    def __init__(self):
        # In-memory episodic experience buffer (Zero SQLite disk I/O lock)
        self.experience_buffer = []
        self.memory_buffer = self.experience_buffer
        self.best_params = {"angle": 45.0, "power": 0.72}

    def ensure_target_environment(self, hint: str = "game") -> int:
        """Finds active game canvas or launches lightweight fallback."""
        matches = []
        def enum_cb(hwnd, res):
            if win32gui.IsWindowVisible(hwnd):
                title = win32gui.GetWindowText(hwnd).lower()
                if any(k in title for k in ['angry', 'bird', 'game', 'flappy', 'canvas', 'chrome']):
                    res.append(hwnd)
        win32gui.EnumWindows(enum_cb, matches)
        if matches:
            force_hardware_focus(matches[0])
            return matches[0]

        print("[AGENT_OBSERVER] No game window active. Launching lightweight canvas...")
        try:
            from tools.browser_ui_controller import open_url
        except ImportError:
            from tools.browser import open_url
        open_url("https://flappybird.io/")
        time.sleep(3.5)
        hwnd = win32gui.GetForegroundWindow()
        force_hardware_focus(hwnd)
        return hwnd

    def ensure_game_environment(self, hint: str = "game") -> int:
        return self.ensure_target_environment(hint)

    def capture_frame_delta(self, hwnd: int) -> float:
        """Lightweight frame capture for reward verification."""
        img = VisualEye.get_window_raw_rgb(hwnd)
        if img is None:
            return 0.0
        delta = float(img[::15, ::15, 0].mean())
        del img
        trim_process_memory()
        return delta

    def capture_frame_diff(self, hwnd: int) -> float:
        return self.capture_frame_delta(hwnd)

    def compute_trajectory(self, player_pos, target_pos, trial_idx: int) -> tuple:
        """
        Solves ballistics pull vector from Player -> Target.
        Applies reinforcement adjustments if previous trials were misses.
        """
        if player_pos and target_pos:
            px, py = player_pos
            tx, ty = target_pos
            dx = tx - px
            dy = ty - py
            # Base ballistic angle calculation
            raw_angle = math.degrees(math.atan2(-dy, dx)) if dx != 0 else 45.0
            angle = max(25.0, min(70.0, raw_angle))
            distance = math.hypot(dx, dy)
            power = max(0.50, min(0.95, distance / 500.0))
        else:
            # Seed from best known experience with exploration noise
            angle = self.best_params["angle"] + (random.uniform(-4.0, 4.0) if trial_idx > 1 else 0.0)
            power = self.best_params["power"] + (random.uniform(-0.05, 0.05) if trial_idx > 1 else 0.0)

        # Pull vector is opposite to launch direction
        rad = math.radians(angle)
        pull_dx = -int(110 * power * math.cos(rad))
        pull_dy = int(110 * power * math.sin(rad))
        return angle, power, pull_dx, pull_dy

    def run_continuous_loop(self, max_trials: int = 6):
        hwnd = self.ensure_target_environment("game")
        force_hardware_focus(hwnd)
        print("\n[AGENT_OBSERVER] Sensed environment (4GB RAM Safe Mode). Initializing physics sensor...")
        time.sleep(2.5)

        for trial in range(1, max_trials + 1):
            if not win32gui.IsWindow(hwnd):
                print("[AGENT_OBSERVER] Window closed. Clean exit.")
                break

            force_hardware_focus(hwnd)
            rect = win32gui.GetWindowRect(hwnd)
            win_w, win_h = rect[2] - rect[0], rect[3] - rect[1]

            # 1. Perception Step: Detect Character and Target via VisualEye
            entities = VisualEye.locate_game_entities(hwnd)
            player_pos = entities.get('character') if entities else None
            target_pos = entities.get('target') if entities else None

            if player_pos:
                origin_x, origin_y = player_pos
                print(f"[TRIAL #{trial}] Locked Entity Anchor at ({origin_x}, {origin_y})")
            else:
                origin_x = rect[0] + int(win_w * 0.25)
                origin_y = rect[1] + int(win_h * 0.60)

            # 2. Planning Step: Solve Vector
            angle, power, pull_dx, pull_dy = self.compute_trajectory(player_pos, target_pos, trial)

            # 3. Pre-Action Visual Snapshot
            pre_reward = self.capture_frame_delta(hwnd)

            # 4. Actuation: Physical Drag & Release
            game_drag_and_release((origin_x, origin_y), (pull_dx, pull_dy), hold_duration=0.22)
            time.sleep(1.2)

            # 5. Reflection & Reward Evaluation
            post_reward = self.capture_frame_delta(hwnd)
            rwd = abs(post_reward - pre_reward)
            outcome = "HIT" if rwd > 3.5 else "MISS"

            print(f"[TRIAL #{trial}] Angle: {angle:.1f}° | Power: {power:.2f} | Vector: ({pull_dx}, {pull_dy}) | Delta: {rwd:.2f} -> {outcome}")

            # Reinforce Best Parameters
            if outcome == "HIT" or rwd > 2.0:
                self.best_params["angle"] = angle
                self.best_params["power"] = power

            self.experience_buffer.append({
                "trial": trial, "angle": angle, "power": power, "reward": rwd, "outcome": outcome
            })

            # OS Memory Compaction
            trim_process_memory()
            gc.collect()
            time.sleep(1.0)

    def solve_and_execute_continuous_loop(self, max_iterations: int = 20):
        return self.run_continuous_loop(max_trials=max_iterations)

@tool(
    name="run_autonomous_agent",
    description="Engages autonomous closed-loop visual game physics and reinforcement learning.",
    parameters={
        "type": "object",
        "properties": {
            "task_type": {"type": "string", "description": "game, web, or puzzle"},
            "query": {"type": "string", "description": "Objective description"}
        },
        "required": ["task_type"]
    },
    category="application",
    risk_level="state_changing"
)
def run_autonomous_agent(task_type: str = "game", query: str = "") -> dict:
    agent = AutonomousVisualAgent()
    agent.run_continuous_loop(max_trials=6)
    return {"status": "completed", "message": "Physics RL loop completed successfully."}
