"""
Game framework (Stage D): play a game by observe -> decide -> act -> verify -> learn, and never claim a result it did not see.

Why this exists: the old loops rewarded "the screen got brighter or darker" and then reported PASSED. An explosion animation, a menu or
a pop-up changes brightness too. Here the reward comes only from VERIFIED evidence, in this order of trust:
    1. a win / lose text that appeared after the action (OCR / UI Automation text)
    2. a score that went up or down
    3. target mass (pixels or count of the things to destroy) that really dropped, seen in two stable reads
Pixel change alone is "activity". It is reported, but it is never a hit, and it is never learned as one.

Pieces (all pure Python, nothing here imports win32 or any heavy library):
    Observation / Verdict    what was seen / what the judge concluded and why
    RewardJudge              before + after -> outcome with its evidence; unusable observations -> "unknown"
    ActionGuard              only mouse drag/click inside the game window, key allow-list, rate limit; everything else refused
    ActionPolicy             picks parameters (angle, power, ...) from a grid: UCB with neighbour smoothing, learns only verified results,
                             persists per game in MemoryStore (scope game:<name>)
    GameSession              the bounded loop: emergency stop, time and trial limits, RAM pressure, user takeover, window lost,
                             no perception -> no action; honest final status
Adapters (the Windows side that really sees and clicks) live in tools/game_adapters.py.
"""
from __future__ import annotations

import itertools
import math
import random
import re
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, Iterable, List, Optional, Sequence, Tuple

WIN_RE = re.compile(r"(?i)\b(level\s+(?:complete|cleared|passed)|you\s+win|you\s+won|victory|mission\s+(?:complete|accomplished)|stage\s+clear(?:ed)?|well\s+done|three\s+stars|new\s+high\s*score)\b")
LOSE_RE = re.compile(r"(?i)\b(game\s+over|you\s+(?:lose|lost|died)|defeat(?:ed)?|level\s+failed|try\s+again|out\s+of\s+(?:birds|lives|moves|time)|no\s+more\s+(?:birds|moves))\b")
MIN_TARGET_DROP = 0.25        # relative drop of target mass that counts as real progress
MIN_CONFIDENCE = 0.5


# ---------------------------------------------------------------------------------------------------------------- data
@dataclass
class Observation:
    ts: float
    ok: bool = True                              # perception worked at all
    window: Any = None
    target_mass: Optional[float] = None          # pixels (or count) belonging to the things to destroy / collect
    score: Optional[float] = None
    texts: List[str] = field(default_factory=list)
    activity: float = 0.0                        # 0..1 amount of raw pixel change since the last frame. NEVER evidence of success
    confidence: float = 1.0
    stable: bool = True                          # two consecutive reads agreed
    note: str = ""
    extra: Dict[str, Any] = field(default_factory=dict)


@dataclass
class Verdict:
    outcome: str                                 # success | progress | failure | no_effect | unknown
    reward: float                                # -1 .. 1
    verified: bool                               # True only when real evidence backs it
    evidence: List[str]
    strength: str = "none"                       # win_text | lose_text | score | target_mass | none

    def as_dict(self) -> Dict[str, Any]:
        return {"outcome": self.outcome, "reward": round(self.reward, 3), "verified": self.verified, "evidence": list(self.evidence), "strength": self.strength}


# ---------------------------------------------------------------------------------------------------------------- judge
class RewardJudge:
    def __init__(self, max_gap_s: float = 20.0, min_target_drop: float = MIN_TARGET_DROP, min_activity: float = 0.02):
        self.max_gap_s, self.min_target_drop, self.min_activity = max_gap_s, min_target_drop, min_activity

    def judge(self, before: Observation, after: Observation) -> Verdict:
        bad = self._unusable(before, after)
        if bad:
            return Verdict("unknown", 0.0, False, [f"observation not usable: {bad}"])
        b_texts = {t.strip().lower() for t in before.texts}
        new_texts = [t for t in after.texts if t.strip().lower() not in b_texts]
        win = [t for t in new_texts if WIN_RE.search(t)]
        lose = [t for t in new_texts if LOSE_RE.search(t)]
        if win and lose:
            return Verdict("unknown", 0.0, False, [f"conflicting texts on screen: win {win[0]!r} and lose {lose[0]!r}"])
        if win:
            return Verdict("success", 1.0, True, [f"win text appeared: {win[0][:80]!r}"], "win_text")
        if lose:
            return Verdict("failure", -1.0, True, [f"lose text appeared: {lose[0][:80]!r}"], "lose_text")
        ev: List[str] = []
        measured = False                              # True once a real, stable measurement says "nothing improved"
        if before.score is not None and after.score is not None:
            if after.score > before.score:
                d = after.score - before.score
                return Verdict("progress", min(0.9, 0.3 + math.log10(1 + d) / 4), True, [f"score rose {before.score:g} -> {after.score:g}"], "score")
            if after.score < before.score:
                return Verdict("failure", -0.3, True, [f"score fell {before.score:g} -> {after.score:g}"], "score")
            ev.append(f"score unchanged at {after.score:g}")
            measured = True
        if before.target_mass is not None and after.target_mass is not None and before.target_mass > 0:
            if before.stable and after.stable and min(before.confidence, after.confidence) >= MIN_CONFIDENCE:
                drop = (before.target_mass - after.target_mass) / float(before.target_mass)
                if drop >= self.min_target_drop:
                    note = "all targets gone (could also be a scene change)" if after.target_mass <= 0 else f"target mass fell {drop:.0%}"
                    return Verdict("progress", min(0.8, 0.3 + drop * 0.5), True, [note], "target_mass")
                ev.append(f"target mass changed only {drop:.0%} (< {self.min_target_drop:.0%})")
                measured = True
            else:
                ev.append("target mass not stable/confident enough to count")
        if after.activity >= self.min_activity:
            ev.append(f"screen changed ({after.activity:.0%}) but that alone is not a hit (animation, effect or menu)")
        if measured:
            return Verdict("no_effect", 0.0, True, ev, "none")       # a real measurement showed no improvement: a verified miss, worth learning
        if ev:
            return Verdict("no_effect", 0.0, False, ev, "none")
        return Verdict("unknown", 0.0, False, ["no verifiable signal in this game (no score, no target measure, no win/lose text)"])

    def _unusable(self, b: Observation, a: Observation) -> Optional[str]:
        if not b.ok or not a.ok:
            return "perception failed" + (f" ({(b.note if not b.ok else a.note)})" if (b.note or a.note) else "")
        if b.window is not None and a.window is not None and b.window != a.window:
            return "different window before and after"
        if a.ts - b.ts > self.max_gap_s:
            return f"observations {a.ts - b.ts:.0f}s apart"
        if a.ts < b.ts:
            return "observations out of order"
        return None


# ---------------------------------------------------------------------------------------------------------------- guard
FORBIDDEN_KEYS = {"win", "windows", "alt+f4", "ctrl+alt+delete", "ctrl+shift+esc", "alt+tab", "ctrl+w", "ctrl+q", "f11"}


class ActionGuard:
    """What a game session may physically do. Anything else is refused with a reason, never silently clipped into something else."""

    def __init__(self, window_rect: Tuple[int, int, int, int], allowed_kinds: Iterable[str] = ("drag", "click"), allowed_keys: Iterable[str] = (),
                 min_interval_s: float = 0.4, max_per_minute: int = 40, clock: Callable[[], float] = time.monotonic):
        self.rect = tuple(window_rect)
        self.kinds = set(allowed_kinds)
        self.keys = {k.lower() for k in allowed_keys} - FORBIDDEN_KEYS
        self.min_interval, self.max_per_min, self.clock = min_interval_s, max_per_minute, clock
        self._times: List[float] = []

    def _inside(self, p: Sequence[float]) -> bool:
        return self.rect[0] <= p[0] < self.rect[2] and self.rect[1] <= p[1] < self.rect[3]

    def check(self, action: Dict[str, Any]) -> Tuple[bool, str]:
        kind = action.get("kind")
        if kind not in self.kinds:
            return False, f"action kind {kind!r} is not allowed for this game"
        if kind in ("drag", "click"):
            pts = [action.get("start") or action.get("at")] + ([action.get("end")] if kind == "drag" else [])
            if any(p is None or len(p) < 2 or not self._inside(p) for p in pts):
                return False, "point outside the game window"
        if kind == "key":
            k = str(action.get("key", "")).lower()
            if k in FORBIDDEN_KEYS or k not in self.keys:
                return False, f"key {k!r} is not on the allow-list"
        now = self.clock()
        self._times = [t for t in self._times if now - t < 60.0]
        if len(self._times) >= self.max_per_min:
            return False, "too many actions per minute"
        if self._times and now - self._times[-1] < self.min_interval:
            return False, "acting too fast"
        return True, "ok"

    def note(self) -> None:
        self._times.append(self.clock())


# ---------------------------------------------------------------------------------------------------------------- policy
class ActionPolicy:
    """Parameter search over a grid. space = {"angle": (30, 60, 7), "power": (0.4, 0.9, 6)} -> 42 buckets.
    Score of a bucket = smoothed mean verified reward + UCB bonus. Only verified results are learned; 'unknown' teaches nothing."""

    def __init__(self, game: str, space: Dict[str, Tuple[float, float, int]], store: Any = None, seed: Optional[int] = None,
                 c: float = 0.6, neighbour_weight: float = 0.5, min_epsilon: float = 0.08):
        self.game, self.space, self.store = game, dict(space), store
        self.names = list(space)
        self.axes = {n: [lo + (hi - lo) * i / max(1, k - 1) for i in range(k)] for n, (lo, hi, k) in space.items()}
        self.c, self.nw, self.min_eps = c, neighbour_weight, min_epsilon
        self.rng = random.Random(seed)
        self.stats: Dict[Tuple[int, ...], Dict[str, float]] = {}
        self.banned: set = set()
        self.total = 0
        self._ids: Dict[Tuple[int, ...], int] = {}
        self._load()

    # -- bucket helpers
    def key_of(self, idx: Tuple[int, ...]) -> str:
        return "bucket:" + ",".join(f"{n}={self.axes[n][i]:.3f}" for n, i in zip(self.names, idx))

    def params(self, idx: Tuple[int, ...]) -> Dict[str, float]:
        return {n: round(self.axes[n][i], 4) for n, i in zip(self.names, idx)}

    def _neighbours(self, idx: Tuple[int, ...]) -> Iterable[Tuple[int, ...]]:
        for d in range(len(idx)):
            for step in (-1, 1):
                j = idx[d] + step
                if 0 <= j < len(self.axes[self.names[d]]):
                    yield idx[:d] + (j,) + idx[d + 1:]

    # -- persistence (MemoryStore, kind "game", scope game:<name>)
    def _scope(self) -> str:
        return f"game:{self.game}"

    def _load(self) -> None:
        if self.store is None:
            return
        for idx in itertools.product(*[range(len(self.axes[n])) for n in self.names]):
            rows = self.store.by_key("game", self.key_of(idx), scope=self._scope())
            if rows:
                m = rows[0]["meta"]
                self.stats[idx] = {"n": float(m.get("n", 0)), "sum": float(m.get("sum", 0.0)), "ok": float(m.get("ok", 0))}
                self._ids[idx] = rows[0]["id"]
                self.total += int(m.get("n", 0))

    def _save(self, idx: Tuple[int, ...]) -> None:
        if self.store is None:
            return
        s = self.stats[idx]
        if idx not in self._ids:
            self.store.add("game", f"{self.game} {self.key_of(idx)} {self.params(idx)}", key=self.key_of(idx), scope=self._scope(), source="tool_verified", meta={"n": 0})
            rows = self.store.by_key("game", self.key_of(idx), scope=self._scope())
            if not rows:
                return
            self._ids[idx] = rows[0]["id"]
        self.store.update_meta(self._ids[idx], n=int(s["n"]), sum=round(s["sum"], 4), ok=int(s["ok"]), params=self.params(idx))

    # -- choosing and learning
    def _eff(self, idx: Tuple[int, ...]) -> Tuple[float, float]:
        s = self.stats.get(idx, {"n": 0.0, "sum": 0.0})
        n, tot = s["n"], s["sum"]
        for nb in self._neighbours(idx):
            t = self.stats.get(nb)
            if t:
                n += self.nw * t["n"]
                tot += self.nw * t["sum"]
        return n, tot

    def select(self, trial: int) -> Tuple[Tuple[int, ...], Dict[str, float], str]:
        all_idx = [i for i in itertools.product(*[range(len(self.axes[n])) for n in self.names]) if i not in self.banned]
        if not all_idx:
            raise RuntimeError("every action was refused by the guard")
        # exploration shrinks with what was really LEARNED (verified results, also from earlier sessions), not with this session's trial number
        eps = max(self.min_eps, 0.6 * (0.93 ** max(self.total, trial - 1)))
        if self.rng.random() < eps:
            idx = self.rng.choice(all_idx)
            return idx, self.params(idx), "explore"
        lnN = math.log(self.total + 2)
        best, best_score = None, -1e9
        for idx in all_idx:
            n, tot = self._eff(idx)
            mean = tot / n if n > 0 else 0.2                 # unseen = mildly optimistic
            score = mean + self.c * math.sqrt(lnN / (n + 1.0)) + self.rng.random() * 1e-6
            if score > best_score:
                best, best_score = idx, score
        return best, self.params(best), "exploit" if self.stats.get(best, {}).get("n", 0) > 0 else "explore"

    def update(self, idx: Tuple[int, ...], verdict: Verdict) -> bool:
        """Returns True if this result was learned. Unverified/unknown results are not."""
        if not verdict.verified or verdict.outcome == "unknown":
            return False
        s = self.stats.setdefault(idx, {"n": 0.0, "sum": 0.0, "ok": 0.0})
        s["n"] += 1
        s["sum"] += verdict.reward
        s["ok"] += 1 if verdict.outcome in ("success", "progress") else 0
        self.total += 1
        self._save(idx)
        return True

    def ban(self, idx: Tuple[int, ...]) -> None:
        self.banned.add(idx)

    def best(self) -> Optional[Dict[str, Any]]:
        cand = [(s["sum"] / s["n"], i, s) for i, s in self.stats.items() if s["n"] >= 1 and s["ok"] >= 1]
        if not cand:
            return None
        mean, idx, s = max(cand, key=lambda x: (x[0], x[2]["n"]))
        return {"params": self.params(idx), "mean_reward": round(mean, 3), "trials": int(s["n"]), "successes": int(s["ok"])}


# ---------------------------------------------------------------------------------------------------------------- session
class GameSession:
    """
    adapter must provide:
        observe() -> Observation
        perform(action: dict) -> {"executed": bool, "error": str?}
        build_action(params: dict) -> dict          turns searched parameters into a concrete action (needs a fresh observation)
        foreground_ok() -> bool                     game window still exists and is in front
        user_took_over() -> bool   (optional)       the person moved the mouse / pressed keys during the pause
    """

    def __init__(self, game: str, adapter: Any, policy: ActionPolicy, judge: RewardJudge, guard: ActionGuard, *, max_trials: int = 10, max_seconds: float = 300.0,
                 settle_s: float = 1.2, clock: Callable[[], float] = time.monotonic, sleep: Callable[[float], None] = time.sleep,
                 stop_check: Callable[[], bool] = lambda: False, pressure_fn: Callable[[], str] = lambda: "normal", trim_fn: Optional[Callable[[], Any]] = None,
                 on_trial: Optional[Callable[[Dict[str, Any]], None]] = None, store: Any = None, stable_reads: int = 3):
        self.game, self.adapter, self.policy, self.judge, self.guard = game, adapter, policy, judge, guard
        self.max_trials, self.max_seconds, self.settle = max_trials, max_seconds, settle_s
        self.clock, self.sleep, self.stop_check, self.pressure = clock, sleep, stop_check, pressure_fn
        self.trim, self.on_trial, self.store, self.stable_reads = trim_fn, on_trial, store, stable_reads

    # -- helpers
    def _wait(self, seconds: float) -> bool:
        """Sleep in small slices so an emergency stop is noticed within ~0.1 s. Returns False if a stop arrived."""
        end = self.clock() + seconds
        while True:
            if self.stop_check():
                return False
            left = end - self.clock()
            if left <= 0:
                return True
            self.sleep(min(0.1, left))

    def _stable_observe(self) -> Observation:
        last: Optional[Observation] = None
        for i in range(max(1, self.stable_reads)):
            o = self.adapter.observe()
            if not o.ok:
                return o
            if last is not None and o.target_mass == last.target_mass and o.score == last.score:
                o.stable = True
                o.activity = max(o.activity, last.activity)
                return o
            last = o
            if i < self.stable_reads - 1 and not self._wait(0.25):
                break
        if last is not None:
            last.stable = False
        return last or Observation(self.clock(), ok=False, note="no observation")

    def _finish(self, status: str, message: str, trials: List[Dict[str, Any]], t0: float, stopped: bool = False) -> Dict[str, Any]:
        verified = [t for t in trials if t["verdict"]["verified"]]
        wins = [t for t in trials if t["verdict"]["outcome"] == "success"]
        progress = [t for t in trials if t["verdict"]["outcome"] == "progress"]
        learned = sum(1 for t in trials if t.get("learned"))
        if status == "RUNNING":
            if wins:
                status, message = "WON", f"Verified win after {len(trials)} trial(s)."
            elif progress:
                status, message = "PROGRESS", f"{len(progress)} verified progress signal(s) in {len(trials)} trial(s), but no win was seen."
            elif verified:
                status, message = "NO_EFFECT", "Actions were performed; nothing verifiable improved."
            else:
                status, message = "INCONCLUSIVE", "Actions were performed but no verifiable signal (score, target measure, win/lose text) was available, so no success is claimed."
        best = self.policy.best()
        if self.store is not None and best and wins:
            try:
                self.store.add("game", f"{self.game}: best verified parameters {best['params']} (mean reward {best['mean_reward']})", key="best", scope=f"game:{self.game}", source="oracle_verified")
            except Exception:
                pass
        return {"status": status, "success": status == "WON", "verified": bool(verified), "message": message, "game": self.game, "trials_completed": len(trials),
                "verified_trials": len(verified), "progress_trials": len(progress), "learned_trials": learned, "unverified_trials": len(trials) - len(verified),
                "best": best, "seconds": round(self.clock() - t0, 1), "trials": trials[-20:], "stopped_early": stopped}

    # -- the loop
    def run(self) -> Dict[str, Any]:
        t0 = self.clock()
        trials: List[Dict[str, Any]] = []
        no_perception = low_ram_waits = action_failures = 0
        for trial in range(1, self.max_trials + 1):
            if self.stop_check():
                return self._finish("STOPPED_EMERGENCY", "Emergency stop requested; nothing further was done.", trials, t0, True)
            if self.clock() - t0 > self.max_seconds:
                return self._finish("STOPPED_TIME", f"Time limit of {self.max_seconds:.0f}s reached.", trials, t0, True)
            if self.pressure() == "critical":
                low_ram_waits += 1
                if low_ram_waits > 3 or not self._wait(2.0):
                    return self._finish("STOPPED_LOW_RAM", "RAM stayed critical; stopped instead of risking the machine. Learned results are saved.", trials, t0, True)
                continue
            if not self.adapter.foreground_ok():
                return self._finish("STOPPED_WINDOW", "The game window is gone or not in front; no input was sent.", trials, t0, True)
            took = getattr(self.adapter, "user_took_over", None)
            if took and took():
                return self._finish("STOPPED_USER", "You used the mouse or keyboard; GOKU stopped instead of fighting you.", trials, t0, True)
            before = self._stable_observe()
            if not before.ok or not before.extra.get("can_act", True):
                no_perception += 1
                if no_perception >= 2:
                    return self._finish("STOPPED_NO_PERCEPTION", f"The game scene could not be read ({before.note or 'no detection'}); GOKU does not act blind.", trials, t0, True)
                continue
            if any(WIN_RE.search(t) for t in before.texts) or any(LOSE_RE.search(t) for t in before.texts):
                word = "won" if any(WIN_RE.search(t) for t in before.texts) else "lost"
                return self._finish("ALREADY_FINISHED", f"The screen already shows that the game is {word}; no action taken.", trials, t0, True)
            try:
                idx, params, mode = self.policy.select(trial)
            except RuntimeError as exc:
                return self._finish("STOPPED_GUARD", str(exc), trials, t0, True)
            action = self.adapter.build_action(params)
            ok, why = self.guard.check(action)
            if not ok:
                self.policy.ban(idx)
                trials.append({"trial": trial, "params": params, "refused": why, "verdict": Verdict("unknown", 0.0, False, [f"refused by guard: {why}"]).as_dict()})
                continue
            res = self.adapter.perform(action)
            self.guard.note()
            if not res.get("executed"):
                action_failures += 1
                trials.append({"trial": trial, "params": params, "error": res.get("error", "action not executed"), "verdict": Verdict("unknown", 0.0, False, ["action did not execute"]).as_dict()})
                if action_failures >= 2:
                    return self._finish("STOPPED_ACTION_FAILED", f"Input could not be sent twice in a row: {res.get('error', '')}", trials, t0, True)
                continue
            action_failures = 0
            if not self._wait(self.settle):
                return self._finish("STOPPED_EMERGENCY", "Emergency stop requested while waiting for the result.", trials, t0, True)
            after = self._stable_observe()
            verdict = self.judge.judge(before, after)
            learned = self.policy.update(idx, verdict)
            rec = {"trial": trial, "mode": mode, "params": params, "verdict": verdict.as_dict(), "learned": learned}
            trials.append(rec)
            if self.on_trial:
                try:
                    self.on_trial(rec)
                except Exception:
                    pass
            if verdict.outcome == "success":
                return self._finish("RUNNING", "", trials, t0)
            if verdict.outcome == "failure" and verdict.strength == "lose_text":
                return self._finish("LOST", "The game shows it was lost; stopped.", trials, t0, True)
            if self.trim and trial % 3 == 0:
                try:
                    self.trim()
                except Exception:
                    pass
        return self._finish("RUNNING", "", trials, t0)
