"""
Game adapters (Stage D): the thin Windows side of the game framework. Everything that touches win32 is injected or imported lazily,
so this module imports anywhere and is fully testable with fakes.

SlingshotAdapter turns the existing scene detector (tools.game_engine.detect_game_scene) and the existing mouse tool
(tools.gui_controller.game_drag_and_release) into the observe/perform interface of brain.game_framework.GameSession.

Perception per observation:
    target_mass  = number of "target" pixels the scene detector counted (a real, repeatable measurement; a drop means targets went away)
    texts        = optional OCR / UI Automation texts (win / lose banners)         texts_fn() -> list[str]
    score        = optional parsed score                                         score_fn() -> float | None
    activity     = optional raw pixel change 0..1 (only ever reported, never a reward)
"""
from __future__ import annotations

import math
import sys
import time
from typing import Any, Callable, Dict, List, Optional, Tuple

from brain.game_framework import ActionGuard, ActionPolicy, GameSession, Observation, RewardJudge

TIER_TRIALS = {"tiny": 8, "small": 12, "medium": 20, "large": 30}
SLINGSHOT_SPACE = {"angle": (25.0, 65.0, 9), "power": (0.35, 0.95, 7)}
USER_MOVE_PX = 25


def _default_cursor() -> Optional[Tuple[int, int]]:
    if sys.platform != "win32":
        return None
    try:
        import ctypes
        from ctypes import wintypes
        pt = wintypes.POINT()
        ctypes.windll.user32.GetCursorPos(ctypes.byref(pt))
        return pt.x, pt.y
    except Exception:
        return None


def _default_window_ok(hwnd: Any) -> bool:
    if sys.platform != "win32":
        return True
    try:
        import ctypes
        u = ctypes.windll.user32
        return bool(u.IsWindow(hwnd)) and u.GetForegroundWindow() == hwnd
    except Exception:
        return False


class SlingshotAdapter:
    def __init__(self, hwnd: Any, detect_fn: Callable[..., Dict[str, Any]], drag_fn: Callable[..., Any], *, rect: Tuple[int, int, int, int],
                 texts_fn: Optional[Callable[[], List[str]]] = None, score_fn: Optional[Callable[[], Optional[float]]] = None,
                 activity_fn: Optional[Callable[[], float]] = None, window_ok_fn: Optional[Callable[[Any], bool]] = None,
                 cursor_fn: Optional[Callable[[], Optional[Tuple[int, int]]]] = None, clock: Callable[[], float] = time.time):
        self.hwnd, self.detect, self.drag, self.rect = hwnd, detect_fn, drag_fn, tuple(rect)
        self.texts_fn, self.score_fn, self.activity_fn = texts_fn, score_fn, activity_fn
        self.window_ok = window_ok_fn or _default_window_ok
        self.cursor_fn = cursor_fn or _default_cursor
        self.clock = clock
        self.origin: Optional[Tuple[int, int]] = None
        self._left_cursor: Optional[Tuple[int, int]] = None

    # -- perception
    def observe(self) -> Observation:
        now = self.clock()
        try:
            scene = self.detect(self.hwnd)
        except Exception as exc:
            return Observation(now, ok=False, window=self.hwnd, note=f"scene detector error: {type(exc).__name__}")
        counts = (scene or {}).get("pixel_counts")
        if not isinstance(counts, dict):
            return Observation(now, ok=False, window=self.hwnd, note=(scene or {}).get("message", "frame could not be read"))
        texts: List[str] = []
        score = None
        try:
            if self.texts_fn:
                texts = [str(t) for t in (self.texts_fn() or [])][:200]
            if self.score_fn:
                score = self.score_fn()
        except Exception:
            texts, score = [], None                       # a broken OCR must never turn into a fake banner
        activity = 0.0
        try:
            if self.activity_fn:
                activity = max(0.0, min(1.0, float(self.activity_fn())))
        except Exception:
            activity = 0.0
        detected = scene.get("status") == "success" and bool(scene.get("origin"))
        if detected:
            self.origin = tuple(scene["origin"])
        return Observation(now, True, self.hwnd, float(counts.get("target_pixels", 0)), score, texts, activity, float(scene.get("confidence", 0.7) or 0.7), True,
                           "" if detected else (scene.get("message") or "scene anchors not detected"),
                           {"can_act": detected, "origin": self.origin, "detected_targets": bool(scene.get("detected_targets"))})

    # -- acting
    def build_action(self, params: Dict[str, float]) -> Dict[str, Any]:
        if self.origin is None:
            return {"kind": "none"}
        rad = math.radians(float(params["angle"]))
        power = float(params["power"])
        dx, dy = -int(110 * power * math.cos(rad)), int(110 * power * math.sin(rad))
        ox, oy = self.origin
        return {"kind": "drag", "start": (ox, oy), "offset": (dx, dy), "end": (ox + dx, oy + dy), "params": dict(params)}

    def perform(self, action: Dict[str, Any]) -> Dict[str, Any]:
        try:
            res = self.drag(tuple(action["start"]), tuple(action["offset"]), hold_duration=0.25)
        except Exception as exc:
            return {"executed": False, "error": f"{type(exc).__name__}: {exc}"}
        ok = not (isinstance(res, dict) and res.get("success") is False)
        self._left_cursor = tuple(action["end"]) if ok else self._left_cursor
        return {"executed": ok, "error": "" if ok else str((res or {}).get("message", "drag failed"))}

    # -- safety
    def foreground_ok(self) -> bool:
        try:
            return bool(self.window_ok(self.hwnd))
        except Exception:
            return False

    def user_took_over(self) -> bool:
        """The cursor was left where GOKU released it. If it is somewhere else now, a person moved it."""
        if self._left_cursor is None:
            return False
        cur = self.cursor_fn()
        if cur is None:
            return False
        return abs(cur[0] - self._left_cursor[0]) + abs(cur[1] - self._left_cursor[1]) > USER_MOVE_PX


def ocr_texts_fn(rect: Tuple[int, int, int, int]) -> Callable[[], List[str]]:
    """Reads on-screen text (win / lose banners) with OCR, but only when the hardware tier allows it and RAM pressure is normal.
    Otherwise it returns [] and the game can still be judged by target mass or score, it just cannot be declared WON."""
    cache: Dict[str, Any] = {}

    def fn() -> List[str]:
        try:
            from tools.hw_profile import get_hw_profile
            if not (get_hw_profile().get("settings") or {}).get("ocr_allowed", True):
                return []
            from tools.resource_monitor import pressure_level
            if pressure_level() != "normal":
                return []
            if "ocr" not in cache:
                from tools.vision.screen_providers import default_providers
                cache["ocr"] = default_providers().get("ocr")
            if cache["ocr"] is None:
                return []
            return [str(i.get("text", "")) for i in (cache["ocr"](rect) or []) if i.get("text")]
        except Exception:
            return []
    return fn


def tier_trials(tier: Optional[str] = None) -> int:
    if tier is None:
        try:
            from tools.hw_profile import get_hw_profile
            tier = str(get_hw_profile().get("tier", "small"))
        except Exception:
            tier = "small"
    return TIER_TRIALS.get(str(tier).lower(), 12)


def default_runtime() -> Dict[str, Any]:
    """Stop check, RAM pressure and memory trim from the P0 modules; harmless defaults if they are unavailable."""
    rt: Dict[str, Any] = {"stop_check": lambda: False, "pressure_fn": lambda: "normal", "trim_fn": None, "store": None}
    try:
        from tools.emergency_stop import is_stop_requested
        rt["stop_check"] = is_stop_requested
    except Exception:
        pass
    try:
        from tools.resource_monitor import pressure_level
        rt["pressure_fn"] = pressure_level
    except Exception:
        pass
    try:
        from tools.ram_planner import trim_process_memory
        rt["trim_fn"] = trim_process_memory
    except Exception:
        pass
    try:
        from brain.learning_hooks import get_store, learning_enabled
        if learning_enabled():
            rt["store"] = get_store()
    except Exception:
        pass
    return rt


def run_slingshot_session(game: str, adapter: SlingshotAdapter, *, max_trials: Optional[int] = None, max_seconds: float = 300.0, settle_s: float = 1.2,
                          seed: Optional[int] = None, on_trial: Optional[Callable[[Dict[str, Any]], None]] = None, runtime: Optional[Dict[str, Any]] = None,
                          sleep: Callable[[float], None] = time.sleep, clock: Callable[[], float] = time.monotonic) -> Dict[str, Any]:
    rt = runtime if runtime is not None else default_runtime()
    policy = ActionPolicy(game, SLINGSHOT_SPACE, store=rt.get("store"), seed=seed)
    guard = ActionGuard(adapter.rect, allowed_kinds=("drag",), min_interval_s=0.8, max_per_minute=30, clock=clock)
    session = GameSession(game, adapter, policy, RewardJudge(), guard, max_trials=max_trials or tier_trials(), max_seconds=max_seconds, settle_s=settle_s,
                          clock=clock, sleep=sleep, stop_check=rt.get("stop_check", lambda: False), pressure_fn=rt.get("pressure_fn", lambda: "normal"),
                          trim_fn=rt.get("trim_fn"), on_trial=on_trial, store=rt.get("store"))
    return session.run()


def to_tool_result(report: Dict[str, Any], hwnd: Any = None) -> Dict[str, Any]:
    """Tool-style result. status is 'PASSED' ONLY for a verified win, so the verifier and the truth oracle cannot be fooled."""
    st = report["status"]
    out = dict(report)
    hard_fail = ("STOPPED_NO_PERCEPTION", "STOPPED_WINDOW", "STOPPED_ACTION_FAILED")
    out["status"] = "PASSED" if st == "WON" else "failed" if st in hard_fail else st.lower()
    out["success"] = st == "WON"
    out["game_status"] = st
    if st == "STOPPED_NO_PERCEPTION":
        out["message"] = "game scene not detected; no input was sent. " + report["message"]
    elif st == "STOPPED_WINDOW":
        out["message"] = f"game window {hwnd} not found or closed. " + report["message"]
    return out
