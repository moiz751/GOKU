"""
Reliable LLM routing, structured tool parsing, and word-boundary intent engine.
Replaces brittle substring matching with tokenized word-boundary lexicons,
provides schema-validated tool-call extraction, and enforces adaptive timeouts.
"""
from __future__ import annotations

import json
from pathlib import Path
import re
import time
from typing import Any, Optional, Tuple
import urllib.request
import urllib.error

from config.settings import (
    MODEL,
    OLLAMA_URL,
    is_model_call_allowed,
    OLLAMA_KEEP_ALIVE,
    GOKU_KEEP_ALIVE,
    GOKU_NUM_CTX,
    GOKU_NUM_BATCH,
    ollama_options,
    MAX_INPUT_CHARS,
    NUM_PREDICT_CAP,
)
from brain.ollama_manager import unload_model, is_model_loaded

SYSTEM_PROMPT = (
    "You are a local desktop control agent. You have access to tools to control the system. "
    "When the user asks to create/open a folder or file, search for files, or launch an application, "
    "always call the matching tool with the appropriate arguments. "
    "Only reply with a text message if the request is a general conversational question."
)

CONVERSATIONAL_SYSTEM_PROMPT = (
    "You are a helpful and concise local desktop AI assistant. Answer user questions directly and briefly."
)

# Adaptive timeout state
_OLLAMA_WARMED = False

# Lexicon of Roman Urdu and English action verbs
VERB_LEXICON_SINGLE = {
    # Roman Urdu
    "kholo", "banao", "likho", "chalao", "dhundo", "dhoondo", "dikhao",
    "dekho", "nikalo", "badlo", "bhejo", "batao", "hatao", "padho",
    # English
    "open", "launch", "start", "close", "exit", "kill", "shut",
    "create", "make", "type", "write", "search", "find", "show",
    "display", "view", "check", "inspect", "read", "extract",
    "fetch", "change", "modify", "replace", "send", "tell",
    "delete", "remove", "clear", "copy", "rename", "minimize",
    "maximize", "save", "screenshot", "scroll", "click", "move",
    "press", "summarize", "summary", "run", "execute", "restart"
}

VERB_LEXICON_MULTI = [
    ("band", "karo"),
    ("band", "kero"),
    ("band", "kardo"),
    ("band", "karein"),
    ("summary", "do"),
    ("kaat", "do"),
]

KNOWN_APPS = {
    "chrome", "notepad", "calculator", "calc", "cmd", "powershell",
    "terminal", "explorer", "youtube", "browser", "vlc", "word",
    "excel", "powerpoint", "vscode", "paint", "spotify"
}

SYSTEM_TARGETS = {
    "window", "windows", "tab", "tabs", "file", "files", "folder", "folders",
    "directory", "directories", "screen", "wifi", "sound", "volume",
    "url", "link", "mouse", "keyboard", "desktop", "process", "task",
    "document", "documents", "button", "buttons", "cache", "address", "ip",
    "page", "pages", "color", "logs", "log", "start"
}

CONVERSATIONAL_EXACT_PHRASES = {
    "mujhe khushi hui", "how are you", "who are you", "what can you do",
    "kaise ho", "kya haal hai", "kya haal hai goku", "tum kaun ho", "tell me a joke",
    "goku test", "hello computer", "thank you", "thanks a lot",
    "bohot shukriya", "nice to meet you", "who created you",
    "what is ai", "explain gravity", "what is 2+2", "hello", "hi", "hey"
}

GREETING_TOKENS = {
    "hello", "hi", "hey", "assalam", "salam", "adaab", "greetings",
    "shukriya", "thanks", "bye", "alvida", "goodbye"
}

CONV_PREFIX_PATTERNS = [
    re.compile(r"^\b(?:what\s+is|who\s+is|explain|tell\s+me|why\s+is|how\s+does|what\s+are|how\s+to|how\s+do|can\s+you|where\s+is|is\s+it|difference\s+between|define|meaning\s+of|tell\s+a\s+joke)\b", re.IGNORECASE)
]

FILE_EXT_PATTERN = re.compile(r"\b[a-zA-Z0-9_\-]+\.(?:txt|pdf|docx|xlsx|pptx|csv|py|json|log|png|jpg|jpeg|html|xml|md|zip)\b", re.IGNORECASE)
COMPOUND_CONJ_PATTERN = re.compile(r"\b(?:phir|aur|then|and|after\s+that|pehle|uske\s+baad)\b", re.IGNORECASE)


def _edit_distance_1(s1: str, s2: str) -> bool:
    """Returns True if Levenshtein distance between s1 and s2 is exactly 1."""
    if abs(len(s1) - len(s2)) > 1:
        return False
    if s1 == s2:
        return True
    m, n = len(s1), len(s2)
    if m == n:
        diffs = sum(1 for a, b in zip(s1, s2) if a != b)
        return diffs == 1
    if m > n:
        s1, s2 = s2, s1
        m, n = n, m
    for i in range(n):
        if s2[:i] + s2[i + 1 :] == s1:
            return True
    return False


def _match_verb_token(token: str) -> bool:
    """
    Checks if a token matches the verb lexicon.
    Uses exact lookup for short words (< 5 letters),
    and distance-1 tolerance for words of 5+ letters.
    """
    if token in VERB_LEXICON_SINGLE:
        return True
    if len(token) >= 5:
        for v in VERB_LEXICON_SINGLE:
            if len(v) >= 5 and _edit_distance_1(token, v):
                return True
    return False


def decompose_compound_clauses(text: str) -> list[str]:
    """
    Splits compound commands by conjunctions ('phir', 'aur', 'then', 'and', 'after that')
    without returning an empty list. Returns individual executable clauses.
    """
    raw_clauses = COMPOUND_CONJ_PATTERN.split(text)
    cleaned = [c.strip(" ,.;") for c in raw_clauses if c.strip(" ,.;")]
    return cleaned if len(cleaned) > 1 else [text.strip()]


def log_routing_trace(
    user_cmd: str,
    layer: str,
    reason: str,
    confidence: float = 1.0,
    extra: Optional[dict] = None,
) -> None:
    """
    Appends a routing trace line per command to execution_traces.jsonl:
    records which layer decided ('regex layer', 'planner', 'llm', 'clarify') and why.
    """
    rec = {
        "timestamp": time.time(),
        "user_cmd": user_cmd,
        "layer": layer,
        "reason": reason,
        "confidence": round(float(confidence), 3),
    }
    if extra:
        rec.update(extra)
    try:
        trace_path = Path("execution_traces.jsonl")
        if trace_path.exists() and trace_path.stat().st_size >= 2 * 1024 * 1024:
            from tools.log_rotator import rotate_log_file
            rotate_log_file(trace_path)
        with open(trace_path, "a", encoding="utf-8") as f:
            f.write(json.dumps(rec) + "\n")
    except Exception:
        pass


def classify_command_intent(user_text: str) -> dict[str, Any]:
    """
    Computes confidence scores for action vs chat vs ambiguous commands
    using strict word-boundary token matching.
    Returns:
      {
        "intent": "action" | "chat" | "clarify",
        "action_score": float,
        "chat_score": float,
        "confidence": float,
        "action_verbs": list[str],
        "options": list[str] (if clarify),
        "question": str (if clarify),
      }
    """
    text_clean = user_text.strip()
    tokens = re.findall(r"\b[a-zA-Z0-9_\-.]+\b", text_clean.lower())
    token_set = set(tokens)

    # 1. Exact conversational phrases
    text_clean.lower()
    for phrase in CONVERSATIONAL_EXACT_PHRASES:
        p_tokens = re.findall(r"\b[a-zA-Z0-9_\-.]+\b", phrase)
        if len(p_tokens) == 1 and p_tokens[0] in token_set and len(tokens) <= 2:
            return {
                "intent": "chat",
                "action_score": 0.0,
                "chat_score": 0.98,
                "confidence": 0.98,
                "action_verbs": [],
            }
        elif len(p_tokens) > 1 and all(pt in token_set for pt in p_tokens):
            return {
                "intent": "chat",
                "action_score": 0.0,
                "chat_score": 0.96,
                "confidence": 0.96,
                "action_verbs": [],
            }

    # 2. Extract action verbs
    found_verbs = [t for t in tokens if _match_verb_token(t)]
    for w1, w2 in VERB_LEXICON_MULTI:
        if w1 in token_set and w2 in token_set:
            found_verbs.append(f"{w1} {w2}")

    # 3. Targets and Context
    has_app_target = any(app in token_set for app in KNOWN_APPS)
    has_sys_target = any(sys_t in token_set for sys_t in SYSTEM_TARGETS)
    has_file_ext = bool(FILE_EXT_PATTERN.search(text_clean))
    has_conjunction = bool(COMPOUND_CONJ_PATTERN.search(text_clean))

    # 4. Chat Signals
    has_greeting = any(g in token_set for g in GREETING_TOKENS)
    has_conv_prefix = any(bool(p.search(text_clean)) for p in CONV_PREFIX_PATTERNS)

    # 5. Score calculation
    action_score = 0.0
    chat_score = 0.0

    if found_verbs:
        action_score += 0.80
        if has_app_target or has_sys_target or has_file_ext:
            action_score += 0.20
        if has_conjunction:
            action_score += 0.10
    elif has_app_target or has_file_ext:
        # App or file mentioned without an action verb (e.g. "document.pdf", "chrome")
        action_score += 0.40

    if has_greeting and not found_verbs:
        chat_score += 0.85
    elif has_greeting and found_verbs:
        chat_score += 0.10

    if has_conv_prefix and not found_verbs:
        chat_score += 0.85

    action_score = min(1.0, action_score)
    chat_score = min(1.0, chat_score)

    # 6. Intent classification logic
    if action_score >= 0.70 and action_score > chat_score + 0.15:
        return {
            "intent": "action",
            "action_score": action_score,
            "chat_score": chat_score,
            "confidence": action_score,
            "action_verbs": found_verbs,
        }
    elif chat_score >= 0.70 and chat_score > action_score + 0.15:
        return {
            "intent": "chat",
            "action_score": action_score,
            "chat_score": chat_score,
            "confidence": chat_score,
            "action_verbs": [],
        }
    else:
        # Ambiguous command: compute clarification options
        opt1 = f"Perform system action on '{text_clean}'"
        opt2 = f"Search or discuss '{text_clean}' conversationally"
        question = (
            f"Aap '{text_clean}' par koi action perform karna chahte hain ya iske baray mein maloomat chahte hain?"
        )
        return {
            "type": "clarify",
            "intent": "clarify",
            "action_score": action_score,
            "chat_score": chat_score,
            "confidence": round(max(action_score, chat_score), 2),
            "action_verbs": found_verbs,
            "options": [opt1, opt2],
            "question": question,
        }


def _is_conversational_prompt(text: str) -> bool:
    """
    Determines whether a user prompt is purely conversational or informational,
    using word-boundary token matching and confidence scoring.
    """
    classification = classify_command_intent(text)
    return classification["intent"] == "chat"


def _filter_relevant_schemas(user_text: str, schemas: list[dict]) -> list[dict]:
    """
    Filters schemas to relevant subsets based on word-boundary matching.
    On compound commands, gathers relevant schemas across all clauses
    instead of dropping them.
    """
    clauses = decompose_compound_clauses(user_text)
    combined_tokens: set[str] = set()
    for c in clauses:
        combined_tokens.update(re.findall(r"\b[a-zA-Z0-9_\-.]+\b", c.lower()))

    relevant: list[dict] = []
    seen_names: set[str] = set()

    def add_schema(s: dict):
        fn = s.get("function", {}) if "function" in s else s
        name = fn.get("name")
        if name and name not in seen_names:
            seen_names.add(name)
            relevant.append(s)

    for s in schemas:
        fn_name = s.get("function", {}).get("name", "") if "function" in s else s.get("name", "")
        # App management
        if any(t in combined_tokens for t in ("app", "program", "chrome", "notepad", "calculator", "calc", "vlc", "browser")) and fn_name in (
            "launch_app", "close_app", "focus_app", "list_running_apps", "is_app_running"
        ):
            add_schema(s)
        # File management
        elif any(t in combined_tokens for t in ("file", "files", "pdf", "txt", "docx", "doc", "xlsx", "csv", "log")) and fn_name in (
            "open_file", "create_file", "search_files", "read_document", "find_file"
        ):
            add_schema(s)
        # Folders
        elif any(t in combined_tokens for t in ("folder", "folders", "directory", "dir")) and fn_name in (
            "open_folder", "create_folder", "list_folder"
        ):
            add_schema(s)
        # Screenshot & vision
        elif any(t in combined_tokens for t in ("screenshot", "screen", "inspect")) and fn_name in (
            "take_screenshot", "inspect_screen", "get_screen_size"
        ):
            add_schema(s)
        # Typing / keyboard
        elif any(t in combined_tokens for t in ("type", "likho", "key", "press")) and fn_name in (
            "type_text", "press_hotkey", "find_and_interact"
        ):
            add_schema(s)
        # Mouse
        elif any(t in combined_tokens for t in ("click", "mouse", "scroll", "move")) and fn_name in (
            "click_mouse", "move_mouse", "mouse_scroll", "click_ui_element"
        ):
            add_schema(s)

    if relevant:
        return relevant

    primary_names = {"launch_app", "close_app", "open_url", "take_screenshot", "type_text", "search_files"}
    return [s for s in schemas if (s.get("function", {}).get("name") if "function" in s else s.get("name")) in primary_names] or schemas[:6]


def parse_tool_call_json(content: str) -> tuple[Optional[dict], Optional[str]]:
    """
    Extracts a JSON tool call object from raw model content using json.JSONDecoder.raw_decode.
    Replaces brittle greedy regex with robust stream decoding.
    Returns (parsed_call, error_message).
    """
    decoder = json.JSONDecoder()
    pos = 0
    while pos < len(content):
        idx = content.find("{", pos)
        if idx == -1:
            break
        try:
            obj, end_idx = decoder.raw_decode(content, idx)
            if isinstance(obj, dict):
                if "name" in obj:
                    args = obj.get("arguments") or obj.get("parameters") or obj.get("args") or {}
                    if isinstance(args, str):
                        try:
                            args = json.loads(args)
                        except Exception:
                            pass
                    return {"name": obj["name"], "args": args}, None
                elif "function" in obj and isinstance(obj["function"], dict):
                    fn = obj["function"]
                    args = fn.get("arguments") or fn.get("parameters") or fn.get("args") or {}
                    if isinstance(args, str):
                        try:
                            args = json.loads(args)
                        except Exception:
                            pass
                    return {"name": fn.get("name", ""), "args": args}, None
            pos = end_idx
        except json.JSONDecodeError:
            pos = idx + 1

    return None, "No valid JSON tool call object found in content"


def validate_tool_call(call: dict[str, Any], schemas: list[dict]) -> tuple[bool, str, dict[str, Any]]:
    """
    Validates a parsed tool call against registered schemas.
    Checks:
    1. Tool name exists in schemas.
    2. Required parameters are present.
    3. Argument types match the JSON schema.
    Returns (is_valid, error_reason, normalized_call).
    """
    if not isinstance(call, dict) or "name" not in call:
        return False, "Call missing 'name' field", call

    tool_name = call.get("name")
    args = call.get("args", {})
    if not isinstance(args, dict):
        return False, f"Arguments for '{tool_name}' must be an object/dict", call

    matching_schema = None
    for s in schemas:
        fn = s.get("function", {}) if "function" in s else s
        if fn.get("name") == tool_name:
            matching_schema = fn
            break

    if not matching_schema:
        return False, f"Unknown tool '{tool_name}' not found in active schemas", call

    params = matching_schema.get("parameters", {})
    properties = params.get("properties", {})
    required = params.get("required", [])

    # Check required arguments
    for req in required:
        if req not in args or args[req] is None or args[req] == "":
            return False, f"Missing required parameter '{req}' for tool '{tool_name}'", call

    # Check types
    for param_name, val in args.items():
        if param_name in properties:
            expected_type = properties[param_name].get("type")
            if expected_type == "string" and not isinstance(val, str):
                return False, f"Parameter '{param_name}' must be a string, got {type(val).__name__}", call
            elif expected_type == "integer" and not isinstance(val, int):
                if isinstance(val, str) and val.isdigit():
                    args[param_name] = int(val)
                else:
                    return False, f"Parameter '{param_name}' must be an integer, got {type(val).__name__}", call
            elif expected_type == "boolean" and not isinstance(val, bool):
                return False, f"Parameter '{param_name}' must be a boolean, got {type(val).__name__}", call
            elif expected_type == "array" and not isinstance(val, list):
                return False, f"Parameter '{param_name}' must be an array/list, got {type(val).__name__}", call
            elif expected_type == "object" and not isinstance(val, dict):
                return False, f"Parameter '{param_name}' must be an object/dict, got {type(val).__name__}", call

    return True, "", {"name": tool_name, "args": args}


def _get_adaptive_timeout() -> float:
    """Returns 30.0s for the first (cold) request, 8.0s for subsequent requests."""
    return 30.0 if not _OLLAMA_WARMED else 8.0


def _call_ollama(body: dict, timeout_val: float = 30.0) -> Tuple[Optional[dict], Optional[str]]:
    # Prompt P7: Enforce physical RAM headroom (refuse call when free RAM < 500 MB)
    from config.budget import check_system_ram_for_llm, MODEL_CALL_LOCK
    from tools.system_sentry import is_low_ram_mode
    from tools.budget_governor import heavy_slot

    ram_ok, avail_mb, _ = check_system_ram_for_llm()
    if not ram_ok:
        return None, f"Refused: Available RAM {avail_mb:.1f} MB is below 500 MB headroom"

    # Enforce options bounds: small num_ctx and configurable keep_alive sent on EVERY request
    if "options" not in body or not isinstance(body.get("options"), dict):
        body["options"] = {}
    requested_ctx = body["options"].get("num_ctx", GOKU_NUM_CTX)
    body["options"]["num_ctx"] = 512 if is_low_ram_mode() else int(requested_ctx)
    if "num_batch" not in body["options"]:
        body["options"]["num_batch"] = GOKU_NUM_BATCH
    body["keep_alive"] = GOKU_KEEP_ALIVE

    # Model calls run inside budget_governor.heavy_slot() as cpu_class "heavy"
    try:
        with heavy_slot(timeout=timeout_val, tool_name="ollama_model"):
            # Enforce single model call at a time via global concurrency lock
            with MODEL_CALL_LOCK:
                try:
                    req = urllib.request.Request(
                        OLLAMA_URL,
                        data=json.dumps(body).encode("utf-8"),
                        headers={"Content-Type": "application/json"},
                    )
                    with urllib.request.urlopen(req, timeout=timeout_val) as resp:
                        if resp.status == 200:
                            return json.loads(resp.read().decode("utf-8")), None
                except urllib.error.HTTPError as he:
                    if he.code == 503 or "loading" in str(he).lower():
                        return None, "model is loading"
                    return None, f"HTTPError {he.code}"
                except Exception as ex:
                    ex_str = str(ex).lower()
                    if "loading" in ex_str or "timed out" in ex_str:
                        return None, "model is loading"
                    return None, str(ex)
            return None, "Failed to connect to Ollama"
    except TimeoutError as te:
        return None, f"Heavy slot timeout: {te}"


def ask_llm(user_text: str, tool_schemas: list[dict]) -> dict:
    """
    Sends the command to the local model along with the available tools.
    Handles compound clause decomposition, schema validation, 1-shot retry,
    adaptive timeouts, and execution tracing.
    """
    global _OLLAMA_WARMED

    allowed, block_reason = is_model_call_allowed()
    if not allowed:
        log_routing_trace(user_text, layer="llm", reason=block_reason, confidence=0.0)
        msg = f"LLM disabled: {block_reason}" if "LLM disabled" not in block_reason else block_reason
        return {"type": "message", "text": msg, "success": False}

    # 1. Intent & Ambiguity check
    intent_info = classify_command_intent(user_text)
    if intent_info.get("intent") == "clarify":
        log_routing_trace(
            user_text,
            layer="clarify",
            reason="Ambiguous command lacking clear action or conversational context",
            confidence=intent_info.get("confidence", 0.5),
        )
        return {
            "type": "clarify",
            "options": intent_info.get("options", []),
            "question": intent_info.get("question", "Aap kya karna chahte hain?"),
        }

    # 2. Compound commands decomposition
    clauses = decompose_compound_clauses(user_text)
    if len(clauses) > 1:
        calls = []
        for clause in clauses:
            sub_res = ask_llm(clause, tool_schemas)
            if sub_res.get("type") == "tool_call":
                calls.append({"name": sub_res["name"], "args": sub_res["args"]})
            elif sub_res.get("type") == "multi_tool_call":
                calls.extend(sub_res.get("calls", []))
        if calls:
            log_routing_trace(
                user_text,
                layer="planner",
                reason=f"Decomposed into {len(clauses)} compound clauses and routed sequentially",
                confidence=0.95,
            )
            return {"type": "multi_tool_call", "calls": calls, "clauses": clauses}

    user_text = user_text[:MAX_INPUT_CHARS]
    is_conv = intent_info.get("intent") == "chat"
    active_tools = None if is_conv else _filter_relevant_schemas(user_text, tool_schemas)
    sys_prompt = CONVERSATIONAL_SYSTEM_PROMPT if is_conv else SYSTEM_PROMPT

    payload: dict = {
        "model": MODEL,
        "messages": [
            {"role": "system", "content": sys_prompt},
            {"role": "user", "content": user_text},
        ],
        "options": ollama_options(
            temperature=0.0,
            num_predict=NUM_PREDICT_CAP,
        ),
        "keep_alive": GOKU_KEEP_ALIVE,
        "stream": False,
    }
    if active_tools:
        payload["tools"] = active_tools

    _get_adaptive_timeout()

    def _log_llm_call(prompt_tokens: int, comp_tokens: int, latency_ms: float, status: str = "success") -> None:
        rec = {
            "timestamp": time.time(),
            "command": user_text,
            "prompt_tokens": prompt_tokens,
            "completion_tokens": comp_tokens,
            "latency_ms": round(latency_ms, 2),
            "model": MODEL,
            "call_count": 1,
            "status": status,
        }
        try:
            log_path = Path("reports/llm_calls.jsonl")
            log_path.parent.mkdir(parents=True, exist_ok=True)
            with open(log_path, "a", encoding="utf-8") as f_log:
                f_log.write(json.dumps(rec) + "\n")
        except Exception:
            pass

    t0 = time.time()
    prompt_tokens = int(len(json.dumps(payload["messages"]).split()) * 1.3)
    resp_json, err = _call_ollama(payload)
    latency_ms = (time.time() - t0) * 1000
    comp_tokens = int(len(str(resp_json).split()) * 1.3) if resp_json else 0
    _log_llm_call(prompt_tokens, comp_tokens, latency_ms, status="success" if resp_json else f"error: {err}")

    if err == "model is loading":
        log_routing_trace(user_text, layer="llm", reason="Ollama reports model is loading", confidence=0.0)
        return {"type": "message", "text": "model is loading"}

    if not resp_json:
        log_routing_trace(user_text, layer="clarify", reason="LLM service unavailable", confidence=0.0)
        return {
            "type": "clarify",
            "options": ["Check if Ollama service is running", "Retry command manually"],
            "question": "Local Ollama model service is currently unavailable. Please verify it is running.",
        }

    _OLLAMA_WARMED = True
    msg = resp_json.get("message", {})

    # Native Ollama tool calls
    native_calls = msg.get("tool_calls")
    if native_calls:
        validated_calls = []
        for nc in native_calls:
            fn = nc.get("function", {})
            call_obj = {"name": fn.get("name"), "args": fn.get("arguments", {})}
            ok, v_err, norm_call = validate_tool_call(call_obj, tool_schemas)
            if ok:
                validated_calls.append(norm_call)
        if len(validated_calls) == 1:
            log_routing_trace(user_text, layer="llm", reason="Native tool call parsed and validated", confidence=1.0)
            return {"type": "tool_call", "name": validated_calls[0]["name"], "args": validated_calls[0]["args"]}
        elif len(validated_calls) > 1:
            log_routing_trace(user_text, layer="llm", reason=f"Native {len(validated_calls)} tool calls validated", confidence=1.0)
            return {"type": "multi_tool_call", "calls": validated_calls}

    content = msg.get("content", "").strip()

    if not is_conv and content:
        # Structured content tool call parsing via raw_decode
        parsed_call, parse_err = parse_tool_call_json(content)
        if parsed_call:
            ok, v_err, norm_call = validate_tool_call(parsed_call, tool_schemas)
            if ok:
                log_routing_trace(user_text, layer="llm", reason="JSON tool call parsed via raw_decode and validated", confidence=1.0)
                return {"type": "tool_call", "name": norm_call["name"], "args": norm_call["args"]}

            # Strictly 1 model call per command: no second retry call. Clarify immediately.
            log_routing_trace(user_text, layer="clarify", reason=f"Tool call validation failed: {v_err}", confidence=0.0)
            return {
                "type": "clarify",
                "options": [
                    f"Specify full parameters for '{parsed_call.get('name')}'",
                    "Rephrase request with clearer arguments",
                ],
                "question": f"Could not determine valid parameters for '{parsed_call.get('name')}': {v_err}. Please clarify.",
            }
        elif "{" in content or "}" in content:
            log_routing_trace(user_text, layer="clarify", reason=f"Invalid JSON syntax in model response: {parse_err}", confidence=0.0)
            return {
                "type": "clarify",
                "options": ["Rephrase request with clearer arguments"],
                "question": "Model response was not valid JSON. Could you please clarify your request?",
            }

    log_routing_trace(user_text, layer="llm", reason="Conversational reply generated by LLM", confidence=0.85)
    return {"type": "message", "text": content}


def ask_conversational_llm(
    user_text: str, context_notes: str | None = None, timeout_seconds: float = 8.0
) -> str | None:
    """
    Sends conversational inquiries directly to the local Ollama instance (qwen2.5:0.5b).
    Returns the response string, or 'model is loading' if Ollama is still initializing.
    """
    allowed, block_reason = is_model_call_allowed()
    if not allowed:
        return f"LLM disabled: {block_reason}" if "LLM disabled" not in block_reason else block_reason

    sys_prompt = (
        "You are a helpful, polite, and concise local Windows desktop AI assistant named GOKU. "
        "Answer the user directly, briefly, and conversationally in the same language they used (English or Roman Urdu)."
    )
    if context_notes:
        sys_prompt += f" Context of previous action: {context_notes}"

    user_text = user_text[:MAX_INPUT_CHARS]
    payload = {
        "model": MODEL,
        "messages": [
            {"role": "system", "content": sys_prompt},
            {"role": "user", "content": user_text},
        ],
        "options": ollama_options(
            temperature=0.0,
            num_predict=NUM_PREDICT_CAP,
        ),
        "keep_alive": GOKU_KEEP_ALIVE,
        "stream": False,
    }

    result, err = _call_ollama(payload, timeout_val=timeout_seconds)
    if err == "model is loading":
        return "model is loading"
    if result:
        return result.get("message", {}).get("content", "").strip()
    return None


# ==============================================================================
# PROMPT R7: CONSTRAINED JSON OUTPUT ENGINE (FIXED SCHEMA, 1 RETRY, TELEMETRY)
# ==============================================================================

ALLOWED_INTENT_IDS = [
    "launch_app", "close_app", "open_file", "create_file", "delete_file",
    "create_folder", "open_folder", "search_files", "search_web",
    "execute_command", "get_wifi_status", "get_battery_status",
    "capture_screen", "get_processes", "type_text", "click_ui_element",
    "chat", "clarify", "refuse"
]

CONSTRAINED_OUTPUT_SCHEMA = {
    "type": "object",
    "properties": {
        "intent": {
            "type": "string",
            "enum": ALLOWED_INTENT_IDS
        },
        "slots": {
            "type": "object"
        },
        "confidence": {
            "type": "number",
            "minimum": 0.0,
            "maximum": 1.0
        }
    },
    "required": ["intent", "slots", "confidence"]
}

_JSON_TELEMETRY = {
    "total_queries": 0,
    "first_attempt_invalid": 0,
    "retry_success": 0,
    "fatal_invalid": 0,
}


def get_invalid_json_metrics() -> dict:
    total = _JSON_TELEMETRY["total_queries"]
    invalid = _JSON_TELEMETRY["first_attempt_invalid"]
    fatal = _JSON_TELEMETRY["fatal_invalid"]
    rate = (invalid / total * 100.0) if total > 0 else 0.0
    fatal_rate = (fatal / total * 100.0) if total > 0 else 0.0
    return {
        "total_queries": total,
        "first_attempt_invalid": invalid,
        "retry_success": _JSON_TELEMETRY["retry_success"],
        "fatal_invalid": fatal,
        "invalid_json_rate_pct": round(rate, 2),
        "fatal_invalid_rate_pct": round(fatal_rate, 2),
    }


def reset_invalid_json_metrics() -> None:
    _JSON_TELEMETRY["total_queries"] = 0
    _JSON_TELEMETRY["first_attempt_invalid"] = 0
    _JSON_TELEMETRY["retry_success"] = 0
    _JSON_TELEMETRY["fatal_invalid"] = 0


def validate_constrained_json(content: str) -> tuple[bool, str, Optional[dict]]:
    """Validates raw output against fixed schema: intent in allowed list, slots dict, confidence float [0, 1]."""
    if not content or not content.strip():
        return False, "Empty response received", None
    try:
        obj = json.loads(content)
    except Exception as e:
        return False, f"JSON parse error: {e}", None

    if not isinstance(obj, dict):
        return False, "Output must be a JSON object", None

    intent = obj.get("intent")
    if intent not in ALLOWED_INTENT_IDS:
        return False, f"Intent '{intent}' not in allowed list {ALLOWED_INTENT_IDS}", None

    slots = obj.get("slots")
    if not isinstance(slots, dict):
        return False, f"Slots must be an object/dict, got {type(slots).__name__}", None

    conf = obj.get("confidence")
    if not isinstance(conf, (int, float)) or not (0.0 <= float(conf) <= 1.0):
        return False, f"Confidence must be a float between 0.0 and 1.0, got {conf}", None

    return True, "", {
        "intent": intent,
        "slots": slots,
        "confidence": float(conf),
        "type": intent,
    }


def ask_constrained_json_llm(
    user_text: str,
    timeout_seconds: float = 12.0,
    num_ctx: int = GOKU_NUM_CTX,
    keep_alive: int = GOKU_KEEP_ALIVE,
    num_predict: int = NUM_PREDICT_CAP,
) -> dict:
    """
    R7 Constrained Output Engine:
    The model must return only JSON from the fixed schema (intent id, slots, confidence).
    Invalid JSON = exactly ONE retry with error feedback.
    If retry still invalid = clarification question (NEVER a free-text action).
    Measures the invalid-JSON rate.
    """
    _JSON_TELEMETRY["total_queries"] += 1
    allowed, block_reason = is_model_call_allowed()
    if not allowed:
        msg = f"LLM disabled: {block_reason}" if "LLM disabled" not in block_reason else block_reason
        return {
            "success": False,
            "type": "message",
            "text": msg,
            "error": msg,
            "blocked": True,
            "reason": block_reason,
            "parsed": None,
            "raw": "",
        }

    user_text = user_text[:MAX_INPUT_CHARS]
    sys_prompt = (
        "You are GOKU, a local desktop control agent. Return ONLY a valid JSON object matching "
        "the fixed schema: {\"intent\": \"<intent_id>\", \"slots\": {<args>}, \"confidence\": <float 0.0-1.0>}.\n"
        f"Allowed intents: {json.dumps(ALLOWED_INTENT_IDS)}"
    )

    payload = {
        "model": MODEL,
        "messages": [
            {"role": "system", "content": sys_prompt},
            {"role": "user", "content": user_text},
        ],
        "format": CONSTRAINED_OUTPUT_SCHEMA,
        "options": ollama_options(
            temperature=0.0,
            num_predict=num_predict,
            extra={"num_ctx": num_ctx} if num_ctx != GOKU_NUM_CTX else None,
        ),
        "keep_alive": keep_alive,
        "stream": False,
    }

    # Attempt 1
    result1, _ = _call_ollama(payload, timeout_val=timeout_seconds)
    content_raw = result1.get("message", {}).get("content", "").strip() if result1 else ""

    valid, err_msg, parsed = validate_constrained_json(content_raw)
    if valid and parsed:
        return {"success": True, "parsed": parsed, "raw": content_raw, "retried": False}

    # Attempt 1 failed -> Record invalid attempt and trigger ONE retry
    _JSON_TELEMETRY["first_attempt_invalid"] += 1

    retry_payload = {
        "model": MODEL,
        "messages": [
            {"role": "system", "content": sys_prompt},
            {"role": "user", "content": user_text},
            {"role": "assistant", "content": content_raw or "{}"},
            {
                "role": "user",
                "content": (
                    f"ERROR: Your response was invalid: {err_msg}. "
                    "Output ONLY valid JSON adhering strictly to: {\"intent\": \"<intent_id>\", \"slots\": {}, \"confidence\": 1.0}. "
                    "No conversational commentary or markdown."
                ),
            },
        ],
        "format": CONSTRAINED_OUTPUT_SCHEMA,
        "options": ollama_options(
            temperature=0.0,
            num_predict=num_predict,
            extra={"num_ctx": num_ctx} if num_ctx != GOKU_NUM_CTX else None,
        ),
        "keep_alive": keep_alive,
        "stream": False,
    }

    # Attempt 2 (Retry)
    result2, _ = _call_ollama(retry_payload, timeout_val=timeout_seconds)
    retry_raw = result2.get("message", {}).get("content", "").strip() if result2 else ""

    valid2, err_msg2, parsed2 = validate_constrained_json(retry_raw)
    if valid2 and parsed2:
        _JSON_TELEMETRY["retry_success"] += 1
        return {"success": True, "parsed": parsed2, "raw": retry_raw, "retried": True}

    # Retry also failed -> Fatal invalid JSON
    _JSON_TELEMETRY["fatal_invalid"] += 1
    # Fallback to clarification question. NEVER a free-text action.
    return {
        "success": False,
        "type": "clarify",
        "intent": "clarify",
        "slots": {},
        "confidence": 0.0,
        "question": "Could not structure command into a valid system intent. Could you please clarify what action you want to perform?",
        "options": ["Specify application or file name", "Rephrase request simply"],
        "invalid_json": True,
        "error": f"Attempt 1 failed ({err_msg}); Retry failed ({err_msg2})",
        "raw": retry_raw or content_raw,
    }


def ask_structured_output_llm(
    user_text: str,
    schema: Optional[dict] = None,
    tools_subset: Optional[list[str]] = None,
    timeout_seconds: float = 15.0,
) -> dict:
    """
    Level 1 Structured output with JSON schema enforcement.
    Uses ask_constrained_json_llm for fixed schema requests, or general schema validation.
    """
    allowed, block_reason = is_model_call_allowed()
    if not allowed:
        msg = f"LLM disabled: {block_reason}" if "LLM disabled" not in block_reason else block_reason
        return {
            "success": False,
            "error": msg,
            "type": "message",
            "text": msg,
            "raw": "",
            "parsed": None,
        }

    if schema is None and tools_subset is None:
        res = ask_constrained_json_llm(user_text, timeout_seconds=timeout_seconds)
        if res.get("parsed"):
            return {"success": True, "parsed": res["parsed"], "raw": res.get("raw", "")}
        elif res.get("type") == "clarify":
            return {"success": True, "parsed": res, "raw": res.get("raw", "")}
        return {"success": False, "error": res.get("error", "Failed constrained JSON"), "raw": res.get("raw", "")}

    from tools.registry import generate_tool_registry_json_schema

    target_schema = schema or generate_tool_registry_json_schema(tools_subset=tools_subset)

    sys_prompt = (
        "You are GOKU, a local desktop control agent. Return a valid JSON object matching "
        "the provided JSON schema. If the command requires a tool, emit type='tool_call' with "
        "the tool name and arguments. If it is general chat, emit type='chat'. If ambiguous, "
        "emit type='clarify' with a clarifying question."
    )

    user_text = user_text[:MAX_INPUT_CHARS]
    payload = {
        "model": MODEL,
        "messages": [
            {"role": "system", "content": sys_prompt},
            {"role": "user", "content": user_text},
        ],
        "format": target_schema,
        "options": ollama_options(
            temperature=0.0,
            num_predict=NUM_PREDICT_CAP,
        ),
        "keep_alive": OLLAMA_KEEP_ALIVE,
        "stream": False,
    }

    result, err = _call_ollama(payload, timeout_val=timeout_seconds)
    if result:
        content = result.get("message", {}).get("content", "").strip()
        try:
            parsed = json.loads(content)
            return {"success": True, "parsed": parsed, "raw": content}
        except json.JSONDecodeError as jde:
            return {"success": False, "error": f"JSON decode failed: {jde}", "raw": content}
    return {"success": False, "error": err or "No response from Ollama", "raw": ""}

