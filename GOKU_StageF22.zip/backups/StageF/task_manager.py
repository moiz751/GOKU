"""
Persistent task manager (Stage E, spec section 10 "autonomous agent").

A task is a list of steps (tool + args + depends_on + optional alternatives/retries). Steps run through the normal executor, so the
safety policy, confirmation, budget governor and emergency stop apply to every step. The manager adds:

  * persistence    every state change is checkpointed (tools.safe_state); after a crash a task that was running becomes "interrupted" and can be resumed
  * honesty        a step counts as done only when the tool result has success AND verified; success without proof is "unverified" and its
                   dependants are skipped; the task is "completed" only when every required step is done
  * control        pause / resume / cancel take effect at step boundaries; emergency stop interrupts; low RAM defers
  * confirmation   a step that needs confirmation parks the task in "waiting_confirmation"; only confirm(..., True) from the person continues it.
                   Steps from non-user origins (file/web/screen/model) that change state always need confirmation
  * conflicts      one task at a time owns the GUI; file-writing steps lock their path; others wait (no deadlock: locks are released on pause/finish)
  * priority       higher priority first, then oldest

No threads and no timers unless start_background() is called; that worker exists only while something is runnable and exits when idle.
"""
from __future__ import annotations

import os
import threading
import time
import uuid
from typing import Any, Callable, Dict, List, Optional

try:
    from tools import safe_state
except Exception:  # pragma: no cover
    safe_state = None  # type: ignore

TERMINAL = ("completed", "failed", "cancelled", "unverified")
GUI_TOOLS = {"click_element_by_text", "click_ui_element", "click_mouse", "mouse_click", "find_and_interact", "interact_form_element", "type_text", "type_desktop_text",
             "press_hotkey", "send_keyboard_input", "launch_app", "open_file", "open_url", "manage_window", "close_app", "restart_app", "navigate_context_menu"}
FILE_TOOLS = {"write_file", "create_file", "delete_file", "move_file", "replace_file", "rename_file", "copy_file", "extract_archive", "delete_folder", "create_folder"}
_PATH_KEYS = ("path", "file_path", "dest", "destination", "new_path", "target", "folder")


def _default_runner(tool: str, args: dict, confirmed: bool = False) -> dict:
    from executor.executor import run_tool_call
    return run_tool_call(tool, args, confirmed=confirmed)


def _summ(res: Any) -> Dict[str, Any]:
    r = res if isinstance(res, dict) else {"message": str(res)}
    return {"success": bool(r.get("success")), "verified": bool(r.get("verified")), "status": str(r.get("status", "")), "message": str(r.get("message", ""))[:300]}


class TaskManager:
    def __init__(self, runner: Optional[Callable[..., dict]] = None, state_dir: Any = None, clock: Callable[[], float] = time.time,
                 stop_fn: Optional[Callable[[], bool]] = None, pressure_fn: Optional[Callable[[], str]] = None):
        self.runner = runner or _default_runner
        self.state_dir = state_dir
        self.clock = clock
        self._stop_fn = stop_fn
        self._pressure_fn = pressure_fn
        self._lock = threading.RLock()
        self._tasks: Dict[str, Dict[str, Any]] = {}
        self._worker: Optional[threading.Thread] = None
        self.recover()

    # ------------------------------------------------------------------ persistence
    def _save(self, t: Dict[str, Any]) -> None:
        t["updated"] = self.clock()
        if safe_state is None:
            return
        try:
            if t["status"] in TERMINAL:
                safe_state.save_checkpoint(t["id"], t, "done", self.state_dir)
                safe_state.complete_checkpoint(t["id"], self.state_dir)
            else:
                safe_state.save_checkpoint(t["id"], t, "running" if t["status"] in ("queued", "running") else "paused", self.state_dir)
        except Exception:
            t["persist_error"] = True

    def recover(self) -> List[str]:
        """Load unfinished tasks. A task marked running by a process that no longer exists becomes 'interrupted' (resume() continues it)."""
        out: List[str] = []
        if safe_state is None:
            return out
        try:
            for item in safe_state.list_incomplete(self.state_dir):
                cp = safe_state.load_checkpoint(item["task_id"], self.state_dir)
                st = (cp or {}).get("state") or {}
                if not st.get("steps") or st.get("id") in self._tasks:
                    continue
                if st["status"] in ("queued", "running") and not (st.get("pid") == os.getpid() or safe_state._pid_alive(st.get("pid"))):
                    for s in st["steps"]:
                        if s["status"] == "running":
                            s["status"] = "pending"
                    st["status"] = "interrupted"
                    st["note"] = "previous run ended before the task finished; resume to continue (finished steps are not repeated)"
                self._tasks[st["id"]] = st
                out.append(st["id"])
        except Exception:
            pass
        return out

    # ------------------------------------------------------------------ submit / control
    def submit(self, title: str, steps: List[Dict[str, Any]], origin: str = "user", priority: int = 5, task_id: Optional[str] = None) -> str:
        if not steps:
            raise ValueError("a task needs at least one step")
        norm: List[Dict[str, Any]] = []
        ids = set()
        for i, s in enumerate(steps):
            sid = str(s.get("id") or f"s{i + 1}")
            if sid in ids:
                raise ValueError(f"duplicate step id {sid}")
            ids.add(sid)
            tool = str(s.get("tool") or "")
            if not tool:
                raise ValueError(f"step {sid} has no tool")
            norm.append({"id": sid, "tool": tool, "args": dict(s.get("args") or {}), "depends_on": [str(d) for d in s.get("depends_on", [])],
                         "alternatives": [{"tool": a.get("tool", tool), "args": dict(a.get("args") or {})} for a in s.get("alternatives", [])],
                         "retries": int(s.get("retries", 1)), "required": bool(s.get("required", True)), "status": "pending", "attempts": 0, "result": None,
                         "origin": str(s.get("origin") or origin)})
        for s in norm:
            for d in s["depends_on"]:
                if d not in ids:
                    raise ValueError(f"step {s['id']} depends on unknown step {d}")
        if self._has_cycle(norm):
            raise ValueError("steps contain a dependency cycle")
        with self._lock:
            tid = task_id or f"task-{uuid.uuid4().hex[:8]}"
            t = {"id": tid, "title": str(title)[:120], "origin": origin, "priority": int(priority), "status": "queued", "steps": norm, "created": self.clock(),
                 "pid": os.getpid(), "note": "", "log": []}
            self._tasks[tid] = t
            self._save(t)
            return tid

    @staticmethod
    def _has_cycle(steps: List[Dict[str, Any]]) -> bool:
        deps = {s["id"]: set(s["depends_on"]) for s in steps}
        done: set = set()
        while deps:
            ready = [k for k, v in deps.items() if v <= done]
            if not ready:
                return True
            for k in ready:
                done.add(k)
                del deps[k]
        return False

    def _get(self, tid: str) -> Dict[str, Any]:
        if tid not in self._tasks:
            raise KeyError(f"no such task: {tid}")
        return self._tasks[tid]

    def pause(self, tid: str) -> bool:
        with self._lock:
            t = self._get(tid)
            if t["status"] in ("queued", "running", "waiting_confirmation", "interrupted"):
                t["status"] = "paused" if t["status"] != "waiting_confirmation" else "waiting_confirmation"
                t["log"].append("paused")
                self._save(t)
                return True
            return False

    def resume(self, tid: str) -> bool:
        with self._lock:
            t = self._get(tid)
            if t["status"] in ("paused", "interrupted"):
                t["status"] = "queued"
                t["pid"] = os.getpid()
                t["log"].append("resumed")
                self._save(t)
                return True
            return False

    def cancel(self, tid: str) -> bool:
        with self._lock:
            t = self._get(tid)
            if t["status"] in TERMINAL:
                return False
            for s in t["steps"]:
                if s["status"] in ("pending", "waiting_confirmation"):
                    s["status"] = "skipped"
            t["status"] = "cancelled"
            t["log"].append("cancelled by user; finished steps are NOT undone")
            self._save(t)
            return True

    def confirm(self, tid: str, step_id: Optional[str], yes: bool) -> bool:
        """The person's decision for the step that is waiting. Never called automatically."""
        with self._lock:
            t = self._get(tid)
            if t["status"] != "waiting_confirmation":
                return False
            s = next((x for x in t["steps"] if x["status"] == "waiting_confirmation" and (step_id in (None, "", x["id"]))), None)
            if s is None:
                return False
            if yes:
                s["status"] = "pending"
                s["confirmed"] = True
                t["status"] = "queued"
                t["log"].append(f"{s['id']} confirmed by user")
            else:
                s["status"] = "failed"
                s["result"] = {"success": False, "verified": False, "status": "declined", "message": "declined by the user"}
                t["status"] = "queued"
                t["log"].append(f"{s['id']} declined by user")
                self._skip_dependants(t)
            self._save(t)
            return True

    # ------------------------------------------------------------------ queries
    def list(self) -> List[Dict[str, Any]]:
        with self._lock:
            return [{"id": t["id"], "title": t["title"], "status": t["status"], "priority": t["priority"], "origin": t["origin"],
                     "done": sum(s["status"] == "done" for s in t["steps"]), "total": len(t["steps"])} for t in self._tasks.values()]

    def status(self, tid: str) -> Dict[str, Any]:
        with self._lock:
            t = self._get(tid)
            return {"id": t["id"], "title": t["title"], "status": t["status"], "note": t.get("note", ""),
                    "steps": [{"id": s["id"], "tool": s["tool"], "status": s["status"], "attempts": s["attempts"], "result": s["result"]} for s in t["steps"]]}

    def report(self, tid: str) -> str:
        """Honest plain-text report: what was proven, what was not."""
        with self._lock:
            t = self._get(tid)
            lines = [f"Task {t['id']} - {t['title']}: {t['status'].upper()}"]
            for s in t["steps"]:
                r = s["result"] or {}
                mark = {"done": "VERIFIED", "failed": "FAILED", "unverified": "NOT VERIFIED", "skipped": "SKIPPED", "pending": "NOT RUN",
                        "waiting_confirmation": "WAITING FOR YOUR CONFIRMATION"}.get(s["status"], s["status"])
                lines.append(f"- {s['id']} {s['tool']}: {mark}" + (f" - {r.get('message')}" if r.get("message") else ""))
            if t["status"] == "unverified":
                lines.append("Some required steps ran but could not be proven; check them yourself before relying on the result.")
            if t.get("note"):
                lines.append(t["note"])
            return "\n".join(lines)

    # ------------------------------------------------------------------ scheduling
    def _locks_for(self, s: Dict[str, Any]) -> List[str]:
        out = []
        if s["tool"] in GUI_TOOLS:
            out.append("gui")
        if s["tool"] in FILE_TOOLS:
            for k in _PATH_KEYS:
                if s["args"].get(k):
                    out.append("file:" + str(s["args"][k]).lower().replace("\\", "/"))
        return out

    def _held_by_others(self, me: str) -> set:
        held = set()
        for t in self._tasks.values():
            if t["id"] != me and t["status"] == "running":
                held |= set(t.get("locks", []))
        return held

    def _next_step(self, t: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        st = {s["id"]: s["status"] for s in t["steps"]}
        for s in t["steps"]:
            if s["status"] == "pending" and all(st[d] == "done" for d in s["depends_on"]):
                return s
        return None

    def _skip_dependants(self, t: Dict[str, Any]) -> None:
        changed = True
        while changed:
            changed = False
            st = {s["id"]: s["status"] for s in t["steps"]}
            for s in t["steps"]:
                if s["status"] == "pending" and any(st[d] in ("failed", "unverified", "skipped") for d in s["depends_on"]):
                    s["status"] = "skipped"
                    s["result"] = {"success": False, "verified": False, "status": "skipped", "message": "skipped because an earlier step did not finish verified"}
                    changed = True

    def _finish_if_done(self, t: Dict[str, Any]) -> None:
        if any(s["status"] in ("pending", "waiting_confirmation") for s in t["steps"]):
            return
        req = [s for s in t["steps"] if s["required"]]
        if all(s["status"] == "done" for s in req):
            t["status"] = "completed"
        elif any(s["status"] == "failed" for s in req):
            t["status"] = "failed"
        elif any(s["status"] == "unverified" for s in req):
            t["status"] = "unverified"
        else:
            t["status"] = "failed"
        t["locks"] = []

    def _stop_requested(self) -> bool:
        try:
            if self._stop_fn is not None:
                return bool(self._stop_fn())
            from tools.emergency_stop import is_stop_requested
            return bool(is_stop_requested())
        except Exception:
            return False

    def _low_ram(self) -> bool:
        try:
            if self._pressure_fn is not None:
                return self._pressure_fn() in ("critical", "emergency")
            from tools import workload_modes
            return workload_modes.current_mode() == workload_modes.EMERGENCY
        except Exception:
            return False

    def _runnable(self) -> List[Dict[str, Any]]:
        out = []
        for t in self._tasks.values():
            if t["status"] not in ("queued", "running"):
                continue
            s = self._next_step(t)
            if s is None:
                continue
            if set(self._locks_for(s)) & self._held_by_others(t["id"]):
                continue
            out.append(t)
        return sorted(out, key=lambda t: (-t["priority"], t["created"]))

    def has_runnable(self) -> bool:
        with self._lock:
            return bool(self._runnable())

    def tick(self) -> Optional[Dict[str, Any]]:
        """Runs ONE step of the best runnable task. Returns what happened, or None when nothing is runnable."""
        with self._lock:
            if self._stop_requested():
                for t in self._tasks.values():
                    if t["status"] in ("queued", "running"):
                        t["status"] = "interrupted"
                        t["note"] = "emergency stop was requested; resume when it is cleared"
                        self._save(t)
                return {"event": "emergency_stop"}
            if self._low_ram():
                return {"event": "deferred", "reason": "low_ram"}
            cand = self._runnable()
            if not cand:
                for t in list(self._tasks.values()):
                    if t["status"] in ("queued", "running"):
                        self._skip_dependants(t)
                        self._finish_if_done(t)
                        self._save(t)
                return None
            t = cand[0]
            s = self._next_step(t)
            assert s is not None
            t["status"] = "running"
            t["locks"] = sorted(set(t.get("locks", [])) | set(self._locks_for(s)))
        return self._run_step(t, s)

    def _needs_origin_confirmation(self, s: Dict[str, Any]) -> bool:
        try:
            from security.untrusted import origin_needs_confirmation
            return origin_needs_confirmation(s.get("origin", "user"), s["tool"]) and not s.get("confirmed")
        except Exception:
            return s.get("origin", "user") != "user" and not s.get("confirmed")

    def _run_step(self, t: Dict[str, Any], s: Dict[str, Any]) -> Dict[str, Any]:
        if self._needs_origin_confirmation(s):
            return self._wait(t, s, f"This step came from {s.get('origin')} content, not from you. Confirm '{s['tool']}' before it runs.")
        variants = [{"tool": s["tool"], "args": s["args"]}] + s["alternatives"]
        last: Dict[str, Any] = {}
        for vi, v in enumerate(variants):
            tries = (s["retries"] + 1) if vi == 0 else 1
            for _ in range(tries):
                s["attempts"] += 1
                try:
                    res = self.runner(v["tool"], v["args"], confirmed=bool(s.get("confirmed")))
                except Exception as exc:
                    res = {"success": False, "verified": False, "status": "failed", "message": f"{type(exc).__name__}: {exc}"}
                last = res if isinstance(res, dict) else {"message": str(res)}
                st = str(last.get("status", ""))
                if st == "pending_confirmation" or last.get("needs_confirmation"):
                    return self._wait(t, s, str(last.get("message", "confirmation required")))
                if st == "blocked_by_policy":
                    return self._end_step(t, s, "failed", last)
                if last.get("success") and last.get("verified"):
                    return self._end_step(t, s, "done", last)
                if last.get("success") and not last.get("verified"):
                    break  # ran but unproven: do not repeat an action that may already have happened
                if self._stop_requested():
                    s["status"] = "pending"
                    t["status"] = "interrupted"
                    self._save(t)
                    return {"event": "emergency_stop", "task": t["id"], "step": s["id"]}
            if last.get("success") and not last.get("verified"):
                return self._end_step(t, s, "unverified", last)
        return self._end_step(t, s, "failed", last)

    def _wait(self, t: Dict[str, Any], s: Dict[str, Any], msg: str) -> Dict[str, Any]:
        s["status"] = "waiting_confirmation"
        s["result"] = {"success": False, "verified": False, "status": "pending_confirmation", "message": msg[:300]}
        t["status"] = "waiting_confirmation"
        t["locks"] = []
        self._save(t)
        return {"event": "waiting_confirmation", "task": t["id"], "step": s["id"], "message": msg}

    def _end_step(self, t: Dict[str, Any], s: Dict[str, Any], status: str, res: Dict[str, Any]) -> Dict[str, Any]:
        s["status"] = status
        s["result"] = _summ(res)
        s["confirmed"] = False  # a confirmation is for one run only
        with self._lock:
            if status != "done":
                self._skip_dependants(t)
            self._finish_if_done(t)
            if t["status"] in TERMINAL or t["status"] == "paused":
                t["locks"] = []
            self._save(t)
        return {"event": "step", "task": t["id"], "step": s["id"], "status": status, "task_status": t["status"]}

    def run_until_idle(self, max_steps: int = 200) -> List[Dict[str, Any]]:
        out: List[Dict[str, Any]] = []
        for _ in range(max_steps):
            ev = self.tick()
            if ev is None:
                break
            out.append(ev)
            if ev["event"] in ("emergency_stop", "deferred"):
                break
        return out

    def start_background(self) -> bool:
        """Starts a worker only if something is runnable; it exits when nothing is. No idle polling."""
        with self._lock:
            if (self._worker and self._worker.is_alive()) or not self._runnable():
                return False
            self._worker = threading.Thread(target=self.run_until_idle, name="goku-task-worker", daemon=True)
            self._worker.start()
            return True

    def wait_background(self, timeout: float = 30.0) -> None:
        w = self._worker
        if w:
            w.join(timeout)


_MANAGER: Optional[TaskManager] = None


def get_manager() -> TaskManager:
    global _MANAGER
    if _MANAGER is None:
        _MANAGER = TaskManager()
    return _MANAGER


def handle_task_command(text: str, manager: Optional[TaskManager] = None) -> Dict[str, Any]:
    """`task list|status <id>|pause <id>|resume <id>|cancel <id>|confirm <id> [yes|no]|report <id>|run`"""
    import re
    m = manager or get_manager()
    parts = re.sub(r"(?i)^\s*(task|tasks)\s*", "", text).split()
    cmd = (parts[0].lower() if parts else "list")
    tid = parts[1] if len(parts) > 1 else ""
    try:
        if cmd == "list":
            rows = m.list()
            return {"success": True, "verified": True, "message": "\n".join(f"{r['id']}  {r['status']:<22} {r['done']}/{r['total']}  {r['title']}" for r in rows) or "No tasks."}
        if cmd == "run":
            ev = m.run_until_idle()
            return {"success": True, "verified": True, "message": f"{len(ev)} step(s) processed. " + "; ".join(f"{e.get('task', '')}:{e.get('step', '')}:{e.get('status', e['event'])}" for e in ev[-6:])}
        if not tid:
            return {"success": False, "verified": False, "message": f"task {cmd} needs a task id"}
        if cmd in ("status", "report"):
            return {"success": True, "verified": True, "message": m.report(tid)}
        if cmd in ("pause", "resume", "cancel"):
            ok = getattr(m, cmd)(tid)
            return {"success": ok, "verified": ok, "message": f"{cmd} {'done' if ok else 'not possible in the current state'}: {tid}"}
        if cmd == "confirm":
            yes = (parts[2].lower() if len(parts) > 2 else "yes") in ("yes", "y", "haan", "han", "ok", "true")
            ok = m.confirm(tid, None, yes)
            return {"success": ok, "verified": ok, "message": f"{'confirmed' if yes else 'declined'}: {tid}" if ok else "nothing is waiting for confirmation in that task"}
    except KeyError as exc:
        return {"success": False, "verified": False, "message": str(exc)}
    return {"success": False, "verified": False, "message": "task commands: list, status <id>, pause <id>, resume <id>, cancel <id>, confirm <id> [yes|no], report <id>, run"}
