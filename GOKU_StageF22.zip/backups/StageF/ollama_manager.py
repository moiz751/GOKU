"""
Ollama Service Lifecycle and Health Management.
Handles automatic discovery, cold startup, non-blocking polling, model verification,
and graceful shutdown for local Ollama server.
"""
import atexit
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

from config.settings import (
    MODEL,
    OLLAMA_CONNECT_TIMEOUT,
    OLLAMA_STARTUP_TIMEOUT,
    OLLAMA_TAGS_URL,
)

_AGENT_STARTED_OLLAMA_PID: int | None = None


def find_ollama_executable() -> str | None:
    """
    Discovers the absolute path of the ollama executable on Windows or POSIX.
    Checks PATH, LOCALAPPDATA, USERPROFILE, and standard Program Files locations.
    """
    direct = shutil.which("ollama")
    if direct:
        return str(Path(direct).resolve())

    if sys.platform == "win32":
        candidates = [
            Path(os.environ.get("LOCALAPPDATA", "")) / "Programs" / "Ollama" / "ollama.exe",
            Path(os.environ.get("USERPROFILE", "")) / "AppData" / "Local" / "Programs" / "Ollama" / "ollama.exe",
            Path(os.environ.get("ProgramFiles", "")) / "Ollama" / "ollama.exe",
            Path(os.environ.get("ProgramFiles(x86)", "")) / "Ollama" / "ollama.exe",
            Path(r"C:\Users\Work\AppData\Local\Programs\Ollama\ollama.exe"),
            Path(r"C:\Program Files\Ollama\ollama.exe"),
        ]
        for c in candidates:
            if c.exists() and c.is_file():
                return str(c.resolve())

    return None


def is_ollama_running(url: str = OLLAMA_TAGS_URL, timeout: float | tuple[float, float] = OLLAMA_CONNECT_TIMEOUT) -> bool:
    """Checks if the Ollama HTTP server is responsive."""
    try:
        import requests
        res = requests.get(url, timeout=timeout)
        return res.status_code == 200
    except Exception:
        return False


def get_available_models(url: str = OLLAMA_TAGS_URL, timeout: float = OLLAMA_CONNECT_TIMEOUT) -> list[str]:
    """Fetches list of installed model names from local Ollama service."""
    try:
        import requests
        res = requests.get(url, timeout=timeout)
        if res.status_code == 200:
            data = res.json()
            models = [m.get("name", "") for m in data.get("models", [])]
            return models
    except Exception:
        pass
    return []


def is_model_available(model_name: str = MODEL, url: str = OLLAMA_TAGS_URL) -> bool:
    """Checks if the requested model (e.g. qwen2.5:0.5b) is available locally."""
    models = get_available_models(url=url)
    target = model_name.lower().split(":")[0]
    for m in models:
        m_lower = m.lower()
        if model_name.lower() in m_lower or target in m_lower:
            return True
    return False


def start_ollama_service() -> tuple[bool, str]:
    """
    Launches 'ollama serve' in background without console window.
    Polls /api/tags until ready or timeout.
    Returns (success, message).
    """
    global _AGENT_STARTED_OLLAMA_PID

    if is_ollama_running():
        return True, "Ollama service is already running."

    exe_path = find_ollama_executable()
    if not exe_path:
        return False, "Could not locate 'ollama' executable. Please make sure Ollama is installed."

    try:
        creationflags = 0x08000000 if sys.platform == "win32" else 0  # CREATE_NO_WINDOW
        proc = subprocess.Popen(
            [exe_path, "serve"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            creationflags=creationflags,
        )
        _AGENT_STARTED_OLLAMA_PID = proc.pid
    except Exception as e:
        return False, f"Failed to launch Ollama process ({exe_path}): {e}"

    # Poll until ready or startup timeout
    start_time = time.time()
    while time.time() - start_time < OLLAMA_STARTUP_TIMEOUT:
        if is_ollama_running(timeout=(2.0, 4.0)):
            return True, f"Ollama service started (PID {proc.pid})."
        time.sleep(0.5)

    if is_ollama_running(timeout=(2.0, 4.0)):
        return True, f"Ollama service started (PID {proc.pid})."

    return False, f"Ollama started (PID {proc.pid}) but HTTP health check timed out after {OLLAMA_STARTUP_TIMEOUT}s."


def ensure_ollama_ready(model_name: str = MODEL, print_status: bool = True) -> tuple[bool, str]:
    """
    Complete lifecycle verification:
    1. Checks if running; starts background server if off.
    2. Verifies configured model is available.
    """
    from config.settings import is_model_call_allowed
    allowed, reason = is_model_call_allowed()
    if not allowed:
        if print_status:
            print(f"[OLLAMA BLOCKED] {reason}", flush=True)
        return False, reason

    if print_status:
        print("Checking Ollama...", flush=True)

    if not is_ollama_running():
        if print_status:
            print("Ollama not running. Starting Ollama...", flush=True)
        started, msg = start_ollama_service()
        if not started:
            if print_status:
                print(f"Error: {msg}", flush=True)
            return False, msg
        if print_status:
            print("Ollama service ready.", flush=True)
    else:
        if print_status:
            print("Ollama already running.", flush=True)

    # Check model
    if not is_model_available(model_name=model_name):
        msg = f"Model '{model_name}' is not available locally in Ollama. Please run 'ollama pull {model_name}'."
        if print_status:
            print(f"Warning: {msg}", flush=True)
        return False, msg

    if print_status:
        print(f"Model {model_name} available.", flush=True)

    return True, f"Model {model_name} available."


def unload_model(model_name: str = MODEL, timeout: float = 5.0) -> bool:
    """
    Explicitly unloads a model from RAM/VRAM via Ollama's API by setting keep_alive to 0.
    Sends POST to ${OLLAMA_BASE_URL}/api/generate with {"model": model_name, "keep_alive": 0}.
    """
    try:
        from config.settings import OLLAMA_BASE_URL
        import requests
        url = f"{OLLAMA_BASE_URL.rstrip('/')}/api/generate"
        res = requests.post(url, json={"model": model_name, "keep_alive": 0}, timeout=timeout)
        return res.status_code == 200
    except Exception:
        try:
            from config.settings import OLLAMA_BASE_URL
            import urllib.request
            import json
            url = f"{OLLAMA_BASE_URL.rstrip('/')}/api/generate"
            data = json.dumps({"model": model_name, "keep_alive": 0}).encode("utf-8")
            req = urllib.request.Request(url, data=data, headers={"Content-Type": "application/json"})
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                return resp.status == 200
        except Exception:
            return False


def is_model_loaded(model_name: str = MODEL, timeout: float = 2.0) -> bool:
    """
    Checks if a model is currently loaded in Ollama's memory via /api/ps.
    """
    try:
        from config.settings import OLLAMA_BASE_URL
        import requests
        url = f"{OLLAMA_BASE_URL.rstrip('/')}/api/ps"
        res = requests.get(url, timeout=timeout)
        if res.status_code == 200:
            data = res.json()
            models = data.get("models", [])
            for m in models:
                name = m.get("name") or m.get("model") or ""
                if name == model_name or name.startswith(f"{model_name}:"):
                    return True
        return False
    except Exception:
        try:
            from config.settings import OLLAMA_BASE_URL
            import urllib.request
            import json
            url = f"{OLLAMA_BASE_URL.rstrip('/')}/api/ps"
            req = urllib.request.Request(url)
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                if resp.status == 200:
                    data = json.loads(resp.read().decode("utf-8"))
                    models = data.get("models", [])
                    for m in models:
                        name = m.get("name") or m.get("model") or ""
                        if name == model_name or name.startswith(f"{model_name}:"):
                            return True
            return False
        except Exception:
            return False


def cleanup_agent_ollama() -> None:
    """Terminates Ollama process only if it was started by this agent instance."""
    global _AGENT_STARTED_OLLAMA_PID
    pid = _AGENT_STARTED_OLLAMA_PID
    _AGENT_STARTED_OLLAMA_PID = None
    if pid is not None:
        try:
            if sys.platform == "win32":
                subprocess.run(
                    ["taskkill", "/F", "/T", "/PID", str(pid)],
                    capture_output=True,
                    timeout=2.0,
                    check=False,
                )
            else:
                os.kill(pid, 15)
        except Exception:
            pass


atexit.register(cleanup_agent_ollama)
