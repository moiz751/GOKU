"""
Task router (P2). Decides whether a request is a calculation, an explicit deep-thinking request, a system
action or something else, and answers the first two itself. Everything else returns None so the existing
command_layer.router.handle_command keeps full ownership (no existing behaviour is replaced).

    route(text)        -> {"route": "calc"|"deep"|"action"|"other", "confidence": float, "reason": str}
    try_handle(text)   -> reply string, or None meaning "not mine, use handle_command"
"""
from __future__ import annotations

import re
from typing import Any, Callable, Dict, List, Optional

from brain import calc_engine, reasoning_engine

_ACTION_START = re.compile(
    r"^\s*(open|launch|start|run|close|kill|stop|kholo|khol|band|delete|remove|create|make|rename|copy|move|play|pause|search|find|type|write|click|press|scroll|"
    r"take|capture|screenshot|read|summari[sz]e|show|list|set|turn|volume|mute|download|install|send|save|focus|switch|minimi[sz]e|maximi[sz]e|lock|shutdown|restart)\b", re.I)


_FILE_VERB = re.compile(r"^\s*(?:please\s+)?(deep\s+analy[sz]e|analy[sz]e|audit|review|inspect|compare|code\s+review)\b", re.I)
_PATH = re.compile(r"""(?:"([^"]+)"|'([^']+)'|((?:[A-Za-z]:)?[\\/]?[\w\-. \\/~]+\.[A-Za-z0-9]{1,5}))""")


def _existing_paths(text: str) -> List[str]:
    import os

    found: List[str] = []
    for m in _PATH.finditer(text):
        cand = next((g for g in m.groups() if g), "").strip()
        for c in (cand, cand.split()[-1] if " " in cand else cand):
            c = os.path.expanduser(c)
            if c and os.path.isfile(c) and c not in found:
                found.append(c)
                break
    return found


def route(text: str) -> Dict[str, Any]:
    t = (text or "").strip()
    if not t:
        return {"route": "other", "confidence": 0.0, "reason": "empty"}
    if re.match(r"^\s*(memory|knowledge)\s+\w+", t, re.I):
        return {"route": "memory", "confidence": 0.95, "reason": "memory/knowledge data command"}
    if _FILE_VERB.match(t) and _existing_paths(t):
        return {"route": "file", "confidence": 0.9, "reason": "analyse/review/compare an existing file"}
    if reasoning_engine.wants_deep(t) and not _ACTION_START.match(t):
        return {"route": "deep", "confidence": 0.9, "reason": "explicit deep-thinking request"}
    score = calc_engine.looks_like_math(t)
    if score >= 0.5 and not _ACTION_START.match(t):
        return {"route": "calc", "confidence": score, "reason": "looks like a calculation"}
    if _ACTION_START.match(t):
        return {"route": "action", "confidence": 0.7, "reason": "starts with an action verb"}
    if reasoning_engine.classify_complexity(t) == "complex" and "?" in t:
        return {"route": "deep", "confidence": 0.6, "reason": "long multi-part question"}
    return {"route": "other", "confidence": 0.3, "reason": "no specialised route"}


def _model_ask() -> Optional[Callable[[str], Optional[str]]]:
    """The model is used only when the existing readiness gate allows it; otherwise reasoning stays deterministic."""
    try:
        from config.settings import is_model_call_allowed

        allowed = is_model_call_allowed()
        if isinstance(allowed, tuple):
            allowed = allowed[0]
        if not allowed:
            return None
        from brain.llm import ask_conversational_llm

        return lambda prompt: ask_conversational_llm(prompt)
    except Exception:
        return None


def try_handle(text: str, ask: Optional[Callable[[str], Optional[str]]] = None) -> Optional[str]:
    info = route(text)
    if info["route"] == "calc":
        cmp = reasoning_engine.compare_values(text)
        if cmp:
            return f"{cmp['answer']} ({cmp['a']} vs {cmp['b']})\n  both sides computed exactly with fractions"
        res = calc_engine.calculate_from_text(text)
        if res is None:
            return None
        if not res["ok"]:
            return f"[calc] {res['error']}"
        extra = "" if res["verified"] else " (not verified)"
        steps = res.get("steps") or []
        how = f"\n  {res['verification']}" if res.get("verification") else ""
        head = f"{res['display']}{extra}"
        if res["kind"] in ("equation",) and steps:
            head += "\n  " + "\n  ".join(steps[:3])
        return head + how
    if info["route"] == "memory":
        from brain import learning_hooks
        return learning_hooks.handle_memory_command(text)
    if info["route"] == "file":
        try:
            from brain import doc_insight

            paths = _existing_paths(text)
            if re.match(r"^\s*compare\b", text, re.I) and len(paths) >= 2:
                r = doc_insight.compare_files(paths[0], paths[1])
                lines = [f"Similarity {r['similarity']:.0%}; added {r['counts']['added']}, removed {r['counts']['removed']}, changed {r['counts']['changed']}" + ("  (identical)" if r["identical"] else "")]
                lines += [f"+ {a['text']}  [{a['loc']}]" for a in r["added"][:5]] + [f"- {a['text']}  [{a['loc']}]" for a in r["removed"][:5]] + [f"~ {c['a']} -> {c['b']}  [{c['a_loc']} / {c['b_loc']}]" for c in r["changed"][:5]]
                return "\n".join(lines)
            return doc_insight.render_report(doc_insight.analyze_file(paths[0]))
        except Exception as exc:
            return f"[file analysis] could not finish: {type(exc).__name__}: {exc}"
    if info["route"] == "deep":
        rep = reasoning_engine.reason(text, ask=ask if ask is not None else _model_ask())
        return rep.render()
    return None
