"""
Route planner (Stage C5): choose HOW to do a task, from measured cost and success - not from guesses.

Candidate routes (cheap -> expensive): playbook, uia, shortcut, ocr_click, vision, ask_user.
* Costs (peak RAM, time) and success rates are learned per (task type, route, environment) from route_performance memory.
* A route whose expected RAM does not fit the currently free RAM (with margin) is dropped; under critical pressure no heavy route is tried.
* Two consecutive failures in the same environment put that route on a cooldown (a changed environment gets a fresh start).
* Exploration (trying a route with too little data) only happens when the task is read-only; never for destructive tasks.
* `ask_user` is always the final fallback, so the chain never ends in a silent guess.
* run_with_fallback() returns what really happened: which route worked, which failed and why.
No threads, no timers: everything runs when the caller asks.
"""
from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Any, Callable, Dict, List, Optional

from brain.memory_store import MemoryStore


@dataclass(frozen=True)
class Route:
    name: str
    heavy: bool
    est_mb: float
    est_s: float
    risk: float          # 0 (safe) .. 1 (can break things)


ROUTES: Dict[str, Route] = {
    "playbook": Route("playbook", False, 20, 2, 0.15),
    "uia": Route("uia", False, 40, 2, 0.10),
    "shortcut": Route("shortcut", False, 5, 1, 0.20),
    "ocr_click": Route("ocr_click", True, 250, 6, 0.40),
    "vision": Route("vision", True, 500, 15, 0.45),
    "ask_user": Route("ask_user", False, 1, 30, 0.0),
}
DEFAULT_ORDER = ["playbook", "uia", "shortcut", "ocr_click", "vision", "ask_user"]
COOLDOWN_S = 600.0
FAILS_FOR_COOLDOWN = 2
EMA = 0.3


class RoutePlanner:
    def __init__(self, store: MemoryStore, free_mb_fn: Callable[[], float], pressure_fn: Callable[[], str] = lambda: "normal",
                 clock: Callable[[], float] = time.time, margin: float = 0.8):
        self.store, self.free_mb, self.pressure, self.clock, self.margin = store, free_mb_fn, pressure_fn, clock, margin

    # ------------------------------------------------------------ learned statistics
    @staticmethod
    def _key(task: str, route: str, env: str) -> str:
        return f"{task}|{route}|{env}"

    def _stat(self, task: str, route: str, env: str) -> Optional[Dict[str, Any]]:
        rows = self.store.by_key("route_performance", self._key(task, route, env))
        return rows[0] if rows else None

    def record(self, task: str, route: str, ok: bool, seconds: float, peak_mb: float, env: str = "default") -> None:
        key = self._key(task, route, env)
        rec = self._stat(task, route, env)
        if rec is None:
            self.store.add("route_performance", f"route stats {key}", key=key, source="tool_verified", meta={"n": 0, "ok": 0, "ema_mb": peak_mb, "ema_s": seconds, "consec_fail": 0, "cooldown_until": 0})
            rec = self._stat(task, route, env)
        m = dict(rec["meta"])
        m["n"] += 1
        m["ok"] += 1 if ok else 0
        m["ema_mb"] = round((1 - EMA) * m["ema_mb"] + EMA * peak_mb, 2)
        m["ema_s"] = round((1 - EMA) * m["ema_s"] + EMA * seconds, 3)
        m["consec_fail"] = 0 if ok else m["consec_fail"] + 1
        if m["consec_fail"] >= FAILS_FOR_COOLDOWN:
            m["cooldown_until"] = self.clock() + COOLDOWN_S
        elif ok:
            m["cooldown_until"] = 0
        self.store.update_meta(rec["id"], **m)
        self.store.record_outcome(rec["id"], ok)

    # ------------------------------------------------------------ planning
    def plan(self, task: str, env: str = "default", destructive: bool = False, read_only: bool = False, candidates: Optional[List[str]] = None) -> Dict[str, Any]:
        cands = [c for c in (candidates or DEFAULT_ORDER) if c in ROUTES]
        if "ask_user" not in cands:
            cands.append("ask_user")
        free, pressure, now = float(self.free_mb()), self.pressure(), self.clock()
        ranked, dropped = [], []
        for name in cands:
            base = ROUTES[name]
            st = self._stat(task, name, env)
            meta = st["meta"] if st else {}
            n, ok = meta.get("n", 0), meta.get("ok", 0)
            mb, secs = meta.get("ema_mb", base.est_mb), meta.get("ema_s", base.est_s)
            if name != "ask_user":
                if meta.get("cooldown_until", 0) > now:
                    dropped.append({"route": name, "why": f"cooldown after {meta.get('consec_fail')} failures in this environment"})
                    continue
                if pressure == "critical" and base.heavy:
                    dropped.append({"route": name, "why": "RAM pressure critical: heavy routes are not tried"})
                    continue
                if mb > free * self.margin:
                    dropped.append({"route": name, "why": f"needs ~{mb:.0f} MB but only {free:.0f} MB free"})
                    continue
            success = (ok + 1.0) / (n + 2.0)
            cheap = 1.0 / (1.0 + mb / 100.0 + secs / 10.0)
            score = success * cheap / (0.2 + base.risk)
            if pressure == "elevated" and base.heavy:
                score *= 0.5
            exploring = False
            if read_only and not destructive and n < 3 and name != "ask_user":
                score *= 1.3
                exploring = True
            if destructive and base.risk >= 0.4 and n < 3:
                dropped.append({"route": name, "why": "destructive task: unproven risky route not allowed"})
                continue
            if name == "ask_user":
                score = 1e-6                                  # always last
            ranked.append({"route": name, "score": round(score, 5), "expected_mb": round(mb, 1), "expected_s": round(secs, 2), "samples": n, "exploring": exploring})
        ranked.sort(key=lambda r: -r["score"])
        return {"task": task, "env": env, "free_mb": round(free, 1), "pressure": pressure, "chain": ranked, "dropped": dropped}

    def run_with_fallback(self, task: str, runners: Dict[str, Callable[[], Any]], env: str = "default", destructive: bool = False,
                          read_only: bool = False, rss_fn: Optional[Callable[[], float]] = None) -> Dict[str, Any]:
        """runner returns a truthy value on success, falsy/raises on failure. ask_user runner (if given) is the last resort."""
        plan = self.plan(task, env, destructive, read_only, candidates=list(runners))
        tried = []
        for item in plan["chain"]:
            fn = runners.get(item["route"])
            if fn is None:
                continue
            r0, t0 = (rss_fn() if rss_fn else 0.0), time.monotonic()
            err, result = None, None
            try:
                result = fn()
            except Exception as exc:  # a failing route must not stop the chain
                err = f"{type(exc).__name__}: {exc}"
            ok = bool(result) and err is None
            dt = time.monotonic() - t0
            peak = max(0.0, (rss_fn() if rss_fn else 0.0) - r0) or item["expected_mb"]
            if item["route"] != "ask_user":
                self.record(task, item["route"], ok, dt, peak, env)
            tried.append({"route": item["route"], "ok": ok, "error": err, "seconds": round(dt, 3)})
            if ok:
                return {"ok": True, "route": item["route"], "result": result, "tried": tried, "plan": plan}
        return {"ok": False, "route": None, "result": None, "tried": tried, "plan": plan,
                "message": "No route succeeded; nothing was claimed as done."}
