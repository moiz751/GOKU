"""
Tool wrapper for ScreenUnderstanding (Stage B): `understand_screen`.
Read-only. It never clicks or types. The instance is created on first use and keeps only small records (hashes and names).
"""
from __future__ import annotations

from typing import Any, Dict, Optional, Tuple

from tools.registry import tool

_SU = None


def _get(providers: Optional[Dict[str, Any]] = None):
    global _SU
    if providers is not None:
        from tools.vision.screen_fusion import ScreenUnderstanding

        return ScreenUnderstanding(providers)
    if _SU is None:
        from tools.vision.screen_fusion import ScreenUnderstanding
        from tools.vision.screen_providers import default_providers

        _SU = ScreenUnderstanding(default_providers())
    return _SU


def _trim(state: Dict[str, Any]) -> Dict[str, Any]:
    keep = ("goal", "verdict", "confidence", "needs_reobserve", "reasons", "window", "monitors", "cursor", "elements", "title_fact", "errors", "dialog",
            "change", "motion", "user_activity", "returning_to_known_screen", "conflicts", "unavailable_methods", "provider_errors", "limits", "suggested_region", "rounds")
    out = {k: state.get(k) for k in keep}
    out["plan"] = {"methods": state["plan"]["methods"], "reasons": state["plan"]["reasons"]}
    if isinstance(out.get("change"), dict):
        out["change"] = {k: v for k, v in out["change"].items() if k != "cells"}
    return out


def run_understand_screen(goal: str = "overview", region: Optional[Tuple[int, int, int, int]] = None, check_safe: bool = False, providers: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    su = _get(providers)
    state = su.observe(goal=goal, region=tuple(region) if region else None)
    res: Dict[str, Any] = {"success": state["verdict"] == "OK", "status": "VERIFIED" if state["verdict"] == "OK" else "UNCERTAIN", "observation": _trim(state)}
    if not res["success"]:
        res["message"] = state["verdict"]
    if check_safe:
        res["safe_to_act"] = su.safe_to_act()
    return res


@tool(
    name="understand_screen",
    description="Looks at the screen with several independent methods (window metadata, UI Automation, OCR, frame difference), combines the evidence, reports disagreements and uncertainty, and refuses to guess. Read-only.",
    parameters={
        "type": "object",
        "properties": {
            "goal": {"type": "string", "description": "overview | read_text | find_element | detect_change | verify_dialog | game", "default": "overview"},
            "check_safe": {"type": "boolean", "description": "Also report whether it is safe to act on this observation.", "default": False},
        },
    },
    category="vision",
    risk_level="read_only",
)
def understand_screen(goal: str = "overview", check_safe: bool = False) -> Dict[str, Any]:
    return run_understand_screen(goal=goal, check_safe=check_safe)
