"""
Learning hooks (Stage C): GOKU learns from what really happened, never from what it hoped happened.

* install() wraps executor.executor.run_tool_call (same name, same signature via functools.wraps). The wrapper only OBSERVES:
  it records the tool, a short argument summary (secrets redacted by the store), the real status, duration and RSS change, then returns the
  original result untouched. If recording fails, the result still goes through.
* A tool result counts as a success for learning ONLY when it says success AND verified. Unverified = recorded as such, with low trust.
* Learning is on when GOKU_LEARNING=1, or in normal runs unless GOKU_LEARNING=0. It is off under pytest unless forced.
* run_idle_maintenance() is called by main after a command (no threads, no timers) and only when RAM pressure is normal.
* handle_memory_command() serves `memory ...` / `knowledge ...` text commands as pure data operations.
"""
from __future__ import annotations

import functools
import os
import re
import time
from typing import Any, Dict, Optional

_STORE = None
_LIFECYCLE = None
_INSTALLED = False
_LAST_MAINT = 0.0
MAINT_EVERY_S = 900.0


def learning_enabled() -> bool:
    flag = os.environ.get("GOKU_LEARNING", "").strip()
    if flag == "1":
        return True
    if flag == "0":
        return False
    return "PYTEST_CURRENT_TEST" not in os.environ


def get_store():
    global _STORE
    if _STORE is None:
        from brain.memory_store import MemoryStore
        _STORE = MemoryStore()
    return _STORE


def get_lifecycle():
    global _LIFECYCLE
    if _LIFECYCLE is None:
        from brain.knowledge_lifecycle import KnowledgeLifecycle
        _LIFECYCLE = KnowledgeLifecycle(get_store())
    return _LIFECYCLE


def reset_for_tests() -> None:
    global _STORE, _LIFECYCLE, _INSTALLED, _LAST_MAINT
    if _STORE is not None:
        _STORE.close()
    _STORE = _LIFECYCLE = None
    _INSTALLED = False
    _LAST_MAINT = 0.0


def _rss_mb() -> float:
    try:
        import psutil
        return psutil.Process().memory_info().rss / 1048576.0
    except Exception:
        return 0.0


def record_tool_outcome(tool: str, args: Any, result: Dict[str, Any], seconds: float, rss_delta_mb: float, store=None) -> Optional[int]:
    store = store or get_store()
    ok = bool(result.get("success")) and bool(result.get("verified"))
    status = str(result.get("status", "?"))
    summary = re.sub(r"\s+", " ", str(args))[:200]
    if ok:
        r = store.add("episodic", f"tool {tool} verified ok ({status}) args {summary}", key=f"tool:{tool}", source="tool_verified",
                      meta={"seconds": round(seconds, 3), "rss_delta_mb": round(rss_delta_mb, 1), "status": status})
    elif result.get("success"):
        r = store.add("episodic", f"tool {tool} reported success but UNVERIFIED ({status}) args {summary}", key=f"tool:{tool}", source="system", trust=0.3,
                      meta={"status": status, "unverified": True})
    else:
        msg = re.sub(r"\s+", " ", str(result.get("message", "")))[:160]
        r = store.add("failure", f"tool {tool} failed ({status}): {msg}", key=f"tool:{tool}", source="system",
                      meta={"status": status, "seconds": round(seconds, 3)})
    return r.get("id")


def install() -> bool:
    """Idempotent. Returns True if the wrapper is (now) active."""
    global _INSTALLED
    if _INSTALLED:
        return True
    if not learning_enabled():
        return False
    try:
        import executor.executor as ex
        orig = ex.run_tool_call
        if getattr(orig, "_goku_learning_wrapped", False):
            _INSTALLED = True
            return True

        @functools.wraps(orig)
        def wrapped(*a, **kw):
            t0, r0 = time.monotonic(), _rss_mb()
            result = orig(*a, **kw)
            try:
                if isinstance(result, dict):
                    tool = a[0] if a else kw.get("tool_name", "?")
                    args = a[1] if len(a) > 1 else kw.get("args", {})
                    record_tool_outcome(str(tool), args, result, time.monotonic() - t0, _rss_mb() - r0)
            except Exception:
                pass                                  # learning must never break a tool call
            return result

        wrapped._goku_learning_wrapped = True
        ex.run_tool_call = wrapped
        try:
            import executor
            executor.run_tool_call = wrapped
        except Exception:
            pass
        _INSTALLED = True
        return True
    except Exception:
        return False


def record_episode(user_text: str, outcome: str, ok: Optional[bool] = None) -> None:
    """One line per finished command. `ok=None` means the outcome was not verified."""
    if not learning_enabled():
        return
    try:
        src = "tool_verified" if ok else "system"
        get_store().add("conversation", f"user said: {user_text[:200]} | outcome: {outcome[:200]}", key="episode", source=src, trust=None if ok else 0.4)
    except Exception:
        pass


def run_idle_maintenance(force: bool = False) -> Optional[Dict[str, Any]]:
    global _LAST_MAINT
    if _STORE is None and not force:
        return None
    now = time.monotonic()
    if not force and now - _LAST_MAINT < MAINT_EVERY_S:
        return None
    try:
        from tools.resource_monitor import pressure_level
        if not force and pressure_level() != "normal":
            return None
    except Exception:
        pass
    _LAST_MAINT = now
    try:
        return get_store().maintenance(max_seconds=1.5)
    except Exception:
        return None


_CMD = re.compile(r"^\s*(memory|knowledge)\s+(\w+)\s*(.*)$", re.I)


def handle_memory_command(text: str) -> Optional[str]:
    m = _CMD.match(text or "")
    if not m:
        return None
    area, verb, rest = m.group(1).lower(), m.group(2).lower(), m.group(3).strip()
    try:
        if area == "memory":
            st = get_store()
            if verb == "status":
                s = st.stats()
                kinds = ", ".join(f"{k}:{v}" for k, v in sorted(s["by_kind"].items())) or "empty"
                return f"Memory: {s['total']} records, {s['db_bytes']/1024:.0f} KB on disk, {s['untrusted']} untrusted.\n  {kinds}" + (f"\n  recovered from: {s['recovered_from']}" if s["recovered_from"] else "")
            if verb in ("show", "search"):
                rows = st.search(rest, limit=8, touch=False)
                if not rows:
                    return "Memory: nothing found."
                return "\n".join(f"#{r['id']} [{r['kind']}/{r['scope']}] conf {r['effective_confidence']:.2f}{' UNTRUSTED' if r['untrusted'] else ''}: {r['content'][:140]}" for r in rows)
            if verb == "forget":
                n = st.forget(rid=int(rest)) if rest.isdigit() else st.forget(query=rest)
                return f"Memory: forgot {n} record(s)."
            if verb == "export":
                import json
                p = st.path.with_name("memory_export.json")
                rows = [st._row(r) for r in st.con.execute("SELECT * FROM mem LIMIT 5000").fetchall()]
                p.write_text(json.dumps(rows, ensure_ascii=False, indent=1, default=str), encoding="utf-8")
                return f"Memory: exported {len(rows)} records to {p}"
            return "Memory commands: status | show <text> | forget <id or text> | export"
        lc = get_lifecycle()
        if verb == "list":
            rows = lc.list(state=rest or None)
            return "\n".join(f"#{r['id']} {r['state']:<9} {r['type']}/{r['key']} = {r['value']} (risk {r['risk']})" for r in rows) or "Knowledge: nothing yet."
        if verb == "test":
            r = lc.test(int(rest))
            return f"Knowledge #{r['id']}: " + ("tests passed" if r["passed"] else "FAILED: " + "; ".join(r["problems"])) + (f" | conflicts: {r['conflicts']}" if r["conflicts"] else "")
        if verb == "approve":
            lc.approve(int(rest))
            v = lc.activate(int(rest))
            return f"Knowledge #{rest} approved and active (pack v{v})."
        if verb == "reject":
            lc.reject(int(rest))
            return f"Knowledge #{rest} rejected."
        if verb == "retire":
            lc.retire(int(rest))
            return f"Knowledge #{rest} retired."
        if verb == "rollback":
            p = lc.rollback()
            return f"Knowledge rolled back to pack v{p['version']}."
        return "Knowledge commands: list [state] | test <id> | approve <id> | reject <id> | retire <id> | rollback"
    except Exception as exc:
        return f"[{area}] {type(exc).__name__}: {exc}"
