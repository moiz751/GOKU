"""
Screen understanding by evidence fusion (Stage B).

Every observation method (UIA, Win32 metadata, OCR, pixel/temporal diff, cursor, monitors) is a *provider*:
a plain callable injected by the caller (see tools/vision/screen_providers.py for the Windows ones). This module only
does the thinking, so it is fully testable without a screen:

  plan_observation()  decides WHICH methods to use for a goal, given RAM pressure and the hardware tier
  fuse()              combines evidence, drops stale evidence, finds disagreements between methods
  ScreenUnderstanding.observe()   runs the plan, re-observes (bounded) instead of guessing, updates visual memory
  VisualMemory        bounded memory of past screens (hash + names, never images)
  UserActivityDetector  recognises manual user actions between two of GOKU's own actions
  StaleGuard          forbids decisions on old observations

Nothing here clicks or types.
"""
from __future__ import annotations

import re
import time
from collections import deque
from dataclasses import dataclass, field
from typing import Any, Callable, Deque, Dict, List, Optional, Sequence, Tuple

from tools.vision import frame_diff

METHODS = ("window_meta", "uia", "ocr", "pixel_diff", "cursor", "monitors", "capture")
# how much each method is trusted for what kind of claim (0..1). Structural APIs beat pixels for names/roles; OCR beats UIA for canvas text.
TRUST = {
    ("window_meta", "title"): 0.9, ("uia", "title"): 0.85, ("uia", "element"): 0.9, ("ocr", "element"): 0.6,
    ("uia", "text"): 0.8, ("ocr", "text"): 0.7, ("window_meta", "dialog"): 0.85, ("uia", "dialog"): 0.8, ("ocr", "dialog"): 0.5,
    ("pixel_diff", "changed"): 0.9, ("ocr", "error"): 0.65, ("uia", "error"): 0.8,
}
DEFAULT_MAX_AGE_S = 3.0

ERROR_PATTERNS: List[Tuple[re.Pattern, str]] = [
    (re.compile(r"\b(not responding|has stopped working|has encountered a problem|fatal error|unhandled exception|crash(?:ed)?)\b", re.I), "critical"),
    (re.compile(r"\b(error|failed|failure|cannot|can't|could not|unable to|access is denied|permission denied|not found|invalid|exception|0x[0-9a-f]{6,8})\b", re.I), "error"),
    (re.compile(r"\b(warning|are you sure|low disk space|battery low|update required|expired)\b", re.I), "warning"),
]
DIALOG_BUTTONS = {"ok", "cancel", "yes", "no", "retry", "close", "save", "don't save", "apply", "abort", "ignore", "allow", "deny", "continue"}


@dataclass
class Evidence:
    method: str
    kind: str                 # title | element | text | dialog | error | changed
    key: str                  # normalised identity of the claim, e.g. "title" or "element:save button"
    value: Any
    ts: float
    bbox: Optional[Tuple[int, int, int, int]] = None
    confidence: float = 0.5
    meta: Dict[str, Any] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# Planning: which method when
# ---------------------------------------------------------------------------
def plan_observation(goal: str = "overview", pressure: str = "normal", ocr_allowed: bool = True, screen_size: Optional[Tuple[int, int]] = None,
                     max_side: Optional[int] = None, free_mb: Optional[float] = None) -> Dict[str, Any]:
    """goal: overview | read_text | find_element | detect_change | verify_dialog | game"""
    g = (goal or "overview").lower()
    steps: List[Tuple[str, str]] = [("window_meta", "cheap and exact: which window is in front")]
    if g in ("overview", "find_element", "verify_dialog", "read_text"):
        steps.append(("uia", "structure: names, roles and positions without pixels"))
    if g in ("detect_change", "game", "overview"):
        steps.append(("capture", "pixels are needed for change detection"))
        steps.append(("pixel_diff", "compare with the previous frame on a small grid"))
    if g in ("read_text", "verify_dialog", "overview") and ocr_allowed:
        steps.append(("ocr", "text that UI Automation cannot see (canvas, images, games)"))
    steps.append(("cursor", "pointer position, to separate user actions from GOKU's"))
    steps.append(("monitors", "which screen each window is on"))
    limits: List[str] = []
    if pressure == "critical":
        steps = [s for s in steps if s[0] in ("window_meta", "cursor")]
        limits.append("critical memory pressure: metadata only, no screenshots, no OCR")
    elif pressure == "elevated":
        steps = [s for s in steps if s[0] != "ocr"]
        limits.append("elevated memory pressure: OCR disabled, reduced resolution")
    if not ocr_allowed and not any("OCR" in l for l in limits):
        limits.append("OCR is not allowed on this hardware tier")
    capture_plan = None
    if screen_size and any(s[0] == "capture" for s in steps):
        try:
            from tools.resource_monitor import plan_capture

            budget = None if free_mb is None else max(20.0, free_mb * 0.08)
            capture_plan = plan_capture(screen_size[0], screen_size[1], budget_mb=budget, max_side=max_side)
        except Exception:
            capture_plan = {"max_side": max_side or 1280}
    return {"goal": g, "pressure": pressure, "methods": [s[0] for s in steps], "reasons": dict(steps), "limits": limits, "capture": capture_plan}


# ---------------------------------------------------------------------------
# Error / dialog recognition on text
# ---------------------------------------------------------------------------
def classify_texts(texts: Sequence[str]) -> Dict[str, Any]:
    errors: List[Dict[str, str]] = []
    buttons = set()
    for t in texts:
        s = str(t).strip()
        if not s:
            continue
        if s.lower() in DIALOG_BUTTONS:
            buttons.add(s.lower())
        for pat, sev in ERROR_PATTERNS:
            m = pat.search(s)
            if m:
                errors.append({"severity": sev, "text": s[:160], "match": m.group(0)})
                break
    rank = {"critical": 0, "error": 1, "warning": 2}
    errors.sort(key=lambda e: rank[e["severity"]])
    is_dialog = len(buttons) >= 2 or (bool(buttons) and bool(errors))
    return {"errors": errors[:10], "dialog_buttons": sorted(buttons), "looks_like_dialog": is_dialog}


# ---------------------------------------------------------------------------
# Fusion
# ---------------------------------------------------------------------------
def _norm(s: Any) -> str:
    return re.sub(r"\s+", " ", re.sub(r"[^\w\s]", " ", str(s).lower())).strip()


def _trust(ev: Evidence) -> float:
    return min(1.0, max(0.05, TRUST.get((ev.method, ev.kind), 0.5) * (0.5 + ev.confidence / 2.0) * 1.0))


def fuse(evidence: Sequence[Evidence], now: Optional[float] = None, max_age_s: float = DEFAULT_MAX_AGE_S) -> Dict[str, Any]:
    now = time.time() if now is None else now
    fresh = [e for e in evidence if now - e.ts <= max_age_s]
    stale = [e for e in evidence if now - e.ts > max_age_s]
    groups: Dict[str, List[Evidence]] = {}
    for e in fresh:
        groups.setdefault(e.key, []).append(e)
    facts: List[Dict[str, Any]] = []
    conflicts: List[Dict[str, Any]] = []
    for key, items in groups.items():
        by_method: Dict[str, Evidence] = {}
        for e in items:
            if e.method not in by_method or _trust(e) > _trust(by_method[e.method]):
                by_method[e.method] = e
        vals: Dict[str, List[str]] = {}
        for m, e in by_method.items():
            vals.setdefault(_norm(e.value), []).append(m)
        if len(vals) == 1:
            # independent methods agreeing -> noisy-or; one method alone -> its own trust
            miss = 1.0
            for e in by_method.values():
                miss *= (1.0 - _trust(e) * 0.9)
            conf = round(1.0 - miss, 3)
            best = max(by_method.values(), key=_trust)
            facts.append({"key": key, "kind": best.kind, "value": best.value, "methods": sorted(by_method), "confidence": conf, "bbox": best.bbox, "agreed": len(by_method) > 1})
        else:
            # disagreement is reported, never silently resolved
            conflicts.append({"key": key, "claims": [{"value": next(e.value for e in by_method.values() if _norm(e.value) == v), "methods": ms} for v, ms in vals.items()]})
    facts.sort(key=lambda f: -f["confidence"])
    needs: List[str] = []
    if not fresh:
        needs.append("no fresh evidence: every observation is older than %.1f s" % max_age_s)
    if conflicts:
        needs.append(f"{len(conflicts)} conflict(s) between methods: {', '.join(c['key'] for c in conflicts[:4])}")
    weak = [f for f in facts if f["confidence"] < 0.5 and f["kind"] in ("title", "dialog", "error")]
    if weak:
        needs.append("weak evidence for: " + ", ".join(f["key"] for f in weak[:4]))
    overall = 0.0 if not facts else round(sum(f["confidence"] for f in facts[:10]) / min(len(facts), 10) * (0.6 if conflicts else 1.0), 3)
    return {"facts": facts, "conflicts": conflicts, "stale_dropped": len(stale), "confidence": overall, "needs_reobserve": bool(needs), "reasons": needs}


# ---------------------------------------------------------------------------
# Memory, freshness, user activity
# ---------------------------------------------------------------------------
class VisualMemory:
    """Last N screens as tiny records (hash, title, key element names). No pixels are kept."""

    def __init__(self, capacity: int = 40):
        self.items: Deque[Dict[str, Any]] = deque(maxlen=capacity)

    def remember(self, ts: float, title: str, hwnd: Any, phash: Optional[int], names: Sequence[str], note: str = "") -> None:
        self.items.append({"ts": ts, "title": title, "hwnd": hwnd, "phash": phash, "names": list(names)[:25], "note": note})

    def recall(self, title_substr: str = "", phash: Optional[int] = None, max_dist: int = 8) -> List[Dict[str, Any]]:
        out = []
        for it in reversed(self.items):
            if title_substr and title_substr.lower() not in (it["title"] or "").lower():
                continue
            if phash is not None and it["phash"] is not None and frame_diff.hamming(phash, it["phash"]) > max_dist:
                continue
            out.append(it)
        return out

    def seen_before(self, phash: int, max_dist: int = 6) -> Optional[Dict[str, Any]]:
        for it in reversed(self.items):
            if it["phash"] is not None and frame_diff.hamming(phash, it["phash"]) <= max_dist:
                return it
        return None


class StaleGuard:
    """A decision may only use an observation that is recent AND still about the same foreground window."""

    def __init__(self, max_age_s: float = DEFAULT_MAX_AGE_S):
        self.max_age_s = max_age_s

    def check(self, observed_ts: float, observed_hwnd: Any, current_hwnd: Any = None, now: Optional[float] = None, last_action_ts: Optional[float] = None) -> Dict[str, Any]:
        now = time.time() if now is None else now
        age = now - observed_ts
        reasons = []
        if age > self.max_age_s:
            reasons.append(f"observation is {age:.1f}s old (limit {self.max_age_s}s)")
        if current_hwnd is not None and observed_hwnd is not None and current_hwnd != observed_hwnd:
            reasons.append("the foreground window changed since the observation")
        if last_action_ts is not None and last_action_ts > observed_ts:
            reasons.append("an action was performed after this observation")
        return {"fresh": not reasons, "age_s": round(age, 2), "reasons": reasons}


class UserActivityDetector:
    """
    GOKU declares what it is about to do (`expect`); the next observation is compared with that expectation.
    Unexplained foreground changes or pointer jumps are reported as manual user activity.
    """

    def __init__(self, pointer_tolerance_px: int = 6):
        self.tol = pointer_tolerance_px
        self.expected_cursor: Optional[Tuple[int, int]] = None
        self.expected_hwnd: Any = None
        self.last_cursor: Optional[Tuple[int, int]] = None
        self.last_hwnd: Any = None

    def expect(self, cursor: Optional[Tuple[int, int]] = None, hwnd: Any = None) -> None:
        self.expected_cursor, self.expected_hwnd = cursor, hwnd

    def check(self, cursor: Optional[Tuple[int, int]], hwnd: Any) -> Dict[str, Any]:
        signs: List[str] = []
        exp_c = self.expected_cursor or self.last_cursor
        if cursor and exp_c and (abs(cursor[0] - exp_c[0]) > self.tol or abs(cursor[1] - exp_c[1]) > self.tol):
            signs.append(f"pointer moved from {exp_c} to {cursor} without a GOKU action")
        exp_h = self.expected_hwnd if self.expected_hwnd is not None else self.last_hwnd
        if hwnd is not None and exp_h is not None and hwnd != exp_h:
            signs.append("foreground window changed without a GOKU action")
        self.last_cursor, self.last_hwnd = cursor or self.last_cursor, hwnd if hwnd is not None else self.last_hwnd
        self.expected_cursor = self.expected_hwnd = None
        return {"user_activity": bool(signs), "signs": signs}


# ---------------------------------------------------------------------------
# Orchestrator
# ---------------------------------------------------------------------------
Provider = Callable[..., Any]


class ScreenUnderstanding:
    """
    providers: dict of callables (all optional):
      window_meta() -> {"hwnd","title","pid","rect":(l,t,r,b),"process"}
      uia(hwnd)     -> list of {"name","role","bbox","text"?}
      ocr(region)   -> list of {"text","bbox"?,"confidence"?}
      capture(region, max_side) -> PIL image
      cursor()      -> (x, y)
      monitors()    -> list of {"index","bbox","primary","scale"}
    """

    def __init__(self, providers: Dict[str, Provider], clock: Callable[[], float] = time.time, max_age_s: float = DEFAULT_MAX_AGE_S,
                 pressure_fn: Optional[Callable[[], str]] = None, tier_fn: Optional[Callable[[], Dict[str, Any]]] = None):
        self.p = providers
        self.clock = clock
        self.max_age_s = max_age_s
        self.memory = VisualMemory()
        self.motion = frame_diff.MotionTracker()
        self.user = UserActivityDetector()
        self.guard = StaleGuard(max_age_s)
        self._prev_thumb: Optional[frame_diff.Thumb] = None
        self._prev_hwnd: Any = None
        self.pressure_fn = pressure_fn or _default_pressure
        self.tier_fn = tier_fn or _default_tier
        self.last_state: Optional[Dict[str, Any]] = None

    # -- collecting ------------------------------------------------------
    def _run(self, method: str, ev: List[Evidence], ctx: Dict[str, Any], plan: Dict[str, Any]) -> None:
        now = self.clock()
        prov = self.p.get(method)
        if prov is None and method == "pixel_diff":
            prov = True  # internal method: needs the captured image, not a provider
        if prov is None:
            ctx["unavailable"].append(method)
            return
        try:
            if method == "window_meta":
                m = prov() or {}
                if m:
                    ctx["window"] = m
                    ev.append(Evidence("window_meta", "title", "title", m.get("title", ""), now, m.get("rect"), 0.9))
            elif method == "uia":
                els = prov((ctx.get("window") or {}).get("hwnd")) or []
                ctx["uia_count"] = len(els)
                for e in els[:200]:
                    nm = str(e.get("name") or "").strip()
                    if nm:
                        ev.append(Evidence("uia", "element", f"element:{_norm(nm)}", nm, now, e.get("bbox"), 0.9, {"role": e.get("role")}))
                        ctx["texts"].append(nm)
                title = next((e.get("name") for e in els if str(e.get("role", "")).lower() in ("window", "title", "titlebar")), None)
                if title:
                    ev.append(Evidence("uia", "title", "title", title, now, None, 0.85))
            elif method == "capture":
                cap = plan.get("capture") or {}
                ctx["image"] = prov(ctx.get("region"), cap.get("max_side"))
            elif method == "pixel_diff":
                img = ctx.get("image")
                if img is not None:
                    t = frame_diff.thumb(img, region=None)
                    same_window = self._prev_hwnd == (ctx.get("window") or {}).get("hwnd")
                    if self._prev_thumb is not None and same_window:
                        d = frame_diff.diff(self._prev_thumb, t)
                        ctx["diff"] = d
                        ctx["motion"] = self.motion.add(d, now)
                        ev.append(Evidence("pixel_diff", "changed", "changed", d["level"], now, d.get("bbox_px"), 0.9))
                    elif self._prev_thumb is not None:
                        ctx["diff"] = {"comparable": False, "level": "major", "reason": "different window than the previous observation", "cells": [], "bbox_px": None}
                    ctx["phash"] = frame_diff.dhash(t)
                    self._prev_thumb, self._prev_hwnd = t, (ctx.get("window") or {}).get("hwnd")
            elif method == "ocr":
                region = ctx.get("region")
                items = prov(region) or []
                for it in items[:200]:
                    tx = str(it.get("text") or "").strip()
                    if tx:
                        ev.append(Evidence("ocr", "text", f"text:{_norm(tx)}", tx, now, it.get("bbox"), float(it.get("confidence", 0.7))))
                        ctx["texts"].append(tx)
                        if len(tx) <= 40:
                            ev.append(Evidence("ocr", "element", f"element:{_norm(tx)}", tx, now, it.get("bbox"), float(it.get("confidence", 0.7))))
            elif method == "cursor":
                ctx["cursor"] = prov()
            elif method == "monitors":
                ctx["monitors"] = prov() or []
        except Exception as exc:
            ctx["errors"].append(f"{method}: {type(exc).__name__}: {exc}")

    # -- public ----------------------------------------------------------
    def observe(self, goal: str = "overview", region: Optional[Tuple[int, int, int, int]] = None, max_rounds: int = 2) -> Dict[str, Any]:
        pressure = "normal"
        try:
            pressure = self.pressure_fn()
        except Exception:
            pass
        tier = {}
        try:
            tier = self.tier_fn() or {}
        except Exception:
            pass
        ocr_allowed = bool(tier.get("ocr_allowed", True))
        evidence: List[Evidence] = []
        ctx: Dict[str, Any] = {"texts": [], "errors": [], "unavailable": [], "region": region}
        plan = plan_observation(goal, pressure, ocr_allowed, tier.get("screen_size"), tier.get("screenshot_max_side"), tier.get("free_mb"))
        rounds = 0
        fused: Dict[str, Any] = {}
        tried = set()
        while rounds < max(1, max_rounds):
            rounds += 1
            for m in plan["methods"]:
                if m in tried and m not in ("window_meta",):
                    continue
                self._run(m, evidence, ctx, plan)
                tried.add(m)
            fused = fuse(evidence, self.clock(), self.max_age_s)
            if not fused["needs_reobserve"] or rounds >= max_rounds:
                break
            # insufficient or conflicting -> look again with a stronger method instead of guessing
            extra = []
            if "ocr" not in tried and ocr_allowed and pressure == "normal":
                extra.append("ocr")
            if "uia" not in tried:
                extra.append("uia")
            if not extra:
                evidence = [e for e in evidence if e.method in ("window_meta",)] if fused["conflicts"] else evidence
                tried -= {"uia", "ocr", "window_meta"}
                if rounds >= 1 and fused["conflicts"]:
                    plan["methods"] = [m for m in plan["methods"] if m in ("window_meta", "uia", "ocr")] or ["window_meta"]
                else:
                    break
            else:
                plan["methods"] = extra
        win = ctx.get("window") or {}
        diag = classify_texts(ctx["texts"])
        user = self.user.check(tuple(ctx["cursor"]) if ctx.get("cursor") else None, win.get("hwnd"))
        names = [f["value"] for f in fused.get("facts", []) if f["kind"] == "element"][:25]
        if win:
            self.memory.remember(self.clock(), win.get("title", ""), win.get("hwnd"), ctx.get("phash"), names)
        seen = self.memory.seen_before(ctx["phash"]) if ctx.get("phash") is not None and len(self.memory.items) > 1 else None
        state = {
            "ts": self.clock(), "goal": plan["goal"], "plan": plan, "rounds": rounds, "window": win, "monitors": ctx.get("monitors", []),
            "cursor": ctx.get("cursor"), "elements": [f for f in fused.get("facts", []) if f["kind"] == "element"][:60],
            "title_fact": next((f for f in fused.get("facts", []) if f["kind"] == "title"), None),
            "errors": diag["errors"], "dialog": {"buttons": diag["dialog_buttons"], "looks_like_dialog": diag["looks_like_dialog"]},
            "change": ctx.get("diff"), "motion": ctx.get("motion"), "user_activity": user, "returning_to_known_screen": bool(seen and seen.get("title")),
            "conflicts": fused.get("conflicts", []), "confidence": fused.get("confidence", 0.0),
            "needs_reobserve": fused.get("needs_reobserve", True), "reasons": fused.get("reasons", []),
            "unavailable_methods": ctx["unavailable"], "provider_errors": ctx["errors"], "limits": plan["limits"],
        }
        if state["needs_reobserve"]:
            state["verdict"] = "UNCERTAIN: " + "; ".join(state["reasons"] or ["insufficient evidence"]) + ". Do not act on this observation without observing again."
        else:
            state["verdict"] = "OK"
        state["suggested_region"] = frame_diff.suggest_region(ctx["diff"], tuple(win.get("size") or (0, 0))) if ctx.get("diff") and win.get("size") else None
        self.last_state = state
        return state

    def safe_to_act(self, current_hwnd: Any = None, last_action_ts: Optional[float] = None) -> Dict[str, Any]:
        """False unless the last observation is fresh, certain and not overtaken by the user or by GOKU's own action."""
        s = self.last_state
        if s is None:
            return {"safe": False, "reasons": ["nothing has been observed yet"]}
        g = self.guard.check(s["ts"], (s.get("window") or {}).get("hwnd"), current_hwnd, self.clock(), last_action_ts)
        reasons = list(g["reasons"])
        if s["needs_reobserve"]:
            reasons.append("the observation itself was uncertain")
        if s["user_activity"]["user_activity"]:
            reasons.append("the user did something manually; re-observe first")
        if any(e["severity"] == "critical" for e in s["errors"]):
            reasons.append("a critical error is on screen")
        return {"safe": not reasons, "reasons": reasons}


def _default_pressure() -> str:
    from tools.resource_monitor import pressure_level, sample

    s = sample(False)
    return pressure_level(s.get("ram_free_mb"))


def _default_tier() -> Dict[str, Any]:
    from tools.hw_profile import get_hw_profile

    p = get_hw_profile()
    st = dict(p["settings"])
    st["free_mb"] = p.get("ram_available_mb_at_probe")
    return st
