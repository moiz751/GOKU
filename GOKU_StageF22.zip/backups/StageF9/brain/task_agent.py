"""
Task router (P2). Decides whether a request is a calculation, an explicit deep-thinking request, a system
action or something else, and answers the first two itself. Everything else returns None so the existing
command_layer.router.handle_command keeps full ownership (no existing behaviour is replaced).

    route(text)        -> {"route": "calc"|"deep"|"action"|"other", "confidence": float, "reason": str}
    try_handle(text)   -> reply string, or None meaning "not mine, use handle_command"
"""
from __future__ import annotations

import re
from typing import Any, Callable, Dict, List, Optional

from brain import calc_engine, reasoning_engine

_ACTION_START = re.compile(
    r"^\s*(open|launch|start|run|close|kill|stop|kholo|khol|band|delete|remove|create|make|rename|copy|move|play|pause|search|find|type|write|click|press|scroll|"
    r"take|capture|screenshot|read|summari[sz]e|show|list|set|turn|volume|mute|download|install|send|save|focus|switch|minimi[sz]e|maximi[sz]e|lock|shutdown|restart)\b", re.I)


_FILE_VERB = re.compile(r"^\s*(?:please\s+)?(deep\s+analy[sz]e|analy[sz]e|audit|review|inspect|compare|code\s+review)\b", re.I)
_PATH = re.compile(r"""(?:"([^"]+)"|'([^']+)'|((?:[A-Za-z]:)?[\\/]?[\w\-. \\/~]+\.[A-Za-z0-9]{1,5}))""")


def _existing_paths(text: str) -> List[str]:
    import os

    found: List[str] = []
    for m in _PATH.finditer(text):
        cand = next((g for g in m.groups() if g), "").strip()
        for c in (cand, cand.split()[-1] if " " in cand else cand):
            c = os.path.expanduser(c)
            if c and os.path.isfile(c) and c not in found:
                found.append(c)
                break
    for tok in text.split():                     # unquoted paths without spaces, in the order they were written
        c = os.path.expanduser(tok.strip("\"',;"))
        if c and os.path.isfile(c) and c not in found:
            found.append(c)
    order = {p: text.find(p) for p in found}
    found.sort(key=lambda p: order[p] if order[p] >= 0 else 10 ** 9)
    return found


_EXTRA = re.compile(r"^\s*(verify\s+quote|column\s+stats|code\s+graph|corpus|retrieve\s+context)\b", re.I)


def _handle_extras(text: str) -> str:
    from brain import doc_extras

    t = text.strip()
    try:
        if re.match(r"(?i)verify\s+quote", t):
            m = re.match(r"(?is)verify\s+quote\s+[\"'](.+?)[\"']\s+(?:in|inside|mein)\s+(.+)$", t)
            if not m:
                return 'Use: verify quote "text to check" in <file>'
            r = doc_extras.verify_quote(m.group(2).strip().strip("\"'"), m.group(1))
            if r["found"]:
                return f"Quote {'found exactly' if r['exact'] else 'found (close match, similarity %.0f%%)' % (r['similarity'] * 100)} at {r['loc']}: {r['text'][:120]}"
            return f"Quote NOT found. {r.get('note', '')}" + (f" Closest ({r['similarity']:.0%}) at {r['loc']}: {r['text'][:120]}" if r.get("loc") else "")
        paths = _existing_paths(t)
        if re.match(r"(?i)column\s+stats", t):
            if not paths:
                return "Use: column stats <file.csv|file.xlsx>"
            r = doc_extras.column_stats(paths[0])
            lines = [f"{r['rows']} rows, {len(r['columns'])} columns, {r['duplicate_rows']} duplicate rows"]
            for c in r["columns"][:20]:
                lines.append(f"  {c['name']}: " + (f"number, min {c['min']}, max {c['max']}, mean {c['mean']}, nulls {c['nulls']}" if c["type"] == "number" else f"text, {c['distinct']} distinct, nulls {c['nulls']}"))
            lines += [f"  related: {x['a']} ~ {x['b']} (r={x['correlation']}) - correlation is not causation" for x in r["related"][:5]]
            return "\n".join(lines)
        if re.match(r"(?i)code\s+graph", t):
            import os
            arg = re.sub(r"(?i)^\s*code\s+graph\s*", "", t).strip().strip("\"'")
            arg = os.path.expanduser(arg)
            if not (arg and os.path.exists(arg)):
                return "Use: code graph <folder or .py file>"
            g = doc_extras.code_graph(arg)
            lines = [f"{g['modules']} modules, {g['edges']} imports between them"]
            lines += ["circular import: " + " -> ".join(c) for c in g["circular_imports"][:5]] or []
            lines += [f"unreferenced: {d['module']}.{d['function']} (line {d['line']})" for d in g["unreferenced_functions"][:10]]
            lines.append(g["note"])
            return "\n".join(lines)
        if re.match(r"(?i)corpus", t):
            if len(paths) < 2:
                return "Use: corpus <file1> <file2> [more files]"
            r = doc_extras.analyze_corpus(paths)
            lines = [f"{r['files']} files; shared keywords: {', '.join(r['shared_keywords']) or 'none'}"]
            lines += [f"duplicated passage in {', '.join(d['files'])}" for d in r["duplicated_passages"][:5]]
            lines += [f"number conflict '{c['label']}': {c['values']}" for c in r["cross_file_number_conflicts"][:5]]
            return "\n".join(lines)
        if re.match(r"(?i)retrieve\s+context", t):
            m = re.match(r"(?is)retrieve\s+context\s+(\S+)\s+(.+)$", t)
            if not m:
                return "Use: retrieve context <file> <location>"
            ctx = doc_extras.retrieve_context(m.group(1), m.group(2).strip())
            return "\n".join(f"[{c['loc']}] {c['text']}" for c in ctx) or "No such location in that file."
    except Exception as exc:
        return f"[analysis] could not finish: {type(exc).__name__}: {exc}"
    return "Not understood."


def _f5_route(t: str) -> str:
    if re.match(r"^\s*(wrong|galat|ghalat)\s*(:.*)?$", t, re.I):
        return "wrong_feedback"
    if re.match(r"^\s*fact\s+(history|now|forget)\s+\S", t, re.I):
        return "fact_versions"
    if re.match(r"^\s*regressions?(\s+(list|run|promote))?\s*$", t, re.I):
        return "regressions"
    if re.match(r"^\s*dialog(\s+(show|clear))?\s*$", t, re.I):
        return "dialog"
    if re.match(r"^\s*seo\s+(run|status|approve|show)\b", t, re.I):
        return "seo_workflow"
    if re.match(r"^\s*lessons?\s+(list|show)\b", t, re.I):
        return "lessons"
    if re.match(r"^\s*schedule\s+(add|list|status|stop)\b", t, re.I):
        return "recurring"
    if re.match(r"^\s*(?:content|preserve)\s+compare\s+(files?\s+)?\S+\s+(and|aur|with|se)\s+\S+", t, re.I):
        return "content_compare"
    if re.match(r"^\s*(understand|samjho)\s*:\s*\S", t, re.I):
        return "understand"
    if re.match(r"^\s*gate\s*:\s*\S", t, re.I):
        return "action_gate"
    if re.search(r"(?i)instruction\s+ko\s+english\s+mein\s+convert", t) and ":" in t:
        return "translate"
    if re.search(r"(?is)(\d+\s*parts?\s+mein\s+divide|split\s+.*\bparts?\b|parts?\s+mein\s+(?:divide|baanto|bhejo)).*:\s*\S", t):
        return "split_text"
    try:
        from brain import task_understanding as _tu
        if _tu.policy_answer(t):
            return "policy"
        from brain import capability_status as _cs
        if re.match(r"(?i)^\s*(kya\s+(tum|aap)|can\s+you|could\s+you)\b", t) and _cs.assess(t):
            return "capability"
    except Exception:
        pass
    if re.match(r"^\s*(explain|trace|plan|route)\s*:?\s+\S", t, re.I):
        return "route_planner"
    if re.match(r"^\s*translate\b.*[:\-]\s*\S", t, re.I):
        return "translate"
    if re.match(r"^\s*pending\s+tasks?(\s+(list|resume))?\s*$", t, re.I):
        return "pending_tasks"
    try:
        from brain import task_route_planner as _rp
        _p = _rp.parse(t)
        if _p["intent"] in ("download", "download_then_move") and (_p["entities"]["urls"] or re.search(r"(?i)\binternet\b", t)):
            return "route_run"
        if _rp._unsupported_kind(t.lower(), _p["intent"]):
            return "route_plan"
    except Exception:
        pass
    return ""


def _f4_route(t: str) -> str:
    if re.match(r"^\s*features?(\s|$)", t, re.I):
        return "feature_switches"
    if re.match(r"^\s*presence(\s|$)", t, re.I):
        return "presence"
    m = re.match(r"^\s*advise\s+(\S+)", t, re.I)
    if m:
        from brain.capability_catalog import resolve_kind
        return "advisor" if resolve_kind(m.group(1)) else ""
    if re.match(r"^\s*doc\s+(index|outline|ask|summary|dups|contradictions|missing|refs|tables|symbols)\s+\S", t, re.I):
        return "doc_index"
    return ""


def _is_planner_command(t: str) -> bool:
    if re.match(r"^\s*(system\s+scan|scan\s+system|capabilit(y|ies)|pending(\s+(list|check|report|cancel)\b.*)?|work(\s+(status|run|file\s+\S.*))?)\s*$", t, re.I):
        return True
    m = re.match(r"^\s*plan\s+(\S+)(\s+[\d.]+\s*(mb|gb)?)?\s*$", t, re.I)
    if m:
        from brain.capability_catalog import resolve_kind
        return bool(resolve_kind(m.group(1)))
    return False


def route(text: str) -> Dict[str, Any]:
    t = (text or "").strip()
    if not t:
        return {"route": "other", "confidence": 0.0, "reason": "empty"}
    if _EXTRA.match(t):
        return {"route": "extras", "confidence": 0.9, "reason": "document/code analysis command"}
    if re.match(r"^\s*(remember|yaad rakho|yaad rakhna)\b\s*(that|ke)?\s+\S+", t, re.I):
        return {"route": "remember", "confidence": 0.95, "reason": "store a user fact"}
    if re.match(r"^\s*(ask|answer|sawal|puchho)\s*[:,]?\s+\S+", t, re.I):
        return {"route": "answer_full", "confidence": 0.95, "reason": "explicit question for the answer engine"}
    if re.match(r"^\s*tasks?(\s+(list|status|pause|resume|cancel|confirm|report|run)\b.*)?\s*$", t, re.I):
        return {"route": "task_manager", "confidence": 0.95, "reason": "task manager command"}
    if _is_planner_command(t):
        return {"route": "capability_planner", "confidence": 0.95, "reason": "system scan / capability / pending-work command"}
    _f5 = _f5_route(t)
    if _f5:
        return {"route": _f5, "confidence": 0.95, "reason": "stage F5 command (wrong / fact / regressions / dialog)"}
    _f4 = _f4_route(t)
    if _f4:
        return {"route": _f4, "confidence": 0.95, "reason": "stage F4 command (features / presence / advise / doc)"}
    if re.match(r"^\s*(memory|knowledge)\s+\w+", t, re.I):
        return {"route": "memory", "confidence": 0.95, "reason": "memory/knowledge data command"}
    if _FILE_VERB.match(t) and _existing_paths(t):
        return {"route": "file", "confidence": 0.9, "reason": "analyse/review/compare an existing file"}
    if reasoning_engine.wants_deep(t) and not _ACTION_START.match(t):
        return {"route": "deep", "confidence": 0.9, "reason": "explicit deep-thinking request"}
    score = calc_engine.looks_like_math(t)
    if score >= 0.5 and not _ACTION_START.match(t):
        return {"route": "calc", "confidence": score, "reason": "looks like a calculation"}
    if _ACTION_START.match(t):
        return {"route": "action", "confidence": 0.7, "reason": "starts with an action verb"}
    if reasoning_engine.classify_complexity(t) == "complex" and "?" in t:
        return {"route": "deep", "confidence": 0.6, "reason": "long multi-part question"}
    return {"route": "other", "confidence": 0.3, "reason": "no specialised route"}


def _model_ask() -> Optional[Callable[[str], Optional[str]]]:
    """The model is used only when the existing readiness gate allows it; otherwise reasoning stays deterministic."""
    try:
        from config.settings import is_model_call_allowed

        allowed = is_model_call_allowed()
        if isinstance(allowed, tuple):
            allowed = allowed[0]
        if not allowed:
            return None
        from brain.llm import ask_conversational_llm

        return lambda prompt: ask_conversational_llm(prompt)
    except Exception:
        return None


_QUESTION = re.compile(r"(?is)^\s*(what|who|whom|where|when|why|how|which|is|are|does|do|can|kya|kitna|kitni|kitne|kaun|kahan|kab|konsa|kaise|passage\s*:)\b|\?\s*$")
_COMMANDISH = re.compile(r"(?is)^\s*(open|close|launch|start|run|delete|remove|kill|install|uninstall|restart|shutdown|click|type|press|kholo|band|chalao)\b")
_IMPLICIT_SOLVERS = {"passage", "dates", "clock", "math", "compare", "units", "stats", "geometry", "finance", "percent", "memory", "knowledge"}


def _remember(text: str) -> str:
    fact = re.sub(r"(?is)^\s*(remember|yaad rakho|yaad rakhna)\b\s*(that|ke)?\s+", "", text).strip()
    try:
        from brain import learning_hooks
        rec = learning_hooks.get_store().add("long_term", fact, source="user", trust=1.0)
        note = ""
        try:
            from brain import fact_versions
            st = fact_versions.parse_statement(fact) if rec else None
            if st:
                v = fact_versions.record(st["key"], st["value"], "user")
                if v.get("change") == "replaced":
                    note = f" (pehli value '{v['previous']}' ab purani hai; newest value use hogi. History: fact history {st['key']})"
        except Exception:
            pass
        return (f"Yaad rakh liya: {fact}" + note) if rec else "Yeh yaad nahi rakh saka (shayad secret jaisa text tha)."
    except Exception as exc:
        return f"[memory] could not store it: {type(exc).__name__}"


def _answer(question: str, full: bool, question_form: bool = True) -> Optional[str]:
    try:
        from brain import answer_engine
        mem = None
        try:
            from brain import learning_hooks
            mem = learning_hooks.get_store()
        except Exception:
            pass
        if full:
            try:
                from brain import answer_pipeline
                return answer_pipeline.respond(question, memory=mem)["display"]
            except Exception:
                pass
        if not full:
            try:
                from brain import answer_pipeline
                pr = answer_pipeline.respond(question, memory=mem)
                keep = pr["status"] in ("answered", "clarify", "refused", "confirm", "conflict", "partial") or (pr["status"] == "needs_web" and question_form)
                if pr["solver"] == "memory" and not question_form:
                    keep = False
                if pr["status"] in ("unknown", "action_needed", "llm_unverified"):
                    keep = False
                if keep and pr["solver"] != "llm":
                    return pr["display"]
                if pr["status"] in ("unknown", "action_needed", "llm_unverified", "needs_web") or not keep:
                    return None
            except Exception:
                pass
        r = answer_engine.answer(question, memory=mem)
    except Exception:
        return None
    if full:
        tag = {"answered": "", "needs_web": "[needs internet] ", "unknown": "[no verified answer] ", "clarify": "[need detail] ", "refused": "[refused] ", "confirm": "[needs confirmation] "}.get(r["status"], "")
        ev = ("\n  evidence: " + "; ".join(r["evidence"][:2])) if r["evidence"] else ""
        return f"{tag}{r['text']}{ev}"
    if r["status"] == "answered" and r["solver"] in _IMPLICIT_SOLVERS and (question_form or r["solver"] != "memory"):
        ev = ("\n  " + r["evidence"][0]) if r["evidence"] else ""
        return f"{r['text']}{ev}"
    return None


def try_handle(text: str, ask: Optional[Callable[[str], Optional[str]]] = None) -> Optional[str]:
    info = route(text)
    if info["route"] == "calc":
        guard = _answer(text, full=False)             # the answer engine refuses half-understood maths ("7 squared plus 3") and never treats dates as arithmetic
        if guard:
            return guard
        try:
            from brain import answer_engine
            g = answer_engine.answer(text)
            if g["status"] == "clarify" and g["solver"] in ("math", "dates"):
                return g["text"]
        except Exception:
            pass
        cmp = reasoning_engine.compare_values(text)
        if cmp:
            return f"{cmp['answer']} ({cmp['a']} vs {cmp['b']})\n  both sides computed exactly with fractions"
        res = calc_engine.calculate_from_text(text)
        if res is None:
            return None
        if not res["ok"]:
            return f"[calc] {res['error']}"
        extra = "" if res["verified"] else " (not verified)"
        steps = res.get("steps") or []
        how = f"\n  {res['verification']}" if res.get("verification") else ""
        head = f"{res['display']}{extra}"
        if res["kind"] in ("equation",) and steps:
            head += "\n  " + "\n  ".join(steps[:3])
        return head + how
    if info["route"] == "extras":
        return _handle_extras(text)
    if info["route"] == "remember":
        return _remember(text)
    if info["route"] == "answer_full":
        return _answer(re.sub(r"(?i)^\s*(ask|answer|sawal|puchho)\s*[:,]?\s+", "", text), full=True)
    if info["route"] == "task_manager":
        from brain import task_manager
        return task_manager.handle_task_command(text)["message"]
    if info["route"] == "capability_planner":
        from brain import capability_planner
        return capability_planner.handle_command(text)
    if info["route"] == "wrong_feedback":
        from brain import regression_log
        from brain.dialog_state import DialogState
        last = DialogState().last_turn
        if not last:
            return "Pichla jawab yaad nahi; pehle koi sawal poochein."
        fix = re.sub(r"(?i)^\s*(wrong|galat|ghalat)\s*:?\s*", "", text).strip()
        try:
            from brain import conversation
            if re.fullmatch(r"-?\d[\d,]*(?:\.\d+)?", fix):
                ds = DialogState()
                lm = conversation._last_math(ds)
                if lm and conversation._num(lm.get("text", "")) not in (None, fix.replace(",", "")):
                    return conversation._recall(f"Wrong, the answer is {fix}", ds)["text"] + " (Isliye ise regression case nahi banaya: aap ka number exact calculation se match nahi karta.)"
        except Exception:
            pass
        r = regression_log.record_failure(last["question"], last["text"], fix)
        return f"Note kar liya ({r['change']}): '{last['question'][:60]}' ka jawab ghalat tha" + (f", sahi: {fix}" if fix else "") + ". Yeh ab ek regression test case hai (regressions run). Main khud source code nahi badalta."
    if info["route"] == "fact_versions":
        from brain import fact_versions
        return fact_versions.handle_command(text)
    if info["route"] == "regressions":
        from brain import regression_log
        return regression_log.handle_command(text)
    if info["route"] in ("route_planner", "route_run", "route_plan"):
        from brain import task_route_planner as route_planner
        if info["route"] == "route_planner":
            return route_planner.handle_command(text)
        r = route_planner.run(text, queue=route_planner.PendingTasks()) if info["route"] == "route_run" else route_planner.plan(text)
        return r["trace"].render() + ("\n\n" + r["message"] if r.get("message") else "")
    if info["route"] == "recurring":
        from brain import recurring_tasks
        return recurring_tasks.handle_command(text)
    if info["route"] == "content_compare":
        from brain import content_diff
        return content_diff.handle_command(text)
    if info["route"] == "understand":
        from brain import task_understanding
        return task_understanding.handle_command(text)
    if info["route"] == "action_gate":
        from brain import action_gate
        return action_gate.handle_command(text.split(":", 1)[1])
    if info["route"] == "split_text":
        from brain import msg_split
        return msg_split.handle_command(text)
    if info["route"] == "policy":
        from brain import task_understanding
        return task_understanding.policy_answer(text)
    if info["route"] == "capability":
        from brain import capability_status
        try:
            from brain import task_route_planner as _trp
            _env = _trp.probe_env(need_net=False)
        except Exception:
            _env = {}
        return capability_status.handle_command(text, _env)
    if info["route"] == "translate":
        from brain import translate
        return translate.handle_command(text)
    if info["route"] == "pending_tasks":
        from brain import task_route_planner as route_planner
        q = route_planner.PendingTasks()
        if text.strip().lower().endswith("resume"):
            now = route_planner.probe_env(need_net=True)
            cap = q.capable_now(now)
            return ("Ab ye kaam kar sakta hoon: " + "; ".join(f"{i['id']}: {i['text']}" for i in cap) + " - dobara command dein ya 'trace: <command>' chalayein.") if cap else "Abhi koi pending kaam capable nahi (RAM/internet ki shart poori nahi hui)."
        pend = [i for i in q.items if i["state"] == "pending"]
        return "\n".join(f"{i['id']} [{i['state']}] {i['text']} (jab: {i['resume_when']})" for i in pend) or "Koi pending kaam nahi."
    if info["route"] == "seo_workflow":
        from brain import seo_workflow
        return seo_workflow.handle_command(text)
    if info["route"] == "lessons":
        from brain import lesson_store
        return lesson_store.handle_command(text)
    if info["route"] == "dialog":
        from brain.dialog_state import DialogState
        ds = DialogState()
        if re.search(r"(?i)clear", text):
            ds.clear()
            return "dialog record cleared"
        return ds.summary()
    if info["route"] == "feature_switches":
        from brain import feature_switches
        return feature_switches.handle_command(text)
    if info["route"] == "presence":
        from brain import presence
        return presence.handle_command(text)
    if info["route"] == "advisor":
        from brain import advisor, presence
        parts = text.split()
        size = 0.0
        for p in parts[2:]:
            try:
                size = float(p.lower().replace("mb", "").replace("gb", "")) * (1024 if p.lower().endswith("gb") else 1)
            except ValueError:
                pass
        return advisor.render(advisor.advise(parts[1], size, presence_info=presence.current()))
    if info["route"] == "doc_index":
        from brain import doc_index
        return doc_index.handle_command(text)
    if info["route"] == "memory":
        from brain import learning_hooks
        return learning_hooks.handle_memory_command(text)
    if info["route"] == "file":
        try:
            from brain import doc_insight

            paths = _existing_paths(text)
            if re.match(r"^\s*compare\b", text, re.I) and len(paths) >= 2:
                r = doc_insight.compare_files(paths[0], paths[1])
                lines = [f"Similarity {r['similarity']:.0%}; added {r['counts']['added']}, removed {r['counts']['removed']}, changed {r['counts']['changed']}" + ("  (identical)" if r["identical"] else "")]
                lines += [f"+ {a['text']}  [{a['loc']}]" for a in r["added"][:5]] + [f"- {a['text']}  [{a['loc']}]" for a in r["removed"][:5]] + [f"~ {c['a']} -> {c['b']}  [{c['a_loc']} / {c['b_loc']}]" for c in r["changed"][:5]]
                return "\n".join(lines)
            return doc_insight.render_report(doc_insight.analyze_file(paths[0]))
        except Exception as exc:
            return f"[file analysis] could not finish: {type(exc).__name__}: {exc}"
    if info["route"] == "deep":
        rep = reasoning_engine.reason(text, ask=ask if ask is not None else _model_ask())
        return rep.render()
    if not _COMMANDISH.match(text):
        return _answer(text, full=False, question_form=bool(_QUESTION.search(text)))   # only verified solver answers; everything else falls through unchanged
    return None
