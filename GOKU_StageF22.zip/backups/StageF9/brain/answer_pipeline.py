"""Answer pipeline (stage F5): the full path of a question, every stage visible.

  1 resolve    "it / isko / wahan / what about Italy" against the verified dialog record (brain/dialog_state.py); unclear -> ask
  2 decompose  a compound question becomes parts, answered one after another (brain/decompose.py); "then add 10" uses the previous number
  3 solve      versioned facts -> word problems -> constraints -> symbolic reasoning -> the answer engine (maths, dates, passage, memory, knowledge pack, real time, honest unknown)
  4 cross-check  memory vs knowledge pack disagreement is a CONFLICT (nothing is picked silently); maths is recomputed by an independent evaluator (second pass);
                 passage answers are graded sentence by sentence against the passage
  5 label      verified | likely | unknown | needs_internet  (+ clarify / refused / conflict), the worst label of all parts is the label of the answer
  6 remember   verified results go into the compact dialog record; the last turn is kept so `wrong: <correct answer>` can create a regression case
Every number in the output comes from code, not from a language model; a model answer is only ever shown as 'likely' (unverified).
"""
from __future__ import annotations

import datetime as dt
import re
from typing import Any, Callable, Dict, List, Optional

from brain import answer_engine, constraints, conversation, decompose, offline_skills, fact_versions, source_check, stepchain, symbolic, wordproblem
from brain.dialog_state import DialogState

_SEVERITY = ["verified", "likely", "needs_internet", "unknown"]


def _label(r: Dict[str, Any]) -> str:
    st = r.get("status")
    if st == "answered":
        return "verified" if r.get("verified") else "likely"
    if st == "llm_unverified":
        return "likely"
    if st == "needs_web":
        return "needs_internet"
    if st in ("clarify", "refused", "confirm", "conflict"):
        return st
    if st == "action_needed":
        return "action"
    return "unknown"


def _solve_one(q: str, *, memory: Any, today: Optional[dt.date], web_fn: Optional[Callable], llm: Optional[Callable], now: Optional[dt.datetime], last_target: Optional[str]) -> Dict[str, Any]:
    checks: List[str] = []
    r = fact_versions.answer_question(q)
    if r is None:
        for fn in (stepchain.solve, wordproblem.solve, constraints.solve, symbolic.solve):
            try:
                r = fn(q)
            except Exception:
                r = None
            if r is not None:
                break
    if r is None:
        try:
            r = offline_skills.solve(q)
        except Exception:
            r = None
    if r is None:
        r = answer_engine.answer(q, today=today, memory=memory, last_target=last_target, web_fn=web_fn, llm=llm, now=now)
    # cross-check between sources
    try:
        if r.get("solver") in ("memory", "knowledge") and r.get("status") == "answered":
            other = answer_engine._knowledge(q) if r["solver"] == "memory" else answer_engine._memory(q, memory)
            if other and other.get("status") == "answered":
                c = source_check.detect_conflict([{"source": r["solver"], "text": r["text"]}, {"source": other["solver"], "text": other["text"]}])
                if c["conflict"]:
                    d = c["details"][0]
                    return {"text": f"My sources disagree: {d['a']} says '{d['a_text']}', {d['b']} says '{d['b_text']}'. I will not pick one silently; tell me which is current.", "status": "conflict", "solver": "source_check",
                            "confidence": 0.9, "verified": False, "evidence": [f"{d['a']}: {d['a_text']}", f"{d['b']}: {d['b_text']}"], "language": r.get("language", "en"), "checks": ["conflict between sources"]}
                checks.append("memory and knowledge pack agree")
    except Exception:
        pass
    # second pass for computed maths
    sp = source_check.second_pass(q, r)
    if sp["applicable"] and sp["agree"] is True:
        checks.append("second pass: recomputed independently, same result")
    elif sp["applicable"] and sp["agree"] is False:
        return {"text": "Two independent calculations disagree, so I am not giving a number. " + sp["note"], "status": "unknown", "solver": "second_pass", "confidence": 0.3, "verified": False,
                "evidence": [sp["note"]], "language": r.get("language", "en"), "checks": ["second pass FAILED"]}
    # grade passage answers against the passage they came from
    if r.get("solver") == "passage" and r.get("status") == "answered":
        g = source_check.grade_answer(r["text"], [q])
        checks.append("answer graded against your text: " + g["overall"])
        if g["overall"] == "unsupported":
            r = dict(r, verified=False, status="unknown", text="I could not find this answer in the text you gave.")
    r = dict(r)
    r["checks"] = checks
    return r


def _special(q: str) -> Optional[Dict[str, Any]]:
    """Whole-question solvers that must see the full text before any splitting."""
    for fn in (stepchain.solve, wordproblem.solve, constraints.solve, symbolic.solve):
        try:
            r = fn(q)
        except Exception:
            r = None
        if r is not None:
            return r
    return None


def respond(question: str, *, state: Optional[DialogState] = None, memory: Any = None, today: Optional[dt.date] = None, web_fn: Optional[Callable] = None,
            llm: Optional[Callable] = None, now: Optional[dt.datetime] = None, record: bool = True) -> Dict[str, Any]:
    import os
    q0 = str(question or "").strip()
    if state is None and "PYTEST_CURRENT_TEST" in os.environ and not os.environ.get("GOKU_DIALOG_FILE"):
        record = False                                   # tests must not write the user's real dialog record
    st = state if state is not None else DialogState()
    if not q0:
        return {"text": "Sawal likhein.", "status": "clarify", "solver": "empty", "confidence": 1.0, "verified": False, "evidence": [], "language": "ur", "label": "clarify", "parts": [], "resolved": [], "display": "[need detail] Sawal likhein."}
    try:
        bctx = next((e["data"] for e in reversed(st.entries) if e["kind"] == "budget" and st.clock() - e["t"] <= 6 * 3600), None)
        osk = offline_skills.solve(q0, budget_ctx=bctx)
    except Exception:
        osk = None
    if osk is not None:
        lab = _label(osk)
        ev = ("\n  evidence: " + "; ".join(osk.get("evidence", [])[:2])) if osk.get("evidence") else ""
        tag = {"answered": "", "unknown": "[no verified answer] ", "clarify": "[need detail] ", "refused": "[refused] ", "action_needed": "[action] "}.get(osk["status"], "")
        out = {"text": osk["text"], "status": osk["status"], "solver": osk["solver"], "confidence": osk.get("confidence", 0.9), "verified": bool(osk.get("verified")), "evidence": osk.get("evidence", []),
               "language": "en", "label": lab, "parts": [{"q": q0, "text": osk["text"], "status": osk["status"], "label": lab, "solver": osk["solver"]}], "resolved": [], "checks": [],
               "display": f"{tag}{osk['text']}{ev}" + (f"\n  confidence label: {lab}" if lab in _SEVERITY else "")}
        if record:
            try:
                st.record(q0, out)
                st.set_last(q0, osk["text"], osk["status"])
                if osk.get("context"):
                    st._add("budget", "budget", st.turn_no(), True, data=osk["context"]["value"])
                    st._save()
            except Exception:
                pass
        return out
    try:
        conv = conversation.handle(q0, st)
    except Exception:
        conv = None
    if conv is not None:
        lab = _label(conv)
        tag = {"answered": "", "clarify": "[need detail] ", "conflict": "[sources disagree] ", "refused": "[refused] "}.get(conv["status"], "")
        ev = ("\n  evidence: " + "; ".join(conv.get("evidence", [])[:2])) if conv.get("evidence") else ""
        return {"text": conv["text"], "status": conv["status"], "solver": conv["solver"], "confidence": conv.get("confidence", 0.9), "verified": bool(conv.get("verified")), "evidence": conv.get("evidence", []),
                "language": "en", "label": lab, "parts": [{"q": q0, "text": conv["text"], "status": conv["status"], "label": lab, "solver": conv["solver"]}], "resolved": [], "checks": [], "display": f"{tag}{conv['text']}{ev}"}
    try:
        selfcontained = stepchain.solve(q0) is not None      # "... multiply the result by 2" inside one complete chain must not borrow an older number
    except Exception:
        selfcontained = False
    res = {"status": "ok", "question": q0, "resolved": []} if selfcontained else st.resolve(q0)
    if res["status"] == "ambiguous":
        return {"text": res["message"], "status": "clarify", "solver": "dialog", "confidence": 0.9, "verified": False, "evidence": [], "language": "ur", "label": "clarify", "parts": [], "resolved": [],
                "display": "[need detail] " + res["message"]}
    q = res["question"]
    whole = _special(q)
    dec = {"mode": "single", "parts": [{"q": q, "chain": None}]} if whole is not None else decompose.split_question(q)
    parts: List[Dict[str, Any]] = []
    prev_num: Optional[str] = None
    last_target = None
    for p in dec["parts"]:
        pq = p["q"]
        if p["chain"]:
            if prev_num is None:
                parts.append({"q": pq, "r": {"text": "There is no previous number for this step.", "status": "clarify", "solver": "decompose", "verified": False, "evidence": [], "confidence": 0.8, "language": "en", "checks": []}})
                continue
            pq = decompose.chain_expression(prev_num, p["chain"])
        r = _solve_one(pq, memory=memory, today=today, web_fn=web_fn, llm=llm, now=now, last_target=last_target)
        if whole is not None and r.get("solver") == whole.get("solver"):
            r["checks"] = r.get("checks", []) + ["solved from the whole text, not split"]
        parts.append({"q": pq, "r": r})
        nums = re.findall(r"-?\d[\d,]*\.?\d*", str(r.get("text", "")).replace(",", ""))
        prev_num = nums[0].rstrip(".") if (r.get("status") == "answered" and r.get("verified") and nums) else None
    labels = [_label(p["r"]) for p in parts]
    sev = max((labels.index(l) if False else (_SEVERITY.index(l) if l in _SEVERITY else -1)) for l in labels) if any(l in _SEVERITY for l in labels) else -1
    overall_label = _SEVERITY[sev] if sev >= 0 else labels[0]
    if len(parts) == 1:
        r = dict(parts[0]["r"])
        text, status = r["text"], r["status"]
    else:
        text = "\n".join(f"{i + 1}) {p['q']} -> {p['r']['text']}  [{_label(p['r'])}]" for i, p in enumerate(parts))
        ok = [p["r"]["status"] == "answered" for p in parts]
        status = "answered" if all(ok) else "partial" if any(ok) else parts[0]["r"]["status"]
        r = {"solver": "pipeline", "confidence": min(p["r"].get("confidence", 0.5) for p in parts), "verified": all(p["r"].get("verified") for p in parts), "evidence": [e for p in parts for e in p["r"].get("evidence", [])][:6],
             "language": parts[0]["r"].get("language", "en")}
    notes = [f"'{x['what']}' = {x['as']} ({x['from']})" for x in res["resolved"]]
    checks = list(dict.fromkeys(c for p in parts for c in p["r"].get("checks", [])))
    tag = {"answered": "", "needs_web": "[needs internet] ", "unknown": "[no verified answer] ", "clarify": "[need detail] ", "refused": "[refused] ", "confirm": "[needs confirmation] ",
           "conflict": "[sources disagree] ", "partial": "[partly answered] ", "llm_unverified": ""}.get(status, "")
    ev = ("\n  evidence: " + "; ".join(r.get("evidence", [])[:2])) if r.get("evidence") else ""
    extra = ("\n  understood: " + "; ".join(notes) if notes else "") + ("\n  checks: " + "; ".join(checks) if checks else "") + (f"\n  confidence label: {overall_label}" if overall_label in _SEVERITY and status in ("answered", "partial", "llm_unverified", "needs_web", "unknown") else "")
    out = {"text": text, "status": status, "solver": r.get("solver", "pipeline"), "confidence": r.get("confidence", 0.5), "verified": bool(r.get("verified")), "evidence": r.get("evidence", []), "language": r.get("language", "en"),
           "label": overall_label, "parts": [{"q": p["q"], "text": p["r"]["text"], "status": p["r"]["status"], "label": _label(p["r"]), "solver": p["r"].get("solver")} for p in parts], "resolved": res["resolved"],
           "checks": checks, "display": f"{tag}{text}{ev}{extra}"}
    if record:
        try:
            st.record(q0, out)
            st.set_last(q0, text, status)
        except Exception:
            pass
    return out
