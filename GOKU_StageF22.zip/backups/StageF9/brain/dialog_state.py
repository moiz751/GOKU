"""Dialog state (stage F5, techniques #36 entity resolution and #37 compact conversation record).

Keeps a SHORT record of the last verified turns (numbers, files, topics, last question template) and resolves "it / that / isko / usko / wahan / what about Italy"
against it. Rules:
  * only VERIFIED results can be a referent for a number; unverified model text never becomes 'it'
  * the referent is always shown to the user ("it = 42, your previous answer") so a wrong guess is visible
  * two different files in the last turn, or nothing suitable in the last 6 hours -> ask, never guess
Record: at most 12 short entries in logs/state/dialog.json; nothing else about the conversation is stored.
"""
from __future__ import annotations

import json
import os
import re
import time
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

PROJECT_ROOT = Path(__file__).absolute().parent.parent
STATE_FILE = Path(os.environ.get("GOKU_DIALOG_FILE", str(PROJECT_ROOT / "logs" / "state" / "dialog.json")))
MAX_ENTRIES, FRESH_S = 60, 6 * 3600
_PATH = re.compile(r"""(?:"([^"]+\.[A-Za-z0-9]{1,5})"|((?:[A-Za-z]:)?[\\/]?[\w\-.~/\\]+\.[A-Za-z0-9]{1,5})\b)""")
_NUM_PRON = re.compile(r"(?i)\b(it|that|this|the result|the answer|that number|isko|usko|isse|usse|is mein|us mein|iska|uska|pichla jawab|previous answer|last answer)\b")
_FILE_PRON = re.compile(r"(?i)\b(it|that file|this file|the file|same file|wahi file|us file|is file|isko|usko|that one)\b")
_FILE_VERB = re.compile(r"(?i)\b(open|read|analy[sz]e|review|summari[sz]e|delete|show|kholo|parho|dikhao|check|index|compare)\b")
_MATH_VERB = re.compile(r"(?i)\b(double|twice|triple|half|square|cube|add|plus|subtract|minus|multiply|times|divide|dugna|tigna|aadha|jama|ghata|guna|taqseem|percent|%|\+|\-|\*|/)")
_PLACE_PRON = re.compile(r"(?i)\b(there|wahan|wahaan|us mulk|us shehar)\b")
_PREV_TOPIC = re.compile(r"(?i)^\s*(?:and|what about|how about|aur|or)\s+(?:the\s+)?(?![^?]*\b(?:ki|ka|capital|kya|is|was|of|thi|hai)\b)([A-Za-z][A-Za-z .'-]{1,30}?)\s*\??\s*$")
_SUBJECT = [re.compile(r"(?i)\b(capital of)\s+([A-Za-z][A-Za-z .'-]*?)\s*\??\s*$"), re.compile(r"(?i)^\s*([A-Za-z][A-Za-z .'-]*?)\s+(ki|ka)\s+(capital|darulhukumat)\s*\??\s*$")]


class DialogState:
    def __init__(self, path: Any = None, clock: Callable[[], float] = time.time):
        self.path = Path(path) if path else STATE_FILE
        self.clock = clock
        data = self._load()
        self.entries: List[Dict[str, Any]] = data.get("entries", [])
        self.last_turn: Optional[Dict[str, Any]] = data.get("last_turn")
        self.passage: Optional[Dict[str, Any]] = data.get("passage")

    def _load(self) -> Dict[str, Any]:
        try:
            return json.loads(self.path.read_text(encoding="utf-8"))
        except Exception:
            return {}

    def set_last(self, question: str, text: str, status: str) -> None:
        self.last_turn = {"question": question[:500], "text": text[:500], "status": status, "t": self.clock()}
        self._save()

    def set_passage(self, text: str) -> None:
        self.passage = {"text": text[:6000], "t": self.clock()}
        self._save()

    def get_passage(self) -> Optional[str]:
        p = self.passage
        return p["text"] if p and self.clock() - p["t"] <= FRESH_S else None

    def _save(self) -> None:
        self.entries = self.entries[-MAX_ENTRIES:]
        self.path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.path.with_suffix(".tmp")
        tmp.write_text(json.dumps({"entries": self.entries, "last_turn": self.last_turn, "passage": self.passage}, indent=1), encoding="utf-8")
        os.replace(tmp, self.path)

    def clear(self) -> None:
        self.entries = []
        self._save()

    def _add(self, kind: str, value: str, turn: int, verified: bool, **extra: Any) -> None:
        self.entries.append(dict(kind=kind, value=str(value)[:200], turn=turn, verified=bool(verified), t=self.clock(), **extra))

    def turn_no(self) -> int:
        return (self.entries[-1]["turn"] + 1) if self.entries else 1

    def record(self, question: str, result: Dict[str, Any]) -> None:
        """Called after every answered turn. Stores files mentioned, the numeric answer (verified only), the answer text, and the question template."""
        n = self.turn_no()
        for m in _PATH.finditer(question):
            p = m.group(1) or m.group(2)
            if p and re.search(r"[\\/]|\.\w{2,4}$", p):
                self._add("file", p, n, True)
        if result.get("status") == "answered":
            nums = re.findall(r"-?\d[\d,]*\.?\d*", str(result.get("text", "")).replace(",", ""))
            if result.get("solver") in ("math", "dates", "clock", "wordproblem", "constraints") and result.get("verified") and nums:
                self._add("number", nums[0].rstrip("."), n, True, text=str(result.get("text"))[:120])
            self._add("answer", str(result.get("text", ""))[:200], n, bool(result.get("verified")))
        self._add("turn", question[:200], n, bool(result.get("verified")), text=str(result.get("text", ""))[:200], followup=bool(result.get("resolved")), solver=str(result.get("solver", "")), status=str(result.get("status", "")))
        for pat in _SUBJECT:
            m = pat.search(question)
            if m:
                subj = (m.group(2) if pat is _SUBJECT[0] else m.group(1)).strip()
                self._add("topic", subj, n, True, template="capital of {X}", subject_kind="country")
                break
        self._save()

    # ------------------------------------------------------------------ resolve
    def _fresh(self, kind: str, verified_only: bool = True) -> List[Dict[str, Any]]:
        now = self.clock()
        return [e for e in reversed(self.entries) if e["kind"] == kind and now - e["t"] <= FRESH_S and (e["verified"] or not verified_only)]

    def resolve(self, question: str) -> Dict[str, Any]:
        q = question.strip()
        out: Dict[str, Any] = {"question": q, "resolved": [], "status": "none", "message": ""}
        m = _PREV_TOPIC.match(q)
        if m and self._fresh("topic"):
            t = self._fresh("topic")[0]
            new = f"capital of {m.group(1).strip().title()}"
            out.update(question=new, status="ok", resolved=[{"what": q, "as": new, "from": f"your earlier question about {t['subject_kind']} ({t['value']})"}])
            return out
        if _PLACE_PRON.search(q) and re.search(r"(?i)\b(capital|darulhukumat|weather|mausam|population|time|kitna|kya|ki|ka|where|distance|ke)\b", q):
            tops = self._fresh("topic")
            if not tops:
                return dict(out, status="ambiguous", message="Kis jagah ke baare mein? Naam batayein. (which place do you mean?)")
            new = _PLACE_PRON.sub(tops[0]["value"], q)
            new = re.sub(r"(?i)\b(wahan ki|there)\s*capital", "capital of " + tops[0]["value"], new)
            out.update(question=f"capital of {tops[0]['value']}" if re.search(r"(?i)capital|darulhukumat", q) else new, status="ok", resolved=[{"what": "there", "as": tops[0]["value"], "from": "your earlier question"}])
            return out
        from brain import decompose
        cm = decompose._CHAIN.match(q)
        if cm and (cm.group(2) or cm.group(1).lower() in ("double", "triple", "half", "square")):
            nums = self._fresh("number")
            if not nums:
                return dict(out, status="ambiguous", message="Kis number par? Pichla verified number nahi mila; number likh dein. (no verified previous number)")
            n = nums[0]["value"]
            out.update(question=decompose.chain_expression(n, {"verb": cm.group(1).lower().split()[0], "arg": cm.group(2)}), status="ok",
                       resolved=[{"what": "the previous result", "as": n, "from": f"your previous answer: {nums[0].get('text', n)}"}])
            return out
        if _MATH_VERB.search(q) and _NUM_PRON.search(q):
            nums = self._fresh("number")
            if not nums:
                return dict(out, status="ambiguous", message="'it' kis number ke liye? Pichla verified number nahi mila; number likh dein. (no verified previous number)")
            n = nums[0]["value"]
            new = self._rewrite_math(q, n)
            out.update(question=new, status="ok", resolved=[{"what": "it", "as": n, "from": f"your previous answer: {nums[0].get('text', n)}"}])
            return out
        if _FILE_VERB.search(q) and _FILE_PRON.search(q) and not _PATH.search(q):
            last_turn = [e for e in self.entries if e["kind"] == "file" and self.clock() - e["t"] <= FRESH_S]
            if not last_turn:
                return dict(out, status="ambiguous", message="Kaunsi file? Naam ya path likhein. (no file mentioned recently)")
            turn = last_turn[-1]["turn"]
            files = sorted({e["value"] for e in last_turn if e["turn"] == turn})
            if len(files) > 1:
                return dict(out, status="ambiguous", message="Pichle sawal mein ek se zyada files thin: " + ", ".join(files) + ". Kaunsi?")
            new = _FILE_PRON.sub(f'"{files[0]}"', q, count=1)
            out.update(question=new, status="ok", resolved=[{"what": "it", "as": files[0], "from": "the file in your previous message"}])
        return out

    @staticmethod
    def _rewrite_math(q: str, n: str) -> str:
        ql = q.lower()
        for pat, fmt in ((r"\b(double|twice|dugna)\b", "{n} * 2"), (r"\b(triple|tigna)\b", "{n} * 3"), (r"\b(half|aadha)\b", "{n} / 2"), (r"\bsquare\b", "{n} ** 2"), (r"\bcube\b", "{n} ** 3")):
            if re.search(pat, ql):
                return fmt.format(n=n)
        m = re.search(r"(?i)\b(?:add|plus|jama)\s+(-?\d+(?:\.\d+)?)", q) or re.search(r"(?i)\b(?:it|isko|usko)\s*\+\s*(-?\d+(?:\.\d+)?)", q)
        if m:
            return f"{n} + {m.group(1)}"
        m = re.search(r"(?i)\b(?:subtract|minus|ghata)\s+(-?\d+(?:\.\d+)?)", q)
        if m:
            return f"{n} - {m.group(1)}"
        m = re.search(r"(?i)\b(?:multiply(?: by)?|times|guna)\s+(-?\d+(?:\.\d+)?)", q)
        if m:
            return f"{n} * {m.group(1)}"
        m = re.search(r"(?i)\bdivide(?:d)?(?: by)?\s+(-?\d+(?:\.\d+)?)", q)
        if m:
            return f"{n} / {m.group(1)}"
        m = re.search(r"(?i)(\d+(?:\.\d+)?)\s*(?:%|percent)\s*(?:of)?", q)
        if m:
            return f"{m.group(1)}% of {n}"
        return _NUM_PRON.sub(n, q)

    def summary(self) -> str:
        if not self.entries:
            return "dialog record is empty"
        return "\n".join(f"  turn {e['turn']:>2} {e['kind']:<7} {'verified' if e['verified'] else 'unverified':<10} {e['value'][:60]}" for e in self.entries[-8:])
