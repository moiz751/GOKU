"""
Visual State Observation and Dialog Detection for Windows desktop automation.
Detects active modal dialogs, error message boxes, Save As dialogs, and observes visual screen changes.
Provides real live OS state grounding: active window titles, process trees, filesystem changes,
clipboard state, UI automation elements, and screen buffers.
"""
from __future__ import annotations

import hashlib
import os
from pathlib import Path
import sys
import time
from typing import Any, Dict, List, Optional

if sys.platform == "win32":
    import ctypes
    from ctypes import wintypes
else:
    ctypes = None
    wintypes = None

try:
    import psutil
except ImportError:
    psutil = None



def _capture_current_screen_image(region: tuple[int, int, int, int] | None = None) -> Any:
    """Captures desktop or target window region as a PIL Image safely with PrintWindow and GDI fallbacks."""
    # 1. If region provided on Win32, attempt PrintWindow on the window owning the region
    if region and sys.platform == "win32":
        try:
            import ctypes
            from ctypes import wintypes
            from PIL import Image
            u32 = ctypes.windll.user32
            g32 = ctypes.windll.gdi32
            pt = wintypes.POINT(region[0] + 5, region[1] + 5)
            hwnd = u32.WindowFromPoint(pt)
            while u32.GetParent(hwnd):
                hwnd = u32.GetParent(hwnd)
            if hwnd and u32.IsWindow(hwnd):
                rc = wintypes.RECT()
                u32.GetWindowRect(hwnd, ctypes.byref(rc))
                w = max(1, rc.right - rc.left)
                h = max(1, rc.bottom - rc.top)

                # Compute local crop coordinates relative to the window rect
                local_left = region[0] - rc.left
                local_top = region[1] - rc.top
                local_right = region[2] - rc.left
                local_bottom = region[3] - rc.top

                # Clamp to window boundaries [0, w] x [0, h]
                clamp_left = max(0, min(w, local_left))
                clamp_top = max(0, min(h, local_top))
                clamp_right = max(0, min(w, local_right))
                clamp_bottom = max(0, min(h, local_bottom))

                # If the clamped box is empty (completely outside window), return capture failure
                if clamp_right <= clamp_left or clamp_bottom <= clamp_top:
                    return None

                hdc_win = u32.GetWindowDC(hwnd)
                hdc_mem = g32.CreateCompatibleDC(hdc_win)
                hbmp = g32.CreateCompatibleBitmap(hdc_win, w, h)
                old = g32.SelectObject(hdc_mem, hbmp)
                res = u32.PrintWindow(hwnd, hdc_mem, 2)
                if res:
                    class BIH(ctypes.Structure):
                        _fields_ = [
                            ('biSize', wintypes.DWORD), ('biWidth', wintypes.LONG), ('biHeight', wintypes.LONG),
                            ('biPlanes', wintypes.WORD), ('biBitCount', wintypes.WORD), ('biCompression', wintypes.DWORD),
                            ('biSizeImage', wintypes.DWORD), ('biXPelsPerMeter', wintypes.LONG), ('biYPelsPerMeter', wintypes.LONG),
                            ('biClrUsed', wintypes.DWORD), ('biClrImportant', wintypes.DWORD)
                        ]
                    bih = BIH()
                    bih.biSize = ctypes.sizeof(BIH)
                    bih.biWidth = w
                    bih.biHeight = -h
                    bih.biPlanes = 1
                    bih.biBitCount = 32
                    buf = ctypes.create_string_buffer(w * h * 4)
                    g32.GetDIBits(hdc_mem, hbmp, 0, h, buf, ctypes.byref(bih), 0)
                    img = Image.frombuffer('RGBA', (w, h), buf, 'raw', 'BGRA', 0, 1)
                    g32.SelectObject(hdc_mem, old)
                    g32.DeleteObject(hbmp)
                    g32.DeleteDC(hdc_mem)
                    u32.ReleaseDC(hwnd, hdc_win)

                    # Crop to the clamped local region
                    cropped_img = img.crop((clamp_left, clamp_top, clamp_right, clamp_bottom))
                    if any(mx > 0 for mn, mx in cropped_img.getextrema()):
                        return cropped_img
                else:
                    g32.SelectObject(hdc_mem, old)
                    g32.DeleteObject(hbmp)
                    g32.DeleteDC(hdc_mem)
                    u32.ReleaseDC(hwnd, hdc_win)
        except Exception:
            pass

    # 2. Try ImageGrab
    try:
        from PIL import ImageGrab
        img = ImageGrab.grab(bbox=region)
        if img:
            return img
    except Exception:
        pass

    # 3. Try pyautogui
    try:
        import pyautogui
        return pyautogui.screenshot(region=region)
    except Exception:
        pass

    # 4. GDI fallback
    if sys.platform == "win32":
        try:
            import tempfile
            from tools.screen import _capture_screen_gdi
            with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as tf:
                tmp_p = Path(tf.name)
            ok, _, _ = _capture_screen_gdi(tmp_p)
            if ok and tmp_p.exists():
                from PIL import Image
                img = Image.open(str(tmp_p))
                img.load()
                try:
                    tmp_p.unlink()
                except Exception:
                    pass
                if region:
                    img = img.crop(region)
                return img
        except Exception:
            pass
    return None


def get_active_window_state() -> Dict[str, Any]:
    """Retrieves live foreground active window title, HWND, class, and process details."""
    state = {
        "hwnd": 0,
        "title": "",
        "class_name": "",
        "pid": 0,
        "process_name": "",
        "is_foreground": False,
        "bounds": {},
    }
    if sys.platform != "win32" or not ctypes:
        return state

    try:
        u32 = ctypes.windll.user32
        hwnd = u32.GetForegroundWindow()
        if hwnd and u32.IsWindow(hwnd):
            state["hwnd"] = int(hwnd)
            state["is_foreground"] = True

            tlen = u32.GetWindowTextLengthW(hwnd)
            if tlen > 0:
                tbuff = ctypes.create_unicode_buffer(tlen + 1)
                u32.GetWindowTextW(hwnd, tbuff, tlen + 1)
                state["title"] = tbuff.value

            cbuff = ctypes.create_unicode_buffer(256)
            u32.GetClassNameW(hwnd, cbuff, 256)
            state["class_name"] = cbuff.value

            pid_val = wintypes.DWORD()
            u32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid_val))
            state["pid"] = int(pid_val.value)

            if psutil and state["pid"]:
                try:
                    p = psutil.Process(state["pid"])
                    state["process_name"] = p.name()
                except Exception:
                    pass

            rc = wintypes.RECT()
            if u32.GetWindowRect(hwnd, ctypes.byref(rc)):
                state["bounds"] = {
                    "left": rc.left, "top": rc.top,
                    "right": rc.right, "bottom": rc.bottom,
                    "width": rc.right - rc.left, "height": rc.bottom - rc.top
                }
    except Exception:
        pass
    return state


def get_process_tree(target_pid: Optional[int] = None) -> List[Dict[str, Any]]:
    """Captures real process tree hierarchy from the OS using psutil."""
    if not psutil:
        return []

    processes = []
    try:
        if target_pid:
            try:
                root_proc = psutil.Process(target_pid)
                family = [root_proc] + root_proc.children(recursive=True)
                for p in family:
                    try:
                        processes.append({
                            "pid": p.pid,
                            "ppid": p.ppid(),
                            "name": p.name(),
                            "status": p.status(),
                            "cpu_percent": p.cpu_percent(interval=0.0),
                            "memory_mb": round(p.memory_info().rss / (1024 * 1024), 2),
                        })
                    except (psutil.NoSuchProcess, psutil.AccessDenied):
                        continue
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                return []
        else:
            for p in psutil.process_iter(["pid", "ppid", "name", "status"]):
                try:
                    processes.append({
                        "pid": p.info["pid"],
                        "ppid": p.info["ppid"],
                        "name": p.info["name"],
                        "status": p.info["status"],
                    })
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
    except Exception:
        pass
    return processes


def get_filesystem_state(directory: str | Path | None = None) -> Dict[str, Any]:
    """Captures live filesystem snapshot of a directory (files, sizes, modification times)."""
    target_dir = Path(directory or "scratch").resolve()
    if not target_dir.exists():
        return {"exists": False, "path": str(target_dir), "files": {}}

    snapshot: Dict[str, Any] = {"exists": True, "path": str(target_dir), "files": {}}
    try:
        for entry in target_dir.rglob("*"):
            if entry.is_file():
                try:
                    st = entry.stat()
                    rel = str(entry.relative_to(target_dir)).replace("\\", "/")
                    snapshot["files"][rel] = {
                        "size": st.st_size,
                        "mtime": st.st_mtime,
                    }
                except Exception:
                    continue
    except Exception:
        pass
    return snapshot


def get_clipboard_state() -> Dict[str, Any]:
    """Captures real OS clipboard text state and hash without side effects."""
    clip_state = {"has_text": False, "length": 0, "sha256": "", "preview": ""}
    if sys.platform != "win32" or not ctypes:
        return clip_state

    try:
        u32 = ctypes.windll.user32
        k32 = ctypes.windll.kernel32
        CF_UNICODETEXT = 13
        if u32.OpenClipboard(0):
            try:
                h_clip = u32.GetClipboardData(CF_UNICODETEXT)
                if h_clip:
                    k32.GlobalLock.restype = ctypes.c_wchar_p
                    ptr = k32.GlobalLock(h_clip)
                    if ptr:
                        text = str(ptr)
                        k32.GlobalUnlock(h_clip)
                        clip_state["has_text"] = True
                        clip_state["length"] = len(text)
                        clip_state["preview"] = text[:60]
                        clip_state["sha256"] = hashlib.sha256(text.encode("utf-8", errors="replace")).hexdigest()
            finally:
                u32.CloseClipboard()
    except Exception:
        pass
    return clip_state


def capture_live_os_state(target_dir: str | Path | None = None) -> Dict[str, Any]:
    """
    Comprehensive live OS state observer.
    Captures active window title, process tree, filesystem snapshot, clipboard, and screen hash.
    """
    win = get_active_window_state()
    fs = get_filesystem_state(target_dir)
    clip = get_clipboard_state()
    dialog = get_active_dialog_info()

    screen_hash = ""
    screen_size = (0, 0)
    img = _capture_current_screen_image()
    if img:
        try:
            screen_size = img.size
            # Downsample for fast hash
            small = img.resize((32, 32)).convert("L")
            screen_hash = hashlib.sha256(small.tobytes()).hexdigest()
        except Exception:
            pass

    return {
        "timestamp": time.time(),
        "active_window": win,
        "dialog": dialog,
        "filesystem": fs,
        "clipboard": clip,
        "screen": {
            "size": screen_size,
            "hash": screen_hash,
            "available": img is not None,
        },
    }


def get_active_dialog_info(owner_pid: int | None = None) -> dict[str, Any]:
    """
    Detects if an active modal or dialog window (#32770 or UIA dialog/modal) is present.
    Scans all visible top-level dialogs; excludes standard apps with keywords in title.
    """
    from executor.truth_oracle import check_dialog
    obs = check_dialog(owner_pid=owner_pid)
    if obs.status == "VERIFIED":
        best = obs.evidence.get("best_dialog", {})
        buttons = best.get("buttons", [])
        btn_summary = f" Buttons: {', '.join(buttons)}" if buttons else ""
        return {
            "success": True,
            "has_dialog": True,
            "is_dialog": True,
            "title": best.get("title", ""),
            "dialog_title": best.get("title", ""),
            "dialog_class": best.get("class_name", "#32770"),
            "bounds": best.get("bounds", {}),
            "buttons": buttons,
            "pid": best.get("pid"),
            "hwnd": best.get("hwnd"),
            "all_dialogs": obs.evidence.get("dialogs", []),
            "message": f"Active dialog detected: '{best.get('title')}'.{btn_summary}",
        }
    return {
        "success": True,
        "has_dialog": False,
        "is_dialog": False,
        "title": "",
        "dialog_title": "",
        "buttons": [],
        "message": obs.reason or "No active dialog detected.",
    }


def wait_for_screen_change(
    before_screenshot_path: str | None = None,
    timeout_seconds: float = 3.0,
    region: tuple[int, int, int, int] | None = None,
) -> dict[str, Any]:
    """
    Waits and verifies if the visual screen state changes within a timeout period.
    Compares real before and after pixel states and returns changed=False on timeout.
    Supports optional target region (e.g. bounding box of an owned static window).
    """
    from executor.truth_oracle import check_screen_changed

    start_time = time.time()
    before_img = None
    if before_screenshot_path and os.path.exists(before_screenshot_path):
        try:
            from PIL import Image
            before_img = Image.open(before_screenshot_path)
            before_img.load()
            if region and before_img.size != (region[2] - region[0], region[3] - region[1]):
                before_img = before_img.crop(region)
        except Exception:
            before_img = None

    if before_img is None:
        before_img = _capture_current_screen_image(region=region)

    poll_interval = 0.2
    while time.time() - start_time < timeout_seconds:
        time.sleep(poll_interval)
        after_img = _capture_current_screen_image(region=region)
        if before_img is None or after_img is None:
            return {
                "success": False,
                "status": "unverified",
                "changed": False,
                "elapsed_seconds": round(time.time() - start_time, 2),
                "message": "Screen capture unavailable for visual state verification.",
            }

        obs = check_screen_changed(before_img, after_img, region=None)
        if obs.is_verified:
            return {
                "success": True,
                "status": "completed",
                "changed": True,
                "elapsed_seconds": round(time.time() - start_time, 2),
                "diff_percent": obs.evidence.get("change_percent", 0.0),
                "message": obs.reason or "Visual screen state change verified.",
            }

    # Bounded timeout reached without change
    return {
        "success": True,
        "status": "completed",
        "changed": False,
        "elapsed_seconds": round(time.time() - start_time, 2),
        "diff_percent": 0.0,
        "message": f"No visual screen change detected within {timeout_seconds:.1f}s.",
    }
