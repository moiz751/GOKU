"""
Task router (P2). Decides whether a request is a calculation, an explicit deep-thinking request, a system
action or something else, and answers the first two itself. Everything else returns None so the existing
command_layer.router.handle_command keeps full ownership (no existing behaviour is replaced).

    route(text)        -> {"route": "calc"|"deep"|"action"|"other", "confidence": float, "reason": str}
    try_handle(text)   -> reply string, or None meaning "not mine, use handle_command"
"""
from __future__ import annotations

import re
from typing import Any, Callable, Dict, List, Optional

from brain import calc_engine, reasoning_engine

_ACTION_START = re.compile(
    r"^\s*(open|launch|start|run|close|kill|stop|kholo|khol|band|delete|remove|create|make|rename|copy|move|play|pause|search|find|type|write|click|press|scroll|"
    r"take|capture|screenshot|read|summari[sz]e|show|list|set|turn|volume|mute|download|install|send|save|focus|switch|minimi[sz]e|maximi[sz]e|lock|shutdown|restart)\b", re.I)


_FILE_VERB = re.compile(r"^\s*(?:please\s+)?(deep\s+analy[sz]e|analy[sz]e|audit|review|inspect|compare|code\s+review)\b", re.I)
_PATH = re.compile(r"""(?:"([^"]+)"|'([^']+)'|((?:[A-Za-z]:)?[\\/]?[\w\-. \\/~]+\.[A-Za-z0-9]{1,5}))""")


def _existing_paths(text: str) -> List[str]:
    import os

    found: List[str] = []
    for m in _PATH.finditer(text):
        cand = next((g for g in m.groups() if g), "").strip()
        for c in (cand, cand.split()[-1] if " " in cand else cand):
            c = os.path.expanduser(c)
            if c and os.path.isfile(c) and c not in found:
                found.append(c)
                break
    for tok in text.split():                     # unquoted paths without spaces, in the order they were written
        c = os.path.expanduser(tok.strip("\"',;"))
        if c and os.path.isfile(c) and c not in found:
            found.append(c)
    order = {p: text.find(p) for p in found}
    found.sort(key=lambda p: order[p] if order[p] >= 0 else 10 ** 9)
    return found


_EXTRA = re.compile(r"^\s*(verify\s+quote|column\s+stats|code\s+graph|corpus|retrieve\s+context)\b", re.I)


def _handle_extras(text: str) -> str:
    from brain import doc_extras

    t = text.strip()
    try:
        if re.match(r"(?i)verify\s+quote", t):
            m = re.match(r"(?is)verify\s+quote\s+[\"'](.+?)[\"']\s+(?:in|inside|mein)\s+(.+)$", t)
            if not m:
                return 'Use: verify quote "text to check" in <file>'
            r = doc_extras.verify_quote(m.group(2).strip().strip("\"'"), m.group(1))
            if r["found"]:
                return f"Quote {'found exactly' if r['exact'] else 'found (close match, similarity %.0f%%)' % (r['similarity'] * 100)} at {r['loc']}: {r['text'][:120]}"
            return f"Quote NOT found. {r.get('note', '')}" + (f" Closest ({r['similarity']:.0%}) at {r['loc']}: {r['text'][:120]}" if r.get("loc") else "")
        paths = _existing_paths(t)
        if re.match(r"(?i)column\s+stats", t):
            if not paths:
                return "Use: column stats <file.csv|file.xlsx>"
            r = doc_extras.column_stats(paths[0])
            lines = [f"{r['rows']} rows, {len(r['columns'])} columns, {r['duplicate_rows']} duplicate rows"]
            for c in r["columns"][:20]:
                lines.append(f"  {c['name']}: " + (f"number, min {c['min']}, max {c['max']}, mean {c['mean']}, nulls {c['nulls']}" if c["type"] == "number" else f"text, {c['distinct']} distinct, nulls {c['nulls']}"))
            lines += [f"  related: {x['a']} ~ {x['b']} (r={x['correlation']}) - correlation is not causation" for x in r["related"][:5]]
            return "\n".join(lines)
        if re.match(r"(?i)code\s+graph", t):
            import os
            arg = re.sub(r"(?i)^\s*code\s+graph\s*", "", t).strip().strip("\"'")
            arg = os.path.expanduser(arg)
            if not (arg and os.path.exists(arg)):
                return "Use: code graph <folder or .py file>"
            g = doc_extras.code_graph(arg)
            lines = [f"{g['modules']} modules, {g['edges']} imports between them"]
            lines += ["circular import: " + " -> ".join(c) for c in g["circular_imports"][:5]] or []
            lines += [f"unreferenced: {d['module']}.{d['function']} (line {d['line']})" for d in g["unreferenced_functions"][:10]]
            lines.append(g["note"])
            return "\n".join(lines)
        if re.match(r"(?i)corpus", t):
            if len(paths) < 2:
                return "Use: corpus <file1> <file2> [more files]"
            r = doc_extras.analyze_corpus(paths)
            lines = [f"{r['files']} files; shared keywords: {', '.join(r['shared_keywords']) or 'none'}"]
            lines += [f"duplicated passage in {', '.join(d['files'])}" for d in r["duplicated_passages"][:5]]
            lines += [f"number conflict '{c['label']}': {c['values']}" for c in r["cross_file_number_conflicts"][:5]]
            return "\n".join(lines)
        if re.match(r"(?i)retrieve\s+context", t):
            m = re.match(r"(?is)retrieve\s+context\s+(\S+)\s+(.+)$", t)
            if not m:
                return "Use: retrieve context <file> <location>"
            ctx = doc_extras.retrieve_context(m.group(1), m.group(2).strip())
            return "\n".join(f"[{c['loc']}] {c['text']}" for c in ctx) or "No such location in that file."
    except Exception as exc:
        return f"[analysis] could not finish: {type(exc).__name__}: {exc}"
    return "Not understood."


def _is_planner_command(t: str) -> bool:
    if re.match(r"^\s*(system\s+scan|scan\s+system|capabilit(y|ies)|pending(\s+(list|check|report|cancel)\b.*)?)\s*$", t, re.I):
        return True
    m = re.match(r"^\s*plan\s+(\S+)(\s+[\d.]+\s*(mb|gb)?)?\s*$", t, re.I)
    if m:
        from brain.capability_catalog import resolve_kind
        return bool(resolve_kind(m.group(1)))
    return False


def route(text: str) -> Dict[str, Any]:
    t = (text or "").strip()
    if not t:
        return {"route": "other", "confidence": 0.0, "reason": "empty"}
    if _EXTRA.match(t):
        return {"route": "extras", "confidence": 0.9, "reason": "document/code analysis command"}
    if re.match(r"^\s*(remember|yaad rakho|yaad rakhna)\b\s*(that|ke)?\s+\S+", t, re.I):
        return {"route": "remember", "confidence": 0.95, "reason": "store a user fact"}
    if re.match(r"^\s*(ask|answer|sawal|puchho)\s*[:,]?\s+\S+", t, re.I):
        return {"route": "answer_full", "confidence": 0.95, "reason": "explicit question for the answer engine"}
    if re.match(r"^\s*tasks?(\s+(list|status|pause|resume|cancel|confirm|report|run)\b.*)?\s*$", t, re.I):
        return {"route": "task_manager", "confidence": 0.95, "reason": "task manager command"}
    if _is_planner_command(t):
        return {"route": "capability_planner", "confidence": 0.95, "reason": "system scan / capability / pending-work command"}
    if re.match(r"^\s*(memory|knowledge)\s+\w+", t, re.I):
        return {"route": "memory", "confidence": 0.95, "reason": "memory/knowledge data command"}
    if _FILE_VERB.match(t) and _existing_paths(t):
        return {"route": "file", "confidence": 0.9, "reason": "analyse/review/compare an existing file"}
    if reasoning_engine.wants_deep(t) and not _ACTION_START.match(t):
        return {"route": "deep", "confidence": 0.9, "reason": "explicit deep-thinking request"}
    score = calc_engine.looks_like_math(t)
    if score >= 0.5 and not _ACTION_START.match(t):
        return {"route": "calc", "confidence": score, "reason": "looks like a calculation"}
    if _ACTION_START.match(t):
        return {"route": "action", "confidence": 0.7, "reason": "starts with an action verb"}
    if reasoning_engine.classify_complexity(t) == "complex" and "?" in t:
        return {"route": "deep", "confidence": 0.6, "reason": "long multi-part question"}
    return {"route": "other", "confidence": 0.3, "reason": "no specialised route"}


def _model_ask() -> Optional[Callable[[str], Optional[str]]]:
    """The model is used only when the existing readiness gate allows it; otherwise reasoning stays deterministic."""
    try:
        from config.settings import is_model_call_allowed

        allowed = is_model_call_allowed()
        if isinstance(allowed, tuple):
            allowed = allowed[0]
        if not allowed:
            return None
        from brain.llm import ask_conversational_llm

        return lambda prompt: ask_conversational_llm(prompt)
    except Exception:
        return None


_QUESTION = re.compile(r"(?is)^\s*(what|who|whom|where|when|why|how|which|is|are|does|do|can|kya|kitna|kitni|kitne|kaun|kahan|kab|konsa|kaise|passage\s*:)\b|\?\s*$")
_COMMANDISH = re.compile(r"(?is)^\s*(open|close|launch|start|run|delete|remove|kill|install|uninstall|restart|shutdown|click|type|press|kholo|band|chalao)\b")
_IMPLICIT_SOLVERS = {"passage", "dates", "clock", "math", "compare", "units", "stats", "geometry", "finance", "percent", "memory", "knowledge"}


def _remember(text: str) -> str:
    fact = re.sub(r"(?is)^\s*(remember|yaad rakho|yaad rakhna)\b\s*(that|ke)?\s+", "", text).strip()
    try:
        from brain import learning_hooks
        rec = learning_hooks.get_store().add("long_term", fact, source="user", trust=1.0)
        return f"Yaad rakh liya: {fact}" if rec else "Yeh yaad nahi rakh saka (shayad secret jaisa text tha)."
    except Exception as exc:
        return f"[memory] could not store it: {type(exc).__name__}"


def _answer(question: str, full: bool, question_form: bool = True) -> Optional[str]:
    try:
        from brain import answer_engine
        mem = None
        try:
            from brain import learning_hooks
            mem = learning_hooks.get_store()
        except Exception:
            pass
        r = answer_engine.answer(question, memory=mem)
    except Exception:
        return None
    if full:
        tag = {"answered": "", "needs_web": "[needs internet] ", "unknown": "[no verified answer] ", "clarify": "[need detail] ", "refused": "[refused] ", "confirm": "[needs confirmation] "}.get(r["status"], "")
        ev = ("\n  evidence: " + "; ".join(r["evidence"][:2])) if r["evidence"] else ""
        return f"{tag}{r['text']}{ev}"
    if r["status"] == "answered" and r["solver"] in _IMPLICIT_SOLVERS and (question_form or r["solver"] != "memory"):
        ev = ("\n  " + r["evidence"][0]) if r["evidence"] else ""
        return f"{r['text']}{ev}"
    return None


def try_handle(text: str, ask: Optional[Callable[[str], Optional[str]]] = None) -> Optional[str]:
    info = route(text)
    if info["route"] == "calc":
        guard = _answer(text, full=False)             # the answer engine refuses half-understood maths ("7 squared plus 3") and never treats dates as arithmetic
        if guard:
            return guard
        try:
            from brain import answer_engine
            g = answer_engine.answer(text)
            if g["status"] == "clarify" and g["solver"] in ("math", "dates"):
                return g["text"]
        except Exception:
            pass
        cmp = reasoning_engine.compare_values(text)
        if cmp:
            return f"{cmp['answer']} ({cmp['a']} vs {cmp['b']})\n  both sides computed exactly with fractions"
        res = calc_engine.calculate_from_text(text)
        if res is None:
            return None
        if not res["ok"]:
            return f"[calc] {res['error']}"
        extra = "" if res["verified"] else " (not verified)"
        steps = res.get("steps") or []
        how = f"\n  {res['verification']}" if res.get("verification") else ""
        head = f"{res['display']}{extra}"
        if res["kind"] in ("equation",) and steps:
            head += "\n  " + "\n  ".join(steps[:3])
        return head + how
    if info["route"] == "extras":
        return _handle_extras(text)
    if info["route"] == "remember":
        return _remember(text)
    if info["route"] == "answer_full":
        return _answer(re.sub(r"(?i)^\s*(ask|answer|sawal|puchho)\s*[:,]?\s+", "", text), full=True)
    if info["route"] == "task_manager":
        from brain import task_manager
        return task_manager.handle_task_command(text)["message"]
    if info["route"] == "capability_planner":
        from brain import capability_planner
        return capability_planner.handle_command(text)
    if info["route"] == "memory":
        from brain import learning_hooks
        return learning_hooks.handle_memory_command(text)
    if info["route"] == "file":
        try:
            from brain import doc_insight

            paths = _existing_paths(text)
            if re.match(r"^\s*compare\b", text, re.I) and len(paths) >= 2:
                r = doc_insight.compare_files(paths[0], paths[1])
                lines = [f"Similarity {r['similarity']:.0%}; added {r['counts']['added']}, removed {r['counts']['removed']}, changed {r['counts']['changed']}" + ("  (identical)" if r["identical"] else "")]
                lines += [f"+ {a['text']}  [{a['loc']}]" for a in r["added"][:5]] + [f"- {a['text']}  [{a['loc']}]" for a in r["removed"][:5]] + [f"~ {c['a']} -> {c['b']}  [{c['a_loc']} / {c['b_loc']}]" for c in r["changed"][:5]]
                return "\n".join(lines)
            return doc_insight.render_report(doc_insight.analyze_file(paths[0]))
        except Exception as exc:
            return f"[file analysis] could not finish: {type(exc).__name__}: {exc}"
    if info["route"] == "deep":
        rep = reasoning_engine.reason(text, ask=ask if ask is not None else _model_ask())
        return rep.render()
    if not _COMMANDISH.match(text):
        return _answer(text, full=False, question_form=bool(_QUESTION.search(text)))   # only verified solver answers; everything else falls through unchanged
    return None
