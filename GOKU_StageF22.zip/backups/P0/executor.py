"""
Executor — executes tool calls with pre-execution security, strict verification,
and bounded retries for recoverable errors.
"""
import inspect
import json
import os
from pathlib import Path
import time
from typing import Any

from config.settings import MAX_RETRIES, RETRY_DELAY_SECONDS
from executor.verifier import verify
from security.confirm import is_allowed
from tools.registry import get_tool
from brain.runtime_bus import RuntimePipingBus


def _validate_and_sanitize_args(func: Any, raw_args: dict[str, Any]) -> tuple[dict[str, Any], str | None]:
    """
    Validates and sanitizes tool arguments against the callable's signature.
    Drops extraneous LLM metadata keys (e.g. 'required', 'properties', 'description', 'type').
    Returns (sanitized_args, error_message).
    """
    if not isinstance(raw_args, dict):
        return {}, "Arguments must be provided as a dictionary."

    try:
        sig = inspect.signature(func)
    except (ValueError, TypeError):
        return raw_args, None

    valid_params = sig.parameters
    has_var_keyword = any(p.kind == inspect.Parameter.VAR_KEYWORD for p in valid_params.values())

    sanitized: dict[str, Any] = {}
    for k, v in raw_args.items():
        if has_var_keyword or k in valid_params:
            if isinstance(v, str):
                v = v.strip()
            sanitized[k] = v

    # Check for missing required parameters
    missing_required = []
    for param_name, param in valid_params.items():
        if param.kind in (inspect.Parameter.POSITIONAL_OR_KEYWORD, inspect.Parameter.KEYWORD_ONLY):
            if param.default is inspect.Parameter.empty and param_name not in sanitized:
                missing_required.append(param_name)

    if missing_required:
        return sanitized, f"Missing required argument(s): {', '.join(missing_required)}"

    return sanitized, None


_MODE_GATE_CONFIG: dict[str, str] | None = None


def _load_mode_gate() -> dict[str, str]:
    global _MODE_GATE_CONFIG
    if _MODE_GATE_CONFIG is None:
        p = Path(__file__).resolve().parent.parent / "config" / "mode_gate.json"
        if p.exists():
            try:
                with open(p, "r", encoding="utf-8") as f:
                    _MODE_GATE_CONFIG = json.load(f)
            except Exception:
                _MODE_GATE_CONFIG = {}
        else:
            _MODE_GATE_CONFIG = {}
    return _MODE_GATE_CONFIG


def is_recoverable_error(tool_name: str, args: dict, result: dict, exception: Exception | None = None) -> bool:
    """
    Classifies whether an execution or verification failure is recoverable and should be retried.
    """
    if exception is not None:
        if isinstance(exception, (FileNotFoundError, PermissionError, TypeError, ValueError, KeyError)):
            return False
        if isinstance(exception, (TimeoutError, BlockingIOError, ConnectionError, OSError)):
            return True
        return False

    if not result:
        return True

    msg = result.get("message", "").lower()
    if "not found" in msg or "does not exist" in msg or "unknown tool" in msg or "permission denied" in msg:
        return False

    if result.get("needs_confirmation"):
        return False

    # For launch_app: if process creation failed due to transient state, recoverable
    if tool_name == "launch_app" and not result.get("success"):
        return True

    # For find_file returning 0 matches: deterministic, not recoverable by simple re-run
    if tool_name == "find_file" and not result.get("success"):
        return False

    return False


def run_tool_call(tool_name: str, args: dict, confirmed: bool = False, max_retries: int = MAX_RETRIES) -> dict:
    """
    Executes a tool call with security enforcement, bounded retry, and strict verification.

    Returns structured dictionary:
    {
        "success": bool,
        "verified": bool,
        "status": "completed" | "unverified" | "failed" | "pending_confirmation" | "already_existed" | "created",
        "message": str,
        "attempts": int,
        ...
    }
    """
    func = get_tool(tool_name)
    if func is None:
        return {
            "success": False,
            "verified": False,
            "status": "failed",
            "message": f"Unknown tool: {tool_name}",
            "attempts": 1,
        }

    # Step 0.5: Mode Gate Admission Check (Prompt T1.10p)
    from config.settings import get_goku_mode
    if get_goku_mode() == "dev":
        mode_gate = _load_mode_gate()
        tool_class = mode_gate.get(tool_name)
        if tool_class in ("screen", "gui"):
            return {
                "success": False,
                "verified": False,
                "status": "blocked_by_mode",
                "message": f"GOKU_MODE is 'dev': tool '{tool_name}' classified as '{tool_class}' is blocked.",
                "attempts": 0,
            }

    # Step 0: Resolve deferred runtime parameters and sanitize tool arguments
    args = args or {}
    args = RuntimePipingBus.resolve_step_parameters(args)
    sanitized_args, validation_err = _validate_and_sanitize_args(func, args)
    if validation_err:
        return {
            "success": False,
            "verified": False,
            "status": "failed",
            "message": f"Invalid arguments for '{tool_name}': {validation_err}",
            "attempts": 1,
        }

    # Step 0.8: Budget Governor Admission & Concurrency Gate
    from config.settings import get_governor_mode
    gov_mode = get_governor_mode()
    cost_info = None
    if gov_mode != "off":
        from tools.budget_governor import decide, heavy_slot
        decision = decide(tool_name)
        action = decision.get("action", "allow")
        cost_info = decision

        if gov_mode == "enforce":
            if action == "refuse":
                return {
                    "success": False,
                    "verified": False,
                    "status": "refused",
                    "message": decision.get("reason", f"Execution refused by budget governor for '{tool_name}'."),
                    "attempts": 0,
                    "governor_decision": decision,
                }
            elif action == "downgrade" and decision.get("fallback_tool"):
                fb_tool = decision["fallback_tool"]
                # Map args through the fallback tool's schema (keep only accepted parameters)
                from tools.registry import get_tool_schema
                fb_schema = get_tool_schema(fb_tool)
                mapped_args = dict(args)
                if fb_schema and isinstance(fb_schema, dict):
                    params = fb_schema.get("function", {}).get("parameters", {})
                    props = params.get("properties", {})
                    required = params.get("required", [])
                    if props:
                        mapped_args = {k: v for k, v in args.items() if k in props}
                    missing = [r for r in required if r not in mapped_args]
                    if missing:
                        return {
                            "success": False,
                            "verified": False,
                            "status": "refused",
                            "message": f"Downgrade from '{tool_name}' to fallback '{fb_tool}' failed: missing required parameter(s): {', '.join(missing)}.",
                            "attempts": 0,
                            "governor_decision": decision,
                        }
                res = run_tool_call(fb_tool, mapped_args, confirmed=confirmed, max_retries=max_retries)
                if isinstance(res, dict):
                    res["downgraded_from"] = tool_name
                return res
            elif action == "queue":
                try:
                    with heavy_slot(timeout=5.0, tool_name=tool_name):
                        pass
                except TimeoutError as te:
                    return {
                        "success": False,
                        "verified": False,
                        "status": "refused",
                        "message": str(te),
                        "attempts": 0,
                        "governor_decision": decision,
                    }

    # Step 1: Centralized pre-execution security check
    
    # Step 1.1: Hardware-level Active Foreground Immunity Enforcer
    try:
        from command_layer.context import session_context
        import win32gui
        import win32process
        fg_hwnd = win32gui.GetForegroundWindow() if win32gui else None
        if fg_hwnd:
            _, fg_pid = win32process.GetWindowThreadProcessId(fg_hwnd)
            immune_pids = getattr(session_context, 'immune_pids', set()) or set()
            immune_hwnds = getattr(session_context, 'immune_hwnds', set()) or set()
            destructive_actions = ('delete_file', 'delete_folder', 'kill_process', 'terminate_process', 'format_disk')
            if (fg_pid in immune_pids or fg_hwnd in immune_hwnds) and tool_name in destructive_actions:
                return {
                    'success': False,
                    'verified': False,
                    'status': 'REJECTED',
                    'message': f'IMMUNE_PROCESS_BLOCKED: Active foreground PID {fg_pid} belongs to user immune session. Destructive tool {tool_name} dropped.',
                    'attempts': 1,
                }
    except Exception:
        pass

    allowed, warning = is_allowed(tool_name, sanitized_args)
    if not allowed and not confirmed:
        return {
            "success": False,
            "verified": False,
            "needs_confirmation": True,
            "status": "pending_confirmation",
            "message": warning or f"Confirmation required for '{tool_name}'.",
            "attempts": 0,
        }

    # Step 1.2: Window & Tab Immunity Guard
    try:
        from command_layer.context import session_context
        if not getattr(session_context, "immune_hwnds", None):
            from tools.window import record_running_chrome_immunity
            record_running_chrome_immunity(session_context)
    except Exception:
        pass

    
    if tool_name in ("close_app", "manage_window"):
        try:
            from command_layer.context import session_context
            immune_hwnds = getattr(session_context, "immune_hwnds", set()) or set()
            immune_pids = getattr(session_context, "immune_pids", set()) or set()
            target_name = sanitized_args.get("app_name") or sanitized_args.get("name") or sanitized_args.get("name_or_pid") or ""
            str(sanitized_args.get("action", "")).lower().strip()

            from tools.window import _get_target_hwnd
            from tools.processes import _find_running_pids
            t_hwnd = sanitized_args.get("hwnd") or _get_target_hwnd(target_name)
            t_pids = set(_find_running_pids(target_name))
            if (t_hwnd and t_hwnd in immune_hwnds) or any((p in immune_hwnds or p in immune_pids) for p in t_pids):
                return {
                    "success": False,
                    "verified": False,
                    "status": "REJECTED",
                    "message": f"Action rejected: Target window/PID for '{target_name}' is protected under immune_hwnds.",
                    "attempts": 1,
                }
        except Exception:
            pass

    last_result: dict[str, Any] = {}
    last_exception: Exception | None = None

    # Step 1.5: Pre-execution State Capture
    pre_hwnd = None
    try:
        from tools.window import get_window_info
        win_info = get_window_info()
        if win_info.get("success"):
            pre_hwnd = win_info.get("hwnd")
            win_info.get("title", "")
    except Exception:
        pass

    ui_interact_tools = (
        "find_and_interact",
        "click_ui_element",
        "locate_ui_element",
        "click_element_by_text",
        "pick_best_on_screen_item",
    )

    # Step 2: Bounded execution and retry loop (max 3 attempts)
    for attempt in range(1, max_retries + 1):
        try:
            from tools.low_power import low_power_scope
            with low_power_scope():
                if gov_mode == "enforce" and cost_info and cost_info.get("cpu_class") == "heavy":
                    with heavy_slot(timeout=5.0, tool_name=tool_name):
                        raw_result = func(**sanitized_args)
                else:
                    raw_result = func(**sanitized_args)
            last_result = raw_result.copy() if isinstance(raw_result, dict) else {"success": True, "result": raw_result}
            last_exception = None
        except TimeoutError as te:
            if gov_mode == "enforce":
                return {
                    "success": False,
                    "verified": False,
                    "status": "refused",
                    "message": str(te),
                    "attempts": attempt,
                    "governor_decision": cost_info,
                }
            last_exception = te
            last_result = {
                "success": False,
                "message": f"Tool '{tool_name}' raised an error: {te}",
            }
        except Exception as e:
            last_exception = e
            last_result = {
                "success": False,
                "message": f"Tool '{tool_name}' raised an error: {e}",
            }

        # Step 3: Oracle Verification & Settle
        unverified_reason = ""
        if last_result.get("success"):
            app_target = sanitized_args.get("app_name") or sanitized_args.get("name") or sanitized_args.get("app") or ""
            file_target = sanitized_args.get("path") or sanitized_args.get("filepath") or sanitized_args.get("target") or ""

            # Application launch / focus
            if tool_name in ("launch_app", "focus_app_window", "open_application") and app_target:
                from executor.truth_oracle import check_window, check_foreground
                w_obs = check_window(title_contains=str(app_target), timeout=1.5)
                if w_obs.status == "VERIFIED":
                    best = w_obs.evidence.get("best_match", {})
                    hwnd = best.get("hwnd")
                    if hwnd:
                        try:
                            from tools.gui_controller import force_foreground_focus
                            force_foreground_focus(hwnd)
                        except Exception:
                            pass
                    fg_obs = check_foreground(hwnd, timeout=0.8) if hwnd else None
                    if fg_obs and fg_obs.status == "VERIFIED":
                        is_verified = True
                    else:
                        is_verified = False
                        unverified_reason = f"could not confirm that {app_target} is in the foreground"
                else:
                    is_verified = False
                    unverified_reason = f"could not find window for {app_target}"
            # File creation / save
            elif tool_name in ("create_file", "save_active_document", "replace_file") and file_target:
                from executor.truth_oracle import check_file
                f_obs = check_file(file_target, allow_empty=bool(last_result.get("allow_empty", False)))
                if f_obs.status == "VERIFIED":
                    is_verified = True
                elif f_obs.status == "FAILED":
                    is_verified = False
                    unverified_reason = f_obs.reason
                else:
                    is_verified = False
                    unverified_reason = f_obs.reason
            # Screen / click actions
            elif tool_name in ("click_mouse", "mouse_click", "click_ui_element", "click_element_by_text"):
                is_verified = verify(tool_name, args, last_result)
                if is_verified:
                    pass
                else:
                    unverified_reason = "could not verify visual screen change or target UI state after click"
            else:
                is_verified = verify(tool_name, args, last_result)
                if is_verified:
                    pass
                else:
                    unverified_reason = f"could not independently verify target state for '{tool_name}'"
        else:
            is_verified = False

        last_result["verified"] = is_verified
        last_result["attempts"] = attempt

        if last_result.get("success"):
            # Post-execution UI settle check
            if tool_name in ui_interact_tools:
                try:
                    from tools.window import wait_for_ui_settle
                    wait_for_ui_settle(timeout_ms=250)
                except Exception:
                    pass

            if is_verified:
                last_result["status"] = "completed"
            else:
                last_result["status"] = "unverified"
                # When status is UNVERIFIED, user-facing message explains what could not be verified while preserving original tool output
                orig_msg = last_result.get("message", "")
                if unverified_reason:
                    if orig_msg and orig_msg.strip():
                        last_result["message"] = f"{orig_msg} (Unverified: {unverified_reason})"
                    else:
                        last_result["message"] = f"Done, but I {unverified_reason}."
                elif orig_msg and orig_msg.strip():
                    last_result["message"] = f"Done, but I could not confirm: {orig_msg}"
                else:
                    last_result["message"] = f"Done, but I could not confirm the outcome of '{tool_name}'."
            return last_result

        # Self-Healing Branch on UI lookup/click failures
        if tool_name in ui_interact_tools and attempt < max_retries:
            try:
                if attempt == 1:
                    # Attempt 1: Scroll viewport 2 clicks down to bring element into visible hierarchy
                    from tools.gui import scroll_mouse
                    scroll_mouse(clicks=-2)
                    time.sleep(0.2)
                elif attempt == 2:
                    # Attempt 2: Re-focus target window via aggressive Win32 thread attachment
                    target_app = sanitized_args.get("app_name") or sanitized_args.get("app")
                    from tools.gui_controller import force_foreground_focus, focus_app_window
                    if pre_hwnd:
                        force_foreground_focus(pre_hwnd)
                    elif target_app:
                        focus_app_window(target_app)
                    time.sleep(0.2)
                elif attempt == 3:
                    # Attempt 3: Degrade gracefully to keyboard navigation
                    from tools.gui import press_hotkey
                    press_hotkey(keys="tab")
                    time.sleep(0.1)
            except Exception:
                pass

        # If failed, check if recoverable
        recoverable = is_recoverable_error(tool_name, args, last_result, last_exception)
        if not recoverable or attempt >= max_retries:
            break

        time.sleep(RETRY_DELAY_SECONDS)

    # Failed after all retry attempts
    last_result["success"] = False
    last_result["verified"] = False
    if tool_name in ui_interact_tools:
        # Mark environmental UI misses as RECOVERABLE_UI_DRIFT to suppress destructive rollback
        last_result["status"] = "RECOVERABLE_UI_DRIFT"
        last_result["error_code"] = "RECOVERABLE_UI_DRIFT"
        last_result["recoverable"] = True
    elif "status" not in last_result or last_result.get("status") in ("completed", "unverified", None):
        last_result["status"] = "failed"
    if "message" not in last_result:
        last_result["message"] = f"Tool '{tool_name}' failed after {last_result.get('attempts', 1)} attempt(s)."

    return last_result


def supervise_step_execution(
    step: Any,
    context: Any = None,
    sanitized_args: dict[str, Any] | None = None,
    confirmed: bool = False,
    **kwargs: Any,
) -> dict[str, Any]:
    """
    Wrap all tool and step dispatches in an adaptive supervisor pattern that catches
    native Win32 errors, OS pipe breakage, memory limits, and unhandled exceptions
    without crashing or terminating the agent session.
    """
    from tools.system_sentry import check_and_enforce_ram_headroom
    # Proactively enforce RAM headroom before tool dispatch
    check_and_enforce_ram_headroom()

    tool_name = getattr(step, "tool", "") or (step.get("tool") if isinstance(step, dict) else "")
    args = sanitized_args if sanitized_args is not None else (getattr(step, "args", {}) or (step.get("args") if isinstance(step, dict) else {}))

    try:
        raw_res = run_tool_call(tool_name, args, confirmed=confirmed)
        if raw_res.get("success", False) or raw_res.get("needs_confirmation", False):
            return raw_res

        raw_res.get("message") or "Tool execution failed"
        try:
            setattr(step, "status", "FAILED")
        except Exception:
            pass

        return raw_res

    except (Exception, OSError, MemoryError, BrokenPipeError) as e:
        safe_err = str(e).encode("ascii", errors="replace").decode("ascii")
        try:
            setattr(step, "status", "FAILED")
        except Exception:
            pass

        return {
            "success": False,
            "verified": False,
            "status": "failed",
            "message": f"Step {tool_name} failed: {safe_err}",
            "error": safe_err,
        }

