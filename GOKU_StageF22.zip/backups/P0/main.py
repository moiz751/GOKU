"""
Offline Desktop AI Agent Entry Point.
Performs automatic Ollama health check/startup, model verification,
and text command loop.
"""
import sys
from pathlib import Path

# Fix ROOT_DIR to current directory (not parent.parent.parent.parent)
ROOT_DIR = Path(__file__).resolve().parent
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))


def init_dpi_awareness() -> float:
    """
    Initializes per-monitor v2 DPI awareness and returns detected scaling factor.
    Must be called before any GUI imports or window measurements.
    """
    if sys.platform != "win32":
        return 1.0
    scale = 1.0
    mode = "UNAWARE"
    try:
        import ctypes
        # 1. Try SetProcessDpiAwarenessContext(DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2 = -4)
        try:
            res = ctypes.windll.user32.SetProcessDpiAwarenessContext(ctypes.c_void_p(-4))
            if res:
                mode = "PER_MONITOR_AWARE_V2"
            else:
                raise OSError("SetProcessDpiAwarenessContext returned NULL")
        except Exception:
            # 2. Fall back to SetProcessDpiAwareness(PROCESS_PER_MONITOR_DPI_AWARE = 2)
            try:
                ctypes.windll.shcore.SetProcessDpiAwareness(2)
                mode = "PROCESS_PER_MONITOR_DPI_AWARE"
            except Exception:
                # 3. Fall back to SetProcessDPIAware()
                try:
                    ctypes.windll.user32.SetProcessDPIAware()
                    mode = "SYSTEM_DPI_AWARE"
                except Exception:
                    mode = "UNAWARE"

        # Detect scale
        try:
            dpi = ctypes.windll.user32.GetDpiForSystem()
            scale = dpi / 96.0
        except Exception:
            try:
                hdc = ctypes.windll.user32.GetDC(0)
                LOGPIXELSX = 88
                dpi = ctypes.windll.gdi32.GetDeviceCaps(hdc, LOGPIXELSX)
                ctypes.windll.user32.ReleaseDC(0, hdc)
                scale = dpi / 96.0
            except Exception:
                scale = 1.0

        # Attach thread to interactive desktop
        try:
            h_def = ctypes.windll.user32.OpenDesktopW("default", 0, False, 0x01FF)
            if h_def:
                ctypes.windll.user32.SetThreadDesktop(h_def)
        except Exception:
            pass

        w = ctypes.windll.user32.GetSystemMetrics(0)
        h = ctypes.windll.user32.GetSystemMetrics(1)
        print(f"[DPI] Process DPI awareness initialized: {mode} (Scale: {scale * 100:.0f}%, DPI: {int(scale * 96)}, Screen: {w}x{h})")
    except Exception as e:
        print(f"[DPI] Warning: DPI awareness setup failed: {e}")
    return scale


# Initialize DPI awareness before GUI imports
SYSTEM_DPI_SCALE = init_dpi_awareness()

from brain.ollama_manager import cleanup_agent_ollama, ensure_ollama_ready
from command_layer.router import handle_command
from tools.registry import discover_tools
from tools.instance_lock import (
    acquire_single_instance_lock,
    cleanup_child_processes,
    install_lifecycle_guards,
    release_single_instance_lock,
)


def main():
    if not acquire_single_instance_lock():
        print("[SINGLE INSTANCE ERROR] Another instance of GOKU is already running. Exiting.")
        sys.exit(1)

    install_lifecycle_guards()

    discover_tools()

    # Automatic Ollama health check & service startup
    ensure_ollama_ready()

    print("\nOffline agent ready. Type a command (or 'exit').")

    try:
        while True:
            try:
                user_text = input("> ").strip()
            except (EOFError, KeyboardInterrupt):
                print("\nExiting session.")
                break

            if user_text.lower() in ("exit", "quit"):
                break
            if not user_text:
                continue

            try:
                reply = handle_command(user_text)
                if reply:
                    print(reply)
            except Exception as e:
                print(f"[Warning] Command execution encountered an error: {e}")
                # Keep prompt loop alive after errors or warnings
                continue
    finally:
        cleanup_child_processes()
        cleanup_agent_ollama()
        release_single_instance_lock()


if __name__ == "__main__":
    main()

