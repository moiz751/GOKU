"""
tools/input_guard.py - Safe Actuator Choke Point for GOKU

Provides a single, strictly guarded entry point for all physical keyboard,
mouse, and text actuation on Windows. Enforces:
- Registered ownership of target processes/windows.
- Protected window immunity (Antigravity IDE, browser AI chats, consoles, parent tree).
- Foreground lock verification with AttachThreadInput focus restoration.
- Chunked typing (max 5 chars) with pre-chunk focus re-verification.
- Kill switches (STOP_GOKU file, GOKU_INPUT_DISABLED=1).
- Audit trail in logs/input_audit.jsonl.
- Strict GOKU_TEST_MODE isolation.
"""
from __future__ import annotations

import ctypes
from ctypes import wintypes
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import sys
import time
from typing import Any

_PYAUTOGUI = None


def _get_pyautogui():
    global _PYAUTOGUI
    if _PYAUTOGUI is None:
        try:
            import pyautogui
            pyautogui.FAILSAFE = True
            _PYAUTOGUI = pyautogui
        except ImportError:
            _PYAUTOGUI = None
    return _PYAUTOGUI


class _LazyModuleProxy:
    def __init__(self, loader):
        self._loader = loader

    def __getattr__(self, name):
        m = self._loader()
        if m is None:
            raise AttributeError(f"Module is unavailable: {name}")
        return getattr(m, name)

    def __bool__(self):
        return self._loader() is not None

    def __eq__(self, other):
        if other is None:
            return self._loader() is None
        return self._loader() == other


pyautogui = _LazyModuleProxy(_get_pyautogui)


def __getattr__(name):
    if name == "pyautogui":
        return _get_pyautogui()
    raise AttributeError(f"module '{__name__}' has no attribute '{name}'")


try:
    import psutil
except ImportError:
    psutil = None

PROJECT_ROOT = Path(__file__).absolute().parent.parent
LOGS_DIR = PROJECT_ROOT / "logs"
AUDIT_LOG_PATH = LOGS_DIR / "input_audit.jsonl"
KILL_SWITCH_FILE = PROJECT_ROOT / "STOP_GOKU"

# Registry of authorized owned windows and processes
_OWNED_WINDOWS: dict[int, dict[str, Any]] = {}
_OWNED_PIDS: set[int] = set()
_PROTECTED_WINDOWS: set[int] = set()

# Protected process names (case-insensitive)
PROTECTED_PROCESS_NAMES = {
    "antigravity ide.exe",
    "antigravity.exe",
    "code.exe",
    "cursor.exe",
    "windsurf.exe",
    "devenv.exe",
    "codex.exe",
    "codex-windows-sandbox-service.exe",
    "claude.exe",
    "pycharm.exe",
    "pycharm64.exe",
    "powershell.exe",
    "cmd.exe",
    "windowsterminal.exe",
    "conhost.exe",
}

# Win32 Constants
INPUT_MOUSE = 0
INPUT_KEYBOARD = 1
KEYEVENTF_KEYUP = 0x0002
KEYEVENTF_UNICODE = 0x0004
MOUSEEVENTF_LEFTDOWN = 0x0002
MOUSEEVENTF_LEFTUP = 0x0004
MOUSEEVENTF_RIGHTDOWN = 0x0008
MOUSEEVENTF_RIGHTUP = 0x0010
MOUSEEVENTF_MIDDLEDOWN = 0x0020
MOUSEEVENTF_MIDDLEUP = 0x0040
MOUSEEVENTF_WHEEL = 0x0800
VK_MENU = 0x12
VK_RETURN = 0x0D
SW_RESTORE = 9

if sys.platform == "win32":
    class MOUSEINPUT(ctypes.Structure):
        _fields_ = [
            ("dx", wintypes.LONG),
            ("dy", wintypes.LONG),
            ("mouseData", wintypes.DWORD),
            ("dwFlags", wintypes.DWORD),
            ("time", wintypes.DWORD),
            ("dwExtraInfo", ctypes.POINTER(ctypes.c_ulong)),
        ]

    class KEYBDINPUT(ctypes.Structure):
        _fields_ = [
            ("wVk", wintypes.WORD),
            ("wScan", wintypes.WORD),
            ("dwFlags", wintypes.DWORD),
            ("time", wintypes.DWORD),
            ("dwExtraInfo", ctypes.POINTER(ctypes.c_ulong)),
        ]

    class HARDWAREINPUT(ctypes.Structure):
        _fields_ = [
            ("uMsg", wintypes.DWORD),
            ("wParamL", wintypes.WORD),
            ("wParamH", wintypes.WORD),
        ]

    class _INPUT_UNION(ctypes.Union):
        _fields_ = [
            ("mi", MOUSEINPUT),
            ("ki", KEYBDINPUT),
            ("hi", HARDWAREINPUT),
        ]

    class INPUT(ctypes.Structure):
        _fields_ = [
            ("type", wintypes.DWORD),
            ("u", _INPUT_UNION),
        ]


def register_owned_window(hwnd: int, pid: int | None = None, reason: str = "") -> None:
    """
    Registers a window and process as owned by GOKU or a running test.
    Only windows belonging to processes spawned by GOKU or the test may be registered.
    """
    if not hwnd and not pid:
        return
    h = int(hwnd) if hwnd else 0
    p = int(pid) if pid else 0
    if h and not p and sys.platform == "win32":
        proc_id = wintypes.DWORD()
        ctypes.windll.user32.GetWindowThreadProcessId(h, ctypes.byref(proc_id))
        p = int(proc_id.value) if proc_id.value else 0

    if p:
        _OWNED_PIDS.add(p)
    if h:
        _OWNED_WINDOWS[h] = {
            "pid": p,
            "reason": reason or "Registered owned window",
            "time": time.time(),
        }
        try:
            from tools.window_lifecycle import ownership_registry
            ownership_registry.register(h, p, app_name=reason, how_proven="input_guard")
        except Exception:
            pass


def unregister_owned_window(hwnd: int | None = None, pid: int | None = None) -> None:
    """Removes a window or process from the owned registry upon closure."""
    if hwnd:
        _OWNED_WINDOWS.pop(int(hwnd), None)
        try:
            from tools.window_lifecycle import ownership_registry
            ownership_registry.unregister(int(hwnd))
        except Exception:
            pass
    if pid:
        _OWNED_PIDS.discard(int(pid))


def register_protected_window(hwnd: int, reason: str = "Explicitly protected") -> None:
    """Explicitly marks an HWND as protected (e.g. for testing fake IDEs)."""
    if hwnd:
        _PROTECTED_WINDOWS.add(int(hwnd))


def unregister_protected_window(hwnd: int) -> None:
    """Removes explicit protection from an HWND."""
    if hwnd:
        _PROTECTED_WINDOWS.discard(int(hwnd))


def get_window_pid(hwnd: int) -> int:
    """Retrieves the process ID for an HWND."""
    if not hwnd or sys.platform != "win32":
        return 0
    try:
        pid = wintypes.DWORD()
        ctypes.windll.user32.GetWindowThreadProcessId(int(hwnd), ctypes.byref(pid))
        return int(pid.value) if pid.value else 0
    except Exception:
        return 0


def get_window_title(hwnd: int) -> str:
    """Retrieves the window title for an HWND."""
    if not hwnd or sys.platform != "win32":
        return ""
    try:
        length = ctypes.windll.user32.GetWindowTextLengthW(int(hwnd)) + 1
        buff = ctypes.create_unicode_buffer(length)
        ctypes.windll.user32.GetWindowTextW(int(hwnd), buff, length)
        return buff.value or ""
    except Exception:
        return ""


def get_process_name(pid: int) -> str:
    """Retrieves the executable name for a PID."""
    if not pid:
        return ""
    if psutil is not None:
        try:
            return psutil.Process(pid).name().lower().strip()
        except Exception:
            pass
    if sys.platform == "win32":
        try:
            kernel32 = ctypes.windll.kernel32
            h_proc = kernel32.OpenProcess(0x1000, False, pid)
            if h_proc:
                try:
                    buff = ctypes.create_unicode_buffer(1024)
                    sz = wintypes.DWORD(1024)
                    if kernel32.QueryFullProcessImageNameW(h_proc, 0, buff, ctypes.byref(sz)):
                        return Path(buff.value).name.lower().strip()
                finally:
                    kernel32.CloseHandle(h_proc)
        except Exception:
            pass
    return ""


def get_ancestor_pids() -> set[int]:
    """Retrieves the full ancestor process tree of the current Python process."""
    ancestors: set[int] = set()
    current_pid = os.getpid()
    ancestors.add(current_pid)
    if psutil is not None:
        try:
            p = psutil.Process(current_pid)
            ancestors.add(p.pid)
            for parent in p.parents():
                ancestors.add(parent.pid)
        except Exception:
            pass
    return ancestors


def is_protected(hwnd: int) -> bool:
    """
    Returns True if the window belongs to:
    1. Antigravity IDE or VS Code / Cursor / Windsurf / PyCharm
    2. Any browser window whose title contains Claude, ChatGPT, or Gemini
    3. The console window hosting the current process or its parent chain
    4. The process tree that launched GOKU
    5. Any explicitly registered protected windows
    """
    if not hwnd or sys.platform != "win32":
        return False
    h = int(hwnd)

    if h in _PROTECTED_WINDOWS:
        return True

    kernel32 = ctypes.windll.kernel32

    # Check console window hosting the current process
    try:
        console_hwnd = kernel32.GetConsoleWindow()
        if console_hwnd and h == int(console_hwnd):
            return True
    except Exception:
        pass

    # Check process PID and process tree
    pid = get_window_pid(h)
    if pid:
        ancestors = get_ancestor_pids()
        if pid in ancestors:
            return True

        pname = get_process_name(pid)
        if pname in PROTECTED_PROCESS_NAMES or any(prot in pname for prot in ["antigravity", "cursor", "windsurf", "code"]):
            return True

    # Check window title
    title = get_window_title(h)
    title_lower = title.lower()

    # Browser windows with AI chat sites
    if any(chat_keyword in title_lower for chat_keyword in ["claude", "chatgpt", "gemini"]):
        return True

    # IDE title keywords
    if any(ide_keyword in title_lower for ide_keyword in ["antigravity", "visual studio code", "cursor", "windsurf", "pycharm"]):
        return True
    if "code - " in title_lower or " - visual studio" in title_lower:
        return True

    return False


def is_window_owned(hwnd: int) -> tuple[bool, str]:
    """
    Checks if a window belongs to a process spawned by GOKU or the test.
    Returns (is_owned, reason).
    """
    if not hwnd:
        return False, "HWND is 0 or None"
    h = int(hwnd)

    if h in _OWNED_WINDOWS:
        return True, _OWNED_WINDOWS[h].get("reason", "Registered owned HWND")

    pid = get_window_pid(h)
    if pid and pid in _OWNED_PIDS:
        return True, f"Window belongs to registered owned PID {pid}"

    # Check process tree relationship
    if pid and psutil is not None:
        try:
            proc = psutil.Process(pid)
            for parent in proc.parents():
                if parent.pid in _OWNED_PIDS:
                    _OWNED_WINDOWS[h] = {"pid": pid, "reason": f"Child of owned PID {parent.pid}", "time": time.time()}
                    return True, f"Child of owned PID {parent.pid}"
        except Exception:
            pass

    # Check tools.apps spawned registries
    try:
        from tools.apps import _SPAWNED_APP_PIDS, _TEST_LAUNCHED_HWNDS, _TEST_LAUNCHED_PIDS
        if h in _TEST_LAUNCHED_HWNDS:
            return True, "Registered in test target HWNDs"
        if pid and (pid in _TEST_LAUNCHED_PIDS or any(pid in pids for pids in _SPAWNED_APP_PIDS.values())):
            return True, f"Found in tools.apps tracked PIDs ({pid})"
    except Exception:
        pass

    return False, f"Window (HWND {h}, PID {pid}) is not registered as owned"


def ensure_input_desktop() -> None:
    """Enables foreground window control permissions."""
    if sys.platform == "win32":
        try:
            ctypes.windll.user32.AllowSetForegroundWindow(-1)
        except Exception:
            pass


def bring_window_to_foreground(hwnd: int, max_attempts: int = 3) -> bool:
    """
    Brings target_hwnd to the foreground using the Win32 AttachThreadInput method.
    Makes up to max_attempts attempts, re-checking GetForegroundWindow each time.
    """
    if not hwnd or sys.platform != "win32":
        return False
    ensure_input_desktop()
    user32 = ctypes.windll.user32
    kernel32 = ctypes.windll.kernel32

    for _ in range(max_attempts):
        if user32.GetForegroundWindow() == hwnd:
            return True

        fg_hwnd = user32.GetForegroundWindow()
        fg_tid = user32.GetWindowThreadProcessId(fg_hwnd, None) if fg_hwnd else 0
        target_tid = user32.GetWindowThreadProcessId(hwnd, None)
        cur_tid = kernel32.GetCurrentThreadId()

        attached_fg = False
        attached_target = False

        if fg_tid and fg_tid != cur_tid:
            attached_fg = bool(user32.AttachThreadInput(cur_tid, fg_tid, True))
        if target_tid and target_tid != cur_tid:
            attached_target = bool(user32.AttachThreadInput(cur_tid, target_tid, True))

        try:
            try:
                user32.LockSetForegroundWindow(2)  # LSFW_UNLOCK
            except Exception:
                pass
            user32.AllowSetForegroundWindow(-1)
            # ALT key bypass for Windows focus stealing restriction
            user32.keybd_event(0x12, 0, 0, 0)
            user32.keybd_event(0x12, 0, 0x0002, 0)
            user32.ShowWindow(hwnd, SW_RESTORE)
            user32.SetWindowPos(hwnd, -1, 0, 0, 0, 0, 0x0003)
            user32.SetWindowPos(hwnd, -2, 0, 0, 0, 0, 0x0003)
            user32.BringWindowToTop(hwnd)
            user32.SetForegroundWindow(hwnd)
        finally:
            if attached_fg and fg_tid:
                user32.AttachThreadInput(cur_tid, fg_tid, False)
            if attached_target and target_tid:
                user32.AttachThreadInput(cur_tid, target_tid, False)

        time.sleep(0.08)
        if user32.GetForegroundWindow() == hwnd:
            return True

    return user32.GetForegroundWindow() == hwnd


def log_input_decision(
    target_hwnd: int,
    payload: Any,
    kind: str,
    decision: str,
    reason: str,
    owned: bool = False,
    chars_sent: int = 0,
) -> None:
    """Appends an input decision record to logs/input_audit.jsonl."""
    try:
        LOGS_DIR.mkdir(parents=True, exist_ok=True)
        user32 = ctypes.windll.user32 if sys.platform == "win32" else None
        fg_hwnd = user32.GetForegroundWindow() if user32 else 0

        target_pid = get_window_pid(target_hwnd)
        fg_pid = get_window_pid(fg_hwnd)

        record = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "kind": kind,
            "target": {
                "hwnd": int(target_hwnd or 0),
                "title": get_window_title(target_hwnd) if target_hwnd else "",
                "process": get_process_name(target_pid) if target_pid else "",
                "pid": target_pid,
            },
            "owned": "yes" if owned else "no",
            "foreground": {
                "hwnd": int(fg_hwnd or 0),
                "title": get_window_title(fg_hwnd) if fg_hwnd else "",
                "process": get_process_name(fg_pid) if fg_pid else "",
                "pid": fg_pid,
            },
            "payload_sample": str(payload)[:20] if payload is not None else "",
            "chars_sent": int(chars_sent),
            "decision": decision,
            "reason": reason,
        }
        with open(AUDIT_LOG_PATH, "a", encoding="utf-8") as f:
            f.write(json.dumps(record) + "\n")
    except Exception:
        pass


def _physical_send(action: str, **kwargs: Any) -> Any:
    """
    THE ONLY FUNCTION in the entire codebase permitted to execute raw Win32
    actuation APIs (keybd_event, mouse_event, SendInput, SetCursorPos).
    Must only be called after all verification checks have strictly passed.
    """
    if sys.platform != "win32":
        return None
    user32 = ctypes.windll.user32

    if action == "send_vk":
        vk = int(kwargs["vk"])
        is_up = bool(kwargs.get("is_up", False))
        flags = KEYEVENTF_KEYUP if is_up else 0
        user32.keybd_event(vk, 0, flags, 0)

    elif action == "type_unicode":
        ch = str(kwargs["char"])
        code = ord(ch)
        inp_down = INPUT(type=INPUT_KEYBOARD)
        inp_down.u.ki = KEYBDINPUT(wVk=0, wScan=code, dwFlags=KEYEVENTF_UNICODE, time=0, dwExtraInfo=None)
        inp_up = INPUT(type=INPUT_KEYBOARD)
        inp_up.u.ki = KEYBDINPUT(wVk=0, wScan=code, dwFlags=KEYEVENTF_UNICODE | KEYEVENTF_KEYUP, time=0, dwExtraInfo=None)
        events = (INPUT * 2)(inp_down, inp_up)
        user32.SendInput(2, ctypes.byref(events), ctypes.sizeof(INPUT))

    elif action == "mouse_click":
        x = kwargs.get("x")
        y = kwargs.get("y")
        button = str(kwargs.get("button", "left")).lower().strip()
        clicks = int(kwargs.get("clicks", 1))
        if x is not None and y is not None:
            user32.SetCursorPos(int(x), int(y))
            time.sleep(0.02)
        down_flag = MOUSEEVENTF_RIGHTDOWN if button == "right" else (MOUSEEVENTF_MIDDLEDOWN if button == "middle" else MOUSEEVENTF_LEFTDOWN)
        up_flag = MOUSEEVENTF_RIGHTUP if button == "right" else (MOUSEEVENTF_MIDDLEUP if button == "middle" else MOUSEEVENTF_LEFTUP)
        for _ in range(clicks):
            user32.mouse_event(down_flag, 0, 0, 0, 0)
            time.sleep(0.01)
            user32.mouse_event(up_flag, 0, 0, 0, 0)
            time.sleep(0.05)

    elif action == "mouse_wheel":
        delta = int(kwargs.get("delta", 120))
        user32.mouse_event(MOUSEEVENTF_WHEEL, 0, 0, int(delta), 0)

    elif action == "mouse_down":
        btn = str(kwargs.get("button", "left")).lower().strip()
        down_flag = MOUSEEVENTF_RIGHTDOWN if btn == "right" else (MOUSEEVENTF_MIDDLEDOWN if btn == "middle" else MOUSEEVENTF_LEFTDOWN)
        user32.mouse_event(down_flag, 0, 0, 0, 0)

    elif action == "mouse_up":
        btn = str(kwargs.get("button", "left")).lower().strip()
        up_flag = MOUSEEVENTF_RIGHTUP if btn == "right" else (MOUSEEVENTF_MIDDLEUP if btn == "middle" else MOUSEEVENTF_LEFTUP)
        user32.mouse_event(up_flag, 0, 0, 0, 0)

    return True


VK_KEY_MAP: dict[str, int] = {
    "enter": 0x0D, "return": 0x0D, "esc": 0x1B, "escape": 0x1B, "tab": 0x09,
    "space": 0x20, "spacebar": 0x20, "backspace": 0x08, "delete": 0x2E, "del": 0x2E,
    "insert": 0x2D, "home": 0x24, "end": 0x23, "pageup": 0x21, "pagedown": 0x22,
    "ctrl": 0x11, "alt": 0x12, "shift": 0x10, "win": 0x5B, "capslock": 0x14,
    "up": 0x26, "down": 0x28, "left": 0x25, "right": 0x27,
    "f1": 0x70, "f2": 0x71, "f3": 0x72, "f4": 0x73, "f5": 0x74, "f6": 0x75,
    "f7": 0x76, "f8": 0x77, "f9": 0x78, "f10": 0x79, "f11": 0x7A, "f12": 0x7B,
    "a": 0x41, "b": 0x42, "c": 0x43, "d": 0x44, "e": 0x45, "f": 0x46, "g": 0x47,
    "h": 0x48, "i": 0x49, "j": 0x4A, "k": 0x4B, "l": 0x4C, "m": 0x4D, "n": 0x4E,
    "o": 0x4F, "p": 0x50, "q": 0x51, "r": 0x52, "s": 0x53, "t": 0x54, "u": 0x55,
    "v": 0x56, "w": 0x57, "x": 0x58, "y": 0x59, "z": 0x5A,
    "0": 0x30, "1": 0x31, "2": 0x32, "3": 0x33, "4": 0x34, "5": 0x35,
    "6": 0x36, "7": 0x37, "8": 0x38, "9": 0x39,
}


def guarded_send(
    kind: str,
    target_hwnd: int | None,
    payload: Any = None,
    **kwargs: Any,
) -> dict[str, Any]:
    """
    The ONLY function authorized to send keys, clicks, or text to Windows windows.
    Enforces rules:
    a) Target must be registered as owned AND not protected;
    b) GetForegroundWindow() must equal target; if not, try AttachThreadInput focus bringer;
    c) Type text in chunks of at most 5 characters, re-checking foreground window before EVERY chunk;
    d) Kill switches: STOP_GOKU file or GOKU_INPUT_DISABLED=1 halts all output;
    e) PyAutoGUI failsafe remains enabled;
    f) Decision appended to logs/input_audit.jsonl.
    """
    # Rule e: Keep PyAutoGUI failsafe enabled
    if pyautogui is not None:
        pyautogui.FAILSAFE = True

    # Rule d: Kill switch verification
    if KILL_SWITCH_FILE.exists() or os.environ.get("GOKU_INPUT_DISABLED") == "1":
        reason = "Kill switch active (STOP_GOKU file exists or GOKU_INPUT_DISABLED=1)"
        log_input_decision(target_hwnd or 0, payload, kind, "REFUSED", reason)
        return {"status": "UNVERIFIED", "success": False, "reason": reason}

    if sys.platform != "win32":
        return {"status": "PASSED", "success": True, "message": "Non-Windows platform bypass"}

    ensure_input_desktop()
    user32 = ctypes.windll.user32
    fg_hwnd = user32.GetForegroundWindow()

    # Resolve target_hwnd if None or 0
    resolved_hwnd = int(target_hwnd or 0)
    if not resolved_hwnd:
        app_name = kwargs.get("app_name") or kwargs.get("name") or kwargs.get("target_window")
        if app_name:
            try:
                from tools.window import _get_target_hwnd
                resolved_hwnd = _get_target_hwnd(str(app_name)) or 0
            except Exception:
                pass
        if not resolved_hwnd and _OWNED_WINDOWS:
            resolved_hwnd = list(_OWNED_WINDOWS.keys())[-1]

    if not resolved_hwnd:
        # If no explicit target provided, check if current foreground window is valid and owned
        is_fg_owned, _ = is_window_owned(fg_hwnd)
        if is_fg_owned and not is_protected(fg_hwnd):
            resolved_hwnd = fg_hwnd
        else:
            reason = f"No target HWND specified and current foreground window (HWND {fg_hwnd}, '{get_window_title(fg_hwnd)}') is not registered as owned"
            log_input_decision(resolved_hwnd, payload, kind, "REFUSED", reason)
            return {"status": "UNVERIFIED", "success": False, "reason": reason}

    # Test mode validation: when GOKU_TEST_MODE=1, only dedicated test-registered windows are allowed
    if os.environ.get("GOKU_TEST_MODE") == "1":
        try:
            from tools.apps import is_window_launched_by_test
            if not is_window_launched_by_test(resolved_hwnd):
                reason = f"GOKU_TEST_MODE=1 active: target window (HWND {resolved_hwnd}, '{get_window_title(resolved_hwnd)}') was not launched by test"
                log_input_decision(resolved_hwnd, payload, kind, "REFUSED", reason)
                return {"status": "UNVERIFIED", "success": False, "reason": reason}
        except Exception:
            pass

    # Rule a: Target must NOT be protected
    if is_protected(resolved_hwnd):
        reason = f"Target window (HWND {resolved_hwnd}, '{get_window_title(resolved_hwnd)}') is protected (IDE, AI chat, or console tree)"
        log_input_decision(resolved_hwnd, payload, kind, "REFUSED", reason)
        return {"status": "UNVERIFIED", "success": False, "reason": reason}

    # Rule a: Target must be registered as owned
    owned, own_reason = is_window_owned(resolved_hwnd)
    if not owned:
        reason = f"Target window (HWND {resolved_hwnd}, '{get_window_title(resolved_hwnd)}') is not owned: {own_reason}"
        log_input_decision(resolved_hwnd, payload, kind, "REFUSED", reason)
        return {"status": "UNVERIFIED", "success": False, "reason": reason}

    # Rule b: GetForegroundWindow() must equal target; if not, try to bring to front (max 3 attempts)
    cur_fg = user32.GetForegroundWindow()
    if cur_fg and cur_fg != resolved_hwnd:
        brought = bring_window_to_foreground(resolved_hwnd, max_attempts=3)
        if not brought:
            cur_fg_after = user32.GetForegroundWindow()
            if cur_fg_after and cur_fg_after != resolved_hwnd:
                reason = f"Target HWND {resolved_hwnd} could not be brought to foreground (current foreground is HWND {cur_fg_after}, '{get_window_title(cur_fg_after)}')"
                log_input_decision(resolved_hwnd, payload, kind, "REFUSED", reason)
                return {"status": "UNVERIFIED", "success": False, "reason": reason}

    # Re-verify that foreground window itself is not protected
    cur_fg = user32.GetForegroundWindow()
    if cur_fg and is_protected(cur_fg):
        reason = f"Active foreground window (HWND {cur_fg}, '{get_window_title(cur_fg)}') is protected"
        log_input_decision(resolved_hwnd, payload, kind, "REFUSED", reason, owned=owned, chars_sent=0)
        return {"status": "UNVERIFIED", "success": False, "reason": reason}

    # Dispatch: KIND == "type_text"
    if kind == "type_text":
        text = str(payload or "")
        press_enter = bool(kwargs.get("press_enter", False))
        chunk_size = 5
        chars_sent = 0

        for i in range(0, len(text), chunk_size):
            chunk = text[i : i + chunk_size]
            # Rule c: Re-check foreground window before EVERY chunk
            active_fg = user32.GetForegroundWindow()
            if active_fg and active_fg != resolved_hwnd:
                reason = f"Focus stolen before chunk '{chunk}': active window is HWND {active_fg} ('{get_window_title(active_fg)}') instead of target {resolved_hwnd}"
                log_input_decision(resolved_hwnd, chunk, kind, "REFUSED", reason, owned=owned, chars_sent=chars_sent)
                return {
                    "status": "UNVERIFIED",
                    "success": False,
                    "reason": reason,
                    "chars_sent": chars_sent,
                }

            # Send chunk characters exclusively through _physical_send
            for ch in chunk:
                _physical_send("type_unicode", char=ch)
                time.sleep(0.002)
            chars_sent += len(chunk)
            time.sleep(0.01)

        if press_enter:
            active_fg = user32.GetForegroundWindow()
            if active_fg == resolved_hwnd:
                _physical_send("send_vk", vk=VK_RETURN, is_up=False)
                time.sleep(0.005)
                _physical_send("send_vk", vk=VK_RETURN, is_up=True)
            else:
                reason = f"Focus stolen before Enter key: active window is HWND {active_fg}"
                log_input_decision(resolved_hwnd, payload, kind, "REFUSED", reason, owned=owned, chars_sent=chars_sent)
                return {
                    "status": "UNVERIFIED",
                    "success": False,
                    "reason": reason,
                    "chars_sent": chars_sent,
                }

        log_input_decision(resolved_hwnd, payload, kind, "ALLOWED", "Target owned, foreground verified, not protected", owned=True, chars_sent=chars_sent)
        return {"status": "PASSED", "success": True, "chars_sent": chars_sent}

    # Dispatch: KIND == "press_hotkey"
    elif kind == "press_hotkey":
        keys_str = str(payload or "").lower().strip()
        parts = [k.strip() for k in keys_str.replace("+", " ").split() if k.strip()]
        vks = [VK_KEY_MAP.get(p) or (ord(p[0].upper()) if len(p) == 1 else 0) for p in parts]
        # Down in order
        for vk in vks:
            if vk:
                _physical_send("send_vk", vk=vk, is_up=False)
        time.sleep(0.02)
        # Up in reverse
        for vk in reversed(vks):
            if vk:
                _physical_send("send_vk", vk=vk, is_up=True)
        log_input_decision(resolved_hwnd, payload, kind, "ALLOWED", "Target owned, foreground verified, not protected", owned=True, chars_sent=len(keys_str))
        return {"status": "PASSED", "success": True, "keys": keys_str}

    # Dispatch: KIND == "click_mouse"
    elif kind == "click_mouse":
        params = payload if isinstance(payload, dict) else {}
        x = params.get("x")
        y = params.get("y")
        button = params.get("button", "left")
        clicks = int(params.get("clicks", 1))
        _physical_send("mouse_click", x=x, y=y, button=button, clicks=clicks)
        log_input_decision(resolved_hwnd, payload, kind, "ALLOWED", "Target owned, foreground verified, not protected", owned=True, chars_sent=0)
        return {"status": "PASSED", "success": True}

    # Dispatch: KIND == "mouse_scroll"
    elif kind == "mouse_scroll":
        params = payload if isinstance(payload, dict) else {}
        delta = int(params.get("delta", 120))
        _physical_send("mouse_wheel", delta=delta)
        log_input_decision(resolved_hwnd, payload, kind, "ALLOWED", "Target owned, foreground verified, not protected", owned=True, chars_sent=0)
        return {"status": "PASSED", "success": True}

    # Dispatch: KIND == "mouse_down"
    elif kind == "mouse_down":
        btn = str(payload or "left")
        _physical_send("mouse_down", button=btn)
        log_input_decision(resolved_hwnd, payload, kind, "ALLOWED", "Target owned, foreground verified, not protected", owned=True, chars_sent=0)
        return {"status": "PASSED", "success": True}

    # Dispatch: KIND == "mouse_up"
    elif kind == "mouse_up":
        btn = str(payload or "left")
        _physical_send("mouse_up", button=btn)
        log_input_decision(resolved_hwnd, payload, kind, "ALLOWED", "Target owned, foreground verified, not protected", owned=True, chars_sent=0)
        return {"status": "PASSED", "success": True}

    # Dispatch: KIND == "paste_clipboard"
    elif kind == "paste_clipboard":
        # Dispatch Ctrl+V safely
        _physical_send("send_vk", vk=VK_KEY_MAP["ctrl"], is_up=False)
        _physical_send("send_vk", vk=VK_KEY_MAP["v"], is_up=False)
        time.sleep(0.01)
        _physical_send("send_vk", vk=VK_KEY_MAP["v"], is_up=True)
        _physical_send("send_vk", vk=VK_KEY_MAP["ctrl"], is_up=True)
        log_input_decision(resolved_hwnd, payload, kind, "ALLOWED", "Target owned, foreground verified, not protected", owned=True, chars_sent=0)
        return {"status": "PASSED", "success": True}

    # Dispatch: KIND == "key_down"
    elif kind == "key_down":
        key_name = str(payload or "").lower().strip()
        vk = VK_KEY_MAP.get(key_name) or (ord(key_name[0].upper()) if len(key_name) == 1 else 0)
        if vk:
            _physical_send("send_vk", vk=vk, is_up=False)
        log_input_decision(resolved_hwnd, payload, kind, "ALLOWED", "Target owned, foreground verified, not protected", owned=True, chars_sent=len(key_name))
        return {"status": "PASSED", "success": True, "key": key_name}

    # Dispatch: KIND == "key_up"
    elif kind == "key_up":
        key_name = str(payload or "").lower().strip()
        vk = VK_KEY_MAP.get(key_name) or (ord(key_name[0].upper()) if len(key_name) == 1 else 0)
        if vk:
            _physical_send("send_vk", vk=vk, is_up=True)
        log_input_decision(resolved_hwnd, payload, kind, "ALLOWED", "Target owned, foreground verified, not protected", owned=True, chars_sent=len(key_name))
        return {"status": "PASSED", "success": True, "key": key_name}

    return {"status": "UNVERIFIED", "success": False, "reason": f"Unknown actuation kind '{kind}'"}
