"""
Offline Desktop AI Agent Entry Point.
Performs automatic Ollama health check/startup, model verification,
and text command loop.
"""
import sys
from pathlib import Path

# Fix ROOT_DIR to current directory (not parent.parent.parent.parent)
ROOT_DIR = Path(__file__).resolve().parent
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))


def init_dpi_awareness() -> float:
    """
    Initializes per-monitor v2 DPI awareness and returns detected scaling factor.
    Must be called before any GUI imports or window measurements.
    """
    if sys.platform != "win32":
        return 1.0
    scale = 1.0
    mode = "UNAWARE"
    try:
        import ctypes
        # 1. Try SetProcessDpiAwarenessContext(DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2 = -4)
        try:
            res = ctypes.windll.user32.SetProcessDpiAwarenessContext(ctypes.c_void_p(-4))
            if res:
                mode = "PER_MONITOR_AWARE_V2"
            else:
                raise OSError("SetProcessDpiAwarenessContext returned NULL")
        except Exception:
            # 2. Fall back to SetProcessDpiAwareness(PROCESS_PER_MONITOR_DPI_AWARE = 2)
            try:
                ctypes.windll.shcore.SetProcessDpiAwareness(2)
                mode = "PROCESS_PER_MONITOR_DPI_AWARE"
            except Exception:
                # 3. Fall back to SetProcessDPIAware()
                try:
                    ctypes.windll.user32.SetProcessDPIAware()
                    mode = "SYSTEM_DPI_AWARE"
                except Exception:
                    mode = "UNAWARE"

        # Detect scale
        try:
            dpi = ctypes.windll.user32.GetDpiForSystem()
            scale = dpi / 96.0
        except Exception:
            try:
                hdc = ctypes.windll.user32.GetDC(0)
                LOGPIXELSX = 88
                dpi = ctypes.windll.gdi32.GetDeviceCaps(hdc, LOGPIXELSX)
                ctypes.windll.user32.ReleaseDC(0, hdc)
                scale = dpi / 96.0
            except Exception:
                scale = 1.0

        # Attach thread to interactive desktop
        try:
            h_def = ctypes.windll.user32.OpenDesktopW("default", 0, False, 0x01FF)
            if h_def:
                ctypes.windll.user32.SetThreadDesktop(h_def)
        except Exception:
            pass

        w = ctypes.windll.user32.GetSystemMetrics(0)
        h = ctypes.windll.user32.GetSystemMetrics(1)
        print(f"[DPI] Process DPI awareness initialized: {mode} (Scale: {scale * 100:.0f}%, DPI: {int(scale * 96)}, Screen: {w}x{h})")
    except Exception as e:
        print(f"[DPI] Warning: DPI awareness setup failed: {e}")
    return scale


# Initialize DPI awareness before GUI imports
SYSTEM_DPI_SCALE = init_dpi_awareness()

# P0: derive RAM budget / model options from the detected hardware tier. Must run BEFORE
# config.settings and tools.budget_governor are imported. Explicit user env vars always win.
try:
    from tools.hw_profile import apply_tier_defaults
    apply_tier_defaults()
except Exception:
    pass

from brain.ollama_manager import cleanup_agent_ollama, ensure_ollama_ready
from command_layer.router import handle_command
from tools.registry import discover_tools
from tools.instance_lock import (
    acquire_single_instance_lock,
    cleanup_child_processes,
    install_lifecycle_guards,
    release_single_instance_lock,
)


def _stop_scope():
    """P0: clears a stale stop flag and arms the emergency-stop hotkey while ONE command runs."""
    import contextlib
    try:
        from tools.emergency_stop import clear_stop, hotkey_watch
        clear_stop()
        return hotkey_watch()
    except Exception:
        return contextlib.nullcontext()


def _after_command():
    """P0: back to IDLE and one memory trim after each command (no timers, no threads)."""
    try:
        from tools.workload_modes import go_idle
        go_idle()
    except Exception:
        pass
    try:
        from brain.learning_hooks import run_idle_maintenance
        run_idle_maintenance()      # Stage C: bounded, only when idle and RAM normal; no threads
    except Exception:
        pass


def _try_local_task(user_text):
    """Calculations and explicit deep-thinking requests are answered by deterministic code; anything else
    (or any failure here) returns None so handle_command runs exactly as before."""
    try:
        from brain.task_agent import try_handle
        return try_handle(user_text)
    except Exception:
        return None


def main():
    if not acquire_single_instance_lock():
        print("[SINGLE INSTANCE ERROR] Another instance of GOKU is already running. Exiting.")
        sys.exit(1)

    install_lifecycle_guards()
    try:
        from brain.learning_hooks import install as _install_learning
        _install_learning()         # Stage C: observe tool outcomes (never changes results)
    except Exception:
        pass

    # P0: crash-recovery marker. A leftover marker from a dead process means the last run crashed.
    try:
        from tools.safe_state import begin_session
        _recovery = begin_session()
        if _recovery.get("recovered"):
            print("[RECOVERY] Previous session did not exit cleanly; held keys and mouse buttons were released.")
            _pending = _recovery.get("incomplete_tasks") or []
            if _pending:
                print(f"[RECOVERY] {len(_pending)} unfinished task(s): " + ", ".join(str(t.get("task_id")) for t in _pending[:5]))
    except Exception:
        pass

    discover_tools()

    # Automatic Ollama health check & service startup
    ensure_ollama_ready()

    print("\nOffline agent ready. Type a command (or 'exit').")

    try:
        while True:
            try:
                user_text = input("> ").strip()
            except (EOFError, KeyboardInterrupt):
                print("\nExiting session.")
                break

            if user_text.lower() in ("exit", "quit"):
                break
            if not user_text:
                continue

            try:
                with _stop_scope():
                    reply = _try_local_task(user_text)
                    if reply is None:
                        reply = handle_command(user_text)
                if reply:
                    print(reply)
                    try:
                        from brain.learning_hooks import record_episode
                        record_episode(user_text, str(reply), ok=None)   # Stage C: outcome not verified here
                    except Exception:
                        pass
            except Exception as e:
                print(f"[Warning] Command execution encountered an error: {e}")
                # Keep prompt loop alive after errors or warnings
                continue
            finally:
                _after_command()
    finally:
        cleanup_child_processes()
        cleanup_agent_ollama()
        release_single_instance_lock()
        try:
            from tools.safe_state import end_session
            end_session()
        except Exception:
            pass


if __name__ == "__main__":
    main()

