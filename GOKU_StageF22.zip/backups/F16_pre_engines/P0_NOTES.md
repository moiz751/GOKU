# GOKU P0 / P1-text / P2 notes

## What was added (existing function names and signatures untouched)
| Module | Purpose |
|---|---|
| tools/hw_profile.py | hardware probe, tiers tiny/small/medium/large, env defaults (user env always wins) |
| tools/resource_monitor.py | on-demand RAM/CPU/disk sampling, pressure levels, leak detection, capture planning |
| tools/workload_modes.py | Idle/Light/Normal/Deep/Game/Emergency; heavy modes never overlap |
| tools/emergency_stop.py | in-memory stop flag + STOP_GOKU file, input release, Ctrl+Alt+F12 hotkey (only while a command runs) |
| tools/safe_state.py | atomic checkpoints, crash detection (pid + create_time), recovery report |
| brain/calc_engine.py | exact, safe, double-checked calculations, equations, units, stats, dates, bases |
| brain/reasoning_engine.py | bounded reasoning with budget, checkpoints, stop, facts/assumptions/uncertainty report |
| brain/task_agent.py | routes calc / explicit deep-thinking; everything else still goes to handle_command |
| brain/text_analysis.py | streaming chunks, extractive summary, cited search |
Small edits: tools/input_guard.py (held-key tracking, stop check), executor/executor.py (stop + workload gate, enforce mode only), main.py (tier defaults, session marker, stop scope, local-task hook). Backups in backups/P0/.

## Honest limits
* Tier field `max_heavy_jobs` is reserved: the governor still uses ONE heavy slot.
* The 0.5B model is used only when `is_model_call_allowed()` says yes, and its answers are labelled unverified.
* Windows-only parts (hotkey, UIA, real RAM numbers, Ollama) are NOT tested in the build sandbox. Run `python scripts/p0_laptop_check.py` once and send `reports/p0/laptop_report.json`.
* In the sandbox: new tests 165 passed; full suite shows the same 190 failures / 143 collection errors as the original zip (all Windows-only), no new ones.
* Not done yet: screen multi-method understanding, memory/self-learning, game framework.

## Stage A (files)
tools/file_stream.py: streaming reader + disk-backed FTS5 index for txt/md/code/csv/json/xml/html/docx/xlsx/pptx/pdf/zip/images/audio/video (office via stdlib zip+XML, PDF via pypdf lazily). brain/doc_insight.py: cited summary, possible contradictions / missing info / assumptions, questions, code review (Python AST + generic rules), file comparison. Routed by brain/task_agent.py only for "analyze|review|inspect|audit|compare <existing file>"; every other file command still goes to the old router.
Measured in the sandbox: 54 MB text indexed in 0.9 s, RSS +6 MB.
Honest limits: images need an OCR callable (otherwise metadata only); audio/video are metadata only; scanned PDF pages are reported as "no text layer"; contradictions/assumptions are rule-based hints.

## Stage B (screen understanding)
New: tools/vision/frame_diff.py (small-grid frame comparison, region suggestion, motion/animation tracker, perceptual hash), tools/vision/screen_fusion.py (method planning by goal and RAM pressure, evidence fusion with stale-drop and disagreement report, bounded visual memory without pixels, user-activity detector, stale guard, error/dialog recognition, re-observe instead of guessing), tools/vision/screen_providers.py (Windows window/UIA/OCR/capture/cursor/monitor providers, never raise), tools/vision/screen_tool.py (read-only tool `understand_screen`). The existing observe()/UIA/Win32/OCR code is reused, not replaced.
Fixed: acceptance/oracles.py judged an honest "Task Status: FAILED" report as a false success because it searched for the substring "verified" (also inside "unverified" and in per-step lines). It now reads the overall Task Status line (`_claims_success`). Backup: backups/StageB/oracles.py.
Verified only with fake providers and generated images. Real capture, UIA, OCR and multi-monitor need `python scripts/stageB_laptop_check.py` on the laptop (read-only).
Still open from the outside review: game_engine.py rewards a "HIT" from screen brightness difference (not a verified game outcome); voice (STT/TTS) is not built; audio/video understanding is metadata only.

## RAM-aware partitioning (tools/ram_planner.py)
plan_parts / choose_quality / take_batch do the arithmetic (free RAM - headroom - fixed, x0.8 safety, per-item cost). PartitionedRunner runs a job in parts, re-measuring free RAM before every part: parts shrink under elevated/critical pressure and grow back at most 2x per step; on MemoryError the part is retried at half size; when not even one item fits it releases memory and WAITS (bounded), then PAUSES with a checkpoint (status paused_low_ram) instead of failing; running again resumes with nothing lost and nothing repeated. Emergency stop saves progress too. Results can stream to a JSONL file so they do not pile up in RAM.
Used by: brain/doc_insight.analyze_many (many files). Existing governor/executor behaviour is unchanged; other heavy jobs can adopt PartitionedRunner one by one.
Proven in the sandbox with a real address-space cap (RLIMIT_AS): 2000 MB of work inside a ~100-260 MB window completed in 12-37 parts while holding everything at once failed with MemoryError; a 300 MB text file was indexed under a 200 MB window where reading it whole failed.
Laptop check: python scripts/ram_selftest.py (writes reports/ram/ram_selftest.json).


## Stage C — memory, self-learning, route planning (+ Stage A/B improvements)

New files (nothing existing was renamed or re-signatured; `executor.run_tool_call` is only *observed* by a signature-preserving wrapper):
- `brain/memory_store.py` — one SQLite+FTS5 file (`logs/memory/goku_memory.db`, env `GOKU_MEMORY_DB`), 19 kinds with their own TTL / half-life, scopes `general | game:<n> | app:<n>`,
  secret redaction before writing, exact + near-duplicate merge (key-aware), count-based confidence x source trust x time decay, `untrusted` flag for file/web/model text,
  `maintenance()` (expiry, compression that never touches trust>=0.8, backup), corruption recovery (quarantine copy kept -> `.bak` -> append-only journal), read-only legacy import, bounded `WorkingMemory`.
- `brain/knowledge_lifecycle.py` — observed -> tested -> approved -> active -> outdated -> retired. Test and approval cannot be skipped (enforced). Versioned JSON packs + `rollback()`.
  User correction outranks everything. Code is never modified (`source_fingerprint()`); code ideas only as `proposals/*.md`.
- `brain/route_planner.py` — route choice from measured RAM/time/success; routes that do not fit free RAM dropped, heavy routes dropped under critical pressure, cooldown after 2 failures per environment,
  no exploration for destructive tasks, `ask_user` always last, honest fallback chain.
- `brain/learning_hooks.py` — wrapper + `memory ...` / `knowledge ...` commands. Learning is ON in normal runs (`GOKU_LEARNING=0` turns it off), OFF under pytest unless `GOKU_LEARNING=1`.
  Only verified successes get high trust. Idle maintenance runs after a command, at most every 15 min, only when RAM pressure is normal; no threads.
- Commands: `memory status | show <text> | forget <id|text> | export`; `knowledge list [state] | test <id> | approve <id> | reject <id> | retire <id> | rollback`.
- Stage A: `brain/doc_extras.py` — verify_quote, retrieve_context, hierarchical_summary, column_stats (csv/xlsx), analyze_corpus, code_graph, Roman Urdu/Urdu stopwords.
- Stage B: `tools/vision/screen_extras.py` — masked + fine-grid diff, UIA/OCR merge by IoU, multi-monitor/DPI, ChangeWatcher (+mark_action), AdaptiveRate, classify_dialog.
- NOT yet wired into the live tools (available as library calls): doc_extras functions and screen_extras functions. The route planner is not yet called by the executor.


### Stage C wiring (added after the first Stage C zip)
- `ScreenUnderstanding` now takes `learner=` and `ignore_regions=`: each observation method (uia/ocr/capture) is timed and recorded per application; a method that failed twice in a row in that application is skipped for 10 minutes (reported in `unavailable_methods`, never silent). Clock/cursor regions can be masked; small changes are re-checked on a finer grid. New state fields: `reanalyze`, `element_conflicts`, `monitor`, dialog `classification`. `mark_action()` makes the last observation unsafe to act on.
- `executor.run_tool_call` wrapper keeps a per-tool window of the last 20 outcomes. After >=3 failures (and more than 2x the verified successes) a failed result gets an extra `memory_hint`; status/message are never changed and nothing is ever blocked. `GOKU_LEARNING_USE=0` switches hints off.
- New commands: `verify quote "..." in <file>`, `column stats <csv|xlsx>`, `code graph <folder|file>`, `corpus <f1> <f2> ...`, `retrieve context <file> <loc>`, `memory health`, `memory advice <tool>`.
- Fixed: multi-file commands only saw the last unquoted path.
- Measured (sandbox): 100,000 records -> search median 1.4 ms, p95 1.8 ms, +3 MB RAM under a 200 MB address-space cap; 20,000 tool calls -> 9 MB database, maintenance expires them in 0.4 s.
- Still not done: single heavy slot in `budget_governor` (kept on purpose: one heavy job at a time is the safe default on 4 GB; a tier-based limit needs its own tests), RAM planner for OCR/screenshot tiling, voice, audio/video, game framework, autonomy/security audit.


## Stage D — game framework and honest rewards
Problem found in the old code: both game loops rewarded "the whole screen got brighter/darker" (`abs(brightness_after - brightness_before) > 4.0 -> HIT`) and
`continuous_learning_loop` returned `status: PASSED` after N trials whatever happened; `run_autonomous_agent` always answered "completed successfully". The verifier and
the truth oracle accepted that (the oracle only checked "foreground window is responsive").

New: `brain/game_framework.py` (pure logic) and `tools/game_adapters.py` (Windows side, everything injectable).
- `RewardJudge`: reward only from verified evidence, strongest first: win/lose text that APPEARED after the action, score change, target mass that really dropped (>=25%, two stable reads, confidence>=0.5).
  Pixel change alone = "no_effect, unverified" and is never learned. A readable measure that did not change = "verified miss" (learned). Unusable observations (perception failed, different window, too far apart) = "unknown".
- `ActionGuard`: only drag/click inside the game window rectangle, key allow-list (win, alt+f4, alt+tab, ctrl+w ... always forbidden), rate limits. A refused action is banned and reported, never clipped into something else.
- `ActionPolicy`: grid search over parameters (angle, power) with UCB + neighbour smoothing; exploration shrinks with verified experience (also from earlier sessions); stats persist per game in the memory store (scope `game:<name>`).
- `GameSession`: bounded loop. Stops (with the reason) on emergency stop (checked every 0.1 s), time limit, critical RAM, game window gone/not in front, user moving the mouse, no perception (never acts blind), input failures, already-finished screen. Final status: WON only after win evidence; PROGRESS / NO_EFFECT / INCONCLUSIVE / LOST / STOPPED_* otherwise.
- `tools/game_engine.py`: `continuous_learning_loop` keeps its signature and messages but now runs through the framework; `trial_memory` rows are HIT / MISS / UNVERIFIED by evidence. Status is `PASSED` only after a verified win.
- `brain/autonomous_agent.py`: brightness no longer counts as a hit; `run_autonomous_agent` returns `PASSED` only when the target verifiably disappeared, otherwise `unverified`.
- `executor/truth_oracle.py`: game tools now use `_post_game_result` (needs `status == PASSED`, `success` and `verified`); `on_fail` is `ask_user` so a whole game is not silently replayed.
- Limits: WON needs readable win text (OCR). On the `tiny` tier OCR is off, so those games can reach PROGRESS at best. Only the slingshot adapter exists; other games need an adapter (observe / build_action / perform). Windows-only parts were tested with stubs, not on a real game.


### Stage D2 (improvements after the first Stage D zip)
- The result is read only after the shot has played out: after the minimum settle time the session polls the adapter's `activity_now()` until the screen is calm twice in a row (bounded by `GOKU_GAME_MAX_SETTLE`, default 8 s, emergency-stop aware). Without this a flying bird was read as "no effect" and a false miss was learned.
- `parse_score(texts)`: a score is taken from OCR text only when it literally says "score"; the judge then uses score changes as evidence.
- `dry_run=True`: observe, choose and guard-check actions, send nothing, learn nothing; status `DRY_RUN`.

## Stage E - security, autonomy, spec coverage

Added (new files): `security/policy.py`, `security/redact.py`, `security/audit_chain.py`, `security/untrusted.py`, `security/static_audit.py`,
`brain/task_manager.py`, `scripts/security_audit.py`, `scripts/spec_coverage.py`, `docs/spec_coverage.json`, `docs/SPEC_COVERAGE.md`,
`tests/test_stageE_security.py`, `tests/test_stageE_tasks.py`. Backups of edited files: `backups/StageE`.

Edited (additive, signatures unchanged): `executor/executor.py` (hard block level `blocked_by_policy`, not bypassable by confirmed=True; audit records),
`security/confirm.py` (`is_allowed` also asks the argument-aware policy for the confirm level), `brain/doc_insight.py` (`security` key + SECURITY line in the report),
`brain/task_agent.py` (`task ...` commands).

Policy levels: allow / confirm / block, decided from the tool name AND its arguments. Block: system paths, download-and-execute / encoded commands, disk-destroying commands,
Ctrl+Alt+Del, file:/javascript: URLs, unknown tools. Confirm: delete, overwrite, install/uninstall, registry, power, services, scheduled tasks, purchases/payments,
programs from Downloads/Temp, credential stores, Win+R, executable downloads. If the policy itself errors, high-impact tools fall back to confirm (fail closed).

Task manager: steps run through the normal executor; a step is done only when success AND verified; unverified steps are never repeated and their dependants are skipped;
confirmation is never automatic; non-user origins (file/web/screen) need confirmation for state-changing steps; the GUI is owned by one task at a time; crash recovery marks
running tasks "interrupted" and resume() skips finished steps; no thread unless start_background() and it exits when idle.
Commands: `task list|status <id>|pause <id>|resume <id>|cancel <id>|confirm <id> [yes|no]|report <id>|run`.

Known limits: tool risk_level audit needs the real registry (Windows deps) so it reports "skipped" on Linux; older log writers are not yet redacted (the audit lists them);
no recurring/time-based schedule (would need a timer); voice, reset/uninstall command and versioned config are not built.

## Stage E2 - question answering, scenario bank, honest abstention

New: `brain/answer_engine.py`, `knowledge/core_facts.json` (+ `scripts/build_core_facts.py`), `scripts/scenario_bank.py` (1140 generated cases + judge),
`scripts/heldout_cases.py`, `scripts/heldout_cases_v2.py` (hand-written, not generated), `tests/test_stageE2_answer.py`.
Edited: `brain/task_agent.py` (routes `remember ...`, `ask ...`; implicit verified answers for question-like text; the calc route now asks the engine first),
`security/policy.py` (the `at <n>` scheduler pattern is anchored so "3 notebooks at 45" is not a command).

What it is: an orchestrator, not a bigger model. Solvers in order: safety, passage (instruction-like sentences dropped), clock/dates, maths (word operators, number words, units,
percent, stats, equations, geometry basics; a "all numbers consumed" guard), your own stored notes, the shipped read-only knowledge pack, real-time -> needs_web. If nothing is
sure the answer is "unknown"; an LLM answer is only ever returned if a callable is passed and is labelled unverified. Nothing loads a model; ~ms per question.

Bugs found and fixed by the baseline run: "7 squared plus 3" answered 49 (silently dropped "plus 3"); "kitne din bache 2026-12-25 tak" answered 1989 (date read as subtraction);
a fuzzy fact match answered "8 planets" for "largest planet"; "3 hours 30 minutes in minutes" answered 30.

Measured (sandbox, no LLM): bank 1140 cases: old path 545 pass / 69 wrong / 526 unhandled -> engine 1140 / 0 / 0. The bank was written by the same person as the solvers, so this
number is inflated. Held-out v1 (76 hand-written): first run 49 pass, ~6 confidently wrong; after fixes 72 pass, 0 wrong (tuned on it). Held-out v2 (56, written after, run once
before any tuning): 47 pass first run, 0 truly wrong (1 flagged item was a wrong expectation of mine); after fixes 55 pass. Realistic first-contact accuracy: roughly 65-85% on
questions of these kinds, with the rest answered "unknown", not guessed.

Limits: open-ended questions ("explain photosynthesis", stories, advice) have no verified source offline; word problems ("3 notebooks at 45 each and a pen for 20") are not solved
(honest "unknown"); the pack is small; web search is only a hook (`web_fn`) and is untested here; Roman Urdu is pattern based, not understood.

## Stage F - RAM strategy (20 techniques)
- `tools/resource_strategy.py`: `decide(Situation)` -> per-technique decision (use/skip, reason, estimated MB saved), knobs for Ollama options, server env, isolation, screenshot size, cache TTL, workload mode. `render(plan)` prints the table.
- Numbers are ESTIMATES from model architecture; `scripts/model_bench.py` writes `logs/model_bench.json` and measured rows override estimates. Flash attention / KV-cache quantisation are used only if verified AND the saving >= 25 MB (for qwen2.5:0.5b at ctx 1024 they save ~3-9 MB, so they are skipped).
- Biggest estimated win for the 0.5B model: batch 64 instead of Ollama's 512 (logits buffer ~vocab x batch x 4 B, ~300 MB). Unverified until benchmarked.
- `tools/isolated.py::run_isolated` runs a heavy function in a child process (technique 10).
- Wiring (additive, fail-soft, env `GOKU_RESOURCE_STRATEGY`, off under pytest): `brain/llm._call_ollama` only tightens ctx/batch, sets use_mlock=false, may refuse when memory does not fit; `brain/ollama_manager.start_ollama_service` passes NUM_PARALLEL=1 / MAX_LOADED_MODELS=1 (+ verified flash/KV) only to a server GOKU starts.
- Backups: `backups/StageF`. Tests: `tests/test_stageF_resources.py` (16).

## Stage F2 - Capability planner, pending queue, idle reclaim
- `brain/capability_catalog.py`: techniques 21-120 with honest status (built / partial / planned / scale_up / external) and the kinds of work (chat, big files, PDF, OCR, games light/3D/heavy, video, voice, LLM sizes, training) with ESTIMATED memory.
- `brain/capability_planner.py`: read-only `scan_system()`; `evaluate(work, size_mb)` -> run_now | run_in_pieces | pending (exact resume condition) | impossible_here (with numbers, ranked options, close-app suggestions that only the user can act on; protected system processes never suggested); `PendingQueue` (persistent, timeline: received/deferred/ready/started/interrupted/resumed/completed, crash recovery, checkpoint progress); `resume_check()` is called at natural moments, no thread/timer; `reclaim()` = checkpoint first, then unload model / gc / trim, GOKU's own memory only.
- Piece size = min(tier cap, 5% of usable RAM): 10 MB on tiny (1 GB -> ~103 pieces), 64 MB on large. 1 GB / 10 MB is 100 pieces, not 100,000.
- GOKU's own per-tier ceiling (tiny 1100 MB) is respected: a 3B model is "impossible here" on tiny even if RAM is free, and unlocks automatically on a stronger tier. No code edit when moving to a high-end PC.
- Commands: `system scan`, `capabilities`, `plan <work> [size]`, `pending [list|check|report <id>|cancel <id>]`. `task run` now ends with reclaim (off under pytest / GOKU_RESOURCE_STRATEGY=0).
- Never kills/suspends processes or touches Windows files (tested statically). Backups: `backups/StageF` (task_agent, task_manager too).
- Tests: `tests/test_stageF2_planner.py`.

## Stage F3 - Scheduler, piece runner, calibration, laptop validation
- `brain/piece_runner.py`: big files in natural-boundary pieces (blank line > newline > space, never inside a UTF-8 char) with 10% overlap context; one piece in memory; per-piece results appended to a JSONL on disk; checkpoint after every piece (resume at the exact byte); RAM guard + stop flag per piece; VERIFIED only if piece cores cover the file contiguously. Built-in `file_profile_piece` + `merge_profile` (bytes/lines/words/duplicate pieces/headings).
- `brain/work_scheduler.py`: strictly one job at a time; re-scan before every job; pending jobs do not block others; impossible jobs skip their dependants; done only when ok AND verified; runner exception contained; after each job GOKU's own memory is released; interrupted jobs resume from the saved checkpoint, and file jobs rebuild their runner from persisted params after a restart.
- `brain/capability_planner.py`: unique job ids (a same-millisecond id collision was found and fixed by the new tests), `params` stored with every job, `load_calibration()`/`effective_kind()` so numbers measured on the real laptop replace estimates (`logs/calibration.json`), commands `work file <path>`, `work run`, `work status`.
- `scripts/laptop_validate.py`: run on the laptop. Measures piece-runner peak memory and speed, process isolation, reclaim, solver speed, GOKU tree vs ceiling; writes `logs/laptop_validation.json` and `logs/calibration.json`. `scripts/simulate_schedule.py`: what the planner decides on any hardware.
- Measured in the sandbox (Linux, NOT the user's laptop): a 16 MB piece costs about 53 MB peak (3.3x piece size) after removing copies (memoryview slices, line-by-line counting; before: 86 MB). On the 4 GB tier pieces are 10 MB, so about 35 MB.
- Tests: `tests/test_stageF3_scheduler.py` (16): coverage with unicode, flat memory on a 120 MB file, resume equals single run, RAM drop + restart, crash recovery, stop flag, dependencies, strong-PC profiles, calibration, no kill/delete in code.

## Stage F4 - control layer + document index
- `brain/feature_switches.py`: every feature with ON/OFF, switchable or LOCKED (security policy, audit log, verify-before-done, RAM headroom/ceiling, checkpoints, protected processes, one heavy job, honest 'unknown'), memory cost, and what stops when off. `features`, `feature off|on <id>`, `feature compare off <id> ...` (before/after). A job whose feature is off waits with the reason.
- `brain/presence.py`: user states hold > away > idle > active from the user's words (`presence away [for 2h] [note]`, `hold`, `back`, `status`), Windows idle time (on demand) and network rate (download >= 0.5 MB/s). Background heavy work waits while the user is active or a download runs; nothing sends input while away; hold blocks everything non-read-only. History keeps when the user left / returned. Work typed by the user right now is only blocked by hold.
- Trial run (`make_trial_adapt` in `brain/piece_runner.py`): the first pieces are measured for real; if one grows the process beyond the budget the piece size shrinks (and stays shrunk after a resume).
- `brain/advisor.py`: `advise <work> [size]` - side-by-side options (now / in pieces / after YOU close apps / wait / lighter / strong PC), each calculated on a copy of the machine state, with features ON/OFF and the steps.
- `brain/doc_index.py` (catalog 43-55, 114, 116): streaming SQLite index (paragraph units, FTS5, headings, refs, claims, terms). `doc index|outline|ask|summary|dups|contradictions|missing|refs|tables|symbols <path> [:: question]`. Resumable, incremental, fingerprint skip, verify against the original file. Contradictions are possible-only (heuristic). Binary files refused.
- Tests: `tests/test_stageF4_control.py` (17), `tests/test_stageF4_docs.py` (11). Backups: `backups/StageF4`.
- Known limits: heuristics for headings/claims are rule-based (English/Urdu text), tables only in pipe/tab/CSV form, PDF pages need the PDF tools, Windows idle/network probes not yet seen on a real laptop.

## Stage F5 - answer intelligence (techniques 22, 27, 30, 31, 33, 35-39, 82, 107, 108, 110)
- New: brain/answer_pipeline.py (resolve -> decompose -> solve -> cross-check -> label -> remember), dialog_state.py, decompose.py,
  wordproblem.py, constraints.py, symbolic.py, source_check.py, fact_versions.py, regression_log.py, structured_output.py.
- Commands: `wrong: <correct answer>` / `galat:`, `fact history <key>`, `regressions run|promote`, `dialog show|clear`.
- Honest limits: solvers are conservative rule engines (they refuse rather than guess); labels are verified/likely/needs_internet/unknown;
  memory-vs-pack conflict detection is heuristic (numbers, negation, one differing word in the same sentence frame);
  structured-output constraining is off unless GOKU_CONSTRAIN_OUTPUT=1; nothing here edits source code (regression_log only writes logs/ test file).
- Tests: tests/test_stageF5_intelligence.py. Full-suite regression equals base (2 sandbox-only failures).

## Stage F6 - acceptance fixes from the ChatGPT 12-level test, SEO workflow, lesson store
- Found by running the user's real test questions: plain typed questions never reached the answer pipeline (only `ask ...` did); some answers were WRONG
  ("25% of 800, then add 100" -> 640; "Ali and Omar are both taller" -> "Both"), compound questions silently dropped a part, no identity/greeting/definitions.
- New: brain/stepchain.py (exact multi-step chains, English + Roman Urdu), brain/conversation.py (statements, versioned facts, contradictions, recall of earlier answers,
  "wrong, the answer is 86" is checked against an exact recompute, saved passage for follow-up questions), brain/offline_skills.py (identity, greeting, no-access and future
  honesty, nth prime, code templates that are executed against a self-test, budget, RAM feasibility, safe troubleshooting plans, desktop hand-off that never fakes success),
  knowledge pack core-2 (+30 definitions/differences), brain/seo_workflow.py, brain/lesson_store.py.
- task_agent.try_handle now sends ordinary questions/statements through answer_pipeline (unknown / commands still fall through to the model and the desktop router).
- Commands: `seo run <file>`, `seo status`, `seo show`, `seo approve`; `lessons list`.
- SEO workflow: 12 stages from ONE instruction, each saved to logs/seo_jobs/<name>/stageNN_*.json, resumable; competitor/keyword-volume data only with internet (otherwise the
  stage is `blocked` with the reason); WordPress draft only, publish only after `seo approve`, then re-read + open the public URL to verify. Needs GOKU_WP_URL,
  GOKU_WP_USER, GOKU_WP_APP_PASSWORD (Application Password). Yoast/RankMath fields are NOT written or verified.
- Lesson store: hypothesis -> verified (measured improvement + evidence) -> reusable (worked in 2 contexts); must-not-apply is mandatory; transfer_report separates
  "remembered" from "demonstrated".
- Tests: test_stageF6_acceptance (all Level 1-12 questions), test_stageF6_seo, test_stageF6_lessons. scripts/heldout_cases.py: two "unknown topic" cases moved to topics
  still outside the pack. tests/test_budget_governor.py: one test now sets NORMAL mode (the module default IDLE refuses heavy work by design) - found by a proper full-suite
  comparison; this failure was already present since stage E.
- Regression method note: earlier "SAME_AS_BASE" checks compared only collection errors; the proper comparison (full run with --continue-on-collection-errors on base vs build) shows
  base 473 sandbox failures (win32 stubs) and the build had 3 extra, all fixed/explained above.
- Honest limits: desktop actions (open Notepad, folders, active window) and the real LLM were not run here (no Windows, no Ollama); the SEO flow was tested against a mock WordPress.

## Stage F7 - execution trace, route planning with RAM gate, downloads, translation, screen watching

Goal: make the task layer honest and capable-aware. If this machine cannot do a task now (no internet, too little free RAM,
tool missing) the task is NOT attempted and NOT faked: it is kept PENDING with a `resume_when` condition and runs when the
machine is capable.

* `brain/execution_trace.py` - `Trace`: 15-field Individual Test Report; unmeasured values print `NOT MEASURED`;
  `PASS` is downgraded to `PARTIAL` unless at least one independent verification passed and none failed.
* `brain/task_route_planner.py` (NOT `route_planner.py`, which is the Stage C learned-route module) - parse intent
  (download / move / copy / rename / download_then_move / search / scroll / watch / payment ...), candidate routes with RAM cost,
  route choice + reason, RAM gate (150 MB headroom), pending queue (`PendingTasks`, `plan_or_queue`, `capable_now`),
  7-point explanation for unsupported tasks, `run()` for file intents with post-condition checks (exists, size, sha256, source gone).
  No overwrite unless confirmed. When two files share a name and one sits in the destination folder, the other is the source.
* `tools/download.py` `download_file` (+ truth-oracle contract `_post_download_file`, `config/tool_ram.json` entry, mutative list).
  Private/local addresses blocked unless `GOKU_ALLOW_LOCAL_DOWNLOAD=1` (tests only).
* `brain/translate.py` phrasebook first, LLM only if given and only accepted when numbers/names are preserved; unverified otherwise.
* `brain/screen_watch.py` changed-frame watcher with backoff and session cap, observe-only, `StaleGuard`, `scroll_search`, `watch_file`.
* `brain/chat_gate.py` draft -> approval -> send; editing a draft removes the approval; no double send.
* `scripts/department_tests.py` - departments A-L; runnable ones are executed here, live ones are listed as NEEDS_LAPTOP and never counted as passed.
* Bugs found by the new tests and fixed: sub-folder dropped ("Desktop ke GOKU_Test folder"), filename polluted by "ka naam",
  same-name file at destination confused with source, low RAM chose manual guide instead of pending, and a module-name collision
  that had overwritten the Stage C `route_planner.py` (restored).
* Not proven (needs the laptop): real Chrome/desktop control, real screen capture, real RAM/network probes, live LLM, real WordPress.

## Stage F8 - ChatGPT F7 benchmark items that can be proven without Windows/accounts

Source: ChatGPT's "F7 ultra-detailed capability audit" (browser, YouTube, WhatsApp, X, streaks, long tasks, screen loops, translation,
content preservation, capability decisions, route calculations, learning, notifications). Everything below is rule based and unit tested;
nothing here proves a real account, real browser or real screen works.

* `brain/capability_status.py` - every "can you ...?" returns a status (CAPABLE / PARTIALLY_CAPABLE / NOT_CAPABLE / NEEDS_PERMISSION /
  NEEDS_CONNECTION / NEEDS_RESOURCE / PENDING / BLOCKED) AND a reason code (MISSING_TOOL, LOW_RAM, LOW_DISK, NO_NETWORK, LOGIN_REQUIRED,
  MACHINE_MUST_BE_ON, ...). Disk/RAM answers are arithmetic on the numbers in the question.
* `brain/task_understanding.py` - ordered steps, `must_not_change` copied word for word, stay-on-same-page constraints, irreversible actions,
  approval need, evidence needed, feasibility; plus honest policy answers (download vs install, original page, lighting only, partial
  work, two routes, stale screenshot, click succeeded but screen unchanged).
* `brain/action_gate.py` - approval for post/DM/follow/send/call/install/delete/payment; "kar do" is not a final confirmation; refuses mass
  messaging, CAPTCHA/OTP bypass and password requests; accounts only by exact handle (look-alikes -> ask).
* `brain/msg_split.py` - sentence-boundary splitting with "Part i/N", counts in code points / UTF-16 / bytes, reconstruction + missing-sentence
  proof, platform limit "NOT VERIFIED" unless confirmed; `SendLedger` makes sending idempotent (a dropped connection stops instead of resending).
* `brain/recurring_tasks.py` - saved schedules (daily/weekly/except-day/once, timezone flagged when assumed), due/missed detection, one run per
  slot, wording hash, skip day, stop, replace, expiry, anti-spam limits, stale messages never sent late. It runs only while the PC is on;
  it never claims machine-off execution.
* `brain/task_notify.py` - PENDING/BLOCKED/FAILED/PARTIAL/COMPLETED saved with timestamp+reason BEFORE a notification exists; COMPLETED needs
  a passed verification; resume needs the condition AND the user's permission.
* `brain/watch_verify.py` - playback log -> measured playing/paused/buffering/frozen seconds (a frozen "playing" player is not watch time),
  verify_playback, exact title+channel result choice (no substitute video), ClickGuard (success = screen changed as expected, bounded retries).
* `brain/content_diff.py` - heading/word/link/number/sentence/keyword/readability comparison with a PRESERVED / SCOPE_EXCEEDED verdict.
* `brain/translate.py` - `translate_instruction` / `restrictions_preserved`: negations, "only", verbs, numbers survive translation; unknown clauses are
  reported, not guessed.
* task_agent routes: capability questions, policy questions, `understand:`, `gate:`, `schedule add|list|stop`, `content compare A and B` (the older `compare "A" and "B"` file-similarity route is untouched), long-text splitting.
* Not proven (needs laptop/accounts): real Chrome/YouTube/WhatsApp/X, screen observation loop, notifications delivery, scheduler running
  across sleep/restart, real LLM, real WordPress.


## Stage F9 - QA mind (10-point question answering)
Pipeline: Understanding (language, N points, level, question type, concepts, follow-up kind) -> critical thinking (false premise / misconception / wrong capital / wrong attribute challenged BEFORE any solver) -> exact reasoning (brain/qa_logic.py: syllogisms incl. affirming-the-consequent, bat-and-ball, rate and doubling traps) -> compose from knowledge (knowledge/concepts.json 60 concepts, reasoning_rules.json whys/procedures/misconceptions) -> optional model draft, always labelled `llm_unverified` and rejected on invented URLs/studies/numbers/self-contradiction/sample disagreement -> verify and self-correct (arithmetic recomputed, N-points repaired, never padded) -> honest "unknown" with closest known topics.
Fixes from the ChatGPT audit: "And what about Italy?" follow-up bug (dialog_state `_PREV_TOPIC`), LLM now receives conversation history through the one pipeline, `or True` assertions removed (this exposed a real bug: an approval-pending scheduled message slot was lost on the next run_due - fixed in recurring_tasks).
Tiers (GOKU_QA_TIER or RAM): tiny(1 GB) 1 model call, 4-turn history; small; medium 2 samples; large(16/32 GB) 3 samples + critique pass, 16-turn history. Packs are ~40 KB and loaded lazily.
Benchmark: scripts/qa_score.py, 68 items by the 10 dimensions, dev 33 + held-out 35. F8: dev 21.2%, held-out 17.1%. F9 first run: dev 84.8%, held-out 62.9%; after fixing the failures found: 100% / 100%. SAME AUTHOR as the code, fake LLMs only: a regression/honesty benchmark, NOT an independent score. Real Ollama answer quality, Urdu script beyond a small word map, and knowledge outside the 60 concepts are not measured/covered.

## Stage F10 - live-task contracts, long commands, RAM-pending queue, feedback loop
New: brain/long_command.py (1,200+ word command -> requirement ledger, conflicts, updates, plan, coverage, resume), brain/live_task_specs.py (YouTube, download+install, wallpaper, Shopify blog, video colour scan, image inspect: steps, needs, approvals, RAM full/reduced, status PASS/UNVERIFIED/PARTIAL/UNSUPPORTED/BLOCKED/NOT_TESTED), brain/ram_queue.py (task that does not fit free RAM waits in a persistent PENDING queue, admitted when RAM frees; never fits -> unsupported_on_this_hardware), brain/blog_seo.py (exact meta counts, suggestion from blog words only, OEM matching exact/probable/ambiguous/unmatched, independent re-verification), tools/video_color_scan.py (streamed one frame at a time, SAMPLED coverage, RGB/HEX + bbox, unidentified-colour timestamps), brain/feedback_fix.py (10-point correction report, one-time vs permanent PROPOSAL, 5 memory layers, unverified never becomes verified knowledge). Commands: `preflight: <task>`, `ledger: <long command>`, `scan video colors: <file>`. Question pack: docs/LIVE_AUDIT_QUESTIONS.md (17 topics, 125 questions).
HONEST LIMITS: nothing here drives a real Windows PC, Chrome, YouTube, Shopify or the installer. The specs are contracts the live run must satisfy; best offline status is NOT_TESTED. Video scan was tested on a synthetic ffmpeg clip only.

## Stage F11 - roadmap build (orchestrator, scheduler, recovery, perception, workflows)
New: `brain/orchestrator.py` (preflight states, COMPLETED only with independent evidence, audit log), `brain/ram_scheduler.py` (light task runs while heavy is
queued, pause only at checkpoints, no double execution, free RAM never authorises a public action), `brain/recovery.py` (15 failure categories; an uncertain
external action is never retried until a read-back proves it did not happen), `brain/screen_state.py` (fresh-state action loop), `tools/video_audit.py`
(black/frozen/silence/clipping/cuts with honest coverage, correction to a NEW file with approval, re-verification), `tools/image_audit.py`,
`brain/social_prep.py` (validation, preview, approval gate, published read-back), `brain/install_plan.py` (download and install need separate approvals),
`brain/blog_seo.py` (audit, publish compare), `brain/feedback_fix.py` (11 feedback classes, 7 memory types), `brain/long_command.py` (schema 2, safe save),
`brain/f11_commands.py` + routes in `task_agent.py`. Matrix: `scripts/capability_matrix.py` -> `docs/CAPABILITY_MATRIX.{md,json,html}`, `evidence/matrix/*.json`.
Guidance probe: `scripts/guidance_probe.py` (18 capabilities x 3 phrasings; F8 3/18, F9 4/18, F10 6/18, F11 18/18 without guidance).
Fixes found by the probe/matrix: "pending tasks" exact phrase stays on the old route; translate/explain/show-features phrasings; qa honest unknown.
Honest limits: nothing was run on real Windows/Chrome/YouTube/Shopify/installers/accounts - every live-claiming capability is capped at YELLOW until
`evidence/live/<id>.json` exists. Video audit does NOT perform face/hand/lip-sync/subtitle OCR. Platform limits are a recalled snapshot (verified_live False).
Benchmarks are self-authored. `brain/action_machine.py` is an unwired earlier draft (RED in the matrix), superseded by orchestrator + recovery.

## Stage F12 - gap closure from the F11 audit (ChatGPT blueprint + gap list)
Decisions locked without questions: the 1.1 GB budget applies to GOKU's whole process tree (own + children incl. browser/Ollama GOKU started); independent processes and system
free RAM are reported as separate numbers; higher-RAM modes are automatic tiers (`brain/ram_profiles.py`) but stay PROPOSED_NOT_MEASURED until measured and never relax approvals;
existing designs are improved, not remade; `action_machine` is retired (SUPERSEDED).
New: `brain/verifier.py` (independent verifiers, each with a good + mutated sample test), `tools/process_tree.py`, `brain/ram_profiles.py`, `tools/live_observer.py` (UIA+OCR cross-check),
`brain/f12_commands.py` (my tier, ram budget, emergency stop, safe state, install plan, schedule, verify, screen observer, evidence status), `scripts/live_evidence.py` (Windows only, writes
evidence/live/<id>.json only for PASS), `scripts/guidance_heldout.py` (held-out benchmark with false-action rate), `scripts/build_solutions.py` -> docs/F12_SOLUTIONS.md (options + 5 further points per capability).
Bugs found by the new tests and fixed: "why is the capital of Australia Sydney?" was answered "country not in pack" (false premise now challenged); tier phrasings were unrouted; live observer did not merge
UIA+OCR sources; verifier false-flagged an honest video claim.
Matrix statuses: PASS_INTEGRATION (green), PASS_OFFLINE_LIVE_PENDING (every offline criterion met; only real Windows/account proof missing), PASS_OFFLINE_GAPS, FAIL, SUPERSEDED.
Honest limits: the 7 live-claiming rows (screen_vision, screen_loop, game_framework, download, shopify_seo_oem, social_prep, install_policy) cannot be green without evidence/live files from
scripts/live_evidence.py on your PC. Matrix criteria are partly keyword-mapped from test names (documented in scripts/capability_matrix.py). The held-out set is self-authored.

### F12 inspection round (after the first matrix)
The first F12 matrix said 32 green; inspection showed that was inflated (keyword-matching of free-form test names, and several weak assertions such as "result is not None").
Fixes: criteria 5/6/11/12/13 are now STRICT - a passing test named `test_<rowid>_<kind>_...` or an explicit entry in `COVERS` (scripts/capability_matrix.py, reviewable) is required;
parametrised tests count only when every case passes. Weak tests were rewritten with real assertions, which exposed real gaps that are now fixed: reasoning did not ask for missing details
("Book a flight") nor catch "red / not red"; route-planner test used invalid route names; translation had a tiny phrasebook (now clauses, `mat karo` negation with correct word order, `abhi`, names, "Ali's file";
gibberish -> unclear_language; unknown words -> unsupported); public requests like "publish this blog post" returned nothing (now an honest gated "Not done" with the safe next step, without hijacking delete/install or questions).
Result under the strict rules: 32 green, 7 yellow = only the real-Windows/account proof missing (screen_vision, screen_loop, game_framework, download, shopify_seo_oem, social_prep, install_policy).

## F13 (roadmap wave 1)
New, each with real-tool tests (tests/test_stageF13_*.py):
- brain/capability_health.py: component-level health per capability (PASS/ALTERNATIVE_PASS/PARTIAL/UNVERIFIED/BLOCKED/NOT_POSSIBLE/NOT_IMPLEMENTED). A missing required part (e.g. OCR) keeps the whole capability non-green; only the ask-the-user route = PARTIAL. Windows-only parts are UNVERIFIED on Linux. Command: `capability health [name]`.
- brain/admission.py (on RamQueue): run if RAM allows, else persisted PENDING and auto-resumed; unsupported/unmeasurable/missing-handler are kept visible, never dropped. Command: `ram queue`.
- tools/scan_ocr.py: scanned-PDF OCR with page refs (pdftoppm+tesseract), image OCR with boxes/confidence, burned-in video subtitle OCR (frame sampling, polarity fix), embedded subtitle tracks. Low confidence = UNVERIFIED. Command: `ocr: <path>`.
- tools/detectors.py: face/hand/head/lip-sync/object interface; NOT_POSSIBLE until a detector is plugged in (no model ships).
- tools/download_robust.py: Range resume, backoff, SHA-256/512, magic-byte/MIME check, redirect policy, history. Tested on a LOCAL server only - not internet evidence.
- tools/watchdog.py: timeout/heartbeat + process-tree kill (Linux-tested).
- tools/win_measure.py + scripts/laptop_measure.py: idle (GetLastInputInfo), Job Object limit, hardware measurement - UNVERIFIED until run on the Windows laptop.
- tools/readback.py: file/process/http read-back, retry policy (retry only when read-back proves it did not happen), state export/import with HMAC integrity (NOT encryption).
Still open: real Windows/account proof for the 7 live rows, shopify CSV fallback, detectors/models, translation/calculator/QA expansion, voice, game adapters.

## F14 (brain: contract, multi-route search, executor, timeline)
- brain/task_contract.py turns a command into a contract (item type, exact title/year/format/quality, size/duration/pages bounds, legal flag, success criteria). `check_item` decides MATCH / WRONG_ITEM / UNVERIFIED from real file facts; a generic file name is UNVERIFIED, never a guessed match; language cannot be measured and is reported, not checked. Limits: regex/heuristic extraction, no human-labelled phrasing set yet; the piracy-domain list is incomplete.
- brain/cap_registry.py + brain/route_search.py: every capability declares needs/provides; the best-first search finds all minimal plans, scores them (learned success, time, peak RAM, risk, approvals, handlers present), applies legal/user policy, keeps RAM-short plans as PENDING and explains "would work if you ..." for missing environment. Limits: success priors are estimates until outcomes accumulate; web/page handlers are built in F15, so those routes are listed as not executable.
- brain/route_executor.py runs the ranked plans through the existing Orchestrator (independent verifiers, approvals denied by default), falls back to the next plan, quarantines a wrong file in `_rejected` (never deletes), feeds outcomes back, turns RAM-short work into a persistent pending task. Limits: proved on a local HTTP server and real files; real websites need live evidence; GUI steps go through the old desktop handoff and fail honestly.
- brain/timeline.py records what was done and why. Commands: `plan task: ...`, `do task: ...`, `timeline`, `idle status`, `measure hardware`; natural "download <title> movie/book" now goes to the executor.
- Inspection round fixes (found by running, not assumed): watchdog pipe deadlock with chatty children; redirect-refused reported as http_error; "3 Idiots" lost its number; known piracy domains; pending task not resumable in a fresh process; generic file name wrongly WRONG_ITEM; author text inside the title breaking title_match.

## Stage F14b - real-task fixes (found by scripts/real_task_suite.py, not by unit tests)
User's real commands failed although unit tests were green. `scripts/real_task_suite.py` now runs ~25 real commands through the real
input path (try_handle -> handle_command) and checks the RESULT from outside (process / file / word count / reply). Verdicts: PASS,
FAIL_HONEST (said it failed), FALSE_SUCCESS (claimed ok, check failed), UNVERIFIED.
Fixed: `brain/f15_tasks.py` (mkdir, summarise_file, download_to with legal policy + disk check, recall_fact incl. naam/umar synonyms,
code_request not hijacked by definitions), `brain/f15_blog.py` (blog_write: research -> draft -> verify -> save; no filler, no invented numbers;
honest "facts nahi" when sources missing), `brain/f15_text.py` (read_any, extractive summary), task_agent route(): paths/quoted names never
reach calc, calc guard returns None for word sentences. GOKU_MODE='dev' (default) blocks LLM/GUI/screenshots: replies now say `set GOKU_MODE=run`.

## Stage F15 - skill injection (104 expert packs -> GOKU)
Source: GOKU_ALL_SKILLS (27 main + 77 gamedev .skill packs) built from the repos the user supplied (humanizer, ui-ux-pro-max, impeccable,
hallmark, diagram-design, last30days, Scrapling, hypit, REA, ponytail, business-os, awesome-gamedev, onyx...). `scripts/build_skill_library.py`
unpacks them as TEXT ONLY into `knowledge/skills/<group>/<name>/` (+ index.json). Pack text is third-party data: `brain/skill_engine.py`
retrieves (BM25) and injection-scans it; scripts inside packs are never run. A 0.5B model cannot read an 85 KB skill, so skills work as
manuals + deterministic tools:
- `brain/skill_engine.py` - skill list/find/show/plan/status; status EXECUTABLE_LOCAL / NEEDS_PROVIDER / KNOWLEDGE_ONLY / RESTRICTED (REA: own/authorised software only, never cracks/DRM/anti-cheat bypass).
- `brain/humanize_check.py` - AI-writing detector built from the humanizer skill's own watch lists + safe fixes; used by `brain/f15_blog.py` verification.
- `brain/design_search.py` - offline search/brief over the ui-ux-pro-max CSVs; every colour/font comes from a data row.
- `brain/design_lint.py` - HTML accessibility/legibility/placeholder lint.
- `brain/diagram_svg.py` - flow/sequence/timeline SVG with self-check (cycle-safe layout).
- `brain/web_fetch_routes.py` - fetch alternatives: urllib -> scrapling.Fetcher -> (optional) browser; CAPTCHA/login/paywall are reported, never bypassed; robots.txt honoured.
- `brain/recent_research.py` - Hacker News + Reddit public JSON; keyed sources are NEEDS_KEY.
- `brain/f15_tasks.py` routes: `skill ...`, `design search|brief|lint`, `humanize check|fix`, `diagram: ...`, `research recent ...`, `fetch page <url>`, and build requests ("landing page banao", "tower defense game banao") -> playbook + data brief.
Honest limits: retrieval is keyword-based; 91 skills are knowledge-only; hypit/image-generation/onyx need providers; scrapling browser mode and live web
sources need the real laptop/internet; nothing here proves taste - judge outputs yourself.

## Stage F15B - intake, ladder, repo audit
- brain/skill_intake.py: `skill intake "<zip|folder>" [adopt]`. Scans read-only (zip-slip and zip-bomb guards, nested .skill bundles), reports licence, third-party/heavy dependencies, dangerous patterns, prompt-injection-like text, classification KNOWLEDGE_ONLY / EXECUTABLE_LOCAL / NEEDS_PROVIDER / RESTRICTED / BLOCKED. `adopt` copies text only; BLOCKED/RESTRICTED packs keep documents but never code (evidence in data/quarantine). Limits: static scan, regex rules can false-positive (Scrapling constants.py) or miss; third-party text is data, never instructions.
- brain/ladder.py: `ladder status`. L0 deterministic, L1/L2/L3 chosen from installed Ollama models by parameter size (embedding models ignored). A tier is climbed only when the independent verifier fails; the cheapest passing tier is remembered (data/ladder_history.json); every attempt records measured RAM/GPU (data/resource_records.jsonl). GOKU_MODE=dev still blocks model calls. Limits: proven against a fake Ollama only; real quality and GPU/RAM numbers come from the user's laptop.
- scripts/repo_audit.py (read-only): syntax of every .py, import graph, unreferenced modules, duplicate basenames and function bodies, stray root files -> data/repo_audit.json.
- Audit result (this tree): no syntax errors after BOM strip in tests/stage1_reasoning_eval.py and tests/proactive_reasoning_benchmark.py; history check across stage..F15 shows no file lost except brain/action_machine.py, retired on purpose in F12 (retired/action_machine.py.txt). Orphans kept unchanged because tests or tool discovery still reference them: brain/autonomous_trainer.py, brain/tiered_actuator.py, executor/adaptive_replanner.py, executor/ledger_generator.py (no production caller, no test); executor/registry.py (shim). Duplicate names executor/verifier vs brain/verifier, executor/recovery vs brain/recovery, executor/registry vs tools/registry have different roles (step observation vs claim verification) and are all imported, so none was merged.


## Stage F15C - failing/yellow/red items fixed by root cause (honest status)

Each fix below is pinned by `tests/test_stageF15c_fixes.py`. Results marked SIMULATED used `tests/sim_windows.py` (a fake app catalog, only when
not on Windows). SIMULATED passes are logic proof only, never real-Windows proof.

| Root cause | Fix | Files |
|---|---|---|
| `EntityType`/`TypedEntity` defined twice (context.py shadowed context_models.py) so enum `==` was False across modules | single definition (context_models) | command_layer/context.py |
| "isko kholo / open it" re-classified resolved text, so a file named Chrome.txt launched Chrome | `_launch_by_reference` binds to the most recent entity of its own type (app/file/folder) | command_layer/router_classifier_core.py |
| "Chrome kholo... nahi Edge open karo" reached later classifiers uncorrected (opened the abandoned half) | self-repair applied after the safety classifier; bare "A kholo nahi B kholo" recognised | router_classifier_core.py, semantic_helpers.py |
| "ping google.com" opened the website | domain navigation skipped for ping/latency/traceroute/nslookup | router_classifier_special1.py |
| 17 undefined names (NameError at runtime): Path, urllib, agent_state, get_canonical_app_name, RiskLevel, tempfile, step_idx, ... | imports/variables fixed (lazy imports where circular) | firewall, plan_synthesizer, semantic_parser, capability_extractor_system, context_updater, router_step_executor, experience_diagnostics, budget_governor, scripts |
| `PlanStep()` built without `step` for Bluetooth list | `step=1` | router_classifier_devices2.py |
| Disk-format block message missing the documented phrase | message states "restricted for security" | router_classifier_special1.py |
| "which website/app/browser is open" went to is_app_running; "show wifi" had no route; "storage health/check karo" used diagnose_storage | proper read-only tools | router_classifier_devices1/2.py |
| simulated catalog lost after `tools.registry` force-reload (test-order leak, 67 false failures) | re-asserted before every test | tests/conftest.py, tests/sim_windows.py |

Ledger: `GOKU_IGNORE_LEDGER=1` runs the suite with no xfail masking (audit mode). Entries that now pass were removed from `tests/known_failures.json`.
Still open (not faked): multi-clause pipelines (test_bullet10), game/autonomous-agent routing, tool-name conflicts between phases
(`capture_screen` vs `take_screenshot`, `is_app_running` vs `get_browser_status`, `get_processes` vs `discover_running_processes`),
`package_artifact.py` (module referenced by test_bullet33 is absent from the project), and everything that needs a real Windows desktop.
