"""Capability planner (stage F2): scan the machine, decide for each piece of work whether it can run NOW, run in PIECES, wait (pending, with a
timeline and an exact resume condition) or is impossible on this device, and list ranked ways out with the numbers.

Rules it never breaks
  * Read-only scan. It never terminates, suspends or modifies any process or Windows file. Other programs are only ever SUGGESTED for closing, and
    protected system processes are never suggested.
  * No thread, no timer. Pending work is re-checked at natural moments (start-up, next command, end of a task) by calling `resume_check()`.
  * The same code runs on a 4 GB laptop and on a high-end PC: every limit comes from the live scan and the hardware tier, nothing is hard-wired.
  * All memory/time figures are estimates (see brain/capability_catalog.py) until measured; verdicts say so.
"""
from __future__ import annotations

import json
import math
import os
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

from brain.capability_catalog import CATALOG, TIER_ORDER, WORK, resolve_kind

PROJECT_ROOT = Path(__file__).absolute().parent.parent
PENDING_FILE = PROJECT_ROOT / "logs" / "state" / "pending_work.json"
CALIBRATION_FILE = Path(os.environ.get("GOKU_CALIBRATION", str(PROJECT_ROOT / "logs" / "calibration.json")))
_CAL_CACHE: Dict[str, Any] = {"mtime": None, "data": {}}

PROTECTED = {"system", "system idle process", "registry", "smss.exe", "csrss.exe", "wininit.exe", "winlogon.exe", "services.exe", "lsass.exe", "svchost.exe", "dwm.exe",
             "explorer.exe", "fontdrvhost.exe", "msmpeng.exe", "securityhealthservice.exe", "searchindexer.exe", "taskhostw.exe", "sihost.exe", "ctfmon.exe", "audiodg.exe",
             "spoolsv.exe", "wudfhost.exe", "init", "systemd", "kthreadd"}
MIN_CLOSE_MB = 150.0     # a user app below this is not worth suggesting
RUN_NOW, RUN_CHUNKED, PENDING, IMPOSSIBLE = "run_now", "run_in_pieces", "pending", "impossible_here"


# ------------------------------------------------------------------------------------------------ calibration
def load_calibration() -> Dict[str, Any]:
    """Numbers measured ON THIS MACHINE by scripts/laptop_validate.py: {"kinds": {"big_text": {"chunk_ram_mb": 31.5, "mb_per_s": 18.2}, ...}}. Cached by file time."""
    try:
        m = CALIBRATION_FILE.stat().st_mtime
    except OSError:
        _CAL_CACHE.update(mtime=None, data={})
        return {}
    if _CAL_CACHE["mtime"] != m:
        try:
            _CAL_CACHE.update(mtime=m, data=json.loads(CALIBRATION_FILE.read_text(encoding="utf-8")))
        except Exception:
            _CAL_CACHE.update(mtime=m, data={})
    return _CAL_CACHE["data"]


def effective_kind(key: str) -> Dict[str, Any]:
    k = dict(WORK[key])
    over = (load_calibration().get("kinds") or {}).get(key) or {}
    for f in ("ram_mb", "chunk_ram_mb", "mb_per_s"):
        if isinstance(over.get(f), (int, float)) and over[f] > 0:
            k[f] = float(over[f])
            k["calibrated"] = True
    return k


# ------------------------------------------------------------------------------------------------ scan
def scan_system(top_n: int = 12) -> Dict[str, Any]:
    """Read-only snapshot. Every probe is fail-soft; missing data is None, never invented."""
    snap: Dict[str, Any] = {"time": time.time(), "total_mb": None, "free_mb": None, "tier": "tiny", "cpu_count": os.cpu_count(), "cpu_percent": None, "battery_pct": None,
                            "on_ac": None, "temp_c": None, "disk_free_mb": None, "goku_mb": None, "processes": [], "headroom_mb": 150.0, "notes": []}
    try:
        from tools import hw_profile
        mem = hw_profile.read_memory_mb()
        snap["total_mb"], snap["free_mb"] = mem.get("total_mb"), mem.get("available_mb")
        snap["tier"] = hw_profile.classify_tier(snap["total_mb"])
    except Exception:
        snap["notes"].append("memory probe unavailable")
    try:
        from tools import resource_monitor as rm
        snap["headroom_mb"] = float(rm.default_headroom_mb())
        f = rm.free_ram_mb()
        if f is not None:
            snap["free_mb"] = float(f)
    except Exception:
        pass
    try:
        import psutil
        snap["cpu_percent"] = psutil.cpu_percent(interval=None)
        b = psutil.sensors_battery()
        if b is not None:
            snap["battery_pct"], snap["on_ac"] = float(b.percent), bool(b.power_plugged)
        try:
            temps = psutil.sensors_temperatures()  # not available on Windows: stays None
            vals = [t.current for v in temps.values() for t in v if t.current]
            snap["temp_c"] = max(vals) if vals else None
        except Exception:
            pass
        snap["disk_free_mb"] = psutil.disk_usage(str(PROJECT_ROOT)).free / 1048576.0
        me = psutil.Process()
        tree = [me] + me.children(recursive=True)
        pids = {p.pid for p in tree}
        snap["goku_mb"] = sum(p.memory_info().rss for p in tree) / 1048576.0
        procs: List[Dict[str, Any]] = []
        for p in psutil.process_iter(["pid", "name", "memory_info"]):
            try:
                name = (p.info.get("name") or "?")
                rss = (p.info["memory_info"].rss if p.info.get("memory_info") else 0) / 1048576.0
                lname = name.lower()
                cat = "goku" if p.info["pid"] in pids else "goku_model" if lname.startswith("ollama") else "protected_system" if lname in PROTECTED else "user_app"
                procs.append({"pid": p.info["pid"], "name": name, "rss_mb": round(rss, 1), "category": cat})
            except Exception:
                continue
        procs.sort(key=lambda r: -r["rss_mb"])
        snap["processes"] = procs[:top_n]
        snap["user_apps_mb"] = round(sum(r["rss_mb"] for r in procs if r["category"] == "user_app"), 1)
    except Exception:
        snap["notes"].append("process/battery/disk probes unavailable")
    if snap["free_mb"] is None:
        snap["free_mb"] = 1500.0
        snap["notes"].append("free RAM unknown; 1500 MB assumed")
    if snap["total_mb"] is None:
        snap["total_mb"] = 4096.0
    return snap


def closable_apps(snap: Dict[str, Any]) -> List[Dict[str, Any]]:
    return [p for p in snap.get("processes", []) if p.get("category") == "user_app" and p.get("rss_mb", 0) >= MIN_CLOSE_MB]


# ------------------------------------------------------------------------------------------------ chunk maths
TIER_PIECE_MB = {"tiny": 10.0, "small": 16.0, "medium": 32.0, "large": 64.0}


def plan_chunks(total_mb: float, free_mb: float, headroom_mb: float = 150.0, per_chunk_overhead_mb: float = 20.0, tier_cap_mb: Optional[float] = None, tier: str = "tiny") -> Dict[str, Any]:
    """Piece size = min(tier cap, 5% of the usable RAM): ~10 MB pieces on a 4 GB laptop (1 GB file -> ~103 pieces), bigger pieces on a bigger machine. Real pieces follow natural boundaries (heading, page, function)."""
    usable = max(free_mb - headroom_mb, 0.0)
    cap = tier_cap_mb if tier_cap_mb else TIER_PIECE_MB.get(tier, 10.0)
    size = max(1.0, min(cap, usable * 0.05))
    n = max(1, math.ceil(total_mb / size)) if total_mb > 0 else 1
    return {"chunk_mb": round(size, 2), "pieces": n, "overlap": "10%", "checkpoint_every": 1, "merge": "hierarchical (piece -> section -> document)"}


# ------------------------------------------------------------------------------------------------ verdict
def _eta(kind: Dict[str, Any], size_mb: float) -> Optional[float]:
    r = kind.get("mb_per_s")
    return round(size_mb / r, 0) if r and size_mb else None


def evaluate(work: str, size_mb: float = 0.0, snapshot: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """verdict in {run_now, run_in_pieces, pending, impossible_here} plus numbers, reasons, resume condition and ranked options."""
    key = resolve_kind(work)
    if not key:
        return {"verdict": IMPOSSIBLE, "work": work, "reasons": [f"unknown kind of work '{work}'. Known: {', '.join(sorted(WORK))}"], "options": [], "estimate": True}
    k = effective_kind(key)
    s = snapshot or scan_system()
    free, total, head = float(s["free_mb"]), float(s["total_mb"]), float(s.get("headroom_mb", 150.0))
    usable = free - head
    reasons: List[str] = []
    options: List[Dict[str, Any]] = []
    ext = float(k.get("external_ram_mb") or 0.0)
    whole = k.get("ram_mb")
    if whole is None and k.get("chunk_ram_mb"):
        whole = float(k["chunk_ram_mb"]) + size_mb * float(k.get("size_factor", 1.0))
    need_whole = (float(whole) if whole is not None else 0.0) + ext
    need_chunk = (float(k["chunk_ram_mb"]) + ext) if k.get("chunk_ram_mb") else None
    ceiling = _goku_ceiling_mb(s.get("tier", "tiny"))
    over_ceiling = (need_whole - ext) > ceiling
    out: Dict[str, Any] = {"work": key, "title": k["title"], "size_mb": size_mb, "need_mb": round(need_whole), "need_chunked_mb": round(need_chunk) if need_chunk else None,
                           "free_mb": round(free), "usable_mb": round(usable), "headroom_mb": round(head), "estimate": not k.get("calibrated"), "eta_s": _eta(k, size_mb),
                           "reasons": reasons, "options": options, "resume_when": {}, "feature_status": k.get("status"), "goku_ceiling_mb": round(ceiling)}
    if k.get("calibrated"):
        reasons.append("memory figures were measured on this machine (logs/calibration.json)")
    if k.get("status") in ("planned", "partial"):
        reasons.append("feature status: " + ("not built yet (resources are judged as if it existed)" if k["status"] == "planned" else "partly built / not yet tested on a real Windows laptop"))

    if k.get("status") == "external":
        reasons.append(f"{k['title']}: {k.get('external_reason', 'needs a stronger machine')}")
        options.append({"kind": "other_machine", "text": "prepare it on a stronger machine and copy the verified result in (knowledge pack / adapter)"})
        out["verdict"] = IMPOSSIBLE
        return out
    if k.get("needs_net"):
        reasons.append("needs internet; offline it will answer 'needs_web' instead of guessing")
    bat, ac = s.get("battery_pct"), s.get("on_ac")
    heavy = need_whole > 300 or k.get("cpu", 1) >= 3
    if heavy and bat is not None and ac is False and bat < 25:
        reasons.append(f"battery {bat:.0f}% and not charging: heavy work waits for power")
        out["resume_when"] = {"on_ac": True}
        out["verdict"] = PENDING
        options.append({"kind": "wait", "text": "plug in the charger; it then resumes by itself at the next check"})
        return out
    if heavy and s.get("temp_c") is not None and s["temp_c"] > 85:
        reasons.append(f"temperature {s['temp_c']:.0f} C is too high")
        out["resume_when"] = {"max_temp_c": 75}
        out["verdict"] = PENDING
        return out
    if k.get("needs_gpu") and not s.get("gpu_ok", False) and need_whole > total * 0.5:
        reasons.append("needs a real GPU for playable speed; none confirmed on this device")

    if need_whole <= usable and not over_ceiling:
        out["verdict"] = RUN_NOW
        reasons.append(f"needs about {need_whole:.0f} MB, usable now {usable:.0f} MB")
        return out

    if need_chunk is not None and need_chunk <= usable and (need_chunk - ext) <= ceiling:
        out["verdict"] = RUN_CHUNKED
        out["chunks"] = plan_chunks(size_mb, free, head, tier=s.get("tier", "tiny"))
        reasons.append((f"whole job needs about {need_whole:.0f} MB, above GOKU's own memory ceiling of {ceiling:.0f} MB for this tier" if over_ceiling else
                        f"whole job needs about {need_whole:.0f} MB but only {usable:.0f} MB is usable") + f"; in pieces each step needs about {need_chunk:.0f} MB")
        options.append({"kind": "chunk", "text": f"{out['chunks']['pieces']} pieces of ~{out['chunks']['chunk_mb']} MB, checkpoint after each piece, so a restart continues from the last piece"})
        return out

    # cannot run now: what would change that?
    if over_ceiling and (need_chunk is None or (need_chunk - ext) > ceiling):
        reasons.append(f"needs {need_whole - ext:.0f} MB inside GOKU, above its own ceiling of {ceiling:.0f} MB for tier '{s.get('tier')}'. A stronger tier raises the ceiling automatically")
        options.append({"kind": "lighter_or_stronger", "text": "use a lighter option, or run on a stronger PC (no code change needed)"})
        options.extend(_lighter_alternatives(key, min(usable, ceiling)))
        out["verdict"] = IMPOSSIBLE
        return out
    gap = need_whole - usable
    apps = closable_apps(s)
    freeable = sum(a["rss_mb"] for a in apps)
    for a in apps[:4]:
        options.append({"kind": "close_app", "text": f"close {a['name']} (~{a['rss_mb']:.0f} MB). Only you can do this; GOKU will not close it", "frees_mb": a["rss_mb"]})
    if apps:
        reasons.append(f"short by {gap:.0f} MB; closing the listed apps could free up to {freeable:.0f} MB")
    if need_chunk is not None:
        options.append({"kind": "wait", "text": f"even one piece needs {need_chunk:.0f} MB; waits until about {need_chunk + head:.0f} MB is free"})
    for alt in _lighter_alternatives(key, usable):
        options.append(alt)
    fits_device = (need_chunk if need_chunk is not None else need_whole) + head <= total * 0.85
    if fits_device:
        out["verdict"] = PENDING
        target = (need_chunk if need_chunk is not None else need_whole) + head
        out["resume_when"] = {"min_free_mb": round(target)}
        reasons.append(f"needs {need_whole:.0f} MB, usable now {usable:.0f} MB (short by {gap:.0f} MB). Pending until about {target:.0f} MB is free")
    else:
        out["verdict"] = IMPOSSIBLE
        need_total = (need_chunk if need_chunk is not None else need_whole) + head
        reasons.append(f"needs about {need_total:.0f} MB with headroom, this device has {total:.0f} MB in total: it cannot do this by waiting")
        options.append({"kind": "other_machine", "text": f"run it on a PC with at least {math.ceil(need_total / 0.85 / 1024)} GB RAM; GOKU needs no code change there, the same planner will allow it"})
    return out


def _goku_ceiling_mb(tier: str) -> float:
    try:
        from tools import hw_profile
        return float(hw_profile.tier_settings(tier).budget_max_mb)
    except Exception:
        return {"tiny": 1100.0, "small": 2200.0, "medium": 4096.0, "large": 8192.0}.get(tier, 1100.0)


def _lighter_alternatives(key: str, usable: float) -> List[Dict[str, Any]]:
    alts = {"llm_7b": ["llm_3b", "llm_1_5b", "chat"], "llm_3b": ["llm_1_5b", "chat"], "llm_1_5b": ["chat"], "game_heavy": ["game_3d", "game_light"], "game_3d": ["game_light"],
            "ocr": ["image"], "voice_stt": ["solver"]}
    out = []
    for a in alts.get(key, []):
        need = (WORK[a].get("ram_mb") or WORK[a].get("chunk_ram_mb") or 0) + (WORK[a].get("external_ram_mb") or 0)
        if need <= usable:
            out.append({"kind": "lighter", "text": f"use '{a}' instead ({WORK[a]['title']}, about {need:.0f} MB)"})
            break
    return out


def explain(ev: Dict[str, Any]) -> str:
    lab = {RUN_NOW: "CAN RUN NOW", RUN_CHUNKED: "CAN RUN IN PIECES", PENDING: "PENDING (waits for resources)", IMPOSSIBLE: "NOT POSSIBLE ON THIS DEVICE"}[ev["verdict"]]
    lines = [f"{lab}: {ev.get('title', ev.get('work'))}"]
    if "need_mb" in ev:
        lines.append(f"  need ~{ev['need_mb']} MB (in pieces ~{ev['need_chunked_mb']} MB), free {ev['free_mb']} MB, headroom {ev['headroom_mb']} MB  [{'estimate' if ev.get('estimate') else 'measured'}]")
    if ev.get("eta_s"):
        lines.append(f"  rough time ~{ev['eta_s']:.0f} s at the estimated speed")
    lines += [f"  - {r}" for r in ev["reasons"]]
    if ev.get("resume_when"):
        lines.append(f"  resumes when: {ev['resume_when']}")
    lines += [f"  option: {o['text']}" for o in ev["options"]]
    return "\n".join(lines)


# ------------------------------------------------------------------------------------------------ capability report (same code, any hardware)
def capability_report(snapshot: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    s = snapshot or scan_system()
    tier = s.get("tier", "tiny")
    rank = TIER_ORDER.index(tier) if tier in TIER_ORDER else 0
    rows = []
    for c in CATALOG:
        need = TIER_ORDER.index(c["min_tier"])
        if c["status"] == "external":
            state = "external"
        elif need > rank:
            state = "needs_stronger_device"
        elif c["status"] in ("built",):
            state = "available"
        elif c["status"] in ("partial",):
            state = "partly_available"
        elif c["status"] == "scale_up":
            state = "available"
        else:
            state = "planned"
        rows.append(dict(c, state=state))
    work = {k: evaluate(k, 0.0, s)["verdict"] for k in sorted(WORK)}
    counts: Dict[str, int] = {}
    for r in rows:
        counts[r["state"]] = counts.get(r["state"], 0) + 1
    return {"tier": tier, "counts": counts, "techniques": rows, "work": work}


def render_capabilities(rep: Dict[str, Any]) -> str:
    out = [f"Hardware tier: {rep['tier']}", "Techniques 21-120: " + ", ".join(f"{k} {v}" for k, v in sorted(rep["counts"].items())), "Work kinds right now:"]
    for k, v in rep["work"].items():
        out.append(f"  {k:<15} {v}")
    return "\n".join(out)


# ------------------------------------------------------------------------------------------------ pending queue with timeline
def _stamp(t: float) -> str:
    return datetime.fromtimestamp(t).astimezone().strftime("%Y-%m-%d %H:%M:%S %z")


class PendingQueue:
    """Persistent list of work that could not (or can no longer) run. Every state change is appended to the item's timeline with a timestamp."""

    def __init__(self, path: Any = None, clock: Callable[[], float] = time.time):
        self.path = Path(path) if path else PENDING_FILE
        self.clock = clock
        self.items: List[Dict[str, Any]] = self._load()

    def _load(self) -> List[Dict[str, Any]]:
        try:
            return json.loads(self.path.read_text(encoding="utf-8")).get("items", [])
        except Exception:
            return []

    def _save(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.path.with_suffix(".tmp")
        tmp.write_text(json.dumps({"items": self.items}, indent=1), encoding="utf-8")
        os.replace(tmp, self.path)

    def _log(self, it: Dict[str, Any], event: str, detail: str = "") -> None:
        t = self.clock()
        it["timeline"].append({"t": t, "at": _stamp(t), "event": event, "detail": detail})

    def _find(self, iid: str) -> Dict[str, Any]:
        for it in self.items:
            if it["id"] == iid:
                return it
        raise KeyError(f"no pending item {iid}")

    def submit(self, work: str, size_mb: float = 0.0, label: str = "", snapshot: Optional[Dict[str, Any]] = None, progress: Optional[Dict[str, Any]] = None,
               params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        ev = evaluate(work, size_mb, snapshot)
        import uuid
        iid = "w" + uuid.uuid4().hex[:8]
        while any(x["id"] == iid for x in self.items):
            iid = "w" + uuid.uuid4().hex[:8]
        it = {"id": iid, "work": ev.get("work", work), "label": label or ev.get("title", work), "size_mb": size_mb, "status": "pending",
              "verdict": ev["verdict"], "reasons": ev["reasons"], "resume_when": ev.get("resume_when", {}), "progress": progress or {}, "params": params or {}, "timeline": []}
        self._log(it, "received", f"verdict {ev['verdict']}")
        if ev["verdict"] in (RUN_NOW, RUN_CHUNKED):
            it["status"] = "ready"
            it["chunks"] = ev.get("chunks")
        elif ev["verdict"] == IMPOSSIBLE:
            it["status"] = "impossible_here"
            self._log(it, "impossible_here", "; ".join(ev["reasons"])[:300])
        else:
            self._log(it, "deferred", "; ".join(ev["reasons"])[:300])
        self.items.append(it)
        self._save()
        return {"item": it, "evaluation": ev}

    def start(self, iid: str, detail: str = "") -> None:
        it = self._find(iid)
        if it["status"] not in ("ready", "pending", "interrupted"):
            raise ValueError(f"cannot start from {it['status']}")
        self._log(it, "resumed" if any(e["event"] == "interrupted" for e in it["timeline"]) else "started", detail)
        it["status"] = "running"
        self._save()

    def checkpoint(self, iid: str, progress: Dict[str, Any]) -> None:
        it = self._find(iid)
        it["progress"] = progress
        self._save()

    def interrupt(self, iid: str, why: str) -> None:
        it = self._find(iid)
        self._log(it, "interrupted", why)
        it["status"] = "interrupted"
        self._save()

    def finish(self, iid: str, ok: bool, detail: str = "") -> None:
        it = self._find(iid)
        self._log(it, "completed" if ok else "failed", detail)
        it["status"] = "done" if ok else "failed"
        self._save()

    def cancel(self, iid: str) -> bool:
        it = self._find(iid)
        if it["status"] in ("done", "cancelled"):
            return False
        self._log(it, "cancelled")
        it["status"] = "cancelled"
        self._save()
        return True

    def recover(self) -> List[str]:
        """After a crash/restart: items still 'running' were interrupted by it."""
        ids = []
        for it in self.items:
            if it["status"] == "running":
                self._log(it, "interrupted", "GOKU or the device stopped while this was running; continues from the last checkpoint")
                it["status"] = "interrupted"
                ids.append(it["id"])
        if ids:
            self._save()
        return ids

    @staticmethod
    def _met(req: Dict[str, Any], s: Dict[str, Any]) -> bool:
        if "min_free_mb" in req and float(s.get("free_mb") or 0) < req["min_free_mb"]:
            return False
        if req.get("on_ac") and s.get("on_ac") is False:
            return False
        if "max_temp_c" in req and s.get("temp_c") is not None and s["temp_c"] > req["max_temp_c"]:
            return False
        return True

    def due(self, snapshot: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        s = snapshot or scan_system()
        out = []
        for it in self.items:
            if it["status"] in ("pending", "interrupted"):
                req = it.get("resume_when") or {}
                ev = evaluate(it["work"], it.get("size_mb", 0.0), s)
                if ev["verdict"] in (RUN_NOW, RUN_CHUNKED) and self._met(req, s):
                    out.append(it)
        return out

    def resume_check(self, snapshot: Optional[Dict[str, Any]] = None) -> List[str]:
        """Call at start-up, before/after a command, at the end of a task. Marks due items 'ready' (and logs it); the caller then runs them. No thread is involved."""
        ids = []
        for it in self.due(snapshot):
            self._log(it, "ready", "resources are available now")
            it["status"] = "ready"
            ids.append(it["id"])
        if ids:
            self._save()
        return ids

    def report(self, iid: Optional[str] = None) -> str:
        rows = [self._find(iid)] if iid else self.items
        if not rows:
            return "No pending work."
        out = []
        for it in rows:
            out.append(f"{it['id']}  {it['status']:<16} {it['label']}")
            if iid:
                out += [f"    {e['at']}  {e['event']}  {e['detail']}" for e in it["timeline"]]
                if it.get("progress"):
                    out.append(f"    progress: {it['progress']}")
                if it.get("resume_when"):
                    out.append(f"    resumes when: {it['resume_when']}")
        return "\n".join(out)


# ------------------------------------------------------------------------------------------------ idle reclaim (GOKU's own memory only)
def reclaim(checkpoint: Optional[Callable[[], Any]] = None, unload_model: Optional[Callable[[], Any]] = None, trim: Optional[Callable[[], Any]] = None) -> Dict[str, Any]:
    """Frees GOKU's OWN memory after work: checkpoint first, then unload the model, gc, trim working set. Never touches another program. Call it when a task ends or at exit (no timer)."""
    import gc
    done: List[str] = []
    try:
        if checkpoint:
            checkpoint()
            done.append("checkpoint saved")
    except Exception as exc:
        return {"ok": False, "done": done, "error": f"checkpoint failed, nothing was released: {type(exc).__name__}"}
    for name, fn in (("model unloaded", unload_model), ("working set trimmed", trim)):
        try:
            if fn:
                fn()
                done.append(name)
        except Exception as exc:
            done.append(f"{name}: failed ({type(exc).__name__})")
    gc.collect()
    done.append("gc")
    return {"ok": True, "done": done}


def default_unload_model() -> bool:
    """Asks Ollama to drop the model now (keep_alive 0, empty prompt). Only the model GOKU uses."""
    import urllib.request
    from config import settings
    body = json.dumps({"model": settings.MODEL, "keep_alive": 0}).encode()
    req = urllib.request.Request(settings.OLLAMA_BASE_URL.rstrip("/") + "/api/generate", data=body, headers={"Content-Type": "application/json"})
    urllib.request.urlopen(req, timeout=3).read()
    return True


# ------------------------------------------------------------------------------------------------ text commands
def handle_command(text: str, queue: Optional[PendingQueue] = None, snapshot: Optional[Dict[str, Any]] = None) -> str:
    """scan | capabilities | plan <work> [size MB] | pending [list|report <id>|check|cancel <id>] (also: system scan)"""
    import re
    t = re.sub(r"(?i)^\s*system\s+", "", text).strip()
    parts = t.split()
    cmd = parts[0].lower() if parts else ""
    q = queue or PendingQueue()
    if cmd == "scan":
        s = snapshot or scan_system()
        lines = [f"RAM free {s['free_mb']:.0f} of {s['total_mb']:.0f} MB, tier {s['tier']}, GOKU tree {s.get('goku_mb') or 0:.0f} MB, battery {s.get('battery_pct')}% (AC {s.get('on_ac')}), disk free {s.get('disk_free_mb') or 0:.0f} MB"]
        lines += [f"  {p['rss_mb']:>7.0f} MB  {p['name']:<28} {p['category']}" for p in s.get("processes", [])]
        lines += [f"  note: {n}" for n in s.get("notes", [])]
        return "\n".join(lines)
    if cmd.startswith("capab"):
        return render_capabilities(capability_report(snapshot))
    if cmd == "work":
        from brain.work_scheduler import WorkScheduler
        sub = parts[1].lower() if len(parts) > 1 else "status"
        sch = WorkScheduler(q, scan=(lambda: snapshot) if snapshot else scan_system)
        if sub == "file" and len(parts) > 2:
            path = t.split(None, 2)[2].strip().strip('"')
            if not os.path.isfile(path):
                return f"file not found: {path}"
            iid = sch.add_file(path)
            return f"queued {iid}; run it with: work run"
        if sub == "run":
            res = sch.run_all()
            return "\n".join(res["events"] + [f"unfinished: {', '.join(res['unfinished']) or 'none'}"])
        return q.report()
    if cmd == "plan":
        if len(parts) < 2:
            return "usage: plan <work> [size in MB]   work: " + ", ".join(sorted(WORK))
        size = 0.0
        for p in parts[2:]:
            try:
                size = float(p.lower().replace("mb", "").replace("gb", "")) * (1024 if p.lower().endswith("gb") else 1)
            except ValueError:
                continue
        ev = evaluate(parts[1], size, snapshot)
        res = q.submit(parts[1], size, snapshot=snapshot) if ev["verdict"] in (PENDING, IMPOSSIBLE) else None
        return explain(ev) + (f"\n  recorded as {res['item']['id']} (see: pending report {res['item']['id']})" if res else "")
    if cmd == "pending":
        sub = parts[1].lower() if len(parts) > 1 else "list"
        if sub == "check":
            ids = q.resume_check(snapshot)
            return f"{len(ids)} item(s) can run now: {', '.join(ids)}" if ids else "nothing is ready yet"
        if sub == "report" and len(parts) > 2:
            try:
                return q.report(parts[2])
            except KeyError as exc:
                return str(exc)
        if sub == "cancel" and len(parts) > 2:
            try:
                return "cancelled" if q.cancel(parts[2]) else "already finished"
            except KeyError as exc:
                return str(exc)
        return q.report()
    return "commands: scan, capabilities, plan <work> [MB], work file <path>, work run, pending [list|check|report <id>|cancel <id>]"
