"""Work scheduler (stage F3): runs several jobs one after another, safely, on any machine.

For every job, right before it starts, the machine is scanned again and the planner decides (run now / in pieces / pending / impossible). Rules:
  * strictly one job at a time (no overlap of OCR, PDF, model, game); between jobs GOKU's own memory is released (reclaim hook) and the machine is re-scanned
  * a job that cannot run yet is left pending (it does not block the others); one that can never run is marked impossible and its dependants are skipped
  * a job is finished only when its runner reports ok AND verified; an unverified result is recorded as failed, never as done
  * a stop request or low RAM in the middle of a job interrupts it at a piece boundary; progress stays in the pending queue and the job resumes where it stopped
  * runners are rebuilt from the persisted `params` after a restart, so file jobs resume without any code from the caller
No threads, no timers: it works when `run_all()` is called (after a command, at start-up, at the end of a task).
"""
from __future__ import annotations

import os
import time
from typing import Any, Callable, Dict, List, Optional

from brain import capability_planner as cp
from brain.piece_runner import file_profile_piece, merge_profile, run_pieces

Runner = Callable[[Dict[str, Any], Dict[str, Any]], Dict[str, Any]]
FINAL = ("done", "failed", "cancelled", "impossible_here", "skipped")


def _file_runner(item: Dict[str, Any], ctx: Dict[str, Any]) -> Dict[str, Any]:
    path = (item.get("params") or {}).get("path")
    if not path or not os.path.isfile(path):
        return {"ok": False, "verified": False, "status": "failed", "reason": f"file not found: {path}"}
    ev = ctx["evaluation"]
    piece_mb = (ev.get("chunks") or {}).get("chunk_mb") or 10.0
    r = run_pieces(path, file_profile_piece, piece_mb=piece_mb, progress=item.get("progress") or {}, checkpoint=ctx["checkpoint"], guard=ctx["guard"], stop=ctx["stop"],
                   results_path=ctx["results_path"])
    ok = r["status"] == "done" and r["coverage_ok"]
    summary = merge_profile(r["results_path"]) if ok else {}
    return {"ok": ok, "verified": ok, "status": r["status"], "reason": r["reason"], "summary": summary, "progress": {"offset": r["offset"], "index": r["pieces"]}}


BUILTIN_RUNNERS: Dict[str, Runner] = {"file_profile": _file_runner}


class WorkScheduler:
    def __init__(self, queue: Optional[cp.PendingQueue] = None, scan: Callable[[], Dict[str, Any]] = cp.scan_system, after_item: Optional[Callable[[], Any]] = None,
                 results_dir: Any = None):
        self.queue = queue or cp.PendingQueue()
        self.scan = scan
        self.after_item = after_item
        self.runners: Dict[str, Runner] = {}
        self.deps: Dict[str, List[str]] = {}
        self._stop = False
        self.results_dir = results_dir

    # ---------------------------------------------------------------- submit
    def add(self, work: str, size_mb: float = 0.0, label: str = "", priority: int = 5, depends_on: Optional[List[str]] = None, runner: Optional[Runner] = None,
            params: Optional[Dict[str, Any]] = None) -> str:
        snap = self.scan()
        res = self.queue.submit(work, size_mb, label=label, snapshot=snap, params=params)
        it = res["item"]
        it["priority"] = priority
        it["depends_on"] = list(depends_on or [])
        if it["status"] == "ready":
            it["status"] = "pending"          # the scheduler starts it in order; "ready" is set by resume_check
        self.queue._save()
        if runner:
            self.runners[it["id"]] = runner
        return it["id"]

    def add_file(self, path: str, label: str = "", priority: int = 5, depends_on: Optional[List[str]] = None) -> str:
        size = os.path.getsize(path) / 1048576.0
        return self.add("big_text", size, label or f"profile {os.path.basename(path)}", priority, depends_on, params={"kind": "file_profile", "path": os.path.abspath(path)})

    def request_stop(self) -> None:
        self._stop = True

    # ---------------------------------------------------------------- run
    def _item(self, iid: str) -> Dict[str, Any]:
        return self.queue._find(iid)

    def _runner_for(self, it: Dict[str, Any]) -> Optional[Runner]:
        if it["id"] in self.runners:
            return self.runners[it["id"]]
        return BUILTIN_RUNNERS.get((it.get("params") or {}).get("kind", ""))

    def _dep_state(self, it: Dict[str, Any]) -> str:
        states = []
        for d in it.get("depends_on", []):
            try:
                states.append(self._item(d)["status"])
            except KeyError:
                return "broken"
        if any(s in ("failed", "cancelled", "impossible_here", "skipped") for s in states):
            return "broken"
        return "ok" if all(s == "done" for s in states) else "wait"

    def order(self) -> List[Dict[str, Any]]:
        live = [it for it in self.queue.items if it["status"] in ("pending", "ready", "interrupted")]
        return sorted(live, key=lambda it: (it.get("priority", 5), it.get("size_mb", 0.0), it["timeline"][0]["t"]))

    def run_all(self, max_items: int = 50) -> Dict[str, Any]:
        self._stop = False
        events: List[str] = []
        waiting_logged = set()
        for _ in range(max_items):
            ran = False
            for it in self.order():
                dep = self._dep_state(it)
                if dep == "broken":
                    self.queue._log(it, "skipped", "a job it depends on failed, was cancelled or is impossible")
                    it["status"] = "skipped"
                    self.queue._save()
                    events.append(f"{it['id']} skipped (dependency)")
                    ran = True
                    continue
                if dep == "wait":
                    continue
                snap = self.scan()
                ev = cp.evaluate(it["work"], it.get("size_mb", 0.0), snap)
                if ev["verdict"] == cp.IMPOSSIBLE:
                    self.queue._log(it, "impossible_here", "; ".join(ev["reasons"])[:300])
                    it["status"] = "impossible_here"
                    self.queue._save()
                    events.append(f"{it['id']} impossible here")
                    ran = True
                    continue
                if ev["verdict"] == cp.PENDING:
                    it["resume_when"] = ev.get("resume_when", {})
                    if it["id"] not in waiting_logged and not any(e["event"] == "deferred" and e["detail"] == "; ".join(ev["reasons"])[:300] for e in it["timeline"]):
                        self.queue._log(it, "deferred", "; ".join(ev["reasons"])[:300])
                    waiting_logged.add(it["id"])
                    self.queue._save()
                    continue
                runner = self._runner_for(it)
                if runner is None:
                    if it["id"] not in waiting_logged:
                        self.queue._log(it, "deferred", "no runner is registered for this job (it was created in an earlier session); submit it again")
                        waiting_logged.add(it["id"])
                        self.queue._save()
                    continue
                self._execute(it, ev, snap, runner, events)
                ran = True
                break                      # re-scan and re-order after every executed job
            if not ran or self._stop:
                break
        left = [it["id"] for it in self.queue.items if it["status"] in ("pending", "ready", "interrupted")]
        return {"events": events, "unfinished": left, "stopped": self._stop}

    def _execute(self, it: Dict[str, Any], ev: Dict[str, Any], snap: Dict[str, Any], runner: Runner, events: List[str]) -> None:
        iid = it["id"]
        head = float(snap.get("headroom_mb", 150.0))
        need_piece = float(ev.get("need_chunked_mb") or ev.get("need_mb") or 0)

        def guard() -> Optional[str]:
            free = float(self.scan().get("free_mb") or 0)
            floor = need_piece * 0.5 + head        # the running job already holds part of its own memory, so only half is counted again
            return f"free RAM fell to {free:.0f} MB (floor {floor:.0f} MB); paused, will resume from the last piece" if free < floor else None

        rdir = self.results_dir or os.path.join(os.path.dirname(str(self.queue.path)), "work_results")
        os.makedirs(rdir, exist_ok=True)
        ctx = {"evaluation": ev, "guard": guard, "stop": lambda: self._stop, "checkpoint": lambda p: self.queue.checkpoint(iid, p), "results_path": os.path.join(rdir, f"{iid}.jsonl")}
        self.queue.start(iid, f"verdict {ev['verdict']}")
        try:
            res = runner(it, ctx)
        except Exception as exc:
            res = {"ok": False, "verified": False, "status": "failed", "reason": f"{type(exc).__name__}: {str(exc)[:200]}"}
        st = res.get("status", "done" if res.get("ok") else "failed")
        if st in ("interrupted", "stopped"):
            self.queue.interrupt(iid, res.get("reason") or st)
            events.append(f"{iid} {st}: {res.get('reason', '')}")
        elif res.get("ok") and res.get("verified"):
            it["result"] = res.get("summary", {})
            self.queue.finish(iid, True, "verified")
            events.append(f"{iid} done (verified)")
        else:
            self.queue.finish(iid, False, ("not verified: " if res.get("ok") else "") + str(res.get("reason", ""))[:200])
            events.append(f"{iid} failed: {res.get('reason', '')}")
        try:
            if self.after_item:
                self.after_item()
        except Exception:
            pass
