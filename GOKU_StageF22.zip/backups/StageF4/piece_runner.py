"""Piece runner (stage F3): processes a big file in small pieces so RAM stays flat however large the file is.

  * a piece is cut at a natural boundary (blank line, then newline, then space; never inside a UTF-8 character), with a small overlap of context taken
    from the end of the previous piece; each piece also tells which part is its own ("core") so nothing is counted twice
  * only ONE piece is in memory at a time; per-piece results are appended to a JSONL file on disk
  * after every piece a checkpoint {offset, index, ...} is handed to the caller (the pending queue stores it), so a stop / crash / restart resumes at the
    exact byte where it stopped, without redoing finished pieces
  * before each piece a guard may say "not enough RAM now" (-> interrupted, resumable) and a stop flag may cancel
  * the run is VERIFIED only if the cores of all pieces cover the file contiguously from the start offset to the end
"""
from __future__ import annotations

import hashlib
import io
import json
import os
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Dict, Iterator, Optional


@dataclass
class Piece:
    index: int
    start: int          # first byte read (start of the overlap context)
    core_start: int     # first byte that belongs to this piece
    end: int            # one past the last byte of the piece
    context: str        # overlap text from the previous piece (read-only context)
    core: str           # this piece's own text
    file_size: int

    @property
    def text(self) -> str:
        return self.context + self.core


def _boundary(buf: bytes, core_off: int) -> int:
    n = len(buf)
    mid = core_off + (n - core_off) // 2
    i = buf.rfind(b"\n\n", mid, n)
    if i != -1:
        return i + 2
    i = buf.rfind(b"\n", mid, n)
    if i != -1:
        return i + 1
    i = buf.rfind(b" ", mid, n)
    if i != -1:
        return i + 1
    cut = n
    while cut > core_off + 1 and cut < n and (buf[cut] & 0xC0) == 0x80:
        cut -= 1
    return cut


def iter_pieces(path: Any, piece_bytes: int, overlap: float = 0.1, start_offset: int = 0, start_index: int = 0) -> Iterator[Piece]:
    size = os.path.getsize(path)
    piece_bytes = max(1024, int(piece_bytes))
    ob = int(piece_bytes * max(0.0, min(overlap, 0.5)))
    pos, idx = int(start_offset), int(start_index)
    with open(path, "rb") as f:
        while pos < size:
            ctx_start = max(0, pos - ob)
            f.seek(ctx_start)
            buf = f.read(pos - ctx_start + piece_bytes)
            core_off = pos - ctx_start
            if ctx_start < pos:
                nl = buf.find(b"\n", 0, core_off)
                if nl != -1:
                    buf, ctx_start, core_off = buf[nl + 1:], ctx_start + nl + 1, core_off - nl - 1
            end_rel = len(buf) if ctx_start + len(buf) >= size else _boundary(buf, core_off)
            mv = memoryview(buf)                       # slices without copying the bytes
            yield Piece(idx, ctx_start, pos, ctx_start + end_rel, str(mv[:core_off], "utf-8", "replace"), str(mv[core_off:end_rel], "utf-8", "replace"), size)
            mv.release()
            pos = ctx_start + end_rel
            idx += 1


def run_pieces(path: Any, fn: Callable[[Piece], Any], piece_mb: float = 10.0, progress: Optional[Dict[str, Any]] = None, checkpoint: Optional[Callable[[Dict[str, Any]], Any]] = None,
               guard: Optional[Callable[[], Optional[str]]] = None, stop: Optional[Callable[[], bool]] = None, overlap: float = 0.1, results_path: Any = None) -> Dict[str, Any]:
    """fn(piece) must return something JSON-serialisable and small. Returns {status: done|interrupted|stopped|failed, offset, pieces, coverage_ok, results_path, reason}."""
    path = Path(path)
    size = path.stat().st_size
    prog = dict(progress or {})
    offset, index, gaps = int(prog.get("offset", 0)), int(prog.get("index", 0)), int(prog.get("gaps", 0))
    rp = Path(results_path) if results_path else path.with_suffix(path.suffix + ".pieces.jsonl")
    if offset == 0 and rp.exists():
        rp.unlink()                      # our own results file from an earlier, abandoned run
    out: Dict[str, Any] = {"status": "done", "offset": offset, "pieces": index, "size": size, "results_path": str(rp), "reason": "", "coverage_ok": False}
    expected = offset
    with open(rp, "a", encoding="utf-8") as rf:
        for piece in iter_pieces(path, int(piece_mb * 1048576), overlap, offset, index):
            if stop and stop():
                out.update(status="stopped", reason="stopped by user or governor")
                break
            why = guard() if guard else None
            if why:
                out.update(status="interrupted", reason=why)
                break
            if piece.core_start != expected:
                gaps += 1
            try:
                res = fn(piece)
            except Exception as exc:
                out.update(status="failed", reason=f"{type(exc).__name__}: {str(exc)[:200]}")
                break
            rf.write(json.dumps({"i": piece.index, "from": piece.core_start, "to": piece.end, "r": res}, default=str) + "\n")
            rf.flush()
            expected = offset = piece.end
            index = piece.index + 1
            prog = {"offset": offset, "index": index, "gaps": gaps, "size": size}
            if checkpoint:
                checkpoint(prog)
            out.update(offset=offset, pieces=index)
    out["coverage_ok"] = (out["status"] == "done" and gaps == 0 and offset >= size)
    out["gaps"] = gaps
    if out["status"] == "done" and not out["coverage_ok"]:
        out["status"] = "failed"
        out["reason"] = f"coverage check failed (gaps {gaps}, offset {offset} of {size})"
    return out


_HEAD = re.compile(r"^(#{1,6}\s+.+|[A-Z][A-Z0-9 .:-]{3,60})$")


def file_profile_piece(piece: Piece) -> Dict[str, Any]:
    """Built-in per-piece analysis: size, lines, words, fingerprint (duplicate detection) and headings. Small result, no text kept."""
    core = piece.core
    lines = words = 0
    heads: list = []
    h = hashlib.sha1()
    for ln in io.StringIO(core):                      # line by line: no giant word list is ever built (that was 5x the piece size)
        lines += 1
        words += len(ln.split())
        if len(heads) < 3 and _HEAD.match(ln.strip()):
            heads.append(ln.strip()[:80])
        h.update(ln.encode("utf-8"))
    return {"bytes": piece.end - piece.core_start, "lines": lines, "words": words, "sha": h.hexdigest()[:16], "heads": heads}


def merge_profile(results_path: Any) -> Dict[str, Any]:
    """Second level of the hierarchy: reads the piece results from disk one line at a time and merges them."""
    tot = {"pieces": 0, "bytes": 0, "lines": 0, "words": 0, "duplicate_pieces": 0, "headings": []}
    seen: Dict[str, int] = {}
    with open(results_path, "r", encoding="utf-8") as f:
        for line in f:
            r = json.loads(line)["r"]
            tot["pieces"] += 1
            for k in ("bytes", "lines", "words"):
                tot[k] += r[k]
            if r["sha"] in seen:
                tot["duplicate_pieces"] += 1
            seen[r["sha"]] = 1
            if len(tot["headings"]) < 20:
                tot["headings"] += r["heads"]
    return tot
