"""
Document and code insight (Stage A), built on tools.file_stream.

Everything is rule based and cited (file, page / slide / sheet row / paragraph / line). Findings are labelled
"possible" when they are heuristics. No model is needed; nothing is invented: every sentence in a summary is copied
from the file together with its location.

    analyze_file(path, question=None, ocr=None) -> report dict
    render_report(report)                       -> readable text with citations
    find_text_issues(units)                     -> contradictions, missing information, hidden assumptions
    review_code(path)                           -> structure (functions/classes/imports/calls) + bugs/security findings
    compare_files(a, b)                         -> added / removed / changed units with locations
    generate_questions(units, n)                -> study questions grounded in the file
"""
from __future__ import annotations

import ast
import hashlib
import math
import re
import sys
from collections import Counter, defaultdict
from difflib import SequenceMatcher
from pathlib import Path
from typing import Any, Callable, Dict, Iterable, Iterator, List, Optional, Sequence, Tuple

from tools.file_stream import CODE_EXT, FileIndex, Unit, identify, iter_units

_SENT = re.compile(r"(?<=[.!?؟۔])\s+|\n+")
_WORD = re.compile(r"[A-Za-z؀-ۿ][A-Za-z؀-ۿ'-]{2,}")
_STOP = set("the and for with that this are was were from have has had not but you your our their they them his her its will can could should would may might been being into over under about more most some any each other such only than then there here what which who how when where also very just all one two its per via".split())

MAX_ISSUE_UNITS = 50_000


def _sentences(text: str) -> List[str]:
    return [s.strip() for s in _SENT.split(text) if len(s.strip()) >= 3]


def _norm(s: str) -> str:
    return re.sub(r"\s+", " ", re.sub(r"[^\w\s%.\-]", " ", s.lower())).strip()


# ---------------------------------------------------------------------------
# Text issues
# ---------------------------------------------------------------------------
_FACT = re.compile(r"\b(?P<label>[A-Za-z][A-Za-z ]{2,40}?)\s*(?:is|was|are|were|=|:|equals|of)\s+(?:about |approximately |around )?(?P<num>-?\$?\d[\d,]*(?:\.\d+)?)\s*(?P<unit>%|percent|[A-Za-z]{1,12})?", re.I)
_PLACEHOLDER = re.compile(r"\b(TODO|TBD|TBA|FIXME|XXX|lorem ipsum|to be decided|to be determined|coming soon|N/A pending)\b|\?\?\?|\[(?:insert|add|fill|your)[^\]]*\]|<insert[^>]*>", re.I)
_XREF = re.compile(r"\b(?:see|refer to|as shown in|described in)\s+(section|table|figure|chapter|appendix)\s+([A-Z]?\d+(?:\.\d+)*)", re.I)
_ASSUME = re.compile(r"\b(assum(?:e|es|ed|ing|ption)|presum(?:e|ed|ably)|obviously|clearly|of course|everyone knows|it is known that|naturally|self-evident|taken for granted|should be|must be|surely|undoubtedly|without doubt)\b", re.I)


def find_text_issues(units: Iterable[Unit], max_units: int = MAX_ISSUE_UNITS) -> Dict[str, List[Dict[str, Any]]]:
    facts: Dict[str, List[Tuple[str, str, str]]] = defaultdict(list)   # label -> (value, unit, loc)
    neg_map: Dict[str, List[Tuple[bool, str, str]]] = defaultdict(list)
    missing: List[Dict[str, Any]] = []
    assumptions: List[Dict[str, Any]] = []
    headings: List[str] = []
    refs: List[Tuple[str, str, str]] = []
    count = 0
    for u in units:
        count += 1
        if count > max_units:
            break
        if u.kind in ("note", "meta"):
            if u.kind == "note" and ("no text layer" in u.text or "NOT" in u.text or "not analysed" in u.text):
                missing.append({"loc": u.loc, "issue": u.text})
            continue
        if u.kind == "heading" or re.match(r"^(chapter|section|appendix|table|figure|fig\.)\s+[A-Z]?\d", u.text, re.I):
            headings.append(u.text)
        for s in _sentences(u.text):
            for m in _FACT.finditer(s):
                label = _norm(m["label"])
                label = re.sub(r"^(the|a|an|our|its|their)\s+", "", label)
                if len(label) >= 3 and label not in _STOP:
                    facts[label].append((m["num"].replace(",", "").replace("$", ""), (m["unit"] or "").lower(), u.loc))
            n = _norm(s)
            has_neg = bool(re.search(r"\b(not|no|never|cannot|isn t|aren t|doesn t|don t|won t|nahi|nahin)\b", n))
            core = re.sub(r"\b(not|no|never|cannot|isn t|aren t|doesn t|don t|won t|nahi|nahin)\b", "", n)
            core = re.sub(r"\b(is|are|was|were|does|do|did|will|can)\b", "", core)
            core = re.sub(r"\s+", " ", core).strip()
            if len(core.split()) >= 3:
                neg_map[core].append((has_neg, s[:160], u.loc))
            if _ASSUME.search(s):
                assumptions.append({"loc": u.loc, "text": s[:200]})
            pm = _PLACEHOLDER.search(s)
            if pm:
                missing.append({"loc": u.loc, "issue": f"placeholder left in text: '{pm.group(0)}'", "text": s[:160]})
            for rm in _XREF.finditer(s):
                refs.append((rm[1].lower(), rm[2], u.loc))
    contradictions: List[Dict[str, Any]] = []
    for label, vals in facts.items():
        distinct = {(v, un) for v, un, _ in vals}
        nums = {v for v, _ in distinct}
        if len(nums) > 1 and len({un for _, un in distinct}) <= 2:
            contradictions.append({"kind": "possible numeric conflict", "label": label, "values": sorted(nums), "locs": sorted({l for _, _, l in vals})[:6]})
    for core, items in neg_map.items():
        if {h for h, _, _ in items} == {True, False}:
            pos = next(i for i in items if not i[0])
            neg = next(i for i in items if i[0])
            contradictions.append({"kind": "possible statement vs its negation", "a": pos[1], "a_loc": pos[2], "b": neg[1], "b_loc": neg[2]})
    heads_blob = " ".join(headings).lower()
    for kind, num, loc in refs:
        if not re.search(rf"\b{re.escape(kind)}\s*{re.escape(num)}\b", heads_blob) and not re.search(rf"\b{re.escape(num)}\b", heads_blob):
            missing.append({"loc": loc, "issue": f"refers to {kind} {num}, which was not found among headings/captions"})
    return {"contradictions": contradictions[:40], "missing": missing[:60], "assumptions": assumptions[:40]}


# ---------------------------------------------------------------------------
# Summary / questions (extractive, cited)
# ---------------------------------------------------------------------------
def _words(s: str) -> List[str]:
    return [w.lower() for w in _WORD.findall(s) if w.lower() not in _STOP]


def summarize_units(units: Iterable[Unit], max_sentences: int = 6, max_units: int = MAX_ISSUE_UNITS) -> Dict[str, Any]:
    freq: Counter = Counter()
    sents: List[Tuple[str, str, int]] = []
    for i, u in enumerate(units):
        if i >= max_units:
            break
        if u.kind in ("note", "meta"):
            continue
        for s in _sentences(u.text):
            if 25 <= len(s) <= 400:
                sents.append((s, u.loc, len(sents)))
                freq.update(_words(s))
    if not sents:
        return {"sentences": [], "keywords": []}
    top = freq.most_common(1)[0][1] if freq else 1
    scored = []
    for s, loc, order in sents:
        ws = _words(s)
        if ws:
            scored.append((sum(freq[w] / top for w in ws) / math.sqrt(len(ws)), order, s, loc))
    best = sorted(scored, key=lambda x: -x[0])[:max_sentences]
    best.sort(key=lambda x: x[1])
    return {"sentences": [{"text": b[2], "loc": b[3]} for b in best], "keywords": [w for w, _ in freq.most_common(10)]}


def generate_questions(units: Iterable[Unit], n: int = 5) -> List[Dict[str, str]]:
    qs: List[Dict[str, str]] = []
    keyed: List[Unit] = []
    for u in units:
        if u.kind == "heading" and len(qs) < n:
            qs.append({"question": f"What does the section '{u.text[:70]}' say?", "loc": u.loc})
        elif u.kind not in ("note", "meta"):
            keyed.append(u)
        if len(keyed) > 5000:
            break
    summ = summarize_units(keyed, max_sentences=n * 2)
    for s in summ["sentences"]:
        if len(qs) >= n:
            break
        ws = _words(s["text"])
        if ws:
            topic = Counter(ws).most_common(1)[0][0]
            qs.append({"question": f"What is stated about '{topic}'?", "loc": s["loc"]})
    return qs[:n]


# ---------------------------------------------------------------------------
# Code review
# ---------------------------------------------------------------------------
_SECRET = re.compile(r"""(?ix)\b(password|passwd|pwd|secret|api[_-]?key|token|auth[_-]?key|private[_-]?key)\b\s*[:=]\s*(['"])(?!\s*\2)([^'"\n]{6,})\2""")
_PLACEHOLDER_SECRET = re.compile(r"(?i)(your|example|changeme|xxx|<|\*{3}|dummy|test|sample|placeholder|none|null|env)")


def _finding(line: int, sev: str, rule: str, msg: str) -> Dict[str, Any]:
    return {"line": line, "severity": sev, "rule": rule, "message": msg}


def _call_name(node: ast.AST) -> str:
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        base = _call_name(node.value)
        return f"{base}.{node.attr}" if base else node.attr
    return ""


class _PyVisitor(ast.NodeVisitor):
    def __init__(self) -> None:
        self.findings: List[Dict[str, Any]] = []
        self.functions: List[Dict[str, Any]] = []
        self.classes: List[Dict[str, Any]] = []
        self.imports: Dict[str, int] = {}
        self.used_names: set = set()
        self._fn_stack: List[str] = []
        self.calls: Dict[str, set] = defaultdict(set)

    def visit_Import(self, n: ast.Import) -> None:
        for a in n.names:
            self.imports[(a.asname or a.name).split(".")[0]] = n.lineno
            if a.name.split(".")[0] in ("pickle", "marshal", "shelve"):
                self.findings.append(_finding(n.lineno, "info", "unsafe-deserialization-module", f"imports {a.name}: loading untrusted data with it can run code"))

    def visit_ImportFrom(self, n: ast.ImportFrom) -> None:
        for a in n.names:
            self.imports[a.asname or a.name] = n.lineno
        self.generic_visit(n)

    def _fn(self, n: Any) -> None:
        end = getattr(n, "end_lineno", n.lineno)
        self.functions.append({"name": n.name, "line": n.lineno, "lines": end - n.lineno + 1, "args": [a.arg for a in n.args.args], "class": next((c for c in reversed(self._fn_stack) if c.startswith("class:")), "")[6:] or None})
        if end - n.lineno + 1 > 80:
            self.findings.append(_finding(n.lineno, "low", "long-function", f"function {n.name} is {end - n.lineno + 1} lines long; consider splitting it"))
        for d in list(n.args.defaults) + [x for x in n.args.kw_defaults if x is not None]:
            if isinstance(d, (ast.List, ast.Dict, ast.Set)) or (isinstance(d, ast.Call) and _call_name(d.func) in ("list", "dict", "set")):
                self.findings.append(_finding(d.lineno, "medium", "mutable-default", f"{n.name}() has a mutable default argument that is shared between calls"))
        self._fn_stack.append(n.name)
        self.generic_visit(n)
        self._fn_stack.pop()

    visit_FunctionDef = _fn
    visit_AsyncFunctionDef = _fn

    def visit_ClassDef(self, n: ast.ClassDef) -> None:
        self.classes.append({"name": n.name, "line": n.lineno, "bases": [_call_name(b) for b in n.bases], "methods": [m.name for m in n.body if isinstance(m, (ast.FunctionDef, ast.AsyncFunctionDef))]})
        self._fn_stack.append("class:" + n.name)
        self.generic_visit(n)
        self._fn_stack.pop()

    def visit_Name(self, n: ast.Name) -> None:
        self.used_names.add(n.id)

    def visit_Attribute(self, n: ast.Attribute) -> None:
        root = n
        while isinstance(root, ast.Attribute):
            root = root.value
        if isinstance(root, ast.Name):
            self.used_names.add(root.id)
        self.generic_visit(n)

    def visit_ExceptHandler(self, n: ast.ExceptHandler) -> None:
        if n.type is None:
            self.findings.append(_finding(n.lineno, "medium", "bare-except", "bare 'except:' also hides KeyboardInterrupt and real bugs"))
        body_is_pass = len(n.body) == 1 and isinstance(n.body[0], (ast.Pass, ast.Continue))
        if body_is_pass and (n.type is None or _call_name(n.type) in ("Exception", "BaseException")):
            self.findings.append(_finding(n.lineno, "medium", "swallowed-exception", "the error is caught and ignored; failures become silent"))
        self.generic_visit(n)

    def visit_Call(self, n: ast.Call) -> None:
        name = _call_name(n.func)
        if self._fn_stack:
            fn = next((f for f in reversed(self._fn_stack) if not f.startswith("class:")), None)
            if fn and name:
                self.calls[fn].add(name)
        kw = {k.arg: k.value for k in n.keywords if k.arg}
        if name in ("eval", "exec"):
            self.findings.append(_finding(n.lineno, "high", "code-execution", f"{name}() runs arbitrary code; never use it on external input"))
        elif name in ("os.system", "os.popen"):
            self.findings.append(_finding(n.lineno, "high", "shell-command", f"{name}() runs a shell command; use subprocess with a list of arguments"))
        elif name.startswith("subprocess.") and isinstance(kw.get("shell"), ast.Constant) and kw["shell"].value is True:
            self.findings.append(_finding(n.lineno, "high", "shell-true", f"{name}(shell=True) allows command injection if any part comes from input"))
        elif name in ("pickle.load", "pickle.loads", "marshal.loads", "shelve.open"):
            self.findings.append(_finding(n.lineno, "high", "unsafe-deserialization", f"{name}() can execute code from untrusted data"))
        elif name == "yaml.load" and "Loader" not in kw:
            self.findings.append(_finding(n.lineno, "high", "yaml-load", "yaml.load without a safe Loader can execute code; use yaml.safe_load"))
        elif name in ("hashlib.md5", "hashlib.sha1"):
            self.findings.append(_finding(n.lineno, "low", "weak-hash", f"{name} is weak for security purposes"))
        elif name == "tempfile.mktemp":
            self.findings.append(_finding(n.lineno, "medium", "insecure-temp", "tempfile.mktemp is racy; use NamedTemporaryFile or mkstemp"))
        elif isinstance(kw.get("verify"), ast.Constant) and kw["verify"].value is False:
            self.findings.append(_finding(n.lineno, "high", "tls-verify-off", "certificate verification is disabled (verify=False)"))
        elif name.endswith(".execute") and n.args and (isinstance(n.args[0], ast.JoinedStr) or (isinstance(n.args[0], ast.BinOp) and isinstance(n.args[0].op, (ast.Mod, ast.Add)))):
            self.findings.append(_finding(n.lineno, "high", "sql-injection", "SQL is built with string formatting; use parameters"))
        self.generic_visit(n)

    def visit_Assert(self, n: ast.Assert) -> None:
        self.generic_visit(n)


def _review_python(text: str) -> Dict[str, Any]:
    try:
        tree = ast.parse(text)
    except SyntaxError as exc:
        return {"language": "python", "syntax_error": f"line {exc.lineno}: {exc.msg}", "findings": [_finding(exc.lineno or 1, "high", "syntax-error", exc.msg)], "functions": [], "classes": [], "imports": [], "calls": {}}
    v = _PyVisitor()
    v.visit(tree)
    for name, line in v.imports.items():
        if name not in v.used_names and name != "*" and not text.count(f"'{name}'") and not text.count(f'"{name}"') and name != "annotations":
            v.findings.append(_finding(line, "low", "unused-import", f"'{name}' is imported but never used"))
    third = sorted(n for n in v.imports if n not in getattr(sys, "stdlib_module_names", set()) and n not in ("annotations",))
    local_fns = {f["name"] for f in v.functions}
    def _local(c: str) -> bool:
        head, _, tail = c.rpartition(".")
        return c in local_fns or (head in ("self", "cls") and tail in local_fns)

    calls = {fn: sorted(c for c in cs if _local(c)) for fn, cs in v.calls.items()}
    return {"language": "python", "functions": v.functions, "classes": v.classes, "imports": sorted(v.imports), "third_party_or_local_imports": third,
            "calls": {k: x for k, x in calls.items() if x}, "findings": v.findings}


_GENERIC_RULES: List[Tuple[re.Pattern, str, str, str]] = [
    (re.compile(r"\beval\s*\("), "high", "code-execution", "eval() runs arbitrary code"),
    (re.compile(r"\b(gets|strcpy|strcat|sprintf|vsprintf)\s*\("), "high", "unsafe-c-function", "unbounded C string function: buffer overflow risk"),
    (re.compile(r"\bsystem\s*\("), "high", "shell-command", "system() runs a shell command"),
    (re.compile(r"\.innerHTML\s*=|document\.write\s*\("), "medium", "dom-xss", "writing raw HTML can allow cross-site scripting"),
    (re.compile(r"new\s+Function\s*\("), "high", "code-execution", "new Function() runs arbitrary code"),
    (re.compile(r"(?i)\bselect\b.+\bfrom\b.+(\+|\$\{|%s)"), "medium", "sql-injection", "SQL built by concatenation"),
    (re.compile(r"(?i)rejectUnauthorized\s*:\s*false|InsecureSkipVerify\s*:\s*true|verify\s*=\s*False"), "high", "tls-verify-off", "TLS certificate verification disabled"),
    (re.compile(r"\b(TODO|FIXME|HACK|XXX)\b"), "info", "todo", "unfinished work marker"),
]
_FUNC_RE = {
    ".js": r"(?:function\s+(\w+)\s*\(|(?:const|let|var)\s+(\w+)\s*=\s*(?:async\s*)?\([^)]*\)\s*=>)", ".ts": r"(?:function\s+(\w+)\s*\(|(?:const|let|var)\s+(\w+)\s*=\s*(?:async\s*)?\([^)]*\)\s*=>)",
    ".java": r"(?:public|private|protected|static)[\w<>\[\], ]*\s+(\w+)\s*\([^)]*\)\s*\{", ".cs": r"(?:public|private|protected|internal|static)[\w<>\[\], ]*\s+(\w+)\s*\([^)]*\)\s*\{",
    ".c": r"^[A-Za-z_][\w \*]*\s+\**(\w+)\s*\([^;]*\)\s*\{", ".cpp": r"^[A-Za-z_][\w:<>,\* &]*\s+\**([\w:~]+)\s*\([^;]*\)\s*(?:const)?\s*\{", ".go": r"func\s+(?:\([^)]*\)\s*)?(\w+)\s*\(", ".rs": r"fn\s+(\w+)\s*[<(]",
}
_CLASS_RE = re.compile(r"^\s*(?:export\s+)?(?:public\s+|abstract\s+|final\s+)*(?:class|struct|interface|enum)\s+(\w+)", re.M)


def review_code(path_or_text: str, language: Optional[str] = None, max_bytes: int = 5 * 1024 * 1024) -> Dict[str, Any]:
    p = Path(path_or_text) if "\n" not in path_or_text and len(path_or_text) < 1024 and Path(path_or_text).is_file() else None
    if p is not None:
        if p.stat().st_size > max_bytes:
            return {"language": language or p.suffix, "findings": [], "note": f"file larger than {max_bytes} bytes; not reviewed"}
        text = p.read_text(encoding="utf-8-sig", errors="replace")
        ext = p.suffix.lower()
    else:
        text, ext = path_or_text, "." + (language or "py").lstrip(".")
    res = _review_python(text) if ext == ".py" else {"language": ext.lstrip("."), "findings": [], "functions": [], "classes": [], "imports": []}
    lines = text.splitlines()
    if ext != ".py":
        pat = _FUNC_RE.get(ext)
        if pat:
            for i, ln in enumerate(lines, 1):
                m = re.search(pat, ln)
                if m:
                    res["functions"].append({"name": next(g for g in m.groups() if g), "line": i})
        for m in _CLASS_RE.finditer(text):
            res["classes"].append({"name": m[1], "line": text.count("\n", 0, m.start()) + 1})
        for pt, sev, rule, msg in _GENERIC_RULES:
            for i, ln in enumerate(lines, 1):
                if pt.search(ln):
                    res["findings"].append(_finding(i, sev, rule, msg))
    else:
        for pt, sev, rule, msg in _GENERIC_RULES[-1:]:
            for i, ln in enumerate(lines, 1):
                if "#" in ln and pt.search(ln.split("#", 1)[1]):
                    res["findings"].append(_finding(i, sev, rule, msg))
    for i, ln in enumerate(lines, 1):
        m = _SECRET.search(ln)
        if m and not _PLACEHOLDER_SECRET.search(m.group(3)):
            res["findings"].append(_finding(i, "high", "hardcoded-secret", f"'{m.group(1)}' looks like a hard-coded credential (value hidden)"))
    order = {"high": 0, "medium": 1, "low": 2, "info": 3}
    res["findings"].sort(key=lambda f: (order.get(f["severity"], 9), f["line"]))
    res["lines"] = len(lines)
    return res


# ---------------------------------------------------------------------------
# Compare
# ---------------------------------------------------------------------------
def _hash(s: str) -> str:
    return hashlib.blake2b(_norm(s).encode("utf-8"), digest_size=8).hexdigest()


def compare_files(a: str, b: str, max_units: int = 20_000, show: int = 15, ocr: Optional[Callable[[str], str]] = None) -> Dict[str, Any]:
    ua = [(u.loc, u.text) for u, _ in zip(iter_units(a, ocr), range(max_units)) if u.kind not in ("note", "meta")]
    ub = [(u.loc, u.text) for u, _ in zip(iter_units(b, ocr), range(max_units)) if u.kind not in ("note", "meta")]
    ha, hb = [_hash(t) for _, t in ua], [_hash(t) for _, t in ub]
    sm = SequenceMatcher(None, ha, hb, autojunk=False)
    added: List[Dict[str, str]] = []
    removed: List[Dict[str, str]] = []
    changed: List[Dict[str, str]] = []
    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        if tag == "delete":
            removed += [{"loc": ua[i][0], "text": ua[i][1][:160]} for i in range(i1, i2)]
        elif tag == "insert":
            added += [{"loc": ub[j][0], "text": ub[j][1][:160]} for j in range(j1, j2)]
        elif tag == "replace":
            for k in range(max(i2 - i1, j2 - j1)):
                i, j = i1 + k, j1 + k
                if i < i2 and j < j2:
                    changed.append({"a_loc": ua[i][0], "b_loc": ub[j][0], "a": ua[i][1][:120], "b": ub[j][1][:120]})
                elif i < i2:
                    removed.append({"loc": ua[i][0], "text": ua[i][1][:160]})
                else:
                    added.append({"loc": ub[j][0], "text": ub[j][1][:160]})
    return {"a_units": len(ua), "b_units": len(ub), "similarity": round(sm.ratio(), 4), "identical": ha == hb,
            "added": added[:show], "removed": removed[:show], "changed": changed[:show],
            "counts": {"added": len(added), "removed": len(removed), "changed": len(changed)}}


# ---------------------------------------------------------------------------
# Full analysis
# ---------------------------------------------------------------------------
def analyze_file(path: str, question: Optional[str] = None, ocr: Optional[Callable[[str], str]] = None, with_issues: bool = True) -> Dict[str, Any]:
    info = identify(path)
    rep: Dict[str, Any] = {"file": info, "ok": bool(info["exists"]) and info.get("corrupt") is not True, "units": 0, "notes": [], "summary": {}, "answers": [],
                           "issues": {}, "questions": [], "code": None, "limits": []}
    if not info["exists"]:
        rep["limits"].append("file not found")
        return rep
    if info.get("corrupt") is True:
        rep["limits"].append(f"file looks corrupt: {info['detail']}")
    if info["category"] in ("image", "audio", "video"):
        rep["limits"].append(f"{info['category']} content is only described by metadata unless an OCR/vision callable is supplied")
    with FileIndex(path, ocr=ocr) as idx:
        rep["units"] = idx.units
        rep["notes"] = idx.notes[:20]
        units = list(_cap(idx.all_units(), 20_000))
        rep["summary"] = summarize_units(units)
        if with_issues:
            rep["issues"] = find_text_issues(units)
        rep["questions"] = generate_questions(units)
        if question:
            rep["answers"] = [{"loc": h["loc"], "snippet": h["snippet"], "score": h["score"]} for h in idx.search(question, 5)]
            if not rep["answers"]:
                rep["limits"].append(f"nothing in the file matches: {question!r}")
        if idx.units > 20_000:
            rep["limits"].append("summary and issue checks used the first 20000 units only; search covers the whole file")
    if info["category"] == "code" or Path(path).suffix.lower() in CODE_EXT:
        rep["code"] = review_code(path)
    return rep


def _cap(it: Iterator[Unit], n: int) -> Iterator[Unit]:
    for i, u in enumerate(it):
        if i >= n:
            return
        yield u


def render_report(rep: Dict[str, Any], max_items: int = 6) -> str:
    f = rep["file"]
    out = [f"File: {Path(f['path']).name}  type={f['type']}  size={f['size']} bytes  units={rep['units']}"]
    out.append(f"Integrity: {'corrupt - ' if f.get('corrupt') else 'ok - ' if f.get('corrupt') is False else 'not verified - '}{f.get('detail', '')}")
    for n in rep["notes"][:max_items]:
        out.append(f"! {n['loc']}: {n['text']}")
    if rep["summary"].get("sentences"):
        out.append("\nSummary (sentences copied from the file):")
        out += [f"- {s['text']}  [{s['loc']}]" for s in rep["summary"]["sentences"][:max_items]]
        out.append("Keywords: " + ", ".join(rep["summary"]["keywords"][:8]))
    if rep["answers"]:
        out.append("\nBest matches for your question:")
        out += [f"- {a['snippet']}  [{a['loc']}]" for a in rep["answers"][:max_items]]
    iss = rep.get("issues") or {}
    for key, title in (("contradictions", "Possible contradictions"), ("missing", "Missing / unfinished"), ("assumptions", "Assumptions stated without proof")):
        items = iss.get(key) or []
        if items:
            out.append(f"\n{title} ({len(items)}):")
            for it in items[:max_items]:
                if key == "contradictions":
                    out.append("- " + (f"'{it['label']}' appears as {', '.join(it['values'])} [{', '.join(it['locs'][:3])}]" if "label" in it else f"\"{it['a']}\" [{it['a_loc']}] vs \"{it['b']}\" [{it['b_loc']}]"))
                else:
                    out.append(f"- {it.get('issue') or it.get('text')}  [{it['loc']}]")
    if rep.get("code"):
        c = rep["code"]
        out.append(f"\nCode: {len(c.get('functions', []))} functions, {len(c.get('classes', []))} classes, {c.get('lines', '?')} lines")
        for fd in c["findings"][:max_items * 2]:
            out.append(f"- [{fd['severity']}] line {fd['line']}: {fd['message']}")
    if rep["questions"]:
        out.append("\nQuestions to check understanding:")
        out += [f"- {q['question']}  [{q['loc']}]" for q in rep["questions"]]
    if rep["limits"]:
        out.append("\nLimits: " + "; ".join(rep["limits"]))
    out.append("\nNote: contradictions/assumptions are rule-based hints marked 'possible', not proof.")
    return "\n".join(out)


# ---------------------------------------------------------------------------
# Many files, RAM-aware
# ---------------------------------------------------------------------------
def file_cost_mb(path: str) -> float:
    """Conservative RAM estimate for analysing one file with the streaming reader (the file itself is never loaded whole)."""
    try:
        size_mb = Path(path).stat().st_size / 1048576.0
    except OSError:
        size_mb = 0.0
    return round(12.0 + min(size_mb, 300.0) * 0.08, 1)


def analyze_many(paths: Sequence[str], question: Optional[str] = None, free_fn: Optional[Callable[[], Optional[float]]] = None, task_id: Optional[str] = None,
                 result_path: Optional[str] = None, **runner_kw: Any) -> Dict[str, Any]:
    """
    Analyses many files in RAM-sized parts. If RAM is too low the job pauses (resumable) instead of failing.
    Returns {"run": runner summary, "reports": [compact per-file dicts]} (reports stay on disk when result_path is given).
    """
    from tools.ram_planner import PartitionedRunner

    def brief(p: str) -> Dict[str, Any]:
        rep = analyze_file(p, question)
        return {"file": p, "ok": rep["ok"], "units": rep["units"], "summary": [s["text"] for s in rep["summary"].get("sentences", [])[:3]],
                "answers": rep["answers"][:3], "limits": rep["limits"], "issues": {k: len(v) for k, v in (rep.get("issues") or {}).items()}}

    runner = PartitionedRunner(list(paths), lambda batch: [brief(p) for p in batch], cost=file_cost_mb, free_fn=free_fn, task_id=task_id, result_path=result_path, **runner_kw)
    out = runner.run()
    return {"run": out, "reports": runner.results}
