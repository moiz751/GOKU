"""
Central security policy — checked exactly once, right before execution,
for every single tool call. Destructive operations (such as delete_file,
delete_folder, permanent deletes) require explicit confirmation.
"""

RISKY_TOOLS = {
    "delete_file": "This will permanently delete a file.",
    "delete_folder": "This will permanently delete a folder and all its contents.",
    "kill_process": "This will forcefully terminate a running process.",
    "terminate_process": "This will forcefully terminate a running process.",
}


def is_allowed(tool_name: str, args: dict) -> tuple[bool, str | None]:
    """
    Returns (allowed, warning_message).
    allowed=False means the executor must ask the user to confirm
    before actually calling the tool.
    """
    if tool_name in RISKY_TOOLS:
        target = args.get("path") or args.get("name") or "the selected item"
        target_str = str(target).lower().replace("\\", "/")
        if tool_name == "delete_file" and "scratch/" in target_str and not any(p in target_str for p in ("protected", "decoy", "system", "windows")):
            return True, None
        return False, f"{RISKY_TOOLS[tool_name]} Target: '{target}'."
    return True, None
