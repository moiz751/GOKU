"""Stage F16: build data/engine_repos.json from the two repo lists (text files with github URLs; '## N. Name Intelligence' section headings).
Usage: python scripts/engine_inventory.py <list1.txt> [<list2.txt> ...]   (offline; it only reads the files, it never contacts GitHub)
Every unique repo gets ONE decision class; duplicates keep all their category memberships. Licences/URL liveness are NOT verified here."""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

ALREADY = {"ollama": "GOKU already drives Ollama (brain/ollama_manager.py, ladder)", "llama.cpp": "GGUF runtime behind Ollama; no second runtime added"}
FRAMEWORK = {"langgraph": "overlaps brain/orchestrator.py + planner_dag.py", "llama_index": "overlaps brain/doc_index.py + text_analysis.py + memory_store.py", "autogen": "multi-agent framework; GOKU stays the single decision-maker",
             "crewai": "multi-agent framework; same reason", "haystack": "RAG framework; overlaps doc_index/text_analysis", "litellm": "EXCLUDED: API router for cloud providers (offline rule)",
             "opentelemetry-python": "tracing exporter; brain/execution_trace.py already records traces locally", "langchain": "overlaps orchestrator", "mcp": "server protocol; skill_intake treats third-party text as untrusted"}
SERVER = {"qdrant": "separate server process; MemoryStore (SQLite+FTS5) already covers local recall", "comfyui": "GPU image-generation app, not an engine", "searxng": "meta-search server; needs network",
          "scrapy": "crawler framework needs network", "browser-use": "browser agent; GOKU has its own browser tools", "tika": "Java server; documents tools already extract text",
          "chroma": "vector DB (pip chromadb) - dependency conflict under wheel-only install, see dep report", "lean4": "separate prover toolchain", "z3": "native lib, optional (z3-solver)"}
SLUG_TO_LIB = {"scikit-learn": "sklearn", "opencv": "cv2", "pillow": "PIL", "z3": "z3", "chroma": "chromadb", "qdrant": "qdrant_client", "pysmt": "pysmt", "kanren": "kanren"}


def optional_libs() -> dict:
    from brain.engines.hub import _default_engines
    out: dict = {}
    for e in _default_engines():
        for lib in e.optional_libs:
            out.setdefault(lib.lower(), []).append(e.name)
    return out


def classify(slug: str, libs: dict) -> tuple:
    s = slug.lower()
    if s in ALREADY:
        return "ALREADY_IN_GOKU", ALREADY[s]
    if s in FRAMEWORK:
        return "NOT_INTEGRATED_OVERLAP" if s != "litellm" else "EXCLUDED_OFFLINE", FRAMEWORK[s]
    if s in SERVER:
        return "NOT_INTEGRATED_SERVER_OR_HEAVY", SERVER[s]
    mod = SLUG_TO_LIB.get(s, s.replace("-", "_"))
    for k, engines in libs.items():
        if k == mod.lower() or k == s:
            return "OPTIONAL_PROBED", "engine(s) " + ", ".join(sorted(set(engines))) + " use it only if already installed; native stdlib path always exists"
    return "REFERENCE_ONLY", "not imported; the engine's native path covers the need or the repo needs heavy/GPU/network dependencies"


def build(files: list) -> dict:
    libs = optional_libs()
    seen: dict = {}
    total = 0
    for f in files:
        sec = ""
        for ln in Path(f).read_text(encoding="utf-8", errors="replace").splitlines():
            m = re.match(r"##\s*\**\s*(?:\d+\.\s*)?(.+?)(?:\s*[—-]\s*\d+ repositories)?\**\s*$", ln)
            if m:
                sec = m.group(1).strip()
            for u in re.findall(r"https://github\.com/[\w.-]+/[\w.-]+", ln):
                total += 1
                key = u.lower().rstrip("/")
                row = seen.setdefault(key, {"url": u, "slug": u.rstrip("/").split("/")[-1], "categories": []})
                if sec and sec not in row["categories"]:
                    row["categories"].append(sec)
    repos = []
    for row in seen.values():
        cls, why = classify(row["slug"], libs)
        repos.append({**row, "decision": cls, "why": why, "licence": "UNVERIFIED (not fetched)", "url_checked": False})
    repos.sort(key=lambda r: r["slug"].lower())
    by: dict = {}
    for r in repos:
        by[r["decision"]] = by.get(r["decision"], 0) + 1
    return {"url_occurrences": total, "unique_repos": len(repos), "duplicates_merged": total - len(repos), "by_decision": by, "repos": repos}


if __name__ == "__main__":
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    out = build(sys.argv[1:])
    (ROOT / "data").mkdir(exist_ok=True)
    (ROOT / "data" / "engine_repos.json").write_text(json.dumps(out, indent=1, ensure_ascii=False), encoding="utf-8")
    print({k: out[k] for k in ("url_occurrences", "unique_repos", "duplicates_merged", "by_decision")})
