"""
tests/ocr_real_apps_test_v2.py
OCR on Real Applications Benchmark Suite (Stage 1 Task 1.2c - Kit v2).

Repairs measurement bugs identified in real1:
- K1 REGION: Full enumeration of Chrome_RenderWidgetHostHWND children; discards invisible
  or width < 200 / height <= 150; selects largest area; falls back to window rect minus 120px top.
- K2 PAGE READY: Polls up to 10s for title containing 'OCR REAL PAGE' and valid widget host region.
  Fails explicitly on timeout as NOT_READY (never silent).
- K3 OCC LATENCY: ocr_added_latency = median(include_ocr=True) - median(include_ocr=False) on
  the SAME Notepad window with occluder present. Records target HWND and title from scene.
- K4 ARTIFACTS: Saves window surface bitmap to reports/ocr/real/<tag>_img/<case>.png; stores
  raw OCR words with inside_region flag; tracks UIA counts and up to 20 differing names.
- K5 PRINTING: G1-G6 each prints explicit [PASS]/[FAIL] header and comprehensive per-case metrics.
- K6 INFORMATIONAL ROWS: Extracts CA/ST truth only from on-screen, in-window elements (>= 4 letters);
  flags truth < 5 words as TRUTH TOO SMALL; computes capture_blank.
- K7 COMPARE: --compare TAG1 TAG2 side-by-side analysis and list of K-changes.
"""
from __future__ import annotations

import argparse
import collections
import ctypes
from ctypes import wintypes
import gc
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import statistics
import subprocess
import sys
import tempfile
import time
from typing import Any, Callable

from PIL import Image, ImageDraw, ImageFont, ImageStat

# Project root setup
PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from tests.eye_ab_test import (
    find_browser_binary,
    find_matching_visible_windows,
    find_new_app_window,
    get_window_info,
    init_uia_oracle,
    matches_app_identity,
    snapshot_visible_top_level_hwnds,
    walk_uia_tree,
)
from tests.eye_cold_start_probe import (
    classify_preexisting_window,
    find_all_identity_windows,
    get_window_extended_info,
)
from tests.ocr_ab_test import (
    compute_engine_sha256,
    compute_file_sha256,
    get_display_scale_pct,
    get_process_ram_mb,
    normalize_word,
)
from tools.vision.screen_engine import observe, _capture_window_surface, get_screen_size


# ==============================================================================
# 1. GROUND TRUTH VOCABULARY & DETERMINISTIC ASSET GENERATION
# ==============================================================================

NOTEPAD_C1_WORDS = [
    "The", "quick", "brown", "fox", "jumps", "over",
    "the", "lazy", "sleeping", "dog", "near", "river",
    "under", "the", "bright", "sunny", "afternoon", "sky",
]

CANVAS_WORDS = [
    "Canvas", "Matrix", "Vector", "Quantum", "Horizon",
    "Orbit", "Speed", "Frequency", "Pulse", "Telemetry",
]

IMAGE_C1_WORDS = NOTEPAD_C1_WORDS

IMAGE_C6_WORDS = [
    "Save", "Cancel", "Search", "Settings", "Open",
    "Delete", "Submit", "Refresh", "Help", "Close",
]

IMAGE_WORDS = IMAGE_C1_WORDS + IMAGE_C6_WORDS

DOM_WORDS = [
    "DOM", "Heading", "Standard", "Browser", "Text",
    "Modern", "browser", "rendering", "architecture", "pipeline", "verification",
]

ALL_PAGE_TRUTH_WORDS = CANVAS_WORDS + IMAGE_WORDS + DOM_WORDS


def ensure_real_page_assets(real_dir: Path | None = None) -> tuple[Path, Path, str, dict[str, list[str]]]:
    """
    Ensures reports/ocr/real/page.html and fixture.png exist deterministically.
    Returns (html_path, fixture_path, fixture_sha256, truth_words_dict).
    """
    out_dir = real_dir or (PROJECT_ROOT / "reports" / "ocr" / "real")
    out_dir.mkdir(parents=True, exist_ok=True)

    fixture_path = out_dir / "fixture.png"
    html_path = out_dir / "page.html"

    # 1. Render fixture.png if missing
    im = Image.new("RGB", (480, 240), (255, 255, 255))
    dr = ImageDraw.Draw(im)
    try:
        f1 = ImageFont.truetype("segoeui.ttf", 13)
        f2 = ImageFont.truetype("segoeui.ttf", 12)
    except Exception:
        f1 = ImageFont.load_default()
        f2 = ImageFont.load_default()

    lines_c1 = [
        "The quick brown fox jumps over",
        "the lazy sleeping dog near river",
        "under the bright sunny afternoon sky",
    ]
    for i, l in enumerate(lines_c1):
        dr.text((20, 15 + i * 24), l, fill=(0, 0, 0), font=f1)

    labels = ["Save", "Cancel", "Search", "Settings", "Open", "Delete", "Submit", "Refresh", "Help", "Close"]
    start_x, start_y = 15, 115
    btn_w, btn_h = 80, 30
    for i, lbl in enumerate(labels):
        bx = start_x + (i % 5) * (btn_w + 12)
        by = start_y + (i // 5) * (btn_h + 14)
        dr.rectangle([bx, by, bx + btn_w, by + btn_h], fill=(230, 230, 230), outline=(160, 160, 160))
        dr.text((bx + 12, by + 7), lbl, fill=(0, 0, 0), font=f2)

    im.save(fixture_path, format="PNG")

    # 2. Render page.html
    html_content = """<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>OCR REAL PAGE</title>
  <style>
    body {
      margin: 20px;
      font-family: "Segoe UI", Arial, sans-serif;
      background: #ffffff;
      color: #000000;
    }
    #dom-section {
      margin-bottom: 24px;
      padding: 10px;
      background: #fdfdfd;
      border: 1px solid #e0e0e0;
    }
    h1 {
      font-size: 20px;
      margin: 0 0 8px 0;
    }
    p {
      font-size: 15px;
      margin: 0;
    }
    #canvas-section {
      display: block;
      margin-bottom: 24px;
      border: 1px solid #cccccc;
    }
    #image-section {
      display: block;
      border: 1px solid #cccccc;
    }
  </style>
</head>
<body>
  <div id="dom-section">
    <h1>DOM Heading Standard Browser Text</h1>
    <p id="dom-text">Modern browser rendering architecture pipeline verification</p>
  </div>

  <canvas id="canvas-section" width="480" height="120"></canvas>

  <img id="image-section" src="fixture.png" width="480" height="240" alt="OCR Fixture Image" />

  <script>
    const c = document.getElementById('canvas-section');
    const ctx = c.getContext('2d');
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, 480, 120);
    ctx.font = '16px "Segoe UI", Arial, sans-serif';
    ctx.fillStyle = '#000000';
    ctx.fillText('Canvas Matrix Vector Quantum Horizon', 20, 45);
    ctx.fillText('Orbit Speed Frequency Pulse Telemetry', 20, 85);
  </script>
</body>
</html>
"""
    html_path.write_text(html_content, encoding="utf-8")

    # 3. Compute asset sha256
    hasher = hashlib.sha256()
    hasher.update(html_path.read_bytes())
    hasher.update(fixture_path.read_bytes())
    fixture_sha = hasher.hexdigest()

    truth_dict = {
        "canvas": CANVAS_WORDS,
        "image": IMAGE_WORDS,
        "dom": DOM_WORDS,
        "all_page": ALL_PAGE_TRUTH_WORDS,
        "notepad": NOTEPAD_C1_WORDS,
    }
    return html_path, fixture_path, fixture_sha, truth_dict


# ==============================================================================
# 2. HASHING & SYSTEM INTEGRITY
# ==============================================================================

REAL_KIT_V1_HASH_FILE = PROJECT_ROOT / "reports" / "ocr" / "REAL_KIT_HASH.json"
REAL_KIT_V2_HASH_FILE = PROJECT_ROOT / "reports" / "ocr" / "REAL_KIT_HASH_v2.json"


def compute_real_kit_v2_sha256(root: Path | None = None) -> str:
    """Computes SHA-256 of tests/ocr_real_apps_test_v2.py."""
    r = root or PROJECT_ROOT
    f = r / "tests" / "ocr_real_apps_test_v2.py"
    if not f.is_file():
        return ""
    return hashlib.sha256(f.read_bytes()).hexdigest()


def compute_real_kit_v1_sha256(root: Path | None = None) -> str:
    """Computes SHA-256 of tests/ocr_real_apps_test.py."""
    r = root or PROJECT_ROOT
    f = r / "tests" / "ocr_real_apps_test.py"
    if not f.is_file():
        return ""
    return hashlib.sha256(f.read_bytes()).hexdigest()


def check_real_kit_v2_integrity(root: Path | None = None) -> bool:
    """Verifies that kit v2 matches reports/ocr/REAL_KIT_HASH_v2.json."""
    r = root or PROJECT_ROOT
    kit_hash_path = r / "reports" / "ocr" / "REAL_KIT_HASH_v2.json"
    if not kit_hash_path.is_file():
        print(f"FAILED: Real kit v2 hash file not found: {kit_hash_path}")
        return False
    try:
        data = json.loads(kit_hash_path.read_text(encoding="utf-8"))
        expected = data.get("kit_sha256")
        actual = compute_real_kit_v2_sha256(r)
        if actual != expected:
            print(f"FAILED: Real kit v2 SHA mismatch!\n  Expected: {expected}\n  Actual:   {actual}")
            return False
        print("OK: Real kit v2 integrity verified.")
        return True
    except Exception as e:
        print(f"FAILED to verify real kit v2 integrity: {e}")
        return False


def check_real_kit_v1_integrity(root: Path | None = None) -> bool:
    """Verifies that kit v1 matches reports/ocr/REAL_KIT_HASH.json."""
    r = root or PROJECT_ROOT
    kit_hash_path = r / "reports" / "ocr" / "REAL_KIT_HASH.json"
    if not kit_hash_path.is_file():
        print(f"FAILED: Real kit v1 hash file not found: {kit_hash_path}")
        return False
    try:
        data = json.loads(kit_hash_path.read_text(encoding="utf-8"))
        expected = data.get("kit_sha256")
        actual = compute_real_kit_v1_sha256(r)
        if actual != expected:
            print(f"FAILED: Real kit v1 SHA mismatch!\n  Expected: {expected}\n  Actual:   {actual}")
            return False
        print("OK: Real kit v1 integrity verified.")
        return True
    except Exception as e:
        print(f"FAILED to verify real kit v1 integrity: {e}")
        return False


# ==============================================================================
# 3. METRIC & EVALUATION FUNCTIONS (Pure, Headless, Fully Unit-Testable)
# ==============================================================================

def compute_capture_blank(img: Any) -> bool:
    """
    Computes whether a captured window surface bitmap is blank.
    Returns True if:
    - img is None
    - grayscale std-dev < 2.0
    - OR >99.5% of pixels are identical
    """
    if img is None:
        return True
    try:
        gray = img.convert("L")
        stat = ImageStat.Stat(gray)
        stddev = stat.stddev[0]
        if stddev < 2.0:
            return True

        hist = gray.histogram()
        total_pixels = gray.width * gray.height
        if total_pixels == 0:
            return True
        max_identical = max(hist)
        if (max_identical / float(total_pixels)) > 0.995:
            return True

        return False
    except Exception:
        return True


def evaluate_honesty_blank(capture_blank: bool, ocr_status: str, ocr_count: int) -> bool:
    """
    If capture_blank is true, status must NOT be 'available' with an empty list.
    The engine must report unavailable/failed with a reason: otherwise it is a SILENT FALSE NEGATIVE.
    """
    if capture_blank:
        if ocr_status.lower() == "available" and ocr_count == 0:
            return False
    return True


def is_point_in_region(pt: dict[str, int | float], region: dict[str, int | float] | None) -> bool:
    """Checks if point {x, y} is inside bounding box {left, top, right, bottom}."""
    if not region:
        return True
    x = pt.get("x", 0)
    y = pt.get("y", 0)
    return (
        region.get("left", 0) <= x <= region.get("right", 0)
        and region.get("top", 0) <= y <= region.get("bottom", 0)
    )


def filter_elements_by_region(
    elements: list[dict[str, Any]],
    region: dict[str, int | float] | None,
) -> list[dict[str, Any]]:
    """Filters OCR elements to only those whose center lies inside the Region."""
    if not region:
        return list(elements)
    filtered = []
    for el in elements:
        c = el.get("center") or el.get("bounds_center")
        if not c and "bounds" in el:
            b = el["bounds"]
            c = {"x": (b["left"] + b["right"]) // 2, "y": (b["top"] + b["bottom"]) // 2}
        elif not c:
            c = {"x": 0, "y": 0}
        if is_point_in_region(c, region):
            filtered.append(el)
    return filtered


def calculate_word_match(
    truth_words: list[str],
    candidate_tokens: list[str],
) -> dict[str, Any]:
    """
    Greedy matching between truth words and candidate tokens.
    Returns matched count, total truth, recall, matched words list, unmatched truth list.
    """
    norm_truth = [normalize_word(w) for w in truth_words if normalize_word(w)]
    available = list(candidate_tokens)

    matched: list[str] = []
    unmatched: list[str] = []

    for tw in norm_truth:
        if tw in available:
            matched.append(tw)
            available.remove(tw)
        else:
            unmatched.append(tw)

    total_truth = len(norm_truth)
    matched_count = len(matched)
    recall = (matched_count / float(total_truth)) if total_truth > 0 else 1.0

    return {
        "matched_count": matched_count,
        "truth_count": total_truth,
        "recall": round(recall, 4),
        "matched_words": matched,
        "unmatched_truth": unmatched,
    }


def calculate_precision_in_region(
    all_valid_truth_words: list[str],
    ocr_tokens_in_region: list[str],
) -> dict[str, Any]:
    """
    Calculates precision inside the Region against all valid ground truth words for that window.
    """
    valid_norms = {normalize_word(w) for w in all_valid_truth_words if normalize_word(w)}
    total_ocr = len(ocr_tokens_in_region)

    if total_ocr == 0:
        return {
            "ocr_count": 0,
            "matched_count": 0,
            "precision": 1.0 if not valid_norms else 0.0,
        }

    matched_count = sum(1 for tok in ocr_tokens_in_region if tok in valid_norms)
    precision = matched_count / float(total_ocr)
    return {
        "ocr_count": total_ocr,
        "matched_count": matched_count,
        "precision": round(precision, 4),
    }


# ==============================================================================
# 4. K1 - K6 MODULAR REPAIRS
# ==============================================================================

# K1: Region filtering and selection
def filter_and_select_widget_host(
    candidates: list[dict[str, Any]],
    window_rect: dict[str, int],
) -> tuple[dict[str, int], str, list[dict[str, Any]]]:
    """
    K1: Filters candidate RenderWidgetHost children and selects the largest area.
    Discards any not visible, width < 200 or height <= 150.
    Falls back to window rect minus 120 px at top if none qualify.
    Returns (chosen_rect, reason, processed_candidates).
    """
    processed: list[dict[str, Any]] = []
    accepted: list[dict[str, Any]] = []

    for c in candidates:
        item = dict(c)
        r = item.get("rect", {"left": 0, "top": 0, "right": 0, "bottom": 0})
        w = r.get("right", 0) - r.get("left", 0)
        h = r.get("bottom", 0) - r.get("top", 0)
        area = max(0, w) * max(0, h)
        item["width"] = w
        item["height"] = h
        item["area"] = area

        is_vis = bool(item.get("visible", False))
        discard_reason: str | None = None

        if not is_vis:
            discard_reason = "not_visible"
        elif w < 200:
            discard_reason = f"width ({w}) < 200"
        elif h <= 150:
            discard_reason = f"height ({h}) <= 150"

        item["accepted"] = (discard_reason is None)
        item["discard_reason"] = discard_reason
        processed.append(item)

        if item["accepted"]:
            accepted.append(item)

    if accepted:
        chosen = max(accepted, key=lambda x: x["area"])
        reason = f"largest_candidate (w={chosen['width']}, h={chosen['height']}, area={chosen['area']})"
        return chosen["rect"], reason, processed

    print("REGION FALLBACK")
    fallback_rect = {
        "left": window_rect.get("left", 0),
        "top": window_rect.get("top", 0) + 120,
        "right": window_rect.get("right", 0),
        "bottom": window_rect.get("bottom", 0),
    }
    reason = "REGION FALLBACK: window rect minus 120px top"
    return fallback_rect, reason, processed


# K3: Occlusion latency formula
def compute_ocr_added_latency(
    ocr_latencies: list[float],
    base_latencies: list[float],
) -> tuple[float, float, float]:
    """
    K3: ocr_added_latency = median(include_ocr=True) - median(include_ocr=False).
    Returns (ocr_added_latency_ms, median_ocr_latency_ms, median_base_latency_ms).
    """
    med_ocr = statistics.median(ocr_latencies) if ocr_latencies else 0.0
    med_base = statistics.median(base_latencies) if base_latencies else 0.0
    added = max(0.0, med_ocr - med_base)
    return round(added, 2), round(med_ocr, 2), round(med_base, 2)


# K4: Bitmap & word artifacts
def save_captured_bitmap(img: Any, tag: str, case_key: str, out_root: Path | None = None) -> str:
    """Saves the captured surface bitmap to reports/ocr/real/<tag>_img/<case>.png."""
    if img is None:
        return ""
    root = out_root or PROJECT_ROOT
    img_dir = root / "reports" / "ocr" / "real" / f"{tag}_img"
    img_dir.mkdir(parents=True, exist_ok=True)
    out_file = img_dir / f"{case_key}.png"
    try:
        img.save(out_file, format="PNG")
        return str(out_file)
    except Exception as e:
        print(f"Warning: failed to save capture bitmap {out_file}: {e}")
        return ""


def compute_raw_ocr_words(
    all_ocr_elements: list[dict[str, Any]],
    region: dict[str, int | float] | None,
) -> list[dict[str, Any]]:
    """K4: Stores raw OCR words (text, center, inside_region true/false)."""
    raw_words = []
    for el in all_ocr_elements:
        c = el.get("center") or el.get("bounds_center")
        if not c and "bounds" in el:
            b = el["bounds"]
            c = {"x": (b["left"] + b["right"]) // 2, "y": (b["top"] + b["bottom"]) // 2}
        elif not c:
            c = {"x": 0, "y": 0}
        inside = is_point_in_region(c, region)
        raw_words.append({
            "text": str(el.get("name", "")),
            "center": c,
            "inside_region": bool(inside),
        })
    return raw_words


def compute_uia_diff_element_names(base_names: list[str], ocr_names: list[str]) -> list[str]:
    """Computes up to 20 element names that differ between UIA scans."""
    c1 = collections.Counter(base_names)
    c2 = collections.Counter(ocr_names)
    diff = []
    for k in (c1.keys() | c2.keys()):
        if c1[k] != c2[k]:
            diff.append(k)
            if len(diff) >= 20:
                break
    return diff


# K6: Informational UIA bounds filter
def is_bounds_valid_and_onscreen(
    bounds: dict[str, int],
    window_rect: dict[str, int],
    screen_w: int = 1920,
    screen_h: int = 1080,
) -> bool:
    """Checks if bounds lie fully inside window rect and fully on screen."""
    if not bounds:
        return False
    bl, bt = bounds.get("left", 0), bounds.get("top", 0)
    br, bb = bounds.get("right", 0), bounds.get("bottom", 0)
    wl, wt = window_rect.get("left", 0), window_rect.get("top", 0)
    wr, wb = window_rect.get("right", 0), window_rect.get("bottom", 0)

    # Positive area
    if br <= bl or bb <= bt:
        return False
    # Fully inside window rect
    if bl < wl or bt < wt or br > wr or bb > wb:
        return False
    # Fully on screen
    if bl < 0 or bt < 0 or br > screen_w or bb > screen_h:
        return False
    return True


def extract_valid_uia_truth_words(
    walked_nodes: list[dict[str, Any]],
    window_rect: dict[str, int],
    screen_size: tuple[int, int] = (1920, 1080),
) -> list[str]:
    """
    K6: Truth only from UIA elements whose bounds lie fully inside the window rect
    and on screen, with >= 4 letters, deduped.
    """
    screen_w, screen_h = screen_size
    valid_words = set()
    for node in walked_nodes:
        bounds = node.get("bounds")
        if not bounds or not is_bounds_valid_and_onscreen(bounds, window_rect, screen_w, screen_h):
            continue
        raw_name = str(node.get("name", "")).strip()
        for token in re.findall(r"[A-Za-z]{4,}", raw_name):
            norm = normalize_word(token)
            if len(norm) >= 4:
                valid_words.add(norm)
    return sorted(list(valid_words))


# ==============================================================================
# 5. RULE EVALUATION ENGINE (G1 to G6) - K5 Complete Rule Printing
# ==============================================================================

def evaluate_real_apps_rules(case_results: dict[str, Any]) -> tuple[str, list[dict[str, Any]]]:
    """
    Evaluates rules G1 through G6 over case results.
    K5: Ensures every rule produces explicit per-case telemetry.
    Returns: ("ACCEPT" | "REJECT", rules_list).
    """
    rules: list[dict[str, Any]] = []

    # G1: NP, CH, ED: capture_blank == false, or honesty_blank holds when it is true
    g1_errors: list[str] = []
    g1_telemetry: list[str] = []
    for app_key in ["NP", "CH", "ED"]:
        if app_key not in case_results:
            g1_telemetry.append(f"{app_key}=MISSING")
            g1_errors.append(f"{app_key}: MISSING")
            continue
        c = case_results[app_key]
        st = c.get("status", "")
        if st == "NOT_READY":
            g1_telemetry.append(f"{app_key}=NOT_READY")
            g1_errors.append(f"{app_key}: NOT_READY - {c.get('error', 'Page not ready')}")
            continue

        c_blank = c.get("capture_blank", False)
        h_blank = c.get("honesty_blank", True)
        g1_telemetry.append(f"{app_key}(blank={c_blank}, honest={h_blank})")
        if c_blank:
            if not h_blank:
                g1_errors.append(f"{app_key}: SILENT FALSE NEGATIVE (blank capture reported as available with empty elements)")
            else:
                g1_errors.append(f"{app_key}: CAPTURE FAILURE (capture surface is blank; honesty holds)")

    g1_pass = (len(g1_errors) == 0)
    rules.append({
        "rule": "G1",
        "description": "NP, CH, ED: capture_blank == false (or honesty holds on failure)",
        "passed": g1_pass,
        "details": (
            "; ".join(g1_telemetry)
            + (" [PASS]" if g1_pass else f" -> Failures: {'; '.join(g1_errors)}")
        ),
    })

    # G2: recall >= 85% separately for NP, CH-canvas, CH-image, ED-canvas, ED-image
    g2_checks: list[tuple[str, float]] = []
    g2_failures: list[str] = []

    for k in ["NP", "CH", "ED"]:
        c = case_results.get(k, {})
        if c.get("status") == "NOT_READY":
            g2_failures.append(f"{k}: NOT_READY ({c.get('error', 'page not ready')})")

    if "NP" in case_results and case_results["NP"].get("status") != "NOT_READY":
        g2_checks.append(("NP", case_results["NP"].get("recall", 0.0)))
    if "CH" in case_results and case_results["CH"].get("status") != "NOT_READY":
        sub = case_results["CH"].get("subcases", {})
        g2_checks.append(("CH-canvas", sub.get("canvas", {}).get("recall", 0.0)))
        g2_checks.append(("CH-image", sub.get("image", {}).get("recall", 0.0)))
    if "ED" in case_results and case_results["ED"].get("status") != "NOT_READY":
        sub = case_results["ED"].get("subcases", {})
        g2_checks.append(("ED-canvas", sub.get("canvas", {}).get("recall", 0.0)))
        g2_checks.append(("ED-image", sub.get("image", {}).get("recall", 0.0)))

    for name, rec in g2_checks:
        if rec < 0.85:
            g2_failures.append(f"{name} recall={rec*100.0:.1f}% < 85%")

    dom_ch = case_results.get("CH", {}).get("subcases", {}).get("dom", {}).get("recall", 0.0) * 100.0
    dom_ed = case_results.get("ED", {}).get("subcases", {}).get("dom", {}).get("recall", 0.0) * 100.0
    dom_note = f" (DOM reported: CH={dom_ch:.0f}%, ED={dom_ed:.0f}%)"

    g2_pass = (len(g2_failures) == 0) and (len(g2_checks) >= 5)
    rules.append({
        "rule": "G2",
        "description": "recall >= 85% for NP, CH-canvas, CH-image, ED-canvas, ED-image",
        "passed": g2_pass,
        "details": (
            ", ".join(f"{name}={rec*100.0:.1f}%" for name, rec in g2_checks)
            + dom_note
            + (" [PASS]" if g2_pass else f" -> Failures: {'; '.join(g2_failures)}")
        ),
    })

    # G3: precision >= 90% inside Region for those cases
    g3_checks: list[tuple[str, float]] = []
    g3_failures: list[str] = []
    for app_key in ["NP", "CH", "ED"]:
        if app_key in case_results:
            c = case_results[app_key]
            if c.get("status") == "NOT_READY":
                g3_failures.append(f"{app_key}: NOT_READY ({c.get('error')})")
            else:
                prec = c.get("precision", 0.0)
                g3_checks.append((app_key, prec))
                if prec < 0.90:
                    g3_failures.append(f"{app_key} prec={prec*100.0:.1f}% < 90%")
        else:
            g3_failures.append(f"{app_key}=MISSING")

    g3_pass = (len(g3_failures) == 0) and (len(g3_checks) >= 3)
    rules.append({
        "rule": "G3",
        "description": "precision >= 90% inside Region for NP, CH, ED",
        "passed": g3_pass,
        "details": (
            ", ".join(f"{name}={p*100.0:.1f}%" for name, p in g3_checks)
            + (" [PASS]" if g3_pass else f" -> Failures: {'; '.join(g3_failures)}")
        ),
    })

    # G4: occluder_leaks == 0
    occ_case = case_results.get("OCC", {})
    occ_leaks = occ_case.get("occluder_leaks", 0)
    g4_pass = (occ_leaks == 0) and ("OCC" in case_results)
    rules.append({
        "rule": "G4",
        "description": "Notepad occlusion occluder_leaks == 0",
        "passed": g4_pass,
        "details": f"Occluder leaks = {occ_leaks} (required 0)",
    })

    # G5: ocr_added_latency <= 1500 ms, RAM delta <= 150 MB
    gating_keys = ["NP", "CH", "ED", "OCC"]
    lat_map: dict[str, float] = {}
    ram_map: dict[str, float] = {}
    for k in gating_keys:
        if k in case_results:
            lat_map[k] = case_results[k].get("ocr_added_latency_ms", 0.0)
            ram_map[k] = case_results[k].get("ram_delta_mb", 0.0)

    max_lat = max(lat_map.values(), default=0.0)
    max_ram = max(ram_map.values(), default=0.0)
    g5_pass = (max_lat <= 1500.0) and (max_ram <= 150.0) and len(lat_map) >= 4
    lat_str = ", ".join(f"{k}={v:.1f}ms" for k, v in lat_map.items())
    ram_str = ", ".join(f"{k}={v:.1f}MB" for k, v in ram_map.items())
    rules.append({
        "rule": "G5",
        "description": "ocr_added_latency <= 1500 ms, RAM delta <= 150 MB",
        "passed": g5_pass,
        "details": f"Added latency [{lat_str}] (max={max_lat:.1f} ms <= 1500 ms); RAM delta [{ram_str}] (max={max_ram:.1f} MB <= 150 MB)",
    })

    # G6: uia_unchanged == true across all evaluated windows
    g6_details: list[str] = []
    uia_fails: list[str] = []
    for k in gating_keys:
        if k in case_results:
            c = case_results[k]
            unchanged = c.get("uia_unchanged", False)
            f_cnt = c.get("uia_false_count", "-")
            t_cnt = c.get("uia_true_count", "-")
            g6_details.append(f"{k}(false={f_cnt}, true={t_cnt})")
            if not unchanged:
                diff_names = c.get("uia_diff_element_names", [])
                diff_summary = f"diffs={diff_names[:5]}" if diff_names else "count mismatch"
                uia_fails.append(f"{k}: {diff_summary}")
        else:
            uia_fails.append(f"{k}=MISSING")

    g6_pass = (len(uia_fails) == 0) and len(g6_details) >= 4
    rules.append({
        "rule": "G6",
        "description": "uia_unchanged == true across all evaluated windows",
        "passed": g6_pass,
        "details": (
            ", ".join(g6_details)
            + (" [PASS]" if g6_pass else f" -> Mismatch in: {'; '.join(uia_fails)}")
        ),
    })

    overall_accept = all(r["passed"] for r in rules)
    return ("ACCEPT" if overall_accept else "REJECT"), rules


# ==============================================================================
# 6. WINDOW CONTROLLERS & LIVE APP TEST RUNNERS
# ==============================================================================

def find_notepad_edit_control(hwnd: int) -> int:
    """Finds Edit control HWND inside Notepad window."""
    import win32gui
    edit_hwnd = 0

    def _cb(h: int, _: Any) -> bool:
        nonlocal edit_hwnd
        cls = win32gui.GetClassName(h).lower()
        if cls in ("edit", "richeditd2dpt", "notepadtextbox"):
            edit_hwnd = h
            return False
        return True

    try:
        win32gui.EnumChildWindows(hwnd, _cb, None)
    except Exception:
        pass
    return edit_hwnd


def enumerate_render_widget_candidates(hwnd: int) -> list[dict[str, Any]]:
    """K1: Enumerates ALL Chrome_RenderWidgetHostHWND children inside Chrome or Edge."""
    import win32gui
    candidates: list[dict[str, Any]] = []

    def _cb(h: int, _: Any) -> bool:
        try:
            cls = win32gui.GetClassName(h)
            if "renderwidgethost" in cls.lower():
                is_vis = bool(win32gui.IsWindowVisible(h))
                r = win32gui.GetWindowRect(h)
                rect_dict = {"left": r[0], "top": r[1], "right": r[2], "bottom": r[3]}
                w = rect_dict["right"] - rect_dict["left"]
                h_dim = rect_dict["bottom"] - rect_dict["top"]
                candidates.append({
                    "hwnd": h,
                    "class": cls,
                    "visible": is_vis,
                    "rect": rect_dict,
                    "width": w,
                    "height": h_dim,
                    "area": max(0, w) * max(0, h_dim),
                })
        except Exception:
            pass
        return True

    try:
        win32gui.EnumChildWindows(hwnd, _cb, None)
    except Exception:
        pass
    return candidates


def get_rect_dict(hwnd: int) -> dict[str, int]:
    """Retrieves bounding rect as dictionary."""
    import win32gui
    r = win32gui.GetWindowRect(hwnd)
    return {"left": r[0], "top": r[1], "right": r[2], "bottom": r[3]}


def run_case_notepad(tag: str, repeats: int = 3) -> tuple[dict[str, Any], int]:
    """
    Runs Case NP: Notepad with C1 text set via WM_SETTEXT on its Edit control.
    """
    import win32gui

    print("\n[*] Testing Case NP: Notepad...")
    snapshot = snapshot_visible_top_level_hwnds()

    proc = subprocess.Popen(["notepad.exe"])
    hwnd, _ = find_new_app_window("Notepad", snapshot, timeout_sec=6.0)
    if not hwnd:
        return {"status": "launch_failed", "error": "Could not locate opened Notepad window"}, 0

    edit_hwnd = find_notepad_edit_control(hwnd)
    if not edit_hwnd:
        edit_hwnd = hwnd

    # Set text via WM_SETTEXT (0x000C)
    text_content = "\r\n".join([
        "The quick brown fox jumps over",
        "the lazy sleeping dog near river",
        "under the bright sunny afternoon sky",
    ])
    win32gui.SendMessage(edit_hwnd, 0x000C, 0, text_content)
    time.sleep(0.3)

    region = get_rect_dict(edit_hwnd)

    # Baseline call
    base_t0 = time.perf_counter()
    base_obs = observe(scope=hwnd, include_ocr=False, force_refresh=True)
    base_lat_ms = (time.perf_counter() - base_t0) * 1000.0
    base_elements = [e for e in base_obs.get("elements", []) if e.get("source") != "ocr"]
    base_uia_count = len(base_elements)

    ocr_latencies: list[float] = []
    base_latencies: list[float] = []
    ram_deltas: list[float] = []
    uia_history: list[dict[str, Any]] = []
    all_differing_names: list[str] = []
    last_obs: dict[str, Any] = {}
    last_img: Any = None

    for call_idx in range(repeats + 1):
        t_b0 = time.perf_counter()
        b_obs = observe(scope=hwnd, include_ocr=False, force_refresh=True)
        b_dt = (time.perf_counter() - t_b0) * 1000.0
        b_non_ocr = [e for e in b_obs.get("elements", []) if e.get("source") != "ocr"]

        r0 = get_process_ram_mb()
        t0 = time.perf_counter()
        obs = observe(scope=hwnd, include_ocr=True, force_refresh=True)
        dt_ms = (time.perf_counter() - t0) * 1000.0
        r1 = get_process_ram_mb()
        o_non_ocr = [e for e in obs.get("elements", []) if e.get("source") != "ocr"]

        img, _ = _capture_window_surface(hwnd)

        if call_idx > 0:
            ocr_latencies.append(dt_ms)
            base_latencies.append(b_dt)
            ram_deltas.append(max(0.0, r1 - r0))
            last_obs = obs
            last_img = img

            b_names = [str(e.get("name", "")) for e in b_non_ocr]
            o_names = [str(e.get("name", "")) for e in o_non_ocr]
            diff_names = compute_uia_diff_element_names(b_names, o_names)
            for d in diff_names:
                if d not in all_differing_names and len(all_differing_names) < 20:
                    all_differing_names.append(d)

            uia_history.append({
                "repeat": call_idx,
                "include_ocr_false_count": len(b_non_ocr),
                "include_ocr_true_count": len(o_non_ocr),
                "diff_count": len(o_non_ocr) - len(b_non_ocr),
                "differing_names": diff_names,
            })

    added_lat, med_ocr_lat, med_base_lat = compute_ocr_added_latency(ocr_latencies, base_latencies)
    med_ram = statistics.median(ram_deltas) if ram_deltas else 0.0

    c_blank = compute_capture_blank(last_img)
    img_path = save_captured_bitmap(last_img, tag, "NP")

    all_ocr_elements = [e for e in last_obs.get("elements", []) if e.get("source") == "ocr"]
    ocr_in_region = filter_elements_by_region(all_ocr_elements, region)
    ocr_tokens = [normalize_word(e.get("name", "")) for e in ocr_in_region if normalize_word(e.get("name", ""))]

    match_res = calculate_word_match(NOTEPAD_C1_WORDS, ocr_tokens)
    prec_res = calculate_precision_in_region(NOTEPAD_C1_WORDS, ocr_tokens)
    raw_ocr_words = compute_raw_ocr_words(all_ocr_elements, region)

    uia_unchanged = (len(all_differing_names) == 0 and all(h["diff_count"] == 0 for h in uia_history))
    h_blank = evaluate_honesty_blank(
        c_blank,
        last_obs.get("scene", {}).get("ocr_status", "unavailable"),
        len(all_ocr_elements),
    )

    result = {
        "case": "NP",
        "app": "Notepad",
        "status": last_obs.get("scene", {}).get("ocr_status", "available"),
        "capture_method": last_obs.get("scene", {}).get("capture_method", "none"),
        "capture_blank": c_blank,
        "honesty_blank": h_blank,
        "matched_count": match_res["matched_count"],
        "truth_count": match_res["truth_count"],
        "recall": match_res["recall"],
        "precision": prec_res["precision"],
        "ocr_added_latency_ms": added_lat,
        "latency_ms": med_ocr_lat,
        "baseline_latency_ms": med_base_lat,
        "ram_delta_mb": round(med_ram, 2),
        "uia_unchanged": uia_unchanged,
        "uia_false_count": uia_history[-1]["include_ocr_false_count"] if uia_history else base_uia_count,
        "uia_true_count": uia_history[-1]["include_ocr_true_count"] if uia_history else base_uia_count,
        "uia_counts_history": uia_history,
        "uia_diff_element_names": all_differing_names,
        "region": region,
        "captured_image_path": img_path,
        "raw_ocr_words": raw_ocr_words,
        "matched_words": match_res["matched_words"],
        "unmatched_truth": match_res["unmatched_truth"],
    }
    return result, hwnd


def run_case_occlusion(notepad_hwnd: int, tag: str, repeats: int = 3) -> dict[str, Any]:
    """
    K3: Runs Case OCC: Notepad occlusion test.
    ocr_added_latency = median(include_ocr=True) - median(include_ocr=False) on SAME window
    with occluder present.
    """
    import tkinter as tk
    import win32gui

    print("\n[*] Testing Case OCC: Notepad Occlusion...")
    if not notepad_hwnd or not win32gui.IsWindow(notepad_hwnd):
        return {"status": "failed", "occluder_leaks": 0, "error": "Notepad hwnd invalid"}

    np_rect = get_rect_dict(notepad_hwnd)
    occ_w = (np_rect["right"] - np_rect["left"]) // 2
    occ_h = (np_rect["bottom"] - np_rect["top"]) // 2
    occ_x = np_rect["left"] + 20
    occ_y = np_rect["top"] + 20

    root = tk.Tk()
    root.title("OCCLUDER")
    root.geometry(f"{occ_w}x{occ_h}+{occ_x}+{occ_y}")
    root.configure(bg="#ffff00")
    lbl = tk.Label(root, text="OCCLUDERWORD", font=("Segoe UI", 22, "bold"), bg="#ffff00", fg="#ff0000")
    lbl.pack(expand=True, fill="both")
    root.update()
    time.sleep(0.4)

    ocr_latencies: list[float] = []
    base_latencies: list[float] = []
    uia_history: list[dict[str, Any]] = []
    all_differing_names: list[str] = []
    last_obs: dict[str, Any] = {}
    last_img: Any = None

    for call_idx in range(repeats + 1):
        t_b0 = time.perf_counter()
        b_obs = observe(scope=notepad_hwnd, include_ocr=False, force_refresh=True)
        b_dt = (time.perf_counter() - t_b0) * 1000.0
        b_non_ocr = [e for e in b_obs.get("elements", []) if e.get("source") != "ocr"]

        t0 = time.perf_counter()
        obs = observe(scope=notepad_hwnd, include_ocr=True, force_refresh=True)
        dt_ms = (time.perf_counter() - t0) * 1000.0
        o_non_ocr = [e for e in obs.get("elements", []) if e.get("source") != "ocr"]

        img, _ = _capture_window_surface(notepad_hwnd)

        if call_idx > 0:
            ocr_latencies.append(dt_ms)
            base_latencies.append(b_dt)
            last_obs = obs
            last_img = img

            b_names = [str(e.get("name", "")) for e in b_non_ocr]
            o_names = [str(e.get("name", "")) for e in o_non_ocr]
            diff_names = compute_uia_diff_element_names(b_names, o_names)
            for d in diff_names:
                if d not in all_differing_names and len(all_differing_names) < 20:
                    all_differing_names.append(d)

            uia_history.append({
                "repeat": call_idx,
                "include_ocr_false_count": len(b_non_ocr),
                "include_ocr_true_count": len(o_non_ocr),
                "diff_count": len(o_non_ocr) - len(b_non_ocr),
                "differing_names": diff_names,
            })

    added_lat, med_ocr_lat, med_base_lat = compute_ocr_added_latency(ocr_latencies, base_latencies)

    scene = last_obs.get("scene", {})
    target_hwnd_reported = scene.get("target_hwnd", notepad_hwnd)
    target_title_reported = scene.get("foreground_title") or scene.get("active_window", "")

    all_ocr = [e for e in last_obs.get("elements", []) if e.get("source") == "ocr"]
    occ_leaks = sum(1 for e in all_ocr if "occluderword" in str(e.get("name", "")).lower())

    img_path = save_captured_bitmap(last_img, tag, "OCC")
    raw_ocr_words = compute_raw_ocr_words(all_ocr, np_rect)

    root.destroy()

    uia_unchanged = (len(all_differing_names) == 0 and all(h["diff_count"] == 0 for h in uia_history))

    return {
        "case": "OCC",
        "app": "Notepad Occlusion",
        "occluder_leaks": occ_leaks,
        "ocr_added_latency_ms": added_lat,
        "latency_ms": med_ocr_lat,
        "baseline_latency_ms": med_base_lat,
        "target_hwnd": target_hwnd_reported,
        "target_title": target_title_reported,
        "ram_delta_mb": 0.0,
        "uia_unchanged": uia_unchanged,
        "uia_false_count": uia_history[-1]["include_ocr_false_count"] if uia_history else 0,
        "uia_true_count": uia_history[-1]["include_ocr_true_count"] if uia_history else 0,
        "uia_counts_history": uia_history,
        "uia_diff_element_names": all_differing_names,
        "status": "available",
        "captured_image_path": img_path,
        "raw_ocr_words": raw_ocr_words,
    }


def poll_browser_page_ready(
    hwnd: int,
    app_name: str,
    timeout_sec: float = 10.0,
) -> tuple[bool, dict[str, int], str, list[dict[str, Any]], dict[str, int]]:
    """
    K2: Polls up to timeout_sec until:
    1. Window title contains 'OCR REAL PAGE'
    2. Candidate render widget host passes K1 filter (not fallback).
    Returns (ready, chosen_rect, reason, all_candidate_rects, window_rect).
    """
    import win32gui

    start = time.time()
    last_chosen: dict[str, int] = {}
    last_reason: str = "init"
    last_candidates: list[dict[str, Any]] = []
    last_wrect: dict[str, int] = {}

    while time.time() - start < timeout_sec:
        try:
            info = get_window_info(hwnd)
            title = (info.get("title") or "").upper()
            w_rect = get_rect_dict(hwnd)
            last_wrect = w_rect

            if "OCR REAL PAGE" in title:
                cands = enumerate_render_widget_candidates(hwnd)
                chosen_rect, reason, processed = filter_and_select_widget_host(cands, w_rect)
                last_chosen = chosen_rect
                last_reason = reason
                last_candidates = processed

                # Ready if at least one candidate was accepted
                if any(c.get("accepted") for c in processed):
                    return True, chosen_rect, reason, processed, w_rect
        except Exception:
            pass
        time.sleep(0.3)

    return False, last_chosen, last_reason, last_candidates, last_wrect


def run_case_browser(
    case_key: str,
    app_name: str,
    page_url: str,
    truth_dict: dict[str, list[str]],
    tag: str,
    repeats: int = 3,
) -> dict[str, Any]:
    """
    Runs Case CH (Chrome) or ED (Edge) with K1 region and K2 page ready polling.
    """
    import win32gui

    print(f"\n[*] Testing Case {case_key}: {app_name}...")
    bin_names = ["chrome.exe"] if case_key == "CH" else ["msedge.exe"]
    bin_path = find_browser_binary(bin_names)
    if not bin_path:
        return {
            "case": case_key,
            "app": app_name,
            "status": "skipped_binary_not_found",
            "capture_blank": False,
            "honesty_blank": True,
            "recall": 0.0,
            "precision": 0.0,
            "subcases": {},
            "error": f"Binary not found: {bin_names}",
        }

    temp_dir = tempfile.mkdtemp(prefix=f"goku_ocr_{case_key.lower()}_")
    snapshot = snapshot_visible_top_level_hwnds()

    proc = subprocess.Popen([
        bin_path,
        f"--user-data-dir={temp_dir}",
        "--no-first-run",
        "--no-default-browser-check",
        "--force-renderer-accessibility",
        page_url,
    ])

    hwnd = 0
    start = time.time()
    while time.time() - start < 8.0:
        found_hwnds: list[int] = []

        def _cb(h: int, _: Any) -> bool:
            if h in snapshot:
                return True
            try:
                if win32gui.IsWindowVisible(h) and not win32gui.IsIconic(h):
                    info = get_window_info(h)
                    title = (info.get("title") or "").upper()
                    if matches_app_identity(info, app_name) and "OCR REAL PAGE" in title:
                        found_hwnds.append(h)
            except Exception:
                pass
            return True

        win32gui.EnumWindows(_cb, None)
        if found_hwnds:
            hwnd = found_hwnds[0]
            break
        time.sleep(0.3)

    if not hwnd:
        try:
            proc.terminate()
        except Exception:
            pass
        return {
            "case": case_key,
            "app": app_name,
            "status": "launch_failed",
            "capture_blank": False,
            "honesty_blank": True,
            "recall": 0.0,
            "precision": 0.0,
            "subcases": {},
            "error": f"Could not locate opened {app_name} window matching title 'OCR REAL PAGE'",
        }

    # K2: Poll up to 10s for page ready & valid K1 widget host
    ready, chosen_region, reason, candidates, w_rect = poll_browser_page_ready(hwnd, app_name, timeout_sec=10.0)
    if not ready:
        try:
            win32gui.PostMessage(hwnd, 0x0010, 0, 0)
            proc.terminate()
        except Exception:
            pass
        return {
            "case": case_key,
            "app": app_name,
            "status": "NOT_READY",
            "capture_blank": False,
            "honesty_blank": True,
            "recall": 0.0,
            "precision": 0.0,
            "subcases": {},
            "window_rect": w_rect,
            "all_candidate_rects": candidates,
            "chosen_rect": chosen_region,
            "region": chosen_region,
            "region_reason": reason,
            "error": f"Page timeout: title or valid K1 render widget not ready within 10s ({reason})",
        }

    print(f"    [+] K1 Chosen Region: {chosen_region} ({reason})")

    # Baseline call
    base_t0 = time.perf_counter()
    base_obs = observe(scope=hwnd, include_ocr=False, force_refresh=True)
    base_lat_ms = (time.perf_counter() - base_t0) * 1000.0
    base_elements = [e for e in base_obs.get("elements", []) if e.get("source") != "ocr"]
    base_uia_count = len(base_elements)

    ocr_latencies: list[float] = []
    base_latencies: list[float] = []
    ram_deltas: list[float] = []
    uia_history: list[dict[str, Any]] = []
    all_differing_names: list[str] = []
    last_obs: dict[str, Any] = {}
    last_img: Any = None

    for call_idx in range(repeats + 1):
        t_b0 = time.perf_counter()
        b_obs = observe(scope=hwnd, include_ocr=False, force_refresh=True)
        b_dt = (time.perf_counter() - t_b0) * 1000.0
        b_non_ocr = [e for e in b_obs.get("elements", []) if e.get("source") != "ocr"]

        r0 = get_process_ram_mb()
        t0 = time.perf_counter()
        obs = observe(scope=hwnd, include_ocr=True, force_refresh=True)
        dt_ms = (time.perf_counter() - t0) * 1000.0
        r1 = get_process_ram_mb()
        o_non_ocr = [e for e in obs.get("elements", []) if e.get("source") != "ocr"]

        img, _ = _capture_window_surface(hwnd)

        if call_idx > 0:
            ocr_latencies.append(dt_ms)
            base_latencies.append(b_dt)
            ram_deltas.append(max(0.0, r1 - r0))
            last_obs = obs
            last_img = img

            b_names = [str(e.get("name", "")) for e in b_non_ocr]
            o_names = [str(e.get("name", "")) for e in o_non_ocr]
            diff_names = compute_uia_diff_element_names(b_names, o_names)
            for d in diff_names:
                if d not in all_differing_names and len(all_differing_names) < 20:
                    all_differing_names.append(d)

            uia_history.append({
                "repeat": call_idx,
                "include_ocr_false_count": len(b_non_ocr),
                "include_ocr_true_count": len(o_non_ocr),
                "diff_count": len(o_non_ocr) - len(b_non_ocr),
                "differing_names": diff_names,
            })

    added_lat, med_ocr_lat, med_base_lat = compute_ocr_added_latency(ocr_latencies, base_latencies)
    med_ram = statistics.median(ram_deltas) if ram_deltas else 0.0

    c_blank = compute_capture_blank(last_img)
    img_path = save_captured_bitmap(last_img, tag, case_key)

    all_ocr_elements = [e for e in last_obs.get("elements", []) if e.get("source") == "ocr"]
    ocr_in_region = filter_elements_by_region(all_ocr_elements, chosen_region)
    ocr_tokens = [normalize_word(e.get("name", "")) for e in ocr_in_region if normalize_word(e.get("name", ""))]

    canvas_match = calculate_word_match(truth_dict["canvas"], ocr_tokens)
    image_match = calculate_word_match(truth_dict["image"], ocr_tokens)
    dom_match = calculate_word_match(truth_dict["dom"], ocr_tokens)

    prec_res = calculate_precision_in_region(truth_dict["all_page"], ocr_tokens)
    raw_ocr_words = compute_raw_ocr_words(all_ocr_elements, chosen_region)

    uia_unchanged = (len(all_differing_names) == 0 and all(h["diff_count"] == 0 for h in uia_history))
    h_blank = evaluate_honesty_blank(
        c_blank,
        last_obs.get("scene", {}).get("ocr_status", "unavailable"),
        len(all_ocr_elements),
    )

    # Cleanup instance
    try:
        win32gui.PostMessage(hwnd, 0x0010, 0, 0)
        time.sleep(0.5)
    except Exception:
        pass
    try:
        proc.terminate()
    except Exception:
        pass

    return {
        "case": case_key,
        "app": app_name,
        "status": last_obs.get("scene", {}).get("ocr_status", "available"),
        "capture_method": last_obs.get("scene", {}).get("capture_method", "none"),
        "capture_blank": c_blank,
        "honesty_blank": h_blank,
        "precision": prec_res["precision"],
        "subcases": {
            "canvas": canvas_match,
            "image": image_match,
            "dom": dom_match,
        },
        "ocr_added_latency_ms": added_lat,
        "latency_ms": med_ocr_lat,
        "baseline_latency_ms": med_base_lat,
        "ram_delta_mb": round(med_ram, 2),
        "uia_unchanged": uia_unchanged,
        "uia_false_count": uia_history[-1]["include_ocr_false_count"] if uia_history else base_uia_count,
        "uia_true_count": uia_history[-1]["include_ocr_true_count"] if uia_history else base_uia_count,
        "uia_counts_history": uia_history,
        "uia_diff_element_names": all_differing_names,
        "window_rect": w_rect,
        "all_candidate_rects": candidates,
        "chosen_rect": chosen_region,
        "region": chosen_region,
        "region_reason": reason,
        "captured_image_path": img_path,
        "raw_ocr_words": raw_ocr_words,
    }


def run_case_informational(
    case_key: str,
    app_name: str,
    launch_cmd: list[str] | str,
    tag: str,
    repeats: int = 2,
) -> dict[str, Any]:
    """
    K6: Runs Case CA (Calculator) or ST (Settings) (Informational only).
    Truth only from on-screen, in-window UIA elements (>= 4 letters, deduped).
    Flags truth < 5 words as TRUTH TOO SMALL (not evaluated).
    Computes capture_blank.
    """
    import win32gui

    print(f"\n[*] Testing Informational Case {case_key}: {app_name} (with cold-start frame caveat)...")
    snapshot = snapshot_visible_top_level_hwnds()

    proc = None
    if isinstance(launch_cmd, list):
        proc = subprocess.Popen(launch_cmd)
    else:
        os.system(launch_cmd)

    hwnd, _ = find_new_app_window(app_name, snapshot, timeout_sec=5.0)
    if not hwnd:
        matches = find_matching_visible_windows(app_name)
        if matches:
            hwnd = matches[0].get("hwnd", 0)

    if not hwnd:
        return {
            "case": case_key,
            "app": app_name,
            "informational": True,
            "status": "launch_failed",
            "caveat": "UWP cold-start frame caveat",
        }

    w_rect = get_rect_dict(hwnd)
    screen_sz = get_screen_size()
    uia_oracle = init_uia_oracle()
    walked_nodes = walk_uia_tree(uia_oracle, hwnd, max_nodes=100, max_depth=5)

    deduped_truth = extract_valid_uia_truth_words(walked_nodes, w_rect, screen_sz)
    print(f"    [+] K6 On-screen In-window Truth size: {len(deduped_truth)} words")

    img, _ = _capture_window_surface(hwnd)
    c_blank = compute_capture_blank(img)
    img_path = save_captured_bitmap(img, tag, case_key)

    t0 = time.perf_counter()
    obs = observe(scope=hwnd, include_ocr=True, force_refresh=True)
    dt_ms = (time.perf_counter() - t0) * 1000.0

    all_ocr = [e for e in obs.get("elements", []) if e.get("source") == "ocr"]
    ocr_tokens = [normalize_word(e.get("name", "")) for e in all_ocr if normalize_word(e.get("name", ""))]
    raw_ocr_words = compute_raw_ocr_words(all_ocr, w_rect)

    # Cleanup
    try:
        win32gui.PostMessage(hwnd, 0x0010, 0, 0)
        time.sleep(0.4)
    except Exception:
        pass
    if proc:
        try:
            proc.terminate()
        except Exception:
            pass

    if len(deduped_truth) < 5:
        print("    [!] TRUTH TOO SMALL (not evaluated)")
        return {
            "case": case_key,
            "app": app_name,
            "informational": True,
            "status": "TRUTH TOO SMALL (not evaluated)",
            "capture_method": obs.get("scene", {}).get("capture_method", "none"),
            "capture_blank": c_blank,
            "truth_count": len(deduped_truth),
            "matched_count": 0,
            "recall": 0.0,
            "latency_ms": round(dt_ms, 2),
            "caveat": "UWP cold-start frame caveat",
            "captured_image_path": img_path,
            "raw_ocr_words": raw_ocr_words,
        }

    match_res = calculate_word_match(deduped_truth, ocr_tokens)

    return {
        "case": case_key,
        "app": app_name,
        "informational": True,
        "status": obs.get("scene", {}).get("ocr_status", "available"),
        "capture_method": obs.get("scene", {}).get("capture_method", "none"),
        "capture_blank": c_blank,
        "truth_count": len(deduped_truth),
        "matched_count": match_res["matched_count"],
        "recall": match_res["recall"],
        "latency_ms": round(dt_ms, 2),
        "caveat": "UWP cold-start frame caveat",
        "captured_image_path": img_path,
        "raw_ocr_words": raw_ocr_words,
    }


# ==============================================================================
# 7. SUITE RUNNER & TABLE FORMATTER
# ==============================================================================

def print_real_apps_table(case_results: dict[str, Any]) -> None:
    """Prints structured Markdown table of Real Apps OCR telemetry."""
    headers = [
        "Case", "App", "Gating?", "Blank?", "Matched / Truth",
        "Recall", "Prec (Region)", "Added Latency", "RAM Delta", "Status"
    ]
    print("\n## Real Apps OCR Telemetry Table (v2)")
    print("| " + " | ".join(headers) + " |")
    print("|" + "|".join(["---"] * len(headers)) + "|")

    for k in ["NP", "CH", "ED", "OCC", "CA", "ST"]:
        if k not in case_results:
            continue
        c = case_results[k]
        app_name = c.get("app", k)
        is_info = c.get("informational", False)
        gating_str = "No (Info)" if is_info else "YES"

        blank_str = str(c.get("capture_blank", "N/A"))
        matched = c.get("matched_count", "-")
        truth = c.get("truth_count", "-")

        rec_str = f"{c.get('recall', 0.0)*100.0:.1f}%" if "recall" in c else "-"
        prec_str = f"{c.get('precision', 0.0)*100.0:.1f}%" if "precision" in c else "-"
        lat_str = f"{c.get('ocr_added_latency_ms', c.get('latency_ms', 0.0)):.1f} ms"
        ram_str = f"{c.get('ram_delta_mb', 0.0):.1f} MB" if "ram_delta_mb" in c else "-"
        st = c.get("status", "N/A")

        if k in ("CH", "ED") and "subcases" in c:
            sub = c["subcases"]
            c_rec = sub.get("canvas", {}).get("recall", 0.0) * 100.0
            i_rec = sub.get("image", {}).get("recall", 0.0) * 100.0
            d_rec = sub.get("dom", {}).get("recall", 0.0) * 100.0
            rec_str = f"C:{c_rec:.0f}% I:{i_rec:.0f}% (D:{d_rec:.0f}%)"
            matched = f"{sub.get('canvas', {}).get('matched_count', 0)}+{sub.get('image', {}).get('matched_count', 0)}"
            truth = f"{sub.get('canvas', {}).get('truth_count', 0)}+{sub.get('image', {}).get('truth_count', 0)}"

        print(
            f"| {k} | {app_name} | {gating_str} | {blank_str} | {matched} / {truth} | "
            f"{rec_str} | {prec_str} | {lat_str} | {ram_str} | {st} |"
        )
    print("")


def print_rules_summary(verdict: str, rules: list[dict[str, Any]]) -> None:
    """K5: Always prints every rule G1..G6 header and detail line."""
    print("=" * 64)
    print(f"STAGE 1 TASK 1.2c REAL APPS OCR VERDICT: {verdict}")
    print("=" * 64)
    for r in rules:
        status_str = "PASS" if r["passed"] else "FAIL"
        print(f"[{status_str}] {r['rule']}: {r['description']}")
        print(f"       -> {r['details']}")
    print("-" * 64)
    print(f"FINAL RESULT: {verdict}")
    print("=" * 64)


def run_real_apps_suite(
    tag: str = "real2",
    repeats: int = 3,
    check_kit: bool = False,
) -> dict[str, Any]:
    """Executes the full Real Apps OCR test suite v2."""
    scale_pct = get_display_scale_pct()
    if scale_pct != 100:
        sys.exit(f"REFUSED: Level Real Apps requires 100% display scaling (detected {scale_pct}%). Please adjust Windows Settings.")

    kit_sha = compute_real_kit_v2_sha256()
    engine_sha = compute_engine_sha256()

    if check_kit and REAL_KIT_V2_HASH_FILE.is_file():
        kit_data = json.loads(REAL_KIT_V2_HASH_FILE.read_text(encoding="utf-8"))
        if kit_sha != kit_data.get("kit_sha256"):
            sys.exit("REFUSED: Kit v2 hash mismatch in reports/ocr/REAL_KIT_HASH_v2.json")

    html_p, fix_p, fix_sha, truth_dict = ensure_real_page_assets()
    page_url = html_p.resolve().as_uri()

    case_results: dict[str, Any] = {}

    # Case NP: Notepad & Case OCC: Occlusion
    np_res, np_hwnd = run_case_notepad(tag=tag, repeats=repeats)
    case_results["NP"] = np_res

    if np_hwnd:
        occ_res = run_case_occlusion(np_hwnd, tag=tag, repeats=repeats)
        case_results["OCC"] = occ_res
        try:
            import win32gui
            win32gui.PostMessage(np_hwnd, 0x0010, 0, 0)
        except Exception:
            pass

    # Case CH: Chrome
    ch_res = run_case_browser("CH", "Chrome", page_url, truth_dict, tag=tag, repeats=repeats)
    case_results["CH"] = ch_res

    # Case ED: Edge
    ed_res = run_case_browser("ED", "Edge", page_url, truth_dict, tag=tag, repeats=repeats)
    case_results["ED"] = ed_res

    # Informational Cases: CA & ST
    ca_res = run_case_informational("CA", "Calculator", ["calc.exe"], tag=tag, repeats=1)
    case_results["CA"] = ca_res

    st_res = run_case_informational("ST", "Settings", "start ms-settings:", tag=tag, repeats=1)
    case_results["ST"] = st_res

    verdict, rules = evaluate_real_apps_rules(case_results)

    print_real_apps_table(case_results)
    print_rules_summary(verdict, rules)

    payload = {
        "tag": tag,
        "suite": "real_apps_v2",
        "verdict": verdict,
        "kit_sha256": kit_sha,
        "engine_sha256": engine_sha,
        "fixture_sha256": fix_sha,
        "python_version": platform.python_version(),
        "scale": f"{scale_pct}%",
        "repeats": repeats,
        "cases": case_results,
        "rules": rules,
    }

    out_dir = PROJECT_ROOT / "reports" / "ocr" / "real"
    out_dir.mkdir(parents=True, exist_ok=True)
    out_file = out_dir / f"{tag}.json"
    out_file.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    print(f"[+] Successfully wrote report to {out_file}")

    return payload


# ==============================================================================
# 8. K7 COMPARE ENGINE
# ==============================================================================

def run_compare(tag1: str, tag2: str, real_dir: Path | None = None) -> bool:
    """
    K7: Reads reports/ocr/real/<tag1>.json and <tag2>.json side by side,
    prints comparison table and summary of K-changes.
    """
    r_dir = real_dir or (PROJECT_ROOT / "reports" / "ocr" / "real")
    p1 = r_dir / (tag1 if tag1.endswith(".json") else f"{tag1}.json")
    p2 = r_dir / (tag2 if tag2.endswith(".json") else f"{tag2}.json")

    if not p1.is_file():
        print(f"Error: file not found: {p1}")
        return False
    if not p2.is_file():
        print(f"Error: file not found: {p2}")
        return False

    d1 = json.loads(p1.read_text(encoding="utf-8"))
    d2 = json.loads(p2.read_text(encoding="utf-8"))

    t1_name = d1.get("tag", tag1)
    t2_name = d2.get("tag", tag2)

    print("\n" + "=" * 80)
    print(f"REAL APPS OCR RUN COMPARISON: {t1_name} vs {t2_name}")
    print("=" * 80)
    print(f"File 1: {p1} (Verdict: {d1.get('verdict', 'N/A')})")
    print(f"File 2: {p2} (Verdict: {d2.get('verdict', 'N/A')})")
    print("-" * 80)

    headers = ["Case", "App", "Metric", f"{t1_name}", f"{t2_name}", "Delta / Note"]
    print("| " + " | ".join(headers) + " |")
    print("|" + "|".join(["---"] * len(headers)) + "|")

    c1 = d1.get("cases", {})
    c2 = d2.get("cases", {})

    all_keys = ["NP", "CH", "ED", "OCC", "CA", "ST"]
    for k in all_keys:
        row1 = c1.get(k, {})
        row2 = c2.get(k, {})
        app = row2.get("app") or row1.get("app", k)

        # Blank
        b1 = str(row1.get("capture_blank", "-"))
        b2 = str(row2.get("capture_blank", "-"))
        b_note = "identical" if b1 == b2 else f"{b1} -> {b2}"
        print(f"| {k} | {app} | Blank? | {b1} | {b2} | {b_note} |")

        # Recall
        r1 = f"{row1.get('recall', 0.0)*100.0:.1f}%" if "recall" in row1 else "-"
        r2 = f"{row2.get('recall', 0.0)*100.0:.1f}%" if "recall" in row2 else "-"
        print(f"| {k} | {app} | Recall | {r1} | {r2} | - |")

        # Precision
        p1_val = f"{row1.get('precision', 0.0)*100.0:.1f}%" if "precision" in row1 else "-"
        p2_val = f"{row2.get('precision', 0.0)*100.0:.1f}%" if "precision" in row2 else "-"
        print(f"| {k} | {app} | Precision | {p1_val} | {p2_val} | - |")

        # Latency
        l1 = row1.get("ocr_added_latency_ms", row1.get("latency_ms", 0.0))
        l2 = row2.get("ocr_added_latency_ms", row2.get("latency_ms", 0.0))
        d_lat = l2 - l1
        print(f"| {k} | {app} | Added Latency | {l1:.1f} ms | {l2:.1f} ms | {d_lat:+.1f} ms |")

        # Status
        s1 = row1.get("status", "-")
        s2 = row2.get("status", "-")
        print(f"| {k} | {app} | Status | {s1} | {s2} | - |")

    print("-" * 80)
    print("\n### Summary of Kit v2 Architectural & Measurement Changes (K1 - K7):")
    print("- K1 (Region Selection): Enumerate all Chrome_RenderWidgetHostHWND children, discard invisible or < 200x150, pick largest area; fallback flagged if none.")
    print("- K2 (Page Ready Polling): Poll up to 10s for title 'OCR REAL PAGE' and valid widget host; explicit NOT_READY failure on timeout.")
    print("- K3 (OCC Added Latency): ocr_added_latency = median(include_ocr=True) - median(include_ocr=False) on same window with occluder; isolated pure OCR latency.")
    print("- K4 (Artifacts & Telemetry): Save window surface bitmap to reports/ocr/real/<tag>_img/<case>.png, store raw OCR words with region flag, record UIA element counts and differing names.")
    print("- K5 (Complete Rule Output): G1-G6 each prints explicit [PASS]/[FAIL] header and comprehensive per-case metrics.")
    print("- K6 (Filtered Informational Truth): CA/ST truth extracted only from on-screen, in-window elements (>= 4 letters); truth < 5 words flagged as TRUTH TOO SMALL; capture_blank computed.")
    print("- K7 (Side-by-Side Comparison): --compare CLI flag for side-by-side analysis against previous kit runs.\n")
    return True


# ==============================================================================
# 9. CLI DISPATCHER
# ==============================================================================

def main():
    parser = argparse.ArgumentParser(description="GOKU OCR on Real Applications Test Suite v2")
    parser.add_argument("--tag", default="real2", help="Output JSON tag (e.g. real2)")
    parser.add_argument("--repeats", type=int, default=3, help="Measured repeat iterations")
    parser.add_argument("--check-kit", action="store_true", help="Assert kit matches reports/ocr/REAL_KIT_HASH_v2.json")
    parser.add_argument("--check-kit-v1", action="store_true", help="Assert kit v1 matches reports/ocr/REAL_KIT_HASH.json")
    parser.add_argument("--compare", nargs=2, metavar=("TAG1", "TAG2"), help="Compare two report tags side by side")
    args = parser.parse_args()

    if args.check_kit_v1:
        ok = check_real_kit_v1_integrity()
        sys.exit(0 if ok else 1)

    if args.check_kit:
        ok = check_real_kit_v2_integrity()
        sys.exit(0 if ok else 1)

    if args.compare:
        ok = run_compare(args.compare[0], args.compare[1])
        sys.exit(0 if ok else 1)

    payload = run_real_apps_suite(tag=args.tag, repeats=args.repeats, check_kit=False)
    sys.exit(0 if payload["verdict"] == "ACCEPT" else 1)


if __name__ == "__main__":
    main()
