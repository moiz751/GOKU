"""Stage F19 - request advisor: understands a free-form (Roman Urdu / English, misspelt) request BEFORE anything runs, and answers honestly what GOKU can do:
  CAN | PARTIAL | PENDING_NEEDS_INTERNET | PENDING_NEEDS_SETUP | BLOCKED | CANNOT_YET | CLARIFY | UNKNOWN
with the numbers/steps behind it. It never pretends: a task that needs the internet while GOKU is offline is written to the pending list and the user is told so.
  * spelling: tokens are matched to GOKU's own vocabulary (difflib). >=0.85 -> auto-corrected AND shown; 0.6-0.85 -> asked ("kya aap X keh rahe hain?"); nothing close -> asked what is meant.
  * policy: unlicensed media (piracy, cracks, leaked files) is BLOCKED (reuses brain.task_contract patterns) and legal routes are offered; no CAPTCHA/SmartScreen bypass; approvals stay denied by default.
  * learning: every advice is logged (redacted) to data/request_log.jsonl; requests nobody can handle go to adaptive_runtime.SkillGrowth (proposal after 3 similar, no auto code).
No network call is made here: internet-dependent items become PENDING until the user switches online mode on (GOKU_ONLINE=1) - offline is the default."""
from __future__ import annotations

import difflib
import json
import os
import re
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

STATUSES = ("CAN", "PARTIAL", "PENDING_NEEDS_INTERNET", "PENDING_NEEDS_SETUP", "BLOCKED", "CANNOT_YET", "CLARIFY", "UNKNOWN")


def _dir() -> Path:
    d = Path(os.environ.get("GOKU_ADAPTIVE_DIR") or "data")
    d.mkdir(parents=True, exist_ok=True)
    return d


def online() -> bool:
    return os.environ.get("GOKU_ONLINE", "") == "1"


# ---------------------------------------------------------------- vocabulary / spelling
_VOCAB = """download delete show dikhao image photo picture video movie film song music essay write likh likho message send bhejo health scan check report laptop budget price range
exercise running workout schedule plan design glasses mechanical structure editing edit master free tool tools search web internet voice command speak record screen camera
kholo band open close karo kar do mujhe mera meri mere bana banao bata batao samjhao report month monthly summary diet sleep study timetable course learn compare""".split()
_COMMON = set("""aur or ka ki ke ko se me mein ma per par hai hain h ho ye wo is us ab bhi nahi ni to ya jo kya kaise kab kon kis kuch sab ek yak ik pher phir tha thi the na haan han
the a an to of in on for and with my me i you it this that please can could will would want need make get give tell what how when why which""".split())


def normalize(text: str) -> Tuple[str, List[Tuple[str, str, float]], List[Tuple[str, str, float]]]:
    """-> (text with confident corrections applied, applied=[(wrong,right,ratio)], doubtful=[(wrong,best_guess,ratio)])"""
    applied: List[Tuple[str, str, float]] = []
    doubtful: List[Tuple[str, str, float]] = []
    out = []
    for tok in re.findall(r"\S+", text):
        core = re.sub(r"^\W+|\W+$", "", tok).lower()
        if len(core) < 4 or core in _VOCAB or core in _COMMON or not core.isalpha():
            out.append(tok)
            continue
        m = difflib.get_close_matches(core, _VOCAB, n=1, cutoff=0.6)
        if not m:
            out.append(tok)
            continue
        r = difflib.SequenceMatcher(None, core, m[0]).ratio()
        if len(m[0]) < 4 or r < 0.75:
            out.append(tok)
        elif r >= 0.85:
            applied.append((core, m[0], round(r, 2)))
            out.append(m[0])
        else:
            doubtful.append((core, m[0], round(r, 2)))
            out.append(tok)
    return " ".join(out), applied, doubtful


# ---------------------------------------------------------------- policy
def _risky(text: str) -> Optional[str]:
    try:
        from brain.task_contract import PIRACY_DOMAINS, RISKY
        if re.search(RISKY, text, re.I) or re.search(PIRACY_DOMAINS, text, re.I):
            return "piracy/crack/leak keyword"
    except Exception:
        pass
    return None


_MEDIA_TITLE = re.compile(r"\b(?:movie|film|series|season|episode|web ?series|full hd|1080p|720p|480p|bluray|dubbed|hindi dubbed)\b|\b(?:avengers?|end ?game|infinity war|spider[- ]?man|batman|iron man|thor|joker|deadpool|dune|oppenheimer|pushpa|jawan|pathaan|kgf)\b", re.I)


# ---------------------------------------------------------------- intents
def _R(status: str, say: str, **kw: Any) -> Dict[str, Any]:
    return {"status": status, "say": say, **kw}


def _intent_table() -> List[Tuple[str, str, Any]]:
    on = online()

    def media(t: str) -> Dict[str, Any]:
        return _R("BLOCKED", "Movie/series ka download main nahi karunga agar wo licensed source se nahi hai (piracy GOKU me band hai). Legal rasta: apni khareedi hui/rent ki copy, official streaming app ka offline download, library/public-domain films. Agar aap ke paas kisi licensed source ka direct link ya apni file hai, wo main download/organise kar sakta hoon (approval ke baad).",
                  needs=["licensed source ya apni file"], alternatives=["official streaming app (offline download)", "rent/buy", "public-domain / Creative-Commons films"])

    def image_dl(t: str) -> Dict[str, Any]:
        steps = [{"n": 1, "step": "image dhoondna/download karna", "needs": "internet", "approval": True}, {"n": 2, "step": "screen par dikhana (viewer kholna)", "approval": False},
                 {"n": 3, "step": "dikhane ke baad file delete karna", "approval": True, "note": "delete hamesha aap ki manzoori se; pehle batata hoon kaun si file"}]
        return _R("PARTIAL" if on else "PENDING_NEEDS_INTERNET", "Image download ke liye internet chahiye. " + ("Online mode on hai: download aur delete dono ki approval maangunga." if on else "Abhi GOKU offline hai, isliye ye pending list me gaya. Online mode on karo (GOKU_ONLINE=1) to chalaunga; dikhana aur delete (approval ke saath) offline bhi ho sakta hai agar file already hai."), steps=steps, needs=["internet", "approval: download", "approval: delete"])

    def write_live(t: str) -> Dict[str, Any]:
        return _R("CAN", "Likh sakta hoon. Local model se hota hai, is liye chhoti PC par chhota/seedha text milega, badi PC par behtar. Topic, zabaan (Roman Urdu/English/Urdu) aur lambai batao.", needs=["topic", "zabaan", "lambai"], questions=["Kis topic par?", "Kitne lafz/lines?", "Kis zabaan me?"])

    def message_chat(t: str) -> Dict[str, Any]:
        return _R("PENDING_NEEDS_SETUP", "'Is chat ko message kar do' ke liye mujhe pata hona chahiye kahan bhejna hai (WhatsApp/Telegram/Email/SMS). Abhi GOKU me koi messenger connector set nahi hai, to bhej nahi sakta. Main text taiyar kar sakta hoon aur aap khud bhej sakte ho; send hamesha approval ke baad.", needs=["messenger/app ka naam", "receiver", "approval: send"], questions=["Kis app se aur kisko bhejun?", "Poori chat ya summary?"])

    def health(t: str) -> Dict[str, Any]:
        return _R("CLARIFY", "'Health scan' do tarah ka ho sakta hai: (1) aap ke PC/laptop ki health (RAM, disk, CPU, battery) - ye main kar sakta hoon; (2) aap ke jism ki health - main doctor/diagnosis nahi hoon, scan nahi kar sakta, sirf general wellness aur fitness plan bana sakta hoon. Kaun sa?", questions=["PC ki health ya jism ki?"], options=["PC health scan: CAN", "Body: sirf general wellness plan, diagnosis nahi"])

    def make_video(t: str) -> Dict[str, Any]:
        return _R("PARTIAL", "Video do tarah ki banti hai: screen recording/slideshow (ffmpeg + images/text se, offline) ya camera se aap ki video (camera permission + app chahiye, abhi GOKU me camera capture nahi). Konsi chahiye? Kis cheez ki video, kitni lambi?", needs=["ffmpeg (probe)", "content/images", "camera permission (agar camera)"], questions=["Screen recording, slideshow ya camera video?", "Kis topic par, kitni lambi?"])

    def exercise(t: str) -> Dict[str, Any]:
        return _R("CAN", "Running/exercise ka schedule bana sakta hoon, lekin jism ke hisab se sahi karne ke liye ye chahiye: umar, height, weight, goal (stamina/weight/muscle), hafte me kitne din, koi chot/bimari (agar hai to doctor se poochna zaroori). Main medical advice nahi deta; schedule general fitness principles par hoga.", needs=["umar", "height/weight", "goal", "din per hafta", "chot ya bimari ka zikr"], questions=["Umar, height, weight?", "Goal kya hai?", "Hafte me kitne din time hai?", "Koi chot ya bimari?"])

    def laptop(t: str) -> Dict[str, Any]:
        return _R("PARTIAL" if not on else "CAN", "Laptop ke liye budget range aur kaam (gaming/editing/study/coding) batao. Offline main specs ka hisab (kam se kam RAM/CPU/GPU kis kaam ke liye) bata sakta hoon. Aaj ke asli prices aur models ke liye internet search chahiye" + (" (online mode on hai)." if on else " - abhi offline hai, wo hissa pending."), needs=["budget range", "use case", "internet (live prices)"], questions=["Budget kitna (min-max)?", "Kis kaam ke liye?", "Portability ya performance?"])

    def glasses(t: str) -> Dict[str, Any]:
        return _R("PARTIAL", "Mechanical glasses ka structure (frame, hinge, nose pad, lens mount, temple arms, material, tolerances) ka design brief aur requirements list bana sakta hoon, aur 2-3 bilkul alag concept options likh sakta hoon. CAD/3D model ya stress simulation GOKU me abhi nahi, uske liye FreeCAD/Blender jaisa tool aur aap ka setup chahiye. Pehle ye batao: kis kaam ke glasses (safety, fashion, smart/AR, sports)?", needs=["use case", "material/budget", "manufacturing method (3D print/CNC/mold)"], questions=["Kis kaam ke glasses?", "Material/budget?", "3D print ya CNC?"])

    def editing(t: str) -> Dict[str, Any]:
        return _R("PARTIAL" if not on else "CAN", "Video editing ka rasta (workflow, free tools ka general taaruf) offline bata sakta hoon. 'Is waqt ke best free tools aur unki daily limits' live web research chahti hai" + (": online mode on hai." if on else ": GOKU offline hai to ye pending; research ka alag report bana sakta hoon."), needs=["internet (current tool list/limits)", "aap ka PC spec", "kis qism ki video"], questions=["YouTube/shorts/film?", "PC ki RAM/GPU kya hai?"])

    def monthly(t: str) -> Dict[str, Any]:
        return _R("CAN", "Is mahine ka kaam-report GOKU ki notes (docs/P0_NOTES.md stages), test reports aur experience log se ban sakti hai. Command: 'monthly report'.", needs=[])

    def voice(t: str) -> Dict[str, Any]:
        return _R("CANNOT_YET", "Voice command abhi GOKU me nahi hai: mic capture ya speech-to-text module project me maujood nahi. Offline ke liye Vosk/whisper.cpp jaisi tools use ho sakti hain (probe ho jayengi), lekin pehle install + mic permission + Windows par test chahiye. Text commands poori tarah chal rahi hain.", needs=["mic", "offline STT (vosk/whisper.cpp)", "Windows test"])

    def context(t: str) -> Dict[str, Any]:
        return _R("CAN", "Long-term context ke liye GOKU ka MemoryStore (SQLite, redaction ke saath) aur dialog_state (pichle verified jawab, 'isko/usko' ka matlab) maujood hain. Hadd: chhoti model par lamba context chhota rehta hai, isliye khulasa save hota hai, poori chat nahi.")

    def websearch(t: str) -> Dict[str, Any]:
        return _R("PARTIAL" if on else "PENDING_NEEDS_INTERNET", "Web search ke liye internet chahiye." + (" Online mode on hai." if on else " GOKU default me offline hai: ye kaam pending list me gaya, aur aap batate ho to online mode on karke chalaunga."), needs=["internet"])

    return [
        ("media_download", r"\bdownload\b.*|\bdownload\b", media),
        ("image_download", r"\b(?:image|photo|picture|pic|tasveer)\b.*\bdownload\b|\bdownload\b.*\b(?:image|photo|picture|pic|tasveer)\b", image_dl),
        ("websearch", r"\b(?:web search|search karo|internet par|google)\b|\bsearch\b.*\b(?:karo|kar do|web)\b", websearch),
        ("write_live", r"\b(?:essay|likh|likho|write|text likh|article|letter)\b", write_live),
        ("message_chat", r"\b(?:message|msg|bhej|send)\b.*\b(?:chat|conversation)\b|\b(?:chat)\b.*\b(?:message|bhej|send)\b", message_chat),
        ("health", r"\bhealth\b.*\bscan\b|\bscan\b.*\bhealth\b|\bhealth scan\b", health),
        ("make_video", r"\bvideo\b.*\b(?:bana|banao|make|create)\b|\b(?:bana|banao|make|create)\b.*\bvideo\b", make_video),
        ("exercise", r"\b(?:exercise|running|workout|gym|fitness)\b.*\b(?:schedule|plan|design|timetable)\b|\b(?:schedule|plan|timetable)\b.*\b(?:exercise|running|workout)\b", exercise),
        ("laptop", r"\blaptop\b.*\b(?:range|budget|lana|khareed|buy|price)\b|\b(?:range|budget)\b.*\blaptop\b", laptop),
        ("glasses", r"\b(?:glasses|chashma|sunglasses)\b.*\b(?:mechanical|structure|design|bana)\b|\b(?:mechanical|structure)\b.*\bglasses\b", glasses),
        ("editing", r"\bvideo editing\b|\bedit(?:ing)?\b.*\bvideo\b|\bvideo\b.*\bedit", editing),
        ("monthly_report", r"\b(?:monthly|mahine|month|mont)\b.*\breport\b|\breport\b.*\b(?:month|mahine|mont)\b", monthly),
        ("voice", r"\bvoice\b|\bbol kar\b|\bspeech\b|\bawaz\b", voice),
        ("context", r"\b(?:long[- ]term|lamba|purani|pichli)\b.*\b(?:context|memory|yaad|baat)\b|\bcontext\b.*\b(?:yaad|memory|long)\b", context),
    ]


_ORDER = ["media_download", "image_download"]       # image_download is more specific than the generic download rule: checked first


def _intent(text: str) -> Optional[Tuple[str, Dict[str, Any]]]:
    low = text.lower()
    table = _intent_table()
    by = {n: (rx, fn) for n, rx, fn in table}
    if re.search(r"\bdownload\b", low):
        if re.search(by["image_download"][0], low):
            return "image_download", by["image_download"][1](low)
        if _MEDIA_TITLE.search(low) or re.search(r"\b(?:film|movie|video|song)\b", low):
            return "media_download", by["media_download"][1](low)
        if not re.search(r"\b(?:file|app|software|pdf|zip|document|driver|installer|model)\b|\.(?:exe|msi|zip|pdf)\b", low):
            return "download_unclear", _R("CLARIFY", "Kya download karna hai (movie/gaana, image, app/software, document)? Aur kis source se (official site/link)? Licensed ya aap ki apni cheez ho to madad karunga; piracy/crack nahi.", questions=["Kya download karna hai?", "Kis official source/link se?"])
    if re.search(r"\bdownload\b", low):
        return "file_download", _R("PARTIAL" if on_() else "PENDING_NEEDS_INTERNET", "App/file download sirf official source se, aap ki approval ke baad. SmartScreen/antivirus warning ko bypass nahi karta; hash/signature check karke batata hoon." + ("" if on_() else " Abhi offline hai, isliye pending."), needs=["internet", "official source/link", "approval: download", "approval: run installer"], steps=[{"n": 1, "step": "official link se download", "approval": True}, {"n": 2, "step": "sha256/signature check", "approval": False}, {"n": 3, "step": "installer chalana", "approval": True}])
    for name, rx, fn in table:
        if name in ("media_download",):
            continue
        if re.search(rx, low):
            return name, fn(low)
    return None


def on_() -> bool:
    return online()


def _unknown_entity(text: str) -> bool:
    words = re.findall(r"[A-Za-z]+", text)
    return 1 <= len(words) <= 4 and not re.search(r"\b(?:kholo|open|close|band|kar|karo|do|download|likh|bana|search|batao|bata|show|dikhao|delete|run|start|stop)\b", text, re.I)


def advise(text: str, log: bool = True) -> Dict[str, Any]:
    raw = (text or "").strip()
    norm, applied, doubtful = normalize(raw)
    res: Dict[str, Any]
    why = _risky(norm) or _risky(raw)
    hit = _intent(norm)
    if why and not (hit and hit[0] == "media_download"):
        res = {"intent": "unlicensed_content", **_R("BLOCKED", f"Ye request unlicensed/piracy side ki lagti hai ({why}). GOKU ye nahi karta. Legal option batao to madad karunga.", needs=[])}
    elif hit:
        res = {"intent": hit[0], **hit[1]}
    elif re.search(r"(?i)\b(?:kholo|open|close|band karo|launch|start|run|minimi[sz]e|maximi[sz]e)\b", norm):
        res = {"intent": "standard_command", **_R("CAN", "Ye GOKU ki normal desktop command hai: seedha chalao, router khud sahi route chunega (approval wali cheezon par poochega).")}
    elif doubtful:
        d = doubtful[0]
        res = {"intent": "unclear_spelling", **_R("CLARIFY", f"Mujhe '{d[0]}' ki spelling se pakka samajh nahi aaya. Kya aap '{d[1]}' keh rahe hain? Agar nahi, to seedha batao ke kya karwana hai.", questions=[f"Kya aap '{d[1]}' keh rahe hain?"])}
    elif _unknown_entity(raw):
        res = {"intent": "unknown_entity", **_R("UNKNOWN", f"'{raw}' mere paas kisi command, app ya file ke taur par nahi mila. Mujhe iska pakka matlab maloom nahi (guess nahi kar raha). Aap kya chahte hain: iske baare me jaankari, koi app/game kholna, image, ya kuch aur? Internet ho to main web se dekh sakta hoon.", questions=["Ye kya hai (character/app/file/game)?", "Mujhe isse kya karna hai?"])}
    else:
        res = {"intent": "not_understood", **_R("CLARIFY", "Mujhe is request ka matlab pakka samajh nahi aaya. Thoda aur saaf likho: kya karwana hai (kholna/likhna/download/check), aur kis cheez par? Misal: 'notepad kholo', 'essay likho topic X'.", questions=["Aap kya karwana chahte hain?"])}
    res.update({"input": raw, "normalized": norm, "spelling_fixed": [{"from": a, "to": b, "ratio": r} for a, b, r in applied], "spelling_doubtful": [{"from": a, "guess": b, "ratio": r} for a, b, r in doubtful], "online": online()})
    if applied:
        res["say"] = "(Maine " + ", ".join(f"'{a}' ko '{b}'" for a, b, _ in applied) + " samjha.) " + res["say"]
    if res["status"] in ("PENDING_NEEDS_INTERNET", "PENDING_NEEDS_SETUP"):
        res["pending_id"] = pend(raw, res["intent"], res["status"], res.get("needs", []))
    if res["status"] in ("UNKNOWN", "CLARIFY") and res["intent"] in ("unknown_entity", "not_understood"):
        try:
            from brain.adaptive_runtime import SkillGrowth
            res["skill_growth"] = SkillGrowth().note_unhandled(raw)["state"]
        except Exception:
            pass
    if log:
        _log(res)
    return res


# ---------------------------------------------------------------- pending + log (honest status for the user)
def pend(request: str, intent: str, status: str, needs: List[str]) -> str:
    p = _dir() / "pending_requests.json"
    try:
        q = json.loads(p.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        q = []
    for x in q:
        if x["request"] == request and x["intent"] == intent and x["state"] == "PENDING":
            return x["id"]
    pid = f"req{len(q) + 1}"
    q.append({"id": pid, "request": request[:300], "intent": intent, "status": status, "needs": needs, "state": "PENDING", "since": round(time.time())})
    tmp = p.with_suffix(".tmp")
    tmp.write_text(json.dumps(q, indent=1, ensure_ascii=False), encoding="utf-8")
    tmp.replace(p)
    return pid


def pending_requests() -> List[Dict[str, Any]]:
    try:
        return [x for x in json.loads((_dir() / "pending_requests.json").read_text(encoding="utf-8")) if x["state"] == "PENDING"]
    except (OSError, ValueError):
        return []


def _log(res: Dict[str, Any]) -> None:
    try:
        from brain.memory_store import redact
        inp = redact(res["input"])
    except Exception:
        inp = re.sub(r"(?i)(password|token|key)\s*[:=]?\s*\S+", r"\1 [redacted]", res["input"])
    try:
        with open(_dir() / "request_log.jsonl", "a", encoding="utf-8") as f:
            f.write(json.dumps({"t": round(time.time()), "input": inp[:300], "intent": res["intent"], "status": res["status"], "fixed": len(res["spelling_fixed"])}, ensure_ascii=False) + "\n")
    except OSError:
        pass


def stats() -> Dict[str, Any]:
    """What GOKU learned about the requests it receives (counts per intent and status, how often spelling had to be fixed)."""
    out: Dict[str, Any] = {"requests": 0, "by_status": {}, "by_intent": {}, "spelling_fixed": 0}
    try:
        for ln in (_dir() / "request_log.jsonl").read_text(encoding="utf-8").splitlines():
            r = json.loads(ln)
            out["requests"] += 1
            out["by_status"][r["status"]] = out["by_status"].get(r["status"], 0) + 1
            out["by_intent"][r["intent"]] = out["by_intent"].get(r["intent"], 0) + 1
            out["spelling_fixed"] += r.get("fixed", 0)
    except (OSError, ValueError):
        pass
    return out


def capabilities() -> List[Dict[str, str]]:
    return [{"area": n, "status": fn("")["status"]} for n, _, fn in _intent_table()]


def render(res: Dict[str, Any]) -> str:
    lines = [f"[{res['status']}] {res['say']}"]
    for s in res.get("steps", []):
        lines.append(f"  {s['n']}. {s['step']}" + ("  [approval]" if s.get("approval") else ""))
    if res.get("questions"):
        lines.append("Sawal: " + " | ".join(res["questions"]))
    if res.get("alternatives"):
        lines.append("Legal options: " + "; ".join(res["alternatives"]))
    if res.get("pending_id"):
        lines.append(f"Pending list me hai: {res['pending_id']} (dekhne ke liye 'advise pending')")
    return "\n".join(lines)


def handle_command(text: str) -> Optional[str]:
    m = re.match(r"(?is)^\s*(?:advise|advice|samjho|request check)\s*[:,-]?\s*(.*)$", text or "")
    if not m:
        if re.match(r"(?is)^\s*capabilit(?:y|ies)\s*$", text or ""):
            return "\n".join(f"- {c['area']}: {c['status']}" for c in capabilities())
        return None
    rest = m.group(1).strip()
    if rest.lower() == "pending":
        p = pending_requests()
        return "\n".join(f"- {x['id']} [{x['status']}] {x['request']} (chahiye: {', '.join(x['needs']) or '-'})" for x in p) or "koi pending request nahi"
    if rest.lower() in ("stats", "report"):
        return json.dumps(stats(), ensure_ascii=False)
    if not rest:
        return "Likho: advise <request>. Main batata hoon ke GOKU kya kar sakta hai, kya nahi, kya pending hai."
    return render(advise(rest))
