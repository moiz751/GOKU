"""Stage F12: independent output verifier.

Rule: a verifier NEVER imports or calls the module that produced the output. It re-derives or re-checks the claim from plain data
(its own arithmetic evaluator, re-reading the file, re-summing the schedule log...). Every verifier returns
{"ok": bool, "why": str, "checks": [...]} and fails closed: missing/malformed input -> ok False.
Each verifier has a good-sample and a mutated-sample test (tests/test_stageF12_verifier.py) so a verifier that always says "ok" is caught.
"""
from __future__ import annotations
import ast, hashlib, os, re
from fractions import Fraction
from typing import Any, Dict, Iterable, List, Optional

def _r(ok: bool, why: str = "", checks: Optional[list] = None) -> Dict[str, Any]:
    return {"ok": bool(ok), "why": why if not ok else (why or "verified"), "checks": checks or []}

# ---------- arithmetic (own evaluator, exact Fractions) ----------
def _ev(n):
    if isinstance(n, ast.Expression): return _ev(n.body)
    if isinstance(n, ast.Constant) and isinstance(n.value, (int, float)) and not isinstance(n.value, bool): return Fraction(str(n.value))
    if isinstance(n, ast.UnaryOp) and isinstance(n.op, (ast.USub, ast.UAdd)):
        v = _ev(n.operand); return -v if isinstance(n.op, ast.USub) else v
    if isinstance(n, ast.BinOp):
        a, b = _ev(n.left), _ev(n.right)
        if isinstance(n.op, ast.Add): return a + b
        if isinstance(n.op, ast.Sub): return a - b
        if isinstance(n.op, ast.Mult): return a * b
        if isinstance(n.op, ast.Div):
            if b == 0: raise ZeroDivisionError("division by zero")
            return a / b
        if isinstance(n.op, ast.Pow):
            if b.denominator != 1 or abs(b) > 64: raise ValueError("unsupported exponent")
            return a ** int(b)
        if isinstance(n.op, ast.Mod):
            if b == 0: raise ZeroDivisionError("modulo by zero")
            return a % b
    raise ValueError("unsupported expression")

def verify_arithmetic(expr: str, claimed: Any, tol: float = 1e-9) -> Dict[str, Any]:
    try:
        exact = _ev(ast.parse(str(expr).replace("^", "**").replace(",", "").strip(), mode="eval"))
    except ZeroDivisionError:
        return _r(str(claimed).lower() in ("error", "undefined", "zero division") or "zero" in str(claimed).lower(), f"{expr} is undefined; claimed {claimed!r}")
    except Exception as e:
        return _r(False, f"verifier cannot independently evaluate ({e})")
    try:
        c = Fraction(str(claimed).replace(",", "").strip())
    except Exception:
        return _r(False, f"claimed value {claimed!r} is not a number")
    ok = abs(float(c - exact)) <= tol * max(1.0, abs(float(exact)))
    return _r(ok, f"expected {float(exact)!r}, claimed {claimed!r}")

# ---------- file / search / hash ----------
def verify_search_hits(source_text: str, hits: Iterable[Dict[str, Any]], query: str = "") -> Dict[str, Any]:
    hits = list(hits)
    if not hits: return _r(True, "no hits claimed", [])
    norm = lambda s: re.sub(r"\s+", " ", str(s)).strip().lower()
    src = norm(source_text); bad = []
    for h in hits:
        snip = norm(h.get("text") or re.sub(r"[\[\]]", "", str(h.get("snippet") or "")))
        probe = snip.replace("…", "").replace("...", "").strip()
        if not probe or probe not in src: bad.append(h.get("loc", "?"))
    return _r(not bad, f"snippets not found in source at {bad}", [{"hits": len(hits)}])

def verify_hash(path: str, sha256: str = "", size: Optional[int] = None) -> Dict[str, Any]:
    if not os.path.isfile(path): return _r(False, "file missing")
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""): h.update(b)
    if size is not None and os.path.getsize(path) != size: return _r(False, f"size {os.path.getsize(path)} != {size}")
    if sha256 and h.hexdigest().lower() != sha256.lower(): return _r(False, "sha256 mismatch")
    return _r(True, "hash/size match", [{"sha256": h.hexdigest()}])

# ---------- RAM / scheduling ----------
def verify_chunks(total_mb: float, chunks: List[float], budget_mb: float) -> Dict[str, Any]:
    if not chunks: return _r(False, "no chunks")
    if abs(sum(chunks) - total_mb) > 1e-6 * max(1, total_mb) + 0.01: return _r(False, f"chunks sum {sum(chunks)} != total {total_mb}")
    if any(c <= 0 for c in chunks): return _r(False, "non-positive chunk")
    if max(chunks) > budget_mb + 1e-9: return _r(False, f"chunk {max(chunks)} exceeds budget {budget_mb}")
    return _r(True)

def verify_schedule_log(events: List[Dict[str, Any]], budget_mb: float) -> Dict[str, Any]:
    """events: {t, ev: start|finish|pause|resume, id, mb}. Re-sums running memory at every instant."""
    running: Dict[str, float] = {}; started: set = set(); peak = 0.0
    for e in sorted(events, key=lambda x: x["t"]):
        i, ev = e["id"], e["ev"]
        if ev == "start":
            if i in started: return _r(False, f"{i} started twice (double execution)")
            started.add(i); running[i] = float(e["mb"])
        elif ev in ("finish", "pause"): running.pop(i, None)
        elif ev == "resume": running[i] = float(e["mb"])
        peak = max(peak, sum(running.values()))
        if peak > budget_mb + 1e-9: return _r(False, f"{peak} MB running exceeds budget {budget_mb} at t={e['t']}")
    return _r(True, checks=[{"peak_mb": peak}])

def verify_tier(profile: Dict[str, Any], total_ram_mb: Optional[float] = None) -> Dict[str, Any]:
    try:
        b, m = float(profile["budget_mb"]), float(profile["budget_max_mb"])
    except Exception:
        return _r(False, "profile lacks budget fields")
    if not (0 < b <= m): return _r(False, "budget must be >0 and <= budget_max")
    if total_ram_mb and m > total_ram_mb: return _r(False, f"budget_max {m} exceeds installed RAM {total_ram_mb}")
    return _r(True)

def verify_tier_monotonic(tiers: List[Dict[str, Any]]) -> Dict[str, Any]:
    vals = [t["budget_max_mb"] for t in tiers]
    return _r(all(a <= b for a, b in zip(vals, vals[1:])), "budget ceilings must not shrink on bigger tiers")

# ---------- stop / approval / security ----------
def verify_stop_log(events: List[Dict[str, Any]]) -> Dict[str, Any]:
    """events: {t, ev}. After the first 'stop', only cleanup/checkpoint/release events are legal."""
    stop_t = next((e["t"] for e in sorted(events, key=lambda x: x["t"]) if e["ev"] == "stop"), None)
    if stop_t is None: return _r(True, "no stop requested")
    bad = [e for e in events if e["t"] > stop_t and e["ev"] not in ("cleanup", "checkpoint", "release", "stop", "paused", "cancelled")]
    return _r(not bad, f"actions after stop: {[b['ev'] for b in bad][:3]}")

_RISKY = re.compile(r"\b(delete|remove|install|uninstall|publish|post|send|pay|payment|purchase|subscribe|follow|format|shutdown|register|checkout)\b", re.I)
def verify_approval(action_text: str, decision: Dict[str, Any], approver_connected: bool = False) -> Dict[str, Any]:
    allowed = str(decision.get("decision", decision.get("status", ""))).lower() in ("allow", "allowed", "ok", "executed", "run", "approved")
    risky = bool(_RISKY.search(action_text or ""))
    if risky and allowed and not decision.get("approval_id") and not decision.get("approved_by"):
        return _r(False, "risky action allowed without a recorded approval")
    if risky and allowed and not approver_connected and not decision.get("approved_by"):
        return _r(False, "approval claimed but no approver identity")
    return _r(True)

# ---------- plans / tasks ----------
def verify_plan_steps(steps: List[Dict[str, Any]]) -> Dict[str, Any]:
    ids = [s.get("id") for s in steps]
    if not steps or len(set(ids)) != len(ids) or None in ids: return _r(False, "missing or duplicate step ids")
    idx = set(ids)
    for s in steps:
        for d in s.get("depends_on", []) or []:
            if d not in idx: return _r(False, f"{s['id']} depends on unknown {d}")
    seen: Dict[str, int] = {}
    deps = {s["id"]: list(s.get("depends_on", []) or []) for s in steps}
    def cyc(n):
        if seen.get(n) == 1: return True
        if seen.get(n) == 2: return False
        seen[n] = 1
        if any(cyc(d) for d in deps[n]): return True
        seen[n] = 2; return False
    if any(cyc(i) for i in ids): return _r(False, "dependency cycle")
    return _r(True)

def verify_task_history(history: List[str], steps_done: int = 0, steps_total: int = 0) -> Dict[str, Any]:
    terminal = {"done", "completed", "failed", "cancelled"}
    for a, b in zip(history, history[1:]):
        if a in terminal: return _r(False, f"transition out of terminal state {a}->{b}")
    if history and history[-1] in ("done", "completed") and steps_total and steps_done < steps_total:
        return _r(False, f"marked done with {steps_done}/{steps_total} steps")
    return _r(True)

def verify_recurring(run_times: List[float], interval_s: float, tolerance: float = 0.25) -> Dict[str, Any]:
    gaps = [b - a for a, b in zip(run_times, run_times[1:])]
    if any(g < interval_s * (1 - tolerance) for g in gaps): return _r(False, "ran too often (duplicate runs)")
    return _r(True)

def verify_route_choice(plan: Dict[str, Any], destructive: bool = False) -> Dict[str, Any]:
    routes = plan.get("routes") or plan.get("candidates") or ([plan["route"]] if plan.get("route") else [])
    if not routes: return _r(False, "no route chosen")
    if destructive and not (plan.get("needs_confirm") or plan.get("confirm") or plan.get("gate")):
        return _r(False, "destructive task routed without a confirmation gate")
    return _r(True)

# ---------- answers / language ----------
def verify_numbers_preserved(src: str, dst: str) -> Dict[str, Any]:
    pick = lambda s: sorted(re.findall(r"\d+(?:[.,]\d+)?", str(s)))
    a, b = pick(src), pick(dst)
    return _r(a == b, f"numbers differ: {a} vs {b}")

def verify_restrictions_kept(src: str, dst: str, markers: Iterable[str] = ("no", "not", "never", "nahi", "mat", "only", "sirf", "without", "bagair")) -> Dict[str, Any]:
    ws = lambda s: set(re.findall(r"[a-z']+", str(s).lower()))
    s, d = ws(src), ws(dst)
    neg_s = {m for m in markers if m in s}
    neg_d = {m for m in markers if m in d}
    return _r(not neg_s or bool(neg_d), "a negation/restriction in the source is missing from the output")

def verify_labelled_answer(ans: Dict[str, Any]) -> Dict[str, Any]:
    """An answer must carry a status; unverified/guessed text must be labelled and may not claim verified."""
    st = str(ans.get("status", "")).lower()
    if st not in ("verified", "computed", "exact", "unverified", "llm_unverified", "unknown", "needs_clarification"):
        return _r(False, f"unknown status {st!r}")
    if st in ("unverified", "llm_unverified") and ans.get("verified"): return _r(False, "unverified text flagged verified")
    if st == "unknown" and ans.get("text") and re.search(r"\d{3,}", str(ans["text"])): return _r(False, "unknown answer contains invented figures")
    return _r(True)

def verify_memory_row(content: str, stored: str) -> Dict[str, Any]:
    secret = re.compile(r"(\b\d{4}[ -]?\d{4}[ -]?\d{4}[ -]?\d{4}\b|password\s*[:=]\s*(?!\[?redacted)\S+|passwd\s*[:=]\s*(?!\[?redacted)\S+|api[_-]?key\s*[:=]\s*(?!\[?redacted)\S+|\bsk-[A-Za-z0-9]{16,})", re.I)
    if secret.search(stored or "") and secret.search(content or ""): return _r(False, "secret stored unredacted")
    return _r(bool(stored), "empty stored row")

def verify_trace(trace: List[Dict[str, Any]]) -> Dict[str, Any]:
    if not trace: return _r(False, "empty trace")
    for e in trace:
        if e.get("status") == "completed" and not (e.get("evidence") or e.get("verified")):
            return _r(False, f"step {e.get('step')} completed without evidence")
    return _r(True)

def verify_live_evidence(rec: Dict[str, Any]) -> Dict[str, Any]:
    need = ("capability", "live", "os", "when", "result", "log")
    miss = [k for k in need if k not in rec]
    if miss: return _r(False, f"evidence missing fields {miss}")
    if rec["live"] and not str(rec.get("os", "")).lower().startswith("windows"): return _r(False, "live evidence must come from Windows")
    return _r(True)

# ---------- extra independent checks ----------
def verify_assignment(assign: Dict[str, Any], domains: Dict[str, Iterable[Any]], checks: Iterable[Any]) -> Dict[str, Any]:
    """A claimed constraint solution: every variable inside its domain and every check re-evaluated here."""
    for k, dom in domains.items():
        if k not in assign or assign[k] not in list(dom): return _r(False, f"{k}={assign.get(k)!r} outside its domain")
    for i, c in enumerate(checks):
        if not c(assign): return _r(False, f"constraint {i} violated")
    return _r(True)

def verify_within_budget(total_mb: float, budget_mb: float) -> Dict[str, Any]:
    return _r(total_mb <= budget_mb + 1e-9, f"{total_mb} MB exceeds budget {budget_mb} MB")

def verify_screen_log(log: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Every click must be preceded by a fresh observation event and never follow a stale/blocked/disagree event without a new observation."""
    last_bad = False; seen_obs = False
    for e in log:
        ev = e.get("event")
        if ev in ("observed", "observe", "fresh"): seen_obs = True; last_bad = False
        if ev in ("stale", "blocked_no_approval", "sources_disagree"): last_bad = True
        if ev == "clicked" and last_bad: return _r(False, "click after a stale/blocked/disagreeing observation")
    clicks = [e for e in log if e.get("event") == "clicked"]
    return _r(True, checks=[{"clicks": len(clicks)}])

def verify_media_report(report: Dict[str, Any]) -> Dict[str, Any]:
    """An audit may not claim full coverage while listing skipped checks, and every issue needs evidence + a time/region."""
    claim = str(report.get("claim", "")).lower()
    if report.get("not_performed") and re.search(r"\b(fully|complete(ly)?|entire(ly)?|100\s*%|everything|all checks)\b", claim) and "not" not in claim and "partial" not in claim:
        return _r(False, "claims full inspection while listing checks not performed")
    for i in report.get("issues", []):
        if not i.get("evidence"): return _r(False, f"issue {i.get('id')} has no evidence")
    return _r(True)

def verify_reward(before_score: Optional[float], after_score: Optional[float], verdict: Dict[str, Any]) -> Dict[str, Any]:
    """Reward must follow EVIDENCE: a positive verified reward needs a real score gain / win text; pixel activity alone never counts."""
    r = float(verdict.get("reward", 0)); ver = bool(verdict.get("verified"))
    if r > 0 and not ver: return _r(False, "positive reward without verified evidence")
    if r > 0 and verdict.get("strength") == "score" and not (before_score is not None and after_score is not None and after_score > before_score):
        return _r(False, "score reward claimed but the score did not increase")
    if not verdict.get("evidence") and r != 0: return _r(False, "non-zero reward with no evidence list")
    return _r(True)


# ---------- F14: contract / route plan / ranking / timeline (independent: plain data in, own regexes) ----------
def verify_contract(text: str, c: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(c, dict) or not text:
        return _r(False, "no contract or text")
    tl = text.lower()
    bad: List[str] = []
    title = str(c.get("title") or "")
    if title:
        words = [w for w in re.findall(r"[\w']+", title.lower()) if len(w) > 1]
        miss = [w for w in words if w not in tl]
        if miss:
            bad.append("title words not in the command (invented): " + ",".join(miss))
    if c.get("year") and str(c["year"]) not in text:
        bad.append("year not in the command")
    for u in c.get("urls") or []:
        if u not in text:
            bad.append("url not in the command")
    yrs = re.findall(r"\b(19[2-9]\d|20[0-4]\d)\b", text)
    if yrs and not c.get("year"):
        bad.append("year in the command was dropped")
    quoted = re.findall(r"[\"“]([^\"”]{2,100})[\"”]", text)
    if quoted and title and title != quoted[0].strip():
        bad.append("quoted title was not used exactly")
    if re.search(r"(?i)\b(?:do\s*n'?t|do not|never)\s+overwrite|overwrite\s+(?:mat|na)", text) and "no_overwrite" not in (c.get("constraints") or []):
        bad.append("'no overwrite' restriction lost")
    if re.search(r"(?i)\b(crack|keygen|torrent|pirat\w*)\b", text) and not (c.get("legal") or {}).get("blocked_terms"):
        bad.append("piracy wording not flagged")
    if not c.get("goal"):
        bad.append("no goal")
    if c.get("title") and not any(x.get("check") == "title_match" for x in c.get("success_criteria") or []):
        bad.append("title given but no title_match criterion (could accept any file)")
    return _r(not bad, "; ".join(bad))


def verify_plan_chain(caps: List[str], defs: Dict[str, Dict[str, Any]], facts0: Iterable[str], goal: str) -> Dict[str, Any]:
    f = set(facts0)
    for cid in caps:
        d = defs.get(cid)
        if d is None:
            return _r(False, f"unknown capability {cid}")
        miss = set(d["needs"]) - f
        if miss:
            return _r(False, f"{cid} needs {sorted(miss)} that nothing provided")
        f |= set(d["provides"])
    return _r(goal in f, "" if goal in f else f"plan never produces the goal fact '{goal}'")


def verify_ranking(plans: List[Dict[str, Any]], blocked: Iterable[str] = (), env_ok: Optional[Dict[str, bool]] = None) -> Dict[str, Any]:
    bad: List[str] = []
    blocked = set(blocked)
    seen = set()
    last_key = None
    for i, p in enumerate(plans, 1):
        if p.get("rank") != i:
            bad.append(f"rank {p.get('rank')} at position {i}")
        k = tuple(p["caps"])
        if k in seen:
            bad.append("duplicate plan")
        seen.add(k)
        if set(p["caps"]) & blocked:
            bad.append("a policy-blocked capability is in a plan")
        if p.get("partial_only"):
            continue
        key = (not p["executable"], -p["utility"])
        if last_key is not None and key < last_key:
            bad.append(f"plan {i} ranked above a better plan")
        last_key = key
    first_real = next((p for p in plans if not p.get("partial_only")), None)
    if first_real and not first_real["executable"] and any(p["executable"] and not p.get("partial_only") for p in plans):
        bad.append("a not-yet-executable plan outranks an executable one")
    return _r(not bad, "; ".join(bad))


def verify_item_claim(criteria: List[Dict[str, Any]], facts: Dict[str, Any], claimed_status: str) -> Dict[str, Any]:
    """Re-derives MATCH/WRONG_ITEM from raw file facts with its own simple rules."""
    name = str(facts.get("filename", "")).lower()
    wrong = False
    for c in criteria:
        k, v = c.get("check"), c.get("value")
        if k == "extension_in" and name and ("." + name.rsplit(".", 1)[-1]) not in v:
            wrong = True
        if k == "size_mb_between" and facts.get("size_mb") is not None and not ((v[0] is None or facts["size_mb"] >= v[0]) and (v[1] is None or facts["size_mb"] <= v[1])):
            wrong = True
        if k == "duration_min_between" and facts.get("duration_min") is not None and not (v[0] <= facts["duration_min"] <= v[1]):
            wrong = True
        if k == "pages_between" and facts.get("pages") is not None and not (v[0] <= facts["pages"] <= v[1]):
            wrong = True
    if wrong and claimed_status == "MATCH":
        return _r(False, "claimed MATCH but a measurable criterion fails")
    if claimed_status == "MATCH" and not facts:
        return _r(False, "MATCH claimed with no file facts")
    return _r(True, "")


def verify_timeline(events: List[Dict[str, Any]], final_status: str) -> Dict[str, Any]:
    if not events:
        return _r(False, "empty timeline")
    kinds = [e.get("kind") for e in events]
    ts = [e.get("t", 0) for e in events]
    if ts != sorted(ts):
        return _r(False, "timeline goes backwards in time")
    if kinds[-1] != "final" and not ({"pending", "ask"} & set(kinds)):
        return _r(False, "timeline does not end with a final result")
    if final_status == "COMPLETED":
        if "ok" not in kinds:
            return _r(False, "COMPLETED with no verified step in the timeline")
        if "final" in kinds and "fail" in kinds[kinds.index("final"):]:
            return _r(False, "COMPLETED but a failure is recorded after the final line")
    return _r(True, "")


# ---------- F13/F14 support verifiers ----------
_ST_RANK = {"PASS": 0, "ALTERNATIVE_PASS": 1, "PARTIAL": 2, "UNVERIFIED": 3, "BLOCKED": 4, "NOT_POSSIBLE": 5, "NOT_IMPLEMENTED": 6}


def verify_health(h: Dict[str, Any]) -> Dict[str, Any]:
    """A capability health record may only be green when EVERY group is green; a chain is PASS only if its first real link passes."""
    if not isinstance(h, dict) or not h.get("groups"):
        return _r(False, "no groups")
    worst = "PASS"
    for g in h["groups"]:
        comps = g.get("components") or []
        if not comps:
            return _r(False, f"group {g.get('group')} has no components")
        sts = [c["status"] for c in comps]
        if g["mode"] == "required":
            exp = max(sts, key=lambda s: _ST_RANK[s])
            if g["status"] != exp:
                return _r(False, f"required group {g['group']} is {g['status']} but its worst part is {exp}")
        else:
            if g["status"] in ("PASS", "ALTERNATIVE_PASS") and "PASS" not in sts:
                return _r(False, f"chain {g['group']} claims {g['status']} with no passing component")
        if _ST_RANK[g["status"]] > _ST_RANK[worst]:
            worst = g["status"]
    if h.get("green") and _ST_RANK[worst] > 1:
        return _r(False, f"marked green but group status {worst}")
    if h.get("status") != worst:
        return _r(False, f"overall {h.get('status')} != worst group {worst}")
    return _r(True, "")


def verify_queue(submitted: Iterable[str], tasks: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:
    """Nothing submitted may vanish: every id is still present in a known state."""
    known = {"pending", "admitted", "running", "done", "failed", "unsupported_on_this_hardware"}
    for tid in submitted:
        t = tasks.get(tid)
        if t is None:
            return _r(False, f"task {tid} was dropped")
        if t.get("state") not in known:
            return _r(False, f"task {tid} in unknown state {t.get('state')}")
        if t["state"] == "done" and not t.get("history") is not None:
            pass
    return _r(True, "")


def verify_ocr_result(res: Dict[str, Any], min_conf: float = 55.0) -> Dict[str, Any]:
    if res.get("status") == "PASS":
        pages = res.get("pages")
        if pages is not None:
            if not pages or any(p.get("status") != "PASS" for p in pages):
                return _r(False, "PASS claimed but a page was not read cleanly")
            return _r(True, "")
        if not str(res.get("text", "")).strip():
            return _r(False, "PASS claimed with no text")
        c = res.get("confidence")
        if c is None or c < min_conf:
            return _r(False, "PASS claimed with low or missing confidence")
    return _r(True, "")


def verify_kill_result(res: Dict[str, Any]) -> Dict[str, Any]:
    if res.get("status") == "killed":
        if res.get("leftover_pids"):
            return _r(False, "processes survived the kill")
        if not res.get("why"):
            return _r(False, "kill without a reason")
    if res.get("status") == "finished" and res.get("killed"):
        return _r(False, "finished and killed at once")
    return _r(True, "")


def verify_roundtrip(original: Any, imported: Dict[str, Any], tampered_must_fail: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    if not imported.get("success") or imported.get("data") != original:
        return _r(False, "import did not return the exported data")
    if tampered_must_fail is not None and tampered_must_fail.get("success"):
        return _r(False, "a tampered/wrong-key import was accepted")
    return _r(True, "")


def verify_idle(res: Dict[str, Any], platform_name: str) -> Dict[str, Any]:
    if res.get("status") == "PASS" and platform_name != "Windows" and "injected" not in str(res.get("why", "")):
        return _r(False, "idle PASS claimed off Windows without an injected provider")
    if res.get("status") == "PASS" and res.get("idle") is None:
        return _r(False, "PASS with no idle value")
    return _r(True, "")


# ---------- F15: skills / design / diagrams / fetch / research / blog (each re-checks from plain data) ----------
def verify_skill_pick(task: str, picked: str, index: Dict[str, Any]) -> Dict[str, Any]:
    """A skill pick is plausible only if the skill exists and its name/description shares a real word with the task."""
    if not task or picked not in (index or {}):
        return _r(False, "skill not in index")
    words = {w for w in re.findall(r"[a-z0-9]{4,}", task.lower())}
    hay = (picked + " " + str(index[picked].get("description", ""))).lower()
    if not any(w in hay for w in words) and not any(w[:5] in hay for w in words if len(w) > 5):
        return _r(False, "no word of the task appears in the skill name/description")
    return _r(True, "task word found in skill text")


def verify_ai_score(text: str, verdict: str) -> Dict[str, Any]:
    """Chatbot residue is the most certain AI tell: if present the verdict cannot be LOW/MEDIUM."""
    t = (text or "").lower()
    residue = [p for p in ("great question", "i hope this helps", "certainly!", "as an ai language model") if p in t]
    if residue and verdict != "HIGH":
        return _r(False, f"residue {residue} present but verdict {verdict}")
    if verdict == "HIGH" and not residue and len(re.findall(r"\w+", t)) < 5:
        return _r(False, "HIGH on near-empty text")
    return _r(True, "verdict consistent")


def verify_design_row(csv_path: str, product: str, primary: str) -> Dict[str, Any]:
    import csv
    try:
        rows = list(csv.DictReader(open(csv_path, encoding="utf-8", newline="")))
    except Exception as exc:
        return _r(False, f"cannot read csv: {type(exc).__name__}")
    ok = any(r.get("Product Type") == product and (r.get("Primary") or "").lower() == (primary or "").lower() for r in rows)
    return _r(ok, "colour is a real CSV row" if ok else "product/colour pair not in CSV (invented?)")


def verify_svg(svg: str, labels: List[str]) -> Dict[str, Any]:
    import xml.etree.ElementTree as ET
    try:
        root = ET.fromstring(svg)
    except Exception:
        return _r(False, "svg is not well-formed XML")
    tags = [e.tag.split("}")[-1] for e in root.iter()]
    if "script" in tags or "foreignObject" in tags:
        return _r(False, "active content in svg")
    if re.search(r"(?i)(?:xlink:)?href=[\"']https?:", svg):
        return _r(False, "external reference in svg")
    text = re.sub(r"\s+", " ", " ".join("".join(e.itertext()) for e in root.iter() if e.tag.endswith("text")))
    miss = [l for l in labels if not all(w in text for w in l.split())]
    if miss or float(root.get("width", 0)) <= 0 or float(root.get("height", 0)) <= 0:
        return _r(False, f"labels missing {miss} or empty canvas")
    return _r(True, "svg well-formed, labels present")


def verify_fetch_result(res: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(res, dict) or "status" not in res:
        return _r(False, "no result")
    tried = res.get("tried", [])
    if res["status"] == "OK" and (not res.get("text") or not any(str(t.get("result", "")).startswith("http 2") for t in tried)):
        return _r(False, "OK without text or without a 2xx route")
    if res["status"] == "CHALLENGE" and (res.get("text") or (tried and tried[-1].get("challenge") not in ("captcha", "login", "paywall"))):
        return _r(False, "challenge result still carries text or the last route had no challenge (bypass?)")
    if res["status"] == "CHALLENGE" and any(t.get("challenge") in ("captcha", "login", "paywall") for t in tried[:-1]):
        return _r(False, "kept trying routes after a challenge")
    return _r(True, "fetch result consistent")


def verify_recent(res: Dict[str, Any]) -> Dict[str, Any]:
    items = res.get("items", [])
    for i in items:
        if not str(i.get("url", "")).startswith("http") or not re.fullmatch(r"\d{4}-\d{2}-\d{2}", str(i.get("date", ""))):
            return _r(False, "item without url/date")
    urls = {i["url"] for i in items}
    for f in res.get("facts", []):
        m = re.search(r"\((https?://[^)]+)\)", f)
        if not m or m.group(1) not in urls:
            return _r(False, "fact cites a url that is not an item")
    if any(not str(v).startswith("NEEDS_KEY") for k, v in res.get("sources", {}).items() if k in ("x/twitter", "youtube", "tiktok", "polymarket", "instagram")):
        return _r(False, "keyed source reported as used")
    return _r(True, "items carry url/date; facts cite items")


def verify_lint(html: str, rules: List[str]) -> Dict[str, Any]:
    exp = set()
    if re.search(r"(?i)<img\b(?![^>]*\balt=)", html or ""): exp.add("a11y-img-alt")
    if not re.search(r"(?i)<meta[^>]+name=[\"']viewport", html or ""): exp.add("responsive-viewport")
    if re.search(r"(?i)lorem ipsum", html or ""): exp.add("placeholder")
    miss = sorted(exp - set(rules))
    return _r(not miss, "lint reported the obvious problems" if not miss else f"lint missed {miss}")


def verify_blog_draft(path: str, topic: str, facts: List[str]) -> Dict[str, Any]:
    if not os.path.isfile(path):
        return _r(False, "draft file missing")
    txt = open(path, encoding="utf-8", errors="ignore").read()
    body = txt.split("\nSources:")[0]
    if "Sources:" not in txt:
        return _r(False, "no Sources section")
    ftxt = " ".join(facts).lower() + " " + topic.lower()
    inv = [n for n in re.findall(r"\d[\d,.]*", re.sub(r"(?m)^#.*$", "", body)) if n.strip(",.") and n.strip(",.") not in ftxt]
    if inv:
        return _r(False, f"numbers not in facts: {inv[:5]}")
    if re.search(r"(?i)lorem ipsum|\bTODO\b|\[insert", body):
        return _r(False, "placeholder text")
    return _r(topic.lower() in body.lower(), "draft grounded in facts" if topic.lower() in body.lower() else "topic not mentioned")


def verify_ladder_result(res: Dict[str, Any]) -> Dict[str, Any]:
    """A ladder answer counts only if a tier's own verifier passed, the winning attempt is the last one, and every attempt was recorded."""
    att = (res or {}).get("attempts") or []
    if not res or not att:
        return _r(False, "no attempts recorded")
    if res.get("ok"):
        if not att[-1].get("ok") or res.get("tier") != att[-1].get("tier"):
            return _r(False, "claimed success but the last attempt did not pass")
        if any(a.get("ok") for a in att[:-1]):
            return _r(False, "kept climbing after a passing tier")
        return _r(True, f"passed at {res['tier']} after {len(att)} attempt(s)")
    if any(a.get("ok") for a in att):
        return _r(False, "reported failure although an attempt passed")
    return _r(True, "honest failure: every tier failed verification")


def verify_engine_result(res: Dict[str, Any]) -> Dict[str, Any]:
    """An engine answer is only VERIFIED if it carries evidence-free-of-guessing rules: VERIFIED needs an answer, BLOCKED/FAILED need a reason, NOT_APPLICABLE shows no answer."""
    st = (res or {}).get("status")
    if st not in ("VERIFIED", "UNVERIFIED", "NOT_APPLICABLE", "BLOCKED", "FAILED"):
        return _r(False, f"unknown status {st}")
    if st in ("VERIFIED", "UNVERIFIED") and not (res.get("answer") or "").strip():
        return _r(False, f"{st} without an answer")
    if st in ("BLOCKED", "FAILED") and not res.get("reason"):
        return _r(False, f"{st} without a reason")
    if st == "NOT_APPLICABLE" and res.get("answer"):
        return _r(False, "NOT_APPLICABLE must not carry an answer")
    if st == "VERIFIED" and float(res.get("confidence") or 0) <= 0:
        return _r(False, "VERIFIED with zero confidence")
    return _r(True, f"{res.get('engine')}: {st} is consistent")


def verify_intake_report(rep: Dict[str, Any], copied_files: List[str]) -> Dict[str, Any]:
    """Intake safety: a BLOCKED/RESTRICTED pack must not have any code file copied into the library."""
    cls = (rep or {}).get("classification")
    if cls not in ("KNOWLEDGE_ONLY", "EXECUTABLE_LOCAL", "NEEDS_PROVIDER", "RESTRICTED", "BLOCKED"):
        return _r(False, "unknown classification")
    code = [f for f in copied_files if f.lower().endswith((".py", ".js", ".ts", ".mjs", ".cjs", ".sh", ".ps1", ".bat"))]
    if cls in ("RESTRICTED", "BLOCKED") and code:
        return _r(False, f"{cls} pack but code copied: {code[:2]}")
    return _r(True, f"{cls}: {len(copied_files)} text files, no forbidden code")
