"""
F15 real-task handlers: things a person actually types that used to fall through to an LLM/GUI planner and fail.
Every handler does the work itself, checks the result from outside (file exists / hash / word count) and says so
honestly. Nothing here fakes success: when facts, a model or a network are missing the reply says exactly that.

    match(text) -> name | ""        handle(text) -> reply str
Handlers: mkdir, summarise_file, download_to, blog_write, recall_fact, imperative_guard (bug-fix / code requests
are not definitions), open_target (browser / game) with the GOKU_MODE hint.
"""
from __future__ import annotations

import hashlib
import os
import re
from pathlib import Path
from typing import Any, Dict, List, Optional

_Q = r'(?:"([^"]+)"|\'([^\']+)\'|(\S+))'
_MKDIR = re.compile(r'(?is)^\s*(?:please\s+)?(?:naya|nayi|nai|new)?\s*(?:folder|directory)\s+(?:banao|bana\s*do|bana|create|make)\s+' + _Q + r'\s*$|^\s*(?:create|make|mkdir)\s+(?:a\s+)?(?:new\s+)?(?:folder|directory)\s+' + _Q + r'\s*$')
_SUMM = re.compile(r'(?is)^\s*(?:please\s+)?(?:summari[sz]e|summary\s+of)\s+' + _Q + r'\s*$|^\s*' + _Q + r'\s+(?:ko|ki|ka)\s+(?:summari[sz]e|summary|khulasa)\s*(?:karo|kardo|kar\s+do|do|banao)?\s*$')
_DL_TO = re.compile(r'(?is)^\s*(?:please\s+)?download\s+(https?://\S+)\s+(?:to|into|in|mein|me)\s+' + _Q + r'\s*$')
_BLOG_EN = re.compile(r'(?is)^\s*(?:please\s+)?(?:write|draft|compose|create|generate)\s+(?:me\s+)?(?:a|an|the)?\s*(?:(\d{2,4})[\s-]*words?\s+)?(?:blog|article|post)(?:\s+post)?\s+(?:about|on|for)\s+(.+?)\s*$')
_BLOG_UR = re.compile(r'(?is)^\s*(.+?)\s+(?:ke|ki|ka)\s+(?:upar|uper|oopar|baare\s+mein|bare\s+mein|baray\s+mein|mutaliq)\s+(?:(\d{2,4})\s*(?:words?|alfaaz)\s+(?:ka|ki|ke)?\s*)?(?:blog|article|post)\s+(?:likho|likh\s*do|likhein|likhna|banao|bana\s*do|write)\s*$')
_RECALL = re.compile(r'(?is)^\s*(?:mera|meri|mere)\s+(.+?)\s+(?:kya|kia|kaun|kaunsa)\s+(?:hai|h|he)\s*\??\s*$|^\s*what(?:\'s|\s+is)\s+my\s+(.+?)\s*\??\s*$|^\s*(?:tell\s+me\s+)?my\s+(.+?)\s*\?\s*$')
_CODEFIX = re.compile(r'(?is)^\s*(?:please\s+)?(?:fix|debug|refactor|repair|solve|correct|improve)\s+(?:this|the|my|is)?\s*(?:python|code|script|bug|error|program)\b')
_OPEN_BROWSER = re.compile(r'(?is)^\s*(?:please\s+)?(?:open|kholo|khol\s*do|launch|start)\s+(chrome|google\s+chrome|edge|firefox|browser)\b(.*)$')


_LADDER = re.compile(r"(?is)^\s*(?:ladder|model\s+tiers?)\s*(?:status|show)?\s*$")
_INTAKE = re.compile(r"(?is)^\s*skill\s+intake\b")
_ENGINE = re.compile(r"(?is)^\s*(?:engines?|intelligence)\s*(?:$|list\b|status\b|stats\b|report\b|health\b|solve\s*:|[a-z]+\s*:)")
_SKILL = re.compile(r"(?is)^\s*skills?\b(?:\s*:|\s+(?:list|find|show|plan|status|use)\b|\s*$)")
_DESIGN = re.compile(r"(?is)^\s*design\s+(search|brief|lint)\b")
_HUMAN = re.compile(r"(?is)^\s*humani[sz]e\s+(check|fix)\b")
_DIAGRAM = re.compile(r"(?is)^\s*diagram\s*:?\s*(flow(?:chart)?|sequence|seq|timeline)\b")
_RECENT = re.compile(r"(?is)^\s*research\s+recent\b")
_FETCHP = re.compile(r"(?is)^\s*(?:fetch|read)\s+page\s+https?://")
_THING = r"(?:landing\s*page|website|web\s*site|logo|banner|brand(?:ing)?|slides?|presentation|ppt|ui|dashboard|poster|game|diagram|flowchart|video)"
_MAKE = r"(?:design|banao|bana\s*do|create|make|build|kaise\s+banate)"
_NL_SKILL = re.compile(r"(?is)^\s*(?:please\s+)?(?:ek\s+)?(?:(?:\w+\s+){0,4}?" + _THING + r"\b.{0,60}?\b" + _MAKE + r"|" + _MAKE + r"\s+(?:a|an|me\s+ek|ek)?\s*(?:\w+\s+){0,3}?" + _THING + r"\b)")


def match(text: str) -> str:
    t = (text or "").strip()
    if _LADDER.match(t):
        return "ladder"
    if _INTAKE.match(t):
        return "skill_intake"
    if _ENGINE.match(t):
        return "engine"
    if _SKILL.match(t):
        return "skill"
    if _DESIGN.match(t):
        return "design"
    if _HUMAN.match(t):
        return "humanize"
    if _DIAGRAM.match(t):
        return "diagram"
    if _RECENT.match(t):
        return "research_recent"
    if _FETCHP.match(t):
        return "fetch_page"
    if _MKDIR.match(t):
        return "mkdir"
    if _DL_TO.match(t):
        return "download_to"
    if _BLOG_EN.match(t) or _BLOG_UR.match(t):
        return "blog_write"
    if _SUMM.match(t):
        return "summarise_file"
    if _RECALL.match(t) and not re.search(r"(?i)\b(capital|president|price|weather|time|date)\b", t) and _recall_value(t) is not None:
        return "recall_fact"
    if _CODEFIX.match(t):
        return "code_request"
    if _NL_SKILL.match(t) and not re.search(r"(?i)\b(open|kholo|play|download|install)\b", t):
        return "skill_nl"
    return ""


def _first(m: "re.Match[str]") -> str:
    return next((g for g in m.groups() if g), "")


def _mode_hint() -> str:
    try:
        from config import settings
        mode = str(getattr(settings, "GOKU_MODE", os.environ.get("GOKU_MODE", "dev")))
    except Exception:
        mode = os.environ.get("GOKU_MODE", "dev")
    if mode == "dev":
        return "\n  NOTE: GOKU_MODE='dev' hai -> LLM, GUI aur screenshots band hain. Chalane se pehle `set GOKU_MODE=run` karo (aur `python scripts\\real_task_suite.py` se check karo)."
    return ""


# ---------------------------------------------------------------- handlers
def mkdir(text: str) -> str:
    m = _MKDIR.match(text.strip())
    p = Path(os.path.expanduser(_first(m)))
    existed = p.is_dir()
    try:
        p.mkdir(parents=True, exist_ok=True)
    except Exception as exc:
        return f"[folder] nahi bana ({type(exc).__name__}: {exc})"
    if not p.is_dir():
        return f"[folder] bana nahi: {p}"
    return f"Folder {'pehle se maujood tha' if existed else 'ban gaya'} (check kiya: sach mein hai): {p}"


def summarise_file(text: str) -> str:
    m = _SUMM.match(text.strip())
    p = Path(os.path.expanduser(_first(m)))
    if not p.is_file():
        return f"[summary] file nahi mili: {p}"
    from brain import f15_text
    body = f15_text.read_any(p)
    if not body.strip():
        return f"[summary] {p.name} mein padhne layak text nahi mila (scanned/empty ho sakta hai: `ocr: {p}` try karo)."
    sents = f15_text.extractive_summary(body, 4)
    words = len(re.findall(r"\w+", body))
    return f"Summary of {p.name} ({words} words, extractive: sirf file ke apne jumle):\n  " + "\n  ".join(sents)


def download_to(text: str) -> str:
    m = _DL_TO.match(text.strip())
    url, dest = m.group(1), os.path.expanduser(next(g for g in m.groups()[1:] if g))
    from brain import task_contract
    lg = task_contract.make_contract(text).get("legal", {})
    if lg.get("blocked_domains") or lg.get("blocked_terms"):
        return "[download] roka gaya: piracy/unlicensed site ya crack wording - legal policy (" + ", ".join(lg.get("blocked_domains", []) + lg.get("blocked_terms", [])) + "). Legal source ka link do."
    from tools.download_robust import download_robust
    r = download_robust(url, dest)
    if not r.get("success"):
        return f"[download] fail: {r.get('status')} - {r.get('message', '')}"
    path = r.get("path") or r.get("file") or ""
    if not path or not os.path.isfile(path):
        return f"[download] server ne OK kaha lekin file disk par nahi mili ({r.get('status')})"
    sha = hashlib.sha256(Path(path).read_bytes()).hexdigest()
    return f"Download ho gaya aur disk par check kiya: {path} ({os.path.getsize(path)} bytes, sha256 {sha[:16]}...)"


_SYN = {"naam": ["name"], "name": ["naam"], "umar": ["age", "umr"], "age": ["umar", "umr"], "umr": ["age", "umar"], "shehar": ["city"], "city": ["shehar"],
        "number": ["phone", "mobile"], "phone number": ["number", "mobile"], "email": ["mail"], "pasandida rang": ["favorite colour", "favourite color", "favorite color"],
        "favourite color": ["favorite color", "pasandida rang"], "favorite color": ["favourite color", "pasandida rang"]}


def _recall_value(text: str):
    m = _RECALL.match(text.strip())
    if not m:
        return None
    key = _first(m).strip().lower()
    keys = [key] + _SYN.get(key, [])
    try:
        from brain import learning_hooks
        rows = []
        for k in keys:
            rows += learning_hooks.get_store().search(k, limit=25, touch=False)
    except Exception:
        rows = []
    pats = []
    for k in keys:
        pats += [re.compile(r"(?is)\bmy\s+" + re.escape(k) + r"\s+(?:is|=|:)\s+(.+)$"),
                 re.compile(r"(?is)\bmer[aie]\s+" + re.escape(k) + r"\s+(.+?)\s*(?:hai|h)?\s*$"),
                 re.compile(r"(?is)\b" + re.escape(k) + r"\s+(?:is|=|:)\s+(.+)$")]
    for row in rows:
        if row.get("untrusted"):
            continue
        c = str(row.get("content", "")).strip()
        for pt in pats:
            mm = pt.search(c)
            if mm:
                return key, mm.group(1).strip().rstrip("."), row
    return None


def recall_fact(text: str) -> str:
    r = _recall_value(text)
    if r is None:
        return "Mujhe is ki koi saved value nahi mili. Bolo: `remember my <cheez> is ...` taa-ke yaad rakhun."
    key, val, row = r
    return f"Tumhara {key}: {val}  (tumhari saved note #{row.get('id')} se)"


def code_request(text: str) -> str:
    paths = []
    from brain.task_agent import _existing_paths
    paths = _existing_paths(text)
    if paths:
        return (f"Code fix ke liye mujhe file `{paths[0]}` padhni hogi: pehle `analyze {paths[0]}` chalao (bugs/risks list hongi). "
                "Main file ko bina tumhari manzoori ke nahi badlunga." + _mode_hint())
    return "Kaun si file/error? File ka path ya error text bhejo (e.g. `fix python bug in \"C:\\\\path\\\\main.py\"`). Main andaaza se code nahi badalta." + _mode_hint()


def blog_write(text: str) -> str:
    t = text.strip()
    m = _BLOG_EN.match(t)
    if m:
        words, topic = m.group(1), m.group(2)
    else:
        m = _BLOG_UR.match(t)
        topic, words = m.group(1), m.group(2)
    from brain import f15_blog
    return f15_blog.write(topic, int(words) if words else 800, request=t)


def skill(text: str) -> str:
    from brain import skill_engine
    return skill_engine.handle_command(text)


def design(text: str) -> str:
    if re.match(r"(?is)^\s*design\s+lint\b", text):
        from brain import design_lint
        return design_lint.handle_command(text)
    from brain import design_search
    return design_search.handle_command(text)


def humanize(text: str) -> str:
    from brain import humanize_check
    return humanize_check.handle_command(text)


def diagram(text: str) -> str:
    from brain import diagram_svg
    return diagram_svg.handle_command(text)


def research_recent(text: str) -> str:
    from brain import recent_research
    return recent_research.handle_command(text)


def fetch_page(text: str) -> str:
    from brain import web_fetch_routes
    return web_fetch_routes.handle_command(text)


def skill_nl(text: str) -> str:
    """A build request ('landing page banao ...'): GOKU cannot silently build it with a 0.5B model, so it returns the
    matching skill, its status, the relevant checklist and (for UI) a data-backed design brief - clearly labelled."""
    from brain import skill_engine
    p = skill_engine.plan(text)
    out = skill_engine.render_plan(p)
    if p.get("ok") and p["skill"]["name"] in ("ui-ux-pro-max", "hallmark", "impeccable", "design", "ui-styling", "banner-design", "brand"):
        from brain import design_search
        out += "\n\n" + design_search.render(design_search.recommend(text))
    return out + "\n\n(Yeh playbook + data hai; poori file/page banane ke liye `GOKU_MODE=run` + model, ya tum brief approve karo to main HTML skeleton bana sakta hoon.)"


HANDLERS = {"engine": lambda t: __import__("brain.engines", fromlist=["x"]).handle_command(t) or "engine: unknown command", "ladder": lambda t: __import__("brain.ladder", fromlist=["x"]).status_text(), "skill_intake": lambda t: __import__("brain.skill_intake", fromlist=["x"]).handle_command(t), "skill": skill, "design": design, "humanize": humanize, "diagram": diagram, "research_recent": research_recent, "fetch_page": fetch_page, "skill_nl": skill_nl, "mkdir": mkdir, "summarise_file": summarise_file, "download_to": download_to, "recall_fact": recall_fact,
            "code_request": code_request, "blog_write": blog_write}


def handle(text: str) -> Optional[str]:
    name = match(text)
    if not name:
        return None
    try:
        return HANDLERS[name](text)
    except Exception as exc:                                 # never an empty or fake reply
        return f"[{name}] error: {type(exc).__name__}: {exc}"
