"""Stage F11: capability matrix - GREEN / YELLOW / RED per capability, from Stage 1 (P0) to the latest stage.

Every row is judged by the 14 acceptance criteria (source inspected, integrated, dependencies, unit, integration, failure-path,
regression, real environment, independent verification, evidence saved, low-memory, approval policy, recovery, limitations).
Rules: RED = module missing / stub / its tests fail or do not exist. GREEN = every APPLICABLE criterion satisfied. Anything that
claims live Windows/browser/account behaviour can NEVER be green without a saved live-evidence file evidence/live/<id>.json
({"live": true, ...}) - offline tests cannot prove it. YELLOW = the rest. The guidance table comes from scripts/guidance_probe.py.
usage: python scripts/capability_matrix.py [--no-pytest] [--junit file.xml]   (writes docs/CAPABILITY_MATRIX.{md,json,html}, evidence/matrix/*.json)
"""
import ast, importlib, json, os, re, shutil, subprocess, sys, time, types, ctypes
import xml.etree.ElementTree as ET
from unittest.mock import MagicMock

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
os.chdir(ROOT); sys.path.insert(0, ROOT)
os.environ.setdefault("GOKU_QA_NO_MODEL", "1")
for m in ("win32gui", "win32con", "win32api", "win32process", "win32ui", "pythoncom", "pyautogui"):
    sys.modules.setdefault(m, MagicMock())
if not hasattr(ctypes, "windll"):
    ctypes.windll = types.SimpleNamespace(user32=MagicMock(), gdi32=MagicMock(), kernel32=MagicMock())

def R(id, name, stage, mods, tests, live=False, mockfree=True, verifier=None, low_mem=False, approval=False, recovery=False, needs=(), limits="", live_needs=()):
    return dict(id=id, name=name, stage=stage, mods=mods, tests=tests, live=live, mockfree=mockfree, verifier=verifier, low_mem=low_mem, approval=approval, recovery=recovery, needs=list(needs), limits=limits, live_needs=list(live_needs))

ROWS = [
 R("hw_profile", "Hardware tier detection (1 GB .. 32 GB)", "P0", ["tools/hw_profile.py"], ["test_p0_hw_profile.py"], low_mem=True, verifier="classify_tier", limits="tiers are thresholds, real laptop numbers need laptop_validate.py"),
 R("resource_monitor", "RAM/CPU monitoring and budget governor", "P0", ["tools/resource_monitor.py", "tools/budget_governor.py"], ["test_p0_resource_monitor.py", "test_budget_governor.py"], low_mem=True, verifier="free_ram_mb", limits="free RAM vs GOKU's own RAM are separate numbers; process-tree accounting is partial"),
 R("safe_state", "Safe state + emergency stop", "P0", ["tools/safe_state.py", "tools/emergency_stop.py"], ["test_p0_safe_state.py", "test_p0_emergency_stop.py"], recovery=True, approval=True, verifier="is_stopped", limits="stop is cooperative; a hung native call cannot be force-killed from inside"),
 R("calc", "Exact calculator", "P2", ["brain/calc_engine.py"], ["test_p2_calc_engine.py"], verifier="verify", limits="refuses half-understood maths instead of guessing"),
 R("reasoning_agent", "Reasoning agent / dynamic thinking", "P2", ["brain/reasoning_engine.py", "brain/dynamic_thinking_engine.py"], ["test_p2_reasoning_agent.py", "test_dynamic_thinking.py"], verifier="verify", limits="rule based; real model reasoning not measured"),
 R("security_policy", "Security policy, prompt-injection guard, firewall", "E", ["security/policy.py", "security/safety_firewall.py", "security/untrusted.py"], ["test_stageE_security.py", "test_p6_prompt_injection.py", "test_firewall_bypass_adversarial.py"], approval=True, verifier="check", limits="static rules; novel attacks are not covered"),
 R("files_stream", "File streaming + FTS index (Stage A)", "A", ["tools/file_stream.py", "brain/doc_insight.py"], ["test_stageA_files.py", "test_stageA_extras.py"], low_mem=True, recovery=True, verifier="verify", limits="scanned PDFs need OCR; audio/video are metadata only"),
 R("screen_vision", "Screen understanding: frame diff, fusion, stale guard (Stage B)", "B", ["tools/vision/frame_diff.py", "tools/vision/screen_fusion.py"], ["test_stageB_screen.py", "test_stageB_extras.py"], live=True, mockfree=False, low_mem=True, verifier="verify", limits="verified with fake providers and generated images; real capture/UIA/OCR needs the laptop", live_needs=["real Windows capture", "UIA", "OCR"]),
 R("ram_partition", "RAM-aware partitioning (PartitionedRunner)", "B-RAM", ["tools/ram_planner.py"], ["test_ram_planner.py"], low_mem=True, recovery=True, verifier="verify", limits="proved with RLIMIT_AS on Linux, not on Windows"),
 R("memory_store", "Persistent memory (SQLite+FTS, TTL, redaction)", "C", ["brain/memory_store.py"], ["test_stageC_memory.py"], recovery=True, verifier="verify", limits="no cross-device sync; trust scores are heuristic"),
 R("route_planning", "Route planning / action planner", "C", ["brain/route_planner.py"], ["test_planner.py", "test_router_planner_root_cause.py"], verifier="verify", limits="plans are validated offline; execution on real apps is separate"),
 R("game_framework", "Game framework with honest rewards", "D", ["brain/game_framework.py", "tools/game_adapters.py"], ["test_stageD_game.py", "test_game_engine_honesty.py"], live=True, mockfree=False, verifier="verify", limits="no real game session was run; rewards are verified outcomes only", live_needs=["real game window"]),
 R("task_manager", "Task manager + tasks", "E", ["brain/task_manager.py"], ["test_stageE_tasks.py"], recovery=True, approval=True, verifier="verify", limits="state is local; no cloud sync"),
 R("qa_answer_engine", "Answer engine + core facts + honest abstention", "E2", ["brain/answer_engine.py"], ["test_stageE2_answer.py"], verifier="verify", limits="core facts pack is small; unknown stays unknown"),
 R("resource_strategy", "RAM strategy (20 techniques) + Ollama options", "F", ["tools/resource_strategy.py", "tools/isolated.py"], ["test_stageF_resources.py", "test_ollama_options.py"], low_mem=True, verifier="verify", limits="savings are estimates until model_bench runs on the laptop"),
 R("capability_planner", "Capability planner + pending queue", "F2", ["brain/capability_planner.py", "brain/capability_catalog.py"], ["test_stageF2_planner.py"], low_mem=True, recovery=True, verifier="verify", limits="estimated memory per work kind; calibration needs laptop numbers"),
 R("scheduler", "Work scheduler + piece runner", "F3", ["brain/work_scheduler.py", "brain/piece_runner.py"], ["test_stageF3_scheduler.py"], low_mem=True, recovery=True, verifier="verify", limits="one job at a time by design; Windows peak memory not measured"),
 R("control_layer", "Feature switches, presence, advisor, doc index", "F4", ["brain/feature_switches.py", "brain/presence.py", "brain/advisor.py", "brain/doc_index.py"], ["test_stageF4_control.py", "test_stageF4_docs.py"], approval=True, low_mem=True, verifier="verify", limits="idle detection on Windows is on-demand and untested live"),
 R("answer_pipeline", "Answer pipeline (resolve, decompose, solve, cross-check, label)", "F5", ["brain/answer_pipeline.py", "brain/dialog_state.py", "brain/decompose.py"], ["test_stageF5_intelligence.py", "test_stageF6_acceptance.py"], verifier="verify", limits="conservative rule engines"),
 R("seo_workflow", "SEO workflow + lessons", "F6", ["brain/seo_workflow.py", "brain/lesson_store.py"], ["test_stageF6_seo.py", "test_stageF6_lessons.py"], verifier="verify", limits="content is prepared offline; publishing is a separate gated step"),
 R("trace_route_gate", "Execution trace + route planning with RAM gate", "F7", ["brain/execution_trace.py", "brain/task_route_planner.py"], ["test_stageF7_capabilities.py"], low_mem=True, recovery=True, approval=True, verifier="verify", limits="downloads/translation/screen-watch are unit tested only"),
 R("download", "Downloads with size + hash check", "F7", ["tools/download.py"], ["test_stageF7_capabilities.py"], live=True, mockfree=False, recovery=True, verifier="verify", limits="no real download from the internet was run in tests", live_needs=["internet", "real site"]),
 R("translate_text", "Translation (Roman Urdu/English) with restriction preservation", "F7", ["brain/translate.py"], ["test_stageF7_capabilities.py"], verifier="restrictions", limits="offline rule translation is partial; needs a model for real translation"),
 R("benchmark_f8", "Recurring tasks, action gate, notify, content diff (F8)", "F8", ["brain/recurring_tasks.py", "brain/action_gate.py", "brain/content_diff.py", "brain/task_notify.py"], ["test_stageF8_benchmark.py"], approval=True, recovery=True, verifier="verify", limits="no real account/browser/notification service was used"),
 R("qa_mind", "QA mind: premise check, reasoning traps, honest unknown, self-correction", "F9", ["brain/qa_mind.py", "brain/qa_logic.py"], ["test_stageF9_qa.py"], low_mem=True, verifier="verify", limits="knowledge = 60 concepts + rules; benchmark is self-authored; real model quality unmeasured"),
 R("long_ledger", "1,200+ word command ledger", "F10-F11", ["brain/long_command.py"], ["test_stageF10_live.py", "test_stageF11_workflows.py"], recovery=True, approval=True, verifier="coverage", limits="rule based extraction; human-annotated reference set not yet supplied"),
 R("task_specs_preflight", "Live-task specs + capability preflight", "F10", ["brain/live_task_specs.py"], ["test_stageF10_live.py"], low_mem=True, approval=True, verifier="assess", limits="contracts only: nothing drives real YouTube/Shopify/installer"),
 R("ram_queue", "RAM-pending queue (single task admission)", "F10", ["brain/ram_queue.py"], ["test_stageF10_live.py"], low_mem=True, recovery=True, verifier="submit", limits="superseded by ram_scheduler for multi-task"),
 R("shopify_seo_oem", "Shopify meta, blog audit, OEM matching, publish compare", "F10-F11", ["brain/blog_seo.py"], ["test_stageF10_live.py", "test_stageF11_workflows.py"], live=True, mockfree=True, approval=True, verifier="compare_published", limits="no real Shopify session; spelling needs a dictionary; link reachability needs network", live_needs=["Shopify Admin login or API token"]),
 R("video_color_scan", "Video colour scan (streamed, honest coverage)", "F10", ["tools/video_color_scan.py"], ["test_stageF10_live.py"], low_mem=True, verifier="probe", limits="sampled; palette naming is coarse", needs=["ffmpeg"]),
 R("feedback_memory", "Feedback classes, improvement record, 7 memory types", "F10-F11", ["brain/feedback_fix.py"], ["test_stageF10_live.py", "test_stageF11_workflows.py"], approval=True, recovery=True, verifier="analyze", limits="root-cause patterns are regex; never edits source"),
 R("orchestrator", "Central orchestrator state machine (COMPLETED only with evidence)", "F11", ["brain/orchestrator.py"], ["test_stageF11_core.py"], approval=True, recovery=True, low_mem=True, verifier="verify", limits="not yet driving the real executor for every route; steps are injected callables"),
 R("ram_scheduler", "Multi-task RAM scheduler (light task runs, heavy queued, checkpoint pause)", "F11", ["brain/ram_scheduler.py"], ["test_stageF11_core.py"], low_mem=True, recovery=True, approval=True, verifier="select", limits="process-tree/browser memory is not measured here; real 1.1 GB case needs the laptop"),
 R("recovery_engine", "Failure diagnosis, uncertain-action read-back, duplicate refusal", "F11", ["brain/recovery.py"], ["test_stageF11_core.py"], recovery=True, approval=True, verifier="may_execute", limits="classification is pattern based; real external state read-back is the caller's job"),
 R("screen_loop", "Screen-aware action loop (fresh, cross-checked, verified)", "F11", ["brain/screen_state.py"], ["test_stageF11_perception.py"], live=True, mockfree=False, approval=True, verifier="diff", limits="runs on a FAKE screen in tests; the live Windows observer is not connected", live_needs=["Windows observer (UIA/OCR/capture)"]),
 R("video_audit", "Video audit: black/frozen/silence/clipping/cuts, correction, re-verify", "F11", ["tools/video_audit.py"], ["test_stageF11_perception.py"], low_mem=True, approval=True, recovery=False, verifier="verify_correction", needs=["ffmpeg"], limits="NOT done: face/hand/lip-sync/head movement/subtitle OCR (no model on this tier); synthetic clips only"),
 R("image_audit", "Image inspection with regions and uncertainty", "F11", ["tools/image_audit.py"], ["test_stageF11_perception.py"], low_mem=True, verifier="inspect", needs=["PIL", "numpy"], limits="no object/scene recognition; OCR only if tesseract is installed"),
 R("social_prep", "Social post package, validation, preview, approval gate", "F11", ["brain/social_prep.py"], ["test_stageF11_workflows.py"], live=True, approval=True, verifier="verify_published", limits="platform limits are a recalled snapshot; no real account/posting tested", live_needs=["logged-in platform session"]),
 R("install_policy", "Download/install policy (two approvals, hash, no bypass)", "F11", ["brain/install_plan.py"], ["test_stageF11_workflows.py"], live=True, approval=True, verifier="verify_install", limits="Authenticode/SmartScreen checks need Windows; no real installer run", live_needs=["Windows installer run"]),
 R("task_contract", "Task contract: exact-item spec, legal flag, success criteria (F14)", "F14", ["brain/task_contract.py"], ["test_stageF14_brain.py"], verifier="verify_contract", limits="regex/heuristic extraction checked against the command text; unseen phrasings can mis-extract a title; no human-labelled phrasing set yet"),
 R("route_search", "Multi-route search, scoring, policy, what-if (F14)", "F14", ["brain/route_search.py", "brain/cap_registry.py"], ["test_stageF14_brain.py"], low_mem=True, verifier="verify_ranking", limits="success priors are estimates until outcomes accumulate; web/page handlers are built in F15, so those routes are listed as not executable"),
 R("route_executor", "Route executor on the orchestrator: fallback, RAM pending, wrong-file quarantine (F14)", "F14", ["brain/route_executor.py"], ["test_stageF14_brain.py"], live=True, low_mem=True, approval=True, recovery=True, verifier="verify_item_claim", live_needs=["internet", "windows"], limits="proved against a local HTTP server and real files; real websites need evidence/live/route_executor.json from the laptop"),
 R("task_timeline", "Task timeline (F14)", "F14", ["brain/timeline.py"], ["test_stageF14_brain.py"], verifier="verify_timeline", limits="plain-language log; no GUI view yet"),
 R("capability_health", "Per-capability component health records (F13)", "F13", ["brain/capability_health.py"], ["test_stageF13_ocr_health.py", "test_stageF14_brain.py"], verifier="verify_health", limits="probes check presence/runnability; Windows-only parts stay UNVERIFIED off Windows"),
 R("ram_admission", "RAM admission: run if RAM allows else persistent PENDING (F13)", "F13", ["brain/admission.py"], ["test_stageF13_ocr_health.py", "test_stageF14_brain.py"], low_mem=True, recovery=True, verifier="verify_queue", limits="built on RamQueue; only route_exec is wired as a pending handler so far"),
 R("scan_ocr", "Scanned PDF / image / video-subtitle OCR (F13)", "F13", ["tools/scan_ocr.py", "tools/detectors.py"], ["test_stageF13_ocr_health.py", "test_stageF14_brain.py"], verifier="verify_ocr_result", limits="tesseract English only; RAM-light by design (one page at a time) but not measured; face/hand/lip-sync detectors are NOT_POSSIBLE until a model is plugged in"),
 R("download_robust", "Resumable, hash/MIME/redirect-checked downloader (F13)", "F13", ["tools/download_robust.py"], ["test_stageF13_download.py", "test_stageF14_brain.py"], live=True, recovery=True, verifier="verify_hash", live_needs=["internet"], limits="tested on a local server; real internet needs live evidence"),
 R("watchdog", "Watchdog: timeout/heartbeat + process-tree kill (F13)", "F13", ["tools/watchdog.py"], ["test_stageF13_platform.py", "test_stageF14_brain.py"], recovery=True, verifier="verify_kill_result", limits="Linux-tested; Windows tree kill unverified"),
 R("readback_export", "Read-back verification + state export/import (F13)", "F13", ["tools/readback.py"], ["test_stageF13_platform.py", "test_stageF14_brain.py"], recovery=True, verifier="verify_roundtrip", limits="HMAC integrity only, not encryption"),
 R("win_measure", "Windows idle / Job Object / hardware measurement (F13)", "F13", ["tools/win_measure.py"], ["test_stageF13_platform.py", "test_stageF14_brain.py"], live=True, verifier="verify_idle", live_needs=["windows"], limits="needs scripts/laptop_measure.py on the target laptop"),
 R("skill_engine", "Skill library (104 playbooks) + retrieval + injection scan + status (F15)", "F15", ["brain/skill_engine.py"], ["test_stageF15_skills.py"], verifier="verify_skill_pick", limits="retrieval is keyword/BM25, not understanding; 91 skills are knowledge-only; packs are third-party text and never executed"),
 R("humanize_check", "AI-writing pattern detector + safe fixes from the humanizer skill (F15)", "F15", ["brain/humanize_check.py"], ["test_stageF15_skills.py"], verifier="verify_ai_score", limits="detects tells, not authorship; voice rewrite needs a model or a person"),
 R("skill_intake", "Safe intake of third-party skill zips/folders: licence, deps, danger/injection scan, classification, text-only adoption + capsules (F15B)", "F15B", ["brain/skill_intake.py"], ["test_stageF15b_intake.py"], verifier="verify_intake_report", limits="static scan only; a clean scan is not a safety proof; code of BLOCKED/RESTRICTED packs is never copied or run"),
 R("intelligence_engines", "20 offline intelligence engines + hub (planner, bus, shared MemoryStore, self-evaluation); each numeric engine re-checks itself with an independent computation (F16)", "F16", ["brain/engines/__init__.py", "brain/engines/hub.py", "brain/engines/impl_core.py", "brain/engines/impl_more.py", "brain/f15_tasks.py"], ["test_stageF16_engines.py"], verifier="verify_engine_result", limits="heuristic engines (social, creative, research ranking) stay UNVERIFIED; optional libraries are only probed; real-Windows RAM/GPU numbers must be measured on the user machine"),
 R("ladder", "Escalation ladder L0 deterministic -> L1/L2/L3 models by installed size, escalate only on verifier failure, measured RAM/GPU records (F15B)", "F15B", ["brain/ladder.py"], ["test_stageF15b_ladder_audit.py"], verifier="verify_ladder_result", limits="proven against a fake Ollama only; real model quality, GPU use and RAM must be measured on the user's machine"),
 R("design_search", "Offline design data search + data-backed design brief (ui-ux-pro-max data) (F15)", "F15", ["brain/design_search.py"], ["test_stageF15_skills.py"], verifier="verify_design_row", limits="recommends from the dataset rows only; taste/brand fit is the user's call"),
 R("diagram_svg", "Flow / sequence / timeline SVG generator with self-check (F15)", "F15", ["brain/diagram_svg.py"], ["test_stageF15_skills.py"], verifier="verify_svg", limits="three diagram kinds; layout is simple (no crossing minimisation)"),
 R("web_fetch_routes", "Page fetch with alternative routes; challenges/login/paywall never bypassed (F15)", "F15", ["brain/web_fetch_routes.py"], ["test_stageF15_skills.py"], verifier="verify_fetch_result", limits="scrapling route needs pip install; JS-browser route needs RAM + playwright; real sites need live evidence"),
 R("recent_research", "Recent-posts research from public Hacker News / Reddit JSON (F15)", "F15", ["brain/recent_research.py"], ["test_stageF15_skills.py"], verifier="verify_recent", limits="keyed sources (X, YouTube, TikTok...) are NEEDS_KEY; Reddit often blocks anonymous clients"),
 R("design_lint", "HTML design/accessibility lint (F15)", "F15", ["brain/design_lint.py"], ["test_stageF15_skills.py"], verifier="verify_lint", limits="static checks only: no rendering, no layout measurement"),
 R("blog_writer", "Blog writing: research -> draft -> verify -> save, no invented facts (F15)", "F15", ["brain/f15_blog.py", "brain/f15_tasks.py"], ["test_stageF15_real_tasks.py", "test_stageF15_skills.py"], verifier="verify_blog_draft", limits="without a model the draft is facts-only (length = what facts support); live web research needs internet"),
]
RETIRED = [{"id": "action_machine_draft", "status": "SUPERSEDED", "why": "early F11 draft, never wired; replaced by brain/orchestrator.py + brain/recovery.py (file kept as retired/action_machine.py.txt)"}]
F12_TESTS = ["test_stageF12_integration.py", "test_stageF12_verifier.py", "test_stageF12_gaps_c.py", "test_stageF13_ocr_health.py", "test_stageF13_platform.py", "test_stageF13_download.py", "test_stageF14_brain.py", "test_stageF15_real_tasks.py", "test_stageF15_skills.py"]

# Explicit, reviewable map: (row, criterion kind) -> EXISTING older test(s) that genuinely exercise that behaviour. A test named here must exist AND pass.
COVERS = {
 ("skill_engine", "integration"): ["test_commands_reach_handlers"], ("skill_engine", "failure"): ["test_injection_text_in_a_skill_is_not_shown"],
 ("skill_intake", "integration"): ["test_routes_to_intake"], ("skill_intake", "failure"): ["test_dangerous_code_not_copied"],
 ("ladder", "integration"): ["test_escalates_only_on_verifier_failure_and_learns"], ("ladder", "failure"): ["test_all_tiers_fail_is_failure_not_guess"],
 ("humanize_check", "integration"): ["test_blog_reports_ai_pattern_verdict"], ("humanize_check", "failure"): ["test_humanize_fix_safe"],
 ("design_search", "integration"): ["test_commands_reach_handlers"], ("design_search", "failure"): ["test_design_search_no_match"],
 ("diagram_svg", "integration"): ["test_diagram_command_writes_file"], ("diagram_svg", "failure"): ["test_diagram_cycle_keeps_layers_bounded_and_verifier_catches_problems"],
 ("web_fetch_routes", "integration"): ["test_fetch_alternative_route_used_when_first_fails"], ("web_fetch_routes", "failure"): ["test_fetch_challenge_is_not_bypassed"],
 ("recent_research", "integration"): ["test_recent_research_parsing_failure_and_no_fake_sources"], ("recent_research", "failure"): ["test_recent_research_parsing_failure_and_no_fake_sources"],
 ("design_lint", "integration"): ["test_design_lint_flags_and_passes"], ("design_lint", "failure"): ["test_design_lint_flags_and_passes"],
 ("blog_writer", "integration"): ["test_blog_from_website_fetch"], ("blog_writer", "failure"): ["test_blog_no_facts_is_honest_not_invented"],

 ("hw_profile", "lowmem"): ["test_apply_tier_defaults_shrinks_ceiling_when_ram_is_really_short"],
 ("security_policy", "approval"): ["test_policy_overwrite_needs_confirmation", "test_executor_asks_before_install"],
 ("files_stream", "recovery"): ["test_analyze_many_splits_by_ram_and_pauses_instead_of_failing"],
 ("ram_partition", "lowmem"): ["test_tight_ram_means_small_parts_but_everything_is_done"],
 ("ram_partition", "recovery"): ["test_ram_never_recovers_job_is_paused_not_failed_and_resumes_without_loss_or_repeat"],
 ("task_manager", "failure"): ["test_failure_fails_task_and_optional_step_does_not"],
 ("task_manager", "approval"): ["test_confirmation_never_automatic"],
 ("resource_strategy", "failure"): ["test_render_and_fail_soft"],
 ("resource_strategy", "lowmem"): ["test_critical_pressure_refuses_llm_and_shrinks"],
 ("capability_planner", "failure"): ["test_unknown_work_is_honest"],
 ("capability_planner", "lowmem"): ["test_run_now_pieces_pending_impossible"],
 ("capability_planner", "recovery"): ["test_pending_timeline_resume_and_recovery"],
 ("scheduler", "failure"): ["test_failed_piece_is_failed_not_done"],
 ("scheduler", "lowmem"): ["test_pending_job_does_not_block_others_and_runs_when_ram_returns"],
 ("scheduler", "recovery"): ["test_crash_mid_run_is_recovered"],
 ("control_layer", "integration"): ["test_commands_route"],
 ("control_layer", "failure"): ["test_locked_features_refuse_and_say_why"],
 ("control_layer", "lowmem"): ["test_trial_run_shrinks_pieces_and_stays_correct"],
 ("answer_pipeline", "failure"): ["test_word_problems_refuse_what_they_cannot_do"],
 ("seo_workflow", "integration"): ["test_one_instruction_runs_all_stages_and_saves_outputs"],
 ("seo_workflow", "failure"): ["test_bad_credentials_never_pretend"],
 ("trace_route_gate", "integration"): ["test_task_agent_routes"],
 ("trace_route_gate", "failure"): ["test_unsupported_tasks_give_the_seven_points"],
 ("trace_route_gate", "lowmem"): ["test_low_ram_defers_instead_of_failing_and_resumes_when_capable"],
 ("download", "integration"): ["test_real_download_then_move_with_verification"],
 ("benchmark_f8", "failure"): ["test_wording_cannot_change_and_unverified_run_is_failed"],
 ("benchmark_f8", "approval"): ["test_action_gate_approval_prohibition_and_refusals"],
 ("benchmark_f8", "recovery"): ["test_send_ledger_never_duplicates_after_a_dropped_connection"],
 ("qa_mind", "failure"): ["test_unknown_is_honest"],
 ("qa_mind", "lowmem"): ["test_tier_call_counts"],
 ("long_ledger", "integration"): ["test_commands_route_through_task_agent"],
 ("long_ledger", "failure"): ["test_coverage_reports_dropped_and_needs_reason"],
 ("long_ledger", "approval"): ["test_approval_gate_is_not_a_conflict_but_real_conflict_is"],
 ("task_specs_preflight", "integration"): ["test_try_handle_end_to_end"],
 ("task_specs_preflight", "failure"): ["test_gate_statuses_and_alternatives"],
 ("task_specs_preflight", "lowmem"): ["test_gate_ram_decisions"],
 ("ram_queue", "integration"): ["test_ram_queue_pending_then_admitted"],
 ("ram_queue", "failure"): ["test_ram_queue_unsupported_and_pressure_and_unknown"],
 ("ram_queue", "lowmem"): ["test_ram_queue_reserves_ram_between_admissions"],
 ("video_color_scan", "integration"): ["test_video_scan_colors_unknown_and_honest_coverage"],
 ("video_color_scan", "failure"): ["test_video_scan_corrupt_and_missing"],
 ("video_color_scan", "lowmem"): ["test_video_scan_colors_unknown_and_honest_coverage"],
 ("orchestrator", "recovery"): ["test_failure_path_diagnoses_and_blocks_blind_retry"],
 ("trace_route_gate", "approval"): ["test_chat_draft_needs_approval_and_edit_removes_it", "test_handoff_intents_never_pass_from_the_planner"],
 ("trace_route_gate", "recovery"): ["test_internet_down_blocks_download_and_waits"],
 ("download", "recovery"): ["test_internet_down_blocks_download_and_waits"],
 ("long_ledger", "recovery"): ["test_persistence_corruption_migration_duplicates_graph"],
 ("task_specs_preflight", "approval"): ["test_gate_statuses_and_alternatives"],
 ("ram_queue", "recovery"): ["test_ram_queue_pending_then_admitted"],
 ("feedback_memory", "recovery"): ["test_memory_types_promotion_conflict_stale_forget"],
 ("feedback_memory", "integration"): ["test_feedback_report_counts_and_disagreement"],
 ("feedback_memory", "failure"): ["test_feedback_without_checker_is_unverified_and_one_time"],
 ("feedback_memory", "approval"): ["test_memory_layers_never_promote_unverified"],
 ("task_contract", "integration"): ["test_contract_extraction"], ("task_contract", "failure"): ["test_contract_ambiguity_and_legal"],
 ("route_search", "integration"): ["test_direct_url_route_is_first_and_executable"], ("route_search", "failure"): ["test_piracy_wording_blocked"], ("route_search", "lowmem"): ["test_ram_short_plan_kept_as_wait_not_dropped"],
 ("route_executor", "integration"): ["test_end_to_end_download_verified_match"], ("route_executor", "failure"): ["test_wrong_item_is_rejected_not_claimed"], ("route_executor", "lowmem"): ["test_ram_pending_persisted_and_auto_resumed"],
 ("route_executor", "approval"): ["test_approval_denied_by_default_for_approval_steps"], ("route_executor", "recovery"): ["test_html_posing_as_pdf_falls_back_to_guide"],
 ("task_timeline", "integration"): ["test_timeline_persisted_and_readable"], ("task_timeline", "failure"): ["test_mutation_verify_timeline"],
 ("capability_health", "integration"): ["test_real_env_command_runs"], ("capability_health", "failure"): ["test_missing_ocr_makes_screen_vision_not_green"],
 ("ram_admission", "integration"): ["test_admission_pends_then_resumes"], ("ram_admission", "failure"): ["test_admission_failure_recorded"], ("ram_admission", "lowmem"): ["test_admission_unmeasurable_and_unsupported_never_dropped"], ("ram_admission", "recovery"): ["test_pending_task_resumes_in_fresh_process_handler_lookup"],
 ("scan_ocr", "integration"): ["test_scanned_pdf_has_page_refs"], ("scan_ocr", "failure"): ["test_blank_image_is_unverified_not_pass"],
 ("download_robust", "integration"): ["test_resume_after_interruption_and_hash"], ("download_robust", "failure"): ["test_hash_mismatch_discards"], ("download_robust", "recovery"): ["test_resume_after_interruption_and_hash"],
 ("watchdog", "integration"): ["test_watchdog_kills_hung_tree"], ("watchdog", "failure"): ["test_watchdog_failed_rc"], ("watchdog", "recovery"): ["test_watchdog_chatty_child_does_not_deadlock"],
 ("readback_export", "integration"): ["test_export_import_integrity"], ("readback_export", "failure"): ["test_retry_policy_never_blind"], ("readback_export", "recovery"): ["test_file_readback"],
 ("win_measure", "integration"): ["test_measure_hardware_writes"], ("win_measure", "failure"): ["test_idle_unverified_off_windows_and_injectable"],
}
VERIFIERS = {"hw_profile": "verify_tier", "resource_monitor": "verify_within_budget", "safe_state": "verify_stop_log", "calc": "verify_arithmetic", "reasoning_agent": "verify_assignment",
             "security_policy": "verify_approval", "files_stream": "verify_search_hits", "screen_vision": "verify_screen_log", "ram_partition": "verify_chunks", "memory_store": "verify_memory_row",
             "route_planning": "verify_route_choice", "game_framework": "verify_reward", "task_manager": "verify_task_history", "qa_answer_engine": "verify_labelled_answer",
             "resource_strategy": "verify_within_budget", "capability_planner": "verify_chunks", "scheduler": "verify_plan_steps", "answer_pipeline": "verify_labelled_answer",
             "download": "verify_hash", "translate_text": "verify_numbers_preserved", "benchmark_f8": "verify_recurring", "orchestrator": "verify_trace", "ram_scheduler": "verify_schedule_log",
             "recovery_engine": "verify_trace", "video_audit": "verify_media_report", "image_audit": "verify_media_report", "install_policy": "verify_hash", "screen_loop": "verify_screen_log", "task_contract": "verify_contract", "route_search": "verify_ranking", "route_executor": "verify_item_claim", "skill_engine": "verify_skill_pick", "skill_intake": "verify_intake_report", "ladder": "verify_ladder_result", "intelligence_engines": "verify_engine_result", "humanize_check": "verify_ai_score", "design_search": "verify_design_row", "diagram_svg": "verify_svg", "web_fetch_routes": "verify_fetch_result", "recent_research": "verify_recent", "design_lint": "verify_lint", "blog_writer": "verify_blog_draft", "task_timeline": "verify_timeline", "capability_health": "verify_health", "ram_admission": "verify_queue", "scan_ocr": "verify_ocr_result", "download_robust": "verify_hash", "watchdog": "verify_kill_result", "readback_export": "verify_roundtrip", "win_measure": "verify_idle"}
for _r in ROWS:
    _r["f12"] = True
    if _r["id"] in VERIFIERS:
        _r["verifier"] = VERIFIERS[_r["id"]]; _r["vmod"] = "brain/verifier.py"
    _r["tests"] = list(_r["tests"]) + F12_TESTS

KEYS = {
 "integration": r"route|end_to_end|integrat|try_handle|pipeline|through|handle_command|command",
 "failure": r"fail|block|refus|corrupt|missing|unsupported|denied|stale|uncertain|reject|bad|error|unknown|honest|never|invalid|conflict|illegal|unsafe|injection|bypass|lost|cannot|wrong",
 "low_mem": r"reduced|pending|ram|memory|queue|sampled|tier|budget|pressure|piece|partition|window|low",
 "approval": r"approv|gate|denied|permission|confirm|consent|irreversible|authoris|authoriz|policy|blocked",
 "recovery": r"recover|retry|resume|checkpoint|uncertain|duplicate|corrupt|backup|restart|persist|crash|interrupt|survive|atomic",
}

def code_hash(mods):
    import hashlib
    h = hashlib.sha256()
    for m in mods:
        if os.path.exists(m):
            h.update(open(m, "rb").read().replace(b"\r\n", b"\n"))
    return h.hexdigest()[:16]

def stubs(path):
    try:
        t = ast.parse(open(path, encoding="utf-8", errors="ignore").read())
    except Exception as e:
        return None, f"syntax error {e}"
    n = bad = 0
    for f in ast.walk(t):
        if isinstance(f, (ast.FunctionDef, ast.AsyncFunctionDef)):
            n += 1
            body = [b for b in f.body if not (isinstance(b, ast.Expr) and isinstance(getattr(b, "value", None), ast.Constant))]
            if not body or all(isinstance(b, ast.Pass) or (isinstance(b, ast.Raise) and "NotImplemented" in ast.dump(b)) for b in body):
                bad += 1
    return (n, bad), ""

def run_junit(path):
    cmd = [sys.executable, "-c", "import sys,types,ctypes;from unittest.mock import MagicMock\n[sys.modules.__setitem__(m,MagicMock()) for m in ('win32gui','win32con','win32api','win32process','win32ui','pythoncom','pyautogui')]\nctypes.windll=types.SimpleNamespace(user32=MagicMock(),gdi32=MagicMock(),kernel32=MagicMock())\nimport pytest;sys.exit(pytest.main(sys.argv[1:]))", "tests", "-q", "--no-header", "-p", "no:cacheprovider", "--continue-on-collection-errors", f"--junitxml={path}"]
    subprocess.run(cmd, capture_output=True, text=True, cwd=ROOT)

def load_junit(path):
    res = {}
    for tc in ET.parse(path).getroot().iter("testcase"):
        f = tc.get("classname", "").split(".")
        file = "test_" + f[1].split("test_", 1)[-1] if len(f) > 1 and "test_" in f[1] else (f[-1] + ".py")
        file = (f[1] if len(f) > 1 else f[-1]) + ".py"
        st = "failed" if (tc.find("failure") is not None or tc.find("error") is not None) else "skipped" if tc.find("skipped") is not None else "passed"
        res.setdefault(file, []).append((tc.get("name"), st))
    return res

def main():
    jpath = "/tmp/goku_matrix_junit.xml"
    if "--junit" in sys.argv:
        jpath = sys.argv[sys.argv.index("--junit") + 1]
    elif "--no-pytest" not in sys.argv:
        run_junit(jpath)
    T = load_junit(jpath) if os.path.exists(jpath) else {}
    base = set()
    bp = os.environ.get("GOKU_BASELINE", "/tmp/b2.txt")
    if os.path.exists(bp):
        base = {re.sub(r"^(FAILED|ERROR) ", "", l.strip()) for l in open(bp)}
    docs = " ".join(open(os.path.join("docs", f), encoding="utf-8", errors="ignore").read() for f in os.listdir("docs") if f.endswith(".md")) if os.path.isdir("docs") else ""
    py_sources = {}
    for dp, dn, fn in os.walk("."):
        if any(x in dp for x in ("/tests", "/backups", "/__pycache__", "/venv", "/scripts", "/.git", "/state", "/logs")):
            continue
        for f in fn:
            if f.endswith(".py"):
                py_sources[os.path.join(dp, f)] = open(os.path.join(dp, f), encoding="utf-8", errors="ignore").read()
    os.makedirs("evidence/matrix", exist_ok=True)
    out = []
    for r in ROWS:
        c, why = {}, {}
        # 1 source
        ok1, det = True, []
        for m in r["mods"]:
            if not os.path.exists(m):
                ok1 = False; det.append(f"{m} missing"); continue
            st, err = stubs(m)
            if st is None:
                ok1 = False; det.append(err)
            elif st[0] == 0 or st[1] > 0:
                ok1 = False; det.append(f"{m}: {st[1]} stub function(s)")
            try:
                importlib.import_module(m[:-3].replace("/", "."))
            except Exception as e:
                ok1 = False; det.append(f"{m} import failed: {type(e).__name__}: {e}"[:120])
        c["1 source inspected"] = (ok1, "; ".join(det) or "files exist, import, no stub bodies")
        # 2 integrated
        names = [os.path.basename(m)[:-3] for m in r["mods"]]
        users = sorted({p for p, s in py_sources.items() for n in names if re.search(rf"(import\s+[^\n]*\b{n}\b|from\s+[\w\.]+\s+import\s+[^\n]*\b{n}\b|from\s+[\w\.]*{n}\s+import)", s) and os.path.basename(p)[:-3] not in names})
        c["2 integrated in the app"] = (bool(users), ("used by " + ", ".join(os.path.basename(u) for u in users[:3])) if users else "no other module imports it")
        # 3 dependencies / permissions
        miss = [n for n in r["needs"] if (not shutil.which(n) if n == "ffmpeg" else not __import__("importlib").util.find_spec(n))]
        if r["live_needs"]:
            c["3 dependencies+permissions verified"] = (False, "live permissions/sessions not verifiable offline: " + ", ".join(r["live_needs"]))
        else:
            c["3 dependencies+permissions verified"] = (not miss, ("missing: " + ", ".join(miss)) if miss else "declared tools present")
        # tests
        tl = [(n, s) for f in r["tests"] for n, s in T.get(f, []) if not f.startswith("test_stageF12") or (f"_{r['id']}_" in n or (f.endswith("verifier.py") and False))]
        passed = [n for n, s in tl if s == "passed"]
        failed = [n for n, s in tl if s == "failed"]
        _nf = [f for f in failed if not any(f in b for b in base)]
        c["4 unit tests pass"] = (bool(passed) and not _nf, (f"{len(passed)} passed, {len(failed)} failed" + (f" ({len(failed)-len(_nf)} pre-existing Windows-only baseline failures)" if failed and not _nf else "")) if tl else "no tests mapped/collected")
        KIND = {"integration": "integration", "failure": "failure", "low_mem": "lowmem", "approval": "approval", "recovery": "recovery"}
        # STRICT: a criterion counts only for a passing test explicitly tagged test_<rowid>_<kind>_ (no keyword guessing from free-form names)
        _bs = {}
        for v in T.values():
            for n, st_ in v:
                b = n.split("[", 1)[0]
                _bs[b] = _bs.get(b, True) and st_ == "passed"          # a parametrised test counts only when EVERY case passed
        allpassed = {b for b, ok_ in _bs.items() if ok_}
        sel = lambda k: [n for n in passed if re.match(rf"test_{re.escape(r['id'])}_{KIND[k]}_", n)] + [n for n in COVERS.get((r["id"], KIND[k]), []) if n in allpassed]
        c["5 integration tests pass"] = (bool(sel("integration")), f"{len(sel('integration'))} matching test(s)" if sel("integration") else "no integration-style test")
        c["6 failure-path tests pass"] = (bool(sel("failure")), f"{len(sel('failure'))} matching test(s)" if sel("failure") else "no failure-path test")
        newfail = [f for f in failed if not any(f in b for b in base)]
        c["7 regression clean"] = (not newfail and bool(tl), "no failing test in its files" if not newfail and tl else ("failing: " + ", ".join(newfail[:3]) if newfail else "no tests"))
        # 8 real environment
        ev = os.path.join("evidence", "live", r["id"] + ".json")
        if r["live"]:
            has = False
            try:
                has = bool(json.load(open(ev)).get("live"))
            except Exception:
                pass
            c["8 real-environment test"] = (has, "live evidence file present" if has else "NO live evidence (needs the real Windows PC / account)")
        else:
            c["8 real-environment test"] = (r["mockfree"] and bool(passed), "offline feature: tests exercise the real code (no mocks of the feature itself)" if r["mockfree"] else "tests rely on fakes")
        # 9 verifier
        vname = r["verifier"]; vmod = r.get("vmod")
        mods_v = ([vmod] if vmod else []) + list(r["mods"])
        has_def = bool(vname) and any(re.search(rf"def\s+{vname}\b", open(m, encoding='utf-8', errors='ignore').read()) for m in mods_v if os.path.exists(m))
        mut = [n for n, st_ in (T.get("test_stageF12_verifier.py", []) + T.get("test_stageF14_brain.py", []) + T.get("test_stageF15_skills.py", [])) if st_ == "passed" and n.startswith("test_mutation_") and vname and vname.replace("verify_", "") in n] if vmod else []
        has_v = has_def and (bool(mut) if vmod else True)
        c["9 output independently verified"] = (has_v, f"verifier `{vname}` in {vmod or 'module'} with passing mutation test" if has_v else ("verifier exists but no mutation (false-flag) test passed" if has_def else "no independent verifier function"))
        # 10 evidence
        c["10 evidence/logs saved"] = (bool(tl), "per-test results saved in evidence/matrix" if tl else "nothing to save")
        # 11-13 conditional
        for key, flag, label in (("low_mem", r["low_mem"], "11 low-memory behaviour tested"), ("approval", r["approval"], "12 approval policy tested"), ("recovery", r["recovery"], "13 recovery tested")):
            if flag:
                c[label] = (bool(sel(key)), f"{len(sel(key))} matching test(s)" if sel(key) else "applicable but no such test")
            else:
                c[label] = (None, "not applicable")
        lim_doc = bool(r["limits"]) and any(n in docs for n in names)
        c["14 limitations documented"] = (lim_doc, "limits stated + module named in docs" if lim_doc else "limits not found in docs/*.md")
        app = [v[0] for v in c.values() if v[0] is not None]
        red = (not c["1 source inspected"][0]) or (not c["4 unit tests pass"][0]) or (not c["7 regression clean"][0])
        miss_list = [k for k, v in c.items() if v[0] is False]
        live_only = bool(miss_list) and all(k.startswith(("3 ", "8 ")) for k in miss_list) and r["live"]
        color = "red" if red else ("green" if not miss_list else "yellow")
        status = "FAIL" if red else ("PASS_INTEGRATION" if not miss_list else ("PASS_OFFLINE_LIVE_PENDING" if live_only else "PASS_OFFLINE_GAPS"))
        row = {"id": r["id"], "name": r["name"], "stage": r["stage"], "color": color, "status": status, "live_claim": r["live"], "score": f"{sum(1 for v in app if v)}/{len(app)}", "criteria": {k: {"ok": v[0], "detail": v[1]} for k, v in c.items()}, "missing": miss_list, "limits": r["limits"]}
        out.append(row)
        json.dump({**row, "tests_passed": passed, "tests_failed": failed, "when": time.strftime("%Y-%m-%d %H:%M:%S"), "os": sys.platform, "python": sys.version.split()[0], "code_hash": code_hash(r["mods"])}, open(f"evidence/matrix/{r['id']}.json", "w"), indent=1)
    gp = {}
    for tag, p in (("F8", "/tmp/gp_F8.json"), ("F9", "/tmp/gp_F9.json"), ("F10", "/tmp/gp_F10.json"), ("F11", "/tmp/gp_f11.json")):
        if os.path.exists(p):
            gp[tag] = {x["id"]: x for x in json.load(open(p))["rows"]}
    json.dump({"retired": RETIRED, "rows": out, "guidance": {t: {k: {"trained_ok": v["trained_ok"], "unseen_ok": v["unseen_ok"], "needs_guidance": v["needs_guidance"]} for k, v in d.items()} for t, d in gp.items()}}, open("docs/CAPABILITY_MATRIX.json", "w"), indent=1, ensure_ascii=False)
    write_md(out, gp)
    write_html(out, gp)
    cnt = {k: sum(1 for r in out if r["color"] == k) for k in ("green", "yellow", "red")}
    cnt["live_pending"] = sum(1 for r in out if r["status"] == "PASS_OFFLINE_LIVE_PENDING")
    print(cnt)
    for r in out:
        print({"green": "G", "yellow": "Y", "red": "R"}[r["color"]], r["stage"], r["id"], r["score"], r["missing"][:3])

E = {"green": "\U0001F7E2", "yellow": "\U0001F7E1", "red": "\U0001F534"}
INTRO = {"qa_definition": "E2", "qa_math": "P2", "qa_false_premise": "F9", "qa_followup_capital": "F5", "qa_unknown_honest": "E2", "long_ledger": "F10", "capability_preflight": "F10", "ram_plan": "F2", "system_scan": "F2",
         "video_audit_missing": "F11", "image_audit": "F11", "blog_audit": "F11", "feedback_classify": "F11", "social_check": "F11", "translate": "F7", "remember_recall": "E2", "features_switches": "F4", "pending_list": "F2"}
ORDER = ["P0", "P2", "A", "B", "B-RAM", "C", "D", "E", "E2", "F", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9", "F10", "F10-F11", "F11"]

def write_md(rows, gp):
    cnt = {k: sum(1 for r in rows if r["color"] == k) for k in E}
    L = ["# GOKU capability matrix (Stage P0 -> F11)", "", f"{E['green']} green {cnt['green']}   {E['yellow']} yellow {cnt['yellow']}   {E['red']} red {cnt['red']}   (of {len(rows)} capabilities)", "",
         "GREEN = every applicable acceptance criterion satisfied. YELLOW = works offline but something required is missing (usually the real-Windows/account test). RED = failing, missing or untested code.",
         "A capability that claims live Windows/browser/account behaviour can NOT be green without evidence/live/<id>.json.", ""]
    for st in ORDER:
        rs = [r for r in rows if r["stage"] == st]
        if not rs:
            continue
        L.append(f"## Stage {st}")
        for r in rs:
            L.append(f"- {E[r['color']]} **{r['name']}** `{r['id']}` - {r['score']} criteria" + (" - LIVE claim" if r["live_claim"] else ""))
            L.append("  " + "  ".join(("✅" if v["ok"] else "❌" if v["ok"] is False else "➖") + k.split(" ", 1)[0] for k, v in r["criteria"].items()))
            if r["missing"]:
                L.append("  missing: " + "; ".join(f"{k.split(' ', 1)[1]} ({r['criteria'][k]['detail']})" for k in r["missing"]))
            L.append(f"  limits: {r['limits']}")
        L.append("")
    if gp:
        L += ["## Did GOKU need guidance? (same command, trained phrasing + 2 unseen paraphrases, first try, no hints)", "",
              "| capability | introduced | F8 | F9 | F10 | F11 |", "|---|---|---|---|---|---|"]
        for cid in INTRO:
            cells = []
            for tag in ("F8", "F9", "F10", "F11"):
                v = gp.get(tag, {}).get(cid)
                intro_i = ORDER.index(INTRO[cid]) if INTRO[cid] in ORDER else 0
                tag_i = ORDER.index(tag) if tag in ORDER else 99
                cells.append("not built yet" if tag_i < intro_i else ("\U0001F7E2 no guidance needed" if v and not v["needs_guidance"] else "\U0001F534 needed guidance" if v else "-"))
            L.append(f"| {cid} | {INTRO[cid]} | " + " | ".join(cells) + " |")
        L += ["", "Self-authored probe (3 phrasings per capability): it shows regressions and fixed gaps, it is not independent proof."]
    open("docs/CAPABILITY_MATRIX.md", "w", encoding="utf-8").write("\n".join(L))

def write_html(rows, gp):
    css = "body{font-family:system-ui,sans-serif;margin:16px;background:#fff;color:#111}@media(prefers-color-scheme:dark){body{background:#111;color:#eee}}.r{padding:8px 0;border-bottom:1px solid #8884}.d{display:inline-block;width:14px;height:14px;border-radius:50%;margin-right:8px;vertical-align:middle}.green{background:#1a9c4a}.yellow{background:#e0a800}.red{background:#d32f2f}small{opacity:.75}"
    h = [f"<!doctype html><html><head><meta charset=utf-8><meta name=viewport content='width=device-width,initial-scale=1'><title>GOKU Capability Matrix</title><style>{css}</style></head><body><h1>GOKU capability matrix</h1>"]
    cnt = {k: sum(1 for r in rows if r["color"] == k) for k in E}
    h.append(f"<p><span class='d green'></span>{cnt['green']} green &nbsp; <span class='d yellow'></span>{cnt['yellow']} yellow &nbsp; <span class='d red'></span>{cnt['red']} red</p>")
    for st in ORDER:
        for r in [x for x in rows if x["stage"] == st]:
            h.append(f"<div class=r><span class='d {r['color']}'></span><b>{r['name']}</b> <small>{st} - {r['score']}{' - live claim' if r['live_claim'] else ''}</small><br><small>" + (" | ".join(r["missing"]) if r["missing"] else "all applicable criteria met") + "</small></div>")
    h.append("</body></html>")
    open("docs/CAPABILITY_MATRIX.html", "w", encoding="utf-8").write("".join(h))

if __name__ == "__main__":
    main()
