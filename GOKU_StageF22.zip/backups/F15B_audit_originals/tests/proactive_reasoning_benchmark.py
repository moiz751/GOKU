﻿import os
import sys

sys.path.insert(0, os.path.abspath("."))

from command_layer.router import route_command

TEST_SUITE = [
    {
        "id": "PROACTIVE-01",
        "title": "Abstract High-Level Goal: Game Synthesis",
        "prompt": "mujhay aik mini game banani hai jo desktop par chal sakay",
        "expected_intent": "ABSTRACT_SYNTHESIS_GAME",
        "required_tools": ["write_file", "open_url"],
        "description": "Agent must understand 'game banani hai' requires writing a full runnable game asset and opening it."
    },
    {
        "id": "PROACTIVE-02",
        "title": "Abstract High-Level Goal: Blog Writing",
        "prompt": "mujhay AI Agents ke upar ek comprehensive blog likh kar do",
        "expected_intent": "ABSTRACT_SYNTHESIS_BLOG",
        "required_tools": ["launch_app", "focus_app_window", "type_text"],
        "description": "Agent must recognize content synthesis, launch editor, latch focus, and write formatted structure."
    },
    {
        "id": "PROACTIVE-03",
        "title": "Calculator Affordance & Next-Step Inference",
        "prompt": "calculator kholo aur 25 multiply by 4 karo",
        "expected_intent": "AFFORDANCE_CALCULATOR",
        "required_tools": ["launch_app", "focus_app_window", "send_keyboard_input"],
        "description": "Agent must pair launch with focus latch and keyboard math dispatch ('25*4=')."
    },
    {
        "id": "PROACTIVE-04",
        "title": "Mid-Sentence Goal Revision & Drop",
        "prompt": "Chrome kholo, phir socha Chrome mat kholo Calculator kholo, aur usme 12 aur 12 jama karo",
        "forbidden_tools": ["launch_app:Chrome"],
        "required_tools": ["launch_app", "send_keyboard_input"],
        "description": "Agent must drop cancelled entity (Chrome) and execute revised goal (Calculator + keypad input)."
    }
]

def run_proactive_eval():
    print("=" * 80)
    print("PROACTIVE COGNITIVE REASONING BENCHMARK")
    print("=" * 80)

    passed = 0
    total = len(TEST_SUITE)

    for idx, t in enumerate(TEST_SUITE, start=1):
        print(f"\n[{idx}/{total}] TEST: {t['title']} ({t['id']})")
        print(f"Prompt: \"{t['prompt']}\"")
        
        plan = route_command(t["prompt"])
        steps_summary = [(s.tool, s.args) for s in plan.steps] if plan and getattr(plan, "steps", None) else []
        tools_emitted = [s.tool for s in plan.steps] if plan and getattr(plan, "steps", None) else []
        flaws = []

        # Check required tools
        for req in t.get("required_tools", []):
            if req not in tools_emitted:
                flaws.append(f"Missing predicted tool: '{req}'")

        # Check forbidden tools
        for forb in t.get("forbidden_tools", []):
            if ":" in forb:
                tn, ta = forb.split(":")
                for s in plan.steps:
                    if s.tool == tn and ta.lower() in str(s.args).lower():
                        flaws.append(f"Emitted forbidden action: {forb}")
            elif forb in tools_emitted:
                flaws.append(f"Emitted forbidden tool: {forb}")

        # Check intent metadata
        intent_type = getattr(plan, "intent_metadata", {}).get("type", "UNKNOWN") if plan else "NONE"
        if "expected_intent" in t and intent_type != t["expected_intent"]:
            flaws.append(f"Expected intent '{t['expected_intent']}', got '{intent_type}'")

        if not flaws:
            print(f"-> [PASS] Successfully inferred intent: {intent_type}")
            print(f"   Emitted Steps: {steps_summary}")
            passed += 1
        else:
            print(f"-> [FAIL] Flaws: {flaws}")
            print(f"   Emitted Steps: {steps_summary}")

    print("\n" + "=" * 80)
    print(f"PROACTIVE REASONING SCORE: {passed}/{total} Passed ({(passed/total)*100:.1f}%)")
    print("=" * 80)

if __name__ == "__main__":
    run_proactive_eval()
