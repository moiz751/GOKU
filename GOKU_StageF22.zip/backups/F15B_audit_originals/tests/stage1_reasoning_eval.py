﻿import os
import sys

sys.path.insert(0, os.path.abspath('.'))

from command_layer.router import route_command
from command_layer.context import session_context
from command_layer.hcot_decomposer import HCoTDecomposer

REASONING_CHALLENGES = [
    {
        'id': 'REASON-01',
        'title': 'Temporal Order Inversion (Peeche Se Aage)',
        'prompt': "Notepad band karne se pehle usme 'SAVE_ME' likho, lekin likhne se pehle check karo Calculator khula hai ya nahi",
        'forbid_tools': []
    },
    {
        'id': 'REASON-02',
        'title': 'Conditional If-Else Branching Deduction',
        'prompt': "agar cmd se ping 8.8.8.8 pass ho jaye to notepad mein likho 'NET_ONLINE', warna 'NET_OFFLINE' likho",
        'forbid_tools': []
    },
    {
        'id': 'REASON-03',
        'title': 'Multi-Layer Contradiction & Cancellation Trap',
        'prompt': 'Chrome kholo, phir socha Chrome mat kholo Calculator kholo, aur usme 12 aur 12 jama karo',
        'forbid_tools': ['launch_app:chrome', 'open_url']
    },
    {
        'id': 'REASON-04',
        'title': 'Entity Extraction with Homonyms',
        'prompt': "File explorer kholo, 'Notepad' naam ka folder dhoondo aur uske andar 'cmd.txt' banao, Notepad app ko run mat karna",
        'forbid_tools': ['launch_app:Notepad', 'launch_app:notepad']
    },
    {
        'id': 'REASON-05',
        'title': 'Mathematical Transposition & Synthesis',
        'prompt': 'Pehle 20 mein 30 jama karo, jo result aaye usko 2 se multiply karo, aur final answer notepad mein likho',
        'forbid_tools': []
    },
    {
        'id': 'REASON-06',
        'title': 'Complex Triple Negation with Selective Immunity',
        'prompt': "Notepad kholo, likho 'DATA', desktop par save mat karna, window band mat karna, lekin calculator ko bilkul launch mat karna",
        'forbid_tools': ['save_file', 'close_app', 'launch_app:calculator', 'launch_app:Calculator']
    }
]

def run_test():
    print('=' * 80)
    print('STAGE 1: COGNITIVE REASONING & INTENT DISAMBIGUATION BENCHMARK')
    print('=' * 80)
    
    passed = 0
    total = len(REASONING_CHALLENGES)
    
    for idx, c in enumerate(REASONING_CHALLENGES, 1):
        print(f"\n[{idx}/{total}] CHALLENGE: {c['title']} ({c['id']})")
        print(f"Prompt: \"{c['prompt']}\"")
        
        dag = HCoTDecomposer.decompose_to_dag(c['prompt'])
        print(f"-> Decomposed into {len(dag)} stages.")
        
        try:
            plan = route_command(c['prompt'], session_context)
            if not plan or not getattr(plan, 'steps', None):
                print('-> [FAIL]: Null/Empty plan generated.')
                continue
                
            steps_summary = [(s.tool, s.args) for s in plan.steps]
            tools = [s.tool for s in plan.steps]
            
            flaws = []
            for f in c['forbid_tools']:
                if ':' in f:
                    t_name, t_arg = f.split(':')
                    for s in plan.steps:
                        if s.tool == t_name and t_arg.lower() in str(s.args).lower():
                            flaws.append(f"Forbidden tool call: {f}")
                elif f in tools:
                    flaws.append(f"Forbidden tool call: {f}")
            
            if flaws:
                print(f"-> [FAIL]: {flaws}")
                print(f"   Emitted: {steps_summary}")
            else:
                print('-> [PASS]: Reasoned successfully.')
                print(f"   Emitted: {steps_summary}")
                passed += 1
        except Exception as e:
            print(f"-> [CRASH]: {str(e)}")
            
    print('\n' + '=' * 80)
    print(f"STAGE 1 RESULT: {passed}/{total} Passed ({(passed/total)*100:.1f}%)")
    print('=' * 80)

if __name__ == '__main__':
    run_test()
