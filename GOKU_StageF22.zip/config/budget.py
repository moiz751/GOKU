"""
config/budget.py - Authoritative RAM & Resource Budget Specification for GOKU.
Thin wrapper reading single source of truth from tools.budget_governor.
Stage 1 Prompt T1.10o: Unified process tree budget gate (512 MB soft floor, 1100 MB hard ceiling).
"""
from __future__ import annotations

import os
import sys
import threading
from typing import Any, Dict, List, Optional, Tuple

import psutil

from tools.budget_governor import (
    GOKU_BUDGET_MB,
    GOKU_BUDGET_MAX_MB,
    RAM_MARGIN_MB,
    get_free_ram_mb,
    tree_private_mb,
)

# Core Budget Thresholds (in Megabytes) - unified with tools.budget_governor
MAX_AGENT_USS_MB: float = float(GOKU_BUDGET_MB)  # 512.0 MB soft floor target
MAX_AGENT_CEILING_MB: float = float(GOKU_BUDGET_MAX_MB)  # 1100.0 MB hard ceiling
MAX_PERCEPTION_USS_MB: float = 8.0
MAX_LLM_RESIDENT_IDLE_MB: float = 0.0
MIN_FREE_RAM_FOR_LLM_MB: float = 500.0
ONE_MODEL_CALL_AT_A_TIME: bool = True

# Global Concurrency Lock enforcing exactly one model call at a time
MODEL_CALL_LOCK = threading.Lock()


def get_process_memory_breakdown(proc: psutil.Process) -> Dict[str, float]:
    """Retrieves authoritative memory metrics for a single psutil.Process."""
    try:
        mf = proc.memory_full_info()
        uss_mb = getattr(mf, "uss", getattr(mf, "private", mf.rss)) / (1024 * 1024)
        rss_mb = mf.rss / (1024 * 1024)
        return {"uss_mb": round(uss_mb, 2), "rss_mb": round(rss_mb, 2)}
    except Exception:
        try:
            mi = proc.memory_info()
            rss_mb = mi.rss / (1024 * 1024)
            return {"uss_mb": round(rss_mb, 2), "rss_mb": round(rss_mb, 2)}
        except Exception:
            return {"uss_mb": 0.0, "rss_mb": 0.0}


def get_agent_and_children_memory(pid: Optional[int] = None) -> Dict[str, Any]:
    """
    Measures memory for the agent process and all descendant child processes.
    Uses psutil.Process.memory_full_info().uss to calculate exact Unique Set Size.
    Returns itemized breakdown and aggregate sums.
    """
    target_pid = pid or os.getpid()
    breakdown: Dict[int, Dict[str, Any]] = {}
    total_uss_mb = 0.0
    total_rss_mb = 0.0
    pids_measured: List[int] = []

    try:
        parent = psutil.Process(target_pid)
        parent_mem = get_process_memory_breakdown(parent)
        breakdown[target_pid] = {
            "name": parent.name(),
            "role": "agent_parent",
            "uss_mb": parent_mem["uss_mb"],
            "rss_mb": parent_mem["rss_mb"],
        }
        total_uss_mb += parent_mem["uss_mb"]
        total_rss_mb += parent_mem["rss_mb"]
        pids_measured.append(target_pid)

        # Collect all children recursively
        children = parent.children(recursive=True)
        for child in children:
            try:
                c_pid = child.pid
                c_mem = get_process_memory_breakdown(child)
                breakdown[c_pid] = {
                    "name": child.name(),
                    "role": "child_process",
                    "uss_mb": c_mem["uss_mb"],
                    "rss_mb": c_mem["rss_mb"],
                }
                total_uss_mb += c_mem["uss_mb"]
                total_rss_mb += c_mem["rss_mb"]
                pids_measured.append(c_pid)
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
    except (psutil.NoSuchProcess, psutil.AccessDenied):
        pass

    return {
        "parent_pid": target_pid,
        "pids": pids_measured,
        "child_count": len(pids_measured) - 1,
        "total_uss_mb": round(total_uss_mb, 2),
        "total_rss_mb": round(total_rss_mb, 2),
        "budget_limit_mb": MAX_AGENT_USS_MB,
        "is_within_budget": total_uss_mb <= MAX_AGENT_USS_MB,
        "headroom_mb": round(MAX_AGENT_USS_MB - total_uss_mb, 2),
        "processes": breakdown,
    }


def check_agent_budget(pid: Optional[int] = None) -> Tuple[bool, str, Dict[str, Any]]:
    """
    Validates whether the agent tree USS is within the budget limit.
    Returns (within_budget, explanation, metrics).
    """
    data = get_agent_and_children_memory(pid)
    uss = data["total_uss_mb"]
    pids = data["pids"]
    if uss <= MAX_AGENT_USS_MB:
        msg = f"Agent tree USS ({uss:.2f} MB across {len(pids)} PIDs) is within budget (<= {MAX_AGENT_USS_MB:.1f} MB)."
        return True, msg, data
    msg = f"Agent tree USS ({uss:.2f} MB across {len(pids)} PIDs) EXCEEDS budget limit ({MAX_AGENT_USS_MB:.1f} MB) by {uss - MAX_AGENT_USS_MB:.2f} MB."
    return False, msg, data


def check_perception_budget(current_perception_mb: float) -> Tuple[bool, str]:
    """Validates perception working buffer memory against the <= 8 MB limit."""
    if current_perception_mb <= MAX_PERCEPTION_USS_MB:
        return True, f"Perception buffer {current_perception_mb:.2f} MB within limit (<= {MAX_PERCEPTION_USS_MB} MB)."
    return False, f"Perception buffer {current_perception_mb:.2f} MB exceeds budget limit ({MAX_PERCEPTION_USS_MB} MB)."


def check_system_ram_for_llm() -> Tuple[bool, float, str]:
    """
    Inspects physical available memory before model inference.
    Enforces minimum 500 MB free RAM before permitting any model call,
    using tools.budget_governor.get_free_ram_mb() as underlying source.
    """
    available_mb = get_free_ram_mb()
    if available_mb < MIN_FREE_RAM_FOR_LLM_MB:
        return False, available_mb, (
            f"Model call rejected: Available RAM {available_mb:.1f} MB is below "
            f"safety threshold {MIN_FREE_RAM_FOR_LLM_MB:.1f} MB."
        )
    return True, available_mb, f"Available RAM {available_mb:.1f} MB is sufficient for model call."
