"""
Central configuration settings for the offline agent.
Follows GOKU RULES v2 + 16-26 (Prompt R1 Step 5).
"""
from __future__ import annotations

import os
from typing import Any

# GOKU Execution Mode: 'dev' (default) or 'run'
# dev: LLM disabled, no model load, no GUI, no screenshots.
# run: model allowed only when readiness is READY or DEGRADED.
GOKU_MODE = os.environ.get("GOKU_MODE", "dev").lower()
if GOKU_MODE not in ("dev", "run"):
    GOKU_MODE = "dev"

# Dynamic RAM margin (MB)
RAM_MARGIN_MB = float(os.environ.get("GOKU_RAM_MARGIN_MB", "150.0"))


def get_goku_mode() -> str:
    """Returns current GOKU_MODE dynamically from environment or default."""
    m = os.environ.get("GOKU_MODE", GOKU_MODE).lower()
    return m if m in ("dev", "run") else "dev"


def get_governor_mode() -> str:
    """Returns the current governor mode: 'off' | 'log' | 'enforce'."""
    val = os.environ.get("GOKU_GOVERNOR")
    if val:
        mode = val.lower().strip()
        if mode in ("off", "log", "enforce"):
            return mode
    return "enforce" if get_goku_mode() == "run" else "log"


def get_model_footprint_mb() -> tuple[float, str]:
    """Returns (footprint_mb, source_label) from RESOURCE_BUDGET.json S3 if present, else (520.0, 'estimate')."""
    try:
        from tools.readiness import get_budget_path
        p = get_budget_path()
        if p.exists():
            import json
            with open(p, "r", encoding="utf-8") as f:
                data = json.load(f)
            inc = data.get("increments", {})
            s3_val = inc.get("inference_peak_available_drop_mb") or inc.get("inference_peak_runner_delta_mb")
            if s3_val is not None and float(s3_val) > 0:
                base = inc.get("ollama_runner_rss_mb") or 0.0
                total = float(base) + float(s3_val)
                return round(total, 2), "measured"
    except Exception:
        pass
    return 520.0, "estimate"


def is_model_call_allowed() -> tuple[bool, str]:
    """
    Evaluates whether LLM / model invocations are permitted.
    - dev mode: LLM disabled, no model load, no GUI, no screenshots.
    - run mode: model allowed only when readiness is READY or DEGRADED,
      AND projected memory (tree_private_mb + model footprint) <= GOKU_BUDGET_MAX_MB.
    """
    mode = get_goku_mode()
    if mode == "dev":
        return False, "GOKU_MODE is 'dev': LLM disabled, no model load, no GUI, no screenshots."

    if mode == "run":
        try:
            from tools.readiness import check_readiness
            res = check_readiness()
            verdict = res.get("verdict", "UNKNOWN")
            if verdict not in ("READY", "DEGRADED"):
                return False, f"Model call blocked in GOKU_MODE=run: readiness is {verdict} ({res.get('reason')})"
        except Exception as e:
            return False, f"Model call blocked in GOKU_MODE=run: readiness check failed ({e})"

        # Projection check against GOKU_BUDGET_MAX_MB
        try:
            from tools.budget_governor import tree_private_mb, GOKU_BUDGET_MAX_MB, _format_top_memory_consumers
            model_mb, source_label = get_model_footprint_mb()
            cur_tree = tree_private_mb()
            projected = round(cur_tree + model_mb, 2)
            if projected > GOKU_BUDGET_MAX_MB:
                return False, (
                    f"Model call blocked in GOKU_MODE=run: projected tree memory {projected:.1f} MB "
                    f"(tree now {cur_tree:.1f} MB + model {model_mb:.1f} MB [{source_label}]) "
                    f"exceeds ceiling {GOKU_BUDGET_MAX_MB} MB.\n"
                    f"{_format_top_memory_consumers()}"
                )
            return True, f"Model call allowed in GOKU_MODE=run (Readiness: {verdict})"
        except Exception as ex:
            return False, f"Model call blocked in GOKU_MODE=run: tree budget check failed ({ex})"

    return False, f"Model call blocked: unknown mode '{mode}'"


# Ollama model configurations
OLLAMA_BASE_URL = os.environ.get("OLLAMA_BASE_URL", "http://127.0.0.1:11434")
OLLAMA_URL = f"{OLLAMA_BASE_URL.rstrip('/')}/api/chat"
OLLAMA_TAGS_URL = f"{OLLAMA_BASE_URL.rstrip('/')}/api/tags"
MODEL = "qwen2.5:0.5b"

# Timeout bounds (in seconds)
OLLAMA_STARTUP_TIMEOUT = 20
OLLAMA_CONNECT_TIMEOUT = 3
OLLAMA_REQUEST_TIMEOUT = 25

# Security configurations
CONFIRMATION_TIMEOUT_SECONDS = 60

# Execution and retry bounds
MAX_RETRIES = 3
RETRY_DELAY_SECONDS = 0.5

# Search and file listings limits
MAX_FIND_MATCHES = 10

# Human Live Operator Execution Mode
HUMAN_MODE = True
DIRECT_MODE = False

# Confidence thresholds for multi-tier routing (Prompt P6 Item 3)
CONFIDENCE_HIGH_THRESHOLD = float(os.environ.get("GOKU_CONF_HIGH", "0.85"))
CONFIDENCE_MEDIUM_THRESHOLD = float(os.environ.get("GOKU_CONF_MED", "0.50"))

# Ollama model gating & token limits (Prompt P6 Item 4, Prompt T1.10d)
GOKU_NUM_CTX = int(os.environ.get("GOKU_NUM_CTX", "1024"))


def _parse_num_batch(val_any: Any = None) -> int:
    """Clamps num_batch to 8..512, defaulting to 64 on invalid/missing values."""
    if val_any is None:
        val_any = os.environ.get("GOKU_NUM_BATCH")
    if val_any is None or val_any == "":
        return 64
    try:
        iv = int(val_any)
        if iv < 8:
            return 8
        if iv > 512:
            return 512
        return iv
    except (ValueError, TypeError):
        return 64


# Import-time semantics of GOKU_NUM_BATCH (default 64, clamped to 8..512)
GOKU_NUM_BATCH = _parse_num_batch(os.environ.get("GOKU_NUM_BATCH"))


def ollama_options(
    temperature: float | None = None,
    num_predict: int | None = None,
    extra: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """
    Returns the standard options dictionary containing shared RAM options:
    - num_ctx: GOKU_NUM_CTX (or dynamic GOKU_NUM_CTX env override)
    - num_batch: GOKU_NUM_BATCH (or dynamic GOKU_NUM_BATCH env override clamped to 8..512)
    plus caller-specified temperature, num_predict, and extra options.
    """
    ctx = int(os.environ.get("GOKU_NUM_CTX", GOKU_NUM_CTX))
    batch = _parse_num_batch(os.environ.get("GOKU_NUM_BATCH", GOKU_NUM_BATCH))
    opts: dict[str, Any] = {
        "num_ctx": ctx,
        "num_batch": batch,
    }
    if temperature is not None:
        opts["temperature"] = float(temperature)
    if num_predict is not None:
        opts["num_predict"] = int(num_predict)
    if extra and isinstance(extra, dict):
        opts.update(extra)
    return opts


GOKU_KEEP_ALIVE = int(os.environ.get("GOKU_KEEP_ALIVE", "0"))
OLLAMA_KEEP_ALIVE = GOKU_KEEP_ALIVE
def is_low_power_enabled() -> bool:
    """Checks whether low power mode is enabled via environment or mode default."""
    val = os.environ.get("GOKU_LOW_POWER")
    if val is not None:
        return val.lower().strip() in ("1", "true", "yes", "on")
    return get_goku_mode() == "run"


GOKU_LOW_POWER = 1 if is_low_power_enabled() else 0
MAX_INPUT_CHARS = int(os.environ.get("GOKU_MAX_INPUT_CHARS", "1000"))
NUM_PREDICT_CAP = int(os.environ.get("GOKU_NUM_PREDICT", "128"))

# Cloud mode configuration (Prompt P7: optional and OFF by default)
CLOUD_MODE_ENABLED = os.environ.get("GOKU_CLOUD_MODE", "false").lower() in ("true", "1", "yes")

# Log rotation bounds & size management (Prompt P7 Item 5)
MAX_LOG_FILE_BYTES = int(os.environ.get("GOKU_MAX_LOG_BYTES", str(2 * 1024 * 1024)))  # 2 MB cap
MAX_LOG_BACKUPS = int(os.environ.get("GOKU_MAX_LOG_BACKUPS", "3"))
ENABLE_LOG_COMPRESSION = True


