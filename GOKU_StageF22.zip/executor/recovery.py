"""
Adaptive Error Recovery Handlers for Desktop GUI Automation.
Provides intelligent retries, automatic window refocusing, and scroll adjustments
when visual targets are not immediately located.
"""
import time
from typing import Any, Callable

from tools.gui import mouse_scroll
from tools.processes import focus_app


def retry_with_recovery(
    action_fn: Callable[[], dict[str, Any]],
    target_name: str | None = None,
    app_name: str | None = None,
    max_retries: int = 2,
) -> dict[str, Any]:
    """
    Executes an action function with adaptive recovery strategies:
    1. First execution attempt.
    2. If failed and app_name provided -> Re-focus the target application window and retry.
    3. If failed -> Scroll down slightly and retry.
    4. If still failed -> Scroll up and retry.
    """
    result = action_fn()
    if result.get("success"):
        return result

    # Recovery Strategy 1: Bring application to foreground if specified
    if app_name:
        focus_app(app_name)
        time.sleep(0.3)
        result = action_fn()
        if result.get("success"):
            return result

    # Recovery Strategy 2: Scroll down to check below the viewport
    mouse_scroll(clicks=3, direction="down")
    time.sleep(0.3)
    result = action_fn()
    if result.get("success"):
        return result

    # Recovery Strategy 3: Scroll back up
    mouse_scroll(clicks=6, direction="up")
    time.sleep(0.3)
    result = action_fn()
    return result
