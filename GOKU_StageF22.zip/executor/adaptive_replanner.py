"""
Adaptive Replanner Module for GOKU / MARK Autonomous Agent.
Provides failure classification, UI safety guards, and bounded replanning
synthesis when execution steps fail.
"""
from __future__ import annotations

from typing import Any, Optional
from brain.planner import Plan, PlanStep, PlanAdaptation, synthesize_adaptive_replan


def replan_failed_step(
    current_plan: Plan,
    failed_step: PlanStep,
    error_result: dict,
    context: Any = None,
) -> tuple[Plan, Optional[PlanAdaptation]]:
    """
    Safely synthesize an adaptive replan for a failed step.
    Guarantees no blind Enter keypress fallback for missing UI elements.
    """
    if failed_step.tool in ("click_ui_element", "locate_ui_element", "wait_for_ui_element", "click_element_by_text"):
        target_name = (
            failed_step.args.get("query")
            or failed_step.args.get("target_text")
            or failed_step.args.get("name")
            or failed_step.args.get("target")
            or failed_step.args.get("element")
            or "element"
        )
        msg = f"Element '{target_name}' not found on active screen."
        if current_plan:
            current_plan.is_direct_message = True
            current_plan.message_text = msg
            current_plan.explanation = msg
            current_plan.steps = []
        return current_plan, None

    return synthesize_adaptive_replan(current_plan, failed_step, error_result, context=context)
