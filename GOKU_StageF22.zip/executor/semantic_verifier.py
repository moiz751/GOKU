"""
Semantic Outcome Verifier for MARK/GOKU Autonomous Agent.
Validates whether the observed state matches the requested semantic expectation.
Differentiates between tool execution success and true semantic task success using truth_oracle.
"""
from typing import Any
from command_layer.semantic_model import SemanticDomain, SemanticAction


def verify_semantic_outcome(
    domain: SemanticDomain,
    action: SemanticAction,
    target: str,
    tool_result: dict[str, Any]
) -> dict[str, Any]:
    """
    Evaluates observed state against expected task outcome.
    Uses truth_oracle to independently verify physical state changes.

    Returns:
        {
            "tool_success": bool,
            "semantic_success": bool,
            "task_success": bool,
            "verified": bool,
            "evidence": str,
            "reason": Optional[str]
        }
    """
    from executor.truth_oracle import (
        check_file,
        check_process,
        check_window,
        check_foreground,
    )

    tool_success = bool(tool_result.get("success", False) or tool_result.get("status") == "PASSED")
    if not tool_success:
        return {
            "tool_success": False,
            "semantic_success": False,
            "task_success": False,
            "verified": False,
            "evidence": tool_result.get("message", "Tool execution failed"),
            "reason": tool_result.get("error", "Execution returned success=False")
        }

    # Verify GUI Move Mouse
    if action == SemanticAction.MOVE_MOUSE:
        pos = tool_result.get("coordinates") or tool_result.get("position")
        if pos:
            return {
                "tool_success": True,
                "semantic_success": True,
                "task_success": True,
                "verified": True,
                "evidence": f"Mouse moved to expected UI target '{target}'.",
                "reason": None
            }

    # Verify Browser URL Navigation
    if domain == SemanticDomain.BROWSER and action in (SemanticAction.OPEN, SemanticAction.SEARCH):
        has_url = bool(tool_result.get("url") or tool_result.get("navigated_url") or tool_result.get("current_url"))
        has_title = bool(tool_result.get("title") or tool_result.get("tab_title") or tool_result.get("window_title"))
        if has_url or has_title:
            return {
                "tool_success": True,
                "semantic_success": True,
                "task_success": True,
                "verified": True,
                "evidence": f"Browser navigation confirmed: URL='{tool_result.get('url') or tool_result.get('current_url')}', Title='{tool_result.get('title') or tool_result.get('tab_title')}'.",
                "reason": None
            }
        return {
            "tool_success": True,
            "semantic_success": False,
            "task_success": False,
            "verified": False,
            "evidence": "Browser navigation missing title or URL evidence.",
            "reason": "No browser URL or title evidence returned"
        }

    # Verify Application Launch
    if domain == SemanticDomain.APPLICATION and action == SemanticAction.LAUNCH:
        w_obs = check_window(title_contains=target)
        if w_obs.status == "VERIFIED":
            best = w_obs.evidence.get("best_match", {})
            hwnd = best.get("hwnd")
            fg_obs = check_foreground(hwnd, timeout=0.5) if hwnd else None
            if fg_obs and fg_obs.status == "VERIFIED":
                return {
                    "tool_success": True,
                    "semantic_success": True,
                    "task_success": True,
                    "verified": True,
                    "evidence": f"Application '{target}' is verified running in foreground (HWND {hwnd}).",
                    "reason": None
                }
            reason_str = fg_obs.reason if fg_obs else f"Application '{target}' window found but foreground check failed."
            return {
                "tool_success": True,
                "semantic_success": False,
                "task_success": False,
                "verified": False,
                "evidence": reason_str,
                "reason": reason_str
            }
        # Window not verified on real OS
        return {
            "tool_success": True,
            "semantic_success": False,
            "task_success": False,
            "verified": False,
            "evidence": w_obs.reason,
            "reason": w_obs.reason
        }

    # Verify Application Close
    if domain == SemanticDomain.APPLICATION and action == SemanticAction.CLOSE:
        p_obs = check_process(name=target)
        if p_obs.status == "FAILED":
            # Process does not exist on system -> successfully closed
            return {
                "tool_success": True,
                "semantic_success": True,
                "task_success": True,
                "verified": True,
                "evidence": f"Application '{target}' confirmed closed/absent from process table.",
                "reason": None
            }
        elif p_obs.status == "VERIFIED":
            # Process still exists on system
            return {
                "tool_success": True,
                "semantic_success": False,
                "task_success": False,
                "verified": False,
                "evidence": f"Application '{target}' still active on system (PID {p_obs.evidence.get('pid')}).",
                "reason": "Process still running"
            }
        else:
            w_obs = check_window(title_contains=target)
            if w_obs.status == "FAILED":
                return {
                    "tool_success": True,
                    "semantic_success": True,
                    "task_success": True,
                    "verified": True,
                    "evidence": f"Application '{target}' window confirmed absent from desktop.",
                    "reason": None
                }
            return {
                "tool_success": True,
                "semantic_success": False,
                "task_success": False,
                "verified": False,
                "evidence": p_obs.reason,
                "reason": p_obs.reason
            }

    # Verify Filesystem Operations
    if domain == SemanticDomain.FILESYSTEM:
        if action in (SemanticAction.CREATE, SemanticAction.OPEN, SemanticAction.MOVE_FILE, SemanticAction.COPY):
            allow_empty = bool(tool_result.get("allow_empty", False))
            obs = check_file(target, must_exist=True, allow_empty=allow_empty)
            if obs.status == "VERIFIED":
                return {
                    "tool_success": True,
                    "semantic_success": True,
                    "task_success": True,
                    "verified": True,
                    "evidence": obs.reason or f"Filesystem operation on '{target}' verified on disk.",
                    "reason": None
                }
            return {
                "tool_success": True,
                "semantic_success": False,
                "task_success": False,
                "verified": False,
                "evidence": obs.reason,
                "reason": obs.reason
            }
        elif action == SemanticAction.DELETE:
            obs = check_file(target, must_exist=False)
            if obs.status == "VERIFIED":
                return {
                    "tool_success": True,
                    "semantic_success": True,
                    "task_success": True,
                    "verified": True,
                    "evidence": f"Target '{target}' verified absent from disk.",
                    "reason": None
                }
            return {
                "tool_success": True,
                "semantic_success": False,
                "task_success": False,
                "verified": False,
                "evidence": obs.reason,
                "reason": obs.reason
            }

    # Verify Network / Diagnostics / Read-only inspections: require non-empty payload
    if domain in (SemanticDomain.NETWORK, SemanticDomain.SYSTEM, SemanticDomain.DIAGNOSTICS, SemanticDomain.CONVERSATION_HISTORY, SemanticDomain.DEVICES) and action in (SemanticAction.INSPECT, SemanticAction.QUERY_HISTORY, SemanticAction.REPORT, SemanticAction.DIAGNOSE):
        payload_keys = ("data", "items", "content", "telemetry", "stdout", "output", "matches", "processes", "stats", "history", "details", "results", "snapshot", "report_path", "evidence_items")
        has_payload = False
        for k in payload_keys:
            val = tool_result.get(k)
            if val is not None and (len(val) > 0 if hasattr(val, "__len__") else bool(val)):
                has_payload = True
                break
        if not has_payload:
            extra_keys = [k for k in tool_result.keys() if k not in ("success", "status", "verified", "message", "attempts", "timestamp", "tool")]
            for ek in extra_keys:
                val = tool_result.get(ek)
                if val not in (None, "", [], {}):
                    has_payload = True
                    break

        if has_payload:
            return {
                "tool_success": True,
                "semantic_success": True,
                "task_success": True,
                "verified": True,
                "evidence": tool_result.get("message", "Telemetry retrieved successfully."),
                "reason": None
            }
        return {
            "tool_success": True,
            "semantic_success": False,
            "task_success": False,
            "verified": False,
            "evidence": "Inspection returned empty payload.",
            "reason": "Empty inspection payload"
        }

    # Default fallback: unknown action or no direct physical oracle check => UNVERIFIED
    return {
        "tool_success": tool_success,
        "semantic_success": False,
        "task_success": False,
        "verified": False,
        "evidence": tool_result.get("message", "Operation evaluated."),
        "reason": "Unknown action type or state change cannot be independently verified (Master Rule 2)."
    }
