"""
Transactional Manager for Offline Desktop Assistant.
Manages transactional boundaries, inverse compensation actions, and rollback suppression rules.
"""
from typing import Any


def should_suppress_rollback(
    failed_step_tool: str,
    error_code: str = "",
    error_message: str = ""
) -> bool:
    """
    Evaluates whether transactional state rollback should be suppressed.
    UI lookup operations (click_element_by_text, find_text_on_screen, locate_ui_element)
    that fail due to visual absence of an element (resource_not_found / element not found)
    must halt cleanly and NEVER invoke compensating actions (e.g. closing external processes)
    on unrelated system state.
    """
    ui_lookup_tools = (
        "click_element_by_text",
        "find_text_on_screen",
        "locate_ui_element",
        "pick_best_on_screen_item",
        "find_and_interact",
        "click_ui_element",
        "find_ui_element",
        "click_at_point",
        "double_click_coordinate",
        "ocr_screen",
    )
    err_c = str(error_code or "").lower()
    err_m = str(error_message or "").lower()
    if "recoverable_ui_drift" in err_c or "recoverable_ui_drift" in err_m or "ui_drift" in err_c or "ui_drift" in err_m:
        return True

    if failed_step_tool in ui_lookup_tools:
        if (
            err_c in ("resource_not_found", "not_found", "element_not_found", "ui_element_not_found", "recoverable_ui_drift")
            or "not found" in err_m
            or "could not be located" in err_m
            or "absent" in err_m
            or "unable to locate" in err_m
            or "no match" in err_m
            or "failed to locate" in err_m
            or not err_c  # Default to suppression for visual UI tools on lookup misses
        ):
            return True

    return False


class TransactionManager:
    """
    Lightweight manager coordinating transactional compensation and rollback boundaries.
    """
    @staticmethod
    def is_rollback_suppressed(tool_name: str, error_code: str = "", error_message: str = "") -> bool:
        return should_suppress_rollback(tool_name, error_code, error_message)

    @staticmethod
    def clear_rollback_stack(session_context: Any = None) -> None:
        clear_rollback_stack(session_context)


def clear_rollback_stack(session_context: Any = None) -> None:
    """
    Explicitly clears the transaction compensation and rollback stack for a new user turn.
    Prevents historical process actions from accumulating or leaking across different user commands.
    """
    if session_context is None:
        try:
            from command_layer.context import session_context as _default_ctx
            session_context = _default_ctx
        except ImportError:
            pass

    if session_context is not None:
        if hasattr(session_context, "clear_recovery_state"):
            session_context.clear_recovery_state()
        else:
            if hasattr(session_context, "allocated_resources"):
                session_context.allocated_resources.clear()
            if hasattr(session_context, "pending_compensations"):
                session_context.pending_compensations.clear()
            if hasattr(session_context, "recovery_ledger"):
                session_context.recovery_ledger.clear()
            if hasattr(session_context, "last_recovery"):
                session_context.last_recovery = None
        if hasattr(session_context, "executed_steps"):
            session_context.executed_steps.clear()

