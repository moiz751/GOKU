"""
Truth Oracle — Independent OS State Ground-Truth Verifier.
Reads real operating system state directly (disk, Win32 process list,
window hierarchies, and visual screen differences) without relying on
tools' self-reported return values or success flags.
"""
from dataclasses import dataclass, field
import hashlib
import os
from pathlib import Path
import sys
import time
import traceback
from typing import Any, Callable, Optional


@dataclass
class Observation:
    status: str  # 'VERIFIED' | 'UNVERIFIED' | 'FAILED'
    evidence: dict[str, Any] = field(default_factory=dict)
    reason: str = ""

    def __post_init__(self):
        self.status = str(self.status).upper()
        if self.status not in ("VERIFIED", "UNVERIFIED", "FAILED"):
            self.status = "UNVERIFIED"

    @property
    def is_verified(self) -> bool:
        return self.status == "VERIFIED"

    @property
    def is_failed(self) -> bool:
        return self.status == "FAILED"

    @property
    def is_unverified(self) -> bool:
        return self.status == "UNVERIFIED"

    def __bool__(self) -> bool:
        return self.status == "VERIFIED"

    def __getitem__(self, key: str) -> Any:
        if key == "status":
            return self.status
        if key == "evidence":
            return self.evidence
        if key == "reason":
            return self.reason
        if key == "verified":
            return self.is_verified
        return self.evidence.get(key)

    def __contains__(self, key: str) -> bool:
        return key in ("status", "evidence", "reason", "verified") or key in self.evidence

    def get(self, key: str, default: Any = None) -> Any:
        if key in ("status", "evidence", "reason"):
            return getattr(self, key)
        if key == "verified":
            return self.is_verified
        return self.evidence.get(key, default)

    def to_dict(self) -> dict[str, Any]:
        return {
            "status": self.status,
            "verified": self.is_verified,
            "evidence": self.evidence,
            "reason": self.reason,
        }


def normalize_text_content(raw_data: bytes | str) -> str:
    """Normalises CRLF/LF to LF, strips UTF-8/UTF-16 BOM, and decodes text."""
    if isinstance(raw_data, bytes):
        if raw_data.startswith(b"\xef\xbb\xbf"):
            text = raw_data[3:].decode("utf-8", errors="replace")
        elif raw_data.startswith(b"\xff\xfe") or raw_data.startswith(b"\xfe\xff"):
            try:
                text = raw_data.decode("utf-16")
            except Exception:
                text = raw_data.decode("utf-8", errors="replace")
        else:
            text = raw_data.decode("utf-8", errors="replace")
    else:
        text = str(raw_data)

    if text.startswith("\ufeff"):
        text = text[1:]
    return text.replace("\r\n", "\n").replace("\r", "\n")


def file_created(
    path: str | Path,
    expected_text: Optional[str] = None,
    action_start: Optional[float] = None
) -> Observation:
    """
    Independent postcondition for file creation / saved claims.
    Normalises CRLF/LF, strips BOM, compares decoded text.
    Enforces size > 0 for saved claim; mtime >= action start if provided.
    Never reads tool result.
    """
    try:
        p = Path(path).resolve()
        if not p.exists():
            return Observation(
                status="FAILED",
                evidence={"path": str(p), "exists": False},
                reason=f"File does not exist on disk at '{p}'."
            )
        if not p.is_file():
            return Observation(
                status="FAILED",
                evidence={"path": str(p), "is_file": False},
                reason=f"Target path '{p}' exists but is not a regular file."
            )

        stat = p.stat()
        if stat.st_size == 0:
            return Observation(
                status="FAILED",
                evidence={"path": str(p), "size_bytes": 0},
                reason=f"File '{p}' exists but has 0 bytes (saved claim requires size > 0)."
            )

        if action_start is not None and stat.st_mtime < action_start:
            return Observation(
                status="FAILED",
                evidence={"path": str(p), "mtime": stat.st_mtime, "action_start": action_start},
                reason=f"File '{p}' mtime ({stat.st_mtime}) was before action start ({action_start})."
            )

        evidence: dict[str, Any] = {
            "path": str(p),
            "size_bytes": stat.st_size,
            "mtime": stat.st_mtime,
        }

        if expected_text is not None:
            raw_bytes = p.read_bytes()
            normalized_file = normalize_text_content(raw_bytes)
            normalized_expected = normalize_text_content(expected_text)
            if normalized_expected not in normalized_file and normalized_file != normalized_expected:
                return Observation(
                    status="FAILED",
                    evidence=evidence,
                    reason=f"File content in '{p}' did not contain expected text: '{expected_text}'."
                )
            evidence["contains_expected"] = True

        return Observation(
            status="VERIFIED",
            evidence=evidence,
            reason=f"File '{p}' successfully verified on disk ({stat.st_size} bytes)."
        )
    except Exception as e:
        tb = traceback.format_exc()
        return Observation(
            status="UNVERIFIED",
            evidence={"path": str(path), "error": str(e), "traceback": tb},
            reason=f"file_created oracle raised exception: {e}"
        )


def text_in_editor(hwnd: int, expected: str) -> Observation:
    """
    Reads text directly from OS control via Win32 API WM_GETTEXT.
    Normalises CRLF/LF, strips BOM, and compares with expected.
    Never reads tool result.
    """
    try:
        if sys.platform != "win32" or not hwnd:
            return Observation(status="UNVERIFIED", reason="Invalid HWND or non-Windows platform.")

        import ctypes
        from ctypes import wintypes
        user32 = ctypes.windll.user32

        if not user32.IsWindow(hwnd):
            return Observation(status="FAILED", evidence={"hwnd": hwnd}, reason=f"Window handle {hwnd} is not a valid window.")

        # Find Edit / RichEdit controls
        edit_hwnd = user32.FindWindowExW(hwnd, None, "Edit", None)
        if not edit_hwnd:
            edit_hwnd = user32.FindWindowExW(hwnd, None, "RichEditD2DPT", None)
        if not edit_hwnd:
            def find_child(ch, _):
                nonlocal edit_hwnd
                cb = ctypes.create_unicode_buffer(256)
                user32.GetClassNameW(ch, cb, 256)
                if cb.value in ("Edit", "RichEditD2DPT", "RICHEDIT50W"):
                    edit_hwnd = ch
                    return False
                return True
            WNDENUM = ctypes.WINFUNCTYPE(ctypes.c_bool, wintypes.HWND, wintypes.LPARAM)
            user32.EnumChildWindows(hwnd, WNDENUM(find_child), 0)

        actual_text = ""
        target_h = edit_hwnd or hwnd
        length = user32.SendMessageW(target_h, 0x000E, 0, 0)
        buff = ctypes.create_unicode_buffer(length + 1)
        user32.SendMessageW(target_h, 0x000D, length + 1, buff)
        actual_text = buff.value

        norm_actual = normalize_text_content(actual_text)
        norm_expected = normalize_text_content(expected)

        if norm_expected in norm_actual or norm_actual.strip() == norm_expected.strip():
            return Observation(
                status="VERIFIED",
                evidence={"hwnd": hwnd, "control_hwnd": target_h, "text_snippet": norm_actual[:100]},
                reason=f"Text in editor (HWND {target_h}) contains expected content."
            )

        return Observation(
            status="FAILED",
            evidence={"hwnd": hwnd, "actual_text": norm_actual[:100], "expected_text": norm_expected[:100]},
            reason=f"Editor text does not contain expected '{norm_expected[:60]}'."
        )
    except Exception as e:
        tb = traceback.format_exc()
        return Observation(
            status="UNVERIFIED",
            evidence={"hwnd": hwnd, "error": str(e), "traceback": tb},
            reason=f"text_in_editor oracle raised exception: {e}"
        )


def window_foreground(
    pid: Optional[int] = None,
    class_name: Optional[str] = None,
    title: Optional[str] = None
) -> Observation:
    """
    Verifies OS foreground window.
    Matches by PID, class_name, and exact title or startswith; never substring.
    Ensures 'Notepad' does not match 'Notepad++'.
    """
    try:
        if sys.platform != "win32":
            return Observation(status="UNVERIFIED", reason="Window checking requires Windows.")

        import ctypes
        from ctypes import wintypes
        user32 = ctypes.windll.user32
        fg_hwnd = user32.GetForegroundWindow()
        if not fg_hwnd:
            return Observation(status="FAILED", evidence={"foreground_hwnd": 0}, reason="No foreground window currently active in OS.")

        fg_pid = wintypes.DWORD()
        user32.GetWindowThreadProcessId(fg_hwnd, ctypes.byref(fg_pid))

        cls_buff = ctypes.create_unicode_buffer(256)
        user32.GetClassNameW(fg_hwnd, cls_buff, 256)
        fg_class = cls_buff.value.strip()

        t_len = user32.GetWindowTextLengthW(fg_hwnd) + 1
        t_buff = ctypes.create_unicode_buffer(t_len)
        user32.GetWindowTextW(fg_hwnd, t_buff, t_len)
        fg_title = t_buff.value.strip()

        evidence = {
            "hwnd": fg_hwnd,
            "pid": fg_pid.value,
            "class_name": fg_class,
            "title": fg_title,
        }

        # Match PID if specified
        if pid is not None and fg_pid.value != pid:
            return Observation(
                status="FAILED",
                evidence=evidence,
                reason=f"Foreground window PID {fg_pid.value} does not match expected {pid}."
            )

        # Match class_name if specified
        if class_name is not None and fg_class.lower() != class_name.lower():
            return Observation(
                status="FAILED",
                evidence=evidence,
                reason=f"Foreground window class '{fg_class}' does not match expected '{class_name}'."
            )

        # Match title: exact or startswith, NEVER substring.
        if title is not None:
            exp_t = title.strip().lower()
            act_t = fg_title.strip().lower()

            is_exact = (act_t == exp_t)
            is_prefix = False
            if act_t.startswith(exp_t):
                if len(act_t) == len(exp_t):
                    is_prefix = True
                elif act_t[len(exp_t)] in (" ", "-", ":", "|", "\t", "[", "(", "."):
                    is_prefix = True

            if not (is_exact or is_prefix):
                return Observation(
                    status="FAILED",
                    evidence=evidence,
                    reason=f"Foreground window title '{fg_title}' does not match expected title '{title}' (exact or startswith required; substring forbidden)."
                )

        return Observation(
            status="VERIFIED",
            evidence=evidence,
            reason=f"Foreground window verified: '{fg_title}' (HWND {fg_hwnd}, PID {fg_pid.value}, Class '{fg_class}')."
        )
    except Exception as e:
        tb = traceback.format_exc()
        return Observation(
            status="UNVERIFIED",
            evidence={"error": str(e), "traceback": tb},
            reason=f"window_foreground oracle raised exception: {e}"
        )


def process_running(
    pid: Optional[int] = None,
    exe_path: Optional[str] = None
) -> Observation:
    """
    Process checks by full exe path, not only name.
    """
    try:
        import psutil

        if pid is not None:
            if not psutil.pid_exists(pid):
                return Observation(status="FAILED", evidence={"pid": pid, "running": False}, reason=f"Process PID {pid} does not exist in operating system.")
            p = psutil.Process(pid)
            if not p.is_running() or p.status() == psutil.STATUS_ZOMBIE:
                return Observation(status="FAILED", evidence={"pid": pid, "status": p.status()}, reason=f"Process PID {pid} is zombie or terminating.")
            actual_exe = ""
            try:
                actual_exe = p.exe()
            except Exception:
                actual_exe = p.name()

            evidence = {"pid": pid, "name": p.name(), "exe": actual_exe, "running": True}
            if exe_path is not None:
                norm_exp = os.path.normpath(exe_path).lower()
                norm_act = os.path.normpath(actual_exe).lower()
                if norm_act != norm_exp:
                    return Observation(
                        status="FAILED",
                        evidence=evidence,
                        reason=f"Process PID {pid} exe path '{actual_exe}' does not match expected full path '{exe_path}'."
                    )
            return Observation(status="VERIFIED", evidence=evidence, reason=f"Process PID {pid} verified running (Full exe: '{actual_exe}').")

        if exe_path is not None:
            norm_exp = os.path.normpath(exe_path).lower()
            matching = []
            for proc in psutil.process_iter(["pid", "name"]):
                try:
                    p_exe = os.path.normpath(proc.exe()).lower()
                    if p_exe == norm_exp:
                        matching.append({"pid": proc.pid, "exe": proc.exe()})
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
            if matching:
                return Observation(
                    status="VERIFIED",
                    evidence={"exe_path": exe_path, "matches": matching},
                    reason=f"Process with full path '{exe_path}' verified running ({len(matching)} instance(s))."
                )
            return Observation(status="FAILED", evidence={"exe_path": exe_path, "matches": []}, reason=f"No running process matches full exe path '{exe_path}'.")

        return Observation(status="UNVERIFIED", evidence={}, reason="Neither pid nor exe_path provided to process_running.")
    except Exception as e:
        tb = traceback.format_exc()
        return Observation(
            status="UNVERIFIED",
            evidence={"pid": pid, "exe_path": exe_path, "error": str(e), "traceback": tb},
            reason=f"process_running oracle raised exception: {e}"
        )


def dialog_absent(pid: Optional[int] = None) -> Observation:
    """
    Verifies that no Win32 modal dialog (#32770) belonging to pid is open.
    """
    try:
        if sys.platform != "win32":
            return Observation(status="UNVERIFIED", reason="Dialog inspection requires Windows.")

        import ctypes
        from ctypes import wintypes
        user32 = ctypes.windll.user32
        dialogs = []

        def enum_proc(hwnd: int, _: Any) -> bool:
            if not user32.IsWindow(hwnd) or not user32.IsWindowVisible(hwnd):
                return True
            cls_buff = ctypes.create_unicode_buffer(256)
            user32.GetClassNameW(hwnd, cls_buff, 256)
            if cls_buff.value.strip() == "#32770":
                win_pid = wintypes.DWORD()
                user32.GetWindowThreadProcessId(hwnd, ctypes.byref(win_pid))
                if pid is None or win_pid.value == pid:
                    t_len = user32.GetWindowTextLengthW(hwnd) + 1
                    t_buf = ctypes.create_unicode_buffer(t_len)
                    user32.GetWindowTextW(hwnd, t_buf, t_len)
                    dialogs.append({"hwnd": hwnd, "pid": win_pid.value, "title": t_buf.value.strip()})
            return True

        WNDPROC = ctypes.WINFUNCTYPE(ctypes.c_bool, wintypes.HWND, wintypes.LPARAM)
        user32.EnumWindows(WNDPROC(enum_proc), 0)

        if dialogs:
            return Observation(
                status="FAILED",
                evidence={"dialogs": dialogs},
                reason=f"Dialog is still present on screen ({len(dialogs)} modal dialog(s): '{dialogs[0]['title']}')."
            )

        return Observation(status="VERIFIED", evidence={"dialogs": []}, reason=f"No modal dialogs (#32770) present for PID {pid}.")
    except Exception as e:
        tb = traceback.format_exc()
        return Observation(
            status="UNVERIFIED",
            evidence={"pid": pid, "error": str(e), "traceback": tb},
            reason=f"dialog_absent oracle raised exception: {e}"
        )


def folder_has(path: str | Path, name: str) -> Observation:
    """
    Verifies directory exists on disk and contains target child.
    """
    try:
        p = Path(path).resolve()
        if not p.exists() or not p.is_dir():
            return Observation(status="FAILED", evidence={"path": str(p), "exists": False}, reason=f"Folder '{p}' does not exist on disk.")
        child = p / name
        if child.exists():
            return Observation(
                status="VERIFIED",
                evidence={"folder": str(p), "child": str(child), "exists": True},
                reason=f"Folder '{p}' verified containing item '{name}'."
            )
        return Observation(status="FAILED", evidence={"folder": str(p), "child": str(child), "exists": False}, reason=f"Folder '{p}' does not contain '{name}'.")
    except Exception as e:
        tb = traceback.format_exc()
        return Observation(
            status="UNVERIFIED",
            evidence={"path": str(path), "name": name, "error": str(e), "traceback": tb},
            reason=f"folder_has oracle raised exception: {e}"
        )


# ==============================================================================
# 1. FILESYSTEM ORACLE
# ==============================================================================

def check_file(
    path: str | Path,
    kind: str = "file",
    must_exist: bool = True,
    min_size: Optional[int] = None,
    allow_empty: bool = False,
    sha256: Optional[str] = None,
    content_contains: Optional[str] = None,
    before_snapshot: Optional[dict[str, Any]] = None,
    action_start: Optional[float] = None,
) -> Observation:
    """
    Independently inspects filesystem state on disk.
    Directories are never evaluated by size.
    """
    try:
        p = Path(path).resolve()
        exists = p.exists()

        if not must_exist:
            if exists:
                return Observation(
                    status="FAILED",
                    evidence={"path": str(p), "exists": True},
                    reason=f"Target still exists on disk at '{p}' (expected deletion/absence).",
                )
            return Observation(
                status="VERIFIED",
                evidence={"path": str(p), "exists": False},
                reason=f"Target is verified absent from disk at '{p}'.",
            )

        if not exists:
            return Observation(
                status="FAILED",
                evidence={"path": str(p), "exists": False},
                reason=f"Target does not exist on disk at '{p}'.",
            )

        stat = p.stat()
        evidence: dict[str, Any] = {
            "path": str(p),
            "exists": True,
            "size_bytes": stat.st_size,
            "mtime": stat.st_mtime,
        }

        # Check directory vs file
        if kind == "dir":
            evidence.pop("size_bytes", None)
            if not p.is_dir():
                return Observation(
                    status="FAILED",
                    evidence=evidence,
                    reason=f"Target '{p}' exists but is a regular file, not a directory.",
                )
            # Directories are never judged by size
            evidence["is_dir"] = True
            try:
                evidence["item_count"] = len(os.listdir(str(p)))
            except Exception:
                evidence["item_count"] = None
            return Observation(
                status="VERIFIED",
                evidence=evidence,
                reason=f"Directory verified on disk: '{p}'.",
            )

        # Kind == 'file'
        if not p.is_file():
            return Observation(
                status="FAILED",
                evidence=evidence,
                reason=f"Target '{p}' exists but is a directory, not a regular file.",
            )

        # Size check
        if stat.st_size == 0 and not allow_empty:
            return Observation(
                status="FAILED",
                evidence=evidence,
                reason=f"File '{p}' exists but has 0 bytes (allow_empty=False).",
            )

        if min_size is not None and stat.st_size < min_size:
            return Observation(
                status="FAILED",
                evidence=evidence,
                reason=f"File '{p}' size ({stat.st_size} bytes) is less than required min_size ({min_size} bytes).",
            )

        # Content contains check
        if content_contains is not None:
            try:
                raw_b = p.read_bytes()
                text_content = normalize_text_content(raw_b)
                norm_expected = normalize_text_content(content_contains)
                if norm_expected not in text_content:
                    return Observation(
                        status="FAILED",
                        evidence=evidence,
                        reason=f"File '{p}' does not contain expected substring: '{content_contains}'.",
                    )
                evidence["contains_expected_text"] = True
            except Exception as e:
                traceback.format_exc()
                return Observation(
                    status="UNVERIFIED",
                    evidence=evidence,
                    reason=f"Could not read file content for substring verification: {e}",
                )

        if action_start is not None and stat.st_mtime < action_start:
            return Observation(
                status="FAILED",
                evidence=evidence,
                reason=f"File '{p}' mtime ({stat.st_mtime}) was before action start ({action_start}).",
            )

        # SHA256 check
        if sha256 is not None:
            h = hashlib.sha256()
            with open(p, "rb") as f:
                while chunk := f.read(65536):
                    h.update(chunk)
            real_hash = h.hexdigest().lower()
            evidence["sha256"] = real_hash
            if real_hash != sha256.lower():
                return Observation(
                    status="FAILED",
                    evidence=evidence,
                    reason=f"File hash mismatch: actual {real_hash} != expected {sha256}.",
                )

        # Before snapshot delta check
        if before_snapshot and isinstance(before_snapshot, dict):
            prev_mtime = before_snapshot.get("mtime")
            prev_size = before_snapshot.get("size_bytes")
            if prev_mtime and stat.st_mtime == prev_mtime and prev_size == stat.st_size:
                evidence["modified"] = False
            else:
                evidence["modified"] = True

        return Observation(
            status="VERIFIED",
            evidence=evidence,
            reason=f"File verified on disk: '{p}' ({stat.st_size} bytes).",
        )

    except Exception as e:
        return Observation(
            status="UNVERIFIED",
            evidence={"path": str(path), "error": str(e)},
            reason=f"Filesystem oracle encounter error: {e}",
        )


# ==============================================================================
# 2. PROCESS ORACLE
# ==============================================================================

def check_process(
    name: Optional[str] = None,
    pid: Optional[int] = None,
) -> Observation:
    """
    Checks active Windows processes via psutil with safe lazy import.
    """
    try:
        import psutil

        if pid is not None:
            if not psutil.pid_exists(pid):
                return Observation(
                    status="FAILED",
                    evidence={"pid": pid, "running": False},
                    reason=f"Process PID {pid} does not exist in operating system.",
                )
            try:
                p = psutil.Process(pid)
                if not p.is_running() or p.status() == psutil.STATUS_ZOMBIE:
                    return Observation(
                        status="FAILED",
                        evidence={"pid": pid, "status": p.status()},
                        reason=f"Process PID {pid} is zombie or terminating.",
                    )
                return Observation(
                    status="VERIFIED",
                    evidence={"pid": pid, "name": p.name(), "running": True, "status": "running"},
                    reason=f"Process PID {pid} ('{p.name()}') is actively running.",
                )
            except (psutil.NoSuchProcess, psutil.AccessDenied) as pe:
                return Observation(
                    status="FAILED",
                    evidence={"pid": pid, "error": str(pe)},
                    reason=f"Process PID {pid} cannot be queried ({pe}).",
                )

        if name:
            clean_name = name.lower().strip()
            is_path = os.sep in clean_name or "/" in clean_name
            matching_procs = []
            for proc in psutil.process_iter(["pid", "name"]):
                try:
                    if is_path:
                        pexe = os.path.normpath(proc.exe()).lower()
                        if pexe == os.path.normpath(name).lower():
                            matching_procs.append({
                                "pid": proc.info["pid"],
                                "exe": proc.exe(),
                            })
                    else:
                        pname = (proc.info.get("name") or "").lower()
                        expected_pname = clean_name if clean_name.endswith(".exe") else clean_name + ".exe"
                        if pname == expected_pname or pname == clean_name:
                            matching_procs.append({
                                "pid": proc.info["pid"],
                                "name": proc.info["name"],
                            })
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue

            if matching_procs:
                return Observation(
                    status="VERIFIED",
                    evidence={"name": name, "matches": matching_procs, "count": len(matching_procs)},
                    reason=f"Found {len(matching_procs)} running process(es) matching '{name}'.",
                )

            return Observation(
                status="FAILED",
                evidence={"name": name, "matches": []},
                reason=f"No running process matches '{name}'.",
            )

        return Observation(
            status="UNVERIFIED",
            evidence={},
            reason="Neither process name nor PID was specified.",
        )

    except Exception as e:
        return Observation(
            status="UNVERIFIED",
            evidence={"name": name, "pid": pid, "error": str(e)},
            reason=f"Process oracle encounter error: {e}",
        )


# ==============================================================================
# 3. WINDOW & FOREGROUND ORACLE
# ==============================================================================

def _ensure_desktop_access(target_pid: Optional[int] = None) -> None:
    if sys.platform == "win32":
        try:
            import ctypes
            user32 = ctypes.windll.user32
            kernel32 = ctypes.windll.kernel32
            curr_th = kernel32.GetCurrentThreadId()
            curr_desk = user32.GetThreadDesktop(curr_th)
            if curr_desk:
                return
            # Only connect if thread has no desktop attached
            h_desk = user32.OpenDesktopW("default", 0, False, 0x01FF)
            if h_desk and user32.SetThreadDesktop(h_desk):
                return
            if target_pid:
                try:
                    import psutil
                    p = psutil.Process(target_pid)
                    threads = p.threads()
                    for th in threads:
                        th_desk = user32.GetThreadDesktop(th.id)
                        if th_desk and user32.SetThreadDesktop(th_desk):
                            return
                except Exception:
                    pass
        except Exception:
            pass


def check_window(
    title_contains: Optional[str] = None,
    pid: Optional[int] = None,
    timeout: float = 0.0,
) -> Observation:
    """
    Discovers top-level Win32 windows matching title, window class, or owner PID/process.
    Reports hwnd, visible, minimized, responsive (IsHungAppWindow), and is_foreground.
    Supports bounded retry polling for up to timeout seconds.
    """
    if sys.platform != "win32":
        return Observation(status="UNVERIFIED", reason="Win32 window checking requires Windows.")

    try:
        import ctypes
        from ctypes import wintypes
        import re

        _ensure_desktop_access(target_pid=pid)
        user32 = ctypes.windll.user32
        matches = []
        fg_hwnd = user32.GetForegroundWindow()

        # Clean search query
        query_norm = ""
        if title_contains:
            query_norm = re.sub(r'[\u200b\s]+', ' ', title_contains.lower()).strip()
            if query_norm.endswith(".exe"):
                query_norm = query_norm[:-4]

        def enum_win_proc(hwnd: int, _: Any) -> bool:
            if not user32.IsWindow(hwnd):
                return True

            is_vis = bool(user32.IsWindowVisible(hwnd))
            length = user32.GetWindowTextLengthW(hwnd) + 1
            buff = ctypes.create_unicode_buffer(length)
            user32.GetWindowTextW(hwnd, buff, length)
            raw_title = buff.value.strip()
            clean_title = re.sub(r'[\u200b\s]+', ' ', raw_title.lower()).strip()

            cls_buff = ctypes.create_unicode_buffer(256)
            user32.GetClassNameW(hwnd, cls_buff, 256)
            cls_name = cls_buff.value.strip().lower()

            win_pid = wintypes.DWORD()
            user32.GetWindowThreadProcessId(hwnd, ctypes.byref(win_pid))

            # Match criteria
            title_matches = True
            if query_norm:
                match_title = False
                if clean_title:
                    if clean_title == query_norm:
                        match_title = True
                    elif clean_title.startswith(query_norm):
                        if len(clean_title) == len(query_norm) or clean_title[len(query_norm)] in (" ", "-", ":", "|", "\t", "[", "(", "."):
                            match_title = True

                match_class = False
                if cls_name:
                    if cls_name == query_norm or (cls_name.startswith(query_norm) and len(cls_name) == len(query_norm)):
                        match_class = True

                match_proc = False
                if win_pid.value:
                    try:
                        import psutil
                        pname = psutil.Process(win_pid.value).name().lower()
                        expected_p = query_norm if query_norm.endswith(".exe") else query_norm + ".exe"
                        match_proc = (pname == expected_p or pname == query_norm)
                    except Exception:
                        pass
                title_matches = (match_title or match_class or match_proc)

            pid_matches = True
            if pid is not None:
                pid_matches = (win_pid.value == pid)

            if title_matches and pid_matches and (is_vis or raw_title):
                is_iconic = bool(user32.IsIconic(hwnd))
                is_hung = bool(user32.IsHungAppWindow(hwnd))
                matches.append({
                    "hwnd": hwnd,
                    "title": raw_title,
                    "class_name": cls_buff.value.strip(),
                    "pid": win_pid.value,
                    "visible": is_vis,
                    "minimized": is_iconic,
                    "responsive": not is_hung,
                    "is_foreground": (hwnd == fg_hwnd),
                })
            return True

        def _collect() -> None:
            _ensure_desktop_access(target_pid=pid)
            WNDENUMPROC = ctypes.WINFUNCTYPE(ctypes.c_bool, wintypes.HWND, wintypes.LPARAM)
            start = time.time()
            while True:
                matches.clear()
                user32.EnumWindows(WNDENUMPROC(enum_win_proc), 0)
                if matches:
                    break
                if time.time() - start >= max(0.05, timeout):
                    break
                time.sleep(0.06)

        _collect()
        if not matches:
            import threading
            t = threading.Thread(target=_collect)
            t.start()
            t.join(timeout=max(2.0, timeout))

        if not matches:
            return Observation(
                status="FAILED",
                evidence={"query_title": title_contains, "query_pid": pid, "matches": []},
                reason=f"No window found matching title_contains='{title_contains}' or pid={pid}.",
            )

        best = matches[0]
        # Prefer visible, non-empty titled, and foreground matches
        for m in matches:
            if m["is_foreground"]:
                best = m
                break
            elif m["title"] and not best["title"]:
                best = m
            elif m["visible"] and not best["visible"]:
                best = m

        return Observation(
            status="VERIFIED",
            evidence={"best_match": best, "all_matches": matches, "count": len(matches)},
            reason=f"Window verified: '{best['title']}' (HWND: {best['hwnd']}, visible={best['visible']}).",
        )

    except Exception as e:
        return Observation(
            status="UNVERIFIED",
            evidence={"error": str(e)},
            reason=f"Window oracle encounter error: {e}",
        )


def check_foreground(
    hwnd: int,
    timeout: float = 1.0,
) -> Observation:
    """
    Honest foreground check with bounded polling.
    If Windows refuses foreground, reports FAILED/UNVERIFIED with real foreground window title.
    Never pretends success.
    """
    if sys.platform != "win32" or not hwnd:
        return Observation(status="FAILED", reason="Invalid HWND or non-Windows platform.")

    try:
        import ctypes
        user32 = ctypes.windll.user32

        start_time = time.time()
        poll_interval = 0.05

        while time.time() - start_time <= max(0.1, timeout):
            fg_hwnd = user32.GetForegroundWindow()
            if fg_hwnd == hwnd:
                length = user32.GetWindowTextLengthW(hwnd) + 1
                buff = ctypes.create_unicode_buffer(length)
                user32.GetWindowTextW(hwnd, buff, length)
                return Observation(
                    status="VERIFIED",
                    evidence={"hwnd": hwnd, "foreground_hwnd": fg_hwnd, "title": buff.value.strip()},
                    reason=f"Target window (HWND {hwnd}) is confirmed in foreground.",
                )
            time.sleep(poll_interval)

        # Timeout reached: get real foreground window details honestly
        curr_fg = user32.GetForegroundWindow()
        curr_len = user32.GetWindowTextLengthW(curr_fg) + 1 if curr_fg else 0
        curr_buf = ctypes.create_unicode_buffer(curr_len) if curr_len else ""
        if curr_len:
            user32.GetWindowTextW(curr_fg, curr_buf, curr_len)
        real_fg_title = curr_buf.value.strip() if curr_len else ""

        if not curr_fg and user32.IsWindow(hwnd) and user32.IsWindowVisible(hwnd):
            return Observation(
                status="VERIFIED",
                evidence={"hwnd": hwnd, "foreground_hwnd": 0, "note": "No competing foreground window."},
                reason=f"Target window (HWND {hwnd}) is confirmed visible with no conflicting foreground window.",
            )

        return Observation(
            status="FAILED",
            evidence={
                "target_hwnd": hwnd,
                "current_foreground_hwnd": curr_fg,
                "current_foreground_title": real_fg_title,
            },
            reason=f"Window (HWND {hwnd}) did not achieve foreground within {timeout:.1f}s. Real foreground window: '{real_fg_title}' (HWND {curr_fg}).",
        )

    except Exception as e:
        return Observation(
            status="UNVERIFIED",
            evidence={"hwnd": hwnd, "error": str(e)},
            reason=f"Foreground check failed with exception: {e}",
        )


# ==============================================================================
# 4. DIALOG ORACLE
# ==============================================================================

def check_dialog(owner_pid: Optional[int] = None) -> Observation:
    """
    Scans all visible top-level windows for genuine modal/dialog boxes.
    Requires Win32 class '#32770' or native dialog styles, with interactive buttons.
    Excludes standard applications that happen to contain keywords in their titles.
    """
    if sys.platform != "win32":
        return Observation(status="UNVERIFIED", reason="Dialog inspection requires Win32.")

    try:
        import ctypes
        from ctypes import wintypes

        _ensure_desktop_access(target_pid=owner_pid)
        user32 = ctypes.windll.user32
        dialogs = []

        def enum_dialog_proc(hwnd: int, _: Any) -> bool:
            if not user32.IsWindow(hwnd) or not user32.IsWindowVisible(hwnd):
                return True

            cls_buff = ctypes.create_unicode_buffer(256)
            user32.GetClassNameW(hwnd, cls_buff, 256)
            cls_name = cls_buff.value.strip()

            # Must be a standard Win32 dialog (#32770) or popup dialog class
            if cls_name != "#32770":
                return True

            win_pid = wintypes.DWORD()
            user32.GetWindowThreadProcessId(hwnd, ctypes.byref(win_pid))
            if owner_pid is not None and win_pid.value != owner_pid:
                return True

            t_len = user32.GetWindowTextLengthW(hwnd) + 1
            t_buf = ctypes.create_unicode_buffer(t_len)
            user32.GetWindowTextW(hwnd, t_buf, t_len)
            title = t_buf.value.strip()

            rect = wintypes.RECT()
            user32.GetWindowRect(hwnd, ctypes.byref(rect))

            # Inspect child buttons
            buttons = []
            def enum_child_proc(c_hwnd: int, _: Any) -> bool:
                if user32.IsWindowVisible(c_hwnd):
                    c_cls = ctypes.create_unicode_buffer(256)
                    user32.GetClassNameW(c_hwnd, c_cls, 256)
                    c_class = c_cls.value.strip().lower()
                    if "button" in c_class:
                        cb_len = user32.GetWindowTextLengthW(c_hwnd) + 1
                        cb_buf = ctypes.create_unicode_buffer(cb_len)
                        user32.GetWindowTextW(c_hwnd, cb_buf, cb_len)
                        txt = cb_buf.value.strip()
                        if txt:
                            buttons.append(txt)
                return True

            CHILDENUM = ctypes.WINFUNCTYPE(ctypes.c_bool, wintypes.HWND, wintypes.LPARAM)
            user32.EnumChildWindows(hwnd, CHILDENUM(enum_child_proc), 0)

            dialogs.append({
                "hwnd": hwnd,
                "title": title,
                "class_name": cls_name,
                "pid": win_pid.value,
                "bounds": {"left": rect.left, "top": rect.top, "right": rect.right, "bottom": rect.bottom},
                "buttons": buttons,
            })
            return True

        WNDPROC = ctypes.WINFUNCTYPE(ctypes.c_bool, wintypes.HWND, wintypes.LPARAM)
        user32.EnumWindows(WNDPROC(enum_dialog_proc), 0)

        if not dialogs:
            import threading
            def _desk_worker():
                _ensure_desktop_access(target_pid=owner_pid)
                user32.EnumWindows(WNDPROC(enum_dialog_proc), 0)
            th = threading.Thread(target=_desk_worker)
            th.start()
            th.join()

        if not dialogs:
            return Observation(
                status="FAILED",
                evidence={"dialogs": []},
                reason="No active Win32 modal dialog (#32770) detected on screen.",
            )

        best = dialogs[0]
        return Observation(
            status="VERIFIED",
            evidence={"best_dialog": best, "dialogs": dialogs, "count": len(dialogs)},
            reason=f"Active dialog verified: '{best['title']}' (buttons: {best['buttons']}).",
        )

    except Exception as e:
        return Observation(
            status="UNVERIFIED",
            evidence={"error": str(e)},
            reason=f"Dialog oracle exception: {e}",
        )


# ==============================================================================
# 5. SCREEN DELTA ORACLE
# ==============================================================================

def check_screen_changed(
    before_img: Any,
    after_img: Any,
    region: Optional[tuple[int, int, int, int]] = None,
    threshold_percent: float = 0.05,
) -> Observation:
    """
    Compares real pixel states of a target region or whole screen.
    Uses Pillow ImageChops difference on grayscale per-region arrays.
    Returns UNVERIFIED if capture is unavailable, FAILED if changed=False.
    """
    if before_img is None or after_img is None:
        return Observation(
            status="UNVERIFIED",
            evidence={"before_available": before_img is not None, "after_available": after_img is not None},
            reason="Screen captures unavailable for visual verification.",
        )

    try:
        from PIL import ImageChops

        # If region provided (left, top, right, bottom), crop both
        b_img = before_img
        a_img = after_img
        if region:
            b_img = b_img.crop(region)
            a_img = a_img.crop(region)

        # Convert to grayscale for robust luminance difference
        b_gray = b_img.convert("L")
        a_gray = a_img.convert("L")

        diff = ImageChops.difference(b_gray, a_gray)
        bbox = diff.getbbox()
        if not bbox:
            return Observation(
                status="FAILED",
                evidence={"changed": False, "change_percent": 0.0, "region": region},
                reason="Zero visual change observed between screen states.",
            )

        # Count pixels with non-trivial difference (> 12 / 255)
        non_zero = sum(1 for p in diff.tobytes() if p > 12)
        total_pixels = diff.size[0] * diff.size[1]
        pct = round((non_zero / total_pixels) * 100.0, 3)

        if pct < threshold_percent:
            return Observation(
                status="FAILED",
                evidence={"changed": False, "change_percent": pct, "threshold": threshold_percent, "bbox": list(bbox)},
                reason=f"Visual change ({pct}%) below detection threshold ({threshold_percent}%).",
            )

        return Observation(
            status="VERIFIED",
            evidence={
                "changed": True,
                "change_percent": pct,
                "bounding_box": list(bbox),
                "region": region,
            },
            reason=f"Visual screen change verified ({pct}% altered within region).",
        )

    except Exception as e:
        return Observation(
            status="UNVERIFIED",
            evidence={"error": str(e)},
            reason=f"Visual diff computation encountered error: {e}",
        )


# ==============================================================================
# 6. STEP CONTRACTS & INDEPENDENT MULTI-STEP TASK ORACLES (Prompt D)
# ==============================================================================

@dataclass
class StepContract:
    tool_name: str
    precondition: Callable[[dict[str, Any], Any], Observation]
    postcondition: Callable[[dict[str, Any], Any, dict[str, Any]], Observation]
    on_fail: str  # 'retry_same' | 'alternative' | 'ask_user' | 'abort'


def check_app_window_found(app_name: str, context: Any = None) -> Observation:
    """
    Independent postcondition oracle for open_app / launch_app.
    Verifies that a NEW or owned window matching the target app exists,
    is visible, and is registered as owned in the input guard.
    Never reads the tool's own return status.
    """
    if sys.platform != "win32":
        return Observation(status="UNVERIFIED", reason="Non-Windows platform.")

    try:
        from tools.input_guard import _OWNED_WINDOWS
        from tools.window import APP_PROFILES
        from tools.utils.app_resolver import get_canonical_app_name
        import ctypes
        user32 = ctypes.windll.user32

        canonical = get_canonical_app_name(app_name).lower()
        profile_key = None
        for k in APP_PROFILES:
            if k in canonical or canonical in k:
                profile_key = k
                break
        if not profile_key:
            profile_key = "notepad" if "notepad" in canonical else ("calculator" if "calc" in canonical else ("chrome" if "chrome" in canonical else ("edge" if "edge" in canonical else canonical)))

        matched_hwnd = None
        # Check registered owned windows first
        for h, info in reversed(list(_OWNED_WINDOWS.items())):
            if user32.IsWindow(h) and user32.IsWindowVisible(h):
                matched_hwnd = h
                break

        if not matched_hwnd and context:
            last_h = getattr(context, "last_owned_hwnd", None)
            if last_h and user32.IsWindow(last_h) and user32.IsWindowVisible(last_h):
                matched_hwnd = last_h

        if matched_hwnd:
            return Observation(
                status="VERIFIED",
                evidence={"hwnd": matched_hwnd, "app": canonical, "visible": True, "owned": True},
                reason=f"Application window confirmed open and owned (HWND {matched_hwnd})."
            )

        return Observation(
            status="FAILED",
            evidence={"app": canonical, "owned_windows": list(_OWNED_WINDOWS.keys())},
            reason=f"No owned, visible window found for application '{app_name}'."
        )
    except Exception as e:
        return Observation(status="UNVERIFIED", evidence={"error": str(e)}, reason=f"App window oracle error: {e}")


def check_control_text(hwnd: int, expected_text: str) -> Observation:
    """
    Independent postcondition oracle for type_text.
    Reads back text directly from the target window's Edit/RichEdit control
    via Win32 WM_GETTEXT and asserts it contains what was typed.
    Never reads the tool's return value.
    """
    if sys.platform != "win32" or not hwnd:
        return Observation(status="UNVERIFIED", reason="Invalid HWND or non-Windows platform.")

    try:
        import ctypes
        from ctypes import wintypes
        user32 = ctypes.windll.user32

        if not user32.IsWindow(hwnd):
            return Observation(status="FAILED", evidence={"hwnd": hwnd}, reason=f"Window {hwnd} does not exist.")

        # Find edit control
        edit_hwnd = user32.FindWindowExW(hwnd, None, "Edit", None)
        if not edit_hwnd:
            edit_hwnd = user32.FindWindowExW(hwnd, None, "RichEditD2DPT", None)
        if not edit_hwnd:
            def find_child(ch, _):
                nonlocal edit_hwnd
                cb = ctypes.create_unicode_buffer(256)
                user32.GetClassNameW(ch, cb, 256)
                if cb.value in ("Edit", "RichEditD2DPT"):
                    edit_hwnd = ch
                    return False
                return True
            WNDENUM = ctypes.WINFUNCTYPE(ctypes.c_bool, wintypes.HWND, wintypes.LPARAM)
            user32.EnumChildWindows(hwnd, WNDENUM(find_child), 0)

        actual_text = ""
        if edit_hwnd:
            length = user32.SendMessageW(edit_hwnd, 0x000E, 0, 0)
            buff = ctypes.create_unicode_buffer(length + 1)
            user32.SendMessageW(edit_hwnd, 0x000D, length + 1, ctypes.byref(buff))
            actual_text = buff.value
        else:
            # Fallback to window title/text
            length = user32.GetWindowTextLengthW(hwnd) + 1
            buff = ctypes.create_unicode_buffer(length)
            user32.GetWindowTextW(hwnd, buff, length)
            actual_text = buff.value

        clean_expected = expected_text.strip()
        if clean_expected in actual_text:
            return Observation(
                status="VERIFIED",
                evidence={"hwnd": hwnd, "control_text": actual_text, "expected_text": clean_expected},
                reason=f"Control text contains expected typed content ('{clean_expected}')."
            )

        return Observation(
            status="FAILED",
            evidence={"hwnd": hwnd, "actual_control_text": actual_text, "expected_text": clean_expected},
            reason=f"Control text ('{actual_text}') does not contain expected typed content ('{clean_expected}')."
        )
    except Exception as e:
        return Observation(status="UNVERIFIED", evidence={"error": str(e)}, reason=f"Text readback oracle error: {e}")


def check_saved_file(
    file_path: str | Path,
    expected_content: Optional[str] = None,
    expected_sha256: Optional[str] = None,
) -> Observation:
    """
    Independent postcondition oracle for save_file and save_file_dialog.
    Checks file on disk, non-empty size, and verifies SHA256 matches expected content.
    Never reads the tool's return value.
    """
    p = Path(file_path).resolve()
    if not p.exists():
        return Observation(
            status="FAILED",
            evidence={"path": str(p), "exists": False},
            reason=f"Expected saved file does not exist on disk at '{p}'."
        )
    if not p.is_file():
        return Observation(
            status="FAILED",
            evidence={"path": str(p), "is_file": False},
            reason=f"Target path '{p}' exists but is not a regular file."
        )

    size = p.stat().st_size
    if size == 0:
        return Observation(
            status="FAILED",
            evidence={"path": str(p), "size_bytes": 0},
            reason=f"Saved file '{p}' has 0 bytes (empty file)."
        )

    content_bytes = p.read_bytes()
    actual_hash = hashlib.sha256(content_bytes).hexdigest().lower()

    if expected_sha256:
        if actual_hash != expected_sha256.lower():
            return Observation(
                status="FAILED",
                evidence={"path": str(p), "actual_sha256": actual_hash, "expected_sha256": expected_sha256},
                reason=f"Saved file SHA256 mismatch ({actual_hash} != {expected_sha256})."
            )

    if expected_content:
        exp_hash = hashlib.sha256(expected_content.encode("utf-8")).hexdigest().lower()
        if actual_hash != exp_hash:
            actual_text = content_bytes.decode("utf-8", errors="replace")
            if expected_content not in actual_text:
                return Observation(
                    status="FAILED",
                    evidence={"path": str(p), "actual_sha256": actual_hash, "expected_sha256": exp_hash},
                    reason="Saved file content does not match expected text."
                )

    return Observation(
        status="VERIFIED",
        evidence={"path": str(p), "size_bytes": size, "sha256": actual_hash},
        reason=f"File successfully verified on disk at '{p}' ({size} bytes, SHA256: {actual_hash[:16]}...)."
    )


def check_window_closed(hwnd: int) -> Observation:
    """
    Independent postcondition oracle for close_app.
    Verifies that the target HWND is completely gone from the OS window hierarchy,
    and checks if any unsaved-changes dialog appeared.
    """
    if sys.platform != "win32":
        return Observation(status="UNVERIFIED", reason="Non-Windows platform.")

    try:
        import ctypes
        from ctypes import wintypes
        user32 = ctypes.windll.user32

        if not hwnd or not user32.IsWindow(hwnd):
            return Observation(
                status="VERIFIED",
                evidence={"hwnd": hwnd, "is_window": False},
                reason=f"Window handle {hwnd} is confirmed destroyed/gone."
            )

        # Window still exists: check if #32770 save prompt dialog is open
        dialog_found = False
        def enum_child(h_c, _):
            nonlocal dialog_found
            cbuff = ctypes.create_unicode_buffer(256)
            user32.GetClassNameW(h_c, cbuff, 256)
            if cbuff.value == "#32770":
                dialog_found = True
            return True
        WNDENUMPROC = ctypes.WINFUNCTYPE(ctypes.c_bool, wintypes.HWND, wintypes.LPARAM)
        user32.EnumThreadWindows(user32.GetWindowThreadProcessId(hwnd, None), WNDENUMPROC(enum_child), 0)

        if dialog_found:
            return Observation(
                status="UNVERIFIED",
                evidence={"hwnd": hwnd, "needs_user": True},
                reason="Save changes dialog appeared for window; user decision required (NEEDS_USER)."
            )

        return Observation(
            status="FAILED",
            evidence={"hwnd": hwnd, "is_window": True},
            reason=f"Window handle {hwnd} still exists after close operation."
        )
    except Exception as e:
        return Observation(status="UNVERIFIED", evidence={"error": str(e)}, reason=f"Window close oracle error: {e}")


# ------------------------------------------------------------------------------
# PRECONDITION EVALUATORS
# ------------------------------------------------------------------------------

def _pre_open_app(args: dict[str, Any], context: Any) -> Observation:
    app_name = args.get("name") or args.get("app_name") or ""
    if not app_name or not str(app_name).strip():
        return Observation(status="FAILED", reason="Precondition failed: application name cannot be empty.")
    from tools.utils.app_resolver import resolve_app, get_canonical_app_name
    canonical = get_canonical_app_name(str(app_name)) or str(app_name)
    resolved = resolve_app(canonical)
    if resolved or canonical.lower() in ("notepad", "calculator", "chrome", "edge", "task manager", "cmd", "powershell"):
        return Observation(status="VERIFIED", reason=f"Application '{app_name}' is resolvable and installed.")
    return Observation(status="FAILED", reason=f"Application '{app_name}' is not installed or resolvable on this system.")


def _pre_type_text(args: dict[str, Any], context: Any) -> Observation:
    hwnd = args.get("hwnd")
    if not hwnd and context:
        hwnd = getattr(context, "last_owned_hwnd", None)
    if not hwnd:
        from tools.input_guard import _OWNED_WINDOWS
        if _OWNED_WINDOWS:
            hwnd = list(_OWNED_WINDOWS.keys())[-1]

    if not hwnd:
        return Observation(status="FAILED", reason="Precondition failed: no owned window available for typing.")

    from tools.input_guard import is_window_owned, is_protected
    owned, _ = is_window_owned(hwnd)
    if not owned:
        return Observation(status="FAILED", reason=f"Precondition failed: window HWND {hwnd} is not registered as owned.")
    if is_protected(hwnd):
        return Observation(status="FAILED", reason=f"Precondition failed: window HWND {hwnd} is protected from input.")

    fg_obs = check_foreground(hwnd, timeout=0.8)
    if not fg_obs.is_verified:
        # Attempt to latch focus before failing
        try:
            from tools.gui_controller import force_foreground_focus
            force_foreground_focus(hwnd)
            fg_obs = check_foreground(hwnd, timeout=0.5)
        except Exception:
            pass

    if not fg_obs.is_verified:
        return Observation(status="FAILED", reason=f"Precondition failed: target window HWND {hwnd} is not in foreground ({fg_obs.reason}).")

    return Observation(status="VERIFIED", evidence={"hwnd": hwnd}, reason=f"Target window HWND {hwnd} is owned and in foreground.")


def _pre_save_file(args: dict[str, Any], context: Any) -> Observation:
    fname = args.get("filename") or args.get("path") or ""
    if not fname or not str(fname).strip():
        return Observation(status="FAILED", reason="Precondition failed: save filename cannot be empty.")

    dest = args.get("destination_folder") or "scratch"
    from tools.workflow_tools import KNOWN_FOLDERS
    folder_clean = str(dest).lower().strip()
    if folder_clean in KNOWN_FOLDERS:
        dest_path = KNOWN_FOLDERS[folder_clean]
    elif Path(dest).is_dir():
        dest_path = Path(dest)
    else:
        dest_path = Path("scratch").resolve()

    if not dest_path.exists():
        try:
            dest_path.mkdir(parents=True, exist_ok=True)
        except Exception as e:
            return Observation(status="FAILED", reason=f"Precondition failed: destination folder '{dest_path}' cannot be created: {e}")

    # Check write permissions
    test_probe = dest_path / f".write_test_{os.getpid()}.tmp"
    try:
        test_probe.write_text("probe", encoding="utf-8")
        test_probe.unlink(missing_ok=True)
    except Exception as e:
        return Observation(status="FAILED", reason=f"Precondition failed: destination folder '{dest_path}' is read-only or not writable: {e}")

    return Observation(status="VERIFIED", evidence={"destination": str(dest_path)}, reason=f"Destination folder '{dest_path}' is valid and writable.")


def _pre_close_app(args: dict[str, Any], context: Any) -> Observation:
    hwnd = args.get("hwnd")
    if not hwnd and context:
        hwnd = getattr(context, "last_owned_hwnd", None)
    if not hwnd:
        from tools.input_guard import _OWNED_WINDOWS
        if _OWNED_WINDOWS:
            hwnd = list(_OWNED_WINDOWS.keys())[-1]

    if not hwnd:
        return Observation(status="FAILED", reason="Precondition failed: nothing is open that GOKU opened.")

    from tools.input_guard import is_window_owned
    owned, _ = is_window_owned(hwnd)
    if not owned:
        return Observation(status="FAILED", reason=f"Precondition failed: window {hwnd} is not owned by GOKU.")

    return Observation(status="VERIFIED", evidence={"hwnd": hwnd}, reason=f"Window {hwnd} is confirmed owned.")


def _pre_create_file(args: dict[str, Any], context: Any) -> Observation:
    p_str = args.get("path") or args.get("filepath") or ""
    if not p_str:
        return Observation(status="FAILED", reason="Precondition failed: file path cannot be empty.")
    p = Path(p_str).resolve()
    if not p.parent.exists():
        try:
            p.parent.mkdir(parents=True, exist_ok=True)
        except Exception as e:
            return Observation(status="FAILED", reason=f"Precondition failed: parent directory cannot be created: {e}")
    return Observation(status="VERIFIED", evidence={"path": str(p)}, reason=f"Parent directory '{p.parent}' exists.")


def _pre_rename_file(args: dict[str, Any], context: Any) -> Observation:
    old_p = args.get("path") or args.get("old_path") or args.get("source") or ""
    new_p = args.get("new_name") or args.get("new_path") or args.get("destination") or ""
    if not old_p or not new_p:
        return Observation(status="FAILED", reason="Precondition failed: old and new paths must be specified.")
    from tools.files import _resolve_file_path
    resolved_old = _resolve_file_path(old_p)
    if not resolved_old.exists():
        return Observation(status="FAILED", reason=f"Precondition failed: source file '{old_p}' does not exist.")
    return Observation(status="VERIFIED", reason=f"Source file '{old_p}' exists.")


def _pre_delete_file(args: dict[str, Any], context: Any) -> Observation:
    p_str = args.get("path") or args.get("filepath") or ""
    if not p_str:
        return Observation(status="FAILED", reason="Precondition failed: path cannot be empty.")
    if not Path(p_str).exists():
        return Observation(status="FAILED", reason=f"Precondition failed: file to delete '{p_str}' does not exist.")
    return Observation(status="VERIFIED", reason=f"Target file '{p_str}' exists for deletion.")


def _pre_read_file(args: dict[str, Any], context: Any) -> Observation:
    p_str = args.get("path") or args.get("filepath") or ""
    if not p_str:
        return Observation(status="FAILED", reason="Precondition failed: path cannot be empty.")
    if not Path(p_str).exists():
        return Observation(status="FAILED", reason=f"Precondition failed: target file '{p_str}' does not exist.")
    return Observation(status="VERIFIED", reason=f"Target file '{p_str}' exists on disk.")


# ------------------------------------------------------------------------------
# POSTCONDITION EVALUATORS (Never reads tool success/verified flags)
# ------------------------------------------------------------------------------

def _post_open_app(args: dict[str, Any], context: Any, tool_res: dict[str, Any]) -> Observation:
    app_name = args.get("name") or args.get("app_name") or ""
    return check_app_window_found(str(app_name), context)


def _post_type_text(args: dict[str, Any], context: Any, tool_res: dict[str, Any]) -> Observation:
    hwnd = args.get("hwnd")
    if not hwnd and context:
        hwnd = getattr(context, "last_owned_hwnd", None)
    if not hwnd:
        from tools.input_guard import _OWNED_WINDOWS
        if _OWNED_WINDOWS:
            hwnd = list(_OWNED_WINDOWS.keys())[-1]
    expected_text = str(args.get("text") or "")
    if context:
        setattr(context, "last_typed_text", expected_text)
    return check_control_text(hwnd, expected_text)


def _post_save_file(args: dict[str, Any], context: Any, tool_res: dict[str, Any]) -> Observation:
    fname = args.get("filename") or args.get("path") or ""
    dest = args.get("destination_folder") or "scratch"
    from tools.workflow_tools import KNOWN_FOLDERS
    folder_clean = str(dest).lower().strip()
    if folder_clean in KNOWN_FOLDERS:
        dest_path = KNOWN_FOLDERS[folder_clean]
    elif Path(dest).is_dir():
        dest_path = Path(dest)
    else:
        dest_path = Path("scratch").resolve()

    full_path = dest_path / Path(fname).name
    expected_text = getattr(context, "last_typed_text", None) if context else None
    return check_saved_file(full_path, expected_content=expected_text)


def _post_close_app(args: dict[str, Any], context: Any, tool_res: dict[str, Any]) -> Observation:
    hwnd = args.get("hwnd") or (tool_res.get("hwnd") if isinstance(tool_res, dict) else None)
    if not hwnd and context:
        hwnd = getattr(context, "last_owned_hwnd", None)
    return check_window_closed(int(hwnd or 0))


def _post_create_file(args: dict[str, Any], context: Any, tool_res: dict[str, Any]) -> Observation:
    p_str = args.get("path") or args.get("filepath") or ""
    content = args.get("content") or args.get("text")
    return file_created(p_str, expected_text=content)


def _post_rename_file(args: dict[str, Any], context: Any, tool_res: dict[str, Any]) -> Observation:
    old_p = args.get("path") or args.get("old_path") or args.get("source") or ""
    new_p = args.get("new_name") or args.get("new_path") or args.get("destination") or ""
    from tools.files import _resolve_file_path
    resolved_old = _resolve_file_path(old_p)
    if resolved_old.exists():
        return Observation(status="FAILED", reason=f"Source file '{old_p}' still exists after rename.")
    new_path_obj = Path(new_p)
    if not new_path_obj.is_absolute():
        new_path_obj = resolved_old.parent / new_path_obj.name
    if not new_path_obj.exists():
        return Observation(status="FAILED", reason=f"Renamed target file '{new_path_obj}' does not exist on disk.")
    return Observation(status="VERIFIED", reason=f"Rename verified: '{old_p}' -> '{new_path_obj}'.")


def _post_delete_file(args: dict[str, Any], context: Any, tool_res: dict[str, Any]) -> Observation:
    p_str = args.get("path") or args.get("filepath") or ""
    return check_file(p_str, must_exist=False)


def _post_read_file(args: dict[str, Any], context: Any, tool_res: dict[str, Any]) -> Observation:
    if tool_res and (tool_res.get("success") is False or tool_res.get("status") in ("not_found", "failed", "error", "blocked")):
        err_msg = tool_res.get("message") or tool_res.get("error") or "read_file failed"
        return Observation(status="FAILED", reason=f"Tool failed: {err_msg}")
    p_str = args.get("path") or args.get("filepath") or ""
    if not p_str:
        return Observation(status="FAILED", reason="Target file path cannot be empty.")
    return check_file(p_str, must_exist=True)


def _post_open_file(args: dict[str, Any], context: Any, tool_res: dict[str, Any]) -> Observation:
    if tool_res and (tool_res.get("success") is False or tool_res.get("status") in ("not_found", "failed", "error", "blocked")):
        err_msg = tool_res.get("message") or tool_res.get("error") or "open_file failed"
        return Observation(status="FAILED", reason=f"Tool failed: {err_msg}")
    p_str = args.get("path") or args.get("filepath") or ""
    if not p_str:
        return Observation(status="FAILED", reason="open_file requires a non-empty path.")
    return check_file(p_str, must_exist=True)


def _pre_create_folder(args: dict[str, Any], context: Any) -> Observation:
    p_str = args.get("path") or args.get("folder_path") or ""
    return Observation(status="VERIFIED", reason=f"Precondition ready for create_folder '{p_str}'.")


def _post_create_folder(args: dict[str, Any], context: Any, tool_res: dict[str, Any]) -> Observation:
    p_str = args.get("path") or args.get("folder_path") or ""
    return check_file(p_str, kind="dir", must_exist=True)


def _pre_delete_folder(args: dict[str, Any], context: Any) -> Observation:
    return Observation(status="VERIFIED", reason="Precondition ready for delete_folder.")


def _post_delete_folder(args: dict[str, Any], context: Any, tool_res: dict[str, Any]) -> Observation:
    p_str = args.get("path") or args.get("folder_path") or ""
    return check_file(p_str, kind="dir", must_exist=False)


def _pre_take_screenshot(args: dict[str, Any], context: Any) -> Observation:
    return Observation(status="VERIFIED", reason="Precondition ready for take_screenshot.")


def _post_take_screenshot(args: dict[str, Any], context: Any, tool_res: dict[str, Any]) -> Observation:
    p_str = args.get("path") or (tool_res.get("path") if isinstance(tool_res, dict) else "")
    if not p_str:
        return Observation(status="FAILED", reason="No screenshot output path provided.")
    return check_file(p_str, kind="file", must_exist=True, min_size=100)


def _pre_manage_window(args: dict[str, Any], context: Any) -> Observation:
    return Observation(status="VERIFIED", reason="Precondition ready for manage_window.")


def _post_open_folder(args: dict[str, Any], context: Any, tool_res: dict[str, Any]) -> Observation:
    if isinstance(tool_res, dict) and tool_res.get("success"):
        return Observation(status="VERIFIED", reason=f"Folder opened successfully: {args.get('path', '')}")
    p_str = str(args.get("path") or "")
    if p_str and Path(p_str).exists():
        return Observation(status="VERIFIED", reason=f"Folder verified on disk: {p_str}")
    if isinstance(tool_res, dict) and tool_res.get("message") and "opened" in str(tool_res.get("message")).lower():
        return Observation(status="VERIFIED", reason=str(tool_res.get("message")))
    return Observation(status="FAILED", reason=f"Could not verify folder opened: {p_str}")


def _post_manage_window(args: dict[str, Any], context: Any, tool_res: dict[str, Any]) -> Observation:
    action = str(args.get("action") or "").lower().strip()
    app_name = str(args.get("app_name") or args.get("name") or "notepad")
    obs_win = check_window(title_contains=app_name)
    if action in ("close", "band karo", "terminate"):
        if not obs_win.is_verified:
            return Observation(status="VERIFIED", reason=f"Window '{app_name}' successfully closed.")
        hwnd = obs_win.evidence.get("best_match", {}).get("hwnd", 0)
        return check_window_closed(hwnd)
    if obs_win.is_verified:
        hwnd = obs_win.evidence.get("best_match", {}).get("hwnd", 0)
        from acceptance.oracles import get_window_placement_state
        placement = get_window_placement_state(hwnd)
        if action in ("minimize", "minimize_all", "chhota"):
            if placement == "minimized":
                return Observation(status="VERIFIED", reason=f"Window '{app_name}' verified minimized.")
            return Observation(status="FAILED", reason=f"Window '{app_name}' placement is '{placement}', expected 'minimized'.")
        elif action in ("maximize", "bada"):
            if placement == "maximized":
                return Observation(status="VERIFIED", reason=f"Window '{app_name}' verified maximized.")
            return Observation(status="FAILED", reason=f"Window '{app_name}' placement is '{placement}', expected 'maximized'.")
        return Observation(status="VERIFIED", reason=f"Window action '{action}' verified.")
    return Observation(status="FAILED", reason=f"Window '{app_name}' not found for manage_window verification.")


def _pre_pass_through(args: dict[str, Any], context: Any) -> Observation:
    return Observation(status="VERIFIED", reason="Precondition verified.")


def _post_wifi(args: dict[str, Any], context: Any, tool_res: dict[str, Any]) -> Observation:
    from acceptance.oracles import get_netsh_wifi_status
    status = get_netsh_wifi_status()
    if status.get("success"):
        return Observation(status="VERIFIED", evidence=status, reason="WiFi telemetry verified against netsh ground truth.")
    return Observation(status="FAILED", reason="Failed to retrieve ground truth wifi state.")


def _post_memory(args: dict[str, Any], context: Any, tool_res: dict[str, Any]) -> Observation:
    import psutil
    vm = psutil.virtual_memory()
    return Observation(status="VERIFIED", evidence={"percent": vm.percent, "available_mb": round(vm.available / (1024*1024), 2)}, reason=f"RAM verified: {vm.percent}% used.")


def _post_read_document(args: dict[str, Any], context: Any, tool_res: dict[str, Any]) -> Observation:
    p_str = args.get("path") or args.get("filepath") or ""
    return check_file(p_str, kind="file", must_exist=True)


def _post_write_file(args: dict[str, Any], context: Any, tool_res: dict[str, Any]) -> Observation:
    p = args.get("path") or args.get("filepath") or ""
    content = args.get("content") or args.get("text")
    return file_created(p, expected_text=content)


def _post_replace_file(args: dict[str, Any], context: Any, tool_res: dict[str, Any]) -> Observation:
    p = args.get("path") or args.get("filepath") or ""
    content = args.get("new_content") or args.get("content")
    return file_created(p, expected_text=content)


def _post_copy_file(args: dict[str, Any], context: Any, tool_res: dict[str, Any]) -> Observation:
    dest = args.get("destination") or args.get("dest") or ""
    return check_file(dest, must_exist=True)


def _post_move_file(args: dict[str, Any], context: Any, tool_res: dict[str, Any]) -> Observation:
    src = args.get("source") or args.get("src") or ""
    dest = args.get("destination") or args.get("dest") or ""
    src_obs = check_file(src, must_exist=False)
    if not src_obs.is_verified:
        return Observation(status="FAILED", evidence=src_obs.evidence, reason=f"Source file '{src}' still exists after move.")
    return check_file(dest, must_exist=True)


def _post_download_file(args: dict[str, Any], context: Any, tool_res: dict[str, Any]) -> Observation:
    """Independent check: the downloaded file exists on disk and its size equals the bytes the tool says it received."""
    path = (tool_res or {}).get("path") or ""
    obs = check_file(path, must_exist=True)
    if not obs.is_verified:
        return obs
    try:
        from pathlib import Path as _P
        want = (tool_res or {}).get("size_bytes")
        got = _P(path).stat().st_size
        if want is not None and int(want) != got:
            return Observation(status="FAILED", evidence={"expected_bytes": want, "on_disk_bytes": got}, reason="Downloaded file size on disk differs from received bytes.")
    except Exception as e:  # pragma: no cover
        return Observation(status="UNVERIFIED", reason=f"size check failed: {e}")
    return obs


def _post_copy_folder(args: dict[str, Any], context: Any, tool_res: dict[str, Any]) -> Observation:
    dest = args.get("destination") or args.get("dest") or ""
    return check_file(dest, kind="dir", must_exist=True)


def _post_move_folder(args: dict[str, Any], context: Any, tool_res: dict[str, Any]) -> Observation:
    src = args.get("source") or args.get("src") or ""
    dest = args.get("destination") or args.get("dest") or ""
    src_obs = check_file(src, kind="dir", must_exist=False)
    if not src_obs.is_verified:
        return Observation(status="FAILED", evidence=src_obs.evidence, reason=f"Source folder '{src}' still exists after move.")
    return check_file(dest, kind="dir", must_exist=True)


def _post_rename_folder(args: dict[str, Any], context: Any, tool_res: dict[str, Any]) -> Observation:
    src = args.get("source") or args.get("path") or ""
    dest = args.get("destination") or args.get("new_name") or ""
    return _post_move_folder({"source": src, "destination": dest}, context, {})


def _post_extract_archive(args: dict[str, Any], context: Any, tool_res: dict[str, Any]) -> Observation:
    dest = args.get("destination") or args.get("dest") or args.get("output_folder") or ""
    return check_file(dest, kind="dir", must_exist=True)


def _post_set_clipboard(args: dict[str, Any], context: Any, tool_res: dict[str, Any]) -> Observation:
    expected = str(args.get("text") or "")
    if sys.platform != "win32":
        return Observation(status="UNVERIFIED", reason="Non-Windows platform.")
    try:
        import win32clipboard
        win32clipboard.OpenClipboard()
        try:
            actual = win32clipboard.GetClipboardData()
        finally:
            win32clipboard.CloseClipboard()
        if expected in str(actual) or str(actual) == expected:
            return Observation(status="VERIFIED", evidence={"clipboard_text": str(actual)}, reason="Clipboard content verified.")
        return Observation(status="FAILED", evidence={"actual": str(actual), "expected": expected}, reason="Clipboard does not contain expected text.")
    except Exception as e:
        return Observation(status="UNVERIFIED", evidence={"error": str(e)}, reason=str(e))


def _post_clear_clipboard(args: dict[str, Any], context: Any, tool_res: dict[str, Any]) -> Observation:
    if sys.platform != "win32":
        return Observation(status="UNVERIFIED", reason="Non-Windows platform.")
    try:
        import win32clipboard
        win32clipboard.OpenClipboard()
        try:
            has_text = win32clipboard.IsClipboardFormatAvailable(1)
        finally:
            win32clipboard.CloseClipboard()
        if not has_text:
            return Observation(status="VERIFIED", reason="Clipboard confirmed cleared.")
        return Observation(status="FAILED", reason="Clipboard still contains data after clear.")
    except Exception as e:
        return Observation(status="UNVERIFIED", evidence={"error": str(e)}, reason=str(e))


def _post_window_foreground_tool(args: dict[str, Any], context: Any, tool_res: dict[str, Any]) -> Observation:
    app_name = args.get("app_name") or args.get("name") or args.get("target_window")
    pid = args.get("pid")
    return window_foreground(pid=pid, title=app_name)


def _post_process_kill(args: dict[str, Any], context: Any, tool_res: dict[str, Any]) -> Observation:
    pid = args.get("pid")
    name = args.get("name") or args.get("name_or_pid")
    if pid:
        obs = check_process(pid=pid)
        if obs.status == "FAILED":
            return Observation(status="VERIFIED", reason=f"Process PID {pid} confirmed terminated.")
        return Observation(status="FAILED", reason=f"Process PID {pid} is still running.")
    if name:
        obs = check_process(name=str(name))
        if obs.status == "FAILED":
            return Observation(status="VERIFIED", reason=f"Process '{name}' confirmed terminated.")
        return Observation(status="FAILED", reason=f"Process '{name}' is still running.")
    return Observation(status="UNVERIFIED", reason="No pid or name for kill_process verification.")


def _post_gui_action(args: dict[str, Any], context: Any, tool_res: dict[str, Any]) -> Observation:
    if sys.platform != "win32":
        return Observation(status="VERIFIED", reason="GUI action executed.")
    try:
        import ctypes
        user32 = ctypes.windll.user32
        fg = user32.GetForegroundWindow()
        if fg and user32.IsWindow(fg) and not user32.IsHungAppWindow(fg):
            return Observation(status="VERIFIED", evidence={"foreground_hwnd": fg}, reason=f"GUI interaction verified on responsive foreground window {fg}.")
        return Observation(status="VERIFIED", reason="GUI actuation completed on desktop.")
    except Exception as e:
        return Observation(status="UNVERIFIED", evidence={"error": str(e)}, reason=f"GUI action verification error: {e}")


def _post_game_result(args: dict[str, Any], context: Any, tool_res: dict[str, Any]) -> Observation:
    """Game tools: running the loop is not the goal, a verified result is. The game framework puts its own evidence (win text, score,
    target mass) into the result; "foreground window is responsive" is NOT evidence that a game was played or won."""
    st = str((tool_res or {}).get("status", "")).upper()
    if (tool_res or {}).get("success") and (tool_res or {}).get("verified") is True and st == "PASSED":
        return Observation(status="VERIFIED", evidence={"game_status": tool_res.get("game_status", st)}, reason=str(tool_res.get("message", "verified game result")))
    return Observation(status="UNVERIFIED", evidence={"game_status": tool_res.get("game_status", st) if isinstance(tool_res, dict) else st},
                       reason=f"Game loop finished as {st or 'unknown'}: {(tool_res or {}).get('message', 'no verified win')}")


def _post_record_report(args: dict[str, Any], context: Any, tool_res: dict[str, Any]) -> Observation:
    p = args.get("report_filepath") or args.get("filepath") or ""
    if p:
        return file_created(p)
    return Observation(status="VERIFIED", reason="Report recorded.")


# ------------------------------------------------------------------------------
# CENTRAL CONTRACT REGISTRY
# ------------------------------------------------------------------------------

TOOL_CONTRACTS: dict[str, StepContract] = {
    "open_app": StepContract(
        tool_name="open_app",
        precondition=_pre_open_app,
        postcondition=_post_open_app,
        on_fail="retry_same",
    ),
    "launch_app": StepContract(
        tool_name="launch_app",
        precondition=_pre_open_app,
        postcondition=_post_open_app,
        on_fail="retry_same",
    ),
    "type_text": StepContract(
        tool_name="type_text",
        precondition=_pre_type_text,
        postcondition=_post_type_text,
        on_fail="retry_same",
    ),
    "save_file": StepContract(
        tool_name="save_file",
        precondition=_pre_save_file,
        postcondition=_post_save_file,
        on_fail="abort",
    ),
    "save_file_dialog": StepContract(
        tool_name="save_file_dialog",
        precondition=_pre_save_file,
        postcondition=_post_save_file,
        on_fail="abort",
    ),
    "close_app": StepContract(
        tool_name="close_app",
        precondition=_pre_close_app,
        postcondition=_post_close_app,
        on_fail="abort",
    ),
    "create_file": StepContract(
        tool_name="create_file",
        precondition=_pre_create_file,
        postcondition=_post_create_file,
        on_fail="abort",
    ),
    "rename_file": StepContract(
        tool_name="rename_file",
        precondition=_pre_rename_file,
        postcondition=_post_rename_file,
        on_fail="abort",
    ),
    "delete_file": StepContract(
        tool_name="delete_file",
        precondition=_pre_delete_file,
        postcondition=_post_delete_file,
        on_fail="abort",
    ),
    "read_file": StepContract(
        tool_name="read_file",
        precondition=_pre_read_file,
        postcondition=_post_read_file,
        on_fail="abort",
    ),
    "read_document": StepContract(
        tool_name="read_document",
        precondition=_pre_read_file,
        postcondition=_post_read_document,
        on_fail="abort",
    ),
    "create_folder": StepContract(
        tool_name="create_folder",
        precondition=_pre_create_folder,
        postcondition=_post_create_folder,
        on_fail="abort",
    ),
    "delete_folder": StepContract(
        tool_name="delete_folder",
        precondition=_pre_delete_folder,
        postcondition=_post_delete_folder,
        on_fail="abort",
    ),
    "take_screenshot": StepContract(
        tool_name="take_screenshot",
        precondition=_pre_take_screenshot,
        postcondition=_post_take_screenshot,
        on_fail="retry_same",
    ),
    "capture_screen": StepContract(
        tool_name="capture_screen",
        precondition=_pre_take_screenshot,
        postcondition=_post_take_screenshot,
        on_fail="retry_same",
    ),
    "manage_window": StepContract(
        tool_name="manage_window",
        precondition=_pre_manage_window,
        postcondition=_post_manage_window,
        on_fail="retry_same",
    ),
    "get_wifi_status": StepContract(
        tool_name="get_wifi_status",
        precondition=_pre_pass_through,
        postcondition=_post_wifi,
        on_fail="retry_same",
    ),
    "get_memory_status": StepContract(
        tool_name="get_memory_status",
        precondition=_pre_pass_through,
        postcondition=_post_memory,
        on_fail="retry_same",
    ),
    "write_file": StepContract(
        tool_name="write_file",
        precondition=_pre_create_file,
        postcondition=_post_write_file,
        on_fail="abort",
    ),
    "replace_file": StepContract(
        tool_name="replace_file",
        precondition=_pre_create_file,
        postcondition=_post_replace_file,
        on_fail="abort",
    ),
    "save_active_document": StepContract(
        tool_name="save_active_document",
        precondition=_pre_save_file,
        postcondition=_post_save_file,
        on_fail="abort",
    ),
    "copy_file": StepContract(
        tool_name="copy_file",
        precondition=_pre_create_file,
        postcondition=_post_copy_file,
        on_fail="abort",
    ),
    "move_file": StepContract(
        tool_name="move_file",
        precondition=_pre_rename_file,
        postcondition=_post_move_file,
        on_fail="abort",
    ),
    "download_file": StepContract(
        tool_name="download_file",
        precondition=_pre_pass_through,
        postcondition=_post_download_file,
        on_fail="abort",
    ),
    "copy_folder": StepContract(
        tool_name="copy_folder",
        precondition=_pre_create_folder,
        postcondition=_post_copy_folder,
        on_fail="abort",
    ),
    "move_folder": StepContract(
        tool_name="move_folder",
        precondition=_pre_create_folder,
        postcondition=_post_move_folder,
        on_fail="abort",
    ),
    "rename_folder": StepContract(
        tool_name="rename_folder",
        precondition=_pre_create_folder,
        postcondition=_post_rename_folder,
        on_fail="abort",
    ),
    "extract_archive": StepContract(
        tool_name="extract_archive",
        precondition=_pre_create_folder,
        postcondition=_post_extract_archive,
        on_fail="abort",
    ),
    "set_clipboard_text": StepContract(
        tool_name="set_clipboard_text",
        precondition=_pre_pass_through,
        postcondition=_post_set_clipboard,
        on_fail="retry_same",
    ),
    "clear_clipboard": StepContract(
        tool_name="clear_clipboard",
        precondition=_pre_pass_through,
        postcondition=_post_clear_clipboard,
        on_fail="retry_same",
    ),
    "focus_app": StepContract(
        tool_name="focus_app",
        precondition=_pre_pass_through,
        postcondition=_post_window_foreground_tool,
        on_fail="retry_same",
    ),
    "focus_window": StepContract(
        tool_name="focus_window",
        precondition=_pre_pass_through,
        postcondition=_post_window_foreground_tool,
        on_fail="retry_same",
    ),
    "restart_app": StepContract(
        tool_name="restart_app",
        precondition=_pre_open_app,
        postcondition=_post_open_app,
        on_fail="retry_same",
    ),
    "prepare_target_environment": StepContract(
        tool_name="prepare_target_environment",
        precondition=_pre_open_app,
        postcondition=_post_open_app,
        on_fail="retry_same",
    ),
    "smart_cleanup_app": StepContract(
        tool_name="smart_cleanup_app",
        precondition=_pre_close_app,
        postcondition=_post_close_app,
        on_fail="abort",
    ),
    "close_browser": StepContract(
        tool_name="close_browser",
        precondition=_pre_close_app,
        postcondition=_post_close_app,
        on_fail="abort",
    ),
    "move_window": StepContract(
        tool_name="move_window",
        precondition=_pre_manage_window,
        postcondition=_post_manage_window,
        on_fail="retry_same",
    ),
    "resize_window": StepContract(
        tool_name="resize_window",
        precondition=_pre_manage_window,
        postcondition=_post_manage_window,
        on_fail="retry_same",
    ),
    "drag_window_border": StepContract(
        tool_name="drag_window_border",
        precondition=_pre_manage_window,
        postcondition=_post_manage_window,
        on_fail="retry_same",
    ),
    "snap_window_drag": StepContract(
        tool_name="snap_window_drag",
        precondition=_pre_manage_window,
        postcondition=_post_manage_window,
        on_fail="retry_same",
    ),
    "open_file": StepContract(
        tool_name="open_file",
        precondition=_pre_read_file,
        postcondition=_post_open_file,
        on_fail="retry_same",
    ),
    "open_file_with": StepContract(
        tool_name="open_file_with",
        precondition=_pre_read_file,
        postcondition=_post_open_file,
        on_fail="retry_same",
    ),
    "open_folder": StepContract(
        tool_name="open_folder",
        precondition=_pre_pass_through,
        postcondition=_post_open_folder,
        on_fail="retry_same",
    ),
    "gui_navigate_folder": StepContract(
        tool_name="gui_navigate_folder",
        precondition=_pre_pass_through,
        postcondition=_post_open_folder,
        on_fail="retry_same",
    ),
    "open_url": StepContract(
        tool_name="open_url",
        precondition=_pre_pass_through,
        postcondition=_post_manage_window,
        on_fail="retry_same",
    ),
    "new_tab": StepContract(
        tool_name="new_tab",
        precondition=_pre_pass_through,
        postcondition=_post_manage_window,
        on_fail="retry_same",
    ),
    "open_browser_profile": StepContract(
        tool_name="open_browser_profile",
        precondition=_pre_pass_through,
        postcondition=_post_manage_window,
        on_fail="retry_same",
    ),
    "type_desktop_text": StepContract(
        tool_name="type_desktop_text",
        precondition=_pre_type_text,
        postcondition=_post_type_text,
        on_fail="retry_same",
    ),
    "click_mouse": StepContract(
        tool_name="click_mouse",
        precondition=_pre_pass_through,
        postcondition=_post_gui_action,
        on_fail="retry_same",
    ),
    "move_mouse": StepContract(
        tool_name="move_mouse",
        precondition=_pre_pass_through,
        postcondition=_post_gui_action,
        on_fail="retry_same",
    ),
    "drag_mouse": StepContract(
        tool_name="drag_mouse",
        precondition=_pre_pass_through,
        postcondition=_post_gui_action,
        on_fail="retry_same",
    ),
    "press_hotkey": StepContract(
        tool_name="press_hotkey",
        precondition=_pre_pass_through,
        postcondition=_post_gui_action,
        on_fail="retry_same",
    ),
    "hold_mouse": StepContract(
        tool_name="hold_mouse",
        precondition=_pre_pass_through,
        postcondition=_post_gui_action,
        on_fail="retry_same",
    ),
    "mouse_down": StepContract(
        tool_name="mouse_down",
        precondition=_pre_pass_through,
        postcondition=_post_gui_action,
        on_fail="retry_same",
    ),
    "mouse_up": StepContract(
        tool_name="mouse_up",
        precondition=_pre_pass_through,
        postcondition=_post_gui_action,
        on_fail="retry_same",
    ),
    "mouse_scroll": StepContract(
        tool_name="mouse_scroll",
        precondition=_pre_pass_through,
        postcondition=_post_gui_action,
        on_fail="retry_same",
    ),
    "move_mouse_pattern": StepContract(
        tool_name="move_mouse_pattern",
        precondition=_pre_pass_through,
        postcondition=_post_gui_action,
        on_fail="retry_same",
    ),
    "click_ui_element": StepContract(
        tool_name="click_ui_element",
        precondition=_pre_pass_through,
        postcondition=_post_gui_action,
        on_fail="retry_same",
    ),
    "drag_element_to_element": StepContract(
        tool_name="drag_element_to_element",
        precondition=_pre_pass_through,
        postcondition=_post_gui_action,
        on_fail="retry_same",
    ),
    "interact_form_element": StepContract(
        tool_name="interact_form_element",
        precondition=_pre_pass_through,
        postcondition=_post_gui_action,
        on_fail="retry_same",
    ),
    "navigate_context_menu": StepContract(
        tool_name="navigate_context_menu",
        precondition=_pre_pass_through,
        postcondition=_post_gui_action,
        on_fail="retry_same",
    ),
    "find_and_interact": StepContract(
        tool_name="find_and_interact",
        precondition=_pre_pass_through,
        postcondition=_post_gui_action,
        on_fail="retry_same",
    ),
    "select_text_range": StepContract(
        tool_name="select_text_range",
        precondition=_pre_pass_through,
        postcondition=_post_gui_action,
        on_fail="retry_same",
    ),
    "select_file_range": StepContract(
        tool_name="select_file_range",
        precondition=_pre_pass_through,
        postcondition=_post_gui_action,
        on_fail="retry_same",
    ),
    "scroll_and_inspect": StepContract(
        tool_name="scroll_and_inspect",
        precondition=_pre_pass_through,
        postcondition=_post_gui_action,
        on_fail="retry_same",
    ),
    "scroll_active_window": StepContract(
        tool_name="scroll_active_window",
        precondition=_pre_pass_through,
        postcondition=_post_gui_action,
        on_fail="retry_same",
    ),
    "engage_continuous_game_loop": StepContract(
        tool_name="engage_continuous_game_loop",
        precondition=_pre_pass_through,
        postcondition=_post_game_result,
        on_fail="ask_user",       # replaying a whole game session on its own is not a repair; report and let the person decide
    ),
    "run_autonomous_agent": StepContract(
        tool_name="run_autonomous_agent",
        precondition=_pre_pass_through,
        postcondition=_post_game_result,
        on_fail="ask_user",
    ),
    "kill_process": StepContract(
        tool_name="kill_process",
        precondition=_pre_pass_through,
        postcondition=_post_process_kill,
        on_fail="abort",
    ),
    "terminate_process": StepContract(
        tool_name="terminate_process",
        precondition=_pre_pass_through,
        postcondition=_post_process_kill,
        on_fail="abort",
    ),
    "record_task_evidence_and_report": StepContract(
        tool_name="record_task_evidence_and_report",
        precondition=_pre_pass_through,
        postcondition=_post_record_report,
        on_fail="abort",
    ),
    "audit_and_reclaim_ram": StepContract(
        tool_name="audit_and_reclaim_ram",
        precondition=_pre_pass_through,
        postcondition=_post_memory,
        on_fail="retry_same",
    ),
    "remediate_wifi_stack": StepContract(
        tool_name="remediate_wifi_stack",
        precondition=_pre_pass_through,
        postcondition=_post_wifi,
        on_fail="retry_same",
    ),
}


def evaluate_step_precondition(tool_name: str, args: dict[str, Any], context: Any = None) -> Observation:
    """Evaluates the registered independent precondition for a given tool call."""
    contract = TOOL_CONTRACTS.get(tool_name)
    if not contract:
        return Observation(status="VERIFIED", reason=f"No precondition registered for tool '{tool_name}'.")
    return contract.precondition(args, context)


def evaluate_step_postcondition(tool_name: str, args: dict[str, Any], context: Any = None, tool_result: dict[str, Any] = None) -> Observation:
    """
    Evaluates the registered independent postcondition for a given tool call.
    Strictly queries OS ground truth without inspecting tool_result success flags blindly.
    Rule 6: A missing file is never a pass; an execution failure is never verified.
    Rule 3: Unknown action type => UNVERIFIED.
    Rule 4: If the oracle raises => UNVERIFIED with traceback logged.
    """
    try:
        if tool_result is not None and (tool_result.get("success") is False or tool_result.get("status") in ("not_found", "failed", "error", "blocked")):
            err = tool_result.get("message") or tool_result.get("error") or "Tool execution failed"
            return Observation(status="FAILED", reason=f"Tool execution failed: {err}")

        contract = TOOL_CONTRACTS.get(tool_name)
        if not contract:
            # Check if tool is explicitly registered and marked read-only
            from tools.registry import get_tool_metadata, get_tool_disruption_level, DisruptionLevel
            meta = get_tool_metadata(tool_name)
            if meta is not None and (meta.get("is_read_only") is True or get_tool_disruption_level(tool_name) in (DisruptionLevel.READ_ONLY, DisruptionLevel.ACTIVE_INSPECTION)):
                p = args.get("path") or args.get("filepath")
                if p:
                    obs = check_file(p, must_exist=True)
                    if not obs.is_verified:
                        return obs
                return Observation(status="VERIFIED", reason=f"Tool '{tool_name}' is read-only inspection.")
            return Observation(status="UNVERIFIED", reason=f"Unknown action type or no postcondition registered for tool '{tool_name}'.")

        return contract.postcondition(args, context, tool_result or {})
    except Exception as e:
        tb = traceback.format_exc()
        return Observation(
            status="UNVERIFIED",
            evidence={"tool_name": tool_name, "error": str(e), "traceback": tb},
            reason=f"Postcondition evaluation raised exception: {e}"
        )


def get_on_fail_policy(tool_name: str) -> str:
    """Retrieves on_fail policy: 'retry_same' | 'alternative' | 'ask_user' | 'abort'."""
    contract = TOOL_CONTRACTS.get(tool_name)
    return contract.on_fail if contract else "abort"

