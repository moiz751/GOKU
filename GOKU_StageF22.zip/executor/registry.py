"""
Executor Registry shim re-exporting tools.registry and registering runtime execution tools.
"""
from tools.registry import (
    TOOLS,
    tool,
    discover_tools,
    get_all_schemas,
    get_tool_schema,
    get_tool_metadata,
    get_tool_disruption_level,
    is_read_only,
    is_destructive,
    check_parameter_feasibility,
    DisruptionLevel,
)

try:
    from tools.game_engine import engage_continuous_game_loop
except ImportError:
    engage_continuous_game_loop = None

try:
    from brain.autonomous_agent import run_autonomous_agent, AutonomousVisualAgent
except ImportError:
    run_autonomous_agent = None
    AutonomousVisualAgent = None

__all__ = [
    "TOOLS",
    "tool",
    "discover_tools",
    "get_all_schemas",
    "get_tool_schema",
    "get_tool_metadata",
    "get_tool_disruption_level",
    "is_read_only",
    "is_destructive",
    "check_parameter_feasibility",
    "DisruptionLevel",
    "engage_continuous_game_loop",
    "run_autonomous_agent",
    "AutonomousVisualAgent",
]
