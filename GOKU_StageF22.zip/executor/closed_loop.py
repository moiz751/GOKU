"""
executor/closed_loop.py - Closed Loop Automation Engine.
Architecture:
  observe -> decide (rules) -> act -> observe -> postcondition
  -> retry at most 2 times with a DIFFERENT strategy -> else FAILED.

Enforces:
1. wait_for(condition, timeout, backoff 50->200 ms). No fixed sleeps.
   Window hung check -> up to 15s -> UNVERIFIED.
2. Launch: record PID, find window by PID, verify foreground PID before key batch.
3. Typing: Strategy 1 (WM_SETTEXT) -> verify; on mismatch Strategy 2 (clipboard paste)
   -> verify; else FAILED. Never save empty editor unless explicitly allowed.
4. Save: Python fast path (temp file + os.replace) if GUI not required;
   GUI Save: Ctrl+S on verified hwnd -> wait Save As -> set filename edit -> BM_CLICK Save.
5. Popup policy evaluator: applies config/popup_policy.json.
6. Postcondition: dialog_absent, file exists, size > 0, normalized content match, mtime >= start.
7. finally: release stuck modifiers (Shift/Ctrl/Alt) and restore clipboard.
"""
from __future__ import annotations

import ctypes
from ctypes import wintypes
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time
from typing import Any

from perception.controls import find_editor_control, get_control_text, inspect_controls
from perception.dialogs import inspect_dialog
from perception.popup_handler import (
    BM_CLICK,
    click_dialog_button,
    evaluate_dialog_policy,
)
from perception.uia import inspect_uia_editor
from perception.wait import WindowHungException, wait_for
from perception.windows import list_top_windows

WM_SETTEXT = 0x000C
WM_COMMAND = 0x0111
WM_PASTE = 0x0302
VK_SHIFT = 0x10
VK_CONTROL = 0x11
VK_MENU = 0x12
VK_S = 0x53
KEYEVENTF_KEYUP = 0x0002


# ==============================================================================
# Clipboard & Modifier Cleanups (Requirement 7)
# ==============================================================================
def release_stuck_modifiers() -> None:
    """Releases VK_SHIFT, VK_CONTROL, and VK_MENU in case they are stuck."""
    if sys.platform != "win32":
        return
    user32 = ctypes.windll.user32
    for vk in (VK_SHIFT, VK_CONTROL, VK_MENU):
        try:
            user32.keybd_event(vk, 0, KEYEVENTF_KEYUP, 0)
        except Exception:
            pass


def get_clipboard_text() -> str | None:
    """Safely retrieves Unicode text from Windows clipboard using 64-bit safe ctypes."""
    if sys.platform != "win32":
        return None
    user32 = ctypes.windll.user32
    kernel32 = ctypes.windll.kernel32

    kernel32.GlobalLock.argtypes = [wintypes.HGLOBAL]
    kernel32.GlobalLock.restype = wintypes.LPVOID
    kernel32.GlobalUnlock.argtypes = [wintypes.HGLOBAL]
    kernel32.GlobalUnlock.restype = wintypes.BOOL

    user32.OpenClipboard.argtypes = [wintypes.HWND]
    user32.OpenClipboard.restype = wintypes.BOOL
    user32.CloseClipboard.argtypes = []
    user32.CloseClipboard.restype = wintypes.BOOL
    user32.GetClipboardData.argtypes = [wintypes.UINT]
    user32.GetClipboardData.restype = wintypes.HANDLE

    if not user32.OpenClipboard(None):
        return None
    try:
        CF_UNICODETEXT = 13
        h_glb = user32.GetClipboardData(CF_UNICODETEXT)
        if not h_glb:
            return ""
        ptr = kernel32.GlobalLock(h_glb)
        if not ptr:
            return ""
        text = ctypes.wstring_at(ptr)
        kernel32.GlobalUnlock(h_glb)
        return text
    finally:
        user32.CloseClipboard()


def set_clipboard_text(text: str) -> bool:
    """Safely writes Unicode text to Windows clipboard using 64-bit safe ctypes."""
    if sys.platform != "win32":
        return False
    user32 = ctypes.windll.user32
    kernel32 = ctypes.windll.kernel32

    kernel32.GlobalAlloc.argtypes = [wintypes.UINT, ctypes.c_size_t]
    kernel32.GlobalAlloc.restype = wintypes.HGLOBAL
    kernel32.GlobalLock.argtypes = [wintypes.HGLOBAL]
    kernel32.GlobalLock.restype = wintypes.LPVOID
    kernel32.GlobalUnlock.argtypes = [wintypes.HGLOBAL]
    kernel32.GlobalUnlock.restype = wintypes.BOOL

    user32.OpenClipboard.argtypes = [wintypes.HWND]
    user32.OpenClipboard.restype = wintypes.BOOL
    user32.CloseClipboard.argtypes = []
    user32.CloseClipboard.restype = wintypes.BOOL
    user32.EmptyClipboard.argtypes = []
    user32.EmptyClipboard.restype = wintypes.BOOL
    user32.SetClipboardData.argtypes = [wintypes.UINT, wintypes.HANDLE]
    user32.SetClipboardData.restype = wintypes.HANDLE

    if not user32.OpenClipboard(None):
        return False
    try:
        user32.EmptyClipboard()
        CF_UNICODETEXT = 13
        data = text.encode("utf-16le") + b"\x00\x00"
        GMEM_MOVEABLE = 0x0002
        h_glb = kernel32.GlobalAlloc(GMEM_MOVEABLE, len(data))
        if not h_glb:
            return False
        ptr = kernel32.GlobalLock(h_glb)
        if not ptr:
            return False
        ctypes.memmove(ptr, data, len(data))
        kernel32.GlobalUnlock(h_glb)
        user32.SetClipboardData(CF_UNICODETEXT, h_glb)
        return True
    finally:
        user32.CloseClipboard()


# ==============================================================================
# Window & Process Perception Helpers (Requirement 1 & 2)
# ==============================================================================
def get_foreground_pid() -> int | None:
    """Returns the process ID of the current foreground window."""
    if sys.platform != "win32":
        return None
    user32 = ctypes.windll.user32
    fg_hwnd = user32.GetForegroundWindow()
    if not fg_hwnd:
        return None
    pid = wintypes.DWORD()
    user32.GetWindowThreadProcessId(fg_hwnd, ctypes.byref(pid))
    return pid.value


def find_window_by_pid(pid: int, class_name: str | None = None) -> dict[str, Any] | None:
    """Finds top-level visible window matching pid (and optional class_name)."""
    windows = list_top_windows()
    for w in windows:
        if w["pid"] == pid and w["visible"]:
            if class_name is None or w["class_name"].lower() == class_name.lower():
                return w
    return None


def normalize_text(text: str) -> str:
    """Normalizes CRLF/LF line endings and strips trailing blank lines for robust comparison."""
    return text.replace("\r\n", "\n").replace("\r", "\n").strip()


# ==============================================================================
# Closed Loop Engine
# ==============================================================================
class ClosedLoopRunner:
    def __init__(self, action_config: dict[str, Any]) -> None:
        self.cfg = action_config
        self.app_cmd = action_config.get("app_cmd", ["notepad.exe"])
        self.text_to_type = action_config.get("text_to_type", "")
        self.target_file = Path(action_config["target_file"]).resolve()
        self.target_file.parent.mkdir(parents=True, exist_ok=True)
        self.gui_required = bool(action_config.get("gui_required", True))
        self.user_allow_overwrite = bool(action_config.get("user_allow_overwrite", False))
        self.task_created_files = [str(Path(f).resolve()) for f in action_config.get("task_created_files", [])]
        self.task_intent = action_config.get("task_intent", "save")
        self.allow_empty_file = bool(action_config.get("allow_empty_file", False))
        self.allow_locked_file = bool(action_config.get("allow_locked_file", False))

        self.proc: subprocess.Popen[Any] | None = None
        self.pid: int = 0
        self.main_hwnd: int = 0
        self.orig_clipboard: str | None = None
        self.action_start: float = 0.0

        self.observations: dict[str, Any] = {
            "app_cmd": self.app_cmd,
            "target_file": str(self.target_file),
            "final_file": str(self.target_file),
            "typing_strategy": None,
            "save_method": "GUI" if self.gui_required else "PYTHON_FAST_PATH",
            "policy_branch": None,
            "policy_rationale": None,
            "postcondition_passed": False,
            "verdict": "UNVERIFIED",
            "dialog_events": [],
        }

    def execute(self) -> dict[str, Any]:
        """
        Executes the closed loop with observe -> decide -> act -> observe -> postcondition.
        Guarantees cleanup in finally: releases modifiers and restores clipboard.
        """
        self.action_start = time.time()
        self.orig_clipboard = get_clipboard_text()

        try:
            # 1. Fast Path Save if GUI is not required (Requirement 4)
            if not self.gui_required:
                return self._execute_python_fast_path()

            # 2. Launch & Window Perception (Requirement 1 & 2)
            self._launch_and_locate_window()

            # 3. Typing with Verification & Strategy Retry (Requirement 3)
            self._type_and_verify()

            # 4. Save & Dialog Policy Enforcement (Requirement 4 & 5)
            self._save_and_handle_popups()

            # 5. Postcondition Verification (Requirement 6)
            self._verify_postconditions()

            self.observations["verdict"] = "PASSED"
            return self.observations

        except WindowHungException as whe:
            self.observations["verdict"] = "UNVERIFIED"
            self.observations["error"] = str(whe)
            return self.observations
        except Exception as ex:
            if self.observations["verdict"] == "UNVERIFIED":
                self.observations["error"] = str(ex)
                return self.observations
            self.observations["verdict"] = "FAILED"
            self.observations["error"] = str(ex)
            return self.observations
        finally:
            self._cleanup()

    def _cleanup(self) -> None:
        """Teardown: terminate process, release stuck modifiers, restore clipboard."""
        if self.proc:
            try:
                self.proc.terminate()
                self.proc.wait(timeout=1.0)
            except Exception:
                try:
                    self.proc.kill()
                except Exception:
                    pass

        release_stuck_modifiers()

        if self.orig_clipboard is not None:
            try:
                set_clipboard_text(self.orig_clipboard)
            except Exception:
                pass

    def _execute_python_fast_path(self) -> dict[str, Any]:
        """Atomic write using temporary file + os.replace without GUI."""
        self.target_file.parent.mkdir(parents=True, exist_ok=True)
        # Write to temp file in same directory
        temp_fd, temp_path = tempfile.mkstemp(
            prefix="goku_p4_", suffix=".tmp", dir=str(self.target_file.parent)
        )
        with os.fdopen(temp_fd, "w", encoding="utf-8") as f:
            f.write(self.text_to_type)

        os.replace(temp_path, str(self.target_file))

        # Verify postconditions
        assert self.target_file.exists(), "Target file does not exist after atomic replace"
        if not self.allow_empty_file:
            assert self.target_file.stat().st_size > 0, "Target file is empty"
        disk_content = self.target_file.read_text(encoding="utf-8")
        assert normalize_text(disk_content) == normalize_text(self.text_to_type), "Content mismatch"
        assert self.target_file.stat().st_mtime >= (self.action_start - 2.0), "mtime older than start"

        self.observations["postcondition_passed"] = True
        self.observations["verdict"] = "PASSED"
        return self.observations

    def _launch_and_locate_window(self) -> None:
        """Launches process, records PID, and waits for top-level window by PID."""
        self.proc = subprocess.Popen(self.app_cmd)
        self.pid = self.proc.pid
        self.observations["pid"] = self.pid

        # Wait for top window by PID (dynamic backoff 50->200ms, hung check up to 15s)
        def _get_win() -> dict[str, Any] | None:
            return find_window_by_pid(self.pid, class_name="Notepad")

        win = wait_for(_get_win, timeout=10.0, initial_delay=0.05, max_delay=0.2, hung_timeout=15.0)
        if not win:
            raise TimeoutError(f"Could not locate visible window for PID {self.pid}")

        self.main_hwnd = win["hwnd"]
        self.observations["hwnd"] = self.main_hwnd

        # Ensure main window is in foreground
        user32 = ctypes.windll.user32
        user32.SetForegroundWindow(self.main_hwnd)

    def _type_and_verify(self) -> None:
        """
        Executes typing with 2 strategies:
        - Strategy 1: WM_SETTEXT directly into editor hwnd.
        - Strategy 2: Focus + clipboard paste via WM_PASTE / Ctrl+V.
        Verifies readback matches text_to_type; fails if mismatch after 2 strategies.
        Guards: Never save empty editor unless explicitly allowed.
        """
        if not self.text_to_type and not self.allow_empty_file:
            raise ValueError("Never save an empty editor unless the task asked for an empty file.")

        user32 = ctypes.windll.user32

        # 1. Locate editor control
        ed = find_editor_control(self.main_hwnd)
        ed_hwnd = ed["hwnd"] if ed else None
        if not ed_hwnd:
            uia_ed = inspect_uia_editor(self.main_hwnd)
            if uia_ed:
                ed_hwnd = uia_ed["hwnd"]

        if not ed_hwnd:
            raise RuntimeError(f"Could not locate editor control inside window {self.main_hwnd}")

        expected_norm = normalize_text(self.text_to_type)

        # ----------------------------------------------------------------------
        # Strategy 1: Direct WM_SETTEXT
        # ----------------------------------------------------------------------
        self.observations["typing_strategy"] = "WM_SETTEXT"
        user32.SendMessageW(ed_hwnd, WM_SETTEXT, 0, self.text_to_type)

        read_text, _, _ = get_control_text(ed_hwnd)
        if normalize_text(read_text) == expected_norm:
            self.observations["typing_verified"] = True
            return

        # ----------------------------------------------------------------------
        # Strategy 2: Clipboard Paste into Focused Editor
        # ----------------------------------------------------------------------
        self.observations["typing_strategy"] = "CLIPBOARD_PASTE"
        set_clipboard_text(self.text_to_type)

        # Verify foreground window is our PID before key/paste batch (Requirement 2)
        self._verify_focus_or_abort()

        user32.SendMessageW(ed_hwnd, WM_PASTE, 0, 0)
        read_text_s2, _, _ = get_control_text(ed_hwnd)
        if normalize_text(read_text_s2) == expected_norm:
            self.observations["typing_verified"] = True
            return

        # Both strategies failed
        raise RuntimeError(
            f"Typing verification failed after 2 strategies. Expected '{expected_norm[:40]}', got '{read_text_s2[:40]}'"
        )

    def _verify_focus_or_abort(self) -> None:
        """
        Requirement 2: Before every key batch verify the foreground window is that PID;
        abort the batch if focus changed.
        """
        user32 = ctypes.windll.user32
        fg_hwnd = user32.GetForegroundWindow()
        if not fg_hwnd:
            user32.SetForegroundWindow(self.main_hwnd)
            return
        fg_pid = get_foreground_pid()
        if fg_pid is not None and fg_pid != self.pid:
            raise RuntimeError(
                f"Foreground focus changed: expected PID {self.pid}, got PID {fg_pid}. Batch aborted."
            )

    def _save_and_handle_popups(self) -> None:
        """
        Executes GUI Save As flow:
        - Trigger Save As (WM_COMMAND 4 / Ctrl+S)
        - Locate filename Edit control and Save button
        - Set filename Edit text
        - Click Save button
        - Detect modal popups and apply config/popup_policy.json
        """
        user32 = ctypes.windll.user32

        # Verify foreground before key/command batch (Requirement 2)
        self._verify_focus_or_abort()

        # Post WM_COMMAND 4 (File -> Save As in Notepad)
        user32.PostMessageW(self.main_hwnd, WM_COMMAND, 4, 0)

        # Wait for Save As dialog
        def _get_save_as_dialog() -> dict[str, Any] | None:
            dlg = inspect_dialog(target_pid=self.pid)
            if dlg and "save" in dlg["title"].lower():
                return dlg
            return None

        save_as_dlg = wait_for(_get_save_as_dialog, timeout=5.0, initial_delay=0.05, max_delay=0.2)
        if not save_as_dlg:
            raise RuntimeError("Save As dialog did not appear within 5.0 seconds")

        dlg_hwnd = save_as_dlg["hwnd"]
        ctrls = inspect_controls(dlg_hwnd)

        # Find filename edit control (id 1001 or Edit)
        fn_edit = next((c for c in ctrls if c["control_id"] == 1001 and c["class_name"].lower() == "edit"), None)
        if not fn_edit:
            fn_edit = next((c for c in ctrls if c["class_name"].lower() == "edit"), None)
        if not fn_edit:
            raise RuntimeError("Could not find filename edit control in Save As dialog")

        # Find Save button (id 1 or '&Save')
        save_btn = next((c for c in ctrls if c["control_id"] == 1 or "&save" in c["text"].lower()), None)
        if not save_btn:
            raise RuntimeError("Could not find Save button in Save As dialog")

        # Set filename edit text
        user32.SendMessageW(fn_edit["hwnd"], WM_SETTEXT, 0, str(self.target_file))
        time.sleep(0.1)

        # Click Save button via BM_CLICK
        user32.PostMessageW(save_btn["hwnd"], BM_CLICK, 0, 0)

        # ----------------------------------------------------------------------
        # Check for Modal Popup Dialogs (Requirement 5)
        # ----------------------------------------------------------------------
        def _check_popup() -> dict[str, Any] | None:
            p = inspect_dialog(target_pid=self.pid)
            # Must be a child popup different from the Save As dialog itself
            if p and p["hwnd"] != dlg_hwnd:
                return p
            return None

        popup = wait_for(_check_popup, timeout=1.5, initial_delay=0.05, max_delay=0.15)
        if popup:
            self.observations["dialog_events"].append(popup["title"])
            context = {
                "target_file": str(self.target_file),
                "task_created_files": self.task_created_files,
                "user_allow_overwrite": self.user_allow_overwrite,
                "task_intent": self.task_intent,
            }
            decision = evaluate_dialog_policy(popup, context)
            self.observations["policy_branch"] = decision["policy_branch"]
            self.observations["policy_rationale"] = decision["rationale"]

            if decision["status"] == "UNVERIFIED":
                self.observations["verdict"] = "UNVERIFIED"
                raise RuntimeError(decision["rationale"])

            if decision["status"] == "STOPPED":
                # If it's a file lock / sharing violation dialog, dismiss OK and report
                if decision["target_button"]:
                    click_dialog_button(popup["hwnd"], decision["target_button"])
                self.observations["verdict"] = "STOPPED"
                raise RuntimeError(decision["rationale"])

            if decision["policy_branch"] == "save_as_numbered_copy":
                # 1. Dismiss confirm dialog with &No
                if decision["target_button"]:
                    click_dialog_button(popup["hwnd"], decision["target_button"])
                time.sleep(0.2)
                # 2. Update filename in Save As dialog
                new_file = decision["new_filename"]
                self.observations["final_file"] = str(new_file)
                user32.SendMessageW(fn_edit["hwnd"], WM_SETTEXT, 0, str(new_file))
                time.sleep(0.1)
                # 3. Click Save button again
                user32.PostMessageW(save_btn["hwnd"], BM_CLICK, 0, 0)
            elif decision["action"] == "click_button" and decision["target_button"]:
                click_dialog_button(popup["hwnd"], decision["target_button"])
                # 1. Wait for this initial popup to close
                def _initial_popup_closed() -> bool:
                    p = inspect_dialog(target_pid=self.pid)
                    return p is None or p["hwnd"] != popup["hwnd"]

                wait_for(_initial_popup_closed, timeout=1.5, initial_delay=0.05, max_delay=0.1)

                # 2. Check if a distinct secondary dialog appeared (e.g. file lock error)
                def _check_secondary() -> dict[str, Any] | None:
                    p = inspect_dialog(target_pid=self.pid)
                    if p and p["hwnd"] != dlg_hwnd and p["hwnd"] != popup["hwnd"]:
                        return p
                    return None

                secondary = wait_for(_check_secondary, timeout=0.8, initial_delay=0.05, max_delay=0.1)
                if secondary:
                    sec_decision = evaluate_dialog_policy(secondary, context)
                    if sec_decision.get("target_button"):
                        click_dialog_button(secondary["hwnd"], sec_decision["target_button"])
                    if sec_decision.get("policy_branch") == "locked_file_detected":
                        self.observations["policy_branch"] = "locked_file_detected"
                        self.observations["policy_rationale"] = sec_decision["rationale"]
                        if self.allow_locked_file:
                            wait_for(lambda: inspect_dialog(target_pid=self.pid) is None, timeout=1.5)
                            self.observations["final_file"] = str(self.target_file)
                            return
                        raise RuntimeError(sec_decision["rationale"])

        # Wait for Save As dialog to dismiss
        def _dialog_gone() -> bool:
            return inspect_dialog(target_pid=self.pid) is None

        wait_for(_dialog_gone, timeout=3.0, initial_delay=0.05, max_delay=0.2)

    def _verify_postconditions(self) -> None:
        """
        Requirement 6:
        After the popup closes verify:
        - dialog_absent
        - file exists
        - size > 0 (or == 0 if empty file requested)
        - content matches (normalised)
        - mtime >= action start
        """
        # 1. Dialog absent
        remaining_dlg = inspect_dialog(target_pid=self.pid)
        if remaining_dlg:
            raise RuntimeError(f"Postcondition failed: dialog still present: {remaining_dlg['title']}")

        # 2. File exists
        final_path = Path(self.observations["final_file"])
        if not final_path.exists():
            raise FileNotFoundError(f"Postcondition failed: final file {final_path} does not exist on disk")

        # 3. Check for locked file verified case
        if self.allow_locked_file and self.observations.get("policy_branch") == "locked_file_detected":
            self.observations["postcondition_passed"] = True
            self.observations["file_size"] = final_path.stat().st_size
            self.observations["mtime"] = final_path.stat().st_mtime
            return

        # 3. Size check
        file_size = final_path.stat().st_size
        if not self.allow_empty_file and file_size == 0:
            raise ValueError(f"Postcondition failed: file {final_path} is 0 bytes (empty)")

        # 4. Content matches (normalized)
        disk_content = final_path.read_text(encoding="utf-8")
        if normalize_text(disk_content) != normalize_text(self.text_to_type):
            raise ValueError(
                f"Postcondition failed: disk content mismatch in {final_path}.\n"
                f"Expected: {self.text_to_type[:100]!r}\nActual: {disk_content[:100]!r}"
            )

        # 5. mtime >= action_start - 2.0s
        mtime = final_path.stat().st_mtime
        if mtime < (self.action_start - 2.0):
            raise ValueError(
                f"Postcondition failed: file mtime ({mtime}) is older than action start ({self.action_start})"
            )

        self.observations["postcondition_passed"] = True
        self.observations["file_size"] = file_size
        self.observations["mtime"] = mtime


def execute_closed_loop(action_config: dict[str, Any]) -> dict[str, Any]:
    """Convenience functional wrapper for ClosedLoopRunner."""
    runner = ClosedLoopRunner(action_config)
    return runner.execute()
