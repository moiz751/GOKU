"""
executor/sandbox_runner.py
Speculative Sandbox Trial Runner.
Probes candidate interactions in an isolated trial before permanent dispatch,
measuring immediate visual delta to detect ineffective probes (e.g. dead clicks or unhandled elements).
"""
from __future__ import annotations
from typing import Any, Callable


class SpeculativeSandbox:
    """
    Trial runner that probes actions in an isolated phase before permanent commitment.
    Measures post-action visual delta to determine if the interaction caused a meaningful UI state change.
    """

    def __init__(self) -> None:
        pass

    def probe_interaction(
        self,
        action_fn: Callable[..., Any],
        *args: Any,
        timeout_ms: int = 300,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """
        1. Captures baseline native GDI screen thumbnail/state.
        2. Dispatches action inside isolated try-block with simulated safety guard.
        3. Measures post-action visual delta via wait_for_visual_event(event_type='settled', timeout=timeout_sec).
        4. If delta <= 0.005:
             records outcome: {"status": "INEFFECTIVE_PROBE", "delta": delta, "should_retry_alternative": True}
           If delta > 0.005:
             confirms successful state transition: {"status": "COMMITTED", "delta": delta}
        """
        from tools.vision_tools import (
            wait_for_visual_event,
            _capture_viewport_thumbnail,
            _compute_frame_difference,
        )

        timeout_sec = max(0.1, timeout_ms / 1000.0)

        # Baseline capture
        baseline = _capture_viewport_thumbnail()

        # Isolated execution attempt
        action_result = None
        try:
            action_result = action_fn(*args)
        except Exception as e:
            return {
                "status": "INEFFECTIVE_PROBE",
                "delta": 0.0,
                "error": str(e),
                "should_retry_alternative": True,
            }

        # Measure post-action visual settlement
        ev_res = wait_for_visual_event(event_type="settled", timeout=timeout_sec)
        post_frame = _capture_viewport_thumbnail()
        diff = _compute_frame_difference(baseline, post_frame)

        delta = max(diff, float(ev_res.get("final_delta", 0.0)))

        if delta > 0.005:
            return {
                "status": "COMMITTED",
                "delta": round(delta, 5),
                "action_result": action_result,
            }
        else:
            return {
                "status": "INEFFECTIVE_PROBE",
                "delta": round(delta, 5),
                "should_retry_alternative": True,
                "action_result": action_result,
            }
