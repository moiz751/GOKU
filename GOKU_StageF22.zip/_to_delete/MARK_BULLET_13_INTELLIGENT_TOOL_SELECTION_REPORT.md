# MARK / GOKU: BULLET #13 — INTELLIGENT TOOL SELECTION REPORT
**Autonomous Windows Desktop System Intelligence & Action Layer**  
**Date:** September 8, 2026  
**Environment:** Windows 11 (Python 3.11.9 Offline Runtime, Low-RAM Profile)  
**Status:** **PASSED — ALL TESTS & LIVE OS VERIFICATIONS GREEN**  
**Verdict:** `INTELLIGENT TOOL SELECTION SOUND`

---

## 1. Executive Summary & Architectural Mandate

Bullet #13 focuses on hardening the agent's **tool selection mechanism, semantic affinity scoring, capability contract matching, and least-disruptive execution routing**. When users express arbitrary, novel, colloquial, or code-switched commands (English, Roman Urdu, Hinglish), the agent must:
1. **Prioritize Semantic Fit over Keyword Collisions:** Select tools based on the semantic match between user intent and tool capability contracts rather than fragile substring keyword matches.
2. **Enforce the Least-Disruptive Action Principle:** Adhere strictly to the safety hierarchy:  
   `READ_ONLY` (0) > `ACTIVE_INSPECTION` (1) > `BENIGN_STATE_CHANGE` (2) > `MUTATIVE` (3) > `DESTRUCTIVE` (4). Prefer minimal, non-disruptive tools to satisfy inquiries without disturbing system state.
3. **Validate Parameter Feasibility Before Planning:** Ensure required arguments are available from user input or context before committing to tool execution, preventing dummy/invalid parameter injections.
4. **Disambiguate Confusable Tool Matrices:** Cleanly resolve common confusion pairs:
   - **Launch vs Focus vs URL:** `launch_app` vs `focus_app` vs `open_url`
   - **Graceful Close vs Brutal Kill:** `close_app` vs `kill_process`
   - **File Search vs Folder Listing:** `search_files` vs `list_folder`
   - **Specific Telemetry vs Generic Diagnostics:** `get_free_space` / `get_cpu_status` vs `diagnose_system`
5. **Achieve Total Keyword Trap Immunity:** Resist deceptive entity names such as *"Close Call app"*, *"open kill.sh"*, *"Delete_backup.txt open karo"*, and *"Google search page kholo"*.

---

## 2. Core Architectural Implementations

All enhancements were surgically incorporated into existing modules with **ZERO new third-party dependencies** and **ZERO new modules**:

### 2.1 Formal Disruption Hierarchy & Cost Metrics (`tools/registry.py`)
Introduced `DisruptionLevel(IntEnum)` and automated disruption cost calculation:
- `READ_ONLY` (Cost 0): `get_cpu_status`, `get_memory_status`, `get_free_space`, `list_folder`, `get_application_status`, `is_app_running`, `get_active_window`, `read_file_text`, etc.
- `ACTIVE_INSPECTION` (Cost 1): `test_internet_connectivity`, `diagnose_system`, `diagnose_performance`, `diagnose_cpu`, `diagnose_memory`, `diagnose_storage`, `diagnose_network`.
- `BENIGN_STATE_CHANGE` (Cost 2): `focus_app`, `launch_app`, `open_folder`, `open_file`, `open_url`, `move_window`, `click_mouse`, `type_text`.
- `MUTATIVE` (Cost 3): `create_file`, `create_folder`, `move_file`, `copy_file`, `set_clipboard_text`, `close_app`.
- `DESTRUCTIVE` (Cost 4): `delete_file`, `delete_folder`, `replace_file`, `kill_process`, `terminate_process`.

Updated the `@tool` decorator to automatically inject `disruption_level` and `disruption_cost` into the tool's runtime capability metadata contract.

### 2.2 Parameter Feasibility Gating (`tools/registry.py`)
Implemented `check_parameter_feasibility(tool_name: str, args: dict | None) -> tuple[bool, list[str]]`:
- Cross-references provided parameters against `required` parameter definitions in the tool's JSON schema.
- Rejects calls where required parameters are absent, `None`, or empty strings.
- Emits specific missing argument keys.

### 2.3 Semantic Affinity Scoring & Optimal Tool Resolution (`tools/registry.py`)
Implemented `calculate_semantic_affinity(...)` and `resolve_optimal_tool(...)`:
- **Domain & Action Alignment:** Matches semantic domain and verb against tool metadata (+0.25 to +0.3).
- **Target Type Affinity:** Biases URL targets to `open_url` (+0.4) and penalizes `launch_app` (-0.6); biases folders to `list_folder` (+0.4) and penalizes `search_files` (-0.3).
- **Least-Disruptive Penalty:** Penalizes state changes (-0.3) and destructive tools (-1.0) when intent is observation or status inquiry.
- **Parameter Completeness Bonus/Penalty:** Penalizes missing required parameters (-0.5).
- **Tie-Breaking:** Resolves ties by selecting the tool with the lowest disruption cost.

### 2.4 Safety Firewall Integration (`command_layer/firewall.py`)
Enhanced `pre_execution_semantic_check`:
- Enforces parameter feasibility gating before execution, blocking execution if required schema parameters are missing.
- Blocks destructive operations (`kill_process`, `delete_file`) when user intent or plan constraints specify `read_only` or inspection.
- Enforces confusable routing rules (e.g. blocking URLs passed to `launch_app`).

### 2.5 Confusable Matrix & Keyword Trap Hardening (`command_layer/router.py`)
- **Graceful Close vs Brutal Kill:** Commands with default close phrasing ("band karo", "close notepad", "window close kar do") route to graceful `close_app`. Explicit kill phrasing ("kill", "terminate", "force close", "forcefully band") routes to `kill_process`. Filenames ending in `.exe` gracefully close via `close_app`.
- **App Focus vs Launch:** Commands with "focus", "switch to", "bring to front", or "par jao" route to `focus_app`, avoiding duplicate window launches.
- **Folder Listing vs File Search:** Commands inspecting folder contents ("Downloads folder dikhao", "folder mein kya hai", "list directory") route to `list_folder`. Targeted filename queries ("find report.pdf") route to `search_files`.
- **Keyword Trap Immunity:** Filename and app name literals (e.g. "Close Call", "kill.sh", "Delete_backup.txt") are masked from destructive action triggers.

---

## 3. Test Verification & Results

### 3.1 Dedicated Test Suite (`tests/test_bullet13_intelligent_tool_selection.py`)
A dedicated test suite was written covering **70 tests across 7 distinct dimensions (10 tests each)**:

| Dimension | Scope & Focus | Tests | Status |
|---|---|---|---|
| **Dimension 1** | Least-Disruptive Action Selection | 10 | **10/10 PASSED** |
| **Dimension 2** | Specific vs Generic Tool Granularity | 10 | **10/10 PASSED** |
| **Dimension 3** | Domain & Target Affinity Matching | 10 | **10/10 PASSED** |
| **Dimension 4** | Keyword Trap Immunity | 10 | **10/10 PASSED** |
| **Dimension 5** | Parameter Feasibility Gating | 10 | **10/10 PASSED** |
| **Dimension 6** | Graceful Degradation & Fallback | 10 | **10/10 PASSED** |
| **Dimension 7** | Multilingual Intent-Tool Mapping | 10 | **10/10 PASSED** |
| **Total** | **Bullet #13 Comprehensive Suite** | **70** | **70/70 PASSED (100%)** |

### 3.2 Full Regression Gauntlet (Bullets #1 through #13)
Executed the entire regression gauntlet across all 13 bullets:
```powershell
pytest tests/test_bullet13_intelligent_tool_selection.py tests/test_bullet12_relevant_evidence.py tests/test_bullet11_situation_interpretation.py tests/test_bullet10_long_command_clauses.py tests/test_bullet9_ambiguity_handling.py tests/test_bullet8_correction_negation.py tests/test_bullet7_reference_resolution.py tests/test_bullet6_context_resolution.py tests/test_bullet5_novel_command_generalization.py tests/test_bullet4_intent_entity_separation.py tests/test_bullet3_semantic_generalization.py tests/test_bullet3_unseen_natural_goals.py tests/test_production_context_stress.py -q
```
**Results:**  
- **766 passed in 58.29s**
- **0 failed, 0 errors, 0 regressions**
- **100% Pass Rate across all 13 bullets**

---

## 4. Live Windows 11 Verification (`tests/test_bullet13_live_verification.py`)

End-to-end verification executed on the live Windows 11 host:
1. **Least-Disruptive Hierarchy:** Verified `disruption_cost` ordering (0 for `get_cpu_status`, 3 for `close_app`, 4 for `kill_process`).
2. **Parameter Feasibility Gating:** Confirmed `delete_file` without `path` fails pre-check, while valid paths pass.
3. **Confusable Disambiguation:** Confirmed URLs route to `open_url`, focus queries route to `focus_app`, graceful close routes to `close_app`, and explicit kills route to `kill_process`.
4. **Keyword Trap Immunity:** Verified *"Close Call app"*, *"open kill.sh"*, and *"Delete_backup.txt open karo"* route cleanly to launch/open without destructive side-effects.
5. **Granularity Routing:** Confirmed specific telemetry queries route to granular tools (`get_free_space`, `get_cpu_status`) rather than whole-system diagnostics.
6. **Live Execution Output:**
   - Command: `"how much free space is on C?"`  
     -> Tool: `get_free_space({'drive': 'C:'})`  
     -> Verified Result: `"C: has 101.5 GB free (45.61%) of 222.52 GB."`
   - Command: `"wifi signal strength batao"`  
     -> Tool: `get_wifi_signal({})`  
     -> Verified Result: `"Wi-Fi is not connected. Signal strength unavailable."`

---

## 5. Architectural Compliance Checklist

| Requirement | Specification Constraint | Status | Evidence |
|---|---|---|---|
| **Semantic Fit over Keyword Collisions** | Goal intent evaluated against capability contracts | **Compliant** | `calculate_semantic_affinity()` & `resolve_optimal_tool()` |
| **Least-Disruptive Action Principle** | Read-Only > Active Inspection > State Change > Destructive | **Compliant** | `DisruptionLevel` ordering and cost penalties enforced |
| **Capability Contract & Parameter Feasibility** | Preconditions & required arguments verified before planning | **Compliant** | `check_parameter_feasibility()` in registry & firewall |
| **Tool Confusion Matrix Hardening** | Disambiguates Launch vs Focus vs URL, Close vs Kill, Search vs List | **Compliant** | All 4 matrices covered in router and tested |
| **Keyword Trap Immunity** | Entity names containing action words do not hijack intent | **Compliant** | Tested with Close Call, kill.sh, Delete_backup.txt |
| **Zero New Modules / Engines** | Changes restricted to existing 5 target files | **Compliant** | Zero new files created in src; clean surgical edits |
| **Zero External Dependencies** | Python 3.11 offline standard library only | **Compliant** | No third-party packages introduced |
| **Zero Regressions** | All 696 prior tests must pass; total >= 766 tests | **Compliant** | 766 / 766 tests passed (100%) in 58.29s |

---

## 6. Conclusion & Production Readiness
The implementation of **Bullet #13: Intelligent Tool Selection** is unit verified, mathematically ordered, and production-hardened. The agent demonstrates robust discrimination between fine-grained and broad tools, enforces least-disruptive execution, validates required parameters, and remains immune to keyword traps across English, Roman Urdu, Hinglish, and Code-switched inputs.

**Final Verdict:** `INTELLIGENT TOOL SELECTION SOUND`
