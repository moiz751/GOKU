# GOKU Mistake Memory & Failure Signatures Report
**Generated**: Thu Oct 15 19:50:47 2026  
**Total Real Failures**: 0  
**Active Real Remedies Registered**: 0  
**Hidden Test/Unknown Records**: 53 records hidden (27 failures, 26 remedies) [origin=real filter active]  

## Top 10 Recurring Failure Signatures

| # | Normalized Signature | Tool | Error Class | Count | Last Seen | Status | Evidence / Remedy |
| :-: | :--- | :--- | :--- | :-: | :--- | :---: | :--- |
| - | *No real failure records found in memory store* | - | - | 0 | - | **clean** | - |

## Active Remedies Status

| Tool | Signature | Remedy Action | Verified Hits | Status | Environment | Implementation |
| :--- | :--- | :--- | :-: | :---: | :--- | :--- |
| - | - | - | 0 | **none** | - | - |

---
*Note: 53 non-real (test/unknown) records were excluded from this report per GOKU Provenance Rules.*
