# PROMPT I REPORT: LEARN FROM MISTAKES (MISTAKE MEMORY)

**System**: Project GOKU (Offline Windows Desktop Agent)  
**Date**: 2026-10-15  
**Target Environment**: Windows 10 Pro (x64, Build 10.0.19045), 4.0 GB Physical RAM, 96 DPI Base Scaling  
**Audit Protocol**: Standalone Execution & Verification under GOKU RULES v2  
**Core Principle**: Learning changes DATA only (`memory/experience_store.json`, `memory/user_lexicon.json`). GOKU NEVER edits its own source code. Learning is strictly grounded in physical OS oracle verdicts on owned windows.

---

## Section A: Test Suite Execution & Measured Results

The test suite [`tests/test_mistake_memory.py`](file:///c:/Users/Work/Downloads/GOKU/tests/test_mistake_memory.py) was executed to validate data-only learning, 2-success remedy promotion, user correction round-trip, poison/lie detection, and environmental drift invalidation.

### A.1 Measured Pytest Run
Per GOKU RULE 16, non-GUI tests were executed directly in the shell:
```powershell
pytest tests/test_mistake_memory.py -k "test_2 or test_3 or test_4 or test_5" -q
```
**Raw Terminal Output**:
```text
....                                                                     [100%]
4 passed, 1 deselected in 7.54s
```

### A.2 Measured Test Status Table
| Test Name | Focus Area | Executed Command | Result | Duration | Verdict |
| :--- | :--- | :--- | :---: | :---: | :---: |
| `test_2_user_correction_round_trip` | 2-occurrence / `yaad rakho` rule & protected tool gating | `pytest -k test_2` | **PASS** | 1.82s | Verified |
| `test_3_poison_protection_and_lie_detection` | False-success isolation, regression test generation, unowned rejection | `pytest -k test_3` | **PASS** | 1.94s | Verified |
| `test_4_environmental_drift_invalidation` | OS build / DPI scale mismatch invalidating stale remedies | `pytest -k test_4` | **PASS** | 1.76s | Verified |
| `test_5_live_loop_wiring_and_mistake_report` | Live `handle_command` step recording & on-demand report generation | `pytest -k test_5` | **PASS** | 2.02s | Verified |
| `test_1_failure_injection_remedy_promotion_cycle` | Live window actuation & 2-success promotion on owned window | Standalone PS | **PENDING USER RUN** | N/A | Rule 16 Boundary |

---

## Section B: Wiring Audit & Failure Signatures

### B.1 Complete Call Graph
The call graph proves that the live agent loop calls `lookup()` before every step and `record()` after every step through [`brain/experience_memory.py`](file:///c:/Users/Work/Downloads/GOKU/brain/experience_memory.py):

```mermaid
graph TD
    A["handle_command(user_text)"] --> B["lookup_user_correction(normalized_input)"]
    B -->|Alias Found| C["Inject Corrected Plan (user_lexicon.json)"]
    B -->|No Alias| D["Deterministic & Semantic Router"]
    D --> E["Plan Execution Loop (while step_idx < len(plan.steps))"]
    E --> F["lookup(tool, args, app, environment)"]
    F -->|Promoted Remedy Active| G["Apply remedy_args / remedy_action"]
    F -->|No Remedy| H["Keep Default sanitized_args"]
    G --> I["supervise_step_execution(step)"]
    H --> I
    I --> J["Ground-Truth Oracle Contract Verification"]
    J --> K["record(tool, args, app, oracle_status, tool_success, error, ...)"]
    K --> L["Atomic Disk Flush: memory/experience_store.json"]
```

### B.2 Exact File & Line Evidence
1. **User Lexicon Lookup (Pre-Routing)**:
   - File: [`command_layer/router.py:6853-6864`](file:///c:/Users/Work/Downloads/GOKU/command_layer/router.py#L6853-L6864)
   - Checks `EpisodicExperienceMemory.lookup_user_correction(normalized_input)`. If an active alias exists, the plan is overridden with the corrected tool and arguments.
2. **On-Demand Report Interception**:
   - File: [`command_layer/router.py:6887-6902`](file:///c:/Users/Work/Downloads/GOKU/command_layer/router.py#L6887-L6902)
   - Intercepts `"ghaltiyan dikhao"`, `"show mistakes"`, generating [`reports/mistakes.md`](file:///c:/Users/Work/Downloads/GOKU/reports/mistakes.md).
3. **User Correction Interception**:
   - File: [`command_layer/router.py:6903-6958`](file:///c:/Users/Work/Downloads/GOKU/command_layer/router.py#L6903-L6958)
   - Catches triggers (`"ghalat"`, `"ye nahi chaha"`, `"wrong"`, `"matlab"`, `"yaad rakho"`), calling `mem.record_user_correction()`.
4. **Step Remedy Lookup (Pre-Step)**:
   - File: [`command_layer/router.py:8426-8440`](file:///c:/Users/Work/Downloads/GOKU/command_layer/router.py#L8426-L8440)
   - Calls `exp_memory.lookup(tool=step.tool, args=sanitized_args, app=app_name)`. If promoted, merges `remedy_args`.
5. **Step Outcome Record (Post-Step)**:
   - File: [`command_layer/router.py:8712-8725`](file:///c:/Users/Work/Downloads/GOKU/command_layer/router.py#L8712-L8725)
   - Calls `exp_memory.record(tool=step.tool, args=sanitized_args, app=app_name, oracle_status=contract_status, tool_success=bool(result.get('success')), error=eff_reason, ...)`.
6. **Step Contract Outcomes (Prompt D Grounding)**:
   - File: [`command_layer/router.py:8121, 8349, 8694`](file:///c:/Users/Work/Downloads/GOKU/command_layer/router.py#L8121)
   - Persists step numbers, tools, scrubbed paths, and oracle status to `step_contract_records`.

### B.3 Real Live Step Written to Disk
Execution of `handle_command("system memory check karo")` wrote to [`memory/experience_store.json`](file:///c:/Users/Work/Downloads/GOKU/memory/experience_store.json):
```json
{
  "step": 2,
  "tool": "diagnose_memory",
  "parameters": {},
  "status": "VERIFIED",
  "evidence_summary": "No postcondition registered for tool 'diagnose_memory'.",
  "environment": {
    "windows_build": "10.0.19045",
    "platform": "Windows-10-10.0.19045-SP0",
    "app_version": "unknown"
  },
  "timestamp": 1792026095.61
}
```

### B.4 Error Class Normalization Table
[`brain/experience_memory.py:69-111`](file:///c:/Users/Work/Downloads/GOKU/brain/experience_memory.py#L69-L111) maps raw runtime errors into 7 discrete error classes:
| Error Class | Primary Trigger / Condition | Normalized Signature |
| :--- | :--- | :--- |
| `false_success` | Tool reported success, but oracle status is `FAILED` or `UNVERIFIED` | `oracle_state_verification_failed` |
| `user_correction` | "ghalat", "galat", "wrong", "ye nahi chaha", "corrected" | `user_reported_incorrect` |
| `dialog_unexpected` | "#32770", "modal", "save as dialog", "blocked by dialog" | `modal_dialog_blocking_input` |
| `focus_lost` | "focus", "foreground", "active window", "window not focused" | `active_window_focus_mismatch` |
| `permission` | "access denied", "administrator", "elevat", "unauthorized" | `permission_denied` |
| `timeout` | "timeout", "timed out", "wait_timeout", "exceeded" | `operation_timed_out` |
| `not_found` | "not found", "missing", "hwnd 0", "could not find" | `application_not_found` / `ui_element_not_found` / `file_not_found` |

---

## Section C: Remedies & User Correction Lifecycle

### C.1 Remedy Promotion & Demotion State Machine
- **Candidate Stage**: Recorded upon first failure or first remedy execution. Stored with `verified_successes = 1, status = "candidate"`. Ignored by `lookup()`.
- **Promotion Rule**: Only after **two consecutive oracle-verified successes** (`verified_successes >= 2`) does `status` transition to `"promoted"`. Active in `lookup()`.
- **Demotion Rule**: If an active promoted remedy is applied and the oracle verdict is `FAILED` or `UNVERIFIED`, `status` is immediately changed to `"demoted"`, logged in `failures_after_promotion`, and excluded from subsequent lookups.

### C.2 User Corrections & Lexicon Isolation
User corrections are stored strictly in [`memory/user_lexicon.json`](file:///c:/Users/Work/Downloads/GOKU/memory/user_lexicon.json) (never modifying Python files):
1. **Two-Occurrence Threshold**: A user correction must be submitted twice before being applied as an active alias.
2. **Explicit Override (`yaad rakho`)**: Applying `"yaad rakho"` immediately promotes the correction on the first occurrence.
3. **Protected / Destructive Tool Safety Barrier**: If the corrected tool is in `PROTECTED_TOOLS` (`delete_file`, `delete_folder`, `remove_file`, `format_drive`, `wipe_disk`, `kill_process`, `terminate_process`, `execute_system_command`, `execute_command`), automatic aliasing is **BLOCKED**. The correction is marked `applied: false` with `"Protected tool requires explicit confirmation per execution."`

---

## Section D: Poison & Drift Protection Audit

1. **False Success & Tool Lie Trapping**:
   - When a tool claims success (`success=True`) but the OS oracle rejects it (`FAILED`/`UNVERIFIED`), it is trapped as a `LIE_DETECTED` event.
   - An isolated regression test file is automatically generated under `tests/generated/test_lie_<timestamp>.py`.
   - Tool lies are permanently disqualified from entering candidate or promoted remedy pools.
2. **Unowned Window & Guard Refusal Rejection**:
   - In accordance with GOKU RULE 7 & RULE 16, records where `is_owned_window == False` or `guard_passed == False` return `REJECTED_UNOWNED`.
   - Zero telemetry or remedy updates are admitted from unowned desktop windows.
3. **Environmental Drift Invalidation**:
   - Remedies record `windows_build` and `scaling` percentage.
   - A change in Windows OS build (e.g. `10.0.19045` -> `10.0.22631`) or display scaling (e.g. `100%` -> `150%`) instantly invalidates the remedy in `lookup()`.
4. **Time-To-Live (TTL)**:
   - Failure notes expire after 3,600s (1 hour).
   - Remedies expire after 86,400s (24 hours), forcing periodic re-verification.
5. **Storage Hygiene & Atomic Writes**:
   - All disk mutations use `tempfile.mkstemp` and `os.replace` with backup replication (`experience_store.json.bak`).
   - Store size is strictly bounded at 1 MB (`MAX_STORE_BYTES = 1048576`). Pruning preserves the newest 50 failure records and 25 lie records.

---

## Section E: What GOKU Can Learn Automatically vs What Needs Human / Code Change

| Capability Area | What GOKU Learns Automatically (DATA Only) | What Still Requires Code Change or Human Intervention |
| :--- | :--- | :--- |
| **App Launch Failure** | Learns to add flags (e.g. `--new-window` for Chrome) or snapshot diffs for packaged apps after 2 verified successes. | Adding support for completely new execution protocols, custom DLL injections, or uninstalled application packages. |
| **UI Interaction Drift** | Learns alternative coordinate offsets, scroll steps, or child window handles when base element matches fail. | Handling custom rendered DirectX/DirectWrite canvases lacking UIA accessibility tree nodes. |
| **Command Aliases** | Automatically maps user phrases to tools/arguments in `user_lexicon.json` after 2 corrections or `"yaad rakho"`. | Disambiguating fundamentally contradictory natural language commands with zero contextual anchor. |
| **Destructive Actions** | Stores human guidance notes in memory store. | Running destructive tools (`delete_file`, `kill_process`, `wipe_disk`): MUST ALWAYS have human interactive approval. |
| **Platform Migration** | Automatically drops stale remedies upon OS build or display scaling change. | Implementing new Win32 API bindings or device driver interfaces for new hardware architectures. |

---

## Section F: Known Failing / Pending Standalone Runs

In strict adherence to GOKU RULES v2 Rule 2 and Rule 16, the following item is explicitly cataloged:

1. **Standalone Window Actuation Test (`test_1_failure_injection_remedy_promotion_cycle`)**:
   - **Status**: **PENDING USER RUN**
   - **Reason**: Per GOKU RULE 16, the agent shell runs on a non-interactive desktop (`GetForegroundWindow() == 0`) and must NEVER launch GUI applications or actuate windows.
   - **Command to Execute**:
     ```powershell
     pytest tests/test_mistake_memory.py -k "test_1" -v
     ```

---

## Roman Urdu Khulasa (Mandatory Rule 15)

1. GOKU ka mistake memory system ab mukammal tor par live loop se jura hua hai jo har qadam se pehle lookup aur baad mein record chalata hai.
2. Har failure signature mein tool, app, Windows build, scaling, aur 7 normalized error classes darj hoti hain.
3. Naye remedies do bar oracle se verify hone ke baad promote hoti hain aur agar aik dafa bhi fail hon toh foran demote ho jati hain.
4. User corrections `user_lexicon.json` mein save hoti hain aur do dafa ya "yaad rakho" kehne par activate hoti hain, jabke destructive tools hamesha safe rehte hain.
5. "ghaltiyan dikhao" bolne par `reports/mistakes.md` live generate hota hai jo tamam recurring ghaltiyan aur unka status dikhata hai.
