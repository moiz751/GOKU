# PROMPT R1 REPORT: RESOURCE BASELINE, MODES AND READINESS

**System**: Project GOKU (Offline Windows Desktop Agent)  
**Date**: 2026-10-15  
**Hardware Baseline**: Windows 10/11 64-bit, 4 GB Physical RAM Architecture  
**Governing Protocols**: GOKU RULES v2 + 16-26  
**Status**: **PARTIAL / PENDING OPERATOR RUN (STOP AT THE GATE)**  
**Core Principle**: Every number is derived from measured JSON files. Missing states are explicitly labeled **`MISSING`**. Zero hand-typed memory estimates.

---

## Section A: Executive Summary & Audit Matrix

Prompt R1 establishes a rigorous, empirical resource baseline for running Project GOKU on a 4 GB RAM laptop:
1. **Multi-Sample Win32 RAM Probe (`tools/ram_probe.py`)**: Rebuilt to capture system memory (total, available, used %, committed memory, and pagefile usage via Win32 `GlobalMemoryStatusEx`) and process memory (RSS and USS via `psutil memory_full_info`). Detects Ollama daemon and Ollama runner processes, explicitly reporting `RUNNER NOT FOUND` when absent. Samples 3 times, 5 seconds apart, computing min, median, and max.
2. **Interactive State Probe Wizard (`scripts/run_states.ps1`)**: In compliance with Rule 16, the agent shell does not execute GUI-interactive or system-idle states. A standalone PowerShell wizard guides the human operator step-by-step through states **S0** to **S4**.
3. **Empirical Resource Budget Compiler (`scripts/make_budget.py`)**: Reads the state JSON files and compiles [`docs/RESOURCE_BUDGET.json`](file:///c:/Users/Work/Downloads/GOKU/docs/RESOURCE_BUDGET.json) and [`docs/RESOURCE_BUDGET.md`](file:///c:/Users/Work/Downloads/GOKU/docs/RESOURCE_BUDGET.md). Computes incremental memory for GOKU python (S1 - S0), Ollama runner (S2 - S1), inference peak (S3 - S2), and Chrome (S4 - S2). Any unmeasured state prints `MISSING`.
4. **Dynamic Readiness Evaluator (`tools/readiness.py`)**: Evaluates `READY`, `DEGRADED`, `NOT_READY`, or `UNKNOWN`. Computes dynamic threshold as `needed_available_mb = measured_s3_peak_increment + config.settings.RAM_MARGIN_MB` with zero hardcoded constants. When S3 peak is unmeasured, returns `UNKNOWN`.
5. **GOKU Mode Architecture (`GOKU_MODE=dev|run`)**: Configured in a single place ([`config/settings.py`](file:///c:/Users/Work/Downloads/GOKU/config/settings.py)). `dev` mode completely disables model loading, network calls, GUI actuation, and screenshots. `run` mode gates model execution strictly on readiness (`READY` or `DEGRADED`).
6. **Ollama Low-RAM Configuration Guide (`docs/OLLAMA_LOWRAM.md`)**: Documents `OLLAMA_MAX_LOADED_MODELS=1`, `OLLAMA_NUM_PARALLEL=1`, and the exact `file:line` locations of `keep_alive`, `num_ctx`, and `num_predict` throughout the codebase.

---

## Section B: Measured System Telemetry & States S0–S4 Status

### B.1 States S0 to S4 Audit Matrix
| State ID | Description | Source JSON File | Measurement Status | Available RAM (Median) | GOKU Python RSS | Ollama Runner Status |
| :--- | :--- | :--- | :---: | :---: | :---: | :---: |
| **S0** | Idle baseline (IDE, Chrome, GOKU closed) | `reports/ram_S0_idle_no_goku.json` | **MISSING (Pending User Run)** | `MISSING` | `MISSING` | `MISSING` |
| **S1** | GOKU Python loaded (Router imported, model NOT loaded) | [`reports/ram_S1_goku_loaded.json`](file:///c:/Users/Work/Downloads/GOKU/reports/ram_S1_goku_loaded.json) | **MEASURED [COMPLETE]** | **512.30 MB** | **46.50 MB** | **RUNNER NOT FOUND** |
| **S2** | Model loaded idle (Warmup done, keep_alive active) | `reports/ram_S2_model_loaded_idle.json` | **MISSING (Pending User Run)** | `MISSING` | `MISSING` | `MISSING` |
| **S3** | Model inferring (Active generation in progress) | `reports/ram_S3_model_inferring.json` | **MISSING (Pending User Run)** | `MISSING` | `MISSING` | `MISSING` |
| **S4** | With Chrome (S2 Model resident + 1 Chrome window) | `reports/ram_S4_with_chrome.json` | **MISSING (Pending User Run)** | `MISSING` | `MISSING` | `MISSING` |

### B.2 Live Telemetry Measured for State S1
Captured via `python tools/ram_probe.py --state S1_goku_loaded` (median of 3 samples):
- **Total Physical RAM**: **3,977.05 MB [MEASURED]**
- **Available RAM**: **512.30 MB [MEASURED]** (87.0% memory load with IDE open)
- **Committed Memory**: **8,325.87 MB [MEASURED]** (Commit Limit: 12,169.05 MB)
- **Pagefile Usage**: **4,861.12 MB [MEASURED]** (Pagefile Total: 8,192.00 MB)
- **GOKU Python Memory**:
  - Resident Set Size (RSS): **46.50 MB [MEASURED]**
  - Unique Set Size (USS / Private Working Set): **32.50 MB [MEASURED]**
- **Ollama Runner**: **`RUNNER NOT FOUND` [MEASURED]** (Daemon: inactive)
- **Chrome Processes**: 7 active processes totaling 219.90 MB RSS (81.10 MB USS)
- **IDE Processes**: 14 active processes totaling 988.60 MB RSS (764.80 MB USS)

---

## Section C: Empirical Resource Budget & Increments

Compiled via [`scripts/make_budget.py`](file:///c:/Users/Work/Downloads/GOKU/scripts/make_budget.py) into [`docs/RESOURCE_BUDGET.md`](file:///c:/Users/Work/Downloads/GOKU/docs/RESOURCE_BUDGET.md) and [`docs/RESOURCE_BUDGET.json`](file:///c:/Users/Work/Downloads/GOKU/docs/RESOURCE_BUDGET.json):

| Metric / Transition | Formula | Measured Component Value | Measured Available RAM Delta | Status |
| :--- | :--- | :---: | :---: | :---: |
| **GOKU Python Overhead** | S1 - S0 | `MISSING` (S0 missing) | `MISSING` (S0 missing) | **PENDING S0** |
| **Ollama Runner Increment** | S2 - S1 | `MISSING` (S2 missing) | `MISSING` (S2 missing) | **PENDING S2** |
| **Inference Peak Increment** | S3 - S2 | `MISSING` (S3 missing) | `MISSING` (S3 missing) | **PENDING S3** |
| **Chrome Browser Increment** | S4 - S2 | `MISSING` (S4 missing) | `MISSING` (S4 missing) | **PENDING S4** |

All missing values will be automatically populated once the human operator completes the steps in `scripts/run_states.ps1`.

---

## Section D: Dynamic Readiness Evaluator (`tools/readiness.py`)

### D.1 Dynamic Threshold Calculation
- Threshold formula:
  $$\text{Needed Available RAM (MB)} = \text{Inference Peak Drop (S3)} + \text{Safety Margin (150.0 MB)}$$
- Constant avoidance: Zero memory thresholds are hardcoded in code. The threshold is read directly from `docs/RESOURCE_BUDGET.json` (or defaults to `UNKNOWN` if S3 is unmeasured).

### D.2 Live Execution Output
Executed via `python tools/readiness.py`:
```text
================================================================================
 GOKU SYSTEM READINESS CHECK
================================================================================
Verdict:              UNKNOWN
Total Physical RAM:   3977.05 MB
Available RAM:        456.55 MB
Required Threshold:   UNKNOWN (docs/RESOURCE_BUDGET.json incomplete)
IDE Running:          True
Chrome Running:       True
Reason:               docs/RESOURCE_BUDGET.json is incomplete (State S3 peak increment is MISSING). Run scripts/run_states.ps1.
--------------------------------------------------------------------------------
Top 5 Memory Consuming Processes (Read-Only):
  1. Antigravity IDE.exe       (PID: 5132  ) -> 516.67 MB
  2. Antigravity IDE.exe       (PID: 8772  ) -> 223.53 MB
  3. language_server_windows_x64.exe (PID: 12236 ) -> 201.69 MB
  4. MsMpEng.exe               (PID: 4168  ) -> 172.30 MB
  5. pyrefly.exe               (PID: 9776  ) -> 161.45 MB
================================================================================
```

---

## Section E: GOKU Modes Architecture & Model Call Wiring

### E.1 Configuration Consolidation ([`config/settings.py`](file:///c:/Users/Work/Downloads/GOKU/config/settings.py))
- Reads `GOKU_MODE = os.environ.get("GOKU_MODE", "dev").lower()` in a single authoritative location.
- Defaults strictly to `dev`.
- Defines `is_model_call_allowed() -> tuple[bool, str]`.

### E.2 Mode Behavior Rules
- **`dev` Mode (Default)**:
  - LLM disabled: `ask_llm`, `ask_conversational_llm`, `ask_structured_output_llm` return immediate block messages.
  - Zero model loads: `ensure_ollama_ready` returns `False` immediately without spawning processes or testing connections.
  - Micro-prompt generation in `time_sliced_orchestrator.py` skips HTTP request.
  - GUI actions disabled: `click_mouse`, `type_text`, `press_hotkey`, `move_mouse` return error without actuating.
  - Screenshots disabled: `take_screenshot` returns error without accessing display buffers.
- **`run` Mode**:
  - Invocations permitted only if `tools/readiness.py` evaluates system as `READY` or `DEGRADED`.
  - If `NOT_READY` or `UNKNOWN`, execution is blocked and the operator is advised which heavy applications to close.

### E.3 Unit Test Verification ([`tests/test_goku_mode_dev.py`](file:///c:/Users/Work/Downloads/GOKU/tests/test_goku_mode_dev.py))
Validated with mock HTTP transport assertions:
```text
tests/test_goku_mode_dev.py::test_goku_mode_dev_setting_read_in_one_place PASSED         [ 25%]
tests/test_goku_mode_dev.py::test_dev_mode_makes_zero_ollama_calls PASSED               [ 50%]
tests/test_goku_mode_dev.py::test_dev_mode_disables_screenshots_and_gui PASSED         [ 75%]
tests/test_goku_mode_dev.py::test_run_mode_checks_readiness PASSED                     [100%]
4 passed in 0.92s
```

---

## Section F: Ollama Low-RAM Settings & Request Options Provenance

Documented in [`docs/OLLAMA_LOWRAM.md`](file:///c:/Users/Work/Downloads/GOKU/docs/OLLAMA_LOWRAM.md):

### F.1 Concurrency Caps
- `OLLAMA_MAX_LOADED_MODELS=1`: Restricts resident models to 1.
- `OLLAMA_NUM_PARALLEL=1`: Restricts concurrent generation slots to 1.

### F.2 Exact Request Option Locations in GOKU Codebase
1. **`keep_alive`**:
   - `brain/llm.py:522` (`"keep_alive": "5m"`)
   - `brain/llm.py:665` (`"keep_alive": "5m"`)
   - `brain/llm.py:727` (`"keep_alive": "5m"`)
2. **`num_ctx`**:
   - `training/Modelfile.goku:5` (`PARAMETER num_ctx 2048`)
   - `brain/llm.py:519` (`"num_ctx": 2048`)
   - `brain/llm.py:662` (`"num_ctx": 2048`)
   - `brain/llm.py:724` (`"num_ctx": 2048`)
   - `tools/documents.py:1000` (`"num_ctx": 2048`)
3. **`num_predict`**:
   - `brain/time_sliced_orchestrator.py:505` (`"num_predict": 60`)
   - `brain/llm.py:723` (`"num_predict": 128`)
   - `tools/documents.py:1001` (`"num_predict": 160`)
   - `brain/llm.py:518` (`"num_predict": 256`)
   - `brain/llm.py:661` (`"num_predict": 256`)

---

## Roman Urdu Khulasa (Mandatory Rule 15)

1. Prompt R1 ke tehat memory ke tamam guessed numbers ko real measured data se replace karne ka structure tayyar kar diya gaya hai.
2. `tools/ram_probe.py` ab Win32 API ke zariye Total RAM, Available RAM, Committed Memory, aur Pagefile Usage measure karta hai aur Ollama runner na milne par `RUNNER NOT FOUND` print karta hai.
3. Rule 16 ke tehat agent shell se GUI aur idle states (S0, S2, S3, S4) nahi chalaye gaye; user ke liye standalone PowerShell script `scripts/run_states.ps1` likh diya gaya hai jo step-by-step guide karta hai.
4. `tools/readiness.py` dynamic threshold use karta hai (`S3 peak + margin`) jo `docs/RESOURCE_BUDGET.json` se compute hota hai, code mein koi constant hardcode nahi hai; JSON na hone par status `UNKNOWN` rehta hai.
5. `GOKU_MODE=dev` default set kar diya gaya hai jisme LLM, model loading, GUI, aur screenshots mukammal band hain; unit tests ne verify kiya hai ke dev mode mein zero HTTP calls hoti hain.

---

## RULE 26 GATE STOP NOTICE

> [!IMPORTANT]
> **GATE HALT: OPERATOR ACTION REQUIRED**
> 
> To complete the resource budget measurements across states S0, S2, S3, and S4 without agent desktop interference (Rule 16), please run the interactive wizard in a standalone PowerShell window:
> 
> ```powershell
> .\scripts\run_states.ps1
> ```
> 
> Once completed, all states will be logged to `reports/ram_*.json` and [`docs/RESOURCE_BUDGET.md`](file:///c:/Users/Work/Downloads/GOKU/docs/RESOURCE_BUDGET.md) will be automatically compiled.
