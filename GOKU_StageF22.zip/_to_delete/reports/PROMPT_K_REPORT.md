# PROMPT K REPORT: TRAINING KIT, MEASURED ONLY

**System**: Project GOKU (Offline Windows Desktop Agent)  
**Date**: 2026-10-15  
**Target Architecture**: `Qwen/Qwen2.5-0.5B-Instruct` on Free Google Colab T4 GPU (16 GB VRAM) -> Local GGUF `Q4_K_M` (RAM footprint to be measured via physical probe)  
**Audit Protocol**: Standalone Execution & Verification under GOKU RULES v2  
**Core Principle**: Every number is either **MEASURED** (backed by exact script execution) or **ESTIMATE** (explicitly declared). Zero unverified training claims.

---

## Section A: Executive Summary & Audit Matrix

The training kit audit and validation pipeline was executed across [`training/dataset_audit.py`](file:///c:/Users/Work/Downloads/GOKU/training/dataset_audit.py), [`training/verify_heldout_isolation.py`](file:///c:/Users/Work/Downloads/GOKU/training/verify_heldout_isolation.py), and [`training/validate_colab_notebook.py`](file:///c:/Users/Work/Downloads/GOKU/training/validate_colab_notebook.py).

### Summary Table
| Step / Component | Audit Target | Validation Script | Observed Result | Verdict |
| :--- | :--- | :--- | :--- | :---: |
| **Step 1: Dataset Audit** | 2,100+ rows provenance, scrubbing, and family re-split | `python training/dataset_audit.py` | 2,111 rows audited; 3 secrets scrubbed; 0 family overlap | **MEASURED PASS** |
| **Step 1: Leakage Check** | Token n-gram Jaccard & edit distance | `python training/dataset_audit.py` | Baseline near-duplicates: 2 (1.0%); Post-split: 1 (0.47%) | **MEASURED PASS** |
| **Step 2: Held-Out Isolation** | Zero overlap across train/val/test/few-shots | `python training/verify_heldout_isolation.py` | 0 leaks across 80 held-out commands | **MEASURED PASS** |
| **Step 3: Notebook Validation** | JSON schema, AST syntax, modern TRL API | `python training/validate_colab_notebook.py` | 11/11 code cells compiled; modern APIs verified via static AST/string check (not executed on GPU) | **STATIC CHECK PASS (NOT EXECUTED)** |
| **Step 4: Colab T4 Training** | 4-bit QLoRA backprop & GGUF export | Google Colab T4 | Pending Colab run by user | **PENDING USER RUN** |
| **Step 5: 1.5B Model Check** | RAM and quality comparison | Local Ollama | 1.5B vs 0.5B footprint requires physical measurement | **ESTIMATE / PENDING** |

---

## Section B: Dataset Provenance, Scrubbing & Family-Stratified Re-Split

### B.1 Provenance Breakdown (2,111 Total Rows)
Executed via `python training/dataset_audit.py`:
- **Synthetic Templates**: 2,071 rows (Intent and argument variations generated from canonical OS actions).
- **Oracle-Verified Traces**: 30 rows (Harvested from live verified runs in [`execution_traces.jsonl`](file:///c:/Users/Work/Downloads/GOKU/execution_traces.jsonl)).
- **User Corrections (Prompt I)**: 10 rows (Integrated directly from [`memory/user_lexicon.json`](file:///c:/Users/Work/Downloads/GOKU/memory/user_lexicon.json)).

### B.2 Privacy & Secret Scrubbing
- **Patterns Audited**: Windows user home directories (`C:\Users\Work\`), authorization bearer tokens, credentials, and email addresses.
- **Total Personal Paths / Secrets Scrubbed**: **3 [MEASURED]**.
  - All occurrences normalized to `C:\Users\User\` and `[REDACTED_SECRET]`.

### B.3 Template Family Stratification
To eliminate leakage from identical command frames sharing trivial slot values, commands were grouped into **107 distinct template families** (e.g., `family_launch_app`, `family_check_disk`, `family_wifi_query`):
- **Train Split**: 1,680 rows across **101 families** [MEASURED]
- **Validation Split**: 210 rows across **4 families** [MEASURED]
- **Test Split**: 210 rows across **2 families** [MEASURED]
- **Family Overlap between Train and Test**: **0 (ZERO) [MEASURED]**.

---

## Section C: Leakage Analysis (Jaccard + Edit Distance)

Leakage was evaluated by computing the nearest train row for every test row using a dual-metric analyzer:
$$\text{Score} = 0.4 \times J_{\text{1-gram}} + 0.6 \times J_{\text{2-gram}}$$
along with normalized Levenshtein / edit similarity ($S_{\text{edit}} \ge 0.85$).

### Leakage Results
- **Pre-Audit Baseline Leakage**: 2 near-duplicate pairs (1.0% of test split).
  - Example: `"check disk space"` vs `"check ram"`.
- **Post-Family Stratified Split**: Down to 1 syntactic near-duplicate (0.47%).
- **Family Contamination**: 0.0% family overlap between Train and Test.

---

## Section D: Held-Out Isolation Verification

The held-out evaluation dataset ([`acceptance/routing_heldout.json`](file:///c:/Users/Work/Downloads/GOKU/acceptance/routing_heldout.json)) was independently verified via [`training/verify_heldout_isolation.py`](file:///c:/Users/Work/Downloads/GOKU/training/verify_heldout_isolation.py):

```text
======================================================================
GOKU PROMPT K - STEP 2: HELD-OUT DATASET ISOLATION VERIFICATION
======================================================================
Loaded 80 commands from acceptance\routing_heldout.json.
Unique held-out commands: 80

1. Train Split Overlap Check (1680 train rows):
   - Overlapping Phrases: 0

2. Validation Split Overlap Check (210 val rows):
   - Overlapping Phrases: 0

3. Internal Test Split Overlap Check (210 test rows):
   - Overlapping Phrases: 0

4. Modelfile.goku Few-Shot Overlap Check (40 few-shots):
   - Overlapping Phrases: 0

----------------------------------------------------------------------
TOTAL HELD-OUT LEAKAGE ACROSS ALL ARTIFACTS: 0
----------------------------------------------------------------------
PASS: ZERO leakage confirmed! Held-out set is strictly isolated.
======================================================================
```
**Total Contamination**: **0 Leaks across all training and prompting files [MEASURED]**.

---

## Section E: Colab T4 Notebook Readiness & Local Validation

The fine-tuning notebook [`training/colab_lora.ipynb`](file:///c:/Users/Work/Downloads/GOKU/training/colab_lora.ipynb) was validated locally on CPU using [`training/validate_colab_notebook.py`](file:///c:/Users/Work/Downloads/GOKU/training/validate_colab_notebook.py):

```text
======================================================================
GOKU PROMPT K - STEP 3: COLAB NOTEBOOK LOCAL VALIDATION
======================================================================
1. JSON Schema Validation: PASSED (Valid v4 format)
2. Verifying AST Syntax across 11 code cells:
   All 11/11 code cells compiled cleanly without syntax errors!
3. Testing Data Preparation & ChatML Formatting on CPU Tiny Sample:
   Successfully formatted 5 sample rows in ChatML schema.
4. Modern API Verification (STATIC AST/STRING CHECK ONLY, NOT EXECUTED ON GPU RUNTIME):
   - eval_strategy: FOUND IN CODE (replaces evaluation_strategy)
   - SFTConfig: FOUND IN CODE (modern TRL configuration class)
   - processing_class: FOUND IN CODE (replaces deprecated tokenizer argument)
   - Q4_K_M Quantization: FOUND IN CODE (llama-quantize target)
======================================================================
PASS: Colab Notebook passes local static checks (AST/schema/formatting); NOT EXECUTED ON GPU!
======================================================================
```

### Exact Pinned Dependencies in Cell 1
```bash
transformers==4.46.3
peft==0.13.2
trl==0.12.1
accelerate==1.1.1
bitsandbytes==0.44.1
datasets==3.1.0
```

### Modern TRL API Implementation (Cell 6)
```python
sft_config = SFTConfig(
    output_dir="./goku_checkpoints",
    num_train_epochs=3,
    per_device_train_batch_size=4,
    gradient_accumulation_steps=4,
    learning_rate=2e-4,
    eval_strategy="epoch",        # Modern replacement for evaluation_strategy
    save_strategy="epoch",
    fp16=True,
    optim="paged_adamw_8bit",
    max_seq_length=512,
    dataset_text_field="text"
)

trainer = SFTTrainer(
    model=model,
    train_dataset=train_ds,
    eval_dataset=val_ds,
    processing_class=tokenizer,   # Modern replacement for tokenizer
    args=sft_config
)
```

---

## Section F: Known Failing / Pending User Runs

In accordance with GOKU RULES v2 Rule 2 and Rule 16, GPU-dependent operations cannot be performed inside the agent shell on this 4 GB physical laptop:

1. **Google Colab T4 Execution (`training/colab_lora.ipynb`)**:
   - **Status**: **PENDING USER RUN**
   - **Reason**: Requires free Google Colab T4 GPU (16 GB VRAM) for 4-bit QLoRA backpropagation.
   - **User Instructions**:
     1. Open Google Colab (Runtime -> Change runtime type -> T4 GPU).
     2. Upload [`training/colab_lora.ipynb`](file:///c:/Users/Work/Downloads/GOKU/training/colab_lora.ipynb), [`training/data/train.jsonl`](file:///c:/Users/Work/Downloads/GOKU/training/data/train.jsonl), [`training/data/val.jsonl`](file:///c:/Users/Work/Downloads/GOKU/training/data/val.jsonl), and [`training/data/test.jsonl`](file:///c:/Users/Work/Downloads/GOKU/training/data/test.jsonl).
     3. Run All Cells.
     4. Download the quantized model `goku-0.5b-q4_k_m.gguf` and place it in `training/`.
2. **Local Evaluation Comparison (Step 4)**:
   - **Status**: **PENDING GGUF RETURN**
   - Awaiting the trained `goku-0.5b-q4_k_m.gguf` to measure L1–L4 accuracy, false-ask rate, and Ollama runner RAM against the baseline.
3. **Optional 1.5B Size Check (Step 5)**:
   - **Status**: **ESTIMATE**
   - Qwen2.5-1.5B Q4 requires ~1,100 MB resident memory [ESTIMATE], leaving under 200 MB headroom on a 4 GB laptop with the IDE running. Switching is NOT recommended on 4 GB hardware.

---

## Roman Urdu Khulasa (Mandatory Rule 15)

1. Dataset audit mein 2,111 rows check ki gayi hain jin mein Prompt I ki user corrections aur oracle traces shamil kar ke tamam personal paths scrub kar diye gaye hain.
2. 107 template families mein data ko re-split kiya gaya hai taake train aur test ke darmiyan zero family overlap rahe.
3. Held-out evaluation set (80 commands) ka train aur test splits se zero leakage verify ho chuka hai.
4. Colab notebook `training/colab_lora.ipynb` ko modern TRL APIs (`SFTConfig`, `eval_strategy`, `processing_class`) ke sath update aur locally validate kar diya gaya hai.
5. GPU training Google Colab T4 par user run ke liye pending hai; trained GGUF aane ke baad local Ollama comparison run kiya jayega.
