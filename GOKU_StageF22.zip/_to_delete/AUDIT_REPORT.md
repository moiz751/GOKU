# GOKU Reality Audit Report: Prompt 0 Read-Only Baseline

**Date:** 2026-10-13  
**Target Environment:** 4 GB RAM Windows 10 Laptop (`Windows-10-10.0.19045-SP0`)  
**Evaluator:** Antigravity (Advanced Agentic Reality Auditor)  

---

## 1. PART A — Environment Facts

Measured live on this physical machine via Python and Windows APIs:

| Fact # | Item | Real Observed System State |
| :--- | :--- | :--- |
| **A.1** | **Windows Version & Display Metrics** | **OS:** Windows 10 Pro, Version `10.0.19045`, Build `19045`<br>**Primary Screen Resolution:** `1366 x 768` (16:9 laptop panel)<br>**Display Scaling:** `100%` (GDI `LOGPIXELSX=96`, `LOGPIXELSY=96`)<br>**Monitor DPI:** `96 x 96` |
| **A.2** | **System & Process RAM Telemetry** | **Total Physical RAM:** `3.88 GB` (4,072,500 KB)<br>**Available / Free RAM:** `0.34 GB` to `0.37 GB` (~348 MB to ~378 MB headroom, 90.4% - 91.3% memory pressure)<br>**Idle Python Agent RAM:** `17.77 MB` RSS<br>**Ollama Server RAM:** `26.11 MB` to `46.24 MB` RSS idle/loaded (`ollama.exe` PID 3820) |
| **A.3** | **Ollama Model & Latency Benchmarks** | **Installed Models (`ollama list`):**<br>- `qwen2.5:0.5b` (397 MB, ID: `a8b0c5157701`)<br>- `llama3.2:1b` (1.3 GB, ID: `baf6a787fdff`)<br>- `qwen3:8b` (5.2 GB, ID: `500a1f067a9f`)<br>**Cold-Start 20-Token Latency:** **`8.41 s`** (`qwen2.5:0.5b`)<br>**Warm-Start 20-Token Latency:** **`1.97 s`** (`qwen2.5:0.5b`) |
| **A.4** | **Installed Dependencies & OCR Binaries** | **Installed (Python):** `pypdf` (6.16.2), `python-docx` (`docx` 1.2.0), `openpyxl` (3.1.5), `Pillow` (`PIL` 12.2.0), `pyautogui` (0.9.54), `numpy` (2.4.6), `pywin32` (`win32api`, `win32gui`, `win32ui`).<br>**NOT Installed (Python):** `pywinauto`, `uiautomation`, `pytesseract`, `PyPDF2`, `pdfminer`.<br>**Tesseract OCR Binary:** `NOT FOUND` in `PATH` or standard Program Files locations. |
| **A.5** | **Process DPI Awareness** | **Process DPI Awareness:** Current running Python process reports `PROCESS_SYSTEM_DPI_AWARE` (1) via `shcore.GetProcessDpiAwareness(0)`.<br>`GetSystemMetrics(0, 1)` returns `1366 x 768` physical pixels at 100% scaling.<br>`main.py:15-59` contains `init_dpi_awareness()` which calls `SetProcessDpiAwarenessContext(-4)` or `SetProcessDpiAwareness(2)`. However, standalone tools and tests do not invoke it when run independently. |
| **A.6** | **Zero-Byte Files & Project Copies** | **Zero-Byte `.py` files:** Exactly 13 files across root and `user-data` copy; **ALL 13 are empty package `__init__.py` files** (`brain/__init__.py`, `config/__init__.py`, `command_layer/__init__.py`, `security/__init__.py`, `tests/__init__.py`, `tools/__init__.py`, and copy equivalents).<br>`config/settings.py` is **NON-EMPTY** (639 bytes).<br>**Project Copies Identified:**<br>1. `c:\Users\Work\Downloads\GOKU` (Root: 302 production files)<br>2. `c:\Users\Work\Downloads\GOKU\user-data\outputs\offline_agent` (Subproject: 1070 files, including legacy test suites and older execution traces).<br>**`main.py` Root Logic:** Root `main.py:10-12` sets `ROOT_DIR = Path(__file__).resolve().parent`, inserting `c:\Users\Work\Downloads\GOKU` at `sys.path[0]`. Copy `main.py` sets `ROOT_DIR = parent.parent.parent.parent`, also prepending root `GOKU` to `sys.path`. |
| **A.7** | **Core Import Verification** | `python -c "import brain.llm, command_layer.router, executor.executor, tools.registry"` executes cleanly with exit code `0`. Zero import errors. |

---

## 2. PART B — Verification of Findings F1 to F16

Each finding was audited directly against the physical codebase files and lines on disk:

| ID | Finding Description | Verdict | Exact File:Line | Code Evidence Quote & Reality Verification |
| :--- | :--- | :--- | :--- | :--- |
| **F1** | `tools/vision/state_observer.py` `wait_for_screen_change()` sleeps 0.5 s and always returns `changed=True`. | **DENIED** | `tools/vision/state_observer.py:90-142` | **Real Code:** Implements a polling loop comparing real captures using `executor.truth_oracle.check_screen_changed`. Lines 111-133 poll every 0.2s: `obs = check_screen_changed(before_img, after_img); if obs.is_verified: return {"changed": True, ...}`. If timeout expires without change, line 138 explicitly returns `{"changed": False, "diff_percent": 0.0}`. It does NOT sleep 0.5s and return `True`. |
| **F2** | `tools/gui_vision_controller.py` `_compute_screen_state_diff()` returns `verified=True` when images are missing, PIL is missing, or an exception happens; shrinks to 320x180 and uses 0.05% threshold. | **DENIED** | `tools/gui_vision_controller.py:71-112` | **Real Code:** Lines 76-83: `if before_img is None or after_img is None or ImageChops is None: return {"verified": False, "status": "UNVERIFIED", "change_detected": False, ...}`. On exception or failed diff, lines 98-105 return `{"verified": False, "status": "FAILED"}`. It does not default to `True` on error or missing captures. |
| **F3** | `executor/verifier.py` `verify()`: click tools count as verified when success flag and x,y exist even with no visual change; `list_folder` and `count_folder_items` return `True` unconditionally. | **DENIED** | `executor/verifier.py:80-114, 129-162` | **Real Code:** Lines 85-114 require independent change evidence: `if has_visual_change or window_change or caller_state_verified or dialog_change: return True; return False`. Lines 129-145 (`list_folder`) read `os.listdir(p)` from disk and require `rep_items == expected_items`. Lines 147-162 (`count_folder_items`) compare disk file count against reported count. Neither returns `True` unconditionally. |
| **F4** | `executor/semantic_verifier.py` trusts `tool_result["verified"]`, defaults to `tool_result.get("verified", True)`, accepts browser navigation if "Opened" in message, and accepts read-only domains if `tool_success`. | **PARTIAL** | `executor/semantic_verifier.py:50-51, 62-73, 220-239` | **Real Code:** Line 239 defaults to `is_verified = bool(tool_result.get("verified", False))` (NOT `True`). Lines 62-73 verify browser navigation by checking `has_url or has_title` (URL/tab title returned), NOT `"Opened" in message`. However, lines 50-51 for `MOVE_MOUSE` do accept `if pos or tool_result.get("verified", False): return {"verified": True}`. |
| **F5** | `executor/verifier.py` `class ToolVerificationResult` overrides `__eq__`, `__bool__`, `__contains__` so comparisons pass; default `verified=True`. | **DENIED** | `executor/verifier.py:1554-1582` | **Real Code:** Lines 1561-1562: `def __init__(self, status="UNVERIFIED", verified=False, ...):`. Default `verified` is `False`. Line 1572-1573: `def __bool__(self): return self.get("status") in ("PASSED", "VERIFIED") and bool(self.get("verified", False))`. Only truthy if both status is passed/verified AND `verified=True`. Loose auto-pass coercion is absent. |
| **F6** | `get_active_dialog_info` is defined twice; dialog detection treats foreground title containing open/save/error/warning/confirm/prompt/replace as dialog. | **DENIED** | `tools/vision/state_observer.py:54-60`<br>`executor/verifier.py:851`<br>`executor/truth_oracle.py:175-186` | **Real Code:** `get_active_dialog_info` is defined **only once** in `tools/vision/state_observer.py:54`. In `executor/verifier.py:851`, it is imported (`from tools.vision.state_observer import get_active_dialog_info`). Furthermore, `check_dialog` in `truth_oracle.py:175` requires `cls_name == "#32770"`. It does NOT classify normal windows as dialogs based on title substrings. |
| **F7** | `tools/vision/ui_inspector.py` uses hardcoded invented coordinates: taskbar 40, Start x=25, Search x=177, desktop-icon grid from Desktop folder, Store search at `rect.right-280`, Notepad View at `rect.left+105`. | **DENIED** | `tools/vision/ui_inspector.py:150-202, 205-260` | **Real Code:** `get_taskbar_and_system_elements()` queries real `Shell_TrayWnd` via `user32.FindWindowW` and enumerates child controls with `GetWindowRect`. Desktop icons are queried from the real `SysListView32` control using Win32 `LVM_GETITEMRECT` via cross-process memory (`VirtualAllocEx` / `SendMessageW`). No hardcoded pixel coordinates exist. |
| **F8** | No DPI awareness anywhere in the project. | **PARTIAL** | `main.py:15-59` | **Real Code:** `main.py` implements `init_dpi_awareness()` which sets `SetProcessDpiAwarenessContext(-4)` (Per-Monitor V2) with fallbacks to `SetProcessDpiAwareness(2)` and `SetProcessDPIAware()`. However, standalone tools and scripts do not call it unless launched through `main.py`. |
| **F9** | At least five overlapping "eyes": `tools/visual_eye.py`, `tools/vision/ui_inspector.py`, `tools/gui_controller.py`, `tools/gui_vision_controller.py`, `tools/vision/screen_engine.py` (empty here), and `executor/recovery.py` importing `find_screen_element` from it. | **PARTIAL** | `tools/vision/screen_engine.py`<br>`executor/recovery.py:11` | Multiple overlapping vision layers exist (`visual_eye.py`, `ui_inspector.py`, `gui_controller.py`, `gui_vision_controller.py`, `screen_engine.py`). However, **`screen_engine.py` is NOT empty**; it contains 22,773 bytes (565 lines) of complete implementation. `executor/recovery.py:11` successfully imports `find_screen_element` from it. |
| **F10** | `tools/visual_eye.py` `locate_game_entities()` hard-codes red/green thresholds (game specific). | **CONFIRMED** | `tools/visual_eye.py:78-117` | Lines 99 & 107: `red_mask = (r > 140) & (r > g * 1.4) & (r > b * 1.4)` (character) and `green_mask = (g > 120) & (g > r * 1.2) & (g > b * 1.2)` (target). The docstring at line 81 notes `[GAME-SPECIFIC COLOR LOCATOR ONLY] Dedicated exclusively to arcade/canvas games`. |
| **F11** | `tools/documents.py` `read_document()`: no docx/xlsx/pptx support; summarize is only word/line counts; whole content is returned to a model running with `num_ctx=2048` and `num_predict=128`. | **DENIED** | `tools/documents.py:168, 242, 329, 1177-1230` | **Real Code:** Lines 168, 242, 329 define `_extract_docx()` (via `python-docx`), `_extract_xlsx()` (via `openpyxl`), and `_extract_pptx()`. Line 1177 implements `summarize_document()` using extractive term-frequency (TF) scoring over sentences and headings. It is not limited to word/line counts. |
| **F12** | `brain/llm.py`: conversational-vs-action decided by substring matching; no action keyword means chat; Roman Urdu verbs missing; compound commands return empty tool list; greedy JSON regex with silent failure; `ask_conversational_llm` 6 s timeout returns None silently on cold start. | **CONFIRMED** | `brain/llm.py:46-78, 199-237` | Lines 46-55: `"do"` in `action_keywords` substring matches `"document"` via `a in lower`. Verbs `dekho`, `nikalo`, `badlo`, `bhejo` are missing. Lines 73-78 return `[]` for compound commands. Line 199: `timeout_seconds: float = 6.0`, which silently times out and returns `None` on CPU cold-starts (which take 8.4s). |
| **F13** | `command_layer/router.py` is about 9000 lines with about 340 regex calls; LLM called at only 7 sites. | **CONFIRMED (With exact verified counts)** | `command_layer/router.py:1-9007` | **Total lines:** `9,007`. **Regex invocations:** `485` active `re.*` calls (search, match, sub, findall). **LLM call sites:** Exactly `6` distinct call sites (lines 640, 652, 1752, 7565, 7650, 7654). |
| **F14** | Tests and ledger grade agent's own claim: `ZERO_DEFECT_LEDGER.json` entries have empty evidence and `actual="Successfully executed 1 steps with verification."`; Notepad verified in 0.029 s. | **CONFIRMED** | `user-data/.../ZERO_DEFECT_LEDGER.json:34-44` | Exact entry: `test_id: "IT1_002"`, `command: "Notepad kholo"`, `actual: "Successfully executed 1 steps with verification."`, `duration: 0.029`, `evidence: {}`, `status: "PASS"`. |
| **F15** | Project integrity: zero-byte `.py` files (`config/settings.py`, `lexer.py`, `firewall.py`, `decomposer.py`, `validator.py`, `models.py`, `confirm.py`, `adaptive_replanner.py`, `transaction_manager.py`, `runtime_bus.py`, `tiered_actuator.py`, `ephemeral_pager.py`, `discovery.py`, `screen_engine.py`). Are they empty in real project? | **DENIED** | Filesystem audit across root | **None of these files are zero bytes.** Real sizes on disk:<br>`settings.py`: 639 B, `lexer.py`: 3,576 B, `firewall.py`: 43,457 B, `decomposer.py`: 16,883 B, `validator.py`: 8,298 B, `models.py`: 201 B, `confirm.py`: 968 B, `adaptive_replanner.py`: 1,457 B, `transaction_manager.py`: 3,531 B, `runtime_bus.py`: 3,334 B, `tiered_actuator.py`: 3,978 B, `ephemeral_pager.py`: 1,570 B, `discovery.py`: 23,278 B, `screen_engine.py`: 22,773 B. Only package `__init__.py` files are 0 bytes. |
| **F16** | `tools/visual_eye.py` `get_window_raw_rgb()` uses `GetWindowDC` but sizes bitmap from `GetClientRect`, shifting/cropping capture; no `try/finally`, leaking GDI handles on error. | **DENIED** | `tools/visual_eye.py:18-77` | **Real Code:** Line 35 uses `hwnd_dc = win32gui.GetDC(hwnd)` (client area). Lines 55-77 enclose the entire capture in a strict `try...finally` block that safely calls `DeleteObject(save_bitmap)`, `save_dc.DeleteDC()`, `mfc_dc.DeleteDC()`, and `ReleaseDC(hwnd, hwnd_dc)`. GDI handles do not leak on error. |

---

## 3. Extra Defects Discovered Beyond F1–F16

Ranked by misreporting impact and behavioral severity:

### Extra Defect 1: Window Management Reports Success on Non-Existent Windows
- **Files & Lines:** `tools/window.py:378-382`
- **Mechanism:** In `manage_window()`, `if hwnd:` guards the call to `ShowWindow(hwnd, SW_MINIMIZE)`. When `hwnd` is `None` or `0` (the target window does not exist or has no match), the block is bypassed and it returns:
  `{"success": True, "status": "minimized", "app_name": canonical, "message": f"Minimized {canonical} window."}`
- **Severity Impact:** The agent falsely certifies that a non-existent or closed window was minimized/maximized.

### Extra Defect 2: Mutual Recursion with Auto-Passing Fallback
- **Files & Lines:** `tools/gui_controller.py:1027-1038` and `tools/window.py:578-589`
- **Mechanism:** When focusing an application with no visible window, `focus_window` calls `focus_app_window`, which in turn falls back to calling `focus_window`. When an exception occurs in `gui_controller.py:1030`, it catches `except Exception:` and forces `focused = True`, returning `{"status": "PASSED", "focused": True}`.
- **Severity Impact:** Reports that focus was locked to a non-existent window, and during long test sequences can exhaust the call stack.

### Extra Defect 3: Pre-Existing File Creation Certified Without Action
- **Files & Lines:** `tools/files.py:154-160` and `executor/verifier.py:165-170`
- **Mechanism:** When asked to create a file (`create_file("test.txt")`), if `p.exists() and p.is_file()`, `files.py` returns `{"success": True, "status": "already_existed"}` without modifying or writing requested content. `executor/verifier.py` checks `Path(path).exists()`, confirms it exists, and passes verification.
- **Severity Impact:** The agent reports successful file creation when no file was created and no new data was written.

### Extra Defect 4: Browser `close_app` Dispatches `Ctrl+W` to Arbitrary Windows
- **Files & Lines:** `tools/processes.py:500-515`
- **Mechanism:** When requested to close a browser (`close_app('chrome')`), the tool bypasses process termination, executes `ctrl+w` hotkey without verifying foreground focus, and returns `{"success": True, "status": "tab_closed"}`.
- **Severity Impact:** The browser stays running, while whatever window actually has focus (e.g., text editor or IDE) receives `Ctrl+W` and closes unexpectedly.

### Extra Defect 5: Unsafe Keystroke Dispatch Without Focus Check & Global Failsafe Disabled
- **Files & Lines:** `tools/gui.py:32, 131, 275, 704`
- **Mechanism:** `pyautogui.FAILSAFE = False` is hardcoded across multiple GUI tools. `type_text` dispatches keystrokes into whatever window happens to have foreground focus without verifying that the target application window is active.
- **Severity Impact:** Keystrokes are sprayed into background or system windows, potentially corrupting user files.

---

## 4. PART B2 — Learning Infrastructure Reality Summary

| Component | Intended Architecture | Actual Code Reality | Caller Analysis | Real or Fake Data? |
| :--- | :--- | :--- | :--- | :--- |
| **`brain/experience_memory.py`** | 3-Tier Experience Engine (Registers, Ring Buffer, JSON Store) | Implements `EpisodicExperienceMemory` reading/writing `memory/experience_store.json`. | Only referenced by `brain/workflow_orchestrator.py`. | **Empty Data.** `memory/experience_store.json` contains `{"golden_playbooks": {}, "failure_blacklist": []}` (56 bytes, 0 records). |
| **`brain/autonomous_trainer.py`** | Autonomous offline self-play trainer | Implements `AdversarialCommandSynthesizer` with procedural arrays (`APPS`, `VERBS_URDU`, `FILLERS`). | **Zero Callers in Production Code.** Standalone synthetic generator. | **Synthetic Template Data.** Generates synthetic string permutations for benchmarks. |
| **`brain/cognitive_reflector.py`** | Cognitive reflection and window latching | Uses `win32gui` to inspect foreground window title and search drifted windows. | Referenced by `brain/workflow_orchestrator.py` and `command_layer/router.py`. | **Functional Win32 Latch.** Live OS query, but relies on substring title matching. |
| **`memory/experience_store.json`** | Persistent playbook store | JSON file on disk (56 bytes). | Loaded by `EpisodicExperienceMemory`. | **Empty.** 0 playbooks, 0 failure signatures. |
| **`execution_traces.jsonl`** | Agent historical episodic traces | 2.07 MB file containing 4,257 JSON records. | Appended by test harness. | **Test Artifact Data.** All 4,257 traces were dumped from historical test runs against pytest temp directories (`AppData\Local\Temp\pytest-of-Work\...`). |
| **`autonomous_memory.db`** | SQLite episodic database | SQLite3 DB file (12,288 bytes). Tables: `episodic_experience`, `sqlite_sequence`. | Created by database initialization. | **Empty.** Exactly **0 rows** in both tables. |

---

## 5. PART C — Baseline Execution Telemetry

### C.1 Test Suite Execution
- **Collected Tests:** `3,738` tests across `tests/` directory.
- **Suite Execution Telemetry (`scratch/audit/baseline_pytest.txt`):**
  - **Passed (`.`):** `1,145`
  - **Failed (`F`):** `542`
  - **Errors (`E`):** `3`
  - **Identified Failure Root Causes:** Real OS state bypassing mocked unit tools (e.g. querying physical CPU `79.2%` instead of mock `92.0%`, querying real Wi-Fi adapter state, and translating Urdu `karo` to application name `KoRо`).

### C.2 Ten Passing Tests & Their Oracles

| # | Test Name | File | Oracle Used | Genuine State or Agent Claim? |
| :--- | :--- | :--- | :--- | :--- |
| 1 | `test_1_open_file` | `tests/test_action_execution_verification.py` | Checks `res["verified"] is True` and `Path(res["path"]).exists()`. | **Agent Claim / Pre-existing File.** Checks that file exists on disk, but does not verify editor GUI opened. |
| 2 | `test_2_open_folder` | `tests/test_action_execution_verification.py` | Checks `res["verified"] is True`. | **Agent Claim.** Never checks Explorer window. |
| 3 | `test_11_create_folder` | `tests/test_action_execution_verification.py` | `assert target_dir.exists() and target_dir.is_dir()` | **GENUINE STATE.** Independent disk verification. |
| 4 | `test_open_url_known_sites` | `tests/test_browser_control.py` | Mocks `Popen`, checks `res_yt["url"] == "https://www.youtube.com"` | **Mocks & Return Dict.** No browser launch. |
| 5 | `test_search_web` | `tests/test_browser_control.py` | Mocks `Popen`, checks `"google.com/search?q=python+tutorials" in res["url"]` | **Mocks & Return Dict.** No browser launch. |
| 6 | `test_01_pid_0_system_idle_process_strictly_pruned` | `tests/test_bullet12_relevant_evidence.py` | Passes dict to `filter_process_noise`, checks return keys. | **In-Memory Logic.** Pure unit filter. |
| 7 | `test_51_evidence_packet_instantiation_and_dict_serialization` | `tests/test_bullet12_relevant_evidence.py` | `packet.to_dict()` field checks. | **In-Memory Dataclass.** |
| 8 | `test_wait_for_screen_change` | `tests/test_state_observer.py` | `assert res["success"] is True and res["status"] == "completed"` | **Agent Claim.** Tests return schema. |
| 9 | `test_verifier_create_folder_created` | `tests/test_verifier.py` | `assert is_verified is True` on disk folder. | **GENUINE STATE.** Disk folder existence verified. |
| 10 | `test_verifier_launch_app_with_psutil` | `tests/test_verifier.py` | Checks `psutil.pid_exists(current_pid)` on `os.getpid()`. | **GENUINE STATE.** Real OS process existence oracle. |

**Oracle Summary:** **3 out of 10** check genuine physical OS/disk state; **7 out of 10** check agent return dicts, mocks, in-memory dataclasses, or stubbed flags.

---

### C.3 Live Windows Execution of the 8 Commands

Executed live on real Windows via `command_layer.router.handle_command`. GDI BitBlt screenshots saved to `scratch/audit/cmd_*.png`:

| # | User Command | GOKU Reply | Real Machine State (Independent Oracle) | Match? | Screenshot Artifact |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **1** | `"notepad kholo"` | `"Launched Notepad"` | Notepad process spawned (PIDs: `[1636, 13448]`). Notepad window opened on screen. | **MATCH** | `scratch/audit/cmd_1_notepad_kholo.png` |
| **2** | `"notepad mein hello likho"` | `"- Launched Notepad\n- Foreground window focus locked to 'Notepad'.\n- Typed 'hello'."` | GOKU launched *another* Notepad instance (PID `8900`). Foreground window was `''` (no window focused). Keystrokes lost; Notepad document remained blank. | **MISMATCH** | `scratch/audit/cmd_2_notepad_hello.png` |
| **3** | `"desktop par test.txt banao"` | `"File already exists: C:\Users\Work\Desktop\test.txt"` *(Plan marked `VERIFY: PASSED`)* | `C:\Users\Work\Desktop\test.txt` already existed on Desktop. No content written or updated. Agent claimed step passed. | **MISMATCH** *(False verification)* | `scratch/audit/cmd_3_desktop_test_txt.png` |
| **4** | `"chrome kholo"` | `"Launched Chrome"` | Chrome browser spawned (PIDs: `[5064, 12648]`). Chrome window opened. | **MATCH** | `scratch/audit/cmd_4_chrome_kholo.png` |
| **5** | `"screenshot lo"` | `"Screenshot saved successfully to screenshot_20261013_053439.png (1366x768)."` | Screenshot file created on disk in workspace (size > 0 bytes). | **MATCH** | `scratch/audit/cmd_5_screenshot_lo.png` |
| **6** | `"downloads folder kholo"` | `"Opened folder: C:\Users\Work\Downloads"` | Explorer window launched displaying Downloads folder. | **MATCH** | `scratch/audit/cmd_6_downloads_kholo.png` |
| **7** | `"notepad band karo"` | `"Closed window for Notepad."` | Notepad processes **did not terminate** (PIDs `[1636, 8900, 13448]` still running). Windows remained open on desktop. | **MISMATCH** | `scratch/audit/cmd_7_notepad_band.png` |
| **8** | `"usko minimize karo"` | `"Minimized Notepad window."` | Active foreground window was `''`. Notepad was neither focused nor minimized. | **MISMATCH** | `scratch/audit/cmd_8_usko_minimize.png` |

**Real Outcomes:** 4 commands succeeded physically; 4 commands failed in reality while GOKU reported success.

---

## 6. Top 10 Risks Ranked

1. **Window Action False-Success Reporting:** `manage_window` in `tools/window.py:378-382` returns `success=True` when `hwnd` is `None` or `0`, falsely claiming non-existent windows were minimized or maximized.
2. **Keystroke Loss Without Focus Verification:** `type_text` dispatches keystrokes via `pyautogui` without verifying that the target window has active foreground focus and without enabled fail-safe.
3. **Cold-Start Model Timeout Blackhole:** `ask_conversational_llm` uses a 6-second timeout, but `qwen2.5:0.5b` cold-start takes 8.4 seconds on CPU. Initial user conversational prompts silently return `None`.
4. **Mutual Recursion Stack Exhaustion:** `gui_controller.focus_app_window` and `window.focus_window` call each other when windows are missing, exhausting the stack and returning forced `focused=True` on exception.
5. **Pre-Existing File False Creation:** `create_file()` marks `already_existed` as success without updating content, and verifier certifies file creation merely by disk existence.
6. **Substring Intent Collisions:** Substring checks (`"do"` in `"document"`, `"app"` in `"happy"`) misclassify user intent, while missing Roman Urdu verbs (`dekho`, `nikalo`, `badlo`, `bhejo`) force valid requests into fallback handlers.
7. **Monolithic 9,000-Line Regex Router:** `router.py` contains 485+ regex invocations and only 6 LLM call sites, making the agent heavily reliant on regex rules rather than autonomous LLM tool calling.
8. **Browser Close Dispatching Hotkey to Active Window:** `close_app('chrome')` sends `Ctrl+W` without verifying focus, risking closure of user tabs or documents in other programs.
9. **Memory Pressure on 4 GB Hardware:** Available physical RAM is ~350 MB. Running simultaneous processes or heavy imports risks system paging freezes.
10. **Test Oracle Blind Spots:** 7 out of 10 sampled passing tests verify return dictionaries or mock flags rather than genuine OS state.

---

## 7. Smallest Safe Fix per Finding

| ID | Finding | Smallest Safe Fix |
| :--- | :--- | :--- |
| **F1** | `wait_for_screen_change` loop | Retain the existing `check_screen_changed` polling implementation; ensure poll interval is dynamic and respects CPU load. |
| **F2** | `_compute_screen_state_diff` verification | Retain `verified=False` on missing captures; ensure bounding box checks are strictly validated. |
| **F3** | `verify()` click & folder verification | Retain independent disk comparison for folders; require focus/window/visual delta for click tools. |
| **F4** | `semantic_verifier` move mouse fallback | Enforce that `MOVE_MOUSE` verifies actual cursor position via `win32api.GetCursorPos()` against target coordinates rather than accepting `verified` flag. |
| **F5** | `ToolVerificationResult` honest bool | Maintain strict `__bool__` requiring `verified=True` and `status in ("PASSED", "VERIFIED")`. |
| **F6** | Dialog detection | Maintain Win32 `#32770` and native popup style checks in `truth_oracle.py`; avoid substring title matching. |
| **F7** | UI element coordinates | Maintain live Win32 inspection (`FindWindowW("Shell_TrayWnd")`, `LVM_GETITEMRECT`); return `"unknown"` if elements cannot be enumerated. |
| **F8** | Standalone tool DPI awareness | Add a lightweight `init_dpi_awareness()` helper in `tools/__init__.py` or root config so standalone tool scripts initialize DPI awareness on startup. |
| **F9** | Overlapping vision layers | Standardize on `tools/vision/screen_engine.py` as the canonical coordinator; mark `tools/visual_eye.py` game entity locator as internal game utility. |
| **F10** | Game-specific color thresholds | Keep arcade game character/target color masks strictly isolated within game-specific modules. |
| **F11** | Document formats & summarization | Retain `_extract_docx`, `_extract_xlsx`, and TF-scoring `summarize_document`; enforce 1,000 token output bounds to protect model context. |
| **F12** | Substring collisions & timeout in `llm.py` | Use word-boundary regex (`\bdo\b`); add missing Roman Urdu verbs (`dekho`, `nikalo`, `badlo`, `bhejo`); increase `ask_conversational_llm` timeout to 25.0s to accommodate CPU cold-start. |
| **F13** | Router regex sprawl | Progressively delegate domain routing to local LLM tool calling while keeping high-speed shortcuts for unambiguous intents. |
| **F14** | Empty evidence in zero-defect ledger | Enforce mandatory physical oracle telemetry (HWND, PID, diff %) for all ledger recordings. |
| **F15** | Preserving populated modules | Keep existing populated modules (`lexer.py`, `firewall.py`, `settings.py`) intact; do not assume files are empty without disk verification. |
| **F16** | GDI cleanup | Retain `GetDC(hwnd)` and the existing `try...finally` block releasing bitmaps, DCs, and window DCs. |

---

*End of AUDIT_REPORT.md*
