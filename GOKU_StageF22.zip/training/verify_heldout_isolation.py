"""
training/verify_heldout_isolation.py - Strict Held-Out Dataset Isolation Verifier
Follows GOKU RULES v2 Prompt K Step 2.
Proves that the held-out evaluation set is NEVER used in training, validation, test, or few-shot examples.
"""
from __future__ import annotations

import json
from pathlib import Path
import re
import sys

HELDOUT_PATH = Path("acceptance/routing_heldout.json")
TRAIN_PATH = Path("training/data/train.jsonl")
VAL_PATH = Path("training/data/val.jsonl")
TEST_PATH = Path("training/data/test.jsonl")
MODELFILE_PATH = Path("training/Modelfile.goku")
ROUTER_PATH = Path("command_layer/router.py")


def normalize_str(s: str) -> str:
    return re.sub(r"\s+", " ", s.strip().lower())


def verify_isolation():
    print("=" * 70)
    print("GOKU PROMPT K - STEP 2: HELD-OUT DATASET ISOLATION VERIFICATION")
    print("=" * 70)

    assert HELDOUT_PATH.exists(), f"Held-out dataset missing at {HELDOUT_PATH}"
    with open(HELDOUT_PATH, "r", encoding="utf-8") as f:
        heldout_entries = json.load(f)

    heldout_cmds = [normalize_str(e["command"]) for e in heldout_entries]
    heldout_set = set(heldout_cmds)
    print(f"Loaded {len(heldout_cmds)} commands from {HELDOUT_PATH}.")
    print(f"Unique held-out commands: {len(heldout_set)}")

    # 1. Check against Train Split
    train_cmds = set()
    with open(TRAIN_PATH, "r", encoding="utf-8") as f:
        for line in f:
            r = json.loads(line)
            train_cmds.add(normalize_str(r["messages"][1]["content"]))

    train_overlap = heldout_set & train_cmds
    print(f"\n1. Train Split Overlap Check ({len(train_cmds)} train rows):")
    print(f"   - Overlapping Phrases: {len(train_overlap)}")
    if train_overlap:
        print(f"   - VIOLATION! Overlaps: {train_overlap}")

    # 2. Check against Val Split
    val_cmds = set()
    with open(VAL_PATH, "r", encoding="utf-8") as f:
        for line in f:
            r = json.loads(line)
            val_cmds.add(normalize_str(r["messages"][1]["content"]))

    val_overlap = heldout_set & val_cmds
    print(f"\n2. Validation Split Overlap Check ({len(val_cmds)} val rows):")
    print(f"   - Overlapping Phrases: {len(val_overlap)}")

    # 3. Check against Test Split
    test_cmds = set()
    with open(TEST_PATH, "r", encoding="utf-8") as f:
        for line in f:
            r = json.loads(line)
            test_cmds.add(normalize_str(r["messages"][1]["content"]))

    test_overlap = heldout_set & test_cmds
    print(f"\n3. Internal Test Split Overlap Check ({len(test_cmds)} test rows):")
    print(f"   - Overlapping Phrases: {len(test_overlap)}")

    # 4. Check against Modelfile Few-Shot Examples
    few_shot_cmds = set()
    if MODELFILE_PATH.exists():
        with open(MODELFILE_PATH, "r", encoding="utf-8") as f:
            text = f.read()
            matches = re.findall(r'MESSAGE user "(.*?)"', text)
            for m in matches:
                few_shot_cmds.add(normalize_str(m))

    few_shot_overlap = heldout_set & few_shot_cmds
    print(f"\n4. Modelfile.goku Few-Shot Overlap Check ({len(few_shot_cmds)} few-shots):")
    print(f"   - Overlapping Phrases: {len(few_shot_overlap)}")

    # Summary assertion
    total_leaks = len(train_overlap) + len(val_overlap) + len(test_overlap) + len(few_shot_overlap)
    print("\n" + "-" * 70)
    print(f"TOTAL HELD-OUT LEAKAGE ACROSS ALL ARTIFACTS: {total_leaks}")
    print("-" * 70)

    if total_leaks > 0:
        print("FAIL: Held-out evaluation set is contaminated with training/prompting phrases!")
        sys.exit(1)
    else:
        print("PASS: ZERO leakage confirmed! Held-out set is strictly isolated.")
        print("=" * 70)


if __name__ == "__main__":
    verify_isolation()
