"""
training/validate_colab_notebook.py - Local CPU Validation for Colab Notebook
Follows GOKU RULES v2 Prompt K Step 3:
- Validates notebook JSON schema via nbformat.
- Verifies python AST compilation across all notebook code cells.
- Executes data-preparation logic on CPU using a tiny sample from train.jsonl.
"""
from __future__ import annotations

import ast
import json
from pathlib import Path
import sys

NOTEBOOK_PATH = Path("training/colab_lora.ipynb")
DATA_SAMPLE_PATH = Path("training/data/train.jsonl")


def validate_notebook():
    print("=" * 70)
    print("GOKU PROMPT K - STEP 3: COLAB NOTEBOOK LOCAL VALIDATION")
    print("=" * 70)

    assert NOTEBOOK_PATH.exists(), f"Notebook file missing at {NOTEBOOK_PATH}"

    # 1. Schema Validation (nbformat if installed, else json check)
    with open(NOTEBOOK_PATH, "r", encoding="utf-8") as f:
        nb_json = json.load(f)

    try:
        import nbformat
        nb = nbformat.from_dict(nb_json)
        nbformat.validate(nb)
        print("1. nbformat JSON Schema Validation: PASSED (Valid v4 format)")
    except ImportError:
        assert "cells" in nb_json and "metadata" in nb_json, "Invalid notebook structure"
        print("1. Fallback JSON Schema Validation: PASSED (cells and metadata present)")

    # 2. Syntax & AST Verification of Code Cells
    code_cells = [c for c in nb_json.get("cells", []) if c.get("cell_type") == "code"]
    print(f"\n2. Verifying AST Syntax across {len(code_cells)} code cells:")

    compiled_cells = 0
    for idx, cell in enumerate(code_cells, 1):
        source = "".join(cell.get("source", []))
        # Strip ipython magics / shell commands (!pip, !git, !cmake, !nvidia-smi) for AST check
        clean_lines = []
        in_shell_continuation = False
        for line in source.split("\n"):
            stripped = line.strip()
            if in_shell_continuation:
                clean_lines.append("# " + line)
                if not stripped.endswith("\\"):
                    in_shell_continuation = False
                continue

            if stripped.startswith("!") or stripped.startswith("%"):
                clean_lines.append("# " + line)
                if stripped.endswith("\\"):
                    in_shell_continuation = True
            else:
                clean_lines.append(line)
        clean_source = "\n".join(clean_lines)

        try:
            ast.parse(clean_source)
            compiled_cells += 1
        except SyntaxError as e:
            print(f"   [ERROR] Cell {idx} Syntax Error: {e}")
            sys.exit(1)

    print(f"   All {compiled_cells}/{len(code_cells)} code cells compiled cleanly without syntax errors!")

    # 3. CPU Execution of Data-Preparation Logic on Tiny Sample
    print("\n3. Testing Data Preparation & ChatML Formatting on CPU Tiny Sample:")
    assert DATA_SAMPLE_PATH.exists(), f"Data sample missing at {DATA_SAMPLE_PATH}"

    with open(DATA_SAMPLE_PATH, "r", encoding="utf-8") as f:
        sample_rows = [json.loads(f.readline()) for _ in range(5)]

    def mock_format_prompt(messages):
        # Emulates standard ChatML serialization
        formatted = ""
        for m in messages:
            formatted += f"<|im_start|>{m['role']}\n{m['content']}<|im_end|>\n"
        return formatted

    sample_formatted = []
    for row in sample_rows:
        msgs = row.get("messages", [])
        text = mock_format_prompt(msgs)
        sample_formatted.append(text)
        assert "<|im_start|>system" in text
        assert "<|im_start|>user" in text
        assert "<|im_start|>assistant" in text

    print(f"   Successfully formatted {len(sample_formatted)} sample rows in ChatML schema.")
    print("   Sample preview:")
    preview_lines = sample_formatted[0].split("\n")[:4]
    for pl in preview_lines:
        print(f"     {pl}")

    # 4. Check for Modern API Presence
    all_source = "\n".join("".join(c.get("source", [])) for c in code_cells)
    assert "eval_strategy=" in all_source, "Deprecated evaluation_strategy found instead of eval_strategy!"
    assert "SFTConfig(" in all_source, "Modern SFTConfig missing!"
    assert "processing_class=" in all_source, "Modern processing_class argument missing!"
    assert "Q4_K_M" in all_source, "Q4_K_M quantization instruction missing!"

    print("\n4. Modern API Verification (STATIC AST/STRING CHECK ONLY, NOT EXECUTED ON GPU RUNTIME):")
    print("   - eval_strategy: FOUND IN CODE (replaces evaluation_strategy)")
    print("   - SFTConfig: FOUND IN CODE (modern TRL configuration class)")
    print("   - processing_class: FOUND IN CODE (replaces deprecated tokenizer argument)")
    print("   - Q4_K_M Quantization: FOUND IN CODE (llama-quantize target)")

    print("\n" + "=" * 70)
    print("PASS: Colab Notebook passes local static checks (AST/schema/formatting); NOT EXECUTED ON GPU!")
    print("=" * 70)


if __name__ == "__main__":
    validate_notebook()
