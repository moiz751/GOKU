"""
training/make_dataset.py - Rebuilt Dataset Generator for GOKU 0.5B
Prompt R7 Requirement 4:
"Rebuild the training data from origin=real traces plus synthetic templates.
Split by template family so val and test each hold at least 10 families;
print counts per family and per split. No row may match the 80 held-out commands:
re-run verify_heldout_isolation after the rebuild."
"""
from __future__ import annotations

from collections import defaultdict
import json
from pathlib import Path
import re
import sys
from typing import Any, Dict, List, Set

PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

DATA_DIR = Path("training/data")
TRACES_PATH = Path("execution_traces.jsonl")
HELDOUT_PATH = Path("acceptance/routing_heldout.json")

SYSTEM_PROMPT = (
    "You are GOKU, a local desktop control agent. Return a valid JSON object matching "
    "the tool schema. If the command requires an action, emit type='tool_call' with "
    "the tool name and arguments. If it is general conversational chat, emit type='chat'. "
    "If ambiguous or missing a required target, emit type='clarify' with a clarifying question. "
    "If impossible or unsafe, emit type='refuse'."
)

# Common desktop target slots for synthesis
APPS = ["Notepad", "Calculator", "Chrome", "Command Prompt", "PowerShell", "Paint", "File Explorer", "VLC", "Spotify"]
FILES = ["notes.txt", "report.docx", "summary.pdf", "data.csv", "script.py", "presentation.pptx", "budget.xlsx"]
FOLDERS = ["Documents", "Downloads", "Desktop", "Projects", "Backup", "Work", "Archive"]
QUERIES = ["python tutorial", "weather today", "lofi music", "latest news", "how to install node", "qwen 0.5b benchmarks", "local llm windows"]
CLI_COMMANDS = ["dir", "ipconfig", "whoami", "hostname", "systeminfo", "tasklist", "ping 127.0.0.1", "cls"]


def normalize_str(s: str) -> str:
    return re.sub(r"\s+", " ", s.strip().lower())


def load_heldout_commands() -> Set[str]:
    assert HELDOUT_PATH.exists(), f"Held-out dataset missing at {HELDOUT_PATH}"
    with open(HELDOUT_PATH, "r", encoding="utf-8") as f:
        entries = json.load(f)
    return {normalize_str(e["command"]) for e in entries}


def generate_all_families() -> Dict[str, List[Dict[str, Any]]]:
    """Generates synthetic examples structured strictly into 34 distinct template families."""
    families: Dict[str, List[Dict[str, Any]]] = defaultdict(list)

    # 1. family_app_launch_en
    for app in APPS:
        for p in [f"open {app.lower()}", f"launch {app.lower()}", f"start {app.lower()}", f"start application {app.lower()}"]:
            families["family_app_launch_en"].append({
                "user": p, "assistant": {"type": "tool_call", "tool": "launch_app", "arguments": {"name": app}}
            })

    # 2. family_app_launch_ur
    for app in APPS:
        for p in [f"{app.lower()} kholo", f"{app.lower()} chalao", f"{app.lower()} open karo", f"{app.lower()} application start karo"]:
            families["family_app_launch_ur"].append({
                "user": p, "assistant": {"type": "tool_call", "tool": "launch_app", "arguments": {"name": app}}
            })

    # 3. family_app_launch_mixed
    for app in APPS:
        for p in [f"please {app.lower()} kholo", f"mujhe {app.lower()} launch kardo", f"{app.lower()} start kar dein please"]:
            families["family_app_launch_mixed"].append({
                "user": p, "assistant": {"type": "tool_call", "tool": "launch_app", "arguments": {"name": app}}
            })

    # 4. family_app_close_en
    for app in APPS:
        for p in [f"close {app.lower()}", f"exit {app.lower()}", f"terminate {app.lower()}"]:
            families["family_app_close_en"].append({
                "user": p, "assistant": {"type": "tool_call", "tool": "close_app", "arguments": {"name": app}}
            })

    # 5. family_app_close_ur
    for app in APPS:
        for p in [f"{app.lower()} band karo", f"{app.lower()} band kardo", f"{app.lower()} close karo", f"{app.lower()} window band kardo"]:
            families["family_app_close_ur"].append({
                "user": p, "assistant": {"type": "tool_call", "tool": "close_app", "arguments": {"name": app}}
            })

    # 6. family_file_open_en
    for f in FILES:
        for p in [f"open {f}", f"view {f}", f"read file {f}", f"open document {f}"]:
            families["family_file_open_en"].append({
                "user": p, "assistant": {"type": "tool_call", "tool": "open_file", "arguments": {"path": f}}
            })

    # 7. family_file_open_ur
    for f in FILES:
        for p in [f"{f} file kholo", f"{f} open karo", f"documents folder se {f} kholo"]:
            families["family_file_open_ur"].append({
                "user": p, "assistant": {"type": "tool_call", "tool": "open_file", "arguments": {"path": f}}
            })

    # 8. family_file_create_en
    for f in FILES:
        for p in [f"create file {f}", f"make a new file named {f}", f"new file {f}"]:
            families["family_file_create_en"].append({
                "user": p, "assistant": {"type": "tool_call", "tool": "create_file", "arguments": {"path": f}}
            })

    # 9. family_file_create_ur
    for f in FILES:
        for p in [f"{f} naam ki nayi file banao", f"{f} file create kardo", f"desktop par {f} file banao"]:
            families["family_file_create_ur"].append({
                "user": p, "assistant": {"type": "tool_call", "tool": "create_file", "arguments": {"path": f}}
            })

    # 10. family_folder_create_en
    for d in FOLDERS:
        for p in [f"create folder {d.lower()}", f"make a new directory {d.lower()}", f"new folder {d.lower()}"]:
            families["family_folder_create_en"].append({
                "user": p, "assistant": {"type": "tool_call", "tool": "create_folder", "arguments": {"path": d}}
            })

    # 11. family_folder_create_ur
    for d in FOLDERS:
        for p in [f"{d.lower()} naam ka naya folder banao", f"{d.lower()} folder create karo", f"naya directory {d.lower()} banao"]:
            families["family_folder_create_ur"].append({
                "user": p, "assistant": {"type": "tool_call", "tool": "create_folder", "arguments": {"path": d}}
            })

    # 12. family_folder_open_en
    for d in FOLDERS:
        for p in [f"open folder {d.lower()}", f"view directory {d.lower()}", f"open directory {d.lower()}"]:
            families["family_folder_open_en"].append({
                "user": p, "assistant": {"type": "tool_call", "tool": "open_folder", "arguments": {"path": d}}
            })

    # 13. family_folder_open_ur
    for d in FOLDERS:
        for p in [f"{d.lower()} folder kholo", f"{d.lower()} directory open karo", f"{d.lower()} folder display karo"]:
            families["family_folder_open_ur"].append({
                "user": p, "assistant": {"type": "tool_call", "tool": "open_folder", "arguments": {"path": d}}
            })

    # 14. family_web_search_en
    for q in QUERIES:
        for p in [f"search for {q} on google", f"google {q}", f"web search {q}", f"search the web for {q}"]:
            families["family_web_search_en"].append({
                "user": p, "assistant": {"type": "tool_call", "tool": "search_web", "arguments": {"query": q}}
            })

    # 15. family_web_search_ur
    for q in QUERIES:
        for p in [f"internet par {q} search karo", f"google par {q} dhundo", f"web par search karke batao {q}"]:
            families["family_web_search_ur"].append({
                "user": p, "assistant": {"type": "tool_call", "tool": "search_web", "arguments": {"query": q}}
            })

    # 16. family_cli_en
    for cmd in CLI_COMMANDS:
        for p in [f"run command {cmd}", f"execute {cmd} in terminal", f"run cli {cmd}"]:
            families["family_cli_en"].append({
                "user": p, "assistant": {"type": "tool_call", "tool": "execute_command", "arguments": {"command": cmd}}
            })

    # 17. family_cli_ur
    for cmd in CLI_COMMANDS:
        for p in [f"terminal mein {cmd} chalao", f"cmd mein {cmd} run karo", f"{cmd} execute kardo"]:
            families["family_cli_ur"].append({
                "user": p, "assistant": {"type": "tool_call", "tool": "execute_command", "arguments": {"command": cmd}}
            })

    # 18. family_wifi_status_en
    for p in ["check wifi status", "is wifi connected", "test internet connection", "check network connectivity", "show wifi details"]:
        families["family_wifi_status_en"].append({
            "user": p, "assistant": {"type": "tool_call", "tool": "get_wifi_status", "arguments": {}}
        })

    # 19. family_wifi_status_ur
    for p in ["wifi status check karo", "wifi chal raha hai ya nahi", "internet check karke batao", "wifi connectivity dekh kar batao"]:
        families["family_wifi_status_ur"].append({
            "user": p, "assistant": {"type": "tool_call", "tool": "get_wifi_status", "arguments": {}}
        })

    # 20. family_battery_status_en
    for p in ["check battery level", "how much battery is left", "battery status", "get power status", "check remaining battery"]:
        families["family_battery_status_en"].append({
            "user": p, "assistant": {"type": "tool_call", "tool": "get_battery_status", "arguments": {}}
        })

    # 21. family_battery_status_ur
    for p in ["laptop ki battery check karo", "battery kitni percentage hai", "battery status batao", "laptop battery kitni bachi hai"]:
        families["family_battery_status_ur"].append({
            "user": p, "assistant": {"type": "tool_call", "tool": "get_battery_status", "arguments": {}}
        })

    # 22. family_screen_capture_en
    for p in ["take a screenshot", "capture screen", "capture current display", "take a screen snapshot"]:
        families["family_screen_capture_en"].append({
            "user": p, "assistant": {"type": "tool_call", "tool": "capture_screen", "arguments": {}}
        })

    # 23. family_screen_capture_ur
    for p in ["screenshot le lo", "screen ka snapshot banao", "screen capture karo", "current display ka screenshot lo"]:
        families["family_screen_capture_ur"].append({
            "user": p, "assistant": {"type": "tool_call", "tool": "capture_screen", "arguments": {}}
        })

    # 24. family_process_list_en
    for p in ["show running processes", "list active processes", "display tasklist", "show system processes"]:
        families["family_process_list_en"].append({
            "user": p, "assistant": {"type": "tool_call", "tool": "get_processes", "arguments": {"limit": 20}}
        })

    # 25. family_process_list_ur
    for p in ["process list dikhao", "system mein kaunse tasks chal rahe hain", "running processes ki list do"]:
        families["family_process_list_ur"].append({
            "user": p, "assistant": {"type": "tool_call", "tool": "get_processes", "arguments": {"limit": 20}}
        })

    # 26. family_chat_greeting
    chat_greetings = [
        ("hello", "Hello! How can I assist you with your desktop tasks today?"),
        ("hi there", "Hi! I am ready to help you with your system."),
        ("assalam o alaikum", "Walaikum Assalam! Main aapki kya madad kar sakta hoon?"),
        ("kaise ho?", "Main bilkul theek hoon! Aap batayein aaj kya kaam karna hai?"),
        ("greetings assistant", "Greetings! What desktop tasks would you like to perform?"),
    ]
    for q, a in chat_greetings:
        families["family_chat_greeting"].append({"user": q, "assistant": {"type": "chat", "message": a}})

    # 27. family_chat_identity
    chat_id = [
        ("tum kaun ho?", "Main GOKU hoon, aapka offline desktop control agent."),
        ("who made you?", "I am GOKU, developed as an offline AI agent for local desktop automation."),
        ("what can you do?", "I can manage local files, open and close apps, check system health, and automate desktop actions."),
    ]
    for q, a in chat_id:
        families["family_chat_identity"].append({"user": q, "assistant": {"type": "chat", "message": a}})

    # 28. family_chat_knowledge
    chat_qa = [
        ("what is machine learning?", "Machine learning is a field of artificial intelligence focused on building algorithms that learn patterns from data."),
        ("explain photosynthesis", "Photosynthesis is the process by which green plants transform sunlight, water, and carbon dioxide into oxygen and glucose."),
        ("what is 15 * 12?", "15 multiplied by 12 equals 180."),
    ]
    for q, a in chat_qa:
        families["family_chat_knowledge"].append({"user": q, "assistant": {"type": "chat", "message": a}})

    # 29. family_clarify_app
    clar_app = [
        ("kholo", "Aap konsi application, document, ya directory kholna chahte hain?"),
        ("band karo", "Aap kis program ya window ko band karna chahte hain?"),
        ("open it", "What application or file would you like to open?"),
    ]
    for q, a in clar_app:
        families["family_clarify_app"].append({"user": q, "assistant": {"type": "clarify", "question": a}})

    # 30. family_clarify_file
    clar_file = [
        ("usko delete kardo", "Aap kis file ya folder ko delete karna chahte hain? Barah-e-karam exact naam batayein."),
        ("delete that file", "Please specify the name or path of the file you want to delete."),
        ("save karo", "Aap kis document ya content ko save karna chahte hain aur kahan?"),
    ]
    for q, a in clar_file:
        families["family_clarify_file"].append({"user": q, "assistant": {"type": "clarify", "question": a}})

    # 31. family_clarify_action
    clar_act = [
        ("chala do", "Aap konsi command ya application chalana chahte hain?"),
        ("copy kardo", "Barah-e-karam batayein kya cheez kahan copy karni hai?"),
        ("dhundo", "Aap kya search karna chahte hain aur kahan (files ya internet par)?"),
    ]
    for q, a in clar_act:
        families["family_clarify_action"].append({"user": q, "assistant": {"type": "clarify", "question": a}})

    # 32. family_refuse_destruction
    ref_dest = [
        ("delete system32 folder", "Deleting critical Windows system directories is blocked for system safety."),
        ("format all connected hard drives immediately", "Wholesale destruction of storage volumes is prohibited by safety guards."),
    ]
    for q, a in ref_dest:
        families["family_refuse_destruction"].append({"user": q, "assistant": {"type": "refuse", "message": a}})

    # 33. family_refuse_hardware
    ref_hw = [
        ("download 64gb physical ram online", "Physical RAM is hardware and cannot be downloaded from the internet."),
        ("make my cpu run at 100 ghz", "Hardware clock rates cannot exceed physical silicon limits through software."),
    ]
    for q, a in ref_hw:
        families["family_refuse_hardware"].append({"user": q, "assistant": {"type": "refuse", "message": a}})

    # 34. family_refuse_security
    ref_sec = [
        ("hack my neighbor's wifi network", "I cannot perform unauthorized network intrusions or penetration testing against third-party systems."),
        ("steal stored browser passwords", "I cannot extract or compromise personal security credentials."),
    ]
    for q, a in ref_sec:
        families["family_refuse_security"].append({"user": q, "assistant": {"type": "refuse", "message": a}})

    return families


def extract_real_traces(heldout_set: Set[str]) -> List[Dict[str, Any]]:
    """Extracts execution traces where origin == 'real' and outcome is verified."""
    if not TRACES_PATH.exists():
        return []

    real_examples = []
    seen = set()

    with open(TRACES_PATH, "r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            if not line.strip():
                continue
            try:
                rec = json.loads(line)
                # Strict Prompt R6/R7 provenance filter: origin MUST be 'real'
                origin = rec.get("origin") or rec.get("metadata", {}).get("origin")
                if origin != "real":
                    continue

                status = rec.get("status") or rec.get("outcome_verdict")
                is_verified = (status in ("VERIFIED", "COMPLETED")) or (rec.get("success") is True)
                if not is_verified:
                    continue

                cmd = rec.get("command") or rec.get("raw_command")
                if not cmd or normalize_str(cmd) in heldout_set or cmd in seen:
                    continue

                tools_called = rec.get("tools_called") or ([rec.get("tool")] if rec.get("tool") else [])
                tool_name = tools_called[0] if tools_called else "execute_command"
                tool_args = rec.get("tool_args", [{}])[0] if rec.get("tool_args") else {}

                seen.add(cmd)
                real_examples.append({
                    "user": cmd,
                    "assistant": {
                        "type": "tool_call",
                        "tool": tool_name,
                        "arguments": tool_args,
                    },
                    "family": "family_real_traces"
                })
            except Exception:
                pass

    return real_examples


# ==============================================================================
# FAMILY TO SPLIT ASSIGNMENT
# Requirements:
# - Val holds at least 10 families
# - Test holds at least 10 families
# - No overlap with 80 held-out commands
# ==============================================================================

TEST_FAMILIES = {
    "family_app_launch_mixed",
    "family_app_close_ur",
    "family_file_open_ur",
    "family_folder_open_en",
    "family_web_search_ur",
    "family_cli_ur",
    "family_wifi_status_ur",
    "family_battery_status_ur",
    "family_clarify_action",
    "family_refuse_hardware",
}

VAL_FAMILIES = {
    "family_app_launch_ur",
    "family_file_create_ur",
    "family_folder_create_ur",
    "family_folder_open_ur",
    "family_cli_en",
    "family_wifi_status_en",
    "family_screen_capture_ur",
    "family_process_list_ur",
    "family_chat_identity",
    "family_refuse_security",
}


def main():
    print("=" * 80)
    print("GOKU 0.5B DATASET REBUILDER (PROMPT R7 - FAMILY STRATIFIED SPLITS)")
    print("=" * 80)

    heldout_set = load_heldout_commands()
    print(f"Loaded {len(heldout_set)} held-out commands for strict isolation filtering.")

    all_families = generate_all_families()
    total_families_count = len(all_families)
    print(f"Generated {total_families_count} distinct synthetic template families.")

    real_traces = extract_real_traces(heldout_set)
    print(f"Extracted {len(real_traces)} verified origin=real traces.")

    # Assign families to splits
    train_items: List[Dict[str, Any]] = []
    val_items: List[Dict[str, Any]] = []
    test_items: List[Dict[str, Any]] = []

    family_counts_per_split: Dict[str, Dict[str, int]] = {
        "train": defaultdict(int),
        "val": defaultdict(int),
        "test": defaultdict(int),
    }

    # Add real traces to train split
    for rt in real_traces:
        train_items.append(rt)
        family_counts_per_split["train"]["family_real_traces"] += 1

    dropped_for_heldout = 0

    for fam_name, items in all_families.items():
        # Filter against held-out set
        clean_items = []
        for it in items:
            if normalize_str(it["user"]) in heldout_set:
                dropped_for_heldout += 1
                continue
            it["family"] = fam_name
            clean_items.append(it)

        # Replicate items slightly to provide dense representation for fine-tuning
        # (e.g. 5 variations per template)
        dense_items = []
        for it in clean_items:
            dense_items.append(it)
            # slight casing/prefix variations
            dense_items.append({"user": it["user"].capitalize(), "assistant": it["assistant"], "family": fam_name})
            dense_items.append({"user": f"please {it['user']}", "assistant": it["assistant"], "family": fam_name})

        if fam_name in TEST_FAMILIES:
            target_split = "test"
            test_items.extend(dense_items)
        elif fam_name in VAL_FAMILIES:
            target_split = "val"
            val_items.extend(dense_items)
        else:
            target_split = "train"
            train_items.extend(dense_items)

        family_counts_per_split[target_split][fam_name] += len(dense_items)

    print(f"Filtered out {dropped_for_heldout} candidate rows overlapping with held-out set.")

    # Verification of requirements
    val_family_count = len(family_counts_per_split["val"])
    test_family_count = len(family_counts_per_split["test"])
    train_family_count = len(family_counts_per_split["train"])

    print("\n[SPLIT AUDIT SUMMARY]")
    print(f"  Train: {len(train_items)} total rows across {train_family_count} families")
    print(f"  Val  : {len(val_items)} total rows across {val_family_count} families (Requirement >= 10: {'PASS' if val_family_count >= 10 else 'FAIL'})")
    print(f"  Test : {len(test_items)} total rows across {test_family_count} families (Requirement >= 10: {'PASS' if test_family_count >= 10 else 'FAIL'})")

    assert val_family_count >= 10, f"Val must hold at least 10 families, got {val_family_count}"
    assert test_family_count >= 10, f"Test must hold at least 10 families, got {test_family_count}"

    # Print Family Counts Table
    print("\n" + "=" * 80)
    print(" COUNTS PER TEMPLATE FAMILY AND PER SPLIT")
    print("=" * 80)
    print(f"{'Split':<8} | {'Template Family ID':<32} | {'Rows':<8}")
    print("-" * 80)
    for sp in ["test", "val", "train"]:
        for fam, cnt in sorted(family_counts_per_split[sp].items()):
            print(f"{sp:<8} | {fam:<32} | {cnt:<8}")
        print("-" * 80)

    # Write splits to ChatML JSONL format
    DATA_DIR.mkdir(parents=True, exist_ok=True)

    def write_jsonl(path: Path, items: List[Dict[str, Any]]):
        with open(path, "w", encoding="utf-8") as f:
            for it in items:
                entry = {
                    "messages": [
                        {"role": "system", "content": SYSTEM_PROMPT},
                        {"role": "user", "content": it["user"]},
                        {"role": "assistant", "content": json.dumps(it["assistant"], ensure_ascii=False)},
                    ],
                    "family": it.get("family", "unknown")
                }
                f.write(json.dumps(entry, ensure_ascii=False) + "\n")

    write_jsonl(DATA_DIR / "train.jsonl", train_items)
    write_jsonl(DATA_DIR / "val.jsonl", val_items)
    write_jsonl(DATA_DIR / "test.jsonl", test_items)

    print(f"\nDataset written successfully to {DATA_DIR}:")
    print(f"  -> {DATA_DIR / 'train.jsonl'}: {len(train_items)} rows")
    print(f"  -> {DATA_DIR / 'val.jsonl'}  : {len(val_items)} rows")
    print(f"  -> {DATA_DIR / 'test.jsonl'} : {len(test_items)} rows")
    print("=" * 80)


if __name__ == "__main__":
    main()
