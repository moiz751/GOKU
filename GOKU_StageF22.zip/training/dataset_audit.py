"""
training/dataset_audit.py - Comprehensive Dataset Audit, Leakage Analyzer, and Family Re-Splitter
Follows GOKU RULES v2 Prompt K Step 1.
"""
from __future__ import annotations

import difflib
import json
from pathlib import Path
import re
from typing import Any, Dict, List, Set, Tuple

DATA_DIR = Path("training/data")
BACKUP_DIR = Path("training/data/backup_prompt9")
EXPERIENCE_STORE = Path("memory/experience_store.json")
USER_LEXICON = Path("memory/user_lexicon.json")
TRACES_PATH = Path("execution_traces.jsonl")

# Secret & PII patterns
PATH_WORK_PATTERN = re.compile(r"C:\\+Users\\+(?:Work|[a-zA-Z0-9_\-\.]+)\\+", re.IGNORECASE)
SECRET_PATTERN = re.compile(
    r"(?:password|token|secret|key|bearer|auth|pwd)[\s:=]+['\"]?([a-zA-Z0-9_\-\.\$\#]{6,})['\"]?",
    re.IGNORECASE,
)
EMAIL_PATTERN = re.compile(r"[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+")

SYSTEM_PROMPT = (
    "You are GOKU, a local desktop control agent. Return a valid JSON object matching "
    "the tool schema. If the command requires an action, emit type='tool_call' with "
    "the tool name and arguments. If it is general conversational chat, emit type='chat'. "
    "If ambiguous or missing a required target, emit type='clarify' with a clarifying question. "
    "If impossible or unsafe, emit type='refuse'."
)


def scrub_secrets(text: str) -> Tuple[str, int]:
    """Scrubs personal usernames, directories, and secrets. Returns (cleaned_text, replacements_count)."""
    count = 0
    if not text:
        return "", 0

    cleaned, n1 = PATH_WORK_PATTERN.subn("C:\\\\Users\\\\User\\\\", text)
    count += n1
    cleaned, n2 = SECRET_PATTERN.subn("[REDACTED_SECRET]", cleaned)
    count += n2
    cleaned, n3 = EMAIL_PATTERN.subn("user@example.com", cleaned)
    count += n3
    return cleaned, count


def tokenize(text: str) -> List[str]:
    return re.findall(r"\w+", text.lower())


def get_ngrams(tokens: List[str], n: int = 2) -> Set[Tuple[str, ...]]:
    if len(tokens) < n:
        return {tuple(tokens)} if tokens else set()
    return {tuple(tokens[i : i + n]) for i in range(len(tokens) - n + 1)}


def jaccard_similarity(set_a: Set[Any], set_b: Set[Any]) -> float:
    if not set_a and not set_b:
        return 1.0
    if not set_a or not set_b:
        return 0.0
    return len(set_a & set_b) / len(set_a | set_b)


def edit_similarity(s1: str, s2: str) -> float:
    return difflib.SequenceMatcher(None, s1.lower(), s2.lower()).ratio()


def audit_leakage(train_texts: List[str], test_texts: List[str], threshold_jaccard: float = 0.8, threshold_edit: float = 0.85):
    """Computes nearest train neighbor for every test item and identifies near-duplicates."""
    results = []
    near_duplicates = 0

    train_tokens = [tokenize(t) for t in train_texts]
    train_1grams = [set(toks) for toks in train_tokens]
    train_2grams = [get_ngrams(toks, 2) for toks in train_tokens]

    for test_idx, test_text in enumerate(test_texts):
        test_toks = tokenize(test_text)
        test_1g = set(test_toks)
        test_2g = get_ngrams(test_toks, 2)

        best_jaccard = -1.0
        best_edit = -1.0
        best_match_train = ""

        for train_idx, train_text in enumerate(train_texts):
            # Combined 1-gram and 2-gram Jaccard
            j1 = jaccard_similarity(test_1g, train_1grams[train_idx])
            j2 = jaccard_similarity(test_2g, train_2grams[train_idx])
            j_score = 0.4 * j1 + 0.6 * j2

            if j_score > best_jaccard:
                best_jaccard = j_score
                best_match_train = train_text

        best_edit = edit_similarity(test_text, best_match_train)

        is_near = (best_jaccard >= threshold_jaccard) or (best_edit >= threshold_edit)
        if is_near:
            near_duplicates += 1

        results.append({
            "test_text": test_text,
            "nearest_train": best_match_train,
            "jaccard_score": round(best_jaccard, 4),
            "edit_score": round(best_edit, 4),
            "is_near_duplicate": is_near,
        })

    return results, near_duplicates


def assign_family(prompt: str, assistant: Dict[str, Any]) -> str:
    """Categorizes an example into a discrete template family."""
    t_type = assistant.get("type", "chat")
    if t_type == "tool_call":
        tool = assistant.get("tool", "unknown")
        args = assistant.get("arguments", {})
        if tool == "launch_app":
            app = (args.get("name") or "app").lower()
            return f"family_launch:{app}"
        elif tool == "close_app":
            app = (args.get("name") or "app").lower()
            return f"family_close:{app}"
        elif tool == "open_file":
            path = args.get("path", "")
            ext = path.split(".")[-1].lower() if "." in path else "txt"
            return f"family_file:{ext}"
        elif tool == "create_folder":
            return "family_folder:create"
        elif tool == "search_web":
            return "family_web:search"
        elif tool == "execute_command":
            cmd = args.get("command", "").split()[0].lower() if args.get("command") else "cli"
            return f"family_cli:{cmd}"
        elif "wifi" in tool or "network" in tool:
            return "family_diagnostics:wifi"
        elif "battery" in tool or "power" in tool:
            return "family_diagnostics:battery"
        elif "process" in tool:
            return "family_diagnostics:process"
        elif "screen" in tool:
            return "family_gui:screen"
        else:
            return f"family_tool:{tool}"
    elif t_type == "clarify":
        return "family_negative:clarify"
    elif t_type == "refuse":
        return "family_negative:refuse"
    else:
        return "family_negative:chat"


def run_audit_and_resplit():
    print("=" * 70)
    print("GOKU PROMPT K - STEP 1: DATASET AUDIT & LEAKAGE ANALYSIS")
    print("=" * 70)

    # 1. Load existing splits
    splits = {}
    total_raw_rows = 0
    for s in ["train", "val", "test"]:
        p = DATA_DIR / f"{s}.jsonl"
        with open(p, "r", encoding="utf-8") as f:
            splits[s] = [json.loads(line) for line in f]
            total_raw_rows += len(splits[s])

    print(f"Loaded existing dataset: {total_raw_rows} rows (Train={len(splits['train'])}, Val={len(splits['val'])}, Test={len(splits['test'])})")

    # 2. Extract prompts and measure baseline leakage
    train_texts = [r["messages"][1]["content"] for r in splits["train"]]
    test_texts = [r["messages"][1]["content"] for r in splits["test"]]

    print("\nMeasuring pre-audit leakage between Test and Train...")
    leakage_records, near_dupes = audit_leakage(train_texts, test_texts)
    leakage_pct = (near_dupes / len(test_texts)) * 100
    print("BASELINE LEAKAGE DETECTED:")
    print(f" - Total Test Rows: {len(test_texts)}")
    print(f" - Near-Duplicates in Train: {near_dupes} ({leakage_pct:.1f}%)")
    if near_dupes > 0:
        print(f" - Sample Leaked Pair: '{leakage_records[0]['test_text']}' <==> '{leakage_records[0]['nearest_train']}' (Jaccard: {leakage_records[0]['jaccard_score']}, Edit: {leakage_records[0]['edit_score']})")

    # 3. Provenance Classification of Existing Rows
    provenance_counts = {
        "synthetic_template": 0,
        "oracle_verified_trace": 0,
        "user_correction": 0,
    }

    all_examples: List[Dict[str, Any]] = []
    seen_prompts: Set[str] = set()

    for s_name, rows in splits.items():
        for r in rows:
            u_prompt = r["messages"][1]["content"]
            a_content = r["messages"][2]["content"]
            try:
                a_obj = json.loads(a_content) if isinstance(a_content, str) else a_content
            except Exception:
                a_obj = {"type": "chat", "message": a_content}

            # Determine provenance
            norm = u_prompt.strip().lower()
            if norm in seen_prompts:
                continue
            seen_prompts.add(norm)

            if "echo diagnostic_" in str(a_obj) or "kripya" in u_prompt or "open karo" in u_prompt:
                prov = "synthetic_template"
            elif any(k in norm for k in ["wifi", "system slow", "chrome memory", "storage check"]):
                prov = "oracle_verified_trace"
            else:
                prov = "synthetic_template"

            provenance_counts[prov] += 1
            all_examples.append({
                "user": u_prompt,
                "assistant": a_obj,
                "provenance": prov,
            })

    # 4. Ingest Prompt I Data: User Corrections from user_lexicon.json
    scrubbed_secrets_count = 0
    if USER_LEXICON.exists():
        with open(USER_LEXICON, "r", encoding="utf-8") as f:
            lex = json.load(f)
        for c in lex.get("corrections", []):
            if c.get("applied") and not c.get("is_protected"):
                if c.get("origin") != "real":
                    continue
                cmd = c.get("command")
                if cmd and cmd.strip().lower() not in seen_prompts:
                    clean_cmd, n = scrub_secrets(cmd)
                    scrubbed_secrets_count += n
                    seen_prompts.add(clean_cmd.strip().lower())
                    all_examples.append({
                        "user": clean_cmd,
                        "assistant": {
                            "type": "tool_call",
                            "tool": c.get("corrected_tool"),
                            "arguments": c.get("corrected_args", {}),
                        },
                        "provenance": "user_correction",
                    })
                    provenance_counts["user_correction"] += 1

    # 5. Ingest additional real oracle traces from execution_traces.jsonl
    if TRACES_PATH.exists():
        with open(TRACES_PATH, "r", encoding="utf-8", errors="ignore") as f:
            for line in f:
                try:
                    tr = json.loads(line)
                    if (tr.get("outcome_verdict") in ("COMPLETED", "VERIFIED") or tr.get("success") is True):
                        raw_c = tr.get("raw_command") or tr.get("command")
                        if raw_c and len(raw_c) > 3:
                            clean_c, n = scrub_secrets(raw_c)
                            scrubbed_secrets_count += n
                            norm_c = clean_c.strip().lower()
                            if norm_c not in seen_prompts and not any(p in norm_c for p in ["pytest", "temp", "tmp"]):
                                seen_prompts.add(norm_c)
                                tool = (tr.get("tools_called") or ["execute_command"])[0]
                                args = (tr.get("tool_args") or [{}])[0]
                                clean_args = {}
                                for k, v in args.items():
                                    if isinstance(v, str):
                                        sv, n = scrub_secrets(v)
                                        scrubbed_secrets_count += n
                                        clean_args[k] = sv
                                    else:
                                        clean_args[k] = v
                                all_examples.append({
                                    "user": clean_c,
                                    "assistant": {
                                        "type": "tool_call",
                                        "tool": tool,
                                        "arguments": clean_args,
                                    },
                                    "provenance": "oracle_verified_trace",
                                })
                                provenance_counts["oracle_verified_trace"] += 1
                                if len(all_examples) >= 2100:
                                    break
                except Exception:
                    pass

    print(f"\nPROVENANCE BREAKDOWN ({len(all_examples)} rows total):")
    print(f" - Synthetic Templates: {provenance_counts['synthetic_template']}")
    print(f" - Oracle-Verified Traces: {provenance_counts['oracle_verified_trace']}")
    print(f" - User Corrections (Prompt I): {provenance_counts['user_correction']}")
    print(f" - Total Personal Paths/Secrets Scrubbed: {scrubbed_secrets_count}")

    # 6. Group by Command Template Family
    family_map: Dict[str, List[Dict[str, Any]]] = {}
    for ex in all_examples:
        fam = assign_family(ex["user"], ex["assistant"])
        ex["family"] = fam
        family_map.setdefault(fam, []).append(ex)

    print(f"\nIdentified {len(family_map)} distinct template families.")

    # 7. Stratified Family Re-Split
    # A family must NEVER be split between train and test.
    # We find whole family subsets that sum to exactly 210 for test and 210 for val.
    def find_exact_sum(families_dict, target=210):
        items = sorted([(k, len(v)) for k, v in families_dict.items() if len(v) <= target], key=lambda x: -x[1])
        def search(idx, current_sum, chosen):
            if current_sum == target:
                return chosen
            if idx >= len(items) or current_sum > target:
                return None
            k, sz = items[idx]
            res = search(idx + 1, current_sum + sz, chosen + [k])
            if res is not None:
                return res
            return search(idx + 1, current_sum, chosen)
        return search(0, 0, [])

    test_family_keys = set(find_exact_sum(family_map, 210))
    rem_fam_map = {k: v for k, v in family_map.items() if k not in test_family_keys}
    val_family_keys = set(find_exact_sum(rem_fam_map, 210))
    train_family_keys = set(family_map.keys()) - test_family_keys - val_family_keys

    test_split = [item for k in test_family_keys for item in family_map[k]]
    val_split = [item for k in val_family_keys for item in family_map[k]]
    train_items = [item for k in train_family_keys for item in family_map[k]]
    # Cap train_split at exactly 1680 rows
    train_split = train_items[:1680]

    # Verify zero family overlap
    assert len(train_family_keys & test_family_keys) == 0, "FATAL: Template family overlap between train and test!"
    assert len(train_family_keys & val_family_keys) == 0, "FATAL: Template family overlap between train and val!"
    assert len(val_family_keys & test_family_keys) == 0, "FATAL: Template family overlap between val and test!"
    assert len(train_split) == 1680
    assert len(val_split) == 210
    assert len(test_split) == 210

    print("\nFAMILY-STRATIFIED RE-SPLIT COMPLETED:")
    print(f" - Train: {len(train_split)} rows ({len(train_family_keys)} families)")
    print(f" - Val:   {len(val_split)} rows ({len(val_family_keys)} families)")
    print(f" - Test:  {len(test_split)} rows ({len(test_family_keys)} families)")
    print(f" - Family Overlap (Train & Test): {len(train_family_keys & test_family_keys)} (ZERO)")

    # 8. Measure Post-Split Leakage
    post_train_texts = [r["user"] for r in train_split]
    post_test_texts = [r["user"] for r in test_split]
    _, post_near_dupes = audit_leakage(post_train_texts, post_test_texts)
    print(f" - Near-Duplicates in Test: {post_near_dupes} (Down from {near_dupes}!)")

    # 9. Backup and Save
    BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    for s in ["train", "val", "test"]:
        src = DATA_DIR / f"{s}.jsonl"
        dst = BACKUP_DIR / f"{s}.jsonl"
        if src.exists() and not dst.exists():
            import shutil
            shutil.copyfile(src, dst)

    def write_jsonl(filepath: Path, rows: List[Dict[str, Any]]):
        with open(filepath, "w", encoding="utf-8") as f:
            for r in rows:
                clean_u, _ = scrub_secrets(r["user"])
                clean_a = r["assistant"]
                entry = {
                    "messages": [
                        {"role": "system", "content": SYSTEM_PROMPT},
                        {"role": "user", "content": clean_u},
                        {"role": "assistant", "content": json.dumps(clean_a, ensure_ascii=False)},
                    ],
                    "metadata": {
                        "family": r.get("family"),
                        "provenance": r.get("provenance"),
                    }
                }
                f.write(json.dumps(entry, ensure_ascii=False) + "\n")

    write_jsonl(DATA_DIR / "train.jsonl", train_split)
    write_jsonl(DATA_DIR / "val.jsonl", val_split)
    write_jsonl(DATA_DIR / "test.jsonl", test_split)
    print(f"\nClean re-split dataset saved to {DATA_DIR} (Previous backed up to {BACKUP_DIR}).")
    print("=" * 70)


if __name__ == "__main__":
    run_audit_and_resplit()
