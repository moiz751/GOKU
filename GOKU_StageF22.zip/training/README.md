# GOKU 0.5B Training & Adaptation Kit (Prompt 9 - Roadmap 2.3)

This kit provides a 3-level enhancement system for fine-tuning and steering `qwen2.5:0.5b` into a high-accuracy, offline Windows desktop agent for English, Roman Urdu, and mixed commands.

---

## Architecture Levels

| Level | Technique | Training Required? | Hardware / Target | Output / Artifact |
| :--- | :--- | :---: | :--- | :--- |
| **Level 1** | Schema-Constrained Output | **NO** | Local 4 GB Laptop | Real tool registry JSON schema (`tools/registry.py`) wired into `brain/llm.py` |
| **Level 2** | Few-Shot Steering Modelfile | **NO** | Local 4 GB Laptop | `training/Modelfile.goku` (40 few-shot Roman Urdu & English examples) |
| **Level 3** | QLoRA Fine-Tuning | **YES (Off-laptop)** | Free Google Colab T4 GPU (16 GB VRAM) | `training/colab_lora.ipynb` $\to$ Merged GGUF `Q4_K_M` (~360 MB) |

---

## 1. Dataset Generation (Level 3)

The dataset is generated with zero PII and zero secrets, synthesizing schema-grounded commands and extracting oracle-verified execution traces:

```bash
# Generates 2,100 deduplicated examples split 80/10/10 into training/data/
python training/make_dataset.py
```

Generated outputs under `training/data/`:
- `train.jsonl` (1,680 examples)
- `val.jsonl` (210 examples)
- `test.jsonl` (210 examples)

Each example strictly follows the OpenAI/Qwen Chat JSONL schema:
```json
{
  "messages": [
    {"role": "system", "content": "You are GOKU, a local desktop control agent..."},
    {"role": "user", "content": "notepad kholo"},
    {"role": "assistant", "content": "{\"type\": \"tool_call\", \"tool\": \"launch_app\", \"arguments\": {\"name\": \"Notepad\"}}"}
  ]
}
```

---

## 2. Level 1: Zero-Training Structured Output

Level 1 dynamically generates JSON schemas from the live tool registry (`tools/registry.py`) and passes them into Ollama's `format` parameter.

In Python:
```python
from brain.llm import ask_structured_output_llm

response = ask_structured_output_llm("notepad open karo", tools_subset=["launch_app", "close_app"])
print(response["parsed"])
# Output: {"type": "tool_call", "tool": "launch_app", "arguments": {"name": "Notepad"}}
```

---

## 3. Level 2: Few-Shot Steering via Ollama Modelfile

Create the specialized `goku-0.5b` model locally using the 40 few-shot examples embedded in `Modelfile.goku`:

```bash
# 1. Create the model in Ollama
ollama create goku-0.5b -f training/Modelfile.goku

# 2. Test interactive prompt
ollama run goku-0.5b "notepad kholo"
```

To switch GOKU to use this steered model, update `config/settings.py`:
```python
MODEL = "goku-0.5b"
```

---

## 4. Level 3: Off-Laptop QLoRA Fine-Tuning on Google Colab

Training happens **OFF this laptop** on a free Google Colab T4 GPU to preserve local physical RAM:

1. Open [Google Colab](https://colab.research.google.com/) and upload `training/colab_lora.ipynb`.
2. Set Runtime Type to **T4 GPU** (free tier).
3. Upload `training/data/train.jsonl`, `val.jsonl`, and `test.jsonl` to the Colab working directory.
4. Execute all cells in `colab_lora.ipynb`:
   - Fine-tunes `Qwen/Qwen2.5-0.5B-Instruct` using QLoRA ($r=16, \alpha=32$) for 3 epochs (~15 minutes on T4).
   - Evaluates on the held-out test split.
   - Merges LoRA adapter weights into the base 16-bit model.
   - Converts weights to GGUF using `llama.cpp` and quantizes to `Q4_K_M`.
   - Outputs `goku-0.5b-q4_k_m.gguf` (~360 MB).
5. Download `goku-0.5b-q4_k_m.gguf` back to your local machine into `training/`.
6. Load the fine-tuned GGUF into local Ollama:
   ```bash
   # Create Modelfile pointing to local GGUF
   echo "FROM ./goku-0.5b-q4_k_m.gguf" > Modelfile.local
   ollama create goku-0.5b -f Modelfile.local
   ```

---

## 5. How to Roll Back to the Base Model

To revert to the stock `qwen2.5:0.5b` base model at any time:

```bash
# 1. Remove the custom model alias from Ollama
ollama rm goku-0.5b

# 2. Ensure config/settings.py points to base model
# Open config/settings.py and verify:
# MODEL = "qwen2.5:0.5b"
```

---

## 6. Local Evaluation Benchmark (`eval_router.py`)

Run the local evaluation benchmark on the held-out test split (`training/data/test.jsonl`) to measure JSON validity, tool-name accuracy, argument exact-match, clarify precision, latency, and memory footprint:

```bash
python training/eval_router.py
```
