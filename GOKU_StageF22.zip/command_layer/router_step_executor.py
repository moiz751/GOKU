from __future__ import annotations
import os
from pathlib import Path
import re
import sys
import time
from typing import Any, Optional, Union, List, Dict, Tuple
from dataclasses import dataclass, field

from brain.planner import (
    Plan,
    PlanStep,
    StructuredIntent,
    create_plan_from_decision,
    decompose_compound_command,
    parse_compound_request,
    resolve_step_variables,
    resolve_step_variables_with_guard,
    inject_plan_prerequisites,
    prune_plan_steps,
    build_hypothesis_investigation_plan,
    build_root_cause_investigation_plan,
    parse_conditional_goal,
    synthesize_adaptive_replan,
    decompose_into_milestones,
    restore_plan_from_checkpoint,
    build_cross_domain_plan,
    apply_cross_domain_transformation,
    build_long_horizon_exploration_plan,
    decompose_long_horizon_goal,
    compute_state_hash,
    detect_state_cycle,
    heuristic_node_score,
    expand_exploration_frontier,
    select_next_frontier_node,
    apply_reflective_history_pruning,
)
from command_layer.cognitive_reasoner import CognitiveReasoner
from command_layer.context import (
    EntityType,
    TypedEntity,
    ORDINAL_REFERENCES,
    SessionContext,
    resolve_references,
    session_context,
    update_context_from_result,
)
from command_layer.semantic_model import (
    SemanticDomain,
    SemanticAction,
    CommandIntent,
    AmbiguityType,
    ClarificationRequest,
    SymptomCategory,
    SituationType,
    ConfidenceTier,
    RiskTier,
    ConfidenceScore,
    ConfirmationRequest,
    FailureType,
    AdaptiveStrategy,
    PlanAdaptation,
    TaskLifecycleState,
    TaskMilestone,
    TaskCheckpoint,
    DomainBridgeType,
    DomainBridgeLink,
    CrossDomainWorkflow,
    HorizonDepth,
    ExplorationNode,
    SearchFrontier,
    LongHorizonReport,
    HistoryQueryType,
    ExecutionTraceRecord,
    TraceSummary,
)
from command_layer.semantic_parser import (
    parse_semantic_intent,
    create_plan_from_intent,
    resolve_in_turn_correction,
    strip_conversational_noise,
    split_compound_clauses,
    detect_symptom_category,
)
from command_layer.firewall import validate_tool_against_firewall, pre_execution_semantic_check, validate_long_horizon_action
from command_layer.state_machine import agent_state
from command_layer.validator import validate_and_sanitize_tool_arguments
from command_layer.lexer import UniversalLexer
from brain.runtime_bus import RuntimePipingBus
from security.state import confirmation_manager
from tools.utils.app_resolver import (
    APP_ALIASES,
    get_canonical_app_name,
    resolve_app,
)
from tools.utils.target_resolver import TargetType, resolve_universal_target, disambiguate_multi_candidates
from command_layer.router_base import (
    Step,
    run_tool_call,
    resolve_system_canonical_path,
    verify_post_recovery,
    verify_semantic_outcome,
    capture_environment_snapshot,
    capture_step_observation,
    detect_environment_drift,
    _entity_val,
    get_all_schemas,
    KNOWN_SITE_KEYS,
    KNOWN_APP_NAMES,
    _has_file_extension,
    _normalize_resolved_path,
    _is_conversational_folder_path,
)
from security.safety_firewall import is_safe_readonly_operation
from security.confirm import RISKY_TOOLS
from command_layer.decomposer import count_action_verbs
from brain.workflow_orchestrator import orchestrate_compound_workflow
from tools.browser import sanitize_search_query
from tools.search import parse_search_grammar
import executor.verifier
import executor.executor

from command_layer.router_sanitizer import (
    _isolate_browser_context,
    prune_negated_steps,
    sanitize_action_query,
    sanitize_url,
    _canonicalize_plan_tools,
    sanitize_ui_target,
    extract_clean_search_query,
)
from command_layer.router_cli_parser import (
    translate_cli_command,
    sanitize_cli_command,
    extract_pure_text_payload,
    parse_sequential_keyboard_actions,
    is_standalone_navigation_request,
    resolve_temporal_order,
    strip_idiomatic_conditions,
)
from command_layer.router_confidence import (
    determine_risk_tier,
    format_uncertainty_response,
    compute_command_confidence,
    synthesize_cross_domain_report,
    synthesize_long_horizon_report,
    get_conversational_response,
)
from command_layer.router_classifier_core import _classify_and_parse_command

from command_layer.router_rollback import execute_transactional_rollback
from command_layer.router_classifier_core import _classify_and_parse_command

def execute_step_precondition_and_dispatch(
    step: PlanStep,
    idx: int,
    plan: Plan,
    session_context: Any,
    step_results: dict[int, dict],
    output_messages: list[str],
    executed_tools: list[str],
    executed_args: list[dict],
    intermediate_traces: list[dict[str, Any]],
    step_contract_records: list[dict[str, Any]],
    unverified_steps: dict[int, str],
    exp_memory: Any,
    active_hypothesis_ledger: Any,
    agent_state: Any,
    dynamic_recovery_steps: int,
    raw_input: str,
) -> tuple[str, str | None, dict[str, Any] | None]:
    """
    Evaluates preconditions, variable resolution, firewall checks, and dispatches the tool call.
    Returns: (action, early_return_msg, result_dict)
    action is one of 'NEXT', 'CONTINUE', 'BREAK', 'EARLY_RETURN'
    """
    _time = time
    from command_layer.router_rollback import _is_step_dependent_on
    active_domain = getattr(plan, "domain", None) or SemanticDomain.UNKNOWN
    active_action = getattr(plan, "action", None) or SemanticAction.OPEN
    active_target = getattr(plan, "target", "") or ""
    semantic_intent = getattr(plan, "semantic_intent", None)
    normalized_input = raw_input
    trace_id = getattr(session_context, "current_trace_id", None) or f"trace_{int(time.time()*1000)}"
    step_caveat = ""
    # Bullet #26 Check for cooperative task pause request
    if session_context.is_task_pause_requested():
        remaining_steps = plan.steps[idx:]
        pending_plan = Plan(steps=remaining_steps, milestones=getattr(plan, "milestones", []), explanation=plan.explanation)
        completed_ids = [s.step for s in plan.steps[:idx]]
        tot = len(plan.steps)
        progress = (len(completed_ids) / tot) * 100.0 if tot > 0 else 0.0
        cp = TaskCheckpoint(
            task_id=agent_state.active_task_id or f"task_{int(_time.time())}",
            task_goal=raw_input,
            lifecycle_state=TaskLifecycleState.PAUSED,
            current_milestone_idx=0,
            completed_step_ids=completed_ids,
            pending_plan=pending_plan,
            saved_context_slots=dict(session_context.step_output_cache),
            progress_percent=progress,
        )
        session_context.save_task_checkpoint(cp)
        agent_state.transition_task_state(TaskLifecycleState.PAUSED)
        session_context.clear_task_pause_request()
        return "EARLY_RETURN", f"Task paused at step {idx}. Progress: {progress:.0f}%. Checkpoint saved. Say 'resume' to continue.", None
    # 0. Conditional Step Evaluation (Bullet #19 & Legacy Support)
    if step.condition_predicate or step.condition:
        cond_passed = True
        ref_res = None
        if step.condition and "step" in step.condition:
            ref_res = step_results.get(step.condition["step"])
        elif step_results:
            ref_res = step_results.get(max(step_results.keys()))
    
        actual_val = None
        if step.condition_predicate is not None:
            cond_passed = step.condition_predicate.evaluate(ref_res or {})
            val_key = step.condition_predicate.metric_key
            if ref_res and isinstance(ref_res, dict):
                actual_val = ref_res.get(val_key, ref_res.get(val_key.replace("usage_", "used_"), None))
                if actual_val is None:
                    for sub in ref_res.values():
                        if isinstance(sub, dict) and val_key in sub:
                            actual_val = sub[val_key]
                            return "BREAK", None, None
    
            branch_choice = "then" if cond_passed else ("else" if (step.on_false_steps or (isinstance(step.on_condition_false, list) and step.on_condition_false)) else "skipped")
            session_context.record_condition_outcome(
                step.condition_predicate,
                actual_value=actual_val,
                passed=cond_passed,
                branch_taken=branch_choice,
                step=step.step,
                tool=step.tool
            )
        elif ref_res is not None and step.condition:
            fld = step.condition.get("field")
            op = step.condition.get("op", "==")
            val = step.condition.get("value")
            actual = ref_res.get(fld)
            actual_val = actual
            if op == "==":
                cond_passed = (actual == val)
            elif op == "!=":
                cond_passed = (actual != val)
            elif op == ">=":
                cond_passed = (actual is not None and actual >= val)
            elif op == "<=":
                cond_passed = (actual is not None and actual <= val)
            elif op == ">":
                cond_passed = (actual is not None and actual > val)
            elif op == "<":
                cond_passed = (actual is not None and actual < val)
            elif op in ("truthy", "is_truthy", "not_empty"):
                cond_passed = bool(actual)
    
            branch_choice = "then" if cond_passed else ("else" if (isinstance(step.on_condition_false, list) and step.on_condition_false) else "skipped")
            session_context.record_condition_outcome(
                step.condition,
                actual_value=actual_val,
                passed=cond_passed,
                branch_taken=branch_choice,
                step=step.step,
                tool=step.tool
            )
    
        if cond_passed:
            print(f"[DEBUG_TRACE] CONDITION TRUE for step {step.step}: {step.condition_predicate or step.condition} (Branch: THEN)")
            if step.on_true_steps:
                for t_step in step.on_true_steps:
                    is_allowed, fw_err = pre_execution_semantic_check(
                        active_domain, active_action, active_target, t_step.tool, t_step.args,
                        constraints=getattr(t_step, "constraints", []) or getattr(step, "constraints", [])
                    )
                    if not is_allowed:
                        print(f"[DEBUG_TRACE] FIREWALL BLOCKED (THEN BRANCH): {fw_err}")
                        return f"Execution blocked by Safety Firewall: {fw_err}"
    
                    print(f"[DEBUG_TRACE] EXECUTING THEN STEP: {t_step.tool}({t_step.args})")
                    t_res = run_tool_call(t_step.tool, t_step.args)
                    step_results[t_step.step] = t_res
                    session_context.record_step_execution(t_step.step, t_step.tool, t_step.args, t_res)
                    update_context_from_result(session_context, t_step.tool, t_step.args, t_res)
                    executed_tools.append(t_step.tool)
                    executed_args.append(t_step.args)
                    output_messages.append(t_res.get("message", f"Step {t_step.step} completed."))
                pass  # step_idx handled by caller
                return "CONTINUE", None, None
        else:
            print(f"[DEBUG_TRACE] CONDITION FALSE for step {step.step}: {step.condition_predicate or step.condition} (Branch: ELSE)")
            alt_steps = step.on_false_steps or (step.on_condition_false if isinstance(step.on_condition_false, list) else [])
            if alt_steps:
                for alt_step in alt_steps:
                    is_allowed, fw_err = pre_execution_semantic_check(
                        active_domain, active_action, active_target, alt_step.tool, alt_step.args,
                        constraints=getattr(alt_step, "constraints", []) or getattr(step, "constraints", [])
                    )
                    if not is_allowed:
                        print(f"[DEBUG_TRACE] FIREWALL BLOCKED (ELSE BRANCH): {fw_err}")
                        return f"Execution blocked by Safety Firewall: {fw_err}"
    
                    print(f"[DEBUG_TRACE] EXECUTING ALTERNATIVE STEP: {alt_step.tool}({alt_step.args})")
                    alt_res = run_tool_call(alt_step.tool, alt_step.args)
                    step_results[alt_step.step] = alt_res
                    session_context.record_step_execution(alt_step.step, alt_step.tool, alt_step.args, alt_res)
                    update_context_from_result(session_context, alt_step.tool, alt_step.args, alt_res)
                    executed_tools.append(alt_step.tool)
                    executed_args.append(alt_step.args)
                    output_messages.append(alt_res.get("message", f"Step {alt_step.step} completed."))
                pass  # step_idx handled by caller
                return "CONTINUE", None, None
            elif step.on_condition_false == "halt":
                print(f"[DEBUG_TRACE] EXECUTION HALTED DUE TO CONDITION")
                return "BREAK", None, None
            else:
                pred_desc = f"{step.condition_predicate.metric_key} {step.condition_predicate.operator} {step.condition_predicate.threshold}" if step.condition_predicate else f"{step.condition.get('field')} {step.condition.get('op')} {step.condition.get('value')}"
                skip_msg = f"Condition not met: {pred_desc} (Actual: {actual_val}). Action '{step.tool}' skipped cleanly."
                print(f"[DEBUG_TRACE] {skip_msg}")
                output_messages.append(skip_msg)
                pass  # step_idx handled by caller
                return "CONTINUE", None, None
    
    resolved_args, guard_err = resolve_step_variables_with_guard(step.args, step_results, plan.steps)
    # Phase C: Dynamic Variable Resolver using extracted_metrics, preceding step buffers, and session state
    try:
        from brain.workflow_orchestrator import _resolve_step_variables
        resolved_args = _resolve_step_variables(resolved_args, session_context, step_results)
    except Exception:
        pass
    
    # Prompt D Step 3: Dependency Check - Stop on Unverified
    dep_bad_id = None
    dep_bad_status = None
    for bad_id, bad_stat in unverified_steps.items():
        if _is_step_dependent_on(step, bad_id, plan):
            dep_bad_id = bad_id
            dep_bad_status = bad_stat
            return "BREAK", None, None
    
    if dep_bad_id is not None:
        skip_msg = f"Dependency not verified (Step {dep_bad_id} was {dep_bad_status})"
        print(f"[DEBUG_TRACE] SKIPPED step {step.step} ({step.tool}): {skip_msg}")
        step_contract_records.append({
            "step": step.step,
            "tool": step.tool,
            "args": resolved_args,
            "status": "SKIPPED",
            "evidence": skip_msg,
            "reason": skip_msg,
        })
        exp_memory.record_step_contract_outcome(
            step=step.step,
            tool=step.tool,
            parameters=resolved_args,
            status="SKIPPED",
            evidence_summary=skip_msg,
        )
        step_results[step.step] = {
            "success": False,
            "status": "SKIPPED",
            "verified": False,
            "message": skip_msg,
            "reason": skip_msg,
        }
        unverified_steps[step.step] = "SKIPPED"
        pass  # step_idx handled by caller
        return "CONTINUE", None, None
    if guard_err:
        upstream_step = guard_err.get("step", 0)
        upstream_tool = "upstream_step"
        if 1 <= upstream_step <= len(plan.steps):
            upstream_tool = plan.steps[upstream_step - 1].tool
    
        err_type = guard_err.get("type")
        if err_type == "empty_candidates":
            abort_msg = f"Step {upstream_step} ({upstream_tool}) produced no candidates. Downstream step {step.tool} aborted safely."
        elif err_type == "missing_step":
            abort_msg = f"Step {upstream_step} not found in execution history. Downstream step {step.tool} aborted safely."
        elif err_type == "index_out_of_range":
            abort_msg = f"Step {upstream_step} ({upstream_tool}) candidate index {guard_err.get('index')} out of range. Downstream step {step.tool} aborted safely."
        elif err_type == "upstream_failed":
            abort_msg = f"Upstream step {upstream_step} ({upstream_tool}) failed: {guard_err.get('message')}. Downstream step {step.tool} aborted safely."
        else:
            abort_msg = f"Step {upstream_step} ({upstream_tool}) produced no valid output. Downstream step {step.tool} aborted safely."
    
        print(f"[DEBUG_TRACE] SHORT_CIRCUIT: {abort_msg}")
        intermediate_traces.append({
            "step": step.step,
            "tool": step.tool,
            "args": step.args,
            "result_status": "short_circuited",
            "verified": False,
            "abort_reason": abort_msg
        })
        agent_state.record_execution(
            trace_id=trace_id,
            user_cmd=raw_input,
            norm_cmd=normalized_input,
            domain=active_domain,
            action=active_action,
            tools=executed_tools + [step.tool],
            args=executed_args + [step.args],
            success=False,
            verified=False,
            status="short_circuited",
            failure_reason=abort_msg,
            intermediate_traces=intermediate_traces
        )
        return abort_msg
    
    # Downstream parameter normalization for chained process status
    if step.tool == "get_process_status" and "pid" in resolved_args and "name_or_pid" not in resolved_args:
        resolved_args["name_or_pid"] = str(resolved_args["pid"])
    if step.tool == "copy_file":
        if "src" in resolved_args and "source" not in resolved_args:
            resolved_args["source"] = resolved_args["src"]
        if "dest" in resolved_args and "destination" not in resolved_args:
            resolved_args["destination"] = resolved_args["dest"]
    
    # Confidence Calibration & Execution Gating (Bullet #20)
    step_conf = compute_command_confidence(
        user_cmd=raw_input,
        domain=active_domain,
        action=active_action,
        target=active_target,
        tool_name=step.tool,
        args=resolved_args,
        context=session_context
    )
    step_risk = determine_risk_tier(step.tool, resolved_args)
    step.confidence_score = step_conf
    step.risk_tier = step_risk
    session_context.record_confidence_score(step_conf)
    
    # 1. High Destructive Risk Gating: requires explicit interactive confirmation
    is_step_confirmed = (
        "confirmed" in (step.constraints or [])
        or "confirmed" in (plan.constraints or [])
        or ("confirmed" in raw_input.lower())
        or getattr(step, "is_adapted", False)
    )
    if step_risk == RiskTier.HIGH_DESTRUCTIVE and not is_step_confirmed:
        conf_target = active_target or resolved_args.get("path") or resolved_args.get("name") or resolved_args.get("name_or_pid") or resolved_args.get("query") or "target"
        conf_prompt = f"Confirmation required: Are you sure you want to execute '{step.tool}' on '{conf_target}'? Risk: HIGH_DESTRUCTIVE (Confidence: {step_conf.overall_score:.2f}). Confirm? (yes/no)"
        req = ConfirmationRequest(
            action=active_action.value if hasattr(active_action, "value") else str(active_action),
            tool=step.tool,
            args=resolved_args,
            target=str(conf_target),
            domain=active_domain.value if hasattr(active_domain, "value") else str(active_domain),
            confidence_score=step_conf,
            risk_tier=step_risk,
            prompt_message=conf_prompt
        )
        session_context.set_pending_confirmation(req)
        confirmation_manager.set_pending(step.tool, resolved_args, conf_prompt)
        return conf_prompt
    
    # 2. Low Confidence Gating: halt execution and return honest uncertainty + options
    if step_conf.tier == ConfidenceTier.LOW:
        agent_state.record_execution(
            trace_id=trace_id,
            user_cmd=raw_input,
            norm_cmd=normalized_input,
            domain=active_domain,
            action=active_action,
            tools=[step.tool],
            args=[resolved_args],
            success=False,
            verified=False,
            status="gated_low_confidence",
            failure_reason=f"Confidence too low ({step_conf.overall_score:.2f}) for deterministic execution",
            intermediate_traces=intermediate_traces
        )
        msg = format_uncertainty_response(step_conf)
        print(f"[DEBUG_TRACE] LOW CONFIDENCE GATED: {step_conf.overall_score:.2f}")
        return msg
    
    # 3. Medium Confidence: prepare caveat for safe read-only actions
    step_caveat = ""
    if step_conf.tier == ConfidenceTier.MEDIUM and step_risk == RiskTier.READ_ONLY:
        step_caveat = f"\n(Note: Executed with moderate confidence [{step_conf.overall_score:.2f}]: {step_conf.reasoning})"
    
    # 1. Tool Selection Firewall & Pre-Execution Semantic Validation
    constraints = getattr(step, "constraints", []) or []
    if semantic_intent and getattr(semantic_intent, "constraints", None):
        constraints = list(set(constraints + semantic_intent.constraints))
    negations = getattr(semantic_intent, "negations", []) or []
    is_negated = getattr(step, "is_negated", False) or (semantic_intent.is_negated if semantic_intent else False)
    
    # Mandate 4: Semantic Negation Disarm Filter
    # When a clause contains negation markers (mat, nahi, don't, stop), disarm destructive or click actuators
    # for that clause and convert to passive observation/hover.
    step_raw = getattr(step, "raw_clause", "") or raw_input
    clause_negated = is_negated or (UniversalLexer.should_disarm_click(step_raw) if step.tool in ("click_mouse", "mouse_click", "click_ui_element", "click_element_by_text") else False)
    if clause_negated:
        if step.tool in ("click_mouse", "mouse_click", "click_ui_element", "click_element_by_text"):
            step.tool = "hover_mouse"
            if "click_type" in resolved_args:
                del resolved_args["click_type"]
            resolved_args.setdefault("duration", 1.0)
        elif step.tool in ("delete_file", "delete_folder", "remove_file", "format_disk"):
            step.tool = "inspect_screen"
            resolved_args = {}
    
    # Multi-Domain Firewall Isolation: Validate each atomic step against its native domain
    step_domain, step_action = active_domain, active_action
    if (plan and len(plan.steps) > 1) or active_domain in (SemanticDomain.UNKNOWN, SemanticDomain.DIAGNOSTICS):
        from command_layer.firewall import get_native_domain_and_action, ALLOWED_TOOLS_MAP
        nat_domain, nat_action = get_native_domain_and_action(step.tool)
        allowed = ALLOWED_TOOLS_MAP.get((active_domain, active_action))
        if allowed is None or step.tool not in allowed:
            step_domain, step_action = nat_domain, nat_action
        elif plan and len(plan.steps) > 1 and nat_domain != SemanticDomain.UNKNOWN:
            step_domain, step_action = nat_domain, nat_action
    
    is_allowed, firewall_err = pre_execution_semantic_check(
        step_domain,
        step_action,
        active_target,
        step.tool,
        resolved_args,
        constraints=constraints,
        negations=negations,
        is_negated=is_negated,
        confirmed=is_step_confirmed
    )
    if not is_allowed:
        agent_state.record_execution(
            trace_id=trace_id,
            user_cmd=raw_input,
            norm_cmd=normalized_input,
            domain=step_domain,
            action=step_action,
            tools=[step.tool],
            args=[resolved_args],
            success=False,
            verified=False,
            status="firewall_blocked",
            failure_reason=firewall_err
        )
        print(f"[DEBUG_TRACE] FIREWALL BLOCKED: {firewall_err}")
        return f"Execution blocked by Safety Firewall: {firewall_err}"
    
    # 2. Pre-Execution Argument Validation
    is_valid, sanitized_args, val_err = validate_and_sanitize_tool_arguments(step.tool, resolved_args)
    if not is_valid:
        agent_state.record_execution(
            trace_id=trace_id,
            user_cmd=raw_input,
            norm_cmd=normalized_input,
            domain=step_domain,
            action=step_action,
            tools=[step.tool],
            args=[resolved_args],
            success=False,
            verified=False,
            status="validation_failed",
            failure_reason=val_err
        )
        print(f"[DEBUG_TRACE] VALIDATION FAILED: {val_err}")
        return f"Argument validation failed for {step.tool}: {val_err}"
    
    # Prompt D Step 2: Evaluate independent Precondition
    from executor.truth_oracle import evaluate_step_precondition
    contract_pre_obs = evaluate_step_precondition(step.tool, sanitized_args, session_context)
    if not contract_pre_obs.is_verified:
        fail_status = contract_pre_obs.status  # "FAILED" or "UNVERIFIED"
        fail_reason = contract_pre_obs.reason
        print(f"[DEBUG_TRACE] CONTRACT PRECONDITION {fail_status} for step {step.step} ({step.tool}): {fail_reason}")
        step_contract_records.append({
            "step": step.step,
            "tool": step.tool,
            "args": sanitized_args,
            "status": fail_status,
            "evidence": contract_pre_obs.evidence or fail_reason,
            "reason": fail_reason,
        })
        exp_memory.record_step_contract_outcome(
            step=step.step,
            tool=step.tool,
            parameters=sanitized_args,
            status=fail_status,
            evidence_summary=contract_pre_obs.evidence or fail_reason,
        )
        step_results[step.step] = {
            "success": False,
            "status": fail_status,
            "verified": False,
            "message": fail_reason,
            "reason": fail_reason,
        }
        unverified_steps[step.step] = fail_status
    
    # Bullet #24: Pre-Step Precondition Sensing & Closed-Loop Environmental Stabilization
    import executor.verifier
    pre_snap = executor.verifier.capture_environment_snapshot()
    session_context.record_environment_snapshot(pre_snap)
    
    gui_tools = {"type_text", "click_mouse", "press_key", "hotkey", "click_ui_element", "manage_window", "write_clipboard"}
    if step.tool in gui_tools:
        expected_win = None
        if getattr(step, "precondition_observation", None):
            expected_win = step.precondition_observation.get("active_window")
        elif session_context.observation_history:
            prev_obs = session_context.observation_history[-1]
            if prev_obs.tool in ("launch_app", "focus_window", "manage_window"):
                expected_win = (
                    prev_obs.physical_state.get("target_app")
                    or prev_obs.raw_evidence.get("name")
                    or prev_obs.physical_state.get("active_window")
                    or prev_obs.physical_state.get("title")
                )
    
        if expected_win and (not pre_snap.active_window or expected_win.lower() not in pre_snap.active_window.lower()):
            print(f"[DEBUG_TRACE] PRECONDITION DRIFT: Active window '{pre_snap.active_window}' != expected '{expected_win}'. Refocusing...")
            try:
                import tools.window
                tools.window.focus_window(app_name=expected_win)
            except Exception:
                pass
    
    # Low-RAM Sentry & Crash-Proof Supervisor step dispatch
    try:
        from tools.system_sentry import check_and_enforce_ram_headroom
        check_and_enforce_ram_headroom()
    except Exception:
        pass
    
    # Before executing type_text or send_keyboard_input: expand template placeholders
    if step.tool in ("type_text", "send_keyboard_input", "type_desktop_text"):
        try:
            from brain.workflow_orchestrator import expand_template_placeholders
            curr_text = sanitized_args.get("text")
            if curr_text is None or str(curr_text).strip() in ("", "$last_output", "[output]"):
                curr_text = getattr(session_context, "last_cli_output", None) or getattr(session_context, "captured_values", {}).get("output", "")
            if curr_text is not None:
                expanded = expand_template_placeholders(curr_text, session_context)
                sanitized_args["text"] = str(expanded)
                if hasattr(step, "args") and isinstance(step.args, dict):
                    step.args["text"] = str(expanded)
        except Exception:
            pass
    
    # Self-Healing Pre-Flight Focus Latch
    app_hint = sanitized_args.get('app_name', '') or sanitized_args.get('name', '')
    if app_hint and step.tool in ('type_text', 'send_keyboard_input', 'click_ui_element', 'click_mouse'):
        try:
            from brain.cognitive_reflector import CognitiveReflector
            CognitiveReflector.verify_window_latch(str(app_hint))
        except Exception:
            pass
    
    # Prompt I Step 1 & 3: Experience Memory Lookup before step execution
    active_remedy = exp_memory.lookup(
        tool=step.tool,
        args=sanitized_args,
        app=str(sanitized_args.get("name") or sanitized_args.get("app_name") or ""),
    )
    active_remedy_action = ""
    active_remedy_args = None
    if active_remedy:
        active_remedy_action = active_remedy.get("remedy_action", "")
        active_remedy_args = active_remedy.get("remedy_args", {})
        if active_remedy_args:
            sanitized_args.update(active_remedy_args)
        print(f"[DEBUG_TRACE] APPLIED PROMOTED REMEDY: '{active_remedy_action}' for step {step.step} ({step.tool})")
    
    print(f"[DEBUG_TRACE] STEP {idx}: {step.tool}({sanitized_args})")
    from executor.executor import supervise_step_execution
    from command_layer.router import run_tool_call as _router_run_tool
    from command_layer.router_base import run_tool_call as _orig_run_tool
    if _router_run_tool is not _orig_run_tool:
        result = _router_run_tool(step.tool, sanitized_args)
    else:
        result = supervise_step_execution(step, session_context, sanitized_args=sanitized_args)
    executed_tools.append(step.tool)
    executed_args.append(sanitized_args)
    
    # When execute_system_command executes: save trimmed stdout into session_context.last_cli_output and captured_values['output']
    if step.tool in ("execute_system_command", "run_headless_shell", "execute_command"):
        try:
            from brain.workflow_orchestrator import record_text_buffer_output
            record_text_buffer_output(step.tool, result, session_context)
        except Exception:
            pass
    
    if result.get("needs_confirmation"):
        conf_target = active_target or sanitized_args.get("path") or sanitized_args.get("name") or sanitized_args.get("name_or_pid") or "target"
        conf_prompt = f"Confirmation required: Are you sure you want to execute '{step.tool}' on '{conf_target}'? Risk: HIGH_DESTRUCTIVE (Confidence: {step_conf.overall_score:.2f}). Confirm? (yes/no)"
        req = ConfirmationRequest(
            action=active_action.value if hasattr(active_action, "value") else str(active_action),
            tool=step.tool,
            args=sanitized_args,
            target=str(conf_target),
            domain=active_domain.value if hasattr(active_domain, "value") else str(active_domain),
            confidence_score=step_conf,
            risk_tier=step_risk,
            prompt_message=conf_prompt
        )
        session_context.set_pending_confirmation(req)
        confirmation_manager.set_pending(step.tool, sanitized_args, result.get("message", conf_prompt))
        return "EARLY_RETURN", f"{result['message']} Confirm? (yes/no)", None
    

    if isinstance(result, dict) and step_caveat:
        result["step_caveat"] = step_caveat
    return "NEXT", None, result
