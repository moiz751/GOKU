from __future__ import annotations
import os
import re
import sys
from typing import Any, Optional, Dict, List, Set, Tuple

from command_layer.semantic_model import (
    SemanticDomain,
    SemanticAction,
    RequestType,
    EntityType,
    CommandIntent,
    AmbiguityType,
    ClarificationRequest,
    SymptomCategory,
    SituationType,
    ConfidenceTier,
    RiskTier,
    ConfidenceScore,
    ConfirmationRequest,
    FailureType,
    AdaptiveStrategy,
    PlanAdaptation,
    TaskLifecycleState,
    TaskMilestone,
    TaskCheckpoint,
    DomainBridgeType,
    DomainBridgeLink,
    CrossDomainWorkflow,
    HorizonDepth,
    ExplorationNode,
    SearchFrontier,
    LongHorizonReport,
    HistoryQueryType,
    ExecutionTraceRecord,
    TraceSummary,
)
from brain.planner import Plan, PlanStep

from command_layer.capability_extractor_system import _extract_system_capabilities
from command_layer.capability_extractor_apps import _extract_app_and_ui_capabilities

def _extract_generalized_capability(text: str, lower: str, quoted_strings: list[str]) -> Optional[CommandIntent]:
    res = _extract_system_capabilities(text, lower, quoted_strings)
    if res is not None:
        return res
    return _extract_app_and_ui_capabilities(text, lower, quoted_strings)
