"""
Conversational State Machine, Typed Context Stack, and Execution History for MARK/GOKU Agent.
Tracks active task, domains, UI/mouse targets, search objectives, corrections,
and structured execution history for self-observation and failure audit (Item 3, 4, 12, 26).
"""
from dataclasses import dataclass, field
import datetime
import time
from typing import Any, Optional
from command_layer.semantic_model import SemanticDomain, SemanticAction, TaskLifecycleState


@dataclass
class ExecutionRecord:
    """Structured record of a command execution turn (Item 12)."""
    trace_id: str
    timestamp: float
    raw_command: str
    normalized_command: str
    intent: str
    domain: str
    action: str
    selected_tool: str
    arguments: dict[str, Any]
    execution_result: dict[str, Any]
    verification_result: dict[str, Any]
    failure_reason: Optional[str] = None
    recovery_attempt: Optional[str] = None
    final_status: str = "completed"  # completed, failed, unverified, blocked, partial
    intermediate_traces: list[dict[str, Any]] = field(default_factory=list)


    @property
    def user_command(self) -> str:
        return self.raw_command

    @property
    def tools(self) -> list[str]:
        if self.intermediate_traces:
            tr_tools = [t["tool"] for t in self.intermediate_traces if isinstance(t, dict) and "tool" in t]
            if tr_tools:
                return tr_tools
        return [self.selected_tool] if self.selected_tool else []

    @property
    def status(self) -> str:
        return self.final_status

    @property
    def verified(self) -> bool:
        return bool(self.verification_result.get("verified", False))

    def to_dict(self) -> dict[str, Any]:
        iso_time = datetime.datetime.fromtimestamp(self.timestamp).strftime("%Y-%m-%d %H:%M:%S")
        return {
            "trace_id": self.trace_id,
            "timestamp": iso_time,
            "raw_command": self.raw_command,
            "user_command": self.raw_command,
            "normalized_command": self.normalized_command,
            "intent": self.intent,
            "domain": self.domain,
            "action": self.action,
            "selected_tool": self.selected_tool,
            "tools": [self.selected_tool] if self.selected_tool else [],
            "arguments": self.arguments,
            "execution_result": self.execution_result,
            "verification_result": self.verification_result,
            "verified": self.verified,
            "failure_reason": self.failure_reason,
            "recovery_attempt": self.recovery_attempt,
            "final_status": self.final_status,
            "status": self.final_status,
            "intermediate_traces": self.intermediate_traces,
        }


class ConversationalStateMachine:
    """Singleton managing active conversational context, task stack, and history."""

    def __init__(self):
        self.clear()

    def clear(self):
        self.active_task: Optional[str] = None
        self.current_domain: SemanticDomain = SemanticDomain.UNKNOWN
        self.last_domain: SemanticDomain = SemanticDomain.UNKNOWN
        self.current_target: Optional[str] = None
        self.current_application: Optional[str] = None
        self.current_window: Optional[str] = None
        self.current_browser: Optional[str] = None
        self.current_page: Optional[str] = None
        self.current_search: Optional[dict[str, Any]] = None  # {"query": ..., "domain": ..., "platform": ...}
        self.last_search_query: Optional[str] = None
        self.current_results: list[Any] = []
        self.current_result_type: Optional[str] = None
        self.current_ui_target: Optional[str] = None
        self.current_mouse_target: Optional[dict[str, Any]] = None  # {"target_query": ..., "coords": ...}
        self.current_file: Optional[str] = None
        self.current_folder: Optional[str] = None
        
        self.last_action: Optional[SemanticAction] = None
        self.last_result: Optional[dict[str, Any]] = None
        self.last_failure: Optional[dict[str, Any]] = None
        self.last_success: Optional[dict[str, Any]] = None
        self.last_user_correction: Optional[str] = None
        self.pending_task: Optional[str] = None
        self.unresolved_user_intent: Optional[str] = None
        self.previous_assistant_clarification: Optional[str] = None

        # Bullet #26: Task Lifecycle State
        self.task_state: TaskLifecycleState = TaskLifecycleState.NOT_STARTED
        self.active_task_id: Optional[str] = None

        self.execution_history: list[ExecutionRecord] = []
        self._trace_counter: int = 0

    VALID_TASK_TRANSITIONS = {
        TaskLifecycleState.NOT_STARTED: {TaskLifecycleState.IN_PROGRESS},
        TaskLifecycleState.IN_PROGRESS: {TaskLifecycleState.PAUSED, TaskLifecycleState.COMPLETED, TaskLifecycleState.CANCELLED},
        TaskLifecycleState.PAUSED: {TaskLifecycleState.RESUMING, TaskLifecycleState.CANCELLED, TaskLifecycleState.NOT_STARTED, TaskLifecycleState.COMPLETED},
        TaskLifecycleState.RESUMING: {TaskLifecycleState.IN_PROGRESS, TaskLifecycleState.PAUSED, TaskLifecycleState.CANCELLED, TaskLifecycleState.COMPLETED},
        TaskLifecycleState.COMPLETED: {TaskLifecycleState.NOT_STARTED, TaskLifecycleState.IN_PROGRESS},
        TaskLifecycleState.CANCELLED: {TaskLifecycleState.NOT_STARTED, TaskLifecycleState.IN_PROGRESS},
    }

    def can_transition(self, to_state: TaskLifecycleState) -> bool:
        """Determines if the requested task state transition is valid from current state (Bullet #26)."""
        allowed = self.VALID_TASK_TRANSITIONS.get(self.task_state, set())
        return to_state in allowed

    def transition_task_state(self, new_state: TaskLifecycleState | str, task_id: Optional[str] = None) -> TaskLifecycleState:
        """
        Transitions the multi-step task lifecycle state machine (Bullet #26).
        Enforces deterministic state transitions and rejects illegal transitions.
        """
        if isinstance(new_state, str):
            for state in TaskLifecycleState:
                if state.value.lower() == new_state.lower() or state.name.lower() == new_state.lower():
                    new_state = state
                    break
            else:
                raise ValueError(f"Unknown TaskLifecycleState: {new_state}")

        if new_state == self.task_state:
            return self.task_state

        if not self.can_transition(new_state):
            raise ValueError(
                f"Invalid task lifecycle transition: Illegal task state transition from {self.task_state.name} to {new_state.name}."
            )

        self.task_state = new_state
        if task_id:
            self.active_task_id = task_id
        elif new_state in (TaskLifecycleState.COMPLETED, TaskLifecycleState.CANCELLED, TaskLifecycleState.NOT_STARTED):
            self.active_task_id = None

        return self.task_state

    def get_task_state(self) -> TaskLifecycleState:
        """Returns the current task lifecycle state."""
        return self.task_state

    def start_trace(self, user_cmd: str, norm_cmd: str) -> str:
        self._trace_counter += 1
        return f"trace_{self._trace_counter}_{int(time.time())}"

    def record_execution(
        self,
        trace_id: str,
        user_cmd: str,
        norm_cmd: str,
        domain: SemanticDomain,
        action: SemanticAction,
        tools: list[str],
        args: list[dict[str, Any]],
        success: bool,
        verified: bool,
        status: str,
        failure_reason: Optional[str] = None,
        results: list[dict[str, Any]] | None = None,
        verification_result: dict[str, Any] | None = None,
        recovery_attempt: Optional[str] = None,
        intermediate_traces: Optional[list[dict[str, Any]]] = None
    ) -> ExecutionRecord:
        primary_tool = tools[0] if tools else "none"
        primary_args = args[0] if args else {}
        primary_res = (results[0] if results else {}) if results else {}

        d_val = domain.value if hasattr(domain, "value") else str(domain)
        a_val = action.value if hasattr(action, "value") else str(action)
        rec = ExecutionRecord(
            trace_id=trace_id,
            timestamp=time.time(),
            raw_command=user_cmd,
            normalized_command=norm_cmd,
            intent=f"{d_val}:{a_val}",
            domain=d_val,
            action=a_val,
            selected_tool=primary_tool,
            arguments=primary_args,
            execution_result=primary_res,
            verification_result=verification_result or {"verified": verified},
            failure_reason=failure_reason,
            recovery_attempt=recovery_attempt,
            final_status=status,
            intermediate_traces=intermediate_traces or []
        )
        self.execution_history.append(rec)
        self.last_domain = self.current_domain
        self.current_domain = domain

        if success and verified:
            self.last_success = rec.to_dict()
            self.last_action = action
            if primary_args.get("path"):
                self.current_target = str(primary_args["path"])
                self.current_file = str(primary_args["path"])
            elif primary_args.get("name"):
                self.current_target = str(primary_args["name"])
                self.current_application = str(primary_args["name"])
        else:
            self.last_failure = rec.to_dict()
            # FAILURE ISOLATION (Bullet #6):
            # Failed or blocked actions must NEVER remain as the current active target in the state stack!
            self.current_target = None
            self.current_file = None
            self.current_application = None

        return rec

    @property
    def history(self) -> list[dict[str, Any]]:
        """Ergonomic property: returns execution_history as list of dicts for indexed access."""
        return [r.to_dict() for r in self.execution_history]

    def get_failed_commands(self) -> list[ExecutionRecord]:
        return [
            r for r in self.execution_history
            if r.final_status in ("failed", "unverified", "blocked") or (r.failure_reason is not None)
        ]

    def get_last_command(self) -> Optional[ExecutionRecord]:
        return self.execution_history[-1] if self.execution_history else None

    def get_last_failure(self) -> Optional[ExecutionRecord]:
        failed = self.get_failed_commands()
        return failed[-1] if failed else None

    def format_failure_report(self) -> str:
        """Constructs truthful human-readable failure report from real execution records (Item 12)."""
        failed = self.get_failed_commands()
        if not failed:
            return "No failed commands found in recent execution history."

        lines = [f"Execution History Audit: {len(failed)} command(s) encountered failures:\n"]
        for i, f in enumerate(failed, 1):
            iso_time = datetime.datetime.fromtimestamp(f.timestamp).strftime("%H:%M:%S")
            lines.append(f"{i}. [{iso_time}] Command: \"{f.raw_command}\"")
            lines.append(f"   Domain: {f.domain} | Tool: {f.selected_tool}")
            lines.append(f"   Status: {f.final_status}")
            if f.failure_reason:
                lines.append(f"   Failure Reason: {f.failure_reason}")
            if f.recovery_attempt:
                lines.append(f"   Recovery Attempt: {f.recovery_attempt}")
            lines.append("")
        return "\n".join(lines).strip()


# Global state machine instance
agent_state = ConversationalStateMachine()
