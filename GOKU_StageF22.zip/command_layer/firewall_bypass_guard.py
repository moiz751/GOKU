"""
Adversarial Firewall Bypass Guard.
Detects and blocks obfuscated, recursive, and subversive bypass attempts:
1. Case permutations (e.g. dEl /S, FoRmAt)
2. Unicode lookalikes, full-width homoglyphs, zero-width spaces
3. Quote de-obfuscation (e.g. "del" /s, d"e"l, 'format')
4. Environment variable obfuscation (%COMSPEC%, %SYSTEMROOT%, $env:TEMP)
5. Short 8.3 filename aliases (PROGRA~1, WINDOW~1, SYSTEM~1)
6. Recursive file deletion (del /s, del -s)
7. Directory removal (rd, rmdir)
8. Disk formatting (format, format.com)
9. Base64 encoded PowerShell (powershell -enc, -encodedcommand, pwsh -e)
10. Directory traversal (../, ..\\, %2e%2e)
11. Malicious or escaped symlink traversal
"""
from __future__ import annotations

import os
from pathlib import Path
import re
from typing import Any, Tuple
import unicodedata

# Cyrillic and unicode homoglyphs mapped to ASCII Latin
HOMOGLYPH_MAP = str.maketrans({
    '\u0430': 'a', '\u0410': 'A',
    '\u0441': 'c', '\u0421': 'C',
    '\u0435': 'e', '\u0415': 'E',
    '\u043e': 'o', '\u041e': 'O',
    '\u0440': 'p', '\u0420': 'P',
    '\u0445': 'x', '\u0425': 'X',
    '\u0443': 'y', '\u0423': 'Y',
    '\u0456': 'i', '\u0406': 'I',
    '\u0455': 's', '\u0405': 'S',
    '\u0458': 'j', '\u0408': 'J',
    '\u0432': 'b', '\u0412': 'B',
    '\u043d': 'h', '\u041d': 'H',
    '\u0442': 't', '\u0422': 'T',
    '\u043c': 'm', '\u041c': 'M',
    '\u043a': 'k', '\u041a': 'K',
})

# Known 8.3 aliases
SHORT_NAME_MAP = {
    "progra~1": "program files",
    "progra~2": "program files (x86)",
    "window~1": "windows",
    "system~1": "system32",
    "locals~1": "local settings",
    "appdata": "appdata",
}

# Protected system prefixes
PROTECTED_SYSTEM_PATHS = [
    r"c:\windows",
    r"c:\windows\system32",
    r"c:\program files",
    r"c:\program files (x86)",
    r"c:\programdata",
    r"system32",
]


def normalize_adversarial_text(raw_text: str) -> str:
    """
    Normalizes unicode, homoglyphs, quotes, environment variables, and 8.3 aliases
    into a canonical plain lowercase ASCII string for security inspection.
    """
    if not raw_text or not isinstance(raw_text, str):
        return ""

    # 1. Unicode NFKD normalization (converts full-width \uff44\uff45\uff4c to del)
    norm = unicodedata.normalize("NFKD", raw_text)

    # 2. Translate Cyrillic/Greek homoglyphs
    norm = norm.translate(HOMOGLYPH_MAP)

    # 3. Strip zero-width spaces and control characters
    norm = re.sub(r'[\u200b-\u200f\ufeff\x00-\x08\x0b\x0c\x0e-\x1f]', '', norm)

    # 4. Canonical lowercase
    norm = norm.lower()

    # 5. Environment variable expansion (Windows cmd %VAR% and PowerShell $env:VAR)
    env_replacements = {
        "%comspec%": "cmd.exe",
        "%systemroot%": "c:\\windows",
        "%windir%": "c:\\windows",
        "%programfiles%": "c:\\program files",
        "%programfiles(x86)%": "c:\\program files (x86)",
        "%programdata%": "c:\\programdata",
        "%temp%": "c:\\temp",
        "%tmp%": "c:\\temp",
        "$env:comspec": "cmd.exe",
        "$env:systemroot": "c:\\windows",
        "$env:windir": "c:\\windows",
        "$env:programfiles": "c:\\program files",
        "$env:temp": "c:\\temp",
    }
    for var, rep in env_replacements.items():
        if var in norm:
            norm = norm.replace(var, rep)

    # Expand any remaining standard os.environ variables
    try:
        norm = os.path.expandvars(norm).lower()
    except Exception:
        pass

    # 6. Expand 8.3 short names
    for short_name, expanded in SHORT_NAME_MAP.items():
        if short_name in norm:
            norm = norm.replace(short_name, expanded)

    return norm


def strip_internal_quotes(text: str) -> str:
    """Removes quotes, backticks, and carats (CMD escape char ^) within tokens."""
    return re.sub(r'[\'\"`\^]', '', text)


def inspect_firewall_bypass(tool_name: str, args: dict[str, Any]) -> Tuple[bool, str | None]:
    """
    Evaluates tool calls for adversarial bypass attempts across:
    case, unicode, quotes, environment variables, 8.3 short names,
    del /s, rd/rmdir, format, powershell -enc, path traversal, symlinks.

    Returns:
        (is_blocked, block_reason)
    """
    t_name = (tool_name or "").strip().lower()
    all_values = [str(v) for v in args.values() if v is not None]
    raw_payload = " ".join(all_values)

    # 1. Base normalized string
    norm_text = normalize_adversarial_text(raw_payload)
    unquoted_text = strip_internal_quotes(norm_text)

    # ---------------------------------------------------------
    # Check 1: Encoded PowerShell (powershell -enc, -encodedcommand, pwsh -e)
    # ---------------------------------------------------------
    enc_patterns = [
        r'\b(?:powershell|pwsh)(?:\.exe)?\s+(?:-[a-z0-9]*e(?:nc(?:odedcommand)?)?)\b',
        r'-(?:e|enc|encodedcommand)\s+[A-Za-z0-9+/=]{4,}',
    ]
    for pat in enc_patterns:
        if re.search(pat, norm_text) or re.search(pat, unquoted_text) or re.search(pat, raw_payload, re.IGNORECASE):
            return True, "FIREWALL BLOCKED: Encoded PowerShell execution (-enc/-encodedcommand) is strictly prohibited."

    # ---------------------------------------------------------
    # Check 2: Recursive Del (`del /s`, `del -s`)
    # ---------------------------------------------------------
    del_s_patterns = [
        r'\bdel\b[^\n\r]*[\/\-]\s*s\b',
        r'[\/\-]\s*s\b[^\n\r]*\bdel\b',
        r'\berase\b[^\n\r]*[\/\-]\s*s\b',
    ]
    for pat in del_s_patterns:
        if re.search(pat, norm_text) or re.search(pat, unquoted_text):
            return True, "FIREWALL BLOCKED: Recursive file deletion ('del /s') is strictly prohibited."

    # ---------------------------------------------------------
    # Check 3: Directory Removal (`rd`, `rmdir`)
    # ---------------------------------------------------------
    rd_patterns = [
        r'\b(?:rd|rmdir)\b(?:\s+[\/\-][a-z0-9]+)*\s+[a-z0-9_\-\.:\\\/]+',
        r'\b(?:rd|rmdir)\b',
    ]
    for pat in rd_patterns:
        if re.search(pat, norm_text) or re.search(pat, unquoted_text):
            return True, "FIREWALL BLOCKED: Directory removal command ('rd' / 'rmdir') is strictly prohibited."

    # ---------------------------------------------------------
    # Check 4: Disk Formatting (`format`)
    # ---------------------------------------------------------
    format_patterns = [
        r'\bformat(?:\.com)?\s+[a-z](?::|\b)',
        r'\bformat\s+(?:disk|drive|partition|hard\s*disk)\b',
        r'\bformat\s*[\/\-][a-z0-9]',
        r'\b(?:diskpart|format\.exe)\b',
    ]
    for pat in format_patterns:
        if re.search(pat, norm_text) or re.search(pat, unquoted_text):
            return True, "FIREWALL BLOCKED: Disk format command ('format') is strictly prohibited."

    # ---------------------------------------------------------
    # Check 5: 8.3 Short Name System Target Access
    # ---------------------------------------------------------
    short_83_indicators = ["progra~1", "progra~2", "window~1", "system~1"]
    if any(s in norm_text for s in short_83_indicators) or any(s in raw_payload.lower() for s in short_83_indicators):
        # Destructive or system root targeting via 8.3 alias
        if t_name in ("delete_file", "delete_folder", "execute_command", "run_cli", "create_file", "write_file"):
            return True, "FIREWALL BLOCKED: Obfuscated 8.3 short filename targeting protected system directory."

    # ---------------------------------------------------------
    # Check 6: Path Traversal (../, ..\, %2e%2e, relative escape)
    # ---------------------------------------------------------
    for path_key in ("path", "folder_path", "file_path", "destination", "source", "filepath", "command"):
        if path_key in args:
            pval = str(args[path_key])
            p_norm = normalize_adversarial_text(pval)
            p_unquoted = strip_internal_quotes(p_norm)
            if ".." in p_norm or ".." in p_unquoted or "%2e%2e" in p_norm:
                if any(crit in p_norm or crit in p_unquoted for crit in ["system32", "windows", "program files", "programdata"]):
                    return True, f"FIREWALL BLOCKED: Illegal directory traversal targeting protected system path '{pval}'."
                # Check resolved path if it points to root system
                try:
                    resolved = Path(p_unquoted).resolve()
                    res_str = str(resolved).lower()
                    if any(res_str == p or res_str.startswith(p + "\\") for p in PROTECTED_SYSTEM_PATHS):
                        return True, f"FIREWALL BLOCKED: Directory traversal resolves to protected system path '{res_str}'."
                except Exception:
                    return True, f"FIREWALL BLOCKED: Malformed directory traversal in '{pval}'."

    # ---------------------------------------------------------
    # Check 7: Symlink Traversal, Reparse Points & Malicious Symlink Creation
    # ---------------------------------------------------------
    if re.search(r'\bmklink\b', norm_text) or re.search(r'\bnew-item\b[^\n\r]*symboliclink\b', norm_text):
        if any(sp in norm_text for sp in ["c:\\windows", "system32", "program files"]):
            return True, "FIREWALL BLOCKED: Symlink creation targeting protected system root is strictly prohibited."

    for path_key in ("path", "folder_path", "file_path", "destination", "source", "filepath"):
        if path_key in args:
            pval = str(args[path_key])
            try:
                p_obj = Path(strip_internal_quotes(normalize_adversarial_text(pval)))
                if p_obj.is_symlink() or (p_obj.exists() and hasattr(p_obj, "is_junction") and p_obj.is_junction()):
                    target_res = str(p_obj.resolve()).lower()
                    if any(target_res == sp or target_res.startswith(sp + "\\") for sp in PROTECTED_SYSTEM_PATHS):
                        return True, f"FIREWALL BLOCKED: Symlink points to protected system target '{target_res}'."
            except Exception:
                pass

    return False, None
