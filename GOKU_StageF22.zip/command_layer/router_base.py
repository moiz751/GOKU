from __future__ import annotations
"""
Deterministic Command Router and Intent Classification Engine.
Routes desktop, filesystem, application, search, browser, clipboard, and document
commands deterministically without relying on local LLM availability.
"""
import os
from pathlib import Path
import re
import sys
import time
from typing import Any, Optional, Union, List, Dict
from brain.planner import (
    Plan,
    PlanStep,
)
from command_layer.cognitive_reasoner import CognitiveReasoner

class Step(PlanStep):
    def __init__(self, tool: str = "", args: Optional[Dict[str, Any]] = None, step: int = 1, **kwargs):
        super().__init__(
            step=kwargs.get("step", step),
            tool=tool or kwargs.get("tool", ""),
            args=args if args is not None else kwargs.get("args", {})
        )

    def __repr__(self):
        return f"Step({self.tool}, {self.args})"

from brain.planner import (
    create_plan_from_decision,
    decompose_compound_command,
    parse_compound_request,
    resolve_step_variables,
    resolve_step_variables_with_guard,
    inject_plan_prerequisites,
    prune_plan_steps,
    build_hypothesis_investigation_plan,
    build_root_cause_investigation_plan,
    parse_conditional_goal,
    synthesize_adaptive_replan,
    decompose_into_milestones,
    restore_plan_from_checkpoint,
    build_cross_domain_plan,
    apply_cross_domain_transformation,
    build_long_horizon_exploration_plan,
    decompose_long_horizon_goal,
    compute_state_hash,
    detect_state_cycle,
    heuristic_node_score,
    expand_exploration_frontier,
    select_next_frontier_node,
    apply_reflective_history_pruning,
)
from command_layer.context import (
    EntityType,
    TypedEntity,
    ORDINAL_REFERENCES,
    SessionContext,
    resolve_references,
    session_context,
    update_context_from_result,
)
from command_layer.semantic_model import (
    SemanticDomain,
    SemanticAction,
    CommandIntent,
    AmbiguityType,
    ClarificationRequest,
    SymptomCategory,
    SituationType,
    ConfidenceTier,
    RiskTier,
    ConfidenceScore,
    ConfirmationRequest,
    FailureType,
    AdaptiveStrategy,
    PlanAdaptation,
    TaskLifecycleState,
    TaskMilestone,
    TaskCheckpoint,
    DomainBridgeType,
    DomainBridgeLink,
    CrossDomainWorkflow,
    HorizonDepth,
    ExplorationNode,
    SearchFrontier,
    LongHorizonReport,
    HistoryQueryType,
    ExecutionTraceRecord,
    TraceSummary,
)
from command_layer.semantic_parser import (
    parse_semantic_intent,
    create_plan_from_intent,
    resolve_in_turn_correction,
    strip_conversational_noise,
    split_compound_clauses,
    detect_symptom_category,
)
from command_layer.firewall import validate_tool_against_firewall, pre_execution_semantic_check, validate_long_horizon_action
from command_layer.state_machine import agent_state
from command_layer.validator import validate_and_sanitize_tool_arguments
def run_tool_call(*args, **kwargs):
    from executor.executor import run_tool_call as _real
    return _real(*args, **kwargs)

from command_layer.lexer import UniversalLexer
from brain.runtime_bus import RuntimePipingBus


def resolve_system_canonical_path(alias: str) -> str:
    try:
        from tools.sandbox import user_dirs
        ud = user_dirs()
        desktop = str(ud["desktop"])
        downloads = str(ud["downloads"])
        documents = str(ud["documents"])
    except Exception:
        home = os.path.expanduser("~")
        desktop = os.path.join(home, "Desktop")
        downloads = os.path.join(home, "Downloads")
        documents = os.path.join(home, "Documents")

    alias_lower = alias.lower()
    if "desktop" in alias_lower:
        base = desktop
    elif "download" in alias_lower:
        base = downloads
    elif "document" in alias_lower:
        base = documents
    else:
        base = os.getcwd()
    
    # Extract filename or subfolder
    m = re.search(r'["\']([^"\']+)["\']', alias)
    if m:
        sub = m.group(1).strip()
    else:
        # Strip location prefix
        clean = re.sub(r'^(?:desktop|downloads|documents)\s*(?:par|pe|mein|me|ma)?\s*', '', alias, flags=re.IGNORECASE).strip()
        # Crucial fix: Stop extraction at Roman Urdu / English verbs and connectors
        stop_pattern = r'\s+(?:aur\s+uske\s+andar|uske\s+andar|and\s+inside\s+it|and\s+inside\s+that|and\s+in\s+it|aur|then|inside|bana\s+do|banao|kholo|karo|create\s*karo|create|make).*$'
        sub = re.sub(stop_pattern, '', clean, flags=re.IGNORECASE).strip()
        sub = re.sub(r'\s+(?:folder|file|directory|dir)$', '', sub, flags=re.IGNORECASE).strip()
    return os.path.join(base, sub) if sub else base


def verify_post_recovery(*args, **kwargs):
    from executor.verifier import verify_post_recovery as _real
    return _real(*args, **kwargs)

def verify_semantic_outcome(*args, **kwargs):
    from executor.semantic_verifier import verify_semantic_outcome as _real
    return _real(*args, **kwargs)

def capture_environment_snapshot(*args, **kwargs):
    from executor.verifier import capture_environment_snapshot as _real
    return _real(*args, **kwargs)

def capture_step_observation(*args, **kwargs):
    from executor.verifier import capture_step_observation as _real
    return _real(*args, **kwargs)

def detect_environment_drift(*args, **kwargs):
    from executor.verifier import detect_environment_drift as _real
    return _real(*args, **kwargs)

def _entity_val(obj: Any) -> Any:
    if obj is None:
        return ""
    if hasattr(obj, "value"):
        return obj.value
    return str(obj)

from security.state import confirmation_manager
def get_all_schemas(*args, **kwargs):
    from tools.registry import get_all_schemas as _gas
    return _gas(*args, **kwargs)
from tools.utils.app_resolver import (
    APP_ALIASES,
    get_canonical_app_name,
    resolve_app,
)
from tools.utils.target_resolver import TargetType, resolve_universal_target, disambiguate_multi_candidates

KNOWN_SITE_KEYS = (
    "youtube", "google", "github", "gmail", "facebook", "twitter", "x",
    "reddit", "chatgpt", "wikipedia", "linkedin", "amazon", "netflix", "openai",
    "daraz", "tiktok", "aliexpress", "ebay", "instagram",
)

KNOWN_APP_NAMES = set(APP_ALIASES.keys()) | {
    "chrome", "google chrome", "code", "vscode", "vs code", "visual studio code",
    "notepad", "calculator", "calc", "explorer", "edge", "msedge", "terminal",
    "wt", "cmd", "powershell", "vsc", "microsoft store", "windows store",
    "miscrosoft store", "file explorer", "windows explorer", "paint", "mspaint",
    "settings", "task manager", "control panel", "firefox", "windows security",
    "vlc", "spotify", "word", "powerpoint", "excel", "python"
}

FILE_EXTENSIONS = {
    ".txt", ".pdf", ".py", ".docx", ".doc", ".png", ".jpg", ".jpeg",
    ".gif", ".csv", ".xlsx", ".xls", ".json", ".html", ".css", ".js",
    ".md", ".zip", ".tar", ".gz", ".mp4", ".mp3", ".wav", ".log"
}


def _has_file_extension(name: str) -> bool:
    return any(ext in name.lower() for ext in FILE_EXTENSIONS)


def _normalize_resolved_path(path_str: str, base_dir: str | None = None) -> str:
    r"""
    Normalizes filesystem paths for open_file, save_active_document, etc.
    - If the path already contains a drive letter (e.g. C:\reports\...), do NOT prepend base_dir.
    - Dynamically resolves Desktop directly to the user's actual Desktop directory.
    - Uses os.path.normpath() to clean duplicate slashes.
    - Collapses repetitive consecutive identical directories (e.g. C:/reports/\reports\isolated.txt -> C:\reports\isolated.txt).
    """
    if not path_str:
        return ""
    p = str(path_str).strip().strip("'\"")

    # Dynamically resolve actual Desktop path
    desktop_actual = os.path.join(os.path.expanduser('~'), 'Desktop')
    p_lower = p.lower()
    if p_lower in ("desktop", "desktop/", "desktop\\"):
        return desktop_actual
    if p_lower.startswith("desktop/") or p_lower.startswith("desktop\\"):
        rel_sub = p[8:].lstrip("/\\")
        return os.path.normpath(os.path.join(desktop_actual, rel_sub))

    has_drive = bool(re.match(r'^[a-zA-Z]:', p))

    if not has_drive and base_dir:
        clean_base = str(base_dir).strip().rstrip("/\\")
        clean_p = p.lstrip("/\\")
        p = f"{clean_base}/{clean_p}"

    norm = os.path.normpath(p)
    parts = norm.split(os.sep)
    new_parts = []
    for part in parts:
        if new_parts and part and part.lower() == new_parts[-1].lower():
            continue
        new_parts.append(part)
    return os.sep.join(new_parts)


def _is_conversational_folder_path(path_str: str) -> bool:
    """Checks if an extracted folder target is conversational words/pronouns (e.g. abb, tu, na, kha, tha)."""
    if not path_str:
        return True
    p_lower = path_str.strip().lower()
    if re.match(r'^[a-zA-Z]:[\\/]', p_lower) and Path(p_lower).exists():
        return False
    conv_tokens = {
        "abb", "ab", "tu", "tum", "na", "ni", "kha", "kaha", "tha", "thi", "the",
        "wo", "woh", "ye", "yeh", "ya", "us", "is", "mera", "meri", "mere",
        "apna", "apni", "kuch", "bhai", "yaar", "bola", "kiya", "khol", "kholo",
        "open", "ker", "karo", "main", "mai", "mujh", "mujhe", "to", "toh"
    }
    words = set(re.findall(r'\b[a-zA-Z]+\b', p_lower))
    if not words:
        return True
    if words.issubset(conv_tokens) or any(w in words for w in {"abb", "ab", "tu", "tum", "kha", "kaha", "tha", "thi", "the", "na", "ni"}):
        return True
    if p_lower in ("wo", "woh", "ye", "yeh", "us", "is", "tu", "tum", "main", "mai"):
        return True
    return False
