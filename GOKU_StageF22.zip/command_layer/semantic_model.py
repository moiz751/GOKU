from __future__ import annotations
from typing import Any, Optional, Dict, List, Set, Tuple
from dataclasses import dataclass, field
from enum import Enum
import time

from command_layer.semantic_model_base import *
# ==============================================================================
# BULLET #21: DYNAMIC PLANNING
# ==============================================================================

class PlanMutationType(str, Enum):
    """Classification of dynamic plan mutations (Bullet #21)."""
    EXPAND_SUBGOAL = "expand_subgoal"           # Batch expansion: 1 step → N steps for discovered items
    INJECT_PREREQUISITE = "inject_prerequisite"  # Insert prerequisite step before consumer
    REORDER_TOPOLOGICAL = "reorder_topological"  # Reorder steps based on dependency DAG
    SPLICE_STEPS = "splice_steps"               # Replace step range with new steps


@dataclass
class PlanDAGNode:
    """
    Dependency graph node for dynamic plan topological ordering (Bullet #21).
    Each node maps to a PlanStep with explicit dependency edges.
    """
    step_id: int
    tool: str
    args: dict[str, Any] = field(default_factory=dict)
    depends_on: list[int] = field(default_factory=list)
    is_dynamically_injected: bool = False
    injected_at_runtime: bool = False
    injection_reason: str = ""
    mutation_type: str | None = None
    is_cross_domain: bool = False
    domain_lineage: list[str] = field(default_factory=list)

    def __post_init__(self):
        if self.injected_at_runtime and not self.is_dynamically_injected:
            self.is_dynamically_injected = True
        elif self.is_dynamically_injected and not self.injected_at_runtime:
            self.injected_at_runtime = True

    def to_dict(self) -> dict[str, Any]:
        return {
            "step_id": self.step_id,
            "tool": self.tool,
            "args": self.args,
            "depends_on": self.depends_on,
            "is_dynamically_injected": self.is_dynamically_injected,
            "injected_at_runtime": self.injected_at_runtime,
            "injection_reason": self.injection_reason,
            "mutation_type": self.mutation_type,
            "is_cross_domain": self.is_cross_domain,
            "domain_lineage": list(self.domain_lineage),
        }


@dataclass
class PlanMutation:
    """
    Audit record for a single dynamic plan modification (Bullet #21).
    Captures what changed, why, and before/after snapshots for accountability.
    """
    mutation_type: PlanMutationType
    affected_step_ids: list[int] = field(default_factory=list)
    reason: str = ""
    timestamp: float = field(default_factory=time.time)
    injected_tools: list[str] = field(default_factory=list)
    before_step_count: int = 0
    after_step_count: int = 0

    def to_dict(self) -> dict[str, Any]:
        return {
            "mutation_type": self.mutation_type.value if hasattr(self.mutation_type, "value") else str(self.mutation_type),
            "affected_step_ids": self.affected_step_ids,
            "reason": self.reason,
            "timestamp": self.timestamp,
            "injected_tools": self.injected_tools,
            "before_step_count": self.before_step_count,
            "after_step_count": self.after_step_count,
        }


# ==============================================================================
# BULLET #22: ADAPTIVE REPLANNING
# ==============================================================================

class FailureType(str, Enum):
    """Standardized failure taxonomy for runtime error categorization (Bullet #22)."""
    RESOURCE_NOT_FOUND = "resource_not_found"      # File, folder, URL, or target missing
    PERMISSION_DENIED = "permission_denied"        # Access denied, unauthorized, elevation needed
    PROCESS_CRASHED = "process_crashed"            # Non-zero exit, abnormal termination, exception
    TIMEOUT_UNRESPONSIVE = "timeout_unresponsive"  # Hanging process, GUI freeze, operation timeout
    TOOL_UNAVAILABLE = "tool_unavailable"          # Application/binary not installed, command not found
    PRECONDITION_FAILED = "precondition_failed"    # Precondition missing (parent dir, dependency, service)


class AdaptiveStrategy(str, Enum):
    """Adaptive alternative strategies for recovering from mid-flight step failures (Bullet #22)."""
    SUBSTITUTE_TOOL = "substitute_tool"                  # Swap out missing/failing tool with compatible equivalent
    RETRY_WITH_REMEDIATION = "retry_with_remediation"    # Inject prerequisite repair step then retry with modified params
    FALLBACK_REPRESENTATION = "fallback_representation"  # GUI -> hotkey/CLI fallback or alternate format
    DEGRADE_GRACEFULLY = "degrade_gracefully"            # Non-critical step failure tolerated with notification


@dataclass
class PlanAdaptation:
    """
    Audit record for mid-flight plan adaptation following an execution failure (Bullet #22).
    Captures failed step id, failure taxonomy, selected strategy, spliced steps, and rationale.
    """
    failed_step_id: int
    failure_type: FailureType
    strategy: AdaptiveStrategy
    injected_steps: list[Any] = field(default_factory=list)
    pruned_steps: list[int] = field(default_factory=list)
    retry_count: int = 1
    rationale: str = ""
    original_tool: str = ""
    adapted_tool: str = ""
    timestamp: float = field(default_factory=time.time)
    resolved: bool = False

    def to_dict(self) -> dict[str, Any]:
        injected = []
        for s in self.injected_steps:
            if hasattr(s, "to_dict"):
                injected.append(s.to_dict())
            elif isinstance(s, dict):
                injected.append(s)
            else:
                injected.append(str(s))
        return {
            "failed_step_id": self.failed_step_id,
            "failure_type": self.failure_type.value if hasattr(self.failure_type, "value") else str(self.failure_type),
            "strategy": self.strategy.value if hasattr(self.strategy, "value") else str(self.strategy),
            "injected_steps": injected,
            "pruned_steps": self.pruned_steps,
            "retry_count": self.retry_count,
            "rationale": self.rationale,
            "original_tool": self.original_tool,
            "adapted_tool": self.adapted_tool,
            "timestamp": self.timestamp,
            "resolved": self.resolved,
        }


# ==============================================================================
# BULLET #23: TRANSACTIONAL RECOVERY & COMPENSATION SCHEMA
# ==============================================================================

class RecoveryStatus(str, Enum):
    """Lifecycle status of failure recovery and transactional rollback operations (Bullet #23)."""
    IDLE = "idle"
    RECOVERING = "recovering"
    RECOVERED = "recovered"
    ROLLBACK_SUCCESSFUL = "rollback_successful"
    ROLLBACK_FAILED = "rollback_failed"
    UNRECOVERABLE = "unrecoverable"


@dataclass
class CompensationAction:
    """
    Transactional inverse action executing compensation/rollback for a previously executed step (Bullet #23).
    Maps mutative actions (create_file, create_folder, copy_file, launch_app) to inverse cleanup operations.
    """
    step_id: int = 0
    action_name: str = ""
    tool: str = ""
    args: dict[str, Any] = field(default_factory=dict)
    reason: str = ""
    risk_level: str = "medium"
    status: str = "pending"  # pending, executed, failed, skipped, firewall_blocked
    timestamp: float = field(default_factory=time.time)
    result: dict[str, Any] | None = None
    verified: bool = False
    original_step_id: int | None = None
    compensation_tool: str | None = None
    arguments: dict[str, Any] | None = None
    execution_timestamp: Any = None
    success: bool = False
    error: str | None = None

    def __post_init__(self):
        if self.original_step_id is not None and not self.step_id:
            self.step_id = self.original_step_id
        if self.compensation_tool is not None and not self.tool:
            self.tool = self.compensation_tool
        if self.arguments is not None and not self.args:
            self.args = self.arguments
        if self.compensation_tool is None:
            self.compensation_tool = self.tool
        if self.original_step_id is None:
            self.original_step_id = self.step_id
        if self.arguments is None:
            self.arguments = self.args

    @property
    def tool_name(self) -> str:
        return self.tool or self.compensation_tool or ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "step_id": self.step_id,
            "original_step_id": self.original_step_id or self.step_id,
            "action_name": self.action_name,
            "tool": self.tool,
            "compensation_tool": self.compensation_tool or self.tool,
            "args": self.args,
            "arguments": self.arguments or self.args,
            "reason": self.reason,
            "risk_level": self.risk_level,
            "status": self.status,
            "timestamp": self.timestamp,
            "result": self.result,
            "verified": self.verified,
            "success": self.success,
            "error": self.error,
        }


@dataclass
class RollbackLedger:
    """
    State ledger tracking transactional rollbacks and compensations during an execution abort (Bullet #23).
    Guarantees full auditability of all undo operations and cleanup traces.
    """
    task_id: str = ""
    executed_steps: list[int] = field(default_factory=list)
    pending_compensations: list[CompensationAction] = field(default_factory=list)
    completed_compensations: list[dict[str, Any]] = field(default_factory=list)
    status: RecoveryStatus = RecoveryStatus.IDLE
    error_reason: str = ""
    timestamp: float = field(default_factory=time.time)
    trigger_failure_step: int = -1
    trigger_error: str = ""
    actions: list[CompensationAction] = field(default_factory=list)
    outcome_details: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self):
        if self.status and isinstance(self.status, str):
            for st in RecoveryStatus:
                if st.value.lower() == self.status.lower():
                    self.status = st
                    break

    def to_dict(self) -> dict[str, Any]:
        return {
            "task_id": self.task_id,
            "trigger_failure_step": self.trigger_failure_step,
            "trigger_error": self.trigger_error,
            "executed_steps": self.executed_steps,
            "pending_compensations": [
                c.to_dict() if hasattr(c, "to_dict") else c for c in self.pending_compensations
            ],
            "completed_compensations": self.completed_compensations,
            "actions": [
                a.to_dict() if hasattr(a, "to_dict") else a for a in self.actions
            ],
            "status": self.status.name if hasattr(self.status, "name") else (self.status.value if hasattr(self.status, "value") else str(self.status)),
            "outcome_details": self.outcome_details,
            "error_reason": self.error_reason,
            "timestamp": self.timestamp,
        }


# ==============================================================================
# BULLET #24: OBSERVATION-DRIVEN EXECUTION & CLOSED-LOOP SENSING
# ==============================================================================

class ObservationType(str, Enum):
    """Categories of concrete physical state observations captured post-execution (Bullet #24)."""
    WINDOW_STATE = "window_state"              # Active window title, handle, responsiveness, focus
    PROCESS_TELEMETRY = "process_telemetry"    # Process alive state, PID, CPU/RAM delta
    FILESYSTEM_DELTA = "filesystem_delta"      # Target file existence, size delta, mtime
    NETWORK_LINK = "network_link"              # Link state, IP, connectivity
    ENVIRONMENT_DRIFT = "environment_drift"    # Focus loss, modal popup, external lock
    UI_MODAL = "ui_modal"                      # Modal dialog, unexpected popup


@dataclass
class StepObservation:
    """
    Structured record of physical environmental observation captured after step execution (Bullet #24).
    Validates physical reality on the OS, preventing blind execution based solely on return codes.
    """
    step_num: int = 0
    tool: str = ""
    obs_type: ObservationType = ObservationType.WINDOW_STATE
    physical_state: dict[str, Any] = field(default_factory=dict)
    state_verified: bool = True
    drift_detected: bool = False
    drift_details: dict[str, Any] = field(default_factory=dict)
    drift_reason: str = ""
    timestamp: float = field(default_factory=time.time)
    raw_evidence: dict[str, Any] = field(default_factory=dict)
    step_id: int = 0
    tool_name: str = ""

    def __post_init__(self):
        if not self.step_id and self.step_num:
            self.step_id = self.step_num
        elif not self.step_num and self.step_id:
            self.step_num = self.step_id
        if not self.tool_name and self.tool:
            self.tool_name = self.tool
        elif not self.tool and self.tool_name:
            self.tool = self.tool_name
        if isinstance(self.obs_type, str):
            for ot in ObservationType:
                if ot.value.lower() == self.obs_type.lower():
                    self.obs_type = ot
                    break

    def to_dict(self) -> dict[str, Any]:
        return {
            "step_num": self.step_num,
            "step_id": self.step_id or self.step_num,
            "tool": self.tool,
            "tool_name": self.tool_name or self.tool,
            "obs_type": self.obs_type.value if hasattr(self.obs_type, "value") else str(self.obs_type),
            "physical_state": dict(self.physical_state),
            "state_verified": self.state_verified,
            "drift_detected": self.drift_detected,
            "drift_details": dict(self.drift_details),
            "drift_reason": self.drift_reason,
            "timestamp": self.timestamp,
            "raw_evidence": dict(self.raw_evidence),
        }


@dataclass
class EnvironmentSnapshot:
    """
    Full snapshot of the live OS and desktop environment state (Bullet #24).
    Enables non-invasive pre-step precondition validation and multi-turn state comparison.
    """
    active_window: str = ""
    active_pid: Optional[int] = None
    cpu_usage: float = 0.0
    available_ram_mb: float = 0.0
    network_up: bool = True
    timestamp: float = field(default_factory=time.time)
    open_windows: list[str] = field(default_factory=list)
    foreground_app: str = ""
    active_handle: int = 0

    def to_dict(self) -> dict[str, Any]:
        return {
            "active_window": self.active_window,
            "active_pid": self.active_pid,
            "cpu_usage": self.cpu_usage,
            "available_ram_mb": self.available_ram_mb,
            "network_up": self.network_up,
            "timestamp": self.timestamp,
            "open_windows": list(self.open_windows),
            "foreground_app": self.foreground_app,
            "active_handle": self.active_handle,
        }


# ==============================================================================
# BULLET #25: OUTCOME VERIFICATION & GOAL FULFILLMENT AUDITING
# ==============================================================================

class OutcomeVerdict(str, Enum):
    """Categorical verdict assessing holistic goal fulfillment (Bullet #25)."""
    GOAL_ACHIEVED = "goal_achieved"                        # 100% verified against physical OS state
    PARTIALLY_ACHIEVED = "partially_achieved"              # Partial progress (e.g. 2/3 batch items completed)
    GOAL_UNFULFILLED = "goal_unfulfilled"                  # Tool reported success but physical outcome missing/invalid
    VERIFICATION_INCONCLUSIVE = "verification_inconclusive" # Telemetry/evidence insufficient to confirm or deny


@dataclass
class OutcomeCriteria:
    """
    Deterministic specification of expected physical end-state criteria (Bullet #25).
    Evaluated independently of raw tool return codes to prevent false success reporting.
    """
    expected_entity_type: str = "file"  # "file", "folder", "process", "application", "network", "system_state"
    target_identifier: str = ""
    expected_state: dict[str, Any] = field(default_factory=dict)
    integrity_checks: list[str] = field(default_factory=list)  # ["non_empty", "readable", "alive", "terminated", "connected"]
    min_size_bytes: int = 1
    allow_empty: bool = False

    def to_dict(self) -> dict[str, Any]:
        return {
            "expected_entity_type": self.expected_entity_type,
            "target_identifier": self.target_identifier,
            "expected_state": dict(self.expected_state),
            "integrity_checks": list(self.integrity_checks),
            "min_size_bytes": self.min_size_bytes,
            "allow_empty": self.allow_empty,
        }


@dataclass
class OutcomeReport:
    """
    Audit report capturing end-state goal fulfillment verification (Bullet #25).
    """
    goal_text: str = ""
    verdict: OutcomeVerdict = OutcomeVerdict.GOAL_ACHIEVED
    confidence: float = 1.0
    verified_evidence: dict[str, Any] = field(default_factory=dict)
    discrepancies: list[str] = field(default_factory=list)
    remediation_suggested: Optional[str] = None
    timestamp: float = field(default_factory=time.time)
    plan_id: str = ""
    steps_executed: int = 0

    def __post_init__(self):
        if isinstance(self.verdict, str):
            for ov in OutcomeVerdict:
                if ov.value.lower() == self.verdict.lower() or ov.name.lower() == self.verdict.lower():
                    self.verdict = ov
                    break

    def to_dict(self) -> dict[str, Any]:
        return {
            "goal_text": self.goal_text,
            "verdict": self.verdict.value if hasattr(self.verdict, "value") else str(self.verdict),
            "verdict_name": self.verdict.name if hasattr(self.verdict, "name") else str(self.verdict),
            "confidence": self.confidence,
            "verified_evidence": dict(self.verified_evidence),
            "discrepancies": list(self.discrepancies),
            "remediation_suggested": self.remediation_suggested,
            "timestamp": self.timestamp,
            "plan_id": self.plan_id,
            "steps_executed": self.steps_executed,
        }


# ==============================================================================
# BULLET #26: MULTI-STEP TASK MANAGEMENT & LIFECYCLE CHECKPOINTING
# ==============================================================================

class TaskLifecycleState(str, Enum):
    """Lifecycle state machine stages for multi-step autonomous tasks (Bullet #26)."""
    NOT_STARTED = "not_started"
    IN_PROGRESS = "in_progress"
    PAUSED = "paused"
    RESUMING = "resuming"
    COMPLETED = "completed"
    CANCELLED = "cancelled"


@dataclass
class TaskMilestone:
    """
    Logical hierarchical milestone partition of a complex multi-step task (Bullet #26).
    Groups steps into discrete semantic phases (Discovery, Execution, Verification).
    """
    milestone_id: int
    title: str
    steps: list[int] = field(default_factory=list)
    is_completed: bool = False
    completed_at: Optional[float] = None
    result_summary: Optional[str] = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "milestone_id": self.milestone_id,
            "title": self.title,
            "steps": [s.to_dict() if hasattr(s, "to_dict") else (dict(s) if isinstance(s, dict) else s) for s in self.steps],
            "is_completed": self.is_completed,
            "completed_at": self.completed_at,
            "result_summary": self.result_summary,
        }


@dataclass
class TaskCheckpoint:
    """
    Complete recoverable snapshot of an in-flight autonomous task (Bullet #26).
    Enables zero-loss suspend/resume and clean serialization without handle leaks.
    """
    task_id: str = ""
    task_goal: str = ""
    lifecycle_state: TaskLifecycleState = TaskLifecycleState.IN_PROGRESS
    current_milestone_idx: int = 0
    completed_step_ids: list[int] = field(default_factory=list)
    pending_plan: dict[str, Any] = field(default_factory=dict)
    saved_context_slots: dict[str, Any] = field(default_factory=dict)
    progress_percent: float = 0.0
    timestamp: float = field(default_factory=time.time)

    def __post_init__(self):
        if isinstance(self.lifecycle_state, str):
            for state in TaskLifecycleState:
                if state.value.lower() == self.lifecycle_state.lower() or state.name.lower() == self.lifecycle_state.lower():
                    self.lifecycle_state = state
                    break

    def to_dict(self) -> dict[str, Any]:
        return {
            "task_id": self.task_id,
            "task_goal": self.task_goal,
            "lifecycle_state": self.lifecycle_state.value if hasattr(self.lifecycle_state, "value") else str(self.lifecycle_state),
            "current_milestone_idx": self.current_milestone_idx,
            "completed_step_ids": list(self.completed_step_ids),
            "pending_plan": self.pending_plan.to_dict() if hasattr(self.pending_plan, "to_dict") else (dict(self.pending_plan) if isinstance(self.pending_plan, dict) else str(self.pending_plan)),
            "saved_context_slots": dict(self.saved_context_slots),
            "progress_percent": round(self.progress_percent, 2),
            "timestamp": self.timestamp,
        }


# ==============================================================================
# BULLET #27: CROSS-DOMAIN PROBLEM SOLVING & DATA BRIDGING
# ==============================================================================

class DomainBridgeType(str, Enum):
    """Bridge types defining variable/data translation across domain boundaries (Bullet #27)."""
    FILE_TO_BROWSER = "file_to_browser"
    PROCESS_TO_GUI = "process_to_gui"
    DIAGNOSTIC_TO_FILE = "diagnostic_to_file"
    NETWORK_TO_SETTINGS = "network_to_settings"
    STORAGE_TO_ARCHIVE = "storage_to_archive"


@dataclass
class DomainBridgeLink:
    """
    Explicit data pipeline bridge linking a producer step in Domain A to a
    consumer step in Domain B with type-safe transformations (Bullet #27).
    """
    source_domain: SemanticDomain
    target_domain: SemanticDomain
    bridge_type: DomainBridgeType
    source_step_id: int
    target_step_id: int
    source_key: str = ""
    target_param: str = ""
    transformation: Optional[str] = None  # e.g. "to_file_uri", "to_path", "to_report_content", "to_pid", "to_settings_uri"

    def __post_init__(self):
        if isinstance(self.source_domain, str):
            for d in SemanticDomain:
                if d.value.lower() == self.source_domain.lower() or d.name.lower() == self.source_domain.lower():
                    self.source_domain = d
                    break
        if isinstance(self.target_domain, str):
            for d in SemanticDomain:
                if d.value.lower() == self.target_domain.lower() or d.name.lower() == self.target_domain.lower():
                    self.target_domain = d
                    break
        if isinstance(self.bridge_type, str):
            for b in DomainBridgeType:
                if b.value.lower() == self.bridge_type.lower() or b.name.lower() == self.bridge_type.lower():
                    self.bridge_type = b
                    break

    def to_dict(self) -> dict[str, Any]:
        return {
            "source_domain": self.source_domain.value if hasattr(self.source_domain, "value") else str(self.source_domain),
            "target_domain": self.target_domain.value if hasattr(self.target_domain, "value") else str(self.target_domain),
            "bridge_type": self.bridge_type.value if hasattr(self.bridge_type, "value") else str(self.bridge_type),
            "source_step_id": self.source_step_id,
            "target_step_id": self.target_step_id,
            "source_key": self.source_key,
            "target_param": self.target_param,
            "transformation": self.transformation,
        }


@dataclass
class CrossDomainWorkflow:
    """
    High-level representation of a coordinated multi-domain problem solving workflow (Bullet #27).
    """
    workflow_id: str
    primary_domains: list[SemanticDomain] = field(default_factory=list)
    data_bridges: list[DomainBridgeLink] = field(default_factory=list)
    is_cross_domain: bool = True

    def __post_init__(self):
        norm_domains = []
        for d in self.primary_domains:
            if isinstance(d, str):
                for sd in SemanticDomain:
                    if sd.value.lower() == d.lower() or sd.name.lower() == d.lower():
                        norm_domains.append(sd)
                        break
                else:
                    norm_domains.append(d)
            else:
                norm_domains.append(d)
        self.primary_domains = norm_domains

    def to_dict(self) -> dict[str, Any]:
        return {
            "workflow_id": self.workflow_id,
            "primary_domains": [d.value if hasattr(d, "value") else str(d) for d in self.primary_domains],
            "data_bridges": [b.to_dict() if hasattr(b, "to_dict") else b for b in self.data_bridges],
            "is_cross_domain": self.is_cross_domain,
        }


# ==============================================================================
# BULLET #28: LONG-HORIZON PROBLEM SOLVING & FRONTIER SEARCH
# ==============================================================================

class HorizonDepth(IntEnum):
    """Hierarchical planning levels for multi-stage goal pursuit (Bullet #28)."""
    STRATEGIC = 0   # Macro Objective / Broad Horizon Strategy
    TACTICAL = 1    # Intermediate Milestone / Sub-Goal
    OPERATIONAL = 2 # Concrete Atomic Step / Tool Execution


@dataclass
class ExplorationNode:
    """
    State tree node tracking intermediate system states, actions, and heuristic scores.
    """
    node_id: str
    parent_id: Optional[str] = None
    depth: HorizonDepth = HorizonDepth.STRATEGIC
    action: str = ""
    state_hash: str = ""
    score: float = 0.0
    status: str = "UNEXPLORED"  # UNEXPLORED, EXPANDED, DEAD_END, PRUNED, SOLVED
    relevance: float = 0.0
    disruption_cost: float = 0.0
    metadata: dict[str, Any] = field(default_factory=dict)
    cost: float = 0.0
    children_ids: list[str] = field(default_factory=list)
    created_at: float = field(default_factory=time.time)

    def to_dict(self) -> dict[str, Any]:
        return {
            "node_id": self.node_id,
            "parent_id": self.parent_id,
            "depth": int(self.depth),
            "action": self.action,
            "state_hash": self.state_hash,
            "score": self.score,
            "status": self.status,
            "relevance": self.relevance,
            "disruption_cost": self.disruption_cost,
            "metadata": dict(self.metadata),
            "cost": self.cost,
            "children_ids": list(self.children_ids),
            "created_at": self.created_at,
        }


@dataclass
class SearchFrontier:
    """
    Tracks visited vs. unexplored states, resource budgets, and cycle invariants.
    """
    nodes: dict[str, ExplorationNode] = field(default_factory=dict)
    active_node_id: Optional[str] = None
    visited_state_hashes: set[str] = field(default_factory=set)
    state_visit_counts: dict[str, int] = field(default_factory=dict)
    max_depth: int = 3
    budget_remaining: int = 15
    max_budget: int = 15
    cycle_detected: bool = False
    dead_end_nodes: list[str] = field(default_factory=list)
    solved_node_id: Optional[str] = None
    history_state_hashes: list[str] = field(default_factory=list)

    def add_node(self, node: ExplorationNode) -> None:
        self.nodes[node.node_id] = node
        if node.parent_id and node.parent_id in self.nodes:
            if node.node_id not in self.nodes[node.parent_id].children_ids:
                self.nodes[node.parent_id].children_ids.append(node.node_id)

    def get_node(self, node_id: str) -> Optional[ExplorationNode]:
        return self.nodes.get(node_id)

    def is_visited(self, state_hash: str) -> bool:
        return state_hash in self.visited_state_hashes

    def prune_branch(self, node_id: str) -> None:
        if node_id in self.nodes:
            self.nodes[node_id].status = "PRUNED"

    def mark_visited(self, state_hash: str) -> None:
        if state_hash:
            self.visited_state_hashes.add(state_hash)
            self.state_visit_counts[state_hash] = self.state_visit_counts.get(state_hash, 0) + 1
            self.history_state_hashes.append(state_hash)

    def consume_budget(self, amount: int = 1) -> bool:
        self.budget_remaining = max(0, self.budget_remaining - amount)
        return self.budget_remaining > 0

    def to_dict(self) -> dict[str, Any]:
        return {
            "nodes": {nid: n.to_dict() for nid, n in self.nodes.items()},
            "active_node_id": self.active_node_id,
            "visited_state_hashes": list(self.visited_state_hashes),
            "state_visit_counts": dict(self.state_visit_counts),
            "max_depth": self.max_depth,
            "budget_remaining": self.budget_remaining,
            "max_budget": self.max_budget,
            "cycle_detected": self.cycle_detected,
            "dead_end_nodes": list(self.dead_end_nodes),
            "solved_node_id": self.solved_node_id,
        }


@dataclass
class LongHorizonReport:
    """
    Formal post-exploration audit report summarizing nodes, branches, and outcome verdict.
    """
    macro_goal: str
    total_nodes_evaluated: int = 0
    depth_reached: int = 0
    dead_ends_encountered: int = 0
    cycles_avoided: int = 0
    budget_consumed: int = 0
    solution_path: list[str] = field(default_factory=list)
    outcome_verdict: str = "SOLVED"  # SOLVED, BUDGET_EXHAUSTED, FRONTIER_EXHAUSTED, PARTIALLY_ACHIEVED, FAILED
    summary_findings: list[str] = field(default_factory=list)
    created_at: float = field(default_factory=time.time)

    def to_dict(self) -> dict[str, Any]:
        return {
            "macro_goal": self.macro_goal,
            "total_nodes_evaluated": self.total_nodes_evaluated,
            "depth_reached": self.depth_reached,
            "dead_ends_encountered": self.dead_ends_encountered,
            "cycles_avoided": self.cycles_avoided,
            "budget_consumed": self.budget_consumed,
            "solution_path": list(self.solution_path),
            "outcome_verdict": self.outcome_verdict,
            "summary_findings": list(self.summary_findings),
            "created_at": self.created_at,
        }

    def to_markdown(self, lang: str = "en") -> str:
        is_ur = (lang.lower() in ("ur", "urdu") or any(w in self.macro_goal.lower() for w in ["karo", "kya", "hua", "dikhao", "pura", "khatam"]))
        if is_ur:
            lines = [
                f"# Long-Horizon Problem Solving Jaiza Report ({self.outcome_verdict}):",
                f"- Kamyabi (Solved): {self.outcome_verdict}",
                f"- Macro Goal: {self.macro_goal}",
                f"- Kul Nodes Janche Gaye: {self.total_nodes_evaluated} (Depth: {self.depth_reached})",
                f"- Dead-Ends Abandoned: {self.dead_ends_encountered} | Bachi Gayi Cycles: {self.cycles_avoided}",
                f"- Budget Istemal: {self.budget_consumed}",
            ]
            if self.solution_path:
                lines.append(f"- Hal Ka Raasta (Solution Path): {' -> '.join(self.solution_path)}")
            if self.summary_findings:
                lines.append("Khas Daryaftat (Key Findings):")
                for f in self.summary_findings:
                    lines.append(f"  * {f}")
            return "\n".join(lines)
        else:
            lines = [
                f"# Long-Horizon Problem Solving Audit Report [{self.outcome_verdict}]",
                f"- Outcome Verdict: {self.outcome_verdict}",
                f"- Macro Goal: {self.macro_goal}",
                f"- Nodes Evaluated: {self.total_nodes_evaluated} (Max Depth Reached: {self.depth_reached})",
                f"- Dead-End Branches Pruned: {self.dead_ends_encountered}",
                f"- Repetitive Cycles Avoided: {self.cycles_avoided}",
                f"- Resource Budget Consumed: {self.budget_consumed}",
            ]
            if self.solution_path:
                lines.append(f"- Solution Path & Milestones: {' -> '.join(self.solution_path)}")
            if self.summary_findings:
                lines.append("## Key Factual Findings:")
                for f in self.summary_findings:
                    lines.append(f"- {f}")
            return "\n".join(lines)


# ==============================================================================
# BULLET #29: SELF-HISTORY & EXECUTION TRACE UTILIZATION
# ==============================================================================

class HistoryQueryType(str, Enum):
    """Classification of historical retrospective queries (Bullet #29)."""
    RECENT_ACTIONS = "recent_actions"
    PAST_TELEMETRY = "past_telemetry"
    FAILURE_REASON = "failure_reason"
    TOOL_USAGE_COUNT = "tool_usage_count"
    COMPARATIVE_METRIC = "comparative_metric"
    EXECUTION_STATUS = "execution_status"


@dataclass
class ExecutionTraceRecord:
    """
    Unified historical record of a single executed user turn (Bullet #29).
    Persisted to disk and maintained in bounded circular in-memory buffer.
    """
    turn_id: int
    session_id: str = "default_session"
    timestamp: float = field(default_factory=time.time)
    raw_command: str = ""
    intent: str = ""
    tools_called: list[str] = field(default_factory=list)
    tool_args: list[dict[str, Any]] = field(default_factory=list)
    results_summary: list[str] = field(default_factory=list)
    success: bool = True
    error_type: Optional[str] = None
    error_message: Optional[str] = None
    outcome_verdict: str = "COMPLETED"  # COMPLETED, FAILED, EARLY_EXIT, CYCLE_HALTED, BUDGET_EXHAUSTED
    telemetry_snapshot: dict[str, Any] = field(default_factory=dict)
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "turn_id": self.turn_id,
            "session_id": self.session_id,
            "timestamp": self.timestamp,
            "raw_command": self.raw_command,
            "intent": self.intent,
            "tools_called": list(self.tools_called),
            "tool_args": list(self.tool_args),
            "results_summary": list(self.results_summary),
            "success": self.success,
            "error_type": self.error_type,
            "error_message": self.error_message,
            "outcome_verdict": self.outcome_verdict,
            "telemetry_snapshot": dict(self.telemetry_snapshot),
            "metadata": dict(self.metadata),
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ExecutionTraceRecord":
        return cls(
            turn_id=data.get("turn_id", 0),
            session_id=data.get("session_id", "default_session"),
            timestamp=data.get("timestamp", time.time()),
            raw_command=data.get("raw_command", ""),
            intent=data.get("intent", ""),
            tools_called=list(data.get("tools_called", [])),
            tool_args=list(data.get("tool_args", [])),
            results_summary=list(data.get("results_summary", [])),
            success=data.get("success", True),
            error_type=data.get("error_type"),
            error_message=data.get("error_message"),
            outcome_verdict=data.get("outcome_verdict", "COMPLETED"),
            telemetry_snapshot=dict(data.get("telemetry_snapshot", {})),
            metadata=dict(data.get("metadata", {})),
        )


@dataclass
class TraceSummary:
    """
    High-level factual aggregation of multi-turn execution traces (Bullet #29).
    """
    total_turns: int = 0
    successful_turns: int = 0
    failed_turns: int = 0
    unique_tools_used: list[str] = field(default_factory=list)
    recent_errors: list[str] = field(default_factory=list)
    last_turn_id: int = 0

    def to_dict(self) -> dict[str, Any]:
        return {
            "total_turns": self.total_turns,
            "successful_turns": self.successful_turns,
            "failed_turns": self.failed_turns,
            "unique_tools_used": list(self.unique_tools_used),
            "recent_errors": list(self.recent_errors),
            "last_turn_id": self.last_turn_id,
        }


# ==============================================================================
# BULLET #30: BLACK-BOX GENERALIZATION & ADVERSARIAL HARDENING
# ==============================================================================

class FirewallVerdict(str, Enum):
    """Evaluation verdict from security and adversarial firewall checks (Bullet #30)."""
    ALLOWED = "ALLOWED"
    DENIED_DESTRUCTIVE = "DENIED_DESTRUCTIVE"
    DENIED_ADVERSARIAL = "DENIED_ADVERSARIAL"
    DENIED_INJECTION = "DENIED_INJECTION"
    CONFIRMATION_REQUIRED = "CONFIRMATION_REQUIRED"


@dataclass
class AdversarialAttackRecord:
    """Audit log entry for intercepted adversarial prompts, jailbreaks, and injection attacks (Bullet #30)."""
    timestamp: float = field(default_factory=time.time)
    raw_input: str = ""
    attack_type: str = "JAILBREAK"  # JAILBREAK, INSTRUCTION_OVERRIDE, COMMAND_INJECTION, PATH_TRAVERSAL, DESTRUCTIVE_EVASION
    verdict: FirewallVerdict = FirewallVerdict.DENIED_ADVERSARIAL
    details: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "timestamp": self.timestamp,
            "raw_input": self.raw_input,
            "attack_type": self.attack_type,
            "verdict": self.verdict.value if hasattr(self.verdict, "value") else str(self.verdict),
            "details": self.details,
        }









