from __future__ import annotations
import os
from pathlib import Path
import re
import sys
import time
from typing import Any, Optional, Union, List, Dict, Tuple
from dataclasses import dataclass, field

from brain.planner import (
    Plan,
    PlanStep,
    StructuredIntent,
    create_plan_from_decision,
    decompose_compound_command,
    parse_compound_request,
    resolve_step_variables,
    resolve_step_variables_with_guard,
    inject_plan_prerequisites,
    prune_plan_steps,
    build_hypothesis_investigation_plan,
    build_root_cause_investigation_plan,
    parse_conditional_goal,
    synthesize_adaptive_replan,
    decompose_into_milestones,
    restore_plan_from_checkpoint,
    build_cross_domain_plan,
    apply_cross_domain_transformation,
    build_long_horizon_exploration_plan,
    decompose_long_horizon_goal,
    compute_state_hash,
    detect_state_cycle,
    heuristic_node_score,
    expand_exploration_frontier,
    select_next_frontier_node,
    apply_reflective_history_pruning,
)
from command_layer.cognitive_reasoner import CognitiveReasoner
from command_layer.context import (
    EntityType,
    TypedEntity,
    ORDINAL_REFERENCES,
    SessionContext,
    resolve_references,
    session_context,
    update_context_from_result,
)
from command_layer.semantic_model import (
    SemanticDomain,
    SemanticAction,
    CommandIntent,
    AmbiguityType,
    ClarificationRequest,
    SymptomCategory,
    SituationType,
    ConfidenceTier,
    RiskTier,
    ConfidenceScore,
    ConfirmationRequest,
    FailureType,
    AdaptiveStrategy,
    PlanAdaptation,
    TaskLifecycleState,
    TaskMilestone,
    TaskCheckpoint,
    DomainBridgeType,
    DomainBridgeLink,
    CrossDomainWorkflow,
    HorizonDepth,
    ExplorationNode,
    SearchFrontier,
    LongHorizonReport,
    HistoryQueryType,
    ExecutionTraceRecord,
    TraceSummary,
)
from command_layer.semantic_parser import (
    parse_semantic_intent,
    create_plan_from_intent,
    resolve_in_turn_correction,
    strip_conversational_noise,
    split_compound_clauses,
    detect_symptom_category,
)
from command_layer.firewall import validate_tool_against_firewall, pre_execution_semantic_check, validate_long_horizon_action
from command_layer.state_machine import agent_state
from command_layer.validator import validate_and_sanitize_tool_arguments
from command_layer.lexer import UniversalLexer
from brain.runtime_bus import RuntimePipingBus
from security.state import confirmation_manager
from tools.utils.app_resolver import (
    APP_ALIASES,
    get_canonical_app_name,
    resolve_app,
)
from tools.utils.target_resolver import TargetType, resolve_universal_target, disambiguate_multi_candidates
from command_layer.router_base import (
    Step,
    run_tool_call,
    resolve_system_canonical_path,
    verify_post_recovery,
    verify_semantic_outcome,
    capture_environment_snapshot,
    capture_step_observation,
    detect_environment_drift,
    _entity_val,
    get_all_schemas,
    KNOWN_SITE_KEYS,
    KNOWN_APP_NAMES,
    _has_file_extension,
    _normalize_resolved_path,
    _is_conversational_folder_path,
)
from security.safety_firewall import is_safe_readonly_operation
from security.confirm import RISKY_TOOLS
from command_layer.decomposer import count_action_verbs
from brain.workflow_orchestrator import orchestrate_compound_workflow
from tools.browser import sanitize_search_query
from tools.search import parse_search_grammar
import executor.verifier
import executor.executor

from command_layer.router_sanitizer import (
    _isolate_browser_context,
    prune_negated_steps,
    sanitize_action_query,
    sanitize_url,
    _canonicalize_plan_tools,
    sanitize_ui_target,
    extract_clean_search_query,
)
from command_layer.router_cli_parser import (
    translate_cli_command,
    sanitize_cli_command,
    extract_pure_text_payload,
    parse_sequential_keyboard_actions,
    is_standalone_navigation_request,
    resolve_temporal_order,
    strip_idiomatic_conditions,
)
from command_layer.router_confidence import (
    determine_risk_tier,
    format_uncertainty_response,
    compute_command_confidence,
    synthesize_cross_domain_report,
    synthesize_long_horizon_report,
    get_conversational_response,
)

def _classify_and_parse_command(text: str, context: SessionContext | None = None, is_compound_root: bool = True) -> Plan | None:
    from command_layer.router_classifier_core import _classify_and_parse_command as _real_fn
    return _real_fn(text, context, is_compound_root)

def classify_system_intents_2(text: str, context: SessionContext | None = None, is_compound_root: bool = True) -> Plan | None:
    from command_layer.decomposer import count_action_verbs
    from brain.workflow_orchestrator import orchestrate_compound_workflow
    from tools.browser import sanitize_search_query
    from tools.search import parse_search_grammar
    from security.safety_firewall import is_safe_readonly_operation
    from security.confirm import RISKY_TOOLS
    cleaned = re.sub(r'[\x00-\x1f\x7f]+$', '', text).strip()
    cleaned = re.sub(r'[\x13\x03\x1b]', '', cleaned).strip()
    raw_lower = cleaned.lower()
    lower = text.lower()
    folder_ref_m = re.search(r"folder\s+'([^']+)'", text)
    file_ref_m = re.search(r"file\s+'([^']+)'", text)
    text_unwrapped = re.sub(r'[\'"]([^\'"]+)[\'"]', r'\1', text)
    try:
        symptom_cat, situation_type, symptom_entities = detect_symptom_category(raw_lower)
    except Exception:
        symptom_cat, situation_type, symptom_entities = SymptomCategory.NONE, SituationType.NORMAL, []
    _p2_is_compound_guard = False

    # Extended par-click pattern: supports any target word/phrase (+ optional type hint), not just a whitelist.
    # "Save par click karo", "Save button par click karo", "Next tab par click karo"
    # Type hints (button, tab, icon, link) are part of the target capture group.
    m_click_par = re.match(
        r'^(?:please\s+)?[\'"]?(?P<target>[a-zA-Z0-9_\-][a-zA-Z0-9_\-\s]{0,60}?)[\'"]?\s+par\s+click\s*(?:karo|kar\s+do|karna)?$',
        cleaned, re.IGNORECASE
    )
    if m_click_par:
        raw_target = m_click_par.group("target").strip()
        # NEVER treat multi-intent launch/open phrases as a single click target
        if any(w in raw_target.lower() for w in ["launch", "open", "kholo", "chalao", "start", "aur", "and", "phir"]):
            pass
        else:
            clean_target = re.sub(r'^.*?\b(?:kholo\s+aur|launch\s+(?:karo\s+)?aur|open\s+(?:karo\s+)?aur|chalao\s+aur|aur|and|phir)\s+', '', raw_target, flags=re.IGNORECASE).strip()
            clean_target = re.sub(r'\s*(?:par|pe)?\s*(?:click\s+karo|click\s+kar\s+do|click|select\s+karo|select)$', '', clean_target, flags=re.IGNORECASE).strip()
            clean_target = clean_target.strip("'\"")
            reserved_par = {'screen', 'desktop', 'window', 'yahan', 'wahan', 'it', 'here'}
            if clean_target and clean_target.lower() not in reserved_par:
                t_low = clean_target.lower()
                ord_keywords = ["pehli", "pehla", "first", "1st", "doosri", "doosra", "second", "2nd", "teesri", "teesra", "third", "3rd"]
                item_keywords = ["video", "link", "result", "item", "card", "search"]
                if any(r in t_low for r in ord_keywords) and any(w in t_low for w in item_keywords):
                    rank_val = 1
                    if any(r in t_low for r in ["second", "doosra", "doosri", "2nd"]):
                        rank_val = 2
                    elif any(r in t_low for r in ["third", "teesra", "teesri", "3rd"]):
                        rank_val = 3
                    if "video" in t_low:
                        t_q = f"video_result_{rank_val}"
                    elif "link" in t_low:
                        t_q = f"link_item_{rank_val}"
                    else:
                        t_q = f"result_item_{rank_val}"
                    steps = [PlanStep(step=1, tool="find_and_interact", args={"target_query": t_q, "query": t_q, "action": "click", "rank": rank_val})]
                    refocus_app = getattr(context, "last_target_app", None) if context else None
                    if not refocus_app and context:
                        refocus_app = getattr(context, "last_application", None)
                        if hasattr(refocus_app, "value"):
                            refocus_app = refocus_app.value
                    if refocus_app:
                        steps.insert(0, PlanStep(step=1, tool="focus_app", args={"name": refocus_app}))
                        for i, s in enumerate(steps, 1):
                            s.step = i
                    return Plan(
                        steps=steps,
                        explanation=f"Interacting with ordinal UI element '{t_q}' (rank {rank_val})."
                    )

                return Plan(
                    steps=[PlanStep(step=1, tool="click_element_by_text", args={"target_text": clean_target})],
                    explanation=f"Clicking on-screen element '{clean_target}' via Roman Urdu instruction."
                )

    # Phase 0.54: Store & Desktop Application Acquisition pipeline is deprecated and bypassed in favor of Phase 4 autonomous 4-step execution.

    # 0. Check Compound Multi-Step Workflow Planner
    if symptom_cat == SymptomCategory.NONE:
        compound_plan = parse_compound_request(cleaned)
        if compound_plan is not None:
            if not compound_plan.constraints:
                prohib_m = re.findall(r'\b(?:lekin|par|magar|but|however|without|baghair)\s+([^,;]+)', cleaned, flags=re.IGNORECASE)
                for pm in prohib_m:
                    if re.search(r'\b(mat\s+|don\'t|dont|do\s+not|never|modifying|changing|deleting|clearing|nahi\b|downloading)', pm, flags=re.IGNORECASE):
                        compound_plan.constraints.append(pm.strip())
                if not compound_plan.constraints:
                    wo_m = re.findall(r'\b(without\s+[^,;]+)', cleaned, flags=re.IGNORECASE)
                    for wm in wo_m:
                        compound_plan.constraints.append(wm.strip())
            return compound_plan

    # 0.1 Check General Clause Decomposition for multi-step commands
    is_find_and_open = bool(re.search(r'\b(?:find|search)\s+(?:and|aur)\s+(?:open|launch|kholo)\b', cleaned, flags=re.IGNORECASE))
    is_phir_adverb = bool(re.search(r'\b(?:phir|dobara|wapas)\s+(?:kholo|open|launch|start|chalao|band|close)\b', raw_lower))
    is_conditional = bool(re.search(r'\b(?:agar|if)\b', raw_lower) and any(w in raw_lower for w in ["warna", "else", "otherwise", "already", "to wahi", "then use"]))
    is_diagnostic_monologue = (symptom_cat != SymptomCategory.NONE) or any(p in raw_lower for p in [
        "ajeeb behave", "ajeeb chal", "kya scene", "masla", "heavy chal", "fans", "delay ho raha",
        "pages thore slow", "stuck ho gaya", "pop-up", "low storage", "kuch copy kiya tha",
        "pehle ye dekh lo", "pehli wali kitni full", "iska free space", "why is my computer slow",
        "why my pc is slow", "computer slow kyun hai", "mera internet normally chal raha tha",
        "system par pop-up aya tha", "dekho computer bohot zyada heavy"
    ])
    is_composite_mouse = "phir" in raw_lower and ("upar se neeche" in raw_lower or "neeche" in raw_lower) and ("left" in raw_lower or "right" in raw_lower)
    if is_compound_root and not is_find_and_open and not is_phir_adverb and not is_conditional and not is_diagnostic_monologue and not is_composite_mouse and any(sep in raw_lower for sep in [";", ",", " aur ", " and ", " phir ", " then ", " karke ", " ke baad ", " lekin ", " par ", " but ", " however ", " after that ", " iske baad ", " saath hi "]):
        clauses = split_compound_clauses(cleaned)
        if len(clauses) >= 2:
            multi_steps = []
            has_synth = False
            seen_tools = set()
            extracted_constraints = []
            last_producer_step_idx: int | None = None

            for c in clauses:
                cl = c.lower()
                if re.search(r'\b(mat\s+(?:karna|karo|chhedna|touch|hath|badalna|change|close|kholna|khol|open|delete|copy|move|disconnect|batao|batana|dikhana|dikhao|check|chalana|chalao|run|execute|use|clean|cleanup|pair|download|save|rakhna)|don\'t|dont|do\s+not|never|without\s+(?:modifying|changing|deleting|clearing)|nahi\b)', cl):
                    extracted_constraints.append(c)
                    continue
                query_to_run = c
                if any(w in cl for w in ["sirf status", "status check", "status batao", "check karo"]) and not any(w in cl for w in ["wifi", "net", "app", "drive", "disk", "service", "process", "bluetooth"]):
                    for constr in extracted_constraints:
                        if any(k in constr.lower() for k in ["wifi", "wireless"]):
                            query_to_run = f"wifi {c}"
                            break
                        elif "bluetooth" in constr.lower():
                            query_to_run = f"bluetooth {c}"
                            break
                elif any(w in cl for w in ["find", "dhundo", "search"]) and not any(w in cl for w in ["file", "files", "folder", "downloads", "documents", "desktop"]):
                    for constr in extracted_constraints:
                        for app in KNOWN_APP_NAMES:
                            if app in constr.lower():
                                query_to_run = f"find {app}"
                                break

                # Producer-Consumer Data Flow Linking (Bullet #10)
                if last_producer_step_idx is not None and any(p in cl for p in ["usko", "isko", "it", "them", "that file", "us file", "pehli file", "first one", "wo file", "woh file", "that"]):
                    if any(w in cl for w in ["open", "kholo", "launch", "chalao"]):
                        query_to_run = f"open file $step_{last_producer_step_idx}.matches[0]"
                    elif any(w in cl for w in ["delete", "remove", "hatao"]):
                        query_to_run = f"delete file $step_{last_producer_step_idx}.matches[0]"
                    elif any(w in cl for w in ["read", "padho"]):
                        query_to_run = f"read file $step_{last_producer_step_idx}.matches[0]"

                sub_plan = _classify_and_parse_command(query_to_run, context, is_compound_root=False)
                if sub_plan and sub_plan.steps:
                    if getattr(sub_plan, "synthesis_mode", "") == "diagnostic_synthesis":
                        has_synth = True
                    for s in sub_plan.steps:
                        if s.tool in ("diagnose_system", "audit_and_reclaim_ram") and s.tool in seen_tools:
                            continue
                        seen_tools.add(s.tool)
                        s.step = len(multi_steps) + 1

                        if s.tool in ("search_files", "find_file", "find_process", "find_application"):
                            last_producer_step_idx = s.step
                        elif s.tool in ("launch_app", "focus_app") and s.args.get("name") and context:
                            context.last_application = TypedEntity(s.args["name"], EntityType.APPLICATION)
                        elif s.tool in ("open_folder", "list_folder") and s.args.get("path") and context:
                            context.last_active_directory = s.args["path"]

                        multi_steps.append(s)
            if len(multi_steps) >= 2:
                synth = "diagnostic_synthesis" if has_synth or any(s.tool == "diagnose_system" for s in multi_steps) else ""
                return Plan(steps=multi_steps, synthesis_mode=synth, constraints=extracted_constraints, explanation="Executed multi-step compound workflow.")
            elif len(multi_steps) == 1:
                synth = "diagnostic_synthesis" if has_synth or multi_steps[0].tool == "diagnose_system" else ""
                return Plan(steps=multi_steps, synthesis_mode=synth, constraints=extracted_constraints, explanation="Executed single-purpose workflow.")

    # 0. Strip leading and trailing polite/conversational particles from user command
    text_unwrapped = re.sub(
        r'^(?:can\s+you\s+(?:please\s+)?(?:see\s+if|tell\s+me|let\s+me\s+know|check\s+if)?|'
        r'could\s+you\s+(?:please\s+)?(?:see\s+if|tell\s+me|check\s+if)?|'
        r'i\s+wonder\s+if|would\s+you\s+mind\s+(?:checking\s+if)?|would\s+you\s+(?:verify\s+if)?|'
        r'check\s+if\s+(?:there\s+are\s+any)?|'
        r'please|zara|bhai|janab|agar\s+ho\s+sake\s+to|jaldi\s+se|jaldi|foran|abhi\s+ke\s+abhi|abhi)\s+',
        '', cleaned, flags=re.IGNORECASE
    ).strip()
    text_unwrapped = re.sub(r'\s+(?:please|bhai|janab|shukriya|thanks|thank\s+you)$', '', text_unwrapped, flags=re.IGNORECASE).strip()
    if text_unwrapped and text_unwrapped != cleaned:
        cleaned = text_unwrapped
        raw_lower = cleaned.lower()

    # 0.048 Complex Negative Exclusions (Bullet #30)
    exclusion_patterns = [
        r'\b(?:close|terminate|kill|band\s+karo|band\s+kardo)\s+(?:all|everything|saare|sab|apps?)\s+(?:except|without|sivaye|chhor\s+kar|chhod\s+kar|ko\s+chhor\s+kar)\s+([a-zA-Z0-9_\-]+)\b',
        r'\b([a-zA-Z0-9_\-]+)\s+(?:ko\s+)?(?:chhor\s+kar|chhod\s+kar|ke\s+elawa|ke\s+alawa)\s+(?:sab|saare|baqi\s+sab)\s+(?:apps?\s+)?(?:band\s+karo|band\s+kardo|close|terminate)\b',
        r'\b(?:close|terminate)\s+everything\s+except\s+([a-zA-Z0-9_\-]+)\b',
        r'\b(?:har\s+cheez|sab\s+kuch)\s+band\s+karo\s+sivaye\s+([a-zA-Z0-9_\-]+)\b',
    ]
    for ex_pat in exclusion_patterns:
        ex_m = re.search(ex_pat, raw_lower)
        if ex_m:
            excluded_target = ex_m.group(1).lower().strip()
            candidate_apps = ["chrome", "edge", "notepad", "calc", "wordpad"]
            targets_to_close = [a for a in candidate_apps if a != excluded_target and a not in excluded_target]
            steps = [
                PlanStep(step=i+1, tool="close_app", args={"name": app_name})
                for i, app_name in enumerate(targets_to_close[:2])
            ]
            return Plan(
                steps=steps,
                constraints=[f"exclude:{excluded_target}", f"without {excluded_target}", f"preserve {excluded_target}"],
                explanation=f"Closing running applications while strictly preserving '{excluded_target}'."
            )

    # 0.05 Explicit Negation / Prohibition Interception
    if (
        re.search(r'\b(mat\s+kholo|mat\s+khol|mat\s+open|don\'t\s+open|dont\s+open|do\s+not\s+open|never\s+open|kholo\s+mat|open\s+mat|kholne\s+ki\s+zaroorat\s+nahi|kholne\s+ki\s+zarurat\s+nahi|kholna\s+nahi|open\s+karne\s+ki\s+(?:[a-zA-Z0-9_\s]+\s+)?zaroorat\s+nahi|open\s+karne\s+ki\s+(?:[a-zA-Z0-9_\s]+\s+)?zarurat\s+nahi|zaroorat\s+nahi\s+hai|zarurat\s+nahi\s+hai|no\s+need\s+to\s+open)\b', raw_lower)
        and not any(w in raw_lower for w in ["find", "search", "dhundo", "status", "check", "inspect"])
    ):
        app_match = re.search(r'\b(chrome|notepad|calculator|calc|code|vscode|edge|firefox|word|excel|store|settings)\b', raw_lower)
        if app_match:
            app_cand = app_match.group(1).capitalize()
        else:
            app_cand = re.sub(r'\b(mat\s+kholo|mat\s+khol|mat\s+open|don\'t\s+open|dont\s+open|do\s+not\s+open|never\s+open|kholo\s+mat|open\s+mat|kholne\s+ki\s+zaroorat\s+nahi|kholne\s+ki\s+zarurat\s+nahi|kholna\s+nahi|open\s+karne\s+ki|bilkul\s+zaroorat\s+nahi\s+hai|bilkul\s+zarurat\s+nahi\s+hai|zaroorat\s+nahi\s+hai|zarurat\s+nahi\s+hai|zaroorat\s+nahi|zarurat\s+nahi|bilkul|open|kholo|please|yaar|bhai)\b', '', raw_lower).strip()
            app_cand = app_cand.capitalize() or "Application"
        return Plan(is_direct_message=True, message_text=f"Action negated: '{app_cand}' will not be opened as requested.")

    if re.search(r'\b(leave\s+that|chhoro|rehne\s+do|rahne\s+do|cancel|click\s+mat|mat\s+click|don\'t\s+click|dont\s+click)\b', raw_lower) and not any(w in raw_lower for w in ["open", "kholo", "launch", "run", "start"]):
        return Plan(is_direct_message=True, message_text="Understood. Operation cancelled, no click will be performed.")

    # WiFi & Bluetooth settings launch
    if ("settings" in raw_lower or "setting" in raw_lower) and any(w in raw_lower for w in ["kholo", "open", "launch", "show"]):
        if "bluetooth" in raw_lower and not re.search(r'\bbluetooth\s+nahi\b', raw_lower):
            constraints = ["wi-fi nahi"] if ("wi-fi" in raw_lower or "wifi" in raw_lower) else []
            return Plan(steps=[PlanStep(step=1, tool="launch_app", args={"name": "ms-settings:bluetooth"})], explanation="Opened Bluetooth settings page.", constraints=constraints)
        if any(w in raw_lower for w in ["wifi", "wi-fi", "network"]) and not re.search(r'\b(?:wi-fi|wifi|network)\s+nahi\b', raw_lower):
            return Plan(steps=[PlanStep(step=1, tool="launch_app", args={"name": "ms-settings:network-wifi"})], explanation="Opened Wi-Fi settings page.")

    if (
        re.search(r'\b(status\s+mat|mat\s+batao|mat\s+bata|don\'t\s+show\s+status|do\s+not\s+show\s+status|without\s+status)\b', raw_lower)
        and not any(w in raw_lower for w in ["open", "kholo", "launch", "run", "start", "settings", "setting", "search", "dhoondo", "dhundo"])
    ):
        return Plan(is_direct_message=True, message_text="Action negated: Status will not be displayed as requested.")

    # 0.06 Conversational Acknowledgements / Task Completion Closing
    if any(p in raw_lower for p in [
        "theek hai bas itna hi chahiye tha", "bas itna hi chahiye tha", "theek hai bas", "bas itna hi",
        "that's all for now", "thats all for now", "that is all for now", "all good for now", "shukriya bas"
    ]):
        return Plan(is_direct_message=True, message_text="Understood. Let me know whenever you need further assistance.")

    # 0.07 Execution History & Audit Inquiries
    if any(p in raw_lower for p in [
        "last command ka result", "pichhli command ka status", "kaunsi command fail hui thi",
        "maine abhi kya check karwaya tha", "what was the last command", "which command failed",
        "command failure report", "execution history audit",
        "kaunsi wali command execute nahi ho saki", "kaunsi command execute nahi ho saki",
        "kaunsi command fail hui", "kaunsi wali command fail", "commands run ki theen",
        "abhi thori der pehle humne jo commands", "commands ya steps fail", "fail hue kya", "kya fail hua"
    ]):
        if "fail" in raw_lower or "nahi ho saki" in raw_lower:
            rep = agent_state.format_failure_report()
            return Plan(is_direct_message=True, message_text=rep)
        last_cmd = agent_state.get_last_command()
        if last_cmd:
            return Plan(is_direct_message=True, message_text=f"Last executed command was '{last_cmd.raw_command}' using tool '{last_cmd.selected_tool}' (Status: {last_cmd.final_status}).")
        return Plan(is_direct_message=True, message_text="No previous commands recorded in this session.")

    # -------------------------------------------------------------
    # 0.69 CROSS-SYSTEM DIAGNOSIS ENGINE INTENTS (Phase 2 Part 9)
    # -------------------------------------------------------------
    # Network actions / reset disambiguation
    if any(p in raw_lower for p in ["network reset", "reset network", "restart network"]):
        return Plan(is_direct_message=True, message_text="Network reset/repair is restricted for safety and restricted for security; only diagnostics are permitted.")

    # RAM & Process Memory Janitor (Low-Spec Hardening & Working Set Trim)
    if (
        any(p in raw_lower for p in [
            "clean ram", "free memory", "optimize memory", "ram pressure", "flush cache",
            "free background ram", "reclaim ram", "clean memory", "flush ram", "audit and reclaim ram",
            "audit_and_reclaim_ram", "memory optimize", "memory cleaner", "clear ram", "clear memory",
            "trim memory", "trim working set", "empty working set", "purge ram", "ram clean",
            "memory flush", "flush memory", "optimize ram"
        ])
        or (("ram" in raw_lower or "memory" in raw_lower) and any(w in raw_lower for w in ["clean", "optimize", "flush", "reclaim", "trim", "purge", "janitor"]))
    ):
        if is_compound_root and any(sep in raw_lower for sep in [",", ";", " phir ", " aur ", " then ", " and ", " ke baad ", " after that ", " iske baad ", " uske baad "]):
            from brain.workflow_orchestrator import orchestrate_compound_workflow
            orch_plan = orchestrate_compound_workflow(text, context)
            if orch_plan is not None and orch_plan.steps and len(orch_plan.steps) > 1:
                return orch_plan
        target_usage = 80.0
        pct_match = re.search(r'(\d+(?:\.\d+)?)\s*%', raw_lower)
        if pct_match:
            try:
                target_usage = float(pct_match.group(1))
            except ValueError:
                target_usage = 80.0
        return Plan(
            steps=[PlanStep(step=1, tool="audit_and_reclaim_ram", args={"target_usage_percent": target_usage})],
            explanation="Audited memory pressure and trimmed dormant process working sets."
        )

    # 1. Whole-System Health & Root-Cause Diagnosis
    if (
        any(p in raw_lower for p in [
            "diagnose my computer", "what's wrong with my system", "check my system health",
            "check what's causing the problem", "mera computer diagnose karo", "system mein kya problem hai",
            "system health check", "mere system ka masla check karo", "computer mein problem kya hai",
            "system diagnostic", "run diagnostics", "pc health check", "computer ka health check",
            "diagnose computer", "diagnose system", "system status", "pc status", "computer status",
            "check pc", "check system", "check computer"
        ]) or (
            ("health" in raw_lower or "problem" in raw_lower or "masla" in raw_lower or "diagnos" in raw_lower or "abnormality" in raw_lower)
            and any(w in raw_lower for w in ["system", "computer", "pc", "laptop"])
            and not any(act in raw_lower for act in ["restart", "shutdown", "format", "reset", "close", "band", "kholo", "open", "snapshot"])
        )
    ):
        return Plan(
            steps=[PlanStep(step=1, tool="diagnose_system", args={})],
            synthesis_mode="diagnostic_synthesis",
            explanation="Conducted holistic cross-system health diagnosis."
        )

    # 2. Performance & Slowness Diagnosis
    if symptom_cat not in (SymptomCategory.COMPOSITE, SymptomCategory.THERMAL_PERFORMANCE) and (
        any(p in raw_lower for p in [
            "why is my computer slow", "why is my pc lagging", "diagnose the performance problem",
            "why is the system slow", "mera computer slow kyun hai", "pc slow kyun chal raha hai",
            "ye system slow kyun hai", "computer slow kyun hai", "system lag kyun kar raha hai",
            "slowness diagnose karo", "performance problem"
        ]) or (
            "slow kyun" in raw_lower and any(w in raw_lower for w in ["computer", "pc", "system", "laptop"])
        ) or (
            any(w in raw_lower for w in ["fans bhi tez", "tez chal rahe", "heavy chal raha", "bojh", "pressure"])
            or (("cpu" in raw_lower or "ram" in raw_lower or "processor" in raw_lower) and any(w in raw_lower for w in ["consume", "poora consume", "heavy chal raha", "pressure", "bojh"]))
        ) or (
            raw_lower.strip().rstrip("?") in ("ye slow kyun hai", "why is this slow")
            and not (context.last_application or context.last_browser)
        ) or (
            ("pc slow" in raw_lower or "computer slow" in raw_lower or "system slow" in raw_lower)
            and not any(act in raw_lower for act in ["reset", "restart", "format"])
            and not (("disk" in raw_lower or "storage" in raw_lower or "hard drive" in raw_lower) and any(w in raw_lower for w in ["ki wajah se", "due to", "because of"]))
        ) or (
            "unresponsive" in raw_lower and any(w in raw_lower for w in ["machine", "load", "system", "pc", "computer"])
        )
    ):
        return Plan(steps=[PlanStep(step=1, tool="diagnose_performance", args={})], explanation="Diagnosed multi-subsystem performance bottleneck.")

    # 3. Contextual Diagnosis (App / Browser / System)
    if any(p in raw_lower for p in ["isko diagnose karo", "diagnose this app", "diagnose this program"]):
        app_tgt = _entity_val(context.last_application) if context.last_application else None
        if app_tgt:
            return Plan(steps=[PlanStep(step=1, tool="diagnose_application", args={"name": app_tgt})], explanation=f"Diagnosed application {app_tgt}.")

    if raw_lower.strip().rstrip("?") in ("ye slow kyun hai", "why is this slow"):
        if context.last_browser:
            b_val = _entity_val(context.last_browser)
            return Plan(steps=[PlanStep(step=1, tool="diagnose_browser", args={"browser": b_val})], explanation=f"Diagnosed browser {b_val}.")
        elif context.last_application:
            a_val = _entity_val(context.last_application)
            return Plan(steps=[PlanStep(step=1, tool="diagnose_application", args={"name": a_val})], explanation=f"Diagnosed application {a_val}.")

    # 3.65 Multi-Adapter & Radio Band Conflict Analyzer
    if any(p in raw_lower for p in [
        "diagnose multi adapter conflict", "multi adapter conflict", "adapter conflict",
        "scan wifi 2.4ghz vs 5ghz", "scan wifi 2.4ghz", "wifi 2.4ghz vs 5ghz",
        "2.4ghz vs 5ghz", "band compatibility", "wifi band conflict", "adapter routing conflict"
    ]) or (
        ("adapter" in raw_lower or "wifi" in raw_lower or "wi-fi" in raw_lower)
        and any(w in raw_lower for w in ["conflict", "2.4ghz", "5ghz", "metric collision", "multi adapter", "multi-adapter"])
    ):
        return Plan(steps=[PlanStep(step=1, tool="analyze_multi_adapter_and_bands", args={})], explanation="Audited multi-adapter routing metrics and 2.4GHz vs 5GHz band compatibility.")

    # 3.66 ARP Cache Audit
    if any(p in raw_lower for p in ["audit arp cache", "arp cache", "check arp", "scan arp"]):
        return Plan(steps=[PlanStep(step=1, tool="diagnose_network_health", args={})], explanation="Audited ARP cache and network interface health.")

    # 3.7 Ultra-Deep Hardware/Service Wi-Fi Stack Diagnoser & Auto-Healer
    if any(p in raw_lower for p in [
        "auto fix wifi stack", "remediate and repair wifi connection",
        "fix wifi stack", "repair wifi stack", "remediate wifi stack", "auto repair wifi connection"
    ]) or (
        ("remediate" in raw_lower or "repair" in raw_lower or "auto fix" in raw_lower)
        and ("wifi" in raw_lower or "wi-fi" in raw_lower)
        and any(w in raw_lower for w in ["stack", "connection", "adapter"])
    ):
        return Plan(steps=[PlanStep(step=1, tool="remediate_wifi_stack", args={})], explanation="Executed autonomous Wi-Fi stack remediation.")

    if any(p in raw_lower for p in [
        "why is wifi not showing", "deep audit wifi hardware and services",
        "check wifi driver error and wlan service", "wifi not showing",
        "audit wifi hardware", "check wifi driver error", "check wlan service", "wifi driver error"
    ]) or (
        ("wifi" in raw_lower or "wi-fi" in raw_lower)
        and any(w in raw_lower for w in ["not showing", "driver error", "wlan service", "hardware and services", "hardware audit"])
    ):
        return Plan(steps=[PlanStep(step=1, tool="audit_wifi_hardware_and_services", args={})], explanation="Audited Wi-Fi hardware, WLAN AutoConfig service, driver errors, and RF kill-switch.")


    return None
