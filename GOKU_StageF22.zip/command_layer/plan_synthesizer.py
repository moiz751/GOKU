from __future__ import annotations
import os
import re
import sys
import urllib.parse
from typing import Any, Optional, Dict, List, Set, Tuple

from command_layer.semantic_model import (
    SemanticDomain,
    SemanticAction,
    RequestType,
    EntityType,
    CommandIntent,
    AmbiguityType,
    ClarificationRequest,
    SymptomCategory,
    SituationType,
    ConfidenceTier,
    RiskTier,
    ConfidenceScore,
    ConfirmationRequest,
    FailureType,
    AdaptiveStrategy,
    PlanAdaptation,
    TaskLifecycleState,
    TaskMilestone,
    TaskCheckpoint,
    DomainBridgeType,
    DomainBridgeLink,
    CrossDomainWorkflow,
    HorizonDepth,
    ExplorationNode,
    SearchFrontier,
    LongHorizonReport,
    HistoryQueryType,
    ExecutionTraceRecord,
    TraceSummary,
)
from brain.planner import Plan, PlanStep
from command_layer.state_machine import agent_state

def create_plan_from_intent(intent: CommandIntent) -> Any:
    """
    Converts a validated CommandIntent into an executable Plan while strictly
    respecting the Tool Selection Firewall.
    """
    from brain.planner import Plan, PlanStep
    domain = intent.domain
    action = intent.action

    # 0. Explicit Negation Handling
    if getattr(intent, "is_negated", False):
        action_name = intent.action.value if hasattr(intent.action, "value") else str(intent.action)
        return Plan(
            is_direct_message=True,
            message_text=f"Action negated: Will not execute {action_name} on '{intent.target}' as requested by user."
        )

    # 0.5 Explicit Direct Message / Security Prohibited
    if getattr(intent, "selected_tool", None) == "DIRECT_MESSAGE":
        msg = intent.tool_args.get("message", "Operation restricted for safety and security.")
        return Plan(is_direct_message=True, message_text=msg)

    # 0.6 Generalized Capability Dispatch
    if getattr(intent, "selected_tool", None):
        return Plan(
            steps=[PlanStep(step=1, tool=intent.selected_tool, args=intent.tool_args, constraints=intent.constraints)],
            explanation=intent.expected_outcome or f"Executed capability '{intent.selected_tool}'.",
            constraints=intent.constraints
        )

    # 1. Conversation / Self-Observation History
    if domain == SemanticDomain.CONVERSATION_HISTORY:
        if intent.target in ("failed_commands", "failed_commands_detailed"):
            failed = agent_state.get_failed_commands()
            if not failed:
                return Plan(
                    is_direct_message=True,
                    message_text="No commands have failed in the current session. All previous operations completed successfully."
                )
            lines = [
                "Here are the failed commands recorded in this session:"
            ]
            for idx, f in enumerate(failed, 1):
                reason = f.failure_reason or "Verification unverified"
                expected = getattr(f, "norm_cmd", None) or f.user_command
                tools_used = ", ".join(f.tools) if f.tools else "None"
                lines.append(
                    f"  [{idx}] Command: '{f.user_command}'\n"
                    f"      - Selected Tool(s): {tools_used}\n"
                    f"      - Expected Outcome: Successful execution of intent '{expected}'\n"
                    f"      - Observed Outcome: {reason}\n"
                    f"      - Recovery Attempted: Evaluated fallback; recorded limitation honestly\n"
                    f"      - Final Status: {f.status}"
                )
            return Plan(is_direct_message=True, message_text="\n".join(lines))

        elif intent.target == "did_scan_computer":
            scans = [r for r in agent_state.execution_history if "scan_computer" in getattr(r, "tools", [])]
            if scans:
                last_scan = scans[-1]
                return Plan(
                    is_direct_message=True,
                    message_text=f"Yes, a computer scan was performed earlier in this session. Status: {last_scan.status} (Verified: {last_scan.verified})."
                )
            return Plan(
                is_direct_message=True,
                message_text="No, a computer discovery scan has not been performed yet in this session."
            )

        elif intent.target == "last_command":
            last_cmd = agent_state.get_last_command()
            if not last_cmd:
                return Plan(is_direct_message=True, message_text="No commands have been executed in this session yet.")
            return Plan(
                is_direct_message=True,
                message_text=f"Last executed command was: '{last_cmd.user_command}'. Status: {last_cmd.status} (Verified: {last_cmd.verified})."
            )

    # 1.5 Whole-System Health Diagnostics
    if domain == SemanticDomain.DIAGNOSTICS and intent.target == "system_health":
        return Plan(
            steps=[PlanStep(step=1, tool="diagnose_system", args={})],
            synthesis_mode="diagnostic_synthesis",
            explanation="Synthesized whole-system health across CPU, memory, storage, network, and active processes."
        )

    # 1.6 Novel Human Language Intents
    if intent.target == "windows_search":
        return Plan(steps=[PlanStep(step=1, tool="press_hotkey", args={"keys": "win+s"})])

    if intent.target == "current_page" and domain == SemanticDomain.BROWSER:
        return Plan(steps=[PlanStep(step=1, tool="get_active_window", args={})])

    if intent.target == "current_tab_avoid_duplicates":
        return Plan(steps=[
            PlanStep(step=1, tool="focus_app", args={"name": "Chrome"}),
            PlanStep(step=2, tool="get_active_window", args={})
        ])

    if domain == SemanticDomain.FILESYSTEM and action == SemanticAction.INSPECT and intent.target in ("Downloads", "Desktop", "Documents"):
        return Plan(steps=[PlanStep(step=1, tool="list_folder", args={"path": intent.target})])

    if domain == SemanticDomain.FILESYSTEM and intent.target == "duplicate_files":
        return Plan(
            is_direct_message=True,
            message_text="Capability limitation: Full C: drive and disk-wide duplicate file scanning is restricted for performance and security. Only bounded folders like Downloads can be analyzed."
        )

    if domain == SemanticDomain.APPLICATION and action == SemanticAction.LAUNCH:
        if "no_new_tab" in getattr(intent, "constraints", []):
            return Plan(steps=[PlanStep(step=1, tool="focus_app", args={"name": intent.target})])

    # 2. Ambiguity Clarification
    if domain == SemanticDomain.BROWSER and action == SemanticAction.CLARIFY:
        msg = (
            intent.entities.get("clarification")
            or intent.entities.get("message")
            or "No browser profiles were found in active context. Please specify which profile name you want to use."
        )
        return Plan(is_direct_message=True, message_text=msg)

    if action == SemanticAction.CLARIFY:
        msg = (
            intent.entities.get("clarification")
            or intent.entities.get("message")
            or "Please provide additional clarification for this command."
        )
        return Plan(is_direct_message=True, message_text=msg)

    # 3. Settings Navigation & WiFi Verification (Section 56 TEST 5, RED-TEAM D & E)
    if domain == SemanticDomain.SETTINGS:
        if intent.target == "network-wifi-with-verification":
            return Plan(
                steps=[
                    PlanStep(step=1, tool="launch_app", args={"name": "ms-settings:network-wifi"}),
                    PlanStep(step=2, tool="get_wifi_status", args={}),
                ],
                explanation="Opened Windows Settings WiFi connection page and verified current network signal."
            )
        else:
            page = intent.entities.get("page", "network-wifi")
            uri = f"ms-settings:{page}"
            return Plan(
                steps=[PlanStep(step=1, tool="launch_app", args={"name": uri})],
                explanation=f"Opening Windows Settings page '{page}'."
            )

    if domain == SemanticDomain.NETWORK and action == SemanticAction.INSPECT:
        return Plan(
            steps=[PlanStep(step=1, tool="get_wifi_status", args={})],
            explanation="Retrieved active Wi-Fi status without navigating GUI settings."
        )

    # 4. GUI Mouse Target & Literal Typing (Section 56 TEST 3 & 4, RED-TEAM A & B)
    if domain == SemanticDomain.GUI:
        if action == SemanticAction.MOVE_MOUSE:
            if intent.target == "coordinates":
                return Plan(steps=[PlanStep(step=1, tool="move_mouse", args={"x": intent.entities["x"], "y": intent.entities["y"]})])
            target_elem = intent.entities.get("target_query", "search bar")
            agent_state.current_domain = SemanticDomain.GUI
            agent_state.current_mouse_target = {"target_query": target_elem}
            return Plan(
                steps=[PlanStep(step=1, tool="find_and_interact", args={"target_query": target_elem, "action": "move"})],
                explanation=f"Locating '{target_elem}' on screen and moving mouse over it."
            )
        elif action == SemanticAction.TYPE:
            target_elem = intent.entities.get("target_query", "search bar")
            text_val = intent.entities.get("text", "")
            return Plan(
                steps=[PlanStep(step=1, tool="find_and_interact", args={"target_query": target_elem, "action": "type", "input_text": text_val})],
                explanation=f"Typed literal text into '{target_elem}'."
            )

    # 5. Protected Filesystem Search (Section 57 RED-TEAM C)
    if domain == SemanticDomain.FILESYSTEM and action == SemanticAction.FIND:
        fn = intent.entities.get("filename", "")
        folder = intent.entities.get("folder", "Downloads")
        return Plan(
            steps=[PlanStep(step=1, tool="find_file", args={"name": fn, "start_folder": folder})],
            explanation=f"Searching for file '{fn}' in '{folder}' folder."
        )

    # 6. Compound Filesystem Context Flow (Section 56 TEST 2 & Section 54)
    if domain == SemanticDomain.FILESYSTEM and intent.target == "downloads_pdf_workflow":
        folder = intent.entities.get("folder", "Downloads")
        ext = intent.entities.get("extension", "pdf")
        return Plan(
            steps=[
                PlanStep(step=1, tool="open_folder", args={"path": folder}),
                PlanStep(step=2, tool="find_file", args={"name": ext, "start_folder": folder}),
                PlanStep(step=3, tool="get_file_metadata", args={"path": "$step_2.matches[0]"}),
                PlanStep(step=4, tool="open_file", args={"path": "$step_2.matches[0]"}),
                PlanStep(step=5, tool="get_foreground_application", args={}),
            ],
            explanation="Opened Downloads folder, located PDF files, inspected size of first match, opened it, and verified active viewer application."
        )

    if domain == SemanticDomain.FILESYSTEM and intent.target == "downloads_first_pdf_size":
        folder = intent.entities.get("folder", "Downloads")
        ext = intent.entities.get("extension", "pdf")
        return Plan(
            steps=[
                PlanStep(step=1, tool="find_file", args={"name": ext, "start_folder": folder}),
                PlanStep(step=2, tool="get_file_metadata", args={"path": "$step_1.matches[0]"}),
            ],
            explanation=f"Found PDF files in {folder} and retrieved metadata/size for the first result."
        )

    # 7. Browser Flows (Section 56 TEST 1 & 6, RED-TEAM F, Section 54)
    if domain == SemanticDomain.BROWSER:
        if intent.target == "web_search_and_verify":
            query = intent.entities.get("query", "new AI modules for developers")
            encoded_query = urllib.parse.quote_plus(query)
            search_url = f"https://www.google.com/search?q={encoded_query}"
            return Plan(
                steps=[
                    PlanStep(step=1, tool="open_url", args={"url": search_url, "browser": "chrome"}),
                    PlanStep(step=2, tool="find_and_interact", args={"target_query": "first result", "action": "click"}),
                    PlanStep(step=3, tool="get_active_window", args={}),
                ],
                explanation=f"Searched Google for '{query}', navigated to the first relevant result, and verified page title."
            )

        elif intent.target == "conditional_chrome_lifecycle":
            return Plan(
                steps=[
                    PlanStep(step=1, tool="is_app_running", args={"name": "chrome"}),
                    PlanStep(
                        step=2,
                        tool="launch_app",
                        args={"name": "chrome"},
                        condition={"field": "running", "op": "==", "value": False}
                    ),
                ],
                explanation="Checked if Chrome is running; launched it if not active, or reused existing process."
            )

        elif intent.target == "conditional_youtube_search":
            query = intent.entities.get("query", "AI tools for developers")
            encoded_query = urllib.parse.quote_plus(query)
            yt_url = f"https://www.youtube.com/results?search_query={encoded_query}"
            return Plan(
                steps=[
                    PlanStep(step=1, tool="is_app_running", args={"name": "chrome"}),
                    PlanStep(
                        step=2,
                        tool="launch_app",
                        args={"name": "chrome"},
                        condition={"field": "running", "op": "==", "value": False}
                    ),
                    PlanStep(step=3, tool="open_url", args={"url": yt_url, "browser": "chrome"}),
                    PlanStep(step=4, tool="find_and_interact", args={"target_query": "first result", "action": "click"}),
                    PlanStep(step=5, tool="get_active_window", args={}),
                ],
                explanation=f"Reused running Chrome or launched it, searched YouTube for '{query}', opened first result, and verified title."
            )

        elif intent.target == "first_search_result":
            return Plan(
                steps=[PlanStep(step=1, tool="find_and_interact", args={"target_query": "first result", "action": "click"})],
                explanation="Clicked the first search result in the browser."
            )

        elif intent.target == "page_title":
            return Plan(
                steps=[PlanStep(step=1, tool="get_active_window", args={})],
                explanation="Inspected active browser window to verify page title."
            )

        elif intent.target == "web":
            from tools.browser import sanitize_search_query
            raw_q = intent.entities.get("query", "")
            query = sanitize_search_query(raw_q)
            encoded_query = urllib.parse.quote_plus(query)
            search_url = f"https://www.google.com/search?q={encoded_query}"
            return Plan(
                steps=[PlanStep(step=1, tool="open_url", args={"url": search_url, "browser": "chrome"})],
                explanation=f"Searching the web for '{query}' using Chrome."
            )

        elif intent.target == "chatgpt":
            deep_query = intent.entities.get("deep_query", "how to download video game for free")
            return Plan(
                steps=[
                    PlanStep(step=1, tool="open_url", args={"url": "https://chatgpt.com", "browser": "chrome"}),
                    PlanStep(step=2, tool="find_and_interact", args={"target_query": "Ask anything", "action": "click"}),
                    PlanStep(step=3, tool="type_text", args={"text": deep_query, "press_enter": True}),
                ],
                explanation="Opened ChatGPT in Chrome and submitted user prompt into search/input area."
            )

    # 8. Store Search & Boundary (Failure F)
    if domain == SemanticDomain.APPLICATION and intent.target == "Microsoft Store":
        app_name = intent.entities.get("app_to_find", "Angry Birds 2")
        return Plan(
            steps=[
                PlanStep(step=1, tool="launch_app", args={"name": "ms-windows-store:"}),
                PlanStep(step=2, tool="wait_for_ui_settle", args={"delay_ms": 2500}),
                PlanStep(step=3, tool="click_element_by_text", args={"target_text": "Search"}),
                PlanStep(step=4, tool="send_keyboard_input", args={"text": app_name, "press_enter": True}),
            ],
            explanation=f"Autonomous loop: Opened Microsoft Store, waited for UI settle, clicked Search, and typed '{app_name}'."
        )

    # 10. Generalized Capability Dispatch
    if intent.selected_tool == "DIRECT_MESSAGE":
        msg = intent.tool_args.get("message", "Operation restricted for safety and security.")
        return Plan(is_direct_message=True, message_text=msg)
    elif intent.selected_tool:
        return Plan(
            steps=[PlanStep(step=1, tool=intent.selected_tool, args=intent.tool_args, constraints=intent.constraints)],
            explanation=intent.expected_outcome or f"Executed capability '{intent.selected_tool}'.",
            constraints=intent.constraints
        )

    return Plan(is_direct_message=True, message_text="Could not build plan for semantic intent.")
