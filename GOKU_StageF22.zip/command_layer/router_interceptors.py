from __future__ import annotations
import os
from pathlib import Path
import re
import sys
import time
from typing import Any, Optional, Union, List, Dict, Tuple
from dataclasses import dataclass, field

from brain.planner import (
    Plan,
    PlanStep,
    StructuredIntent,
    create_plan_from_decision,
    decompose_compound_command,
    parse_compound_request,
    resolve_step_variables,
    resolve_step_variables_with_guard,
    inject_plan_prerequisites,
    prune_plan_steps,
    build_hypothesis_investigation_plan,
    build_root_cause_investigation_plan,
    parse_conditional_goal,
    synthesize_adaptive_replan,
    decompose_into_milestones,
    restore_plan_from_checkpoint,
    build_cross_domain_plan,
    apply_cross_domain_transformation,
    build_long_horizon_exploration_plan,
    decompose_long_horizon_goal,
    compute_state_hash,
    detect_state_cycle,
    heuristic_node_score,
    expand_exploration_frontier,
    select_next_frontier_node,
    apply_reflective_history_pruning,
)
from command_layer.cognitive_reasoner import CognitiveReasoner
from command_layer.context import (
    EntityType,
    TypedEntity,
    ORDINAL_REFERENCES,
    SessionContext,
    resolve_references,
    session_context,
    update_context_from_result,
)
from command_layer.semantic_model import (
    SemanticDomain,
    SemanticAction,
    CommandIntent,
    AmbiguityType,
    ClarificationRequest,
    SymptomCategory,
    SituationType,
    ConfidenceTier,
    RiskTier,
    ConfidenceScore,
    ConfirmationRequest,
    FailureType,
    AdaptiveStrategy,
    PlanAdaptation,
    TaskLifecycleState,
    TaskMilestone,
    TaskCheckpoint,
    DomainBridgeType,
    DomainBridgeLink,
    CrossDomainWorkflow,
    HorizonDepth,
    ExplorationNode,
    SearchFrontier,
    LongHorizonReport,
    HistoryQueryType,
    ExecutionTraceRecord,
    TraceSummary,
)
from command_layer.semantic_parser import (
    parse_semantic_intent,
    create_plan_from_intent,
    resolve_in_turn_correction,
    strip_conversational_noise,
    split_compound_clauses,
    detect_symptom_category,
)
from command_layer.firewall import validate_tool_against_firewall, pre_execution_semantic_check, validate_long_horizon_action
from command_layer.state_machine import agent_state
from command_layer.validator import validate_and_sanitize_tool_arguments
from command_layer.lexer import UniversalLexer
from brain.runtime_bus import RuntimePipingBus
from security.state import confirmation_manager
from tools.utils.app_resolver import (
    APP_ALIASES,
    get_canonical_app_name,
    resolve_app,
)
from tools.utils.target_resolver import TargetType, resolve_universal_target, disambiguate_multi_candidates
from command_layer.router_base import (
    Step,
    run_tool_call,
    resolve_system_canonical_path,
    verify_post_recovery,
    verify_semantic_outcome,
    capture_environment_snapshot,
    capture_step_observation,
    detect_environment_drift,
    _entity_val,
    get_all_schemas,
    KNOWN_SITE_KEYS,
    KNOWN_APP_NAMES,
    _has_file_extension,
    _normalize_resolved_path,
    _is_conversational_folder_path,
)
from security.safety_firewall import is_safe_readonly_operation
from security.confirm import RISKY_TOOLS
from command_layer.decomposer import count_action_verbs
from brain.workflow_orchestrator import orchestrate_compound_workflow
from tools.browser import sanitize_search_query
from tools.search import parse_search_grammar
import executor.verifier
import executor.executor

from command_layer.router_sanitizer import (
    _isolate_browser_context,
    prune_negated_steps,
    sanitize_action_query,
    sanitize_url,
    _canonicalize_plan_tools,
    sanitize_ui_target,
    extract_clean_search_query,
)
from command_layer.router_cli_parser import (
    translate_cli_command,
    sanitize_cli_command,
    extract_pure_text_payload,
    parse_sequential_keyboard_actions,
    is_standalone_navigation_request,
    resolve_temporal_order,
    strip_idiomatic_conditions,
)
from command_layer.router_confidence import (
    determine_risk_tier,
    format_uncertainty_response,
    compute_command_confidence,
    synthesize_cross_domain_report,
    synthesize_long_horizon_report,
    get_conversational_response,
)
from command_layer.router_classifier_core import _classify_and_parse_command

from command_layer.router_core import decompose_deterministic_plan

def intercept_user_command(user_text: str, session_context: Any = None, raw_input: str = '', is_correction: bool = False, plan: Plan | None = None) -> Any:
    normalized_input = raw_input
    clean_lower = raw_input.lower()
    # ═══════════════════════════════════════════════════════════════════════════
    # TOP-LEVEL COMPOUND ORCHESTRATION GUARD
    # MUST run before ANY semantic/typing patterns, Phase 0–5 early returns, or
    # LLM fallback. If the command has conjunctions + 2+ lifecycle verbs, it is
    # a multi-step pipeline. Force orchestrate_compound_workflow immediately and
    # store the plan so all subsequent `if plan is None:` gates are skipped,
    # preventing any single-intent type_text / ctrl+s macro from being returned.
    # ═══════════════════════════════════════════════════════════════════════════
    
    # Priority 0: Deterministic Conjunction Decomposer (Dual-Core Engine)
    if plan is None:
        det_plan = decompose_deterministic_plan(raw_input)
        if det_plan is not None and det_plan.steps and not getattr(det_plan, "is_direct_message", False):
            plan = det_plan

    # Priority 0: Web Domain Navigation (Strictly standalone only)
    if plan is None and is_standalone_navigation_request(raw_input):
        domain_match = re.search(r'(https?://[^\s\]\)]+|\b[a-zA-Z0-9-]+\.(?:com|pk|org|net|io|edu)(?:/[^\s\]\)]*)?\b)', raw_input, re.IGNORECASE)
        if domain_match and any(k in raw_input.lower() for k in ['kholo', 'open', 'jao', 'browser', 'chrome']):
            url = sanitize_url(domain_match.group(1))
            steps = [
                PlanStep(step=1, tool='launch_app', args={'name': 'chrome'}),
                PlanStep(step=2, tool='open_url', args={'url': url, 'browser': 'chrome'})
            ]
            if hasattr(session_context, 'agent_opened_tabs'):
                session_context.agent_opened_tabs += 1
            else:
                session_context.agent_opened_tabs = 1
            if any(k in raw_input.lower() for k in ['tab close', 'tab band', 'close kardo', 'band karo']):
                steps.append(PlanStep(step=3, tool='wait_for_visual_event', args={'event_type': 'settled', 'timeout': 6.0}))
                steps.append(PlanStep(step=4, tool='press_hotkey', args={'keys': 'ctrl+w'}))
            plan = Plan(steps=steps)

    if plan is None:
        _lower_in = raw_input.lower()
        if ("mile" in _lower_in or "aaye" in _lower_in or "milay" in _lower_in) and any(c in _lower_in for c in ["cmd", "command prompt", "terminal", "powershell", "console", "ipconfig", "netstat", "ping", "whoami"]):
            _telem_plan = _classify_and_parse_command(raw_input, session_context)
            if _telem_plan and _telem_plan.steps and len(_telem_plan.steps) > 1 and not getattr(_telem_plan, "is_direct_message", False):
                plan = _telem_plan

        # Direct intercept for headless CLI command executions before compound workflow splits them
        if plan is None and any(c in _lower_in for c in ["cmd", "command prompt", "terminal", "powershell", "pwsh"]) and any(v in _lower_in for v in ["chalao", "run", "execute"]):
            _cli_plan = _classify_and_parse_command(raw_input, session_context)
            if _cli_plan and _cli_plan.steps and any(s.tool in ("execute_system_command", "execute_command") for s in _cli_plan.steps):
                plan = _cli_plan

        _compound_conjunctions = ["phir", "aur", "and", "then", "after that", "pehle"]
        _has_conj = any(re.search(rf"\b{re.escape(_c)}\b", _lower_in) for _c in _compound_conjunctions)
        _lifecycle_verbs = [
            "launch", "open", "close", "read", "save", "scan",
            "kholo", "band", "banao", "calculate", "type", "likho",
        ]
        _verb_count = sum(1 for _v in _lifecycle_verbs if re.search(rf"\b{re.escape(_v)}\b", _lower_in))
        from command_layer.decomposer import decompose_compound_command as _decomp_cmd
        _sub_cmds_early = _decomp_cmd(raw_input)
        _is_multi_step = len(_sub_cmds_early) >= 2

        if (_has_conj and _verb_count >= 2) or _is_multi_step:
            from brain.workflow_orchestrator import orchestrate_compound_workflow
            _early_plan = orchestrate_compound_workflow(raw_input, session_context)
            if _early_plan is not None and _early_plan.steps and len(_early_plan.steps) > 1 and not getattr(_early_plan, "is_direct_message", False):
                plan = _early_plan


    # --- Bullet #30: ReDoS & Prompt Flood Resilience (4 GB RAM Guard) ---
    # 1. Truncate excessively long inputs (max 1000 characters) with clean word boundary
    if len(raw_input) > 1000:
        raw_input = raw_input[:1000].rsplit(' ', 1)[0]

    # 2. Collapse repetitive character and punctuation floods (e.g. 'aaaaa...', '?????...', '!!!!!...')
    raw_input = re.sub(r'([a-zA-Z0-9\?\!\.\,\;\:\-\_\=\+\*\/\\\#\$\%\^\&\(\)])\1{6,}', r'\1\1\1', raw_input)

    # 3. Bullet #30: Adversarial Jailbreak & Persona Injection Guard
    from command_layer.firewall import check_adversarial_jailbreak
    is_jailbreak, jb_reason = check_adversarial_jailbreak(raw_input)
    if is_jailbreak:
        from command_layer.semantic_model import AdversarialAttackRecord, FirewallVerdict
        session_context.record_adversarial_attack(AdversarialAttackRecord(
            timestamp=time.time(),
            raw_input=raw_input,
            attack_type="JAILBREAK",
            verdict=FirewallVerdict.DENIED_ADVERSARIAL,
            details=jb_reason or "Adversarial jailbreak blocked."
        ))
        return "Blocked by safety layer: Adversarial jailbreak, roleplay bypass, or instruction override detected."

    # Normalize leading prompt symbols, politeness prefixes, and trailing punctuation
    clean_raw = re.sub(r'^[>\$#:\s]+', '', raw_input).strip()
    normalized_input = re.sub(r'^(?:please|kripya|agent|bhai|hey|hi|yaar|are|janab|bhaiya)\s+', '', clean_raw, flags=re.IGNORECASE).strip()
    clean_punct = re.sub(r'[\.\!\,\;]+$', '', normalized_input).strip()
    if clean_punct:
        normalized_input = clean_punct
    if not normalized_input:
        normalized_input = raw_input
    # --- Matrix Rows 8 & 9: Non-client window caption button targeting & manipulation limits (KNOWN_LIMITS.md) ---
    _clean_cap = normalized_input.lower()
    if any(k in _clean_cap for k in ["minimize button", "maximize button", "close button"]):
        if any(w in _clean_cap for w in ["antigravity", "mouse le jao", "le jao", "move", "target"]):
            return "Cannot target window caption or minimize button of IDE/system frame directly. Please use standard Windows shortcuts like Win+Down or Alt+Space then N to manage the window."
        if any(w in _clean_cap for w in ["click", "dabao", "press", "karo", "kar"]):
            return "Cannot click or manipulate window caption buttons directly. Please use standard Windows shortcuts like Win+Down or Alt+Space then N to minimize the window."

    # --- Phase 0.002: Prompt I User Lexicon / Learned Correction Alias Check ---
    from brain.experience_memory import EpisodicExperienceMemory
    _lex_mem = EpisodicExperienceMemory()
    _user_alias = _lex_mem.lookup_user_correction(normalized_input)
    if _user_alias and plan is None:
        alias_tool = _user_alias.get("tool")
        alias_args = _user_alias.get("args", {})
        if alias_tool:
            plan = Plan(
                steps=[PlanStep(step=1, tool=alias_tool, args=alias_args)],
                explanation=f"Applied learned user lexicon correction for '{normalized_input}'"
            )

    # --- Phase 0.005: Conversational, Greeting, Acknowledgment & Feedback Bypass ---
    has_any_pending = (session_context.pending_confirmation is not None) or confirmation_manager.has_pending() or (getattr(confirmation_manager, "_pending", None) is not None)
    if plan is None and not has_any_pending:
        from command_layer.semantic_parser import detect_conversational_intent
        is_conv, conv_cat, conv_lang = detect_conversational_intent(normalized_input)
        if is_conv and conv_cat in ("greeting", "capability", "feedback", "acknowledgment", "general_qa"):
            msg = get_conversational_response(normalized_input, conv_cat, conv_lang, session_context)
            trace_id = agent_state.start_trace(raw_input, normalized_input)
            agent_state.record_execution(
                trace_id=trace_id,
                user_cmd=raw_input,
                norm_cmd=normalized_input,
                domain=SemanticDomain.CONVERSATION,
                action=SemanticAction.ANSWER if conv_cat == "general_qa" else SemanticAction.CONVERSE,
                tools=["CONVERSATIONAL_RESPONSE"],
                args=[{"category": conv_cat, "text": normalized_input}],
                success=True,
                verified=True,
                status="completed"
            )
            return msg

    # --- Phase 0.014: Prompt I Mistake Memory Report & User Correction Interception ---
    clean_lower_cmd = normalized_input.lower().strip().rstrip(".?!")
    mistake_triggers = [
        "ghaltiyan dikhao", "ghaltiyan batao", "show mistakes", "mistakes report",
        "mistake report", "failure report", "show failure signatures", "ghaltian dikhao"
    ]
    if clean_lower_cmd in mistake_triggers:
        mem = EpisodicExperienceMemory()
        rep_path = mem.generate_mistakes_report()
        try:
            with open(rep_path, "r", encoding="utf-8") as rf:
                content = rf.read()
        except Exception:
            content = f"Mistake report written to {rep_path}"
        return f"Mistake Memory Report generated at {rep_path}:\n\n{content}"

    corr_triggers = ["ghalat", "galat", "wrong", "ye nahi chaha", "ye galat tha", "ye ghalat tha", "aisa nahi", "that was wrong"]
    is_correction = any(clean_lower_cmd.startswith(ct) for ct in corr_triggers) or "yaad rakho" in clean_lower_cmd or "remember this" in clean_lower_cmd or "matlab" in clean_lower_cmd
    if is_correction and ("->" in raw_input or "matlab" in clean_lower_cmd or any(clean_lower_cmd == ct for ct in corr_triggers) or clean_lower_cmd.startswith("ghalat") or clean_lower_cmd.startswith("galat") or clean_lower_cmd.startswith("wrong")):
        mem = EpisodicExperienceMemory()
        explicit_rem = ("yaad rakho" in clean_lower_cmd or "remember this" in clean_lower_cmd)
        prev_cmd = getattr(session_context, "last_user_command", "")
        prev_tool = getattr(session_context, "last_executed_tool", "unknown")
        prev_args = getattr(session_context, "last_executed_args", {})

        target_cmd = prev_cmd
        corrected_tool = "launch_app"
        corrected_args = {}

        if "->" in raw_input:
            parts = raw_input.split("->", 1)
            target_cmd = parts[0].strip().replace("yaad rakho", "").strip()
            rest = parts[1].strip().replace("yaad rakho", "").strip()
            tokens = rest.split()
            corrected_tool = tokens[0] if tokens else "launch_app"
            if len(tokens) > 1:
                corrected_args = {"name": tokens[1]}
        elif "matlab" in clean_lower_cmd:
            parts = clean_lower_cmd.split("matlab", 1)
            cmd_part = parts[0].strip()
            for ct in corr_triggers:
                cmd_part = cmd_part.replace(ct, "").strip(" ,.-")
            if cmd_part:
                target_cmd = cmd_part
            rest = parts[1].strip().replace("yaad rakho", "").strip()
            tokens = rest.split()
            corrected_tool = tokens[0] if tokens else "launch_app"
            if len(tokens) > 1:
                corrected_args = {"name": tokens[1]}
        elif prev_cmd:
            corr_entry = mem.record_user_correction(
                command=prev_cmd,
                original_tool=prev_tool,
                original_args=prev_args,
                corrected_tool="remedy_needed",
                corrected_args={},
                explicit_remember=explicit_rem,
            )
            return f"Tasheeh darj kar li gayi hai: '{prev_cmd}' ko mistake mark kiya gaya hai (occurrence {corr_entry.get('occurrence_count')})."

        if target_cmd and corrected_tool:
            corr_entry = mem.record_user_correction(
                command=target_cmd,
                original_tool=prev_tool,
                original_args=prev_args,
                corrected_tool=corrected_tool,
                corrected_args=corrected_args,
                explicit_remember=explicit_rem,
            )
            status_desc = "applied to user_lexicon.json" if corr_entry.get("applied") else f"recorded (occurrence {corr_entry.get('occurrence_count')}/2)"
            return f"User correction {status_desc}: '{target_cmd}' -> {corrected_tool}({corrected_args})."

    # --- Phase 0.015: Task Lifecycle Control Interception (Bullet #26) ---
    clean_lower_cmd = normalized_input.lower().strip().rstrip(".?!")
    urdu_lifecycle_words = {"kya", "hua", "hue", "huye", "batao", "dikhao", "hai", "tha", "kitna", "kahan", "kaam", "karo", "chalo", "ruko", "chalao", "rok", "baqi", "kaun", "konsa", "konsay", "se"}
    cmd_tokens = set(re.findall(r'[a-zA-Z]+', clean_lower_cmd))
    is_urdu_lifecycle = bool(urdu_lifecycle_words & cmd_tokens)

    # 1. Progress / Status query
    status_triggers = [
        "status", "task status", "progress", "task progress", "kitna kaam hua",
        "kahan tak pohncha", "kahan tak hua", "progress batao", "status kya hai",
        "task kahan tak hua", "show progress", "check progress", "how much is done",
        "what is the progress", "current progress"
    ]
    if clean_lower_cmd in status_triggers or any(clean_lower_cmd.startswith(st) for st in ["task progress", "task status", "kitna kaam hua", "progress batao", "status batao"]):
        if not any(w in clean_lower_cmd for w in ["wifi", "network", "internet", "cpu", "ram", "storage", "drive", "disk", "service", "process"]):
            return session_context.get_task_progress_summary(lang="ur" if is_urdu_lifecycle else "en")

    # --- Phase 0.016: Cross-Domain Lineage Interception (Bullet #27) ---
    cross_domain_audit_triggers = [
        "kaun kaun se systems use huye", "kaun se systems use huye", "konsa system use hua",
        "konsay systems use hue", "kaun kaun se subsystems use hue", "subsystems breakdown",
        "which subsystems were coordinated", "subsystem breakdown", "cross domain history",
        "cross domain breakdown", "what subsystems were used", "what systems were coordinated",
        "systems used", "subsystems used", "dikhao kaun se systems use huye"
    ]
    if clean_lower_cmd in cross_domain_audit_triggers or any(clean_lower_cmd.startswith(cd) for cd in [
        "kaun kaun se systems", "kaun se subsystems", "which subsystems were", "subsystems breakdown", "cross domain breakdown"
    ]):
        return session_context.get_cross_domain_lineage_summary(lang="ur" if is_urdu_lifecycle else "en")

    # --- Phase 0.017: Long-Horizon Frontier Interception (Bullet #28) ---
    frontier_audit_triggers = [
        "frontier status", "exploration status", "kitne nodes explore huye",
        "nodes explored", "search frontier status", "exploration progress",
        "kitne nodes check huye", "exploration report", "long horizon report",
        "frontier summary", "show exploration nodes", "show search frontier",
        "exploration report dikhao", "frontier report dikhao", "exploration jaiza",
        "kitne nodes explore hue", "kitne nodes explore huye hain",
    ]
    if clean_lower_cmd in frontier_audit_triggers or any(clean_lower_cmd.startswith(fa) for fa in [
        "frontier status", "exploration status", "kitne nodes", "search frontier"
    ]):
        return session_context.get_frontier_summary(lang="ur" if is_urdu_lifecycle else "en")

    # --- Phase 0.018: Self-History & Retrospective Query Interception (Bullet #29) ---
    # 1. Past Telemetry Recall Queries
    telemetry_patterns = [
        r'\b(?:pichli|pehle|earlier|previous)\s+baar\s+(?:wi-?fi|network|internet)\b',
        r'\b(?:kya\s+pehle|did\s+we\s+check)\s+(?:wi-?fi|network|internet)\b',
        r'\bwhat\s+was\s+(?:the\s+)?(?:wi-?fi|network|internet)\s+status\b',
        r'\bwhat\s+was\s+wifi\s+earlier\b',
        r'\bwhat\s+was\s+(?:the\s+)?cpu\b',
        r'\bpichli\s+baar\s+cpu\b',
        r'\bwhat\s+was\s+(?:the\s+)?ram\b',
        r'\bpichli\s+baar\s+ram\b',
        r'\bwhat\s+was\s+(?:the\s+)?disk\s+space\b',
        r'\bpichli\s+baar\s+(?:c\s+drive|disk|storage)\b',
    ]
    if any(re.search(pat, clean_lower_cmd) for pat in telemetry_patterns):
        metric = "wifi"
        if "cpu" in clean_lower_cmd:
            metric = "cpu"
        elif any(w in clean_lower_cmd for w in ["ram", "memory"]):
            metric = "ram"
        elif any(w in clean_lower_cmd for w in ["disk", "space", "storage", "c drive"]):
            metric = "free_gb"
        return session_context.get_history_explanation(HistoryQueryType.PAST_TELEMETRY, param=metric, lang="ur" if is_urdu_lifecycle else "en")

    # 2. Comparative Telemetry Queries
    comparative_patterns = [
        r'\b(?:kam\s+hui\s+hai\s+ya\s+zyada|zyada\s+hui\s+hai\s+ya\s+kam|pehle\s+se\s+kam|pehle\s+se\s+zyada)\b',
        r'\b(?:more\s+or\s+less\s+than\s+earlier|has\s+(?:cpu|ram|space|storage)\s+(?:increased|decreased))\b',
        r'\b(?:compare\s+storage|disk\s+space\s+comparison|storage\s+comparison|compare\s+disk)\b',
        r'\bc\s+drive\s+mein\s+space\s+pehle\s+se\b',
    ]
    if any(re.search(pat, clean_lower_cmd) for pat in comparative_patterns):
        metric = "free_gb"
        if "cpu" in clean_lower_cmd:
            metric = "cpu"
        elif any(w in clean_lower_cmd for w in ["ram", "memory"]):
            metric = "ram"
        return session_context.get_history_explanation(HistoryQueryType.COMPARATIVE_METRIC, param=metric, lang="ur" if is_urdu_lifecycle else "en")

    # 3. Retrospective Actions Queries
    action_history_patterns = [
        r'\bpichle\s+(\d+)?\s*actions\b',
        r'\blast\s+(\d+)?\s*actions\b',
        r'\bpichle\s+actions\b',
        r'\bshow\s+recent\s+actions\b',
        r'\brecent\s+actions\b',
        r'\bwhat\s+were\s+the\s+last\s+(\d+)?\s*actions\b',
        r'\bpichla\s+action\s+kya\s+tha\b',
        r'\bwhat\s+was\s+the\s+last\s+action\b',
        r'\bkya\s+kiya\s+tha\s+pehle\b',
    ]
    for pat in action_history_patterns:
        m = re.search(pat, clean_lower_cmd)
        if m:
            num = m.group(1) if m.groups() and m.group(1) else "3"
            return session_context.get_history_explanation(HistoryQueryType.RECENT_ACTIONS, param=num, lang="ur" if is_urdu_lifecycle else "en")

    # 4. Failure Reason Queries
    failure_patterns = [
        r'\b(?:last|pichli|previous)\s+(?:command|step|task)\s+kyun\s+fail\s+hui\b',
        r'\bwhy\s+did\s+(?:the\s+)?(?:previous|last)\s+(?:command|step|task)\s+fail\b',
        r'\bwhy\s+did\s+it\s+fail\b',
        r'\bpichli\s+galti\s+kya\s+thi\b',
        r'\bwhat\s+failed\s+earlier\b',
        r'\blast\s+failure\s+reason\b',
    ]
    if any(re.search(pat, clean_lower_cmd) for pat in failure_patterns):
        return session_context.get_history_explanation(HistoryQueryType.FAILURE_REASON, lang="ur" if is_urdu_lifecycle else "en")

    # 5. Tool Usage Count Queries
    tool_count_patterns = [
        r'\bkitni\s+dafa\s+([a-zA-Z0-9_]+)\s+(?:run|use|istemal)\s+hua\b',
        r'\bhow\s+many\s+times\s+(?:did\s+we\s+run|was)\s+([a-zA-Z0-9_]+)\b',
    ]
    for pat in tool_count_patterns:
        m = re.search(pat, clean_lower_cmd)
        if m:
            t_name = m.group(1)
            return session_context.get_history_explanation(HistoryQueryType.TOOL_USAGE_COUNT, param=t_name, lang="ur" if is_urdu_lifecycle else "en")

    # 2. Pause command
    pause_triggers = [
        "pause", "pause task", "pause the task", "hold on", "pause execution",
        "hold execution", "ruko", "ruk jao", "pause karo", "rok do", "thoda ruko",
        "suno ruko", "hold karo", "task pause karo", "task roko"
    ]
    if clean_lower_cmd in pause_triggers and not any(w in clean_lower_cmd for w in ["unpause", "play", "music", "video"]):
        cp = session_context.get_task_checkpoint()
        if cp or agent_state.task_state in (TaskLifecycleState.IN_PROGRESS, TaskLifecycleState.RESUMING) or session_context.active_milestones:
            if agent_state.can_transition(TaskLifecycleState.PAUSED):
                agent_state.transition_task_state(TaskLifecycleState.PAUSED)
            if cp:
                cp.lifecycle_state = TaskLifecycleState.PAUSED
            pct = cp.progress_percent if cp else 0.0
            if is_urdu_lifecycle or any(w in clean_lower_cmd for w in ["ruko", "karo", "rok", "do"]):
                return f"Task rok di gayi hai (Paused). Mojooda taraqqi: {pct:.0f}%. Checkpoint mehfooz ho chuka hai. Dobara chalane ke liye 'resume' ya 'chalao' bolein."
            return f"Task paused successfully. Current progress: {pct:.0f}%. Checkpoint saved. To continue, say 'resume'."
        else:
            return "Rukne ke liye koi active task mojood nahi hai." if (is_urdu_lifecycle or "ruko" in clean_lower_cmd) else "No active task is running to pause."

    # 3. Cancel task command
    task_cancel_triggers = [
        "cancel task", "abort task", "stop task", "cancel current task",
        "task cancel karo", "task abort karo", "kaam band karo",
        "task rok do aur cancel karo", "task khatam karo"
    ]
    if clean_lower_cmd in task_cancel_triggers:
        if agent_state.can_transition(TaskLifecycleState.CANCELLED):
            agent_state.transition_task_state(TaskLifecycleState.CANCELLED)
        session_context.clear_task_checkpoint()
        session_context.clear_task_pause_request()
        return "Task mansookh (cancelled) kar diya gaya hai aur resources azad kar diye gaye hain." if (is_urdu_lifecycle or any(w in clean_lower_cmd for w in ["karo", "kaam"])) else "Task cancelled. State and resources released."

    # 4. Resume command
    resume_triggers = [
        "resume", "resume task", "continue", "continue task", "keep going",
        "proceed with task", "chalao", "aage chalo", "continue karo", "resume karo",
        "dobara chalao", "baqi kaam karo", "phir se shuru karo", "task chalao"
    ]
    if clean_lower_cmd in resume_triggers:
        cp = session_context.get_task_checkpoint()
        if not cp:
            return "Resume karne ke liye koi ruka hua task mojood nahi hai." if (is_urdu_lifecycle or any(w in clean_lower_cmd for w in ["chalao", "karo", "baqi"])) else "No paused task found to resume."

        if cp.progress_percent >= 100.0 or cp.lifecycle_state == TaskLifecycleState.COMPLETED:
            session_context.clear_task_checkpoint()
            if agent_state.task_state != TaskLifecycleState.COMPLETED and agent_state.can_transition(TaskLifecycleState.COMPLETED):
                agent_state.transition_task_state(TaskLifecycleState.COMPLETED)
            return "Task pehle hi mukammal ho chuki hai." if (is_urdu_lifecycle or any(w in clean_lower_cmd for w in ["chalao", "karo"])) else "Task is already complete. All milestones achieved."

        if agent_state.can_transition(TaskLifecycleState.RESUMING):
            agent_state.transition_task_state(TaskLifecycleState.RESUMING)
        restored_plan = restore_plan_from_checkpoint(cp)
        if not restored_plan.steps:
            if agent_state.can_transition(TaskLifecycleState.COMPLETED):
                agent_state.transition_task_state(TaskLifecycleState.COMPLETED)
            session_context.clear_task_checkpoint()
            return "Task mukammal ho chuki hai. Mazeed koi step baqi nahi." if (is_urdu_lifecycle or any(w in clean_lower_cmd for w in ["chalao", "karo"])) else "Task complete. No pending steps remain."

        if agent_state.can_transition(TaskLifecycleState.IN_PROGRESS):
            agent_state.transition_task_state(TaskLifecycleState.IN_PROGRESS)
        cp.lifecycle_state = TaskLifecycleState.IN_PROGRESS
        plan = restored_plan

    # --- Phase 0: Hard Security & Anti-Adversarial Jailbreak Guard (Bullet #8 & Bullet #30) ---
    destructive_regexes = [
        r'\bformat\s+[c-z](?::|\b)',
        r'\bformat(?:ting)?\s+(?:the\s+)?(?:disk|drive|partition|hard\s+disk)\b',
        r'\bwip(?:e|ing)\s+(?:the\s+)?(?:disk|drive|partition|hard\s+disk|c:)\b',
        r'\bwipe\s+(?:disk|drive|partition|hard\s+disk)\b',
        r'\bdelete\s+(?:the\s+)?(?:disk|partition|drive|system32)\b',
        r'\bsystem32\b',
        r'\b(?:kill|terminate)\s+all\b',
        r'\bregistry\s+wipe\b',
        r'\bdelete\s+partition\b',
        # Bullet #30: Deceptive negations and deceptive imperatives
        r'\b(?:never\s+stop|don\'t\s+refrain|do\s+not\s+refrain|do\s+not\s+hesitate|don\'t\s+hesitate|never\s+avoid|i\s+forbid\s+you\s+from\s+not|do\s+not\s+fail)\b.*\b(?:format|formatting|wipe|wiping|terminate\s+all|terminating\s+all|kill\s+all|killing\s+all|delete|deleting)\b',
        r'\b(?:balki\s+zara\s+bhi\s+mat\s+socho|zara\s+bhi\s+mat\s+socho)\b.*\b(?:format|wipe|delete|khatam)\b',
        r'\b(?:delete|wipe|format|destroy)\s+(?:all\s+)?(?:windows\s+directory|system\s+files|c\s+drive|drive\s+c)\b',
        r'\b(?:purge|wipe)\s+partition\b',
    ]
    try:
        from security.safety_firewall import is_safe_readonly_operation
        is_safe_readonly_cmd = is_safe_readonly_operation("", {}, normalized_input) or is_safe_readonly_operation("", {}, raw_input)
    except Exception:
        is_safe_readonly_cmd = False
    if any(re.search(pat, normalized_input.lower()) for pat in destructive_regexes) and not is_safe_readonly_cmd:
        msg = "Blocked by safety layer: Destructive system actions, disk formatting, and system directory modifications are restricted and strictly prohibited."

        trace_id = agent_state.start_trace(raw_input, normalized_input)
        agent_state.record_execution(
            trace_id=trace_id,
            user_cmd=raw_input,
            norm_cmd=normalized_input,
            domain=SemanticDomain.UNKNOWN,
            action=SemanticAction.CLARIFY,
            tools=["FIREWALL_BLOCK"],
            args=[{}],
            success=False,
            verified=True,
            status="firewall_blocked",
            failure_reason=msg
        )
        return msg
    destructive_plan = None

    # --- Phase 1: Security Confirmation Interception (Bullet #20) ---
    # Snapshot raw pending BEFORE has_pending() auto-clears expired ones
    raw_mgr_pending = getattr(confirmation_manager, "_pending", None)
    has_session_pending = session_context.pending_confirmation is not None
    has_mgr_pending = confirmation_manager.has_pending() or (raw_mgr_pending is not None)

    # Detect expired confirmation: raw existed but has_pending() cleared it
    if raw_mgr_pending is not None and not confirmation_manager.has_pending() and not has_session_pending:
        intent = confirmation_manager.check_intent(raw_input)
        clean_word = raw_input.strip().lower().rstrip(".?!")
        if intent == "NONE":
            if any(clean_word == w or clean_word.startswith(w) for w in ["haan", "ji haan", "kardo", "kar do", "theek hai", "bilkul", "proceed", "yes"]):
                intent = "CONFIRM"
        if intent == "CONFIRM":
            session_context.clear_pending_confirmation()
            confirmation_manager.clear()
            return "Confirmation request has expired. Please run the command again."

    if has_session_pending or has_mgr_pending:
        intent = confirmation_manager.check_intent(raw_input)
        clean_word = raw_input.strip().lower().rstrip(".?!")
        if intent == "NONE":
            if any(clean_word == w or clean_word.startswith(w) for w in ["haan", "ji haan", "kardo", "kar do", "theek hai", "bilkul", "proceed", "yes"]):
                intent = "CONFIRM"
            elif any(clean_word == w or clean_word.startswith(w) for w in ["nahi", "na", "mat karo", "rehne do", "ruk jao", "cancel", "no", "stop"]):
                intent = "REJECT"

        if intent == "CONFIRM":
            pending_req = session_context.pending_confirmation
            pending_mgr = confirmation_manager.get_pending()

            tool_name = pending_req.tool if pending_req else (pending_mgr.tool_name if pending_mgr else "")
            tool_args = pending_req.args if pending_req else (pending_mgr.args if pending_mgr else {})

            if not tool_name:
                session_context.clear_pending_confirmation()
                confirmation_manager.clear()
                return "Confirmation request has expired. Please run the command again."

            trace_id = agent_state.start_trace(raw_input, f"CONFIRM: {tool_name}")

            # Pre-Execution Argument Validation
            is_valid, sanitized_args, val_err = validate_and_sanitize_tool_arguments(tool_name, tool_args)
            active_args = sanitized_args if is_valid else tool_args

            result = run_tool_call(tool_name, active_args, confirmed=True)
            if pending_req:
                session_context.confirm_pending_action()
            confirmation_manager.clear()
            update_context_from_result(session_context, tool_name, active_args, result)

            # Determine domain & action for verified record
            conf_domain = SemanticDomain.FILESYSTEM if ("folder" in tool_name or "file" in tool_name) else (
                SemanticDomain.APPLICATION if ("process" in tool_name or "app" in tool_name) else SemanticDomain.UNKNOWN
            )
            conf_action = SemanticAction.DELETE if "delete" in tool_name else (
                SemanticAction.TERMINATE if ("kill" in tool_name or "terminate" in tool_name) else SemanticAction.OPEN
            )
            target_item = active_args.get("path") or active_args.get("name") or active_args.get("name_or_pid") or "item"

            sem_ver = verify_semantic_outcome(conf_domain, conf_action, target_item, result)

            agent_state.record_execution(
                trace_id=trace_id,
                user_cmd=raw_input,
                norm_cmd=normalized_input,
                domain=conf_domain,
                action=conf_action,
                tools=[tool_name],
                args=[active_args],
                success=bool(result.get("success")),
                verified=bool(sem_ver.get("verified", result.get("verified", False))),
                status="completed" if result.get("success") else "failed",
                failure_reason=None if result.get("success") else result.get("message", "Confirmation action failed"),
                results=[result],
                verification_result=sem_ver
            )

            if result.get("success"):
                if result.get("verified", False):
                    return result.get("message", "Operation completed and verified.")
                return f"Unverified: {result.get('message', 'Operation executed but could not be verified.')}"
            return f"Failed: {result.get('message', 'unknown error')}"

        elif intent == "REJECT":
            trace_id = agent_state.start_trace(raw_input, "REJECT_CONFIRMATION")
            agent_state.record_execution(
                trace_id=trace_id,
                user_cmd=raw_input,
                norm_cmd=normalized_input,
                domain=SemanticDomain.UNKNOWN,
                action=SemanticAction.CLARIFY,
                tools=["REJECT_CONFIRMATION"],
                args=[{}],
                success=True,
                verified=True,
                status="cancelled"
            )
            if session_context.pending_confirmation:
                session_context.clear_pending_confirmation(rejected=True)
            confirmation_manager.clear()
            return "Action cancelled. Target has not been modified."
        else:
            if session_context.pending_confirmation:
                session_context.clear_pending_confirmation(rejected=False)
            confirmation_manager.clear()

    # --- Phase 1.5: Level 2 Situational Reasoning & Autonomous Investigation Engine ---
    situational_triggers = [
        "figure out whether", "figure out if", "work out whether", "work out if",
        "find out what's wrong", "find out what is wrong", "find out what's unusual",
        "find out what is unusual", "start investigating", "don't waste time checking",
        "dont waste time checking", "acting strange today", "acting weird",
        "feels completely dead", "isn't behaving normally", "is not behaving normally",
        "seems messed up", "something on my screen is not where",
        "find the problem and fix it if you can do so safely",
        "figure out what window is active", "determine which application currently has foreground",
        "determine whether ram exhaustion", "work out if my current connectivity issue",
        "if system telemetry doesn't have enough history", "state that cause is unknown",
        "multiple possible reasons why", "evaluate whether cpu, ram, or storage",
        "conclusive evidence or if the cause cannot be established"
    ]
    norm_lower = normalized_input.lower()
    is_situational = any(t in norm_lower for t in situational_triggers) or (
        any(w in norm_lower for w in ["figure out", "work out", "investigate", "find out", "determine", "observe", "re-check", "dekhna", "check karna", "pata karo", "check karo", "dekh"])
        and any(w in norm_lower for w in ["problem", "wrong", "causing", "unusual", "bottleneck", "issue", "dead", "strange", "messed up", "acting", "stuck", "consuming", "anomalies", "not responding", "unresponsive", "disconnected", "spike", "cleared", "interrupted", "degraded", "relying", "running", "slow", "memory"])
    ) or any(p in norm_lower for p in [
        "browser stuck", "stuck ho gaya", "ajeeb behave", "ajeeb chal", "kya scene", "masla", "heavy chal", "delay ho raha",
        "pages thore slow", "pop-up", "low storage", "computer slow", "pc slow",
        "kitni ram", "kitna ram", "kitna cpu", "kitni cpu", "kitna memory", "kitni memory",
        "how much ram", "how much memory", "how much cpu", "eating all ram", "saari ram",
        "saari memory", "ram le raha", "cpu le raha", "memory le raha", "le raha hai", "le rahi hai"
    ])

    # --- Phase 0: Explicit Context Reset (Bullet #6) ---
    clean_lower = normalized_input.lower().strip().rstrip(".?!")
    if clean_lower in (
        "clear context", "reset context", "reset", "clear session", "reset memory",
        "clear memory", "naya kaam shuru karo", "naya kaam", "start fresh", "clean context",
        "context clear karo", "context reset karo", "memory reset karo"
    ):
        session_context.clear()
        agent_state.clear()
        trace_id = agent_state.start_trace(raw_input, normalized_input)
        agent_state.record_execution(
            trace_id=trace_id,
            user_cmd=raw_input,
            norm_cmd=normalized_input,
            domain=SemanticDomain.UNKNOWN,
            action=SemanticAction.CLARIFY,
            tools=["RESET_CONTEXT"],
            args=[{}],
            success=True,
            verified=True,
            status="completed"
        )
        return "Context and session state have been reset."


    return False, None, plan
