from __future__ import annotations
from command_layer.context_models import EntityType, TypedEntity
import gc
import json
import os
from pathlib import Path
import re
import time
from typing import Any, Optional, Dict, List, Set, Tuple

from command_layer.semantic_model import (
    PlanMutationType,
    PlanDAGNode,
    PlanMutation,
    FailureType,
    AdaptiveStrategy,
    PlanAdaptation,
    RecoveryStatus,
    CompensationAction,
    RollbackLedger,
    ObservationType,
    StepObservation,
    EnvironmentSnapshot,
    OutcomeVerdict,
    OutcomeCriteria,
    OutcomeReport,
    TaskLifecycleState,
    TaskMilestone,
    TaskCheckpoint,
    DomainBridgeType,
    DomainBridgeLink,
    CrossDomainWorkflow,
    HorizonDepth,
    ExplorationNode,
    SearchFrontier,
    LongHorizonReport,
    HistoryQueryType,
    ExecutionTraceRecord,
    TraceSummary,
    FirewallVerdict,
    AdversarialAttackRecord,
)

from command_layer.context_telemetry import SessionTelemetryMixin
from command_layer.context_history import SessionHistoryMixin
from command_layer.context_references import (
    DIRECTORY_REFERENCES,
    FILE_REFERENCES,
    APP_REFERENCES,
    APP_NOUN_REFERENCES,
    FILE_NOUN_REFERENCES,
    FOLDER_NOUN_REFERENCES,
    WINDOW_NOUN_REFERENCES,
    PROCESS_NOUN_REFERENCES,
    DRIVE_NOUN_REFERENCES,
    CONTRASTIVE_REFERENCES,
    MULTILINGUAL_PRONOUNS,
    ORDINAL_REFERENCES,
    resolve_references,
    _safe_val,
)
"""
Session Context and Reference Resolution for conversational continuity.
Tracks typed filesystem, application, browser profile, clipboard, and search entities,
and resolves pronouns/demonstratives ('usmein', 'this', 'that file', 'isko', 'latest wali', etc.)
without entity cross-contamination or hallucination.
"""
from dataclasses import dataclass, field
from enum import Enum
import gc
import json
from pathlib import Path
import re
import time
from typing import Any


@dataclass
class SessionContext(SessionTelemetryMixin, SessionHistoryMixin):
    # Scalar properties for backward compatibility
    last_active_directory: str | None = None
    last_created_directory: str | None = None
    last_opened_directory: str | None = None
    last_saved_directory: str | None = None
    last_created_file: str | None = None
    last_opened_file: str | None = None
    last_referenced_directory: str | None = None
    last_referenced_file: str | None = None
    last_launched_application: str | None = None
    last_referenced_process: int | None = None
    last_referenced_service: str | None = None
    last_tool_result: dict[str, Any] | None = None
    recent_entities: list[str] = field(default_factory=list)

    # Extended Phase 4 typed entity model
    last_application: TypedEntity | None = None
    last_folder: TypedEntity | None = None
    last_file: TypedEntity | None = None
    last_drive: TypedEntity | None = None
    last_device: TypedEntity | None = None
    last_bluetooth_device: TypedEntity | None = None
    last_process: TypedEntity | None = None
    last_service: TypedEntity | None = None
    last_browser: TypedEntity | None = None
    last_window: TypedEntity | None = None
    last_browser_profile: TypedEntity | None = None
    last_search_result: TypedEntity | None = None
    last_search_query: TypedEntity | None = None
    last_search_results: list[str] = field(default_factory=list)
    last_search_results_type: EntityType | None = None
    last_selected_file: TypedEntity | None = None
    last_selected_folder: TypedEntity | None = None
    last_created_item: TypedEntity | None = None
    last_copied_item: TypedEntity | None = None
    last_moved_item: TypedEntity | None = None
    last_renamed_item: TypedEntity | None = None
    last_clipboard_text: str | None = None
    last_visual_element: TypedEntity | None = None
    last_target_app: str | None = None
    recent_typed_entities: list[TypedEntity] = field(default_factory=list)

    # CLI/UI Text Buffer Extraction & Dynamic Piping
    last_output: str | None = None
    last_cli_output: str | None = None
    last_read_content: str | None = None
    captured_values: dict[str, str] = field(default_factory=dict)
    runtime_memory: dict[str, Any] = field(default_factory=dict)
    immune_hwnds: set[int] = field(default_factory=set)
    immune_pids: set[int] = field(default_factory=set)
    agent_spawned_pids: set[int] = field(default_factory=set)
    agent_opened_tabs: int = 0
    observation_allowed_until: float = 0.0

    # Bullet #6 Context Resolution & Lifecycle Tracking
    unverified_entities: list[TypedEntity] = field(default_factory=list)
    unverified_actions: list[dict[str, Any]] = field(default_factory=list)
    last_verified_entity: TypedEntity | None = None
    last_domain: str | None = None
    domain_timestamps: dict[str, float] = field(default_factory=dict)
    parent_container: str | None = None
    current_task_lineage: list[str] = field(default_factory=list)
    last_cancellation_reason: str | None = None

    # Bullet #9 Ambiguity & Disambiguation State
    pending_clarification: Any | None = None
    disambiguation_candidates: list[str] = field(default_factory=list)
    last_clarification_suggestion: str | None = None

    # Bullet #12 Relevant Evidence Selection State
    last_evidence_packet: Any | None = None

    # Bullet #14 Multi-Step Tool Chaining & Lineage State
    step_output_cache: dict[int, dict[str, Any]] = field(default_factory=dict)
    step_lineage_trace: list[dict[str, Any]] = field(default_factory=list)

    # Bullet #16 Evidence-Based Reasoning State
    last_inference: Any | None = None
    reasoning_history: list[dict[str, Any]] = field(default_factory=list)

    # Bullet #17 Hypothesis Generation & Elimination State
    last_hypothesis_ledger: Any | None = None
    hypothesis_history: list[dict[str, Any]] = field(default_factory=list)

    # Bullet #18 Root-Cause Analysis State
    last_root_cause_report: Any | None = None
    root_cause_history: list[dict[str, Any]] = field(default_factory=list)

    # Bullet #19 Conditional Decision Making State
    last_condition_outcome: dict[str, Any] | None = None
    condition_history: list[dict[str, Any]] = field(default_factory=list)

    # Bullet #20 Confidence & Uncertainty State
    pending_confirmation: Any | None = None
    confirmation_history: list[dict[str, Any]] = field(default_factory=list)
    last_confidence_score: Any | None = None
    confidence_history: list[dict[str, Any]] = field(default_factory=list)

    # Bullet #21 Dynamic Planning State
    dynamic_plan_history: list[dict[str, Any]] = field(default_factory=list)
    last_dynamic_plan: dict[str, Any] | None = None

    # Bullet #22 Adaptive Replanning State
    replanning_history: list[dict[str, Any]] = field(default_factory=list)
    failed_step_cache: dict[int, dict[str, Any]] = field(default_factory=dict)
    last_adaptation: dict[str, Any] | None = None

    # Bullet #23 Failure Recovery & Transactional Rollback State
    allocated_resources: list[dict[str, Any]] = field(default_factory=list)
    recovery_ledger: list[dict[str, Any]] = field(default_factory=list)
    last_recovery: dict[str, Any] | None = None
    pending_compensations: list[dict[str, Any]] = field(default_factory=list)

    # Bullet #24 Observation-Driven Execution State
    observation_history: list[Any] = field(default_factory=list)
    last_environment_snapshot: Any | None = None
    observed_filesystem_stats: dict[str, dict[str, Any]] = field(default_factory=dict)

    # Bullet #25 Outcome Verification State
    last_outcome_report: Any | None = None
    outcome_history: list[Any] = field(default_factory=list)

    # Bullet #26 Multi-Step Task Management State
    task_checkpoint: Any | None = None
    milestone_history: list[Any] = field(default_factory=list)
    active_milestones: list[Any] = field(default_factory=list)
    task_pause_requested: bool = False

    # Bullet #27 Cross-Domain Problem Solving State
    cross_domain_history: list[dict[str, Any]] = field(default_factory=list)
    active_cross_domain_workflow: Any | None = None

    # Bullet #28 Long-Horizon Problem Solving State
    frontier: Any | None = None
    long_horizon_history: list[dict[str, Any]] = field(default_factory=list)
    last_long_horizon_report: Any | None = None

    # Bullet #29 Self-History & Execution Trace Ledger (4 GB RAM Guard: max 25 turns)
    execution_trace_ledger: list[Any] = field(default_factory=list)
    trace_disk_log_path: str = "execution_traces.jsonl"

    # Bullet #30 Adversarial Attack & Injection Audit History (4 GB RAM Guard: max 25 entries)
    adversarial_attack_history: list[Any] = field(default_factory=list)

    # Phase 1: Window Ownership, Multi-Window Context & No-Auto-Cleanup Tracking
    existing_hwnds: set[int] = field(default_factory=set)
    existing_apps: set[str] = field(default_factory=set)
    goku_created_hwnds: set[int] = field(default_factory=set)
    goku_created_tabs: list[dict[str, Any]] = field(default_factory=list)
    app_window_history: list[dict[str, Any]] = field(default_factory=list)
    # Continuous Memory Persistence Across Runs (user-data/agent_memory.json)
    history: list[dict[str, Any]] = field(default_factory=list)
    saved_files: list[str] = field(default_factory=list)
    active_windows: list[dict[str, Any]] = field(default_factory=list)
    extracted_metrics: dict[str, Any] = field(default_factory=dict)
    last_calculation: str | None = None

    def __post_init__(self) -> None:
        self.load_memory_from_disk()
        try:
            self.capture_pre_existing_environment()
        except Exception:
            pass

    def capture_pre_existing_environment(self) -> None:
        """
        Scans running processes and top-level HWNDs to populate immune_pids and immune_hwnds.
        Protects user-opened browser sessions, IDE instances, explorer windows, and terminal sessions.
        """
        try:
            import psutil
            for proc in psutil.process_iter(['pid', 'name']):
                try:
                    pname = (proc.info.get('name') or '').lower()
                    pid = proc.info.get('pid')
                    if pid and pid > 4:
                        if any(target in pname for target in [
                            'chrome', 'msedge', 'edge', 'firefox', 'code', 'cursor',
                            'antigravity', 'explorer', 'devenv', 'terminal', 'powershell', 'cmd'
                        ]):
                            self.immune_pids.add(int(pid))
                except Exception:
                    pass
        except Exception:
            pass

        try:
            import win32gui
            import win32process
            def enum_win_cb(hwnd, _):
                try:
                    if win32gui.IsWindow(hwnd) and win32gui.IsWindowVisible(hwnd):
                        title = (win32gui.GetWindowText(hwnd) or '').strip()
                        if title:
                            self.immune_hwnds.add(int(hwnd))
                            _, w_pid = win32process.GetWindowThreadProcessId(hwnd)
                            if w_pid and w_pid > 4:
                                self.immune_pids.add(int(w_pid))
                except Exception:
                    pass
                return True

            win32gui.EnumWindows(enum_win_cb, None)
        except Exception:
            pass

    def is_target_immune(self, pid: int | None = None, hwnd: int | None = None) -> bool:
        """Checks whether a target process PID or window HWND is immune to closing/killing."""
        try:
            if pid is not None and int(pid) in self.immune_pids and int(pid) not in self.agent_spawned_pids:
                return True
        except (ValueError, TypeError):
            pass

        try:
            if hwnd is not None and int(hwnd) in self.immune_hwnds:
                return True
        except (ValueError, TypeError):
            pass

        if hwnd is not None:
            try:
                import win32process
                _, w_pid = win32process.GetWindowThreadProcessId(int(hwnd))
                if w_pid and int(w_pid) in self.immune_pids and int(w_pid) not in self.agent_spawned_pids:
                    return True
            except Exception:
                pass

        return False

    def get_memory_file_path(self) -> Path:
        """Resolves the persistent memory JSON path, prioritizing user-data directory."""
        for parent in Path(__file__).resolve().parents:
            if (parent / "user-data").is_dir():
                return parent / "user-data" / "agent_memory.json"
            if parent.name == "user-data":
                return parent / "agent_memory.json"
        cwd_ud = Path.cwd() / "user-data"
        if cwd_ud.is_dir():
            return cwd_ud / "agent_memory.json"
        mem_path = Path.cwd() / "user-data" / "agent_memory.json"
        try:
            mem_path.parent.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass
        return mem_path

    def load_memory_from_disk(self) -> None:
        """Loads persistent session state and history from disk."""
        try:
            mem_file = self.get_memory_file_path()
            if mem_file.exists():
                with open(mem_file, "r", encoding="utf-8") as f:
                    data = json.load(f)
                if isinstance(data, dict):
                    if not self.history:
                        self.history = data.get("history", [])[-100:]
                    if not self.saved_files:
                        self.saved_files = data.get("saved_files", [])[-50:]
                    if not self.active_windows:
                        self.active_windows = data.get("active_windows", [])[-25:]
                    if not self.extracted_metrics:
                        self.extracted_metrics = data.get("extracted_metrics", {})
                    if self.last_calculation is None:
                        self.last_calculation = data.get("last_calculation")
                    if self.last_output is None and data.get("last_output"):
                        self.last_output = data.get("last_output")
                    if self.saved_files and not self.last_referenced_file:
                        self.last_referenced_file = self.saved_files[-1]
        except Exception:
            pass

    def save_memory_to_disk(self) -> None:
        """Persists session memory across runs to user-data/agent_memory.json safely."""
        try:
            mem_file = self.get_memory_file_path()
            mem_file.parent.mkdir(parents=True, exist_ok=True)
            data = {
                "history": self.history[-100:],
                "saved_files": self.saved_files[-50:],
                "active_windows": self.active_windows[-25:],
                "extracted_metrics": self.extracted_metrics,
                "last_calculation": self.last_calculation,
                "last_output": self.last_output,
                "timestamp": time.time(),
            }
            temp_file = mem_file.with_suffix(".tmp")
            with open(temp_file, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2)
            temp_file.replace(mem_file)
        except Exception:
            pass

    def record_action(self, tool_name: str, args: dict[str, Any], result: Any) -> None:
        """Records executed tool call in continuous history, capping at 100 turns."""
        res_summary = result
        if isinstance(result, dict):
            res_summary = {k: v for k, v in result.items() if k not in ("image", "screenshot", "bitmap")}
        entry = {
            "tool": tool_name,
            "args": args,
            "result": res_summary if isinstance(res_summary, (dict, list, str, int, float, bool)) else str(res_summary),
            "timestamp": time.time(),
        }
        self.history.append(entry)
        if len(self.history) > 100:
            self.history = self.history[-100:]

    def record_step_execution(self, step_num: int, tool_name: str, args: dict[str, Any], result: dict[str, Any]) -> None:
        """Records granular step outcome, lineage trace, and updates output cache for multi-tool chaining (Bullet #14)."""
        self.step_output_cache[step_num] = result
        lineage_entry = {
            "step": step_num,
            "tool": tool_name,
            "args": args,
            "timestamp": time.time(),
            "success": result.get("success", False),
            "status": result.get("status", "unknown"),
        }
        self.step_lineage_trace.append(lineage_entry)
        self.current_task_lineage.append(f"{step_num}:{tool_name}")

    def snapshot_system_state(self) -> None:
        """Snapshots all existing Windows HWNDs and running apps at session start."""
        try:
            import ctypes
            user32 = ctypes.windll.user32
            
            def enum_proc(hwnd, _):
                if user32.IsWindowVisible(hwnd):
                    length = user32.GetWindowTextLengthW(hwnd)
                    if length > 0:
                        buff = ctypes.create_unicode_buffer(length + 1)
                        user32.GetWindowTextW(hwnd, buff, length + 1)
                        title = buff.value
                        if title and title not in ("Program Manager", "Settings", "Microsoft Text Input Application"):
                            self.existing_hwnds.add(int(hwnd))
                return True
                
            WNDENUMPROC = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_int, ctypes.c_int)
            user32.EnumWindows(WNDENUMPROC(enum_proc), 0)
        except Exception:
            pass

    def record_created_hwnd(self, hwnd: int, app_name: str) -> None:
        if hwnd:
            self.goku_created_hwnds.add(int(hwnd))
            self.app_window_history.append({"hwnd": int(hwnd), "app_name": app_name.lower(), "created_by_goku": True})

    def record_created_tab(self, browser: str, title: str = "", url: str = "") -> None:
        self.goku_created_tabs.append({
            "browser": browser.lower(),
            "title": title,
            "url": url,
            "created_by_goku": True,
        })

    def get_open_hwnds_for_app(self, app_name: str) -> list[int]:
        """Returns all open visible HWNDs matching the application name."""
        hwnds = []
        try:
            import ctypes
            user32 = ctypes.windll.user32
            canonical = app_name.lower().strip()
            
            def enum_proc(hwnd, _):
                if user32.IsWindowVisible(hwnd):
                    length = user32.GetWindowTextLengthW(hwnd)
                    if length > 0:
                        buff = ctypes.create_unicode_buffer(length + 1)
                        user32.GetWindowTextW(hwnd, buff, length + 1)
                        title = buff.value.lower()
                        if title and (canonical in title.lower() or canonical in ("chrome", "notepad", "code")):
                            hwnds.append(int(hwnd))
                return True

            WNDENUMPROC = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_int, ctypes.c_int)
            user32.EnumWindows(WNDENUMPROC(enum_proc), 0)
        except Exception:
            pass
        return hwnds

    def record_entity(self, entity: str) -> None:
        if entity and entity not in self.recent_entities:
            self.recent_entities.append(entity)
            if len(self.recent_entities) > 20:
                self.recent_entities.pop(0)

    def record_typed_entity(self, entity: TypedEntity) -> None:
        if entity:
            self.recent_typed_entities.append(entity)
            if len(self.recent_typed_entities) > 20:
                self.recent_typed_entities.pop(0)

    def add_entity(self, entity_type: Any, value: str, domain: str | None = None) -> TypedEntity:
        """Adds a typed entity to session context."""
        typed = TypedEntity(value=str(value), entity_type=entity_type if isinstance(entity_type, EntityType) else EntityType.UNKNOWN)
        typed.domain = domain
        self.recent_typed_entities.append(typed)
        self.record_entity(str(value))
        return typed

    @property
    def entities(self) -> list[TypedEntity]:
        return self.recent_typed_entities

    @entities.setter
    def entities(self, val: list[TypedEntity]) -> None:
        self.recent_typed_entities = list(val)

    def clear(self) -> None:
        self.last_active_directory = None
        self.last_created_directory = None
        self.last_opened_directory = None
        self.last_created_file = None
        self.last_opened_file = None
        self.last_referenced_directory = None
        self.last_referenced_file = None
        self.last_launched_application = None
        self.last_referenced_process = None
        self.last_tool_result = None
        self.recent_entities.clear()

        self.last_application = None
        self.last_folder = None
        self.last_file = None
        self.last_drive = None
        self.last_browser = None
        self.last_browser_profile = None
        self.last_search_result = None
        self.last_search_query = None
        self.last_search_results.clear()
        self.last_selected_file = None
        self.last_selected_folder = None
        self.last_created_item = None
        self.last_copied_item = None
        self.last_moved_item = None
        self.last_renamed_item = None
        self.last_clipboard_text = None
        self.last_process = None
        self.last_service = None
        self.last_device = None
        self.last_bluetooth_device = None
        self.last_visual_element = None
        self.last_target_app = None
        self.last_window = None
        self.last_referenced_service = None
        self.last_search_results_type = None
        self.recent_typed_entities.clear()
        self.goku_created_hwnds.clear()
        self.goku_created_tabs.clear()
        self.app_window_history.clear()

        # Bullet #6 & Bullet #8 Context Resolution & Cancellation tracking clear
        self.unverified_entities.clear()
        self.unverified_actions.clear()
        self.last_verified_entity = None
        self.last_domain = None
        self.domain_timestamps.clear()
        self.parent_container = None
        self.current_task_lineage.clear()
        self.last_cancellation_reason = None

        # Bullet #9 Ambiguity & Disambiguation clear
        self.pending_clarification = None
        self.disambiguation_candidates.clear()

        # Bullet #12 Relevant Evidence clear
        self.last_evidence_packet = None

        # Bullet #14 Multi-Step Lineage clear
        self.step_output_cache.clear()
        self.step_lineage_trace.clear()

        # Bullet #16 Evidence-Based Reasoning clear
        self.last_inference = None
        self.reasoning_history.clear()

        # Bullet #17 Hypothesis Generation & Elimination clear
        self.last_hypothesis_ledger = None
        self.hypothesis_history.clear()

        # Bullet #18 Root-Cause Analysis clear
        self.last_root_cause_report = None
        self.root_cause_history.clear()

        # Bullet #19 Conditional Decision Making clear
        self.last_condition_outcome = None
        self.condition_history.clear()

        # Bullet #20 Confidence & Confirmation clear
        self.pending_confirmation = None
        self.confirmation_history.clear()
        self.last_confidence_score = None
        self.confidence_history.clear()

        # Bullet #21 Dynamic Planning clear
        self.dynamic_plan_history.clear()
        self.last_dynamic_plan = None

        # Bullet #22 Adaptive Replanning clear
        self.replanning_history.clear()
        self.failed_step_cache.clear()
        self.last_adaptation = None

        # Bullet #23 Failure Recovery & Rollback clear
        self.allocated_resources.clear()
        self.recovery_ledger.clear()
        self.last_recovery = None
        self.pending_compensations.clear()

        # Bullet #24 Observation-Driven Execution clear
        self.observation_history.clear()
        self.last_environment_snapshot = None
        self.observed_filesystem_stats.clear()

        # Bullet #25 Outcome Verification clear
        self.last_outcome_report = None
        self.outcome_history.clear()

        # Bullet #26 Multi-Step Task Management clear
        self.task_checkpoint = None
        self.milestone_history.clear()
        self.active_milestones.clear()
        self.task_pause_requested = False

        # Bullet #27 Cross-Domain Problem Solving clear
        self.cross_domain_history.clear()
        self.active_cross_domain_workflow = None

        # Bullet #28 Long-Horizon clear
        self.frontier = None
        self.long_horizon_history.clear()
        self.last_long_horizon_report = None

        # Bullet #29 Self-History clear
        self.execution_trace_ledger.clear()

        # Bullet #30 Adversarial History clear
        self.adversarial_attack_history.clear()

    def reset(self) -> None:
        """Alias for clear() to reset session context."""
        self.clear()

    def record_inference(self, inference: Any) -> None:
        """Records an empirical diagnostic deduction in context (Bullet #16)."""
        self.last_inference = inference
        if hasattr(inference, "to_dict"):
            self.reasoning_history.append(inference.to_dict())
        elif isinstance(inference, dict):
            self.reasoning_history.append(inference)

    def clear_inference(self) -> None:
        """Clears the cached inference and reasoning history (Bullet #16)."""
        self.last_inference = None
        self.reasoning_history.clear()

    def record_hypothesis_ledger(self, ledger: Any) -> None:
        """Records a hypothesis ledger in session context (Bullet #17)."""
        self.last_hypothesis_ledger = ledger
        if hasattr(ledger, "to_dict"):
            self.hypothesis_history.append(ledger.to_dict())
        elif isinstance(ledger, dict):
            self.hypothesis_history.append(ledger)

    def clear_hypothesis_ledger(self) -> None:
        """Clears the cached hypothesis ledger and history (Bullet #17)."""
        self.last_hypothesis_ledger = None
        self.hypothesis_history.clear()

    def record_root_cause_report(self, report: Any) -> None:
        """Records a root cause analysis report in session context (Bullet #18)."""
        self.last_root_cause_report = report
        if hasattr(report, "to_dict"):
            self.root_cause_history.append(report.to_dict())
        elif isinstance(report, dict):
            self.root_cause_history.append(report)

    def clear_root_cause_report(self) -> None:
        """Clears the cached root cause analysis report and history (Bullet #18)."""
        self.last_root_cause_report = None
        self.root_cause_history.clear()

    def record_condition_outcome(
        self,
        predicate: Any,
        actual_value: Any,
        passed: bool,
        branch_taken: str,
        step: int | None = None,
        tool: str | None = None
    ) -> None:
        """Records the deterministic outcome of a runtime condition evaluation (Bullet #19)."""
        pred_dict = predicate.to_dict() if hasattr(predicate, "to_dict") else (predicate if isinstance(predicate, dict) else str(predicate))
        entry = {
            "predicate": pred_dict,
            "actual_value": actual_value,
            "passed": passed,
            "branch_taken": branch_taken,
            "step": step,
            "tool": tool,
            "timestamp": time.time(),
        }
        self.last_condition_outcome = entry
        self.condition_history.append(entry)

    def clear_condition_outcome(self) -> None:
        """Clears the cached condition outcome and history (Bullet #19)."""
        self.last_condition_outcome = None
        self.condition_history.clear()

    def set_pending_confirmation(self, req: Any) -> None:
        """Sets an active pending confirmation request (Bullet #20)."""
        self.pending_confirmation = req
        req_dict = req.to_dict() if hasattr(req, "to_dict") else (req if isinstance(req, dict) else {"req": str(req)})
        self.confirmation_history.append(req_dict)

    def clear_pending_confirmation(self, rejected: bool = False) -> None:
        """Clears the active pending confirmation request (Bullet #20)."""
        if rejected and self.pending_confirmation:
            if hasattr(self.pending_confirmation, "status"):
                self.pending_confirmation.status = "REJECTED"
        self.pending_confirmation = None

    def confirm_pending_action(self) -> Any | None:
        """Confirms and returns the active pending confirmation request, then clears it (Bullet #20)."""
        req = self.pending_confirmation
        if req:
            if hasattr(req, "is_confirmed"):
                req.is_confirmed = True
            if hasattr(req, "status"):
                req.status = "CONFIRMED"
        self.pending_confirmation = None
        return req

    def set_verified_entity(self, value: str, entity_type: EntityType = EntityType.FILE) -> TypedEntity:
        """Helper to directly set or record a verified entity in context."""
        ent = TypedEntity(value=value, entity_type=entity_type, verified=True)
        self.last_verified_entity = ent
        self.recent_typed_entities.append(ent)
        return ent

    def record_confidence_score(self, score: Any) -> None:
        """Records a calibrated ConfidenceScore in context (Bullet #20)."""
        self.last_confidence_score = score
        entry = score.to_dict() if hasattr(score, "to_dict") else (score if isinstance(score, dict) else {"score": str(score)})
        self.confidence_history.append(entry)

    def clear_confidence_state(self) -> None:
        """Clears confidence scores and history (Bullet #20)."""
        self.last_confidence_score = None
        self.confidence_history.clear()
        self.pending_confirmation = None
        self.confirmation_history.clear()
    def clear_dynamic_plan_state(self) -> None:
        """Clears dynamic plan history and last mutation (Bullet #21)."""
        self.dynamic_plan_history.clear()
        self.last_dynamic_plan = None
    def set_evidence_packet(self, packet: Any) -> None:

        """Sets the most recent distilled EvidencePacket in context."""
        self.last_evidence_packet = packet

    def clear_evidence_packet(self) -> None:
        """Clears the cached EvidencePacket."""
        self.last_evidence_packet = None

    def set_pending_clarification(self, request: Any) -> None:
        """Stores a pending clarification request and caches its candidates."""
        self.pending_clarification = request
        self.disambiguation_candidates = list(getattr(request, "candidates", []))

    def clear_pending_clarification(self) -> None:
        """Clears any active clarification request and its candidate list."""
        self.pending_clarification = None
        self.disambiguation_candidates.clear()

    def resolve_clarification_answer(self, text: str) -> tuple[str, Any] | None:
        """
        If there is a pending clarification request, attempts to match the user's reply
        (e.g., '1', 'first one', '2026 wali', candidate name or substring) against the candidates.
        Returns (selected_candidate, pending_clarification) or None.
        """
        if not self.pending_clarification or not self.disambiguation_candidates:
            return None

        cleaned = text.strip()
        low = cleaned.lower()
        candidates = self.disambiguation_candidates

        # 1. Direct digit matching: "1", "2", "#1", "option 1", "number 1"
        num_m = re.search(r'^(?:#|option\s+|choice\s+|number\s+)?(\d+)$', low)
        if num_m:
            idx = int(num_m.group(1)) - 1
            if 0 <= idx < len(candidates):
                return candidates[idx], self.pending_clarification

        # 2. English & Roman Urdu ordinals
        ord_map = {
            "first": 0, "pehla": 0, "pehli": 0, "pehla wala": 0, "pehli wali": 0, "1st": 0,
            "second": 1, "doosra": 1, "doosri": 1, "dusra": 1, "dusri": 1, "doosra wala": 1, "doosri wali": 1, "dusra wala": 1, "2nd": 1,
            "third": 2, "teesra": 2, "teesri": 2, "teesra wala": 2, "teesri wali": 2, "3rd": 2,
            "fourth": 3, "chautha": 3, "chauthi": 3, "4th": 3,
            "fifth": 4, "panchwa": 4, "5th": 4,
            "last": -1, "aakhri": -1, "last one": -1, "aakhri wala": -1, "aakhri wali": -1,
        }
        for ord_word, idx in ord_map.items():
            if re.search(rf'\b{re.escape(ord_word)}\b', low):
                target_idx = idx if idx >= 0 else len(candidates) + idx
                if 0 <= target_idx < len(candidates):
                    return candidates[target_idx], self.pending_clarification

        # 3. Exact candidate matching
        for cand in candidates:
            cand_low = str(cand).lower()
            cand_name = Path(cand).name.lower() if ("/" in str(cand) or "\\" in str(cand)) else cand_low
            cand_stem = Path(cand).stem.lower() if ("/" in str(cand) or "\\" in str(cand)) else cand_low
            if low == cand_low or low == cand_name or low == cand_stem:
                return cand, self.pending_clarification

        # 4. Specific tokens (e.g. "2026 wali", "draft wala", "report 2026")
        sub_tokens = re.findall(r'[a-zA-Z0-9_\-]+', low)
        sub_tokens = [t for t in sub_tokens if t not in ("wali", "wala", "wale", "one", "the", "file", "folder", "app", "open", "kholo", "delete", "karo", "please")]
        if sub_tokens:
            for cand in candidates:
                cand_low = str(cand).lower()
                if all(tok in cand_low for tok in sub_tokens):
                    return cand, self.pending_clarification

        # 5. Loose substring matching
        for cand in candidates:
            cand_low = str(cand).lower()
            cand_name = Path(cand).name.lower() if ("/" in str(cand) or "\\" in str(cand)) else cand_low
            if cand_name in low or any(tok in cand_low for tok in sub_tokens if len(tok) >= 3):
                return cand, self.pending_clarification

        return None

    def cancel_active_task(self, reason: str = "User cancelled operation") -> None:
        """
        Safely halts in-progress or pending operations without context crash (Bullet #8).
        Clears volatile/unverified state and ensures aborted targets do not become verified.
        """
        self.last_cancellation_reason = reason
        self.unverified_entities.clear()
        self.last_created_item = None
        self.last_copied_item = None
        self.last_moved_item = None
        self.last_renamed_item = None
        self.current_task_lineage.clear()
        self.pending_clarification = None
        self.disambiguation_candidates.clear()
        self.unverified_actions.append({
            "action": "cancel",
            "reason": reason,
            "timestamp": time.time(),
            "status": "aborted"
        })

    def get_active_entity_for_domain(self, domain: str) -> TypedEntity | None:
        """Returns the most recent active entity for a specified domain."""
        dom = domain.lower()
        if dom in ("application", "app"):
            return self.last_application
        elif dom in ("filesystem", "file"):
            return self.last_file or self.last_folder
        elif dom in ("folder", "directory"):
            return self.last_folder
        elif dom in ("browser", "web"):
            return self.last_browser or self.last_browser_profile
        elif dom in ("devices", "device", "bluetooth"):
            return self.last_device or self.last_bluetooth_device
        elif dom in ("process", "processes"):
            return self.last_process
        elif dom in ("service", "services"):
            return self.last_service
        elif dom in ("drive", "storage"):
            return self.last_drive
        return None

    def get_typed_target(self, entity_type: EntityType, require_verified: bool = False) -> TypedEntity | None:
        """Retrieves an active entity matching the requested type, with verification check."""
        cand: TypedEntity | None = None
        if entity_type == EntityType.APPLICATION:
            cand = self.last_application
        elif entity_type == EntityType.FILE:
            cand = self.last_file or self.last_selected_file
        elif entity_type == EntityType.FOLDER:
            cand = self.last_folder or self.last_selected_folder
        elif entity_type == EntityType.DRIVE:
            cand = self.last_drive
        elif entity_type == EntityType.BROWSER:
            cand = self.last_browser
        elif entity_type == EntityType.BROWSER_PROFILE:
            cand = self.last_browser_profile
        elif entity_type == EntityType.DEVICE:
            cand = self.last_device
        elif entity_type == EntityType.BLUETOOTH_DEVICE:
            cand = self.last_bluetooth_device
        elif entity_type == EntityType.PROCESS:
            cand = self.last_process
        elif entity_type == EntityType.SERVICE:
            cand = self.last_service
        elif entity_type == EntityType.UI_ELEMENT:
            cand = self.last_visual_element
        elif entity_type == EntityType.WINDOW:
            cand = self.last_window

        if cand and require_verified and not cand.verified:
            return None
        return cand

    def mark_entity_verified(self, value: str, entity_type: EntityType | None = None) -> None:
        """Marks an entity as physically verified ground-truth."""
        for ent in self.recent_typed_entities:
            ent_val = getattr(ent, "value", str(ent))
            if ent_val.lower() == value.lower() and (entity_type is None or ent.entity_type == entity_type):
                ent.verified = True
                self.last_verified_entity = ent
                break

    def is_stale(self, entity: TypedEntity | None, max_age_seconds: float = 300.0) -> bool:
        """Checks if an entity is older than the decay horizon."""
        if not entity:
            return True
        return (time.time() - getattr(entity, "timestamp", 0.0)) > max_age_seconds

    def decay_stale_domain(self, active_domain: str, max_age_seconds: float = 180.0) -> None:
        """Decays entities in unrelated domains when user switches tasks."""
        dom = active_domain.lower()
        now = time.time()
        self.last_domain = dom
        self.domain_timestamps[dom] = now

        # If switching away from browser to system/diagnostic/storage, deprioritize browser specifics
        if dom in ("diagnostics", "system", "storage") and ("browser" in self.domain_timestamps):
            if now - self.domain_timestamps.get("browser", 0) > max_age_seconds:
                self.last_browser_profile = None
                if self.last_search_results_type == EntityType.BROWSER_PROFILE:
                    self.last_search_results.clear()
                    self.last_search_results_type = None

        # If switching away from filesystem to network, ensure search results of files do not pollute
        if dom in ("network", "devices") and ("filesystem" in self.domain_timestamps):
            if now - self.domain_timestamps.get("filesystem", 0) > max_age_seconds:
                if self.last_search_results_type == EntityType.FILE:
                    self.last_search_results_type = None



from command_layer.context_updater import (
    update_context_from_result,
    init_session_immunity,
    compact_working_memory,
    get_frontier_summary,
    clear_frontier_state,
    record_turn_trace,
    get_failed_tool_actions,
    get_historical_metric,
    compare_historical_metric,
    get_trace_summary,
    get_history_explanation,
    record_adversarial_attack,
)

session_context = SessionContext()
session_context.capture_pre_existing_environment()
try:
    init_session_immunity(session_context)
except Exception:
    pass
