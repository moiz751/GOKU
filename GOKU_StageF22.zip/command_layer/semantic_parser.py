from __future__ import annotations
import os
import re
import sys
from typing import Any, Optional, Dict, List, Set, Tuple

from command_layer.semantic_model_base import RiskLevel
from command_layer.semantic_model import (
    SemanticDomain,
    SemanticAction,
    RequestType,
    EntityType,
    CommandIntent,
    AmbiguityType,
    ClarificationRequest,
    SymptomCategory,
    SituationType,
    ConfidenceTier,
    RiskTier,
    ConfidenceScore,
    ConfirmationRequest,
    FailureType,
    AdaptiveStrategy,
    PlanAdaptation,
    TaskLifecycleState,
    TaskMilestone,
    TaskCheckpoint,
    DomainBridgeType,
    DomainBridgeLink,
    CrossDomainWorkflow,
    HorizonDepth,
    ExplorationNode,
    SearchFrontier,
    LongHorizonReport,
    HistoryQueryType,
    ExecutionTraceRecord,
    TraceSummary,
)
from brain.planner import Plan, PlanStep

from command_layer.state_machine import agent_state
from tools.utils.app_resolver import get_canonical_app_name
from command_layer.semantic_helpers import (
    resolve_in_turn_correction,
    strip_conversational_noise,
    split_compound_clauses,
    detect_symptom_category,
    normalize_adversarial_and_typo_input,
    detect_conversational_intent,
)
from command_layer.capability_extractor import (
    _extract_generalized_capability,
)
from command_layer.plan_synthesizer import (
    create_plan_from_intent,
)

def parse_semantic_intent(user_text: str) -> Optional[CommandIntent]:
    """
    Parses user input structurally into a CommandIntent without relying on ad-hoc keyword cascades.
    Extracts entities, resolves negations, and separates domains.
    """
    text = user_text.strip()
    text = re.sub(r'^(?:please|kripya|agent|bhai|hey|hi|yaar|are|janab|bhaiya)\s+', '', text, flags=re.IGNORECASE).strip()
    text = normalize_adversarial_and_typo_input(text)
    lower = text.lower()

    # 0. Anti-Adversarial Destructive Safety Guard
    if (
        any(p in lower for p in [
            "format c:", "format disk", "format drive", "wipe disk", "wipe hard disk",
            "delete partition", "kill all", "terminate all", "stop firewall", "disable adapter",
            "unpair all", "delete system32", "system32", "registry wipe"
        ])
        or bool(re.search(r'\b(disable|stop)\b.*\b(adapter|network|firewall)\b', lower))
        or bool(re.search(r'\b(format|wipe)\b.*\b(disk|drive|c:|d:)\b', lower))
        or bool(re.search(r'\b(kill|terminate)\b.*\ball\b', lower))
        or bool(re.search(r'\bdelete\b.*\bsystem32\b', lower))
    ):
        return CommandIntent(
            domain=SemanticDomain.SYSTEM,
            action=SemanticAction.UNSUPPORTED,
            target="security_prohibited",
            request_type=RequestType.CONFIRMATION,
            is_negated=True,
            risk_level=RiskLevel.DESTRUCTIVE,
            raw_clause=text,
            selected_tool="DIRECT_MESSAGE",
            tool_args={"message": "Operation restricted for safety and security: Destructive system actions are prohibited."}
        )

    # 0.1 Total Prohibition & Cancellation Interception
    if re.search(
        r'\b(?:kuch\s+mat\s+(?:karo|karna)|don\'t\s+do\s+anything|dont\s+do\s+anything|do\s+nothing|'
        r'bilkul\s+kuch\s+mat\s+(?:karo|karna)|chhor\s+do\s+sab|sab\s+chhor\s+do|'
        r'abhi\s+ruk\s+jao|ruk\s+jao\s+abhi|ruk\s+jao|cancel\s+that|cancel\s+the\s+operation|'
        r'cancel\s+it|operation\s+cancel\s+karo|rehne\s+do|rahne\s+do|chhor\s+do|chhoro|'
        r'abort|stop\s+it|cancel)\b',
        lower
    ) and not any(w in lower for w in ["open", "kholo", "launch", "run", "start", "find", "search", "list", "read", "button", "btn"]):
        return CommandIntent(
            domain=SemanticDomain.SYSTEM,
            action=SemanticAction.UNSUPPORTED,
            target="operation_cancelled",
            request_type=RequestType.ACTION,
            is_negated=True,
            risk_level=RiskLevel.READ_ONLY,
            raw_clause=text,
            selected_tool="DIRECT_MESSAGE",
            tool_args={"message": "Operation cancelled as requested. No actions were performed."}
        )

    # 0.2 In-Turn Self-Repair Resolution
    effective_text, correction_note, prohibited = resolve_in_turn_correction(text)
    is_correction = bool(correction_note)
    if is_correction:
        text = effective_text
        lower = text.lower()

    # 0.25 Conversational, Greeting, Feedback & General Q&A Intent Classification
    is_conv, cat, lang = detect_conversational_intent(text)
    if is_conv:
        act = SemanticAction.CONVERSE if cat in ("greeting", "capability", "feedback") else SemanticAction.ANSWER
        req_type = RequestType.CONVERSATIONAL if cat != "general_qa" else RequestType.GENERAL_QA
        if cat == "greeting":
            msg = "Salam! Main aapki Windows system, files aur apps mein kya madad kar sakta hoon?" if lang == "ur" else "Hello! How can I assist you with your computer today?"
        elif cat == "capability":
            msg = (
                "Main GOKU hoon, aapka Windows 11 offline autonomous assistant. Main applications chala sakta hoon, files aur folders dhoond aur manage kar sakta hoon, system health (CPU, RAM, disk) check kar sakta hoon, aur browser tasks automate kar sakta hoon."
                if lang == "ur" else
                "I am GOKU, your Windows 11 offline autonomous assistant. I can launch and close applications, search and manage files/folders, inspect system health (CPU, RAM, disk), control network settings, and automate browser tasks."
            )
        elif cat == "feedback":
            msg = "Maazrat chahta hoon, ghalat samajh gaya tha. Aap bataiye ab kya open ya run karna hai?" if lang == "ur" else "I apologize for the misunderstanding. What would you like me to open or do instead?"
        else:
            from command_layer.router import get_conversational_response
            msg = get_conversational_response(text, "general_qa", lang)

        return CommandIntent(
            domain=SemanticDomain.CONVERSATION,
            action=act,
            target=cat,
            request_type=req_type,
            is_negated=False,
            risk_level=RiskLevel.READ_ONLY,
            raw_clause=text,
            selected_tool="DIRECT_MESSAGE",
            tool_args={"message": msg, "category": cat, "text": text, "lang": lang}
        )

    # -------------------------------------------------------------
    # 1. ENTITY LITERAL & QUOTED DATA EXTRACTION
    # -------------------------------------------------------------
    quoted_strings = re.findall(r'["\']([^"\']+)["\']', text)

    # Protected text after colon: e.g. "type karo: delete my files" or "search karo: open my downloads"
    colon_payload = ""
    if ":" in text:
        colon_payload = text.split(":", 1)[1].strip()

    # Protected filenames with extensions: e.g. delete.txt, notes.docx, script.py
    filename_match = re.search(r'\b([a-zA-Z0-9_\-]+\.(?:txt|pdf|py|docx|doc|png|jpg|csv|xlsx|json|html|zip|exe|md))\b', text, flags=re.IGNORECASE)
    protected_filename = filename_match.group(1) if filename_match else ""

    # -------------------------------------------------------------
    # 2. SELF-OBSERVATION, HISTORY & DIAGNOSTIC QUERIES
    # -------------------------------------------------------------
    is_history_query = (
        any(p in lower for p in [
            "commands ya steps fail hue", "command fail huwi", "commands fail hui",
            "fail hue", "fail huwi", "fail hua", "kya fail hua", "failed commands",
            "show failures", "konse fail hue", "kaun se commands ya steps fail hue",
            "which commands failed", "what commands failed", "which steps failed",
            "which command failed", "what went wrong", "what failed", "show failed commands",
            "list failed commands", "kya galat hua"
        ])
    )
    if is_history_query:
        return CommandIntent(
            domain=SemanticDomain.CONVERSATION_HISTORY,
            action=SemanticAction.QUERY_HISTORY,
            target="failed_commands_detailed",
            request_type=RequestType.REPORT,
            entity_type=EntityType.PROCESS,
            requested_output="detailed_failure_audit",
            risk_level=RiskLevel.READ_ONLY,
            raw_clause=text
        )

    # Past Action Verification Query (e.g. "did you scan my computer?")
    is_past_scan_query = (
        ("scan" in lower and "computer" in lower) and
        any(p in lower for p in ["did you", "have you", "kya tumne", "kya aapne", "pehle scan kiya", "already scan"])
    )
    if is_past_scan_query:
        return CommandIntent(
            domain=SemanticDomain.CONVERSATION_HISTORY,
            action=SemanticAction.QUERY_HISTORY,
            target="did_scan_computer",
            request_type=RequestType.QUERY,
            entity_type=EntityType.PROCESS,
            risk_level=RiskLevel.READ_ONLY,
            raw_clause=text
        )

    # Whole-System Health Diagnostic Query (e.g. "what is wrong with my computer")
    if any(p in lower for p in [
        "what is wrong with my computer", "what's wrong with my computer",
        "what is wrong with the computer", "what is wrong with my pc",
        "computer me kya masla hai", "pc me kya masla hai", "system me kya kharabi hai"
    ]):
        return CommandIntent(
            domain=SemanticDomain.DIAGNOSTICS,
            action=SemanticAction.DIAGNOSE,
            target="system_health",
            request_type=RequestType.DIAGNOSTIC,
            entity_type=EntityType.PROCESS,
            risk_level=RiskLevel.READ_ONLY,
            raw_clause=text
        )

    # Explicit Application / Status Negations (Only if not part of complex search, WiFi, or conditional workflow)
    if not any(w in lower for w in ["wifi", "wi-fi", "search", "dhundo", "dhoondo", "google", "youtube", "pehle dekh", "already chal raha", "dobara mat", "tab ka pata", "agar", "lekin koi nayi tab"]):
        if any(w in lower for w in ["mat kholo", "mat khol", "mat open", "don't open", "dont open", "do not open", "never open", "kholo mat", "open mat"]):
            app_match = re.search(r'\b(chrome|notepad|calculator|calc|code|vscode|edge|firefox|word|excel|microsoft\s+store|windows\s+store|settings)\b', lower)
            app_name = app_match.group(1).title() if app_match else "Application"
            return CommandIntent(
                domain=SemanticDomain.APPLICATION,
                action=SemanticAction.LAUNCH,
                target=app_name,
                request_type=RequestType.ACTION,
                entity_type=EntityType.APPLICATION,
                is_negated=True,
                negations=[f"no_open:{app_name.lower()}"],
                risk_level=RiskLevel.READ_ONLY,
                raw_clause=text
            )

        if any(w in lower for w in ["status mat", "mat batao", "mat bata", "don't show status", "do not show status", "without status"]):
            return CommandIntent(
                domain=SemanticDomain.SYSTEM,
                action=SemanticAction.INSPECT,
                target="status_negated",
                request_type=RequestType.QUERY,
                entity_type=EntityType.PROCESS,
                is_negated=True,
                negations=["no_status"],
                risk_level=RiskLevel.READ_ONLY,
                raw_clause=text
            )

    if any(p in lower for p in ["tumne abhi kya kiya", "last command kya thi", "what did you just do", "last action batao"]):
        return CommandIntent(
            domain=SemanticDomain.CONVERSATION_HISTORY,
            action=SemanticAction.QUERY_HISTORY,
            target="last_command",
            request_type=RequestType.REPORT,
            entity_type=EntityType.PROCESS,
            requested_output="last_command_summary",
            risk_level=RiskLevel.READ_ONLY,
            raw_clause=text
        )

    # -------------------------------------------------------------
    # 3. AMBIGUITY HANDLING (Section 47, Section 57 RED-TEAM H)
    # -------------------------------------------------------------
    # Example: "folder ko right side move karo" -> Ambiguous between moving window GUI vs filesystem folder
    if "folder" in lower and "move" in lower and any(w in lower for w in ["right", "left", "up", "down", "side", "taraf"]):
        # Check if user specified a destination path (e.g. "move folder to Documents")
        has_dest = any(d in lower for d in ["to ", "mein ", "me ", "ke andar "]) and any(f in lower for f in ["desktop", "downloads", "documents", "drive", "c:", "d:"])
        if not has_dest:
            return CommandIntent(
                domain=SemanticDomain.GUI,
                action=SemanticAction.CLARIFY,
                target="folder_move_ambiguity",
                entities={"clarification": "Ambiguity detected: Did you mean moving the open folder window on your screen to the right side, or moving a folder to another location in the filesystem?"},
                risk_level=RiskLevel.READ_ONLY,
                raw_clause=text
            )

    # -------------------------------------------------------------
    # 4. LITERAL TYPING IN GUI TARGETS (Section 10, 27, Section 57 RED-TEAM B)
    # -------------------------------------------------------------
    # "search bar mein ye text type karo: delete my files"
    is_inquiry = any(lower.strip().startswith(p) for p in ["can you", "tell me", "give me", "list", "how many", "kya aap", "mujhe batao", "show me"])
    if not is_inquiry and ("type karo" in lower or "type kar" in lower or "likho" in lower or "type text" in lower) and ("search bar" in lower or "input" in lower or "editor" in lower):
        type_target = "search bar" if "search bar" in lower else "input"
        text_to_type = colon_payload
        if not text_to_type and quoted_strings:
            text_to_type = quoted_strings[0]
        if not text_to_type:
            # Match after 'karo' or 'likho'
            m = re.search(r'(?:type\s+karo:?|likho:?|type:?)\s*(.*)$', text, flags=re.IGNORECASE)
            if m:
                text_to_type = m.group(1).strip()
        if text_to_type:
            return CommandIntent(
                domain=SemanticDomain.GUI,
                action=SemanticAction.TYPE,
                target=type_target,
                entities={"target_query": type_target, "text": text_to_type},
                constraints=["literal_input", "no_filesystem_mutation"],
                risk_level=RiskLevel.STATE_CHANGING,
                raw_clause=text
            )

    # -------------------------------------------------------------
    # 5. FILENAME / ENTITY INJECTION PROTECTION (Section 42, Section 57 RED-TEAM C)
    # -------------------------------------------------------------
    # "Downloads mein delete.txt file find karo" -> Must find file, NOT delete!
    if protected_filename and any(w in lower for w in ["find", "search", "dhundo", "dhoondo", "locate", "kahan"]):
        folder_match = re.search(r'\b(downloads|desktop|documents|pictures|music|videos)\b', lower)
        start_folder = folder_match.group(1).capitalize() if folder_match else "Downloads"
        return CommandIntent(
            domain=SemanticDomain.FILESYSTEM,
            action=SemanticAction.FIND,
            target=protected_filename,
            entities={"filename": protected_filename, "folder": start_folder},
            constraints=["find_only", "no_destructive_delete"],
            risk_level=RiskLevel.READ_ONLY,
            raw_clause=text
        )

    # -------------------------------------------------------------
    # 6. NEGATION & DOMAIN ISOLATION (Section 43, Section 57 RED-TEAM D & E)
    # -------------------------------------------------------------
    # WiFi Status Inspection (Item 6): "WiFi status batao", "WiFi connected hai?", "Check WiFi status"
    if ("wifi" in lower or "wi-fi" in lower or "wireless" in lower) and any(w in lower for w in ["status", "batao", "connected", "check", "state", "kya hai", "laga hua", "juda hua", "active", "chal raha"]) and not any(w in lower for w in ["section", "connecting section", "settings kholo", "open settings", "ssid", "signal", "strength"]):
        return CommandIntent(
            domain=SemanticDomain.NETWORK,
            action=SemanticAction.INSPECT,
            target="wifi_status",
            request_type=RequestType.QUERY,
            entity_type=EntityType.NETWORK_CONNECTION,
            entities={"component": "wifi"},
            constraints=["read_only", "no_gui_navigation"],
            risk_level=RiskLevel.READ_ONLY,
            raw_clause=text
        )

    # Red-Team E: "WiFi status batao, settings mat kholo" -> Strictly read-only status, no settings GUI
    if ("wifi" in lower or "wi-fi" in lower) and ("status" in lower or "batao" in lower or "check" in lower) and ("settings mat" in lower or "mat khol" in lower or "don't open" in lower or "do not open" in lower):
        return CommandIntent(
            domain=SemanticDomain.NETWORK,
            action=SemanticAction.INSPECT,
            target="wifi_status",
            entities={"component": "wifi"},
            constraints=["read_only", "no_gui_navigation"],
            risk_level=RiskLevel.READ_ONLY,
            raw_clause=text
        )

    # Red-Team D: "WiFi settings kholo, status mat batao" -> Strictly GUI settings navigation
    if ("wifi" in lower or "wi-fi" in lower) and ("settings" in lower or "kholo" in lower or "open" in lower) and ("status mat" in lower or "mat bata" in lower or "without status" in lower):
        return CommandIntent(
            domain=SemanticDomain.SETTINGS,
            action=SemanticAction.NAVIGATE_SETTINGS,
            target="network-wifi",
            entities={"page": "network-wifi"},
            constraints=["gui_only", "no_status_retrieval"],
            risk_level=RiskLevel.STATE_CHANGING,
            raw_clause=text
        )

    # Section 56 TEST 5: "Windows Settings kholo aur WiFi connection section open karo, phir current network aur signal information verify karo"
    if ("wifi" in lower or "wi-fi" in lower) and ("settings" in lower or "setting" in lower or "section" in lower) and ("open" in lower or "kholo" in lower) and ("signal" in lower or "network" in lower or "verify" in lower or "information" in lower):
        return CommandIntent(
            domain=SemanticDomain.SETTINGS,
            action=SemanticAction.NAVIGATE_SETTINGS,
            target="network-wifi-with-verification",
            entities={"page": "network-wifi", "verify_signal": True},
            risk_level=RiskLevel.STATE_CHANGING,
            raw_clause=text
        )

    # Failure I / General Wi-Fi Settings navigation
    if ("wifi" in lower or "wi-fi" in lower) and any(w in lower for w in ["connecting section", "settings", "setting", "window tab", "section"]):
        return CommandIntent(
            domain=SemanticDomain.SETTINGS,
            action=SemanticAction.NAVIGATE_SETTINGS,
            target="network-wifi",
            entities={"page": "network-wifi", "section": "connections"},
            risk_level=RiskLevel.STATE_CHANGING,
            raw_clause=text
        )

    # General / Specific Settings Page navigation
    if (
        ("settings" in lower or "setting" in lower)
        and any(w in lower for w in ["page open", "khol do", "kholo", "open settings", "settings open", "show settings", "settings dikhao", "settings page", "open", "karo"])
        and not any(neg in lower for neg in ["mat", "don't", "dont", "bina", "zaroorat nahi", "zarurat nahi", "change mat"])
    ):
        target_page = "default"
        if "network" in lower or "internet" in lower or "wifi" in lower:
            target_page = "network" if "section" in lower or "network" in lower else "network-wifi"
        elif "sound" in lower or "audio" in lower:
            target_page = "sound"
        elif "display" in lower or "screen" in lower:
            target_page = "display"
        elif "bluetooth" in lower:
            target_page = "bluetooth"

        return CommandIntent(
            domain=SemanticDomain.SETTINGS,
            action=SemanticAction.NAVIGATE_SETTINGS,
            target="settings_main",
            entities={"page": target_page},
            risk_level=RiskLevel.STATE_CHANGING,
            raw_clause=text
        )

    # -------------------------------------------------------------
    # 7. MOUSE ACTIONS & RELATIVE CORRECTIONS (Section 27, 28, 29, Section 56 TEST 3 & 4)
    # -------------------------------------------------------------
    # Section 56 TEST 4: "nahi, thora right side per le jao aur sirf mouse move karo."
    # Failure H: "ni tu galat direction per la gya h, sahi direction per move ker"
    is_correction = any(w in lower for w in [
        "galat direction", "wrong direction", "sahi direction", "ni tu galat", "ulta chala gya",
        "wahan nahi", "thora right", "thora left", "thoda right", "thoda left", "right side per",
        "right side le jao", "left side le jao"
    ])
    if is_correction:
        target_dir = "right" if ("right" in lower) else ("left" if "left" in lower else "adjusted")
        return CommandIntent(
            domain=SemanticDomain.GUI,
            action=SemanticAction.MOVE_MOUSE,
            target="relative_mouse_move",
            entities={"direction": target_dir, "correction": True, "target_query": "search bar"},
            constraints=["mouse_only", "no_typing", "no_filesystem"],
            risk_level=RiskLevel.STATE_CHANGING,
            raw_clause=text
        )

    # Coordinate mouse moves: "mouse 500 500 par le jao", "mouse ko (400, 300) move karo"
    coord_m = re.search(r'\b(\d{1,4})\s*[,\s]\s*(\d{1,4})\b', text)
    if "mouse" in lower and coord_m and any(w in lower for w in ["move", "le jao", "le ja", "par", "pe", "to", "ko"]):
        x_val, y_val = int(coord_m.group(1)), int(coord_m.group(2))
        return CommandIntent(
            domain=SemanticDomain.GUI,
            action=SemanticAction.MOVE_MOUSE,
            target="coordinates",
            entities={"x": x_val, "y": y_val},
            constraints=["mouse_only", "coordinates"],
            risk_level=RiskLevel.STATE_CHANGING,
            raw_clause=text
        )

    # Section 56 TEST 3 & Section 57 RED-TEAM A:
    # "current window mein search bar locate karo aur mouse ko uske upar le jao, sirf mouse move karna hai"
    # "mouse ko search bar ke paas le jao"
    if (
        "mouse" in lower and any(w in lower for w in ["move", "le jao", "le ja", "uper la ja", "paas le jao", "locate"])
        and not any(w in lower for w in ["cursor", "pattern", "center", "wheel", "scroll", "position", "located", "where is"])
    ):
        target_elem = "search bar" if "search bar" in lower else ("button" if "button" in lower else "input")
        return CommandIntent(
            domain=SemanticDomain.GUI,
            action=SemanticAction.MOVE_MOUSE,
            target=target_elem,
            entities={"target_query": target_elem, "action": "move"},
            constraints=["mouse_only", "no_typing", "no_filesystem"],
            risk_level=RiskLevel.STATE_CHANGING,
            raw_clause=text
        )

    # -------------------------------------------------------------
    # 8. BROWSER COMPLEX FLOWS & QUERY EXTRACTION (Section 21, Section 56 TEST 1 & 6, RED-TEAM F)
    # -------------------------------------------------------------
    # Red-Team F: "Chrome mein search karo: open my downloads" -> Literal query search, never open folder
    if ("chrome" in lower or "browser" in lower) and ("search karo" in lower or "search kar" in lower) and ":" in text:
        clean_q = text.split(":", 1)[1].strip()
        if clean_q:
            return CommandIntent(
                domain=SemanticDomain.BROWSER,
                action=SemanticAction.SEARCH,
                target="web",
                request_type=RequestType.ACTION,
                entity_type=EntityType.BROWSER_PAGE,
                entities={"query": clean_q, "browser": "chrome"},
                constraints=["browser_search_only", "no_folder_access"],
                risk_level=RiskLevel.STATE_CHANGING,
                raw_clause=text
            )

    # Section 56 TEST 6 & Command 4: Conditional YouTube search
    if ("chrome" in lower) and ("youtube" in lower) and ("search" in lower or "tools" in lower or "ai" in lower):
        yt_query = "AI tools for developers"
        yt_m = re.search(r'youtube\s+par\s+(.*?)\s+search\s*(?:karo|kar|kar do|kardo|karna)?', text, flags=re.IGNORECASE)
        if yt_m:
            yt_query = yt_m.group(1).strip()
        return CommandIntent(
            domain=SemanticDomain.BROWSER,
            action=SemanticAction.SEARCH,
            target="conditional_youtube_search",
            entities={"query": yt_query, "browser": "chrome", "conditional_reuse": True, "open_first": True, "verify_title": True},
            constraints=["browser_only", "no_search_files"],
            risk_level=RiskLevel.STATE_CHANGING,
            raw_clause=text
        )

    # Section 56 TEST 1, Command 1, & Section 54 Fresh Variant:
    # "Chrome kholo aur Google par new AI modules for developers search karo, phir pehli relevant website kholo aur uska title verify karo."
    # "pehle dekh chrome already chal raha hai ya nahi... google par offline ai development tools search karna..."
    # "yaar chrome kholo aur google par developers ke liye naye AI modules search kar"
    if ("chrome" in lower or "browser" in lower) and ("google" in lower) and ("search" in lower or "dhundo" in lower):
        q_m = re.search(r'google\s+par\s+(.*?)\s+search\s*(?:karo|kar|kar do|kardo|karna)?', text, flags=re.IGNORECASE)
        if not q_m:
            q_m = re.search(r'search\s+(.*?)\s+(?:in|on)\s+google', text, flags=re.IGNORECASE)
        query = q_m.group(1).strip() if q_m else "new AI modules for developers"
        open_first = any(w in lower for w in ["pehli", "pehla", "first", "pehle", "pehlay", "pehle result", "open it", "useful result", "relevant website"])
        verify_title = any(w in lower for w in ["title", "verify", "domain"])
        return CommandIntent(
            domain=SemanticDomain.BROWSER,
            action=SemanticAction.SEARCH,
            target="web_search_and_verify" if (open_first or verify_title) else "web",
            entities={"query": query, "browser": "chrome", "open_first": open_first, "verify_title": verify_title},
            constraints=["browser_only", "no_search_files"],
            risk_level=RiskLevel.STATE_CHANGING,
            raw_clause=text
        )

    # Disambiguation: Windows search vs Browser search
    # e.g., "I need the Windows search thing, not the browser search."
    # "Windows search open karo, browser search nahi"
    if ("windows search" in lower or "start search" in lower or "system search" in lower) or (
        ("search" in lower or "dhundo" in lower) and any(w in lower for w in ["not the browser", "not browser", "no browser", "browser search nahi", "browser nahi", "browser par nahi"])
    ):
        return CommandIntent(
            domain=SemanticDomain.GUI,
            action=SemanticAction.SEARCH,
            target="windows_search",
            request_type=RequestType.ACTION,
            entity_type=EntityType.UI_ELEMENT,
            entities={"target": "windows_search", "shortcut": "win+s"},
            constraints=["no_browser_search", "windows_gui_only"],
            risk_level=RiskLevel.STATE_CHANGING,
            raw_clause=text
        )

    # Foreground browser inspection
    # e.g., "jo browser abhi samnay hai uska current page dekhna"
    if ("browser" in lower or "chrome" in lower or "edge" in lower) and ("samnay" in lower or "samne" in lower or "active tab" in lower or "current tab" in lower or "foreground" in lower or (("active" in lower or "current" in lower) and ("page" in lower or "title" in lower or "url" in lower or "website" in lower))) and not any(r in lower for r in ["open hai", "chal raha", "running", "band pada", "band hai", "active hai ya", "closed"]):
        return CommandIntent(
            domain=SemanticDomain.BROWSER,
            action=SemanticAction.INSPECT,
            target="current_page",
            request_type=RequestType.QUERY,
            entity_type=EntityType.BROWSER_PAGE,
            entities={"browser": "chrome"},
            constraints=["read_only"],
            risk_level=RiskLevel.READ_ONLY,
            raw_clause=text
        )

    # Multi-intent conditional tab inspection and duplicate avoidance
    # e.g., "Chrome kholo, meri current tab ka pata karo, aur agar woh page already open hai to dobara mat kholna."
    if ("chrome" in lower or "browser" in lower) and ("current tab" in lower or "tab ka pata" in lower) and ("already open" in lower or "dobara" in lower or "mat kholna" in lower):
        return CommandIntent(
            domain=SemanticDomain.BROWSER,
            action=SemanticAction.INSPECT,
            target="current_tab_avoid_duplicates",
            request_type=RequestType.MIXED_TASK,
            entity_type=EntityType.BROWSER_PAGE,
            entities={"browser": "chrome", "avoid_duplicate": True},
            constraints=["read_only_observation_first", "no_duplicate_launch"],
            risk_level=RiskLevel.STATE_CHANGING,
            raw_clause=text
        )

    # App launch with negation on sub-action (e.g. "Chrome kholo lekin koi nayi tab mat banana")
    if ("kholo" in lower or "open" in lower or "launch" in lower) and any(app in lower for app in ["chrome", "edge", "firefox", "notepad", "code", "calculator"]):
        if any(w in lower for w in ["mat banana", "mat kholna", "mat open karna", "don't create", "dont open", "no new tab", "tab mat", "koi nayi tab mat"]):
            app_match = re.search(r'\b(chrome|edge|firefox|notepad|code|calculator)\b', lower)
            app_name = get_canonical_app_name(app_match.group(1)) if app_match else "Chrome"
            return CommandIntent(
                domain=SemanticDomain.APPLICATION,
                action=SemanticAction.LAUNCH,
                target=app_name,
                request_type=RequestType.ACTION,
                entity_type=EntityType.APPLICATION,
                entities={"app_name": app_name},
                constraints=["no_new_tab", "focus_existing_if_open"],
                risk_level=RiskLevel.STATE_CHANGING,
                raw_clause=text
            )

    # Read-only folder inspection with mutation negation
    # e.g., "Downloads check karo, kuch move ya delete mat karna."
    if any(f in lower for f in ["downloads", "desktop", "documents"]) and any(w in lower for w in ["check", "dekh", "list", "inspect", "pata karo"]) and any(m in lower for m in ["mat karna", "don't delete", "dont delete", "kuch move ya delete mat", "kuch mat badalna", "read only"]):
        folder_target = "Downloads" if "downloads" in lower else ("Desktop" if "desktop" in lower else "Documents")
        return CommandIntent(
            domain=SemanticDomain.FILESYSTEM,
            action=SemanticAction.INSPECT,
            target=folder_target,
            request_type=RequestType.QUERY,
            entity_type=EntityType.FOLDER,
            entities={"folder": folder_target},
            constraints=["read_only", "no_delete", "no_move"],
            risk_level=RiskLevel.READ_ONLY,
            raw_clause=text
        )

    # General English Browser Search (Item 1, 2):
    # - "open Chrome and search new AI modules for developers"
    # - "search this on Google"
    # - "open Chrome, search X, find first result, verify title, open it"
    if ("chrome" in lower or "browser" in lower or "google" in lower) and ("search" in lower or "dhundo" in lower) and not ("file" in lower or "folder" in lower or "pdf" in lower) and not any(w in lower for w in ["not the browser", "not browser", "no browser", "browser search nahi", "browser nahi", "windows search"]):
        extracted_query = ""
        if quoted_strings:
            extracted_query = quoted_strings[0]
        elif ":" in text:
            extracted_query = text.split(":", 1)[1].strip()
        elif "search this on google" in lower or "search on google" in lower:
            extracted_query = (
                (agent_state.current_search.get("query") if agent_state.current_search else "")
                or agent_state.last_active_search_query
                or "new AI modules for developers"
            )
        else:
            m_s = re.search(r'(?:search|dhundo|dhoondo)\s+(?:for\s+)?(.*?)(?:,|$|\s+aur|\s+and|\s+phir|\s+then|\s+find|\s+open|\s+verify)', text, flags=re.IGNORECASE)
            if m_s and m_s.group(1).strip() and m_s.group(1).strip().lower() not in ("karo", "kar", "kardo", "karna"):
                extracted_query = m_s.group(1).strip()
            else:
                from tools.browser import sanitize_search_query
                extracted_query = sanitize_search_query(text)

        from tools.browser import sanitize_search_query
        extracted_query = sanitize_search_query(extracted_query)
        extracted_query = re.sub(r'^(?:for\s+|in\s+google\s+|on\s+google\s+|google\s+par\s+|this\s+on\s+google)', '', extracted_query, flags=re.IGNORECASE).strip()
        extracted_query = sanitize_search_query(extracted_query)
        if not extracted_query or extracted_query.lower() in ("this", "it"):
            extracted_query = "new AI modules for developers"

        open_first = any(w in lower for w in ["pehli", "pehla", "first", "pehle", "pehlay", "pehle result", "open it", "find first", "relevant website"])
        verify_title = any(w in lower for w in ["title", "verify", "domain"])
        return CommandIntent(
            domain=SemanticDomain.BROWSER,
            action=SemanticAction.SEARCH,
            target="web_search_and_verify" if (open_first or verify_title) else "web",
            request_type=RequestType.MIXED_TASK,
            entity_type=EntityType.BROWSER_PAGE,
            entities={"query": extracted_query, "browser": "chrome", "open_first": open_first, "verify_title": verify_title},
            constraints=["browser_only", "no_search_files"],
            risk_level=RiskLevel.STATE_CHANGING,
            raw_clause=text
        )

    # Section 54 Fresh Variant: "agar chrome already chal raha hai to wahi use karo warna open karo"
    if ("agar chrome" in lower or "if chrome" in lower) and ("already chal raha" in lower or "already running" in lower or "chal raha hai" in lower) and "youtube" not in lower:
        return CommandIntent(
            domain=SemanticDomain.BROWSER,
            action=SemanticAction.OPEN,
            target="conditional_chrome_lifecycle",
            entities={"browser": "chrome"},
            risk_level=RiskLevel.STATE_CHANGING,
            raw_clause=text
        )

    # -------------------------------------------------------------
    # 9. COMPOUND FILESYSTEM CONTEXT FLOW (Section 24, 26, Section 56 TEST 2)
    # -------------------------------------------------------------
    # "Downloads folder kholo, PDF files find karo, pehli wali ka size batao, phir usko open karo aur batao kis app mein open hui."
    if "downloads" in lower and ("pdf" in lower) and ("size" in lower) and ("open karo" in lower or "kholo" in lower) and ("kis app" in lower or "app mein" in lower):
        return CommandIntent(
            domain=SemanticDomain.FILESYSTEM,
            action=SemanticAction.INSPECT,
            target="downloads_pdf_workflow",
            entities={"folder": "Downloads", "extension": "pdf"},
            risk_level=RiskLevel.STATE_CHANGING,
            raw_clause=text
        )

    # Section 54 Fresh Variant: "downloads wali folder mein jo PDFs hain unmein se sab se pehli wali ka size batao"
    if "downloads" in lower and ("pdf" in lower) and ("size" in lower or "pehli" in lower) and not ("kis app" in lower or "open karo" in lower):
        return CommandIntent(
            domain=SemanticDomain.FILESYSTEM,
            action=SemanticAction.INSPECT,
            target="downloads_first_pdf_size",
            entities={"folder": "Downloads", "extension": "pdf"},
            risk_level=RiskLevel.READ_ONLY,
            raw_clause=text
        )

    # -------------------------------------------------------------
    # 10. CONTEXTUAL SEARCH TASK INHERITANCE (Failures C & D)
    # -------------------------------------------------------------
    if any(p in lower for p in ["search that i say", "search what i said", "search that i said", "search jo maine kaha", "woh search karo jo maine kaha", "and search that i say"]):
        query = ""
        if agent_state.current_search and agent_state.current_search.get("query"):
            query = agent_state.current_search["query"]
        elif agent_state.execution_history:
            for rec in reversed(agent_state.execution_history):
                if rec.user_command != text:
                    query = rec.user_command
                    break
        if query:
            return CommandIntent(
                domain=SemanticDomain.BROWSER,
                action=SemanticAction.SEARCH,
                target="web",
                entities={"query": query, "inherited_from_context": True},
                risk_level=RiskLevel.STATE_CHANGING,
                raw_clause=text
            )
        else:
            return CommandIntent(
                domain=SemanticDomain.BROWSER,
                action=SemanticAction.CLARIFY,
                target="search",
                entities={"clarification": "Please specify what you would like me to search for."},
                risk_level=RiskLevel.READ_ONLY,
                raw_clause=text
            )

    # Initial search ("AI tools search karo", "new module search ker")
    search_match = re.search(r'^(.*?)\s*(?:search\s+(?:ker|karo|kar\s+do|kardo)|dhundo|dhoondo)\s*$', lower)
    if search_match and not any(w in lower for w in ["file", "folder", "drive", "internet", "google", "web", "youtube", "setting", "store", "chatgpt", "usmein", "ismein", "us mein", "is mein", "in that", "in it", "usko", "isko"]):
        raw_query = search_match.group(1).strip()
        if raw_query:
            agent_state.current_search = {"query": raw_query, "domain": SemanticDomain.BROWSER}
            return CommandIntent(
                domain=SemanticDomain.BROWSER,
                action=SemanticAction.CLARIFY,
                target="search_destination",
                entities={"query": raw_query, "clarification": f"Where should I search for '{raw_query}'? (e.g. on the internet or in local files)"},
                risk_level=RiskLevel.READ_ONLY,
                raw_clause=text
            )

    # Multi-turn search result selection ("pehli relevant website kholo", "open first website", "pehli wali website open karo")
    if any(w in lower for w in ["pehli website", "pehli relevant website", "first website", "first result", "pehla result", "pehli wali"]) and any(w in lower for w in ["kholo", "open", "launch"]):
        return CommandIntent(
            domain=SemanticDomain.BROWSER,
            action=SemanticAction.NAVIGATE,
            target="first_search_result",
            entities={"target_query": "first result", "action": "click"},
            risk_level=RiskLevel.STATE_CHANGING,
            raw_clause=text
        )

    # Page title inspection ("iska title batao", "page title batao", "what is the title")
    if ("title" in lower) and any(w in lower for w in ["batao", "show", "what is", "kya hai", "tell", "verify"]) and not ("youtube" in lower or "google" in lower or "downloads" in lower or "search" in lower or "kholo" in lower or "open" in lower):
        return CommandIntent(
            domain=SemanticDomain.BROWSER,
            action=SemanticAction.INSPECT,
            target="page_title",
            requested_output="title",
            risk_level=RiskLevel.READ_ONLY,
            raw_clause=text
        )


    # Destination modifier following active search ("internet per")
    if lower in ("internet per", "internet par", "on internet", "web par", "online", "browser mein", "google par") and agent_state.current_search:
        prev_query = agent_state.current_search.get("query", "")
        return CommandIntent(
            domain=SemanticDomain.BROWSER,
            action=SemanticAction.SEARCH,
            target="web",
            entities={"query": prev_query, "platform": "google"},
            risk_level=RiskLevel.STATE_CHANGING,
            raw_clause=text
        )

    # Browser Profile Disambiguation ("select the lasts profile in it")
    if "profile" in lower and any(w in lower for w in ["select", "open", "use", "kholo", "chuno"]):
        norm_profile = "last" if ("lasts" in lower or "last" in lower or "lats" in lower) else ""
        if not norm_profile:
            m = re.search(r'profile\s+([a-zA-Z0-9_\-]+)', lower)
            if m:
                norm_profile = m.group(1)

        has_profiles = bool(agent_state.current_results and agent_state.current_result_type == "browser_profile")
        return CommandIntent(
            domain=SemanticDomain.BROWSER,
            action=SemanticAction.OPEN if has_profiles else SemanticAction.CLARIFY,
            target="browser_profile",
            entities={"profile": norm_profile, "has_context_profiles": has_profiles},
            risk_level=RiskLevel.READ_ONLY if not has_profiles else RiskLevel.STATE_CHANGING,
            raw_clause=text
        )

    # Store Search & Install Capability Boundary ("microsoft store open ker or us ma angrybird 2 download per laga day")
    if "microsoft store" in lower or "windows store" in lower or ("store" in lower and ("download" in lower or "install" in lower or "game" in lower)):
        app_target = "Angry Birds 2" if ("angrybird" in lower or "angry bird" in lower) else ""
        return CommandIntent(
            domain=SemanticDomain.APPLICATION,
            action=SemanticAction.SEARCH,
            target="Microsoft Store",
            entities={"app_to_find": app_target, "action": "download"},
            risk_level=RiskLevel.STATE_CHANGING,
            raw_clause=text
        )

    # Filesystem Duplicate Analysis Boundary
    if "duplicate" in lower and any(w in lower for w in ["file", "files", "report", "dhundo", "check"]):
        return CommandIntent(
            domain=SemanticDomain.FILESYSTEM,
            action=SemanticAction.REPORT,
            target="duplicate_files",
            entities={"folders": ["Downloads", "C:"]},
            risk_level=RiskLevel.READ_ONLY,
            raw_clause=text
        )

    # Complex Browser Multi-Step Task ('open chrom and search "chatgpt", then search in chatgpt search bar...')
    if ("chrom" in lower or "chrome" in lower) and ("chatgpt" in lower) and ("search" in lower):
        deep_query = ""
        if "like how to" in lower:
            deep_query = text.split("like", 1)[1].strip().strip("\"'")
        elif quoted_strings and len(quoted_strings) >= 2:
            deep_query = quoted_strings[1]
        else:
            deep_query = "how to download video game for free"

        return CommandIntent(
            domain=SemanticDomain.BROWSER,
            action=SemanticAction.SEARCH,
            target="chatgpt",
            entities={"primary_site": "chatgpt", "deep_query": deep_query},
            risk_level=RiskLevel.STATE_CHANGING,
            raw_clause=text
        )

    # -------------------------------------------------------------
    # 9. GENERALIZED CAPABILITY EXTRACTION (Existing Function Mastery)
    # -------------------------------------------------------------
    gen_intent = _extract_generalized_capability(text, lower, quoted_strings)
    if gen_intent:
        return gen_intent

    return None


