"""
Semantic Command Model & Structured Intermediate Representation for MARK/GOKU Agent.
Implements:
- SemanticDomain
- SemanticAction
- RequestType (Item 7)
- EntityType (Item 13)
- RiskLevel
- CommandIntent
- TaskNode / MultiTurnTaskGraph (Item 2)
"""
from dataclasses import dataclass, field
from enum import Enum, IntEnum
import time
from typing import Any, Optional


class SemanticDomain(str, Enum):
    BROWSER = "browser"
    FILESYSTEM = "filesystem"
    FILE = "filesystem"
    GUI = "gui"
    APPLICATION = "application"
    NETWORK = "network"
    SETTINGS = "settings"
    DIAGNOSTICS = "diagnostics"
    SYSTEM = "system"
    DEVICES = "devices"
    CONVERSATION_HISTORY = "conversation_history"
    CAPABILITY = "capability"
    CONVERSATION = "conversation"
    GENERAL_QA = "general_qa"
    UNKNOWN = "unknown"


class SemanticAction(str, Enum):
    OPEN = "open"
    CLOSE = "close"
    LAUNCH = "launch"
    SEARCH = "search"
    TYPE = "type"
    CLICK = "click"
    MOVE_MOUSE = "move_mouse"
    SCROLL = "scroll"
    INSPECT = "inspect"
    REPORT = "report"
    FIND = "find"
    DIAGNOSE = "diagnose"
    SCAN = "scan"
    NAVIGATE = "navigate"
    NAVIGATE_SETTINGS = "navigate_settings"
    QUERY_HISTORY = "query_history"
    DELETE = "delete"
    CREATE = "create"
    COPY = "copy"
    MOVE_FILE = "move_file"
    CORRECT = "correct"
    CLARIFY = "clarify"
    CONVERSE = "converse"
    ANSWER = "answer"
    UNSUPPORTED = "unsupported"
    REPAIR = "repair"
    INTERACT = "interact"
    OPTIMIZE = "optimize"
    PRESS = "press"



class RequestType(str, Enum):
    """Explicit request classification to distinguish information from actions (Item 7)."""
    QUERY = "query"
    ACTION = "action"
    DIAGNOSTIC = "diagnostic"
    NAVIGATION = "navigation"
    REPORT = "report"
    CONFIRMATION = "confirmation"
    MIXED_TASK = "mixed_task"
    CONVERSATIONAL = "conversational"
    GENERAL_QA = "general_qa"


class EntityType(str, Enum):
    """Explicit entity classification to avoid conflating apps, processes, files, and settings (Item 13)."""
    APPLICATION = "application"
    PROCESS = "process"
    FILE = "file"
    FOLDER = "folder"
    BROWSER_TAB = "browser_tab"
    BROWSER_PAGE = "browser_page"
    SETTINGS_PAGE = "settings_page"
    DEVICE = "device"
    NETWORK_CONNECTION = "network_connection"
    SERVICE = "service"
    UI_ELEMENT = "ui_element"
    UNKNOWN = "unknown"


class ContinuityType(str, Enum):
    NONE = "none"
    SAME = "same"
    AGAIN = "again"
    ALSO = "also"
    NOW = "now"
    RESET = "reset"


class RiskLevel(str, Enum):
    READ_ONLY = "read_only"
    REVERSIBLE = "reversible"
    STATE_CHANGING = "state_changing"
    DESTRUCTIVE = "destructive"


class AmbiguityType(str, Enum):
    """Categorization of ambiguous commands for deterministic resolution (Bullet #9)."""
    NONE = "none"
    ENTITY_AMBIGUITY = "entity_ambiguity"
    INTENT_AMBIGUITY = "intent_ambiguity"
    SCOPE_AMBIGUITY = "scope_ambiguity"
    UNDERSPECIFIED_TARGET = "underspecified_target"


class SymptomCategory(str, Enum):
    """Explicit symptom classification to map informal user complaints to physical domains (Bullet #11 & #12)."""
    NONE = "none"
    THERMAL_PERFORMANCE = "thermal_performance"
    MEMORY_PRESSURE = "memory_pressure"
    NETWORK_CONNECTIVITY = "network_connectivity"
    STORAGE_CRUNCH = "storage_crunch"
    APP_UNRESPONSIVE = "app_unresponsive"
    SYSTEM_SLUGGISHNESS = "system_sluggishness"
    COMPOSITE = "composite"

    # Bullet #12 Fine-Grained Subtypes
    CPU_SLUGGISHNESS = "cpu_sluggishness"
    FAN_NOISE_THERMAL = "fan_noise_thermal"
    RAM_EXHAUSTION = "ram_exhaustion"
    APP_CRASH_MEMORY = "app_crash_memory"
    NETWORK_OFFLINE = "network_offline"
    BROWSING_STALL = "browsing_stall"
    STORAGE_EXHAUSTION = "storage_exhaustion"
    PROCESS_HANG = "process_hang"
    WINDOW_UNRESPONSIVE = "window_unresponsive"


class SituationType(str, Enum):
    """Situational context of user system problem (Bullet #11)."""
    HEALTH_CHECK = "health_check"
    DEGRADED_PERFORMANCE = "degraded_performance"
    OUTAGE = "outage"
    RESOURCE_EXHAUSTION = "resource_exhaustion"
    PROCESS_HANG = "process_hang"
    UNKNOWN = "unknown"


@dataclass
class ClarificationRequest:
    """Structured clarification payload when a command is ambiguous or underspecified (Bullet #9)."""
    ambiguity_type: AmbiguityType
    question: str
    candidates: list[str] = field(default_factory=list)
    original_intent: Optional[str] = None
    original_tool: Optional[str] = None
    original_args: dict[str, Any] = field(default_factory=dict)
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "ambiguity_type": self.ambiguity_type.value if hasattr(self.ambiguity_type, "value") else str(self.ambiguity_type),
            "question": self.question,
            "candidates": self.candidates,
            "original_intent": self.original_intent,
            "original_tool": self.original_tool,
            "original_args": self.original_args,
            "metadata": self.metadata,
        }


@dataclass
class CommandIntent:
    """Structured Semantic Representation of User Intent."""
    domain: SemanticDomain
    action: SemanticAction
    target: str = ""
    request_type: RequestType = RequestType.ACTION
    entity_type: EntityType = EntityType.UNKNOWN
    entities: dict[str, Any] = field(default_factory=dict)
    constraints: list[str] = field(default_factory=list)
    conditions: list[dict[str, Any]] = field(default_factory=list)
    context_refs: dict[str, Any] = field(default_factory=dict)
    negations: list[str] = field(default_factory=list)
    quoted_payloads: list[str] = field(default_factory=list)
    is_negated: bool = False
    expected_outcome: str = ""
    requested_output: str = ""
    confidence: float = 1.0
    risk_level: RiskLevel = RiskLevel.READ_ONLY
    raw_clause: str = ""
    selected_tool: Optional[str] = None
    tool_args: dict[str, Any] = field(default_factory=dict)
    continuity_mode: ContinuityType = ContinuityType.NONE
    parent_container: Optional[str] = None
    child_target: Optional[str] = None
    is_correction: bool = False
    corrected_intent: Optional[str] = None
    prohibited_actions: list[str] = field(default_factory=list)
    ambiguity_type: AmbiguityType = AmbiguityType.NONE
    clarification_needed: bool = False
    clause_index: int = 0
    parent_clause: Optional[str] = None
    symptom_category: SymptomCategory = SymptomCategory.NONE
    situation_type: SituationType = SituationType.UNKNOWN
    early_exit_criteria: Optional[dict[str, Any]] = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "domain": self.domain.value if hasattr(self.domain, "value") else str(self.domain),
            "action": self.action.value if hasattr(self.action, "value") else str(self.action),
            "target": self.target,
            "request_type": self.request_type.value if hasattr(self.request_type, "value") else str(self.request_type),
            "entity_type": self.entity_type.value if hasattr(self.entity_type, "value") else str(self.entity_type),
            "entities": self.entities,
            "constraints": self.constraints,
            "conditions": self.conditions,
            "context_refs": self.context_refs,
            "negations": self.negations,
            "quoted_payloads": self.quoted_payloads,
            "expected_outcome": self.expected_outcome,
            "requested_output": self.requested_output,
            "confidence": self.confidence,
            "risk_level": self.risk_level.value if hasattr(self.risk_level, "value") else str(self.risk_level),
            "raw_clause": self.raw_clause,
            "continuity_mode": self.continuity_mode.value if hasattr(self.continuity_mode, "value") else str(self.continuity_mode),
            "parent_container": self.parent_container,
            "child_target": self.child_target,
            "is_correction": self.is_correction,
            "corrected_intent": self.corrected_intent,
            "prohibited_actions": self.prohibited_actions,
            "ambiguity_type": self.ambiguity_type.value if hasattr(self.ambiguity_type, "value") else str(self.ambiguity_type),
            "clarification_needed": self.clarification_needed,
            "clause_index": self.clause_index,
            "parent_clause": self.parent_clause,
            "symptom_category": self.symptom_category.value if hasattr(self.symptom_category, "value") else str(self.symptom_category),
            "situation_type": self.situation_type.value if hasattr(self.situation_type, "value") else str(self.situation_type),
        }


@dataclass
class TaskNode:
    """An executable node in the Multi-Turn Task Graph (Item 2)."""
    id: str
    action: SemanticAction
    domain: SemanticDomain
    target: str
    tool: str
    args: dict[str, Any] = field(default_factory=dict)
    dependencies: list[str] = field(default_factory=list)
    condition: Optional[dict[str, Any]] = None
    expected_state: dict[str, Any] = field(default_factory=dict)
    expected_outcome: str = ""
    risk_level: RiskLevel = RiskLevel.READ_ONLY
    request_type: RequestType = RequestType.ACTION
    entity_type: EntityType = EntityType.UNKNOWN
    is_negated: bool = False
    status: str = "pending"  # pending, running, completed, failed, skipped
    result: Optional[dict[str, Any]] = None
    verification: Optional[dict[str, Any]] = None
    continuity_mode: ContinuityType = ContinuityType.NONE
    parent_container: Optional[str] = None
    child_target: Optional[str] = None
    is_correction: bool = False
    ambiguity_type: AmbiguityType = AmbiguityType.NONE
    clause_index: int = 0
    parent_clause: Optional[str] = None
    symptom_category: SymptomCategory = SymptomCategory.NONE
    situation_type: SituationType = SituationType.UNKNOWN
    data_bindings: dict[str, str] = field(default_factory=dict)
    early_exit_condition: Optional[dict[str, Any]] = None
    conclusive_evidence: bool = False
    is_cross_domain: bool = False
    domain_lineage: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "action": self.action.value if hasattr(self.action, "value") else str(self.action),
            "domain": self.domain.value if hasattr(self.domain, "value") else str(self.domain),
            "target": self.target,
            "tool": self.tool,
            "args": self.args,
            "dependencies": self.dependencies,
            "condition": self.condition,
            "expected_state": self.expected_state,
            "expected_outcome": self.expected_outcome,
            "risk_level": self.risk_level.value if hasattr(self.risk_level, "value") else str(self.risk_level),
            "request_type": self.request_type.value if hasattr(self.request_type, "value") else str(self.request_type),
            "entity_type": self.entity_type.value if hasattr(self.entity_type, "value") else str(self.entity_type),
            "is_negated": self.is_negated,
            "status": self.status,
            "result": self.result,
            "verification": self.verification,
            "continuity_mode": self.continuity_mode.value if hasattr(self.continuity_mode, "value") else str(self.continuity_mode),
            "parent_container": self.parent_container,
            "child_target": self.child_target,
            "is_correction": self.is_correction,
            "ambiguity_type": self.ambiguity_type.value if hasattr(self.ambiguity_type, "value") else str(self.ambiguity_type),
            "clause_index": self.clause_index,
            "parent_clause": self.parent_clause,
            "symptom_category": self.symptom_category.value if hasattr(self.symptom_category, "value") else str(self.symptom_category),
            "situation_type": self.situation_type.value if hasattr(self.situation_type, "value") else str(self.situation_type),
            "data_bindings": self.data_bindings,
            "early_exit_condition": self.early_exit_condition,
            "conclusive_evidence": self.conclusive_evidence,
            "is_cross_domain": self.is_cross_domain,
            "domain_lineage": list(self.domain_lineage),
        }


class EvidenceRelevance(str, Enum):
    """Discriminative classification of diagnostic signals (Bullet #12)."""
    PRIMARY_SIGNAL = "primary_signal"
    SECONDARY_SIGNAL = "secondary_signal"
    CORROBORATING = "corroborating"
    BACKGROUND_NOISE = "background_noise"
    IRRELEVANT = "irrelevant"


class SignalWeight(float, Enum):
    """Calibrated confidence weight for diagnostic telemetry (Bullet #12)."""
    CRITICAL = 1.0
    HIGH = 0.8
    MEDIUM = 0.5
    LOW = 0.2
    NOISE = 0.0


@dataclass
class EvidencePacket:
    """Compact structured representation of distilled diagnostic evidence (Bullet #12 & #15)."""
    symptom: str
    symptom_category: SymptomCategory = SymptomCategory.NONE
    key_findings: list[str] = field(default_factory=list)
    primary_culprit: Optional[str] = None
    confidence: float = 1.0
    metrics: dict[str, Any] = field(default_factory=dict)
    pruned_noise_count: int = 0
    signal_ranking: list[dict[str, Any]] = field(default_factory=list)
    hypothesis_confirmed: Optional[bool] = None
    hypothesis_reasoning: str = ""
    entropy_reduction: float = 0.0
    is_conclusive: bool = False
    action_count: int = 1

    def to_dict(self) -> dict[str, Any]:
        return {
            "symptom": self.symptom,
            "symptom_category": self.symptom_category.value if hasattr(self.symptom_category, "value") else str(self.symptom_category),
            "key_findings": self.key_findings,
            "primary_culprit": self.primary_culprit,
            "confidence": self.confidence,
            "metrics": self.metrics,
            "pruned_noise_count": self.pruned_noise_count,
            "signal_ranking": self.signal_ranking,
            "hypothesis_confirmed": self.hypothesis_confirmed,
            "hypothesis_reasoning": self.hypothesis_reasoning,
            "entropy_reduction": self.entropy_reduction,
            "is_conclusive": self.is_conclusive,
            "action_count": self.action_count,
        }


# ==============================================================================
# BULLET #16: EVIDENCE-BASED REASONING DATA CONTRACTS
# ==============================================================================

class InferenceVerdict(str, Enum):
    """Empirical diagnostic reasoning verdict (Bullet #16)."""
    CONFIRMED = "confirmed"
    REFUTED = "refuted"
    CONTRADICTED = "contradicted"
    INCONCLUSIVE = "inconclusive"


class ContradictionType(str, Enum):
    """Classification of user subjective claim vs. objective ground truth mismatch (Bullet #16)."""
    NONE = "none"
    CLAIM_CONTRADICTED = "claim_contradicted"
    PREMISE_INVALID = "premise_invalid"
    SITUATION_MISIDENTIFIED = "situation_misidentified"


@dataclass
class ReasoningTrace:
    """A granular logical inference step in an empirical deduction chain (Bullet #16)."""
    step: int
    rule_id: str
    subsystem: str
    premises: list[str]
    deduction: str
    confidence: float

    def to_dict(self) -> dict[str, Any]:
        return {
            "step": self.step,
            "rule_id": self.rule_id,
            "subsystem": self.subsystem,
            "premises": self.premises,
            "deduction": self.deduction,
            "confidence": self.confidence,
        }


@dataclass
class InferenceResult:
    """Complete evidence-backed diagnostic deduction payload (Bullet #16)."""
    verdict: InferenceVerdict
    primary_cause: str
    confidence: float
    evidence_keys: list[str] = field(default_factory=list)
    contradicted_claims: list[str] = field(default_factory=list)
    contradiction_type: ContradictionType = ContradictionType.NONE
    reasoning_chain: list[ReasoningTrace] = field(default_factory=list)
    user_explanation: str = ""
    recommended_checks: list[str] = field(default_factory=list)
    eliminated_hypotheses: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "verdict": self.verdict.value if hasattr(self.verdict, "value") else str(self.verdict),
            "primary_cause": self.primary_cause,
            "confidence": self.confidence,
            "evidence_keys": self.evidence_keys,
            "contradicted_claims": self.contradicted_claims,
            "contradiction_type": self.contradiction_type.value if hasattr(self.contradiction_type, "value") else str(self.contradiction_type),
            "reasoning_chain": [r.to_dict() for r in self.reasoning_chain],
            "user_explanation": self.user_explanation,
            "recommended_checks": self.recommended_checks,
            "eliminated_hypotheses": self.eliminated_hypotheses,
        }


class HypothesisStatus(str, Enum):
    """Lifecycle status of a diagnostic hypothesis (Bullet #17)."""
    UNTESTED = "untested"
    TESTING = "testing"
    ELIMINATED = "eliminated"
    SUPPORTED = "supported"
    CONFIRMED = "confirmed"


@dataclass
class DiagnosticHypothesis:
    """A formal competing diagnostic hypothesis (Bullet #17)."""
    id: str
    name: str
    domain: SemanticDomain
    description: str
    test_tool: str
    test_args: dict[str, Any] = field(default_factory=dict)
    status: HypothesisStatus = HypothesisStatus.UNTESTED
    elimination_reason: Optional[str] = None
    confirmation_reason: Optional[str] = None
    confidence: float = 0.0
    cost: int = 1  # 1: local/cheap, 2: subsystem/medium, 3: external/heavy

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "name": self.name,
            "domain": self.domain.value if hasattr(self.domain, "value") else str(self.domain),
            "description": self.description,
            "test_tool": self.test_tool,
            "test_args": self.test_args,
            "status": self.status.value if hasattr(self.status, "value") else str(self.status),
            "elimination_reason": self.elimination_reason,
            "confirmation_reason": self.confirmation_reason,
            "confidence": self.confidence,
            "cost": self.cost,
        }


@dataclass
class HypothesisLedger:
    """Accounting ledger for multi-hypothesis generation and elimination (Bullet #17)."""
    symptom: str
    hypotheses: list[DiagnosticHypothesis] = field(default_factory=list)
    active_hypothesis: Optional[str] = None
    surviving_root_cause: Optional[str] = None
    eliminated_count: int = 0
    is_conclusive: bool = False

    def get_hypothesis(self, hid: str) -> Optional[DiagnosticHypothesis]:
        for h in self.hypotheses:
            if h.id.lower() == hid.lower() or h.name.lower() == hid.lower():
                return h
        return None

    def get_active_candidates(self) -> list[DiagnosticHypothesis]:
        return [h for h in self.hypotheses if h.status in (HypothesisStatus.UNTESTED, HypothesisStatus.TESTING, HypothesisStatus.SUPPORTED)]

    def get_eliminated_candidates(self) -> list[DiagnosticHypothesis]:
        return [h for h in self.hypotheses if h.status == HypothesisStatus.ELIMINATED]

    def to_dict(self) -> dict[str, Any]:
        return {
            "symptom": self.symptom,
            "hypotheses": [h.to_dict() for h in self.hypotheses],
            "active_hypothesis": self.active_hypothesis,
            "surviving_root_cause": self.surviving_root_cause,
            "eliminated_count": self.eliminated_count,
            "is_conclusive": self.is_conclusive,
        }


class CausalNodeType(str, Enum):
    """Classification of nodes in a directed causal failure graph (Bullet #18)."""
    SYMPTOM = "symptom"
    INTERMEDIATE_FAULT = "intermediate_fault"
    ROOT_CAUSE = "root_cause"
    MITIGATING_FACTOR = "mitigating_factor"


@dataclass
class CausalNode:
    """A node in a directed causal dependency DAG (Bullet #18)."""
    node_id: str
    name: str
    node_type: CausalNodeType
    subsystem: str
    description: str
    telemetry_evidence: dict[str, Any] = field(default_factory=dict)
    confidence: float = 0.0

    def to_dict(self) -> dict[str, Any]:
        return {
            "node_id": self.node_id,
            "name": self.name,
            "node_type": self.node_type.value if hasattr(self.node_type, "value") else str(self.node_type),
            "subsystem": self.subsystem,
            "description": self.description,
            "telemetry_evidence": self.telemetry_evidence,
            "confidence": self.confidence,
        }


@dataclass
class CausalLink:
    """A directed edge expressing a causal dependency mechanism (Bullet #18)."""
    source_id: str
    target_id: str
    relation: str
    mechanism: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "source_id": self.source_id,
            "target_id": self.target_id,
            "relation": self.relation,
            "mechanism": self.mechanism,
        }


@dataclass
class RemediationAction:
    """A targeted, non-disruptive remediation action targeting the root originator entity (Bullet #18)."""
    action_type: str
    target: str
    description: str
    command: Optional[str] = None
    risk_level: str = "low"  # low, medium, high
    is_minimal: bool = True

    def to_dict(self) -> dict[str, Any]:
        return {
            "action_type": self.action_type,
            "target": self.target,
            "description": self.description,
            "command": self.command,
            "risk_level": self.risk_level,
            "is_minimal": self.is_minimal,
        }


@dataclass
class RootCauseReport:
    """Structured Root-Cause Analysis (RCA) report and causal chain DAG (Bullet #18)."""
    symptom: str
    immediate_fault: Optional[str]
    root_cause: str
    root_entity: str
    causal_chain: list[str] = field(default_factory=list)
    nodes: list[CausalNode] = field(default_factory=list)
    links: list[CausalLink] = field(default_factory=list)
    evidence: dict[str, Any] = field(default_factory=dict)
    confidence: float = 0.0
    remediations: list[RemediationAction] = field(default_factory=list)

    def get_root_node(self) -> Optional[CausalNode]:
        for n in self.nodes:
            if n.node_type == CausalNodeType.ROOT_CAUSE:
                return n
        return None

    def get_symptom_node(self) -> Optional[CausalNode]:
        for n in self.nodes:
            if n.node_type == CausalNodeType.SYMPTOM:
                return n
        return None

    def to_dict(self) -> dict[str, Any]:
        return {
            "symptom": self.symptom,
            "immediate_fault": self.immediate_fault,
            "root_cause": self.root_cause,
            "root_entity": self.root_entity,
            "causal_chain": self.causal_chain,
            "nodes": [n.to_dict() for n in self.nodes],
            "links": [link.to_dict() for link in self.links],
            "evidence": self.evidence,
            "confidence": self.confidence,
            "remediations": [r.to_dict() for r in self.remediations],
        }


class BranchPath(str, Enum):
    """Execution path for dynamic conditional branching (Bullet #19)."""
    THEN = "then"
    ELSE = "else"
    SKIPPED = "skipped"


@dataclass
class ConditionalPredicate:
    """
    Standardized, deterministic predicate evaluator for runtime decision making (Bullet #19).
    Evaluates telemetry outputs against numeric, boolean, or membership thresholds.
    """
    metric_key: str
    operator: str  # ">", "<", ">=", "<=", "==", "!=", "in", "not in", "contains", "truthy"
    threshold: Any
    subsystem: str = "general"

    def evaluate(self, telemetry_output: dict[str, Any]) -> bool:
        """
        Safely extracts metric_key from telemetry_output (handling nested dictionaries,
        dotted paths, or flattened aliases) and performs deterministic comparison.
        """
        if not isinstance(telemetry_output, dict):
            return False

        # Extract value via dotted path or standard aliases
        val = None
        if "." in self.metric_key:
            parts = self.metric_key.split(".")
            curr = telemetry_output
            for p in parts:
                if isinstance(curr, dict) and p in curr:
                    curr = curr[p]
                else:
                    curr = None
                    break
            val = curr
        else:
            # Check top level
            if self.metric_key in telemetry_output:
                val = telemetry_output[self.metric_key]
            else:
                # Aliases lookup
                alias_map = {
                    "usage_percent": ["used_percent", "percent", "cpu_percent", "cpu_usage"],
                    "used_percent": ["usage_percent", "percent", "ram_used_percent"],
                    "free_gb": ["available_gb", "free_space_gb", "free"],
                    "connected": ["is_connected", "online", "link_up"],
                    "is_connected": ["connected", "online"],
                    "running": ["is_running", "found"],
                    "found": ["running", "is_running"],
                }
                candidates = alias_map.get(self.metric_key, [])
                for c in candidates:
                    if c in telemetry_output:
                        val = telemetry_output[c]
                        break

                # If still None, search one level down in nested dicts
                if val is None:
                    for sub_v in telemetry_output.values():
                        if isinstance(sub_v, dict):
                            if self.metric_key in sub_v:
                                val = sub_v[self.metric_key]
                                break
                            for c in candidates:
                                if c in sub_v:
                                    val = sub_v[c]
                                    break
                            if val is not None:
                                break

        if val is None:
            if self.operator == "==" and self.threshold in (False, None):
                return True
            if self.operator == "!=" and self.threshold not in (False, None):
                return True
            return False

        op = self.operator.strip().lower()

        # Numeric conversions when comparing numbers
        if op in (">", "<", ">=", "<="):
            try:
                num_val = float(val)
                num_thresh = float(self.threshold)
                if op == ">":
                    return num_val > num_thresh
                elif op == "<":
                    return num_val < num_thresh
                elif op == ">=":
                    return num_val >= num_thresh
                elif op == "<=":
                    return num_val <= num_thresh
            except (ValueError, TypeError):
                return False

        if op == "==":
            if isinstance(self.threshold, bool):
                return bool(val) is self.threshold
            if isinstance(val, str) and isinstance(self.threshold, str):
                return val.strip().lower() == self.threshold.strip().lower()
            try:
                return float(val) == float(self.threshold)
            except (ValueError, TypeError):
                return val == self.threshold

        if op == "!=":
            if isinstance(self.threshold, bool):
                return bool(val) is not self.threshold
            if isinstance(val, str) and isinstance(self.threshold, str):
                return val.strip().lower() != self.threshold.strip().lower()
            try:
                return float(val) != float(self.threshold)
            except (ValueError, TypeError):
                return val != self.threshold

        if op == "contains":
            if isinstance(val, (list, tuple, set, str)):
                thresh_str = str(self.threshold).lower()
                if isinstance(val, str):
                    return thresh_str in val.lower()
                return any(str(item).lower() == thresh_str for item in val)
            return False

        if op == "in":
            if isinstance(self.threshold, (list, tuple, set, str)):
                val_str = str(val).lower()
                if isinstance(self.threshold, str):
                    return val_str in self.threshold.lower()
                return any(str(item).lower() == val_str for item in self.threshold)
            return False

        if op == "not in":
            if isinstance(self.threshold, (list, tuple, set, str)):
                val_str = str(val).lower()
                if isinstance(self.threshold, str):
                    return val_str not in self.threshold.lower()
                return not any(str(item).lower() == val_str for item in self.threshold)
            return True

        if op in ("truthy", "is_truthy"):
            return bool(val)

        return False

    def to_dict(self) -> dict[str, Any]:
        return {
            "metric_key": self.metric_key,
            "operator": self.operator,
            "threshold": self.threshold,
            "subsystem": self.subsystem,
        }


# ==============================================================================
# BULLET #20: CONFIDENCE & UNCERTAINTY HANDLING
# ==============================================================================

class ConfidenceTier(str, Enum):
    """Calibrated confidence tier for risk-weighted execution gating (Bullet #20)."""
    HIGH = "high"       # C >= 0.85: Autonomous execution
    MEDIUM = "medium"   # 0.50 <= C < 0.85: Read-only with caveat, or safest default
    LOW = "low"         # C < 0.50: Execution prohibited, honest uncertainty report


class RiskTier(str, Enum):
    """Inherent risk classification of tools and actions (Bullet #20)."""
    READ_ONLY = "read_only"
    LOW_IMPACT = "low_impact"
    MEDIUM_IMPACT = "medium_impact"
    HIGH_DESTRUCTIVE = "high_destructive"


@dataclass
class ConfidenceScore:
    """
    Multi-vector mathematical confidence calibration (Bullet #20).
    Calculates overall score from intent clarity, entity certainty, and telemetry support.
    """
    intent_confidence: float    # C_intent in [0.0, 1.0]
    entity_confidence: float    # C_entity in [0.0, 1.0]
    evidence_confidence: float  # C_evidence in [0.0, 1.0]
    overall_confidence: float   # Weighted composite score in [0.0, 1.0]
    tier: ConfidenceTier
    rationale: str = ""
    factors: dict[str, float] = field(default_factory=dict)

    @classmethod
    def calculate(
        cls,
        intent_c: float,
        entity_c: float,
        evidence_c: float,
        rationale: str = "",
        w_intent: float = 0.40,
        w_entity: float = 0.35,
        w_evidence: float = 0.25,
        reasoning: str = "",
    ) -> "ConfidenceScore":
        """Deterministic weighted calculation of composite confidence score."""
        effective_rationale = rationale or reasoning
        i_c = max(0.0, min(1.0, float(intent_c)))
        e_c = max(0.0, min(1.0, float(entity_c)))
        ev_c = max(0.0, min(1.0, float(evidence_c)))
        composite = round(w_intent * i_c + w_entity * e_c + w_evidence * ev_c, 3)

        if composite >= 0.85:
            tier = ConfidenceTier.HIGH
        elif composite >= 0.50:
            tier = ConfidenceTier.MEDIUM
        else:
            tier = ConfidenceTier.LOW

        factors = {
            "intent_confidence": i_c,
            "entity_confidence": e_c,
            "evidence_confidence": ev_c,
            "weights": {"intent": w_intent, "entity": w_entity, "evidence": w_evidence},
        }

        return cls(
            intent_confidence=i_c,
            entity_confidence=e_c,
            evidence_confidence=ev_c,
            overall_confidence=composite,
            tier=tier,
            rationale=effective_rationale,
            factors=factors,
        )

    @property
    def overall_score(self) -> float:
        return self.overall_confidence

    @property
    def reasoning(self) -> str:
        return self.rationale

    def to_dict(self) -> dict[str, Any]:
        return {
            "intent_confidence": self.intent_confidence,
            "entity_confidence": self.entity_confidence,
            "evidence_confidence": self.evidence_confidence,
            "overall_confidence": self.overall_confidence,
            "overall_score": self.overall_confidence,
            "tier": self.tier.value if hasattr(self.tier, "value") else str(self.tier),
            "rationale": self.rationale,
            "reasoning": self.rationale,
            "factors": self.factors,
        }


@dataclass
class ConfirmationRequest:
    """
    Interactive confirmation request lifecycle model (Bullet #20).
    Holds staged high-risk or ambiguous actions until explicit affirmative/rejection response.
    """
    action_id: str = ""
    tool: str = ""
    args: dict[str, Any] = field(default_factory=dict)
    target: str = ""
    risk_tier: RiskTier = RiskTier.HIGH_DESTRUCTIVE
    confidence: float = 0.0
    prompt_message: str = ""
    timestamp: float = field(default_factory=time.time)
    is_confirmed: bool = False
    status: str = "PENDING_CONFIRMATION"
    action: str = ""
    domain: str = ""
    confidence_score: Any = None

    def __post_init__(self):
        if not self.action_id and self.action:
            self.action_id = self.action
        if not self.action_id:
            self.action_id = self.tool
        if not self.action:
            self.action = self.action_id
        if self.confidence_score is not None and not self.confidence:
            self.confidence = float(getattr(self.confidence_score, "overall_score", getattr(self.confidence_score, "overall_confidence", 0.0)))

    def to_dict(self) -> dict[str, Any]:
        return {
            "action_id": self.action_id,
            "action": self.action,
            "tool": self.tool,
            "args": self.args,
            "target": self.target,
            "domain": self.domain,
            "risk_tier": self.risk_tier.value if hasattr(self.risk_tier, "value") else str(self.risk_tier),
            "confidence": self.confidence,
            "prompt_message": self.prompt_message,
            "timestamp": self.timestamp,
            "is_confirmed": self.is_confirmed,
            "status": self.status,
        }


