"""
Deterministic Command Router and Intent Classification Engine (Modular Facade).
All components have been split into modular submodules under 800 lines each.
This module re-exports all classes, functions, and constants for 100% backward compatibility.
"""
from __future__ import annotations

from command_layer.router_base import (
    Step,
    run_tool_call,
    resolve_system_canonical_path,
    verify_post_recovery,
    verify_semantic_outcome,
    capture_environment_snapshot,
    capture_step_observation,
    detect_environment_drift,
    _entity_val,
    get_all_schemas,
    KNOWN_SITE_KEYS,
    KNOWN_APP_NAMES,
    _has_file_extension,
    _normalize_resolved_path,
    _is_conversational_folder_path,
)

from command_layer.router_confidence import (
    determine_risk_tier,
    format_uncertainty_response,
    compute_command_confidence,
    synthesize_cross_domain_report,
    synthesize_long_horizon_report,
    get_conversational_response,
    evaluate_confidence_routing,
)

from command_layer.router_sanitizer import (
    _isolate_browser_context,
    prune_negated_steps,
    sanitize_action_query,
    sanitize_url,
    _canonicalize_plan_tools,
    sanitize_ui_target,
    extract_clean_search_query,
)

from command_layer.router_cli_parser import (
    translate_cli_command,
    sanitize_cli_command,
    extract_pure_text_payload,
    parse_sequential_keyboard_actions,
    is_standalone_navigation_request,
    resolve_temporal_order,
    strip_idiomatic_conditions,
)

from command_layer.router_core import (
    decompose_deterministic_plan,
    _route_command_impl,
    route_command,
)

from command_layer.router_classifier_core import (
    _classify_and_parse_command,
)

from command_layer.router_rollback import (
    execute_transactional_rollback,
    _is_step_dependent_on,
)

from command_layer.router_interceptors import (
    intercept_user_command,
)

from command_layer.router_dispatch import (
    dispatch_and_resolve_plan,
)

from command_layer.router_step_executor import (
    execute_step_precondition_and_dispatch,
)

from command_layer.router_step_verifier import (
    post_process_step_execution,
)

from command_layer.router_executor import (
    synthesize_final_execution_output,
    handle_command,
    route_and_execute,
)

# Re-export commonly used types & modules
from brain.planner import (
    Plan,
    PlanStep,
    StructuredIntent,
    create_plan_from_decision,
    decompose_compound_command,
    parse_compound_request,
    resolve_step_variables,
    resolve_step_variables_with_guard,
    inject_plan_prerequisites,
    prune_plan_steps,
    build_hypothesis_investigation_plan,
    build_root_cause_investigation_plan,
    parse_conditional_goal,
    synthesize_adaptive_replan,
    decompose_into_milestones,
    restore_plan_from_checkpoint,
    build_cross_domain_plan,
    apply_cross_domain_transformation,
    build_long_horizon_exploration_plan,
    decompose_long_horizon_goal,
    compute_state_hash,
    detect_state_cycle,
    heuristic_node_score,
    expand_exploration_frontier,
    select_next_frontier_node,
    apply_reflective_history_pruning,
)
from command_layer.cognitive_reasoner import CognitiveReasoner
from command_layer.context import (
    EntityType,
    TypedEntity,
    ORDINAL_REFERENCES,
    SessionContext,
    resolve_references,
    session_context,
    update_context_from_result,
)
from command_layer.semantic_model import (
    SemanticDomain,
    SemanticAction,
    CommandIntent,
    AmbiguityType,
    ClarificationRequest,
    SymptomCategory,
    SituationType,
    ConfidenceTier,
    RiskTier,
    ConfidenceScore,
    ConfirmationRequest,
    FailureType,
    AdaptiveStrategy,
    PlanAdaptation,
    TaskLifecycleState,
    TaskMilestone,
    TaskCheckpoint,
    DomainBridgeType,
    DomainBridgeLink,
    CrossDomainWorkflow,
    HorizonDepth,
    ExplorationNode,
    SearchFrontier,
    LongHorizonReport,
    HistoryQueryType,
    ExecutionTraceRecord,
    TraceSummary,
)
from command_layer.semantic_parser import (
    parse_semantic_intent,
    create_plan_from_intent,
    resolve_in_turn_correction,
    strip_conversational_noise,
    split_compound_clauses,
    detect_symptom_category,
)
from command_layer.firewall import validate_tool_against_firewall, pre_execution_semantic_check, validate_long_horizon_action
from command_layer.state_machine import agent_state
from command_layer.validator import validate_and_sanitize_tool_arguments
from command_layer.lexer import UniversalLexer
from brain.runtime_bus import RuntimePipingBus
from security.state import confirmation_manager
from tools.utils.app_resolver import (
    APP_ALIASES,
    get_canonical_app_name,
    resolve_app,
)
from tools.utils.target_resolver import TargetType, resolve_universal_target, disambiguate_multi_candidates

__all__ = [
    "Step",
    "run_tool_call",
    "resolve_system_canonical_path",
    "verify_post_recovery",
    "verify_semantic_outcome",
    "capture_environment_snapshot",
    "capture_step_observation",
    "detect_environment_drift",
    "_entity_val",
    "get_all_schemas",
    "KNOWN_SITE_KEYS",
    "KNOWN_APP_NAMES",
    "_has_file_extension",
    "_normalize_resolved_path",
    "_is_conversational_folder_path",
    "determine_risk_tier",
    "format_uncertainty_response",
    "compute_command_confidence",
    "evaluate_confidence_routing",
    "synthesize_cross_domain_report",
    "synthesize_long_horizon_report",
    "get_conversational_response",
    "_isolate_browser_context",
    "prune_negated_steps",
    "sanitize_action_query",
    "sanitize_url",
    "_canonicalize_plan_tools",
    "sanitize_ui_target",
    "extract_clean_search_query",
    "translate_cli_command",
    "sanitize_cli_command",
    "extract_pure_text_payload",
    "parse_sequential_keyboard_actions",
    "is_standalone_navigation_request",
    "resolve_temporal_order",
    "strip_idiomatic_conditions",
    "decompose_deterministic_plan",
    "_route_command_impl",
    "route_command",
    "_classify_and_parse_command",
    "execute_transactional_rollback",
    "_is_step_dependent_on",
    "handle_command",
    "route_and_execute",
]
