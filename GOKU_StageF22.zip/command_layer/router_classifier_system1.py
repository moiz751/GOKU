from __future__ import annotations
import os
from pathlib import Path
import re
import sys
import time
from typing import Any, Optional, Union, List, Dict, Tuple
from dataclasses import dataclass, field

from brain.planner import (
    Plan,
    PlanStep,
    StructuredIntent,
    create_plan_from_decision,
    decompose_compound_command,
    parse_compound_request,
    resolve_step_variables,
    resolve_step_variables_with_guard,
    inject_plan_prerequisites,
    prune_plan_steps,
    build_hypothesis_investigation_plan,
    build_root_cause_investigation_plan,
    parse_conditional_goal,
    synthesize_adaptive_replan,
    decompose_into_milestones,
    restore_plan_from_checkpoint,
    build_cross_domain_plan,
    apply_cross_domain_transformation,
    build_long_horizon_exploration_plan,
    decompose_long_horizon_goal,
    compute_state_hash,
    detect_state_cycle,
    heuristic_node_score,
    expand_exploration_frontier,
    select_next_frontier_node,
    apply_reflective_history_pruning,
)
from command_layer.cognitive_reasoner import CognitiveReasoner
from command_layer.context import (
    EntityType,
    TypedEntity,
    ORDINAL_REFERENCES,
    SessionContext,
    resolve_references,
    session_context,
    update_context_from_result,
)
from command_layer.semantic_model import (
    SemanticDomain,
    SemanticAction,
    CommandIntent,
    AmbiguityType,
    ClarificationRequest,
    SymptomCategory,
    SituationType,
    ConfidenceTier,
    RiskTier,
    ConfidenceScore,
    ConfirmationRequest,
    FailureType,
    AdaptiveStrategy,
    PlanAdaptation,
    TaskLifecycleState,
    TaskMilestone,
    TaskCheckpoint,
    DomainBridgeType,
    DomainBridgeLink,
    CrossDomainWorkflow,
    HorizonDepth,
    ExplorationNode,
    SearchFrontier,
    LongHorizonReport,
    HistoryQueryType,
    ExecutionTraceRecord,
    TraceSummary,
)
from command_layer.semantic_parser import (
    parse_semantic_intent,
    create_plan_from_intent,
    resolve_in_turn_correction,
    strip_conversational_noise,
    split_compound_clauses,
    detect_symptom_category,
)
from command_layer.firewall import validate_tool_against_firewall, pre_execution_semantic_check, validate_long_horizon_action
from command_layer.state_machine import agent_state
from command_layer.validator import validate_and_sanitize_tool_arguments
from command_layer.lexer import UniversalLexer
from brain.runtime_bus import RuntimePipingBus
from security.state import confirmation_manager
from tools.utils.app_resolver import (
    APP_ALIASES,
    get_canonical_app_name,
    resolve_app,
)
from tools.utils.target_resolver import TargetType, resolve_universal_target, disambiguate_multi_candidates
from command_layer.router_base import (
    Step,
    run_tool_call,
    resolve_system_canonical_path,
    verify_post_recovery,
    verify_semantic_outcome,
    capture_environment_snapshot,
    capture_step_observation,
    detect_environment_drift,
    _entity_val,
    get_all_schemas,
    KNOWN_SITE_KEYS,
    KNOWN_APP_NAMES,
    _has_file_extension,
    _normalize_resolved_path,
    _is_conversational_folder_path,
)
from security.safety_firewall import is_safe_readonly_operation
from security.confirm import RISKY_TOOLS
from command_layer.decomposer import count_action_verbs
from brain.workflow_orchestrator import orchestrate_compound_workflow
from tools.browser import sanitize_search_query
from tools.search import parse_search_grammar
import executor.verifier
import executor.executor

from command_layer.router_sanitizer import (
    _isolate_browser_context,
    prune_negated_steps,
    sanitize_action_query,
    sanitize_url,
    _canonicalize_plan_tools,
    sanitize_ui_target,
    extract_clean_search_query,
)
from command_layer.router_cli_parser import (
    translate_cli_command,
    sanitize_cli_command,
    extract_pure_text_payload,
    parse_sequential_keyboard_actions,
    is_standalone_navigation_request,
    resolve_temporal_order,
    strip_idiomatic_conditions,
)
from command_layer.router_confidence import (
    determine_risk_tier,
    format_uncertainty_response,
    compute_command_confidence,
    synthesize_cross_domain_report,
    synthesize_long_horizon_report,
    get_conversational_response,
)

def _classify_and_parse_command(text: str, context: SessionContext | None = None, is_compound_root: bool = True) -> Plan | None:
    from command_layer.router_classifier_core import _classify_and_parse_command as _real_fn
    return _real_fn(text, context, is_compound_root)

def classify_system_intents_1(text: str, context: SessionContext | None = None, is_compound_root: bool = True) -> Plan | None:
    from command_layer.decomposer import count_action_verbs
    from brain.workflow_orchestrator import orchestrate_compound_workflow
    from tools.browser import sanitize_search_query
    from tools.search import parse_search_grammar
    from security.safety_firewall import is_safe_readonly_operation
    from security.confirm import RISKY_TOOLS
    cleaned = re.sub(r'[\x00-\x1f\x7f]+$', '', text).strip()
    cleaned = re.sub(r'[\x13\x03\x1b]', '', cleaned).strip()
    raw_lower = cleaned.lower()
    lower = text.lower()
    folder_ref_m = re.search(r"folder\s+'([^']+)'", text)
    file_ref_m = re.search(r"file\s+'([^']+)'", text)
    text_unwrapped = re.sub(r'[\'"]([^\'"]+)[\'"]', r'\1', text)
    try:
        symptom_cat, situation_type, symptom_entities = detect_symptom_category(raw_lower)
    except Exception:
        symptom_cat, situation_type, symptom_entities = SymptomCategory.NONE, SituationType.NORMAL, []
    _p2_is_compound_guard = False
    # Direct typing classifier guard: If input starts with "type " or "likho " (or "send_keyboard_input "),
    # assign directly to send_keyboard_input without evaluating process inspection patterns.
    # Prioritize compound workflow orchestration before generic typing when multiple conjunctions or 3+ verbs exist.
    # HARDENED: also short-circuit when even ONE conjunction co-occurs with a lifecycle verb (launch/open/close/read/save/scan).
    _LIFECYCLE_VERBS_TYP = {"launch", "open", "close", "read", "save", "scan", "kholo", "band", "padhao", "likho"}
    has_multiple_conjs_typ = len(re.findall(r'\b(?:phir|aur|and|then|after\s+that|pehle)\b', raw_lower)) >= 2
    _has_any_conj_typ = bool(re.search(r'\b(?:phir|aur|and|then|after\s+that|pehle)\b', raw_lower))
    _has_lifecycle_typ = any(v in raw_lower.split() for v in _LIFECYCLE_VERBS_TYP) or bool(re.search(r'\b(?:launch|open|close|read|save|scan)\b', raw_lower))
    from command_layer.decomposer import count_action_verbs
    has_3_plus_verbs_typ = count_action_verbs(raw_lower) >= 3
    # Compound guard: >=2 conjunctions OR 3+ action verbs OR (1 conjunction + lifecycle verb)
    _is_compound_typing_guard = has_multiple_conjs_typ or has_3_plus_verbs_typ or (_has_any_conj_typ and _has_lifecycle_typ)
    if _is_compound_typing_guard and is_compound_root:
        from brain.workflow_orchestrator import orchestrate_compound_workflow
        orch_plan = orchestrate_compound_workflow(cleaned, context)
        if orch_plan is not None and orch_plan.steps and not getattr(orch_plan, "is_direct_message", False):
            return orch_plan

    is_inquiry_for_typing = (
        any(raw_lower.startswith(p) for p in ["can you", "tell me", "give me", "list", "how many", "show me", "what is", "what are", "which", "kya", "batao", "dikhao", "type of", "type ka", "type ki"])
        or bool(re.search(r'\b(?:type\s+of)\b', raw_lower))
    )
    type_direct_prefix_m = re.match(r'^(?:type|likho|send_keyboard_input)\s+(.+)$', cleaned, re.IGNORECASE)
    if type_direct_prefix_m and not is_inquiry_for_typing and not _is_compound_typing_guard:

        raw_text_payload = type_direct_prefix_m.group(1).strip()
        with_enter = False
        if re.search(r'\s+(?:aur|and)\s+enter(?:\s+press|\s+karo)?$', raw_text_payload, re.IGNORECASE):
            raw_text_payload = re.sub(r'\s+(?:aur|and)\s+enter(?:\s+press|\s+karo)?$', '', raw_text_payload, flags=re.IGNORECASE).strip()
            with_enter = True
        elif re.search(r'\s+enter(?:\s+press|\s+karo)?$', raw_text_payload, re.IGNORECASE):
            raw_text_payload = re.sub(r'\s+enter(?:\s+press|\s+karo)?$', '', raw_text_payload, flags=re.IGNORECASE).strip()
            with_enter = True

        if (raw_text_payload.startswith('"') and raw_text_payload.endswith('"')) or (raw_text_payload.startswith("'") and raw_text_payload.endswith("'")):
            raw_text_payload = raw_text_payload[1:-1]

        target_app_extracted = None
        m_app = re.search(r'\s+(?:in|into|ke\s+andar|mein|me)\s+(wordpad|notepad|chrome|edge|word|vscode|vs\s+code)$', raw_text_payload, re.IGNORECASE)
        if m_app:
            target_app_extracted = m_app.group(1)
            raw_text_payload = raw_text_payload[:m_app.start()].strip()
        else:
            m_pronoun = re.search(r'\s+(?:in\s+it|into\s+it|inside\s+it|in\s+there|usme|usmein|isme|ismein|there)$', raw_text_payload, re.IGNORECASE)
            if m_pronoun:
                raw_text_payload = raw_text_payload[:m_pronoun.start()].strip()

        step_args = {"text": raw_text_payload, "press_enter": with_enter}
        if target_app_extracted:
            if target_app_extracted.lower() == "wordpad":
                step_args["app_name"] = "WordPad"
            elif target_app_extracted.lower() == "notepad":
                step_args["app_name"] = "Notepad"
            else:
                step_args["app_name"] = target_app_extracted

        tool_to_use = "send_keyboard_input" if cleaned.lower().startswith("send_keyboard_input") else "type_text"
        return Plan(
            steps=[PlanStep(step=1, tool=tool_to_use, args=step_args)],
            explanation=f"Typed '{raw_text_payload}'."
        )

    # Phase 4: OS Hotkey Macro: Minimize All / Show Desktop
    # Matches: "minimize all", "show desktop", "show the desktop", "desktop dikhao", "minimize all windows"
    if not (is_compound_root and any(sep in raw_lower for sep in [";", ",", " aur ", " and ", " phir ", " then ", " karke ", " ke baad ", " pehle "])) and (
        (
            re.search(r'\b(?:minimize\s+all(?:\s+windows)?|show\s+(?:the\s+)?desktop|desktop\s+dikhao|saari\s+windows\s+minimize|sari\s+windows\s+minimize)\b', raw_lower)
            or raw_lower in ("minimize all", "show desktop", "show the desktop")
        ) and not any(w in raw_lower for w in ["folder", "file", "icon", "background", "wallpaper"])
    ):
        return Plan(
            steps=[PlanStep(step=1, tool="press_hotkey", args={"keys": "win+d"})],
            explanation="Minimizing all windows / showing desktop via Win+D hotkey."
        )

    # Phase 4: Autonomous Microsoft Store Navigation & Search Loop
    # Enforces complete 4-step execution: launch -> wait -> click Search -> type query
    # Matches: "search for asphalt 9 on microsoft store", "search asphalt 8 on store", "download angry birds from store",
    #          "search for {game} on microsoft store", "microsoft store par {game} search karo"
    m_store_search = re.search(
        r'\bsearch(?:\s+for)?\s+(.+?)\s+on\s+(?:microsoft\s+store|store)\b',
        cleaned,
        re.IGNORECASE
    )
    if not m_store_search:
        m_store_search = re.search(
            r'\b(?:search\s+for|search|find)\s+(.+?)\s+(?:on|in)\s+(?:microsoft\s+store|windows\s+store|the\s+store|store)\b',
            cleaned,
            re.IGNORECASE
        )
    if not m_store_search:
        m_store_search = re.search(
            r'\b(?:download|install)\s+(.+?)\s+(?:from|on)\s+(?:microsoft\s+store|windows\s+store|the\s+store|store)\b',
            cleaned,
            re.IGNORECASE
        )
    if not m_store_search:
        m_store_search = re.search(
            r'\b(?:microsoft\s+store|windows\s+store|store)\s+(?:par|pe|mein|se)\s+(.+?)\s+(?:search|dhoondo|download|install)\b',
            cleaned,
            re.IGNORECASE
        )

    matched_store_game = None
    if m_store_search:
        cand = m_store_search.group(1).strip().strip("'\"")
        cleaned_cand = re.sub(r'\b(game|app|application|wali|wala|ko|karo|kar|do|karna)\b', '', cand, flags=re.IGNORECASE).strip().strip("'\"")
        if not cleaned_cand:
            cleaned_cand = cand
        if cleaned_cand and cleaned_cand.lower() not in ("microsoft store", "store", "all", "the"):
            matched_store_game = cleaned_cand

    if matched_store_game:
        return Plan(
            steps=[
                PlanStep(step=1, tool="launch_app", args={"name": "ms-windows-store:"}),
                PlanStep(step=2, tool="wait_for_ui_settle", args={"delay_ms": 2500}),
                PlanStep(step=3, tool="click_element_by_text", args={"target_text": "Search"}),
                PlanStep(step=4, tool="send_keyboard_input", args={"text": matched_store_game, "press_enter": True}),
            ],
            explanation=f"Autonomous loop: Opened Microsoft Store, waited for UI settle, clicked Search, and typed '{matched_store_game}'."
        )

    # Phase 4.5: Categorized Games Inquiry (2 Categories: Microsoft Store vs Browser / Win32)
    # Matches: "give me games in two types", "games from chrome and store", "categorize games into store and browser", "games in two categories"
    is_categorized_games = (
        ("game" in raw_lower or "games" in raw_lower)
        and (
            any(w in raw_lower for w in ["two types", "two type", "two categories", "2 types", "2 categories", "both types", "both categories", "do types", "do tareeqay", "chrome and store", "store and chrome", "browser and store", "store and browser"])
            or ("give me games" in raw_lower and "type" in raw_lower)
        )
    )
    if is_categorized_games:
        return Plan(
            steps=[PlanStep(step=1, tool="get_installed_apps", args={"query": "categorized_games"})],
            explanation="Inspecting installed games categorized into Microsoft Store and Win32 / Browser installed games."
        )

    # Phase 4: Store Games Count Routing
    is_store_game_count = (
        ("game" in raw_lower or "games" in raw_lower)
        and any(w in raw_lower for w in ["microsoft store", "store", "uwp"])
        and any(w in raw_lower for w in ["downloaded", "installed", "count", "how many", "kitne", "kitni", "list", "show", "batao"])
    ) and not any(w in raw_lower for w in ["play", "khelna", "launch", "run", "open", "search"])
    if is_store_game_count:
        return Plan(
            steps=[PlanStep(step=1, tool="get_installed_apps", args={"query": "uwp_games"})],
            explanation="Inspecting installed Microsoft Store games via native StartApps package origin."
        )

    # Phase 3: System Inventory & Installed Applications / Games Inspection
    is_game_count = (
        any(w in raw_lower for w in ["how many games", "how many game", "kitni games", "kitne game", "installed games", "downloaded games", "games that are", "games in my pc", "games on this pc", "games on my pc", "games on pc"])
        or (("game" in raw_lower or "games" in raw_lower) and any(w in raw_lower for w in ["downloaded", "installed", "count", "kitne", "kitni", "how many", "list", "show", "batao", "find", "tell", "tell about", "tell me", "give me", "on my pc", "in my pc", "already in", "already on", "my pc", "this pc"]))
    ) and not any(w in raw_lower for w in ["play", "khelna", "khelo", "launch", "run", "open", "search for"])
    if is_game_count:
        return Plan(
            steps=[PlanStep(step=1, tool="get_installed_apps", args={"query": "games"})],
            explanation="Inspecting installed games via native system registry and StartApps index."
        )

    is_app_count = any(w in raw_lower for w in ["how many apps", "how many applications", "kitni apps", "kitne app", "count installed apps", "count apps"])
    if is_app_count:
        return Plan(
            steps=[PlanStep(step=1, tool="get_installed_apps", args={"query": ""})],
            explanation="Inspecting installed applications via native system registry and StartApps index."
        )

    # Phase 3: Web Search Intent Interception
    from tools.browser import sanitize_search_query
    m_search_about = re.match(r'^(?:please\s+)?search\s+(?:(?:about|for)\s+)?(.+?)(?:\s+(?:on\s+(?:google|web|internet|edge|msedge|chrome)|in\s+(?:chrome|browser|google|edge|msedge)))?$', cleaned, re.IGNORECASE)
    if m_search_about and not any(w in raw_lower for w in ["select", "click", "dabao", "type", "likho", "clear", "drag"]) and not _has_file_extension(raw_lower) and not any(f in raw_lower for f in ("file", "folder", "directory", "pdf", "docx", "txt", "ghost_app")):
        raw_q = re.sub(r'^(?:karo|kar\s+do)\s+', '', m_search_about.group(1).strip().strip('\'"'), flags=re.IGNORECASE)
        q = sanitize_search_query(raw_q)
        if q:
            b_target = "edge" if any(b in raw_lower for b in ["edge", "msedge"]) else "chrome"
            return Plan(
                steps=[PlanStep(step=1, tool="search_web", args={"query": q, "browser": b_target})],
                explanation=f"Searching for '{q}' using {b_target.title()}."
            )

    m_search_on_google = re.match(r'^(?:please\s+)?search\s+(.+?)\s+on\s+(google|edge|msedge|chrome|web|internet)$', cleaned, re.IGNORECASE)
    if m_search_on_google:
        q = sanitize_search_query(m_search_on_google.group(1).strip().strip('\'"'))
        dest = m_search_on_google.group(2).lower()
        if q:
            b_target = "edge" if dest in ("edge", "msedge") or any(b in raw_lower for b in ["edge", "msedge"]) else "chrome"
            return Plan(
                steps=[PlanStep(step=1, tool="search_web", args={"query": q, "browser": b_target})],
                explanation=f"Searching for '{q}' using {b_target.title()}."
            )

    m_google_search = re.match(r'^(?:please\s+)?(?:google|edge|msedge)\s+search\s+(.+)$', cleaned, re.IGNORECASE)
    if m_google_search:
        q = sanitize_search_query(m_google_search.group(1).strip().strip('\'"'))
        if q:
            b_target = "edge" if any(b in raw_lower for b in ["edge", "msedge"]) else "chrome"
            return Plan(
                steps=[PlanStep(step=1, tool="search_web", args={"query": q, "browser": b_target})],
                explanation=f"Searching for '{q}' using {b_target.title()}."
            )

    # Phase 3: Text-based UI Element Clicker & Native OCR Finder
    m_find_text = re.match(r'^(?:please\s+)?(?:find|locate)\s+text\s+(?:on\s+screen\s+)?[\'"]?([a-zA-Z0-9_\-\s]+?)[\'"]?$', cleaned, re.IGNORECASE)
    if m_find_text:
        target_t = m_find_text.group(1).strip()
        if target_t:
            return Plan(
                steps=[PlanStep(step=1, tool="find_text_on_screen", args={"target_text": target_t})],
                explanation=f"Locating text '{target_t}' on screen via native UI inspection/OCR."
            )

    # Broadened click-element target extraction:
    # Catches: "click element File", "click on element Save", "click the element OK", "click the element Cancel"
    # Roman Urdu: "File par click karo", "Save button par click karo", "Next tab par click karo"
    m_click_element_target = re.match(
        r'^(?:please\s+)?(?:mouse\s+)?click\s+(?:(?:on|the)\s+)?element\s+[\'"]?(?P<target>[a-zA-Z0-9_\-][a-zA-Z0-9_\-\s]{0,60}?)[\'"]?$',
        cleaned, re.IGNORECASE
    )
    if not m_click_element_target:
        # Also catch: "click <Target>" where Target starts with uppercase (named UI element, not a reserved word)
        m_click_element_target = re.match(
            r'^(?:please\s+)?(?:mouse\s+)?click\s+(?:on\s+)?(?P<target>[A-Z][a-zA-Z0-9_\-\s]{1,60}?)$',
            cleaned
        )
        if m_click_element_target:
            reserved = {'file', 'folder', 'it', 'here', 'screen', 'desktop', 'window',
                        'left', 'right', 'mouse', 'desktop icon', 'current window'}
            if m_click_element_target.group("target").strip().lower() in reserved:
                m_click_element_target = None
    if m_click_element_target:
        target_t = m_click_element_target.group("target").strip()
        if target_t:
            return Plan(
                steps=[PlanStep(step=1, tool="click_element_by_text", args={"target_text": target_t})],
                explanation=f"Clicking on-screen element '{target_t}' via UIA/OCR grounding."
            )

    m_click_text_explicit = re.match(r'^(?:please\s+)?(?:mouse\s+)?click\s+(?:on\s+text|text|element\s+by\s+text|element\s+with\s+text)\s+[\'"]?([a-zA-Z0-9_\-\s]+?)[\'"]?$', cleaned, re.IGNORECASE)
    if m_click_text_explicit:
        target_t = m_click_text_explicit.group(1).strip()
        if target_t:
            return Plan(
                steps=[PlanStep(step=1, tool="click_element_by_text", args={"target_text": target_t})],
                explanation=f"Clicking on-screen element with text '{target_t}'."
            )

    m_click_named = re.match(r'^(?:please\s+)?(?:mouse\s+)?click\s+(?:on\s+)?[\'"]([a-zA-Z0-9_\-\s]+?)[\'"]$', cleaned, re.IGNORECASE)
    if m_click_named and not re.match(r'^\d+\s*,\s*\d+$', m_click_named.group(1).strip()):
        target_t = m_click_named.group(1).strip()
        if target_t and not any(w in target_t.lower() for w in ["file", "folder", "drive"]):
            return Plan(
                steps=[PlanStep(step=1, tool="click_element_by_text", args={"target_text": target_t})],
                explanation=f"Clicking on-screen element with text '{target_t}'."
            )

    m_click_on = re.match(r'^(?:please\s+)?(?:mouse\s+)?click\s+on\s+([a-zA-Z]+)$', cleaned, re.IGNORECASE)
    if m_click_on and m_click_on.group(1).lower() not in [
        'file', 'folder', 'it', 'here', 'screen', 'desktop', 'window', 'left', 'right',
        'element', 'the', 'button', 'icon', 'tab', 'link',  # structural words that are not UI elements
    ]:
        target_t = m_click_on.group(1).strip()
        return Plan(
            steps=[PlanStep(step=1, tool="click_element_by_text", args={"target_text": target_t})],
            explanation=f"Clicking on-screen element with text '{target_t}'."
        )

    m_click_word = re.match(r'^(?:please\s+)?(?:mouse\s+)?click\s+([a-zA-Z]+)$', cleaned, re.IGNORECASE)
    if m_click_word and m_click_word.group(1).lower() in ['search', 'install', 'cancel', 'ok', 'submit', 'login', 'download', 'next', 'save']:
        target_t = m_click_word.group(1).strip()
        return Plan(
            steps=[PlanStep(step=1, tool="click_element_by_text", args={"target_text": target_t})],
            explanation=f"Clicking on-screen element with text '{target_t}'."
        )

    # 0.05 Compound App/URL Launch + UI Action Workflow
    # Matches:
    #   "<app/site> (open|kholo|launch) (karo|ker) aur <target> (par|pe)? (click karo|select karo)"
    #   "taskmgr launch karo aur processes tab par click karo"
    #   "tiktok open karo aur continue with google par click karo"
    #   "calc launch karo, 7 par click karo, multiply par click karo"
    m_compound_app_click = re.match(
        r'^(?:please\s+)?(?P<app>[a-zA-Z0-9_\.\-]+)\s+(?P<verb>open|kholo|launch|start|chalao)\s*(?:karo|kar|ker|do)?\s*(?:,|aur|and|phir|\sthen\s)\s+(?P<rest>.+)$',
        cleaned,
        re.IGNORECASE
    )
    if m_compound_app_click:
        raw_app = m_compound_app_click.group("app").strip()
        rest_clause = m_compound_app_click.group("rest").strip()
        if any(w in rest_clause.lower() for w in ["click", "select", "dabao", "press", "type", "likho"]):
            is_site = (
                raw_app.lower() in KNOWN_SITE_KEYS
                or any(raw_app.lower().startswith(p) for p in ["http://", "https://", "www."])
                or any(raw_app.lower().endswith(s) for s in [".com", ".org", ".net", ".io", ".pk", ".co"])
            )
            c_steps = []
            if is_site:
                c_steps.append(PlanStep(step=1, tool="open_url", args={"url": raw_app, "browser": "chrome"}))
            else:
                app_cand = get_canonical_app_name(raw_app) or raw_app
                c_steps.append(PlanStep(step=1, tool="launch_app", args={"name": app_cand}))

            c_steps.append(PlanStep(step=2, tool="wait_for_ui_settle", args={"timeout_ms": 1000}))

            sub_actions = [a.strip() for a in re.split(r'\s*(?:,|aur|and|phir|\sthen\s)\s*', rest_clause) if a.strip()]
            for act in sub_actions:
                act_lower = act.lower()
                if any(w in act_lower for w in ["click", "select", "dabao", "press"]):
                    t = re.sub(r'^(?:aur|and|phir|then|pehle|please)\s+', '', act, flags=re.IGNORECASE)
                    t = re.sub(r'\s*(?:par|pe)?\s*(?:click\s+karo|click\s+kar\s+do|click|select\s+karo|select|dabao|press)\.?$', '', t, flags=re.IGNORECASE).strip()
                    t = re.sub(r'\s+(?:par|pe)$', '', t, flags=re.IGNORECASE).strip()
                    t = t.strip("'\"")
                    if t:
                        c_steps.append(PlanStep(
                            step=len(c_steps) + 1,
                            tool="find_and_interact",
                            args={"target_query": t, "query": t, "action": "click"}
                        ))
                elif any(w in act_lower for w in ["type", "likho", "write", "enter"]):
                    txt_m = re.search(r"['\"]([^'\"]+)['\"]", act)
                    input_txt = txt_m.group(1) if txt_m else "text"
                    t_field = re.sub(r'\b(mein|me|likho|type|enter|karo|please)\b', '', act, flags=re.IGNORECASE).strip().strip("'\"") or "input"
                    c_steps.append(PlanStep(
                        step=len(c_steps) + 1,
                        tool="find_and_interact",
                        args={"target_query": t_field, "query": t_field, "action": "type", "input_text": input_txt}
                    ))

            if len(c_steps) >= 3:
                return Plan(
                    steps=c_steps,
                    explanation=f"Compound workflow: launched {raw_app} and interacted with target UI elements."
                )

    # Ordinal / Relative UI Click Grounding: "pehli video", "pehla link", "first result", "first item"
    m_ordinal_click = re.match(
        r'^(?:please\s+)?(?:mouse\s+)?(?:click\s+(?:on\s+)?|select\s+)?(?P<target>(?:pehli|pehla|first|1st|doosri|doosra|second|2nd|teesri|teesra|third|3rd)\s+(?:video|link|result|item|card|search\s+result))(?:\s+(?:par|pe))?(?:\s+(?:click|select|dabao)\s*(?:karo|kar\s+do|karna)?)?$',
        cleaned,
        re.IGNORECASE
    )
    if m_ordinal_click:
        ord_t = m_ordinal_click.group("target").lower().strip()
        rank_val = 1
        if any(r in ord_t for r in ["second", "doosra", "doosri", "2nd"]):
            rank_val = 2
        elif any(r in ord_t for r in ["third", "teesra", "teesri", "3rd"]):
            rank_val = 3
        if "video" in ord_t:
            t_q = f"video_result_{rank_val}"
        elif "link" in ord_t:
            t_q = f"link_item_{rank_val}"
        else:
            t_q = f"result_item_{rank_val}"
        steps = [PlanStep(step=1, tool="find_and_interact", args={"target_query": t_q, "query": t_q, "action": "click", "rank": rank_val})]
        refocus_app = getattr(context, "last_target_app", None) if context else None
        if not refocus_app and context:
            refocus_app = getattr(context, "last_application", None)
            if hasattr(refocus_app, "value"):
                refocus_app = refocus_app.value
        if refocus_app:
            steps.insert(0, PlanStep(step=1, tool="focus_app", args={"name": refocus_app}))
            for i, s in enumerate(steps, 1):
                s.step = i
        return Plan(
            steps=steps,
            explanation=f"Interacting with ordinal UI element '{t_q}' (rank {rank_val})."
        )

    return None
