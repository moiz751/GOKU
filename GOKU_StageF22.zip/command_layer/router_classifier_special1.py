from __future__ import annotations
import os
from pathlib import Path
import re
import sys
import time
from typing import Any, Optional, Union, List, Dict, Tuple
from dataclasses import dataclass, field

from brain.planner import (
    Plan,
    PlanStep,
    StructuredIntent,
    create_plan_from_decision,
    decompose_compound_command,
    parse_compound_request,
    resolve_step_variables,
    resolve_step_variables_with_guard,
    inject_plan_prerequisites,
    prune_plan_steps,
    build_hypothesis_investigation_plan,
    build_root_cause_investigation_plan,
    parse_conditional_goal,
    synthesize_adaptive_replan,
    decompose_into_milestones,
    restore_plan_from_checkpoint,
    build_cross_domain_plan,
    apply_cross_domain_transformation,
    build_long_horizon_exploration_plan,
    decompose_long_horizon_goal,
    compute_state_hash,
    detect_state_cycle,
    heuristic_node_score,
    expand_exploration_frontier,
    select_next_frontier_node,
    apply_reflective_history_pruning,
)
from command_layer.cognitive_reasoner import CognitiveReasoner
from command_layer.context import (
    EntityType,
    TypedEntity,
    ORDINAL_REFERENCES,
    SessionContext,
    resolve_references,
    session_context,
    update_context_from_result,
)
from command_layer.semantic_model import (
    SemanticDomain,
    SemanticAction,
    CommandIntent,
    AmbiguityType,
    ClarificationRequest,
    SymptomCategory,
    SituationType,
    ConfidenceTier,
    RiskTier,
    ConfidenceScore,
    ConfirmationRequest,
    FailureType,
    AdaptiveStrategy,
    PlanAdaptation,
    TaskLifecycleState,
    TaskMilestone,
    TaskCheckpoint,
    DomainBridgeType,
    DomainBridgeLink,
    CrossDomainWorkflow,
    HorizonDepth,
    ExplorationNode,
    SearchFrontier,
    LongHorizonReport,
    HistoryQueryType,
    ExecutionTraceRecord,
    TraceSummary,
)
from command_layer.semantic_parser import (
    parse_semantic_intent,
    create_plan_from_intent,
    resolve_in_turn_correction,
    strip_conversational_noise,
    split_compound_clauses,
    detect_symptom_category,
)
from command_layer.firewall import validate_tool_against_firewall, pre_execution_semantic_check, validate_long_horizon_action
from command_layer.state_machine import agent_state
from command_layer.validator import validate_and_sanitize_tool_arguments
from command_layer.lexer import UniversalLexer
from brain.runtime_bus import RuntimePipingBus
from security.state import confirmation_manager
from tools.utils.app_resolver import (
    APP_ALIASES,
    get_canonical_app_name,
    resolve_app,
)
from tools.utils.target_resolver import TargetType, resolve_universal_target, disambiguate_multi_candidates
from command_layer.router_base import (
    Step,
    run_tool_call,
    resolve_system_canonical_path,
    verify_post_recovery,
    verify_semantic_outcome,
    capture_environment_snapshot,
    capture_step_observation,
    detect_environment_drift,
    _entity_val,
    get_all_schemas,
    KNOWN_SITE_KEYS,
    KNOWN_APP_NAMES,
    _has_file_extension,
    _normalize_resolved_path,
    _is_conversational_folder_path,
)
from security.safety_firewall import is_safe_readonly_operation
from security.confirm import RISKY_TOOLS
from command_layer.decomposer import count_action_verbs
from brain.workflow_orchestrator import orchestrate_compound_workflow
from tools.browser import sanitize_search_query
from tools.search import parse_search_grammar
import executor.verifier
import executor.executor

from command_layer.router_sanitizer import (
    _isolate_browser_context,
    prune_negated_steps,
    sanitize_action_query,
    sanitize_url,
    _canonicalize_plan_tools,
    sanitize_ui_target,
    extract_clean_search_query,
)
from command_layer.router_cli_parser import (
    translate_cli_command,
    sanitize_cli_command,
    extract_pure_text_payload,
    parse_sequential_keyboard_actions,
    is_standalone_navigation_request,
    resolve_temporal_order,
    strip_idiomatic_conditions,
)
from command_layer.router_confidence import (
    determine_risk_tier,
    format_uncertainty_response,
    compute_command_confidence,
    synthesize_cross_domain_report,
    synthesize_long_horizon_report,
    get_conversational_response,
)

def _classify_and_parse_command(text: str, context: SessionContext | None = None, is_compound_root: bool = True) -> Plan | None:
    from command_layer.router_classifier_core import _classify_and_parse_command as _real_fn
    return _real_fn(text, context, is_compound_root)

def classify_special_intents_1(text: str, context: SessionContext | None = None, is_compound_root: bool = True) -> Plan | None:
    from command_layer.decomposer import count_action_verbs
    from brain.workflow_orchestrator import orchestrate_compound_workflow
    from tools.browser import sanitize_search_query
    from tools.search import parse_search_grammar
    from security.safety_firewall import is_safe_readonly_operation
    from security.confirm import RISKY_TOOLS
    cleaned = re.sub(r'[\x00-\x1f\x7f]+$', '', text).strip()
    cleaned = re.sub(r'[\x13\x03\x1b]', '', cleaned).strip()
    raw_lower = cleaned.lower()
    lower = text.lower()
    folder_ref_m = re.search(r"folder\s+'([^']+)'", text)
    file_ref_m = re.search(r"file\s+'([^']+)'", text)
    text_unwrapped = re.sub(r'[\'"]([^\'"]+)[\'"]', r'\1', text)
    try:
        symptom_cat, situation_type, symptom_entities = detect_symptom_category(raw_lower)
    except Exception:
        symptom_cat, situation_type, symptom_entities = SymptomCategory.NONE, SituationType.NORMAL, []
    _p2_is_compound_guard = False
    # Priority 0: Web Domain Navigation (Strictly standalone only)
    if is_standalone_navigation_request(cleaned):
        domain_match = re.search(r'(https?://[^\s\]\)]+|\b[a-zA-Z0-9-]+\.(?:com|pk|org|net|io|edu)(?:/[^\s\]\)]*)?\b)', cleaned, re.IGNORECASE)
        if domain_match and any(k in raw_lower for k in ['kholo', 'open', 'jao', 'browser', 'chrome']):
            url = sanitize_url(domain_match.group(1))
            steps = [
                PlanStep(step=1, tool='launch_app', args={'name': 'chrome'}),
                PlanStep(step=2, tool='open_url', args={'url': url, 'browser': 'chrome'})
            ]
            if context is not None:
                if hasattr(context, 'agent_opened_tabs'):
                    context.agent_opened_tabs += 1
                else:
                    context.agent_opened_tabs = 1
            if any(k in raw_lower for k in ['tab close', 'tab band', 'close kardo', 'band karo']):
                steps.append(PlanStep(step=3, tool='wait_for_visual_event', args={'event_type': 'settled', 'timeout': 6.0}))
                steps.append(PlanStep(step=4, tool='press_hotkey', args={'keys': 'ctrl+w'}))
            return Plan(steps=steps, explanation=f'Direct domain navigation to {url}.')


    # 0.00 In-Turn Self-Repair & Contrastive Replacement (Bullet #8)
    effective_text, correction_note, prohibited_targets = resolve_in_turn_correction(cleaned)
    if correction_note:
        cleaned = effective_text
        raw_lower = cleaned.lower()

    # 0.01 Hard Security & Anti-Adversarial Jailbreak Guard (Bullet #8 & Bullet #30)
    destructive_regexes = [
        r'\bformat\s+[c-z](?::|\b)',
        r'\bformat(?:ting)?\s+(?:the\s+)?(?:disk|drive|partition|hard\s+disk)\b',
        r'\bwip(?:e|ing)\s+(?:the\s+)?(?:disk|drive|partition|hard\s+disk|c:)\b',
        r'\bwipe\s+(?:disk|drive|partition|hard\s+disk)\b',
        r'\bdelete\s+(?:the\s+)?(?:disk|partition|drive|system32)\b',
        r'\bsystem32\b',
        r'\b(?:kill|terminate)\s+all\b',
        r'\bregistry\s+wipe\b',
        r'\bdelete\s+partition\b',
        # Bullet #30: Deceptive negations and deceptive imperatives
        r'\b(?:never\s+stop|don\'t\s+refrain|do\s+not\s+refrain|do\s+not\s+hesitate|don\'t\s+hesitate|never\s+avoid|i\s+forbid\s+you\s+from\s+not|do\s+not\s+fail)\b.*\b(?:format|formatting|wipe|wiping|terminate\s+all|terminating\s+all|kill\s+all|killing\s+all|delete|deleting)\b',
        r'\b(?:balki\s+zara\s+bhi\s+mat\s+socho|zara\s+bhi\s+mat\s+socho)\b.*\b(?:format|wipe|delete|khatam)\b',
        r'\b(?:delete|wipe|format|destroy)\s+(?:all\s+)?(?:windows\s+directory|system\s+files|c\s+drive|drive\s+c)\b',
        r'\b(?:purge|wipe)\s+partition\b',
    ]
    has_destructive_in_effective = any(re.search(pat, raw_lower) for pat in destructive_regexes)
    raw_has_destructive = any(re.search(pat, text.lower()) for pat in destructive_regexes)
    try:
        from security.safety_firewall import is_safe_readonly_operation
        is_safe_readonly_cmd = is_safe_readonly_operation("", {}, raw_lower) or is_safe_readonly_operation("", {}, text.lower())
    except Exception:
        is_safe_readonly_cmd = False
    is_safe_repair = bool(
        correction_note
        and any(safe in raw_lower for safe in ["space", "free space", "status", "check", "read", "list"])
        and not any(d in raw_lower for d in ["delete", "format", "wipe", "kill", "terminate", "remove"])
    )
    if (has_destructive_in_effective or (raw_has_destructive and not is_safe_repair)) and not is_safe_readonly_cmd:
        return Plan(is_direct_message=True, message_text="Blocked by safety layer: Destructive system actions, disk formatting, and system directory modifications are restricted for security and restricted for safety, and strictly prohibited.")


    # 0.02 Total Prohibition & Immediate Cancellation Interception (Bullet #8)
    if re.search(
        r'\b(?:kuch\s+mat\s+(?:karo|karna)|don\'t\s+do\s+anything|dont\s+do\s+anything|do\s+nothing|'
        r'bilkul\s+kuch\s+mat\s+(?:karo|karna)|chhor\s+do\s+sab|sab\s+chhor\s+do|'
        r'abhi\s+ruk\s+jao|ruk\s+jao\s+abhi|ruk\s+jao|cancel\s+that|cancel\s+the\s+operation|'
        r'cancel\s+it|operation\s+cancel\s+karo|rehne\s+do|rahne\s+do|chhor\s+do|chhoro|'
        r'abort|stop\s+it|cancel)\b',
        raw_lower
    ) and not any(w in raw_lower for w in ["open", "kholo", "launch", "run", "start", "find", "search", "list", "read", "button", "btn", "click", "slingshot", "kheecho", "kheencho", "drag", "bird"]):
        context.cancel_active_task("User requested cancellation or total prohibition")
        return Plan(is_direct_message=True, message_text="Operation cancelled as requested. No actions were performed.")

    # 0.023 Deterministic Sleep / Delay Step Parser (Objective 2)
    # Matches: "2 second ruko", "wait 2 seconds", "paanch second thehro", "sleep 5 seconds", "thehro 2 sec"
    _urdu_num_map = {
        "ek": 1, "aik": 1, "one": 1,
        "do": 2, "two": 2,
        "teen": 3, "tin": 3, "three": 3,
        "char": 4, "chaar": 4, "four": 4,
        "paanch": 5, "panch": 5, "five": 5,
        "chhe": 6, "che": 6, "six": 6,
        "saat": 7, "seven": 7,
        "aath": 8, "ath": 8, "eight": 8,
        "nau": 9, "no": 9, "nine": 9,
        "das": 10, "ten": 10,
    }
    delay_m = re.match(
        r'^(?:(?:please|zara|bhai)\s+)?(?:wait|delay|sleep|ruko|thehro|pause)\s+(\d+(?:\.\d+)?|[a-zA-Z]+)\s*(?:seconds?|secs?|sec|s|minutes?|mins?|min|m)?(?:\s+(?:ruko|thehro|wait|sleep|thehre|tak|karo))?$',
        raw_lower
    )
    if not delay_m:
        delay_m = re.match(
            r'^(?:(?:please|zara|bhai)\s+)?(\d+(?:\.\d+)?|[a-zA-Z]+)\s*(?:seconds?|secs?|sec|s|minutes?|mins?|min|m)\s+(?:ruko|thehro|thehre|wait|sleep|pause|delay)(?:\s+karo|\s+tak)?$',
            raw_lower
        )
    if not delay_m:
        delay_m = re.match(
            r'^(?:(?:please|zara|bhai)\s+)?(\d+(?:\.\d+)?|[a-zA-Z]+)\s*(?:seconds?|secs?|sec|s|minutes?|mins?|min|m)$',
            raw_lower
        )
    if not delay_m:
        delay_m = re.match(
            r'^(?:wait|sleep|delay)\s+(\d+(?:\.\d+)?)$',
            raw_lower
        )
    if delay_m:
        raw_val = delay_m.group(1).strip().lower()
        dur = 1.0
        if raw_val in _urdu_num_map:
            dur = float(_urdu_num_map[raw_val])
        else:
            try:
                dur = float(raw_val)
            except ValueError:
                dur = 1.0
        if any(w in raw_lower for w in ["minute", "min", "minutes", "mins"]):
            dur *= 60.0
        dur = max(0.1, min(dur, 300.0))
        return Plan(
            steps=[PlanStep(step=1, tool="wait_delay", args={"seconds": dur})],
            explanation=f"Waiting for {dur} seconds as requested."
        )

    # Headless Non-Blocking Shell Execution:
    # Matches: "cmd kholo, usme hostname chalao", "cmd mein hostname chalao", "powershell kholo, usme hostname chalao", "cmd kholo aur dir chalao"
    cli_exec_m = re.search(
        r'\b(?P<shell>cmd|command\s+prompt|powershell|pwsh|terminal)\b'
        r'(?:[^\w\n]*(?:kholo|khol\s*(?:kar|ke)?|open|launch|start|run|banao|chalao))?'
        r'[^\w\n]*(?:aur|and|phir|then|usme|usmein|mein|me|main|in)?\s*'
        r'(?P<cmd>[a-zA-Z0-9_\-\.\s/\\:\*\?]+?)'
        r'(?:\s+(?:chalao|run\s*(?:karo|kar\s*do)?|execute\s*(?:karo|kar\s*do)?)|$)',
        raw_lower
    )
    if cli_exec_m and not any(w in raw_lower for w in ["mile", "aaye", "milay", "output ko notepad"]) and not re.search(r'\b(?:mat\s+chalana|mat\s+chalao|don\'t\s+run|do\s+not\s+run|par\s+mat\s+chalana|par\s+mat)\b', raw_lower):
        sh_type = "powershell" if ("powershell" in cli_exec_m.group("shell").lower() or "pwsh" in cli_exec_m.group("shell").lower()) else "cmd"
        extracted_cmd = sanitize_cli_command(cli_exec_m.group("cmd"))
        extracted_cmd = re.sub(r'^(?:aur|and|phir|then|usme|usmein|mein|me|main|in|kholo|khol|open|start|launch|run|execute|please|chalao|[,\s])+', '', extracted_cmd, flags=re.IGNORECASE).strip()
        extracted_cmd = re.sub(r'\s+(?:chalao|run\s*(?:karo|kar\s*do)?|execute\s*(?:karo|kar\s*do)?)$', '', extracted_cmd, flags=re.IGNORECASE).strip()
        if not extracted_cmd or extracted_cmd in ("kholo", "open", "launch", "chalao"):
            extracted_cmd = "dir" if sh_type == "cmd" else "ls"
        return Plan(
            steps=[PlanStep(step=1, tool="execute_system_command", args={"command": extracted_cmd, "shell": sh_type})],
            explanation=f"Executing headless system command: '{extracted_cmd}' via {sh_type}."
        )

    # Standalone shell invocation (e.g. "cmd kholo", "powershell kholo") -> headless execute
    if re.search(r'^(?:(?:open|launch|start|kholo)\s+)?(?:cmd|command\s+prompt|powershell|pwsh|terminal)(?:\s+(?:kholo|open|launch|start|chalao))?$', raw_lower.strip()):
        sh_type = "powershell" if any(k in raw_lower for k in ["powershell", "pwsh"]) else "cmd"
        default_cmd = "dir" if sh_type == "cmd" else "ls"
        return Plan(
            steps=[PlanStep(step=1, tool="execute_system_command", args={"command": default_cmd, "shell": sh_type})],
            explanation=f"Headless CLI execution: running in {sh_type} without opening interactive terminal window."
        )

    # 0.0234 Autonomous Visual Re-Act Engine Router vs Downloaded App Search
    if "downloaded" in raw_lower and "angry bird" in raw_lower:
        return Plan(
            steps=[
                PlanStep(step=1, tool="find_file", args={"name": "Angry Bird", "start_folder": "Downloads"})
            ],
            explanation="Search local paths for downloaded Angry Bird executable without web redirect."
        )

    # Matches: "angry bird khelo", "play angry birds", "daily mission karke dikhao", "game shoot karo", "angry bird khelo aur game jeeto", etc.
    if re.search(
        r'\b(?:(?:play\s+)?angry\s+birds?|daily\s+mission|game\s+(?:shoot|jeeto|khelo|play)|target\s+par\s+shoot|puzzle|slingshot\s+(?:se\s+)?shoot|slingshot\s+strike)\b',
        raw_lower
    ) and not any(k in raw_lower for k in ['downloaded', 'find', 'search', 'dhoondo']):
        return Plan(
            steps=[
                PlanStep(step=1, tool="run_autonomous_agent", args={"task_type": "game", "query": cleaned})
            ],
            explanation="Autonomous closed-loop visual Re-Act engine engaged for continuous gameplay and reinforcement."
        )

    # 0.02344 Strict URL vs Search Bar Intent & Web Navigation Router
    # Matches: "browser mein fast.com kholo, page load hone tak ruko aur phir search bar par click karo",
    #          "fast.com kholo", "chrome mein reddit.com kholo", etc.
    web_domain_m = re.search(
        r'\b(?:https?://)?(?:www\.)?([a-zA-Z0-9\-]+\.(?:com|org|net|pk|edu|gov|io|co|in|ai|app|dev))\b',
        raw_lower
    )
    # A domain that is the TARGET OF A DIAGNOSTIC (ping/latency/traceroute/nslookup) is not a navigation request: leave it to the network classifiers.
    _net_diag = re.search(r'\b(?:ping|latency|tracert|traceroute|nslookup|dns\s+lookup|whois|packet\s+loss|reachab\w*)\b', raw_lower)
    if web_domain_m and not _net_diag and not any(w in raw_lower for w in ["mile", "aaye", "milay", "output ko notepad", "tab", "shortcut", "ctrl+", "alt+", "wapis", "switch", "naya tab"]) and len(re.findall(r'\b[a-zA-Z0-9\-]+\.(?:com|org|net|pk|edu|gov|io|co|in|ai|app|dev)\b', raw_lower)) <= 1:
        raw_domain = web_domain_m.group(1).lower()
        clean_url = sanitize_url(raw_domain) or f"https://{raw_domain}"
        b_target = "edge" if any(b in raw_lower for b in ["edge", "msedge"]) else "chrome"

        nav_steps: list[PlanStep] = []
        if any(w in raw_lower for w in ["browser", "chrome", "edge", "firefox", "brave"]):
            nav_steps.append(PlanStep(step=1, tool="launch_app", args={"name": b_target}))

        nav_steps.append(PlanStep(step=len(nav_steps) + 1, tool="open_url", args={"url": clean_url, "browser": b_target}))

        # Check for page load wait
        if re.search(r'\b(?:page\s+load|wait\s+(?:for|until)\s+page|load\s+hone\s+tak\s+ruko|loading\s+(?:khatam|complete))\b', raw_lower):
            nav_steps.append(PlanStep(step=len(nav_steps) + 1, tool="wait_for_visual_event", args={"event_type": "settled"}))

        # Check for search bar interaction
        if re.search(r'\b(?:search\s+bar|search\s+box|search\s+input|address\s+bar)\b', raw_lower):
            target_el = "address bar" if "address" in raw_lower else "search bar"
            is_click = any(w in raw_lower for w in ["click", "tap", "locate", "select"])
            if is_click or not any(w in raw_lower for w in ["likho", "type", "enter"]):
                nav_steps.append(PlanStep(step=len(nav_steps) + 1, tool="find_and_interact", args={"target_query": target_el, "action": "click"}))

        # Check for entity query to search or type
        has_typing = any(w in raw_lower for w in ["search karo", "search kar do", "type karo", "likho", "enter"])
        if has_typing:
            clean_q = extract_clean_search_query(text)
            if clean_q and clean_q.lower() not in (raw_domain, "search", "bar"):
                nav_steps.append(PlanStep(step=len(nav_steps) + 1, tool="type_text", args={"text": clean_q, "press_enter": True}))

        # Check for product / item click
        if any(w in raw_lower for w in ["pehli product", "first product", "first item", "result_item"]):
            nav_steps.append(PlanStep(step=len(nav_steps) + 1, tool="find_and_interact", args={"target_query": "result_item_1", "action": "click", "rank": 1}))

        if len(nav_steps) >= 2 or not any(sep in raw_lower for sep in [",", " aur ", " and ", " phir "]):
            for idx, s in enumerate(nav_steps, 1):
                s.step = idx
            return Plan(
                steps=nav_steps,
                explanation=f"Direct URL navigation to '{clean_url}' in {b_target} with clean element interaction sequence."
            )

    # 0.02345 Event-Driven Page Load & First Item Interaction Router
    # Matches: "page load hone tak ruko aur phir pehli product par click karo"
    if re.search(
        r'\b(?:page\s+load\s+hone\s+tak\s+ruko|wait\s+(?:until|for)\s+page\s+load(?:ed)?)\b',
        raw_lower
    ):
        target_q = "result_item_1"
        if any(k in raw_lower for k in ["product", "item", "video", "result"]):
            target_q = "result_item_1"
        return Plan(
            steps=[
                PlanStep(step=1, tool="wait_for_visual_event", args={"event_type": "settled"}),
                PlanStep(step=2, tool="find_and_interact", args={"target_query": target_q, "action": "click", "rank": 1}),
            ],
            explanation="Waiting for real-time visual stability (page load completion) and clicking the primary target item."
        )

    # 0.0235 High-Precision Observation & Visual Stability Router
    # Matches: "speed complete hone tak ruko", "loading khatam hone tak ruko", "wait for visual stability", "jab tak speed complete na ho ruko"
    if re.search(
        r'\b(?:(?:speed|test|loading|animation|download|process|benchmark)\s+(?:complete|khatam|finish|settle|khatm)\s+(?:hone|ho\s+jane)?\s+tak\s+(?:ruko|wait\s+karo|thehro|pause)|'
        r'wait\s+(?:for\s+)?(?:visual\s+)?stability|wait\s+until\s+settled|'
        r'jab\s+tak\s+(?:speed|test|loading)\s+(?:complete|khatam)\s+(?:na\s+ho|ho\s+jaye)\s+(?:ruko|wait\s+karo))\b',
        raw_lower
    ):
        return Plan(
            steps=[PlanStep(step=1, tool="wait_for_visual_stability", args={"max_timeout": 8.0, "min_stable_sec": 0.4})],
            explanation="Observing continuous frame difference until visual state settles."
        )

    # 0.0236 Adaptive Scroll Until Condition Router
    # Matches: "jab tak dikhe scroll karo", "scroll until <condition>", "jab tak <X> nazar na aaye scroll karo"
    scroll_until_m = re.search(
        r'\b(?:scroll\s+until\s+(?P<cond1>.+?)|jab\s+tak\s+(?P<cond2>.+?)\s+(?:dikhe|nazar\s+aaye|mil\s+jaye|dikh\s+na\s+jaye|aaye)\s+scroll\s+karo|jab\s+tak\s+dikhe\s+scroll\s+karo)\b',
        raw_lower
    )
    if scroll_until_m:
        cond = (scroll_until_m.group("cond1") or scroll_until_m.group("cond2") or "").strip()
        if not cond or cond in ("dikhe", "nazar aaye"):
            cond = "target element"
        return Plan(
            steps=[PlanStep(step=1, tool="observe_and_scroll_until", args={"condition": cond, "max_scrolls": 10, "direction": "down"})],
            explanation=f"Scrolling viewport adaptively until '{cond}' appears."
        )

    # 0.0237 2D Canvas & Game Gesture Router
    # Matches: "slingshot kheecho aur chhoro", "bird launch karo", "slingshot drag karo", "angry bird launch karo"
    if re.search(
        r'\b(?:slingshot\s+(?:kheecho|kheencho|drag\s+karo|pull\s+karo|kheench\s+kar)\s*(?:aur\s+chhoro|chhor\s+do|release\s+karo)?|'
        r'(?:angry\s+)?bird\s+launch\s+karo|game\s+drag\s+and\s+release)\b',
        raw_lower
    ):
        return Plan(
            steps=[PlanStep(step=1, tool="game_drag_and_release", args={"drag_offset": [100, 50], "hold_duration": 0.2})],
            explanation="Dispatching real-time physics drag-and-release gesture for 2D game interaction."
        )

    # 0.024 Natural Language Telemetry Extraction Pipeline (Objective 1)
    # Matches: "<console> mein <cli_command> chalao aur jo <metric> mile usko <app> mein type/save karo"
    if "mile" in raw_lower or "aaye" in raw_lower or "milay" in raw_lower:
        telem_m = re.search(
            r'(?:(?:in\s+)?(?P<console>cmd|command\s+prompt|terminal|powershell|console)\s+(?:mein|me|main|in)\s+)?'
            r'(?P<cli>[a-zA-Z0-9_\-\.\s/\\:]+?)\s*(?:chalao|run\s*(?:karo|kar\s*do)?|execute\s*(?:karo|kar\s*do)?)\s+'
            r'(?:aur|and|phir|then)\s+(?:jo|the)\s+(?P<metric>.+?)\s+(?:mile|aaye|output|result|milay)\s*'
            r'(?:usko|use|isko|ise|it)?\s*'
            r'(?:(?P<app>[a-zA-Z0-9_\-]+)\s*(?:mein|me|main|in))?\s*'
            r'(?:type|likho|paste|write)?'
            r'(?:.*?(?:save|mehfooz)\s*(?:karke|kar\s*ke|karo|to)?\s*(?P<filepath>[a-zA-Z]:[^\s"\'<>|?*]+|[^\s"\'<>|?*]+\.[a-zA-Z0-9]+))?',
            cleaned,
            re.IGNORECASE
        )
        if telem_m:
            cli_raw = (telem_m.group("cli") or "").strip()
            cli_raw = re.sub(r'^(?:cmd|terminal|powershell|console)\s+(?:mein|me|main|in)\s+', '', cli_raw, flags=re.IGNORECASE).strip()
            
            m_raw = (telem_m.group("metric") or "").strip().lower()
            if "ipv4" in m_raw or "ip address" in m_raw or "local ip" in m_raw or m_raw == "ip":
                metric_name = "ipv4_address"
                metric_var = "$ipv4"
                keyboard_text = "IPv4 Address: $ipv4"
            elif "gateway" in m_raw:
                metric_name = "default_gateway"
                metric_var = "$gateway"
                keyboard_text = "Default Gateway: $gateway"
            elif "latency" in m_raw or "ping" in m_raw:
                metric_name = "avg_latency_ms"
                metric_var = "$latency"
                keyboard_text = "Latency: $latency"
            elif "loss" in m_raw or "packet" in m_raw:
                metric_name = "packet_loss_pct"
                metric_var = "$packet_loss"
                keyboard_text = "Packet Loss: $packet_loss"
            elif "connection" in m_raw:
                metric_name = "active_connections_count"
                metric_var = "$active_connections"
                keyboard_text = "Active Connections: $active_connections"
            else:
                metric_name = re.sub(r'\s+', '_', m_raw)
                metric_var = f"${metric_name}"
                clean_label = (telem_m.group("metric") or "").strip().title()
                keyboard_text = f"{clean_label}: ${metric_name}"
            
            app_raw = (telem_m.group("app") or "").strip()
            target_app = app_raw.capitalize() if app_raw else "Notepad"
            
            save_path = telem_m.group("filepath")
            if not save_path:
                path_m = re.search(r'([a-zA-Z]:\\[^\s"\'>]+|[a-zA-Z]:/[^\s"\'>]+|["\']([a-zA-Z]:[^\'"]+)["\'])', cleaned)
                if path_m:
                    save_path = path_m.group(1) or path_m.group(2)
            
            p_steps = [
                PlanStep(step=1, tool="run_cli", args={"command": cli_raw}),
                PlanStep(step=2, tool="launch_app", args={"name": target_app}),
                PlanStep(step=3, tool="send_keyboard_input", args={"text": keyboard_text, "press_enter": False, "app_name": target_app}),
            ]
            if save_path:
                norm_fp = _normalize_resolved_path(save_path.strip(" ,;.-'\""))
                p_steps.append(PlanStep(step=4, tool="save_active_document", args={"filepath": norm_fp, "app_name": target_app}))
            
            return Plan(
                steps=p_steps,
                explanation=f"Executed CLI '{cli_raw}', extracted metric '{metric_name}', typed into '{target_app}'" + (f" and saved to '{save_path}'." if save_path else ".")
            )


    return None
