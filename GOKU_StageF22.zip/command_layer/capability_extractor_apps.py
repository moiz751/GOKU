from __future__ import annotations
import os
import re
import sys
from typing import Any, Optional, Dict, List, Set, Tuple

from command_layer.semantic_model import (
    SemanticDomain,
    SemanticAction,
    RequestType,
    EntityType,
    CommandIntent,
    AmbiguityType,
    ClarificationRequest,
    SymptomCategory,
    SituationType,
    ConfidenceTier,
    RiskTier,
    ConfidenceScore,
    ConfirmationRequest,
    FailureType,
    AdaptiveStrategy,
    PlanAdaptation,
    TaskLifecycleState,
    TaskMilestone,
    TaskCheckpoint,
    DomainBridgeType,
    DomainBridgeLink,
    CrossDomainWorkflow,
    HorizonDepth,
    ExplorationNode,
    SearchFrontier,
    LongHorizonReport,
    HistoryQueryType,
    ExecutionTraceRecord,
    TraceSummary,
)
from brain.planner import Plan, PlanStep

def _extract_app_and_ui_capabilities(text: str, lower: str, quoted_strings: list[str]) -> Optional[CommandIntent]:
    # 21.5 USB Hardware Devices
    if any(w in lower for w in ["usb devices", "connected usb", "usb hardware"]):
        return CommandIntent(
            domain=SemanticDomain.DEVICES,
            action=SemanticAction.INSPECT,
            target="usb_devices",
            request_type=RequestType.QUERY,
            entity_type=EntityType.DEVICE,
            selected_tool="get_usb_devices",
            tool_args={},
            raw_clause=text
        )

    # 22. Mobile Hotspot
    if any(w in lower for w in ["hotspot", "mobile hotspot"]):
        return CommandIntent(
            domain=SemanticDomain.NETWORK,
            action=SemanticAction.INSPECT,
            target="hotspot",
            request_type=RequestType.QUERY,
            entity_type=EntityType.NETWORK_CONNECTION,
            selected_tool="get_hotspot_status",
            tool_args={},
            raw_clause=text
        )

    # 23. Active Window & Title
    if any(w in lower for w in ["active window", "focused window", "window title", "kahan focus hai", "foreground app", "focused application", "what window"]):
        return CommandIntent(
            domain=SemanticDomain.GUI,
            action=SemanticAction.INSPECT,
            target="active_window",
            request_type=RequestType.QUERY,
            entity_type=EntityType.UI_ELEMENT,
            selected_tool="get_active_window",
            tool_args={},
            raw_clause=text
        )

    # 24. Screenshot / Screen Capture
    if any(lower.startswith(w) or lower == w for w in ["take a screenshot", "screen capture", "capture screen", "capture the screen"]):
        return CommandIntent(
            domain=SemanticDomain.GUI,
            action=SemanticAction.INSPECT,
            target="screen",
            request_type=RequestType.ACTION,
            entity_type=EntityType.UI_ELEMENT,
            selected_tool="capture_screen",
            tool_args={},
            raw_clause=text
        )

    if any(w in lower for w in ["screenshot", "screen capture", "screen ki photo", "tasveer lo", "snapshot kheecho", "screen ka snapshot"]):
        return CommandIntent(
            domain=SemanticDomain.GUI,
            action=SemanticAction.INSPECT,
            target="screenshot",
            request_type=RequestType.ACTION,
            entity_type=EntityType.UI_ELEMENT,
            selected_tool="take_screenshot",
            tool_args={},
            raw_clause=text
        )

    # 24.5 Set Clipboard Text
    clip_m = re.search(r'\bcopy\s+(?:text\s+)?(.+?)\s+to\s+clipboard\b', lower)
    if clip_m:
        txt = clip_m.group(1).strip()
        return CommandIntent(
            domain=SemanticDomain.GUI,
            action=SemanticAction.COPY,
            target=txt,
            request_type=RequestType.ACTION,
            entity_type=EntityType.UI_ELEMENT,
            selected_tool="set_clipboard_text",
            tool_args={"text": txt},
            raw_clause=text
        )

    # 24.6 Clear Clipboard
    if any(w in lower for w in ["clear clipboard", "empty clipboard", "clipboard saaf"]):
        return CommandIntent(
            domain=SemanticDomain.GUI,
            action=SemanticAction.DELETE,
            target="clipboard",
            request_type=RequestType.ACTION,
            entity_type=EntityType.UI_ELEMENT,
            selected_tool="clear_clipboard",
            tool_args={},
            raw_clause=text
        )

    # 24.7 Mouse Cursor Position
    if any(w in lower for w in ["where is the mouse", "mouse position", "cursor position", "mouse cursor located"]):
        return CommandIntent(
            domain=SemanticDomain.GUI,
            action=SemanticAction.INSPECT,
            target="cursor",
            request_type=RequestType.QUERY,
            entity_type=EntityType.UI_ELEMENT,
            selected_tool="get_cursor_position",
            tool_args={},
            raw_clause=text
        )

    # 24.8 Move Mouse to Center
    if any(w in lower for w in ["move mouse to center", "mouse to center"]):
        return CommandIntent(
            domain=SemanticDomain.GUI,
            action=SemanticAction.MOVE_MOUSE,
            target="center",
            request_type=RequestType.ACTION,
            entity_type=EntityType.UI_ELEMENT,
            selected_tool="move_mouse",
            tool_args={"x": 683, "y": 384},
            raw_clause=text
        )

    # 24.9 Mouse Scroll
    if any(w in lower for w in ["scroll mouse", "mouse wheel", "scroll down", "scroll up"]):
        clicks = 3
        cm = re.search(r'(\d+)\s+clicks?', lower)
        if cm:
            clicks = int(cm.group(1))
        direction = "down" if "down" in lower else "up"
        return CommandIntent(
            domain=SemanticDomain.GUI,
            action=SemanticAction.SCROLL,
            target="scroll",
            request_type=RequestType.ACTION,
            entity_type=EntityType.UI_ELEMENT,
            selected_tool="mouse_scroll",
            tool_args={"clicks": clicks if direction == "up" else -clicks},
            raw_clause=text
        )

    # 24.10 Mouse Pattern
    if any(w in lower for w in ["mouse pattern", "left to right pattern"]):
        return CommandIntent(
            domain=SemanticDomain.GUI,
            action=SemanticAction.MOVE_MOUSE,
            target="pattern",
            request_type=RequestType.ACTION,
            entity_type=EntityType.UI_ELEMENT,
            selected_tool="move_mouse_pattern",
            tool_args={"pattern": "left_right"},
            raw_clause=text
        )

    # 25. Clipboard Setting, Negation & Inspection
    if "clipboard" in lower or any(w in lower for w in ["kuch naya copy mat", "naya copy mat", "copy mat karna"]):
        # Check explicit copy negation / confirmation
        if any(w in lower for w in ["kuch naya copy mat", "mat copy", "don't copy", "dont copy", "copy mat karna"]):
            return CommandIntent(
                domain=SemanticDomain.GUI,
                action=SemanticAction.INSPECT,
                target="clipboard",
                request_type=RequestType.QUERY,
                entity_type=EntityType.UI_ELEMENT,
                selected_tool="get_clipboard_text",
                tool_args={},
                raw_clause=text
            )
        # Check clipboard clear
        if any(w in lower for w in ["clear", "saaf", "empty"]):
            return CommandIntent(
                domain=SemanticDomain.GUI,
                action=SemanticAction.COPY,
                target="clipboard",
                request_type=RequestType.ACTION,
                entity_type=EntityType.UI_ELEMENT,
                selected_tool="clear_clipboard",
                tool_args={},
                raw_clause=text
            )
        # Check clipboard write / copy text
        if any(w in lower for w in ["copy", "rakho", "set", "write", "to clipboard"]) and not any(w in lower for w in ["kya copy", "kya hai", "read", "content", "batao"]):
            text_match = re.search(r"['\"]([^'\"]+)['\"]", text)
            to_copy = text_match.group(1) if text_match else ""
            if not to_copy:
                to_copy = re.sub(r"(?i)\b(clipboard\s+(mein|par|pe)?\s*(text)?\s*copy\s*karo|copy\s+to\s+clipboard|copy)\b", "", text).strip().strip("'\"")
            return CommandIntent(
                domain=SemanticDomain.GUI,
                action=SemanticAction.COPY,
                target="clipboard",
                request_type=RequestType.ACTION,
                entity_type=EntityType.UI_ELEMENT,
                selected_tool="set_clipboard_text",
                tool_args={"text": to_copy or "Extreme Audit GOKU 2026"},
                raw_clause=text
            )
        # Default: read clipboard content
        return CommandIntent(
            domain=SemanticDomain.GUI,
            action=SemanticAction.INSPECT,
            target="clipboard",
            request_type=RequestType.QUERY,
            entity_type=EntityType.UI_ELEMENT,
            selected_tool="get_clipboard_text",
            tool_args={},
            raw_clause=text
        )

    # 25.5 Whole-system diagnostic snapshot / synthesis
    if any(w in lower for w in ["system health ka snapshot", "system snapshot for troubleshooting", "synthesizing total system status snapshot", "conclude audit by synthesizing", "cross-subsystem health check", "overall computer diagnostic"]):
        return CommandIntent(
            domain=SemanticDomain.DIAGNOSTICS,
            action=SemanticAction.DIAGNOSE,
            target="system_health",
            request_type=RequestType.DIAGNOSTIC,
            entity_type=EntityType.PROCESS,
            selected_tool="diagnose_system",
            tool_args={},
            raw_clause=text
        )

    # 26. Performance Diagnostics (fans, heavy, lag)
    if (
        any(w in lower for w in ["heavy chal", "fans", "lag kar raha", "computer slow kyun", "pc slow kyun", "system lag", "problem diagnose", "pc slow", "computer slow", "unresponsive"])
        or (any(w in lower for w in ["system", "computer", "machine", "pc"]) and any(w in lower for w in ["slow", "burdened", "lagging", "unresponsive"]))
    ):
        return CommandIntent(
            domain=SemanticDomain.DIAGNOSTICS,
            action=SemanticAction.DIAGNOSE,
            target="performance",
            request_type=RequestType.DIAGNOSTIC,
            entity_type=EntityType.PROCESS,
            selected_tool="diagnose_performance",
            tool_args={},
            raw_clause=text
        )

    # 26.7 Ultra-Deep Hardware/Service Wi-Fi Stack Diagnoser & Auto-Healer
    if (
        any(p in lower for p in [
            "auto fix wifi stack", "remediate and repair wifi connection",
            "fix wifi stack", "repair wifi stack", "remediate wifi stack", "auto repair wifi"
        ])
        or (
            ("remediate" in lower or "auto fix" in lower)
            and ("wifi" in lower or "wi-fi" in lower)
        )
    ):
        return CommandIntent(
            domain=SemanticDomain.SYSTEM,
            action=SemanticAction.REPAIR,
            target="wifi_stack",
            request_type=RequestType.ACTION,
            entity_type=EntityType.NETWORK_CONNECTION,
            selected_tool="remediate_wifi_stack",
            tool_args={},
            raw_clause=text
        )

    if (
        any(p in lower for p in [
            "why is wifi not showing", "deep audit wifi hardware and services",
            "check wifi driver error and wlan service", "wifi not showing",
            "audit wifi hardware", "check wifi driver error", "check wlan service"
        ])
        or (
            ("wifi" in lower or "wi-fi" in lower)
            and any(w in lower for w in ["not showing", "driver error", "wlan service", "hardware and services"])
        )
    ):
        return CommandIntent(
            domain=SemanticDomain.SYSTEM,
            action=SemanticAction.INSPECT,
            target="wifi_hardware_service",
            request_type=RequestType.DIAGNOSTIC,
            entity_type=EntityType.NETWORK_CONNECTION,
            selected_tool="audit_wifi_hardware_and_services",
            tool_args={},
            raw_clause=text
        )

    # 26.8 Deep Wi-Fi Spectrum Scanner & Latency Engine
    if (
        any(p in lower for p in [
            "deep scan wifi", "scan wifi spectrum", "check wifi signal interference",
            "full network latency scan", "fix and scan wifi adapter", "wifi spectrum",
            "signal interference", "latency scan", "jitter scan", "spectrum scan"
        ])
        or (
            "wifi" in lower
            and any(w in lower for w in ["spectrum", "interference", "deep scan", "latency scan", "jitter"])
        )
    ):
        return CommandIntent(
            domain=SemanticDomain.SYSTEM,
            action=SemanticAction.INSPECT,
            target="wifi_spectrum",
            request_type=RequestType.DIAGNOSTIC,
            entity_type=EntityType.NETWORK_CONNECTION,
            selected_tool="deep_scan_wifi_spectrum",
            tool_args={},
            raw_clause=text
        )

    # 26.9 Deep Network & Wi-Fi Hybrid Diagnostic Engine
    if (
        any(p in lower for p in [
            "diagnose wifi", "check network problem", "wifi problem analysis",
            "network scan karo", "find wifi problem", "wifi problem", "diagnose network health",
            "wifi diagnostic", "network health", "network scan", "check wifi problem"
        ])
        or (
            any(w in lower for w in ["wifi", "network"])
            and any(w in lower for w in ["problem analysis", "find wifi problem", "wifi problem", "scan karo", "diagnose wifi"])
        )
    ):
        return CommandIntent(
            domain=SemanticDomain.SYSTEM,
            action=SemanticAction.INSPECT,
            target="network_health",
            request_type=RequestType.DIAGNOSTIC,
            entity_type=EntityType.NETWORK_CONNECTION,
            selected_tool="diagnose_network_health",
            tool_args={},
            raw_clause=text
        )

    # 27. General Network Issues
    if (
        any(w in lower for w in ["net ajeeb", "internet issue", "network issue", "pages slow", "slow khul rahe", "masla internet", "connection ka scene"])
        or (any(w in lower for w in ["net", "internet", "wifi"]) and any(w in lower for w in ["slow", "delay", "problem", "masla", "issue", "diagnose"]))
    ):
        return CommandIntent(
            domain=SemanticDomain.DIAGNOSTICS,
            action=SemanticAction.DIAGNOSE,
            target="network",
            request_type=RequestType.DIAGNOSTIC,
            entity_type=EntityType.NETWORK_CONNECTION,
            selected_tool="diagnose_network",
            tool_args={},
            raw_clause=text
        )

    # 28. Filesystem Folders List
    if any(d in lower for d in ["music", "videos", "pictures", "downloads", "desktop", "documents"]) and any(w in lower for w in ["contents list", "items dekho", "items list", "folder inspect", "directory ke contents", "contents", "items"]):
        folder = "Downloads"
        for d in ["Music", "Videos", "Pictures", "Downloads", "Desktop", "Documents"]:
            if d.lower() in lower:
                folder = d
                break
        return CommandIntent(
            domain=SemanticDomain.FILESYSTEM,
            action=SemanticAction.INSPECT,
            target=folder,
            request_type=RequestType.QUERY,
            entity_type=EntityType.FOLDER,
            selected_tool="list_folder",
            tool_args={"path": folder.lower()},
            raw_clause=text
        )

    # 29. Network Router / Gateway Device Inspection (Goal vs Entity Protection)
    if ("router" in lower or "gateway" in lower) and any(w in lower for w in ["wifi", "wi-fi", "wireless", "network", "open", "kholo", "check", "batao", "status", "info", "ip"]):
        return CommandIntent(
            domain=SemanticDomain.NETWORK,
            action=SemanticAction.INSPECT,
            target="router",
            request_type=RequestType.QUERY,
            entity_type=EntityType.NETWORK_CONNECTION,
            selected_tool="get_default_gateway",
            tool_args={},
            expected_outcome="Inspected default network gateway and router IP address.",
            raw_clause=text
        )

    # 30. Holistic System Performance & Health Inquiries (Item C, D, E)
    # Matches: "PC running kaisi ja rahi hai", "computer kaisa chal raha hai", "mere PC ki health batao", "system lag kar raha hai", "machine sluggish chal rahi hai"
    if (any(p in lower for p in ["pc", "computer", "system", "machine"]) and any(w in lower for w in ["running kaisi", "kaisi chal", "kaisa chal", "health", "sluggish", "lag kar", "heavy feel", "fans full speed", "masla kya hai"])) or \
       (any(w in lower for w in ["system lag", "pc lag", "machine sluggish", "computer heavy", "heavy feel", "fans full speed", "sluggish chal rahi"])):
        return CommandIntent(
            domain=SemanticDomain.DIAGNOSTICS,
            action=SemanticAction.DIAGNOSE,
            target="system_health",
            request_type=RequestType.DIAGNOSTIC,
            entity_type=EntityType.PROCESS,
            selected_tool="diagnose_system",
            tool_args={},
            expected_outcome="Conducted holistic cross-system health and performance diagnosis.",
            raw_clause=text
        )

    # 31. Storage Condition & Drive Health Diagnostics (Item F, G)
    # Matches: "mera storage check karo", "drive ki health check kar", "storage status check karo", "disk condition check"
    if any(s in lower for s in ["storage", "mera storage", "drive health", "drive ki health", "disk health", "storage health"]) and any(w in lower for w in ["check", "status", "haal", "condition", "batao", "dekh"]):
        return CommandIntent(
            domain=SemanticDomain.DIAGNOSTICS,
            action=SemanticAction.DIAGNOSE,
            target="storage",
            request_type=RequestType.DIAGNOSTIC,
            entity_type=EntityType.FOLDER,
            selected_tool="diagnose_storage",
            tool_args={},
            expected_outcome="Diagnosed storage health and partition capacity.",
            raw_clause=text
        )

    # 32. Generalized Application Lifecycle, Running State & Diagnostics (Item B, C, D, F, H, I, K, L)
    APP_LOOKUP = {
        "google chrome": "Chrome",
        "chrome": "Chrome",
        "browser": "Chrome",
        "msedge": "Edge",
        "edge": "Edge",
        "firefox": "Firefox",
        "notepad": "Notepad",
        "calculator": "Calculator",
        "calc": "Calculator",
        "vscode": "VS Code",
        "vs code": "VS Code",
        "code": "VS Code",
        "word": "Word",
        "excel": "Excel",
        "powerpoint": "PowerPoint",
        "paint": "Paint",
        "cmd": "Command Prompt",
        "powershell": "PowerShell",
        "microsoft store": "Microsoft Store",
        "windows store": "Microsoft Store",
        "settings": "Settings",
    }

    detected_app = None
    for k_app, v_app in sorted(APP_LOOKUP.items(), key=lambda x: len(x[0]), reverse=True):
        if re.search(rf'\b{re.escape(k_app)}\b', lower):
            detected_app = v_app
            break

    imperative_text = text
    imp_m = re.search(r'(?:mujhe\s+bas\s+)?(?:ye\s+)?(?:check\s+karke|pata\s+karke|dekh\s+ke)?\s*(?:batao|bata|dekhna|pata\s+karo)\s+ke\s+(.*)$', text, flags=re.IGNORECASE)
    if imp_m:
        imperative_text = imp_m.group(1).strip()
    imp_lower = imperative_text.lower()

    is_negated_action = bool(re.search(
        r'\b(mat\s+(?:karna|karo|kholna|kholo|khol|open|chalao|start|launch|close|band|delete|hatao|chhedna|touch|modify|change)|don\'t|dont|do\s+not|never|without\s+(?:modifying|changing|deleting)|sirf\s+batao|touch\s+mat)\b',
        lower
    ))

    if detected_app and not any(w in lower for w in ["file", "pdf", "docx", "txt", "search in", "store me", "store mein", "download per", "download karo"]):
        # A) Running state query
        if any(w in imp_lower for w in [
            "actually running", "running hai", "running", "chal raha hai", "chal rahi hai", "open hai",
            "already chal raha", "pehle se running", "background mein", "chalu hai", "is running", "is open", "status"
        ]) and not any(w in lower for w in ["kholo", "open karo", "launch", "band karo", "close", "theek chal", "crash"]):
            if is_negated_action and any(w in lower for w in ["mat kholo", "mat open", "don't open"]):
                return CommandIntent(
                    domain=SemanticDomain.APPLICATION,
                    action=SemanticAction.INSPECT,
                    target=detected_app,
                    request_type=RequestType.QUERY,
                    entity_type=EntityType.APPLICATION,
                    selected_tool="is_app_running",
                    tool_args={"name": detected_app.lower()},
                    constraints=["conditional_skip_if_running"],
                    expected_outcome=f"Checked if {detected_app} is running; launch will be skipped if already open.",
                    raw_clause=text
                )
            return CommandIntent(
                domain=SemanticDomain.APPLICATION,
                action=SemanticAction.INSPECT,
                target=detected_app,
                request_type=RequestType.QUERY,
                entity_type=EntityType.APPLICATION,
                selected_tool="is_app_running",
                tool_args={"name": detected_app.lower()},
                expected_outcome=f"Checked if {detected_app} is running.",
                raw_clause=text
            )

        # B) Diagnostic request
        if any(w in lower for w in ["theek chal raha", "sahi chal raha", "properly chal raha", "crash", "diagnose", "masla", "issue"]):
            return CommandIntent(
                domain=SemanticDomain.DIAGNOSTICS,
                action=SemanticAction.DIAGNOSE,
                target=detected_app,
                request_type=RequestType.DIAGNOSTIC,
                entity_type=EntityType.APPLICATION,
                selected_tool="diagnose_application",
                tool_args={"name": detected_app},
                expected_outcome=f"Diagnosed {detected_app} application health and resource consumption.",
                raw_clause=text
            )

        # C) Close request
        if any(w in lower for w in ["band karo", "band kar do", "close", "terminate", "kill", "exit"]):
            if is_negated_action:
                return CommandIntent(
                    domain=SemanticDomain.APPLICATION,
                    action=SemanticAction.CLOSE,
                    target=detected_app,
                    request_type=RequestType.ACTION,
                    entity_type=EntityType.APPLICATION,
                    is_negated=True,
                    negations=["no_close"],
                    selected_tool="DIRECT_MESSAGE",
                    tool_args={"message": f"Action negated: '{detected_app}' will not be closed as requested."},
                    raw_clause=text
                )
            return CommandIntent(
                domain=SemanticDomain.APPLICATION,
                action=SemanticAction.CLOSE,
                target=detected_app,
                request_type=RequestType.ACTION,
                entity_type=EntityType.APPLICATION,
                selected_tool="close_app",
                tool_args={"name": detected_app},
                expected_outcome=f"Closed application '{detected_app}'.",
                raw_clause=text
            )

        # C.5) Restart request
        if any(w in lower for w in ["restart", "re-open", "reopen", "relaunch"]):
            return CommandIntent(
                domain=SemanticDomain.APPLICATION,
                action=SemanticAction.LAUNCH,
                target=detected_app,
                request_type=RequestType.ACTION,
                entity_type=EntityType.APPLICATION,
                selected_tool="restart_app",
                tool_args={"name": detected_app},
                expected_outcome=f"Restarted application '{detected_app}'.",
                raw_clause=text
            )

        # D) Launch / Open request
        if (
            any(w in lower for w in ["kholo", "khol", "open", "launch", "start", "chalao", "chala do", "chalu karo", "shuru karo", "run", "use karna hai", "open karna hai"])
            and not any(w in lower for w in ["restart", "re-open", "reopen", "relaunch"])
        ):
            if is_negated_action:
                return CommandIntent(
                    domain=SemanticDomain.APPLICATION,
                    action=SemanticAction.LAUNCH,
                    target=detected_app,
                    request_type=RequestType.ACTION,
                    entity_type=EntityType.APPLICATION,
                    is_negated=True,
                    negations=["no_open"],
                    selected_tool="DIRECT_MESSAGE",
                    tool_args={"message": f"Action negated: '{detected_app}' will not be opened as requested."},
                    raw_clause=text
                )
            return CommandIntent(
                domain=SemanticDomain.APPLICATION,
                action=SemanticAction.LAUNCH,
                target=detected_app,
                request_type=RequestType.ACTION,
                entity_type=EntityType.APPLICATION,
                selected_tool="launch_app",
                tool_args={"name": detected_app},
                expected_outcome=f"Launched application '{detected_app}'.",
                raw_clause=text
            )

    # 33. Filesystem Safety & Safe Negation Enforcement (Item K, M)
    if any(w in lower for w in ["delete", "hatao", "remove", "ura do", "erase", "wipe"]):
        if is_negated_action:
            return CommandIntent(
                domain=SemanticDomain.FILESYSTEM,
                action=SemanticAction.DELETE,
                target="file",
                request_type=RequestType.ACTION,
                entity_type=EntityType.FILE,
                is_negated=True,
                negations=["no_delete"],
                selected_tool="DIRECT_MESSAGE",
                tool_args={"message": "Action negated: Target file will not be deleted as requested."},
                raw_clause=text
            )

    # 34. Filesystem Discovery & Implicit Goals (Item E, F)
    if any(f in lower for f in ["downloads", "desktop", "documents"]):
        f_target = "Downloads" if "downloads" in lower else ("Desktop" if "desktop" in lower else "Documents")
        if any(w in lower for w in ["scene dekh", "kya chal raha", "haal dekh", "ka scene"]):
            return CommandIntent(
                domain=SemanticDomain.FILESYSTEM,
                action=SemanticAction.INSPECT,
                target=f_target,
                request_type=RequestType.QUERY,
                entity_type=EntityType.FOLDER,
                selected_tool="list_folder",
                tool_args={"path": f_target.lower()},
                expected_outcome=f"Listed contents of '{f_target}' folder.",
                raw_clause=text
            )
        if any(w in lower for w in ["pdf", "files", "file", "document", "documents"]) and any(w in lower for w in ["dikhao", "dhundo", "find", "search", "latest", "recent"]):
            ext = "pdf" if "pdf" in lower else ""
            return CommandIntent(
                domain=SemanticDomain.FILESYSTEM,
                action=SemanticAction.FIND,
                target=ext or "files",
                request_type=RequestType.QUERY,
                entity_type=EntityType.FILE,
                entities={"folder": f_target, "extension": ext, "latest": "latest" in lower or "recent" in lower},
                selected_tool="find_file",
                tool_args={"name": ext or "*", "start_folder": f_target},
                expected_outcome=f"Found files in '{f_target}'.",
                raw_clause=text
            )

    return None

    return None
