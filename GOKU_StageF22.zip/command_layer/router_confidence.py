from __future__ import annotations
import os
from pathlib import Path
import re
import sys
import time
from typing import Any, Optional, Union, List, Dict, Tuple
from dataclasses import dataclass, field

from brain.planner import (
    Plan,
    PlanStep,
    StructuredIntent,
    create_plan_from_decision,
    decompose_compound_command,
    parse_compound_request,
    resolve_step_variables,
    resolve_step_variables_with_guard,
    inject_plan_prerequisites,
    prune_plan_steps,
    build_hypothesis_investigation_plan,
    build_root_cause_investigation_plan,
    parse_conditional_goal,
    synthesize_adaptive_replan,
    decompose_into_milestones,
    restore_plan_from_checkpoint,
    build_cross_domain_plan,
    apply_cross_domain_transformation,
    build_long_horizon_exploration_plan,
    decompose_long_horizon_goal,
    compute_state_hash,
    detect_state_cycle,
    heuristic_node_score,
    expand_exploration_frontier,
    select_next_frontier_node,
    apply_reflective_history_pruning,
)
from command_layer.cognitive_reasoner import CognitiveReasoner
from command_layer.context import (
    EntityType,
    TypedEntity,
    ORDINAL_REFERENCES,
    SessionContext,
    resolve_references,
    session_context,
    update_context_from_result,
)
from command_layer.semantic_model import (
    SemanticDomain,
    SemanticAction,
    CommandIntent,
    AmbiguityType,
    ClarificationRequest,
    SymptomCategory,
    SituationType,
    ConfidenceTier,
    RiskTier,
    ConfidenceScore,
    ConfirmationRequest,
    FailureType,
    AdaptiveStrategy,
    PlanAdaptation,
    TaskLifecycleState,
    TaskMilestone,
    TaskCheckpoint,
    DomainBridgeType,
    DomainBridgeLink,
    CrossDomainWorkflow,
    HorizonDepth,
    ExplorationNode,
    SearchFrontier,
    LongHorizonReport,
    HistoryQueryType,
    ExecutionTraceRecord,
    TraceSummary,
)
from command_layer.semantic_parser import (
    parse_semantic_intent,
    create_plan_from_intent,
    resolve_in_turn_correction,
    strip_conversational_noise,
    split_compound_clauses,
    detect_symptom_category,
)
from command_layer.firewall import validate_tool_against_firewall, pre_execution_semantic_check, validate_long_horizon_action
from command_layer.state_machine import agent_state
from command_layer.validator import validate_and_sanitize_tool_arguments
from command_layer.lexer import UniversalLexer
from brain.runtime_bus import RuntimePipingBus
from security.state import confirmation_manager
from tools.utils.app_resolver import (
    APP_ALIASES,
    get_canonical_app_name,
    resolve_app,
)
from tools.utils.target_resolver import TargetType, resolve_universal_target, disambiguate_multi_candidates
from command_layer.router_base import (
    Step,
    run_tool_call,
    resolve_system_canonical_path,
    verify_post_recovery,
    verify_semantic_outcome,
    capture_environment_snapshot,
    capture_step_observation,
    detect_environment_drift,
    _entity_val,
    get_all_schemas,
    KNOWN_SITE_KEYS,
    KNOWN_APP_NAMES,
    _has_file_extension,
    _normalize_resolved_path,
    _is_conversational_folder_path,
)
from security.safety_firewall import is_safe_readonly_operation
from security.confirm import RISKY_TOOLS
from command_layer.decomposer import count_action_verbs
from brain.workflow_orchestrator import orchestrate_compound_workflow
from tools.browser import sanitize_search_query
from tools.search import parse_search_grammar
import executor.verifier
import executor.executor



def determine_risk_tier(tool_name: str, args: dict | None = None) -> RiskTier:
    """
    Classifies tool execution risk into one of four deterministic tiers (Bullet #20).
    """
    from security.confirm import RISKY_TOOLS
    destructive_tools = {
        "delete_folder", "kill_process", "terminate_process", "format_disk"
    }
    target_str = ""
    if args and isinstance(args, dict):
        target_str = str(args.get("path") or args.get("name") or "").lower().replace("\\", "/")

    is_scratch = "scratch/" in target_str and not any(p in target_str for p in ("protected", "decoy", "system", "windows"))
    if tool_name == "delete_file" and is_scratch:
        return RiskTier.MEDIUM_IMPACT

    if tool_name in destructive_tools or tool_name in RISKY_TOOLS or "format" in tool_name.lower():
        return RiskTier.HIGH_DESTRUCTIVE

    medium_impact_tools = {
        "close_app", "write_clipboard", "empty_recycle_bin", "manage_window",
        "type_text", "click_mouse", "move_mouse", "press_key", "hotkey",
        "create_file", "move_file", "copy_file", "rename_file", "create_folder", "move_folder"
    }
    if tool_name in medium_impact_tools:
        return RiskTier.MEDIUM_IMPACT

    low_impact_tools = {
        "launch_app", "open_file", "open_folder", "open_url", "open_browser_profile",
        "focus_app", "switch_window"
    }
    if tool_name in low_impact_tools:
        return RiskTier.LOW_IMPACT

    return RiskTier.READ_ONLY


def format_uncertainty_response(confidence_score: Any) -> str:
    """Formats an honest uncertainty response for low confidence execution gating."""
    score_val = getattr(confidence_score, "overall_score", getattr(confidence_score, "overall_confidence", 0.0))
    reasoning = getattr(confidence_score, "reasoning", "Ambiguous or underspecified execution context.")
    return f"I am uncertain about executing this command (Confidence: {score_val:.2f}). {reasoning} Please clarify or specify additional details."


ZERO_ARG_UTILITY_TOOLS = {
    "take_screenshot", "capture_screen", "wait_delay", "get_system_time", "get_system_datetime",
    "get_active_window", "test_internet_connectivity", "get_network_status", "get_wifi_status",
    "get_screen_size", "get_cursor_position", "clear_clipboard", "get_clipboard_text",
    "get_system_diagnostic_snapshot", "diagnose_system", "wait_for_ui_settle", "discover_drives",
    "get_system_health_snapshot", "get_cpu_status", "get_ram_status", "get_memory_status",
    "get_storage_status", "get_drive_status", "get_drives", "get_connected_devices",
    "get_audio_devices", "analyze_multi_adapter_and_bands", "deep_scan_wifi_spectrum",
    "diagnose_network", "diagnose_network_health", "diagnose_performance", "diagnose_storage",
    "diagnose_cpu", "diagnose_memory", "audit_and_reclaim_ram", "audit_wifi_hardware_and_services",
    "list_wifi_profiles", "get_battery_status", "get_ip_address", "inspect_screen",
    "get_open_windows", "list_processes", "list_installed_apps", "get_installed_apps",
    "get_desktop_items", "scroll_active_window", "scroll_and_inspect", "scroll_until_visible",
    "mouse_scroll"
}


def compute_command_confidence(
    user_cmd: str,
    domain: SemanticDomain,
    action: SemanticAction,
    target: str,
    tool_name: str,
    args: dict,
    context: SessionContext
) -> ConfidenceScore:
    """
    Multi-vector mathematical confidence calibration for MARK/GOKU Agent (Bullet #20).
    Score = (0.4 * C_intent) + (0.4 * C_entity) + (0.2 * C_evidence).
    """
    # Objective 1: Zero-argument and standalone utility tools must never be penalized
    # with "Missing target entity and arguments"
    if tool_name in ZERO_ARG_UTILITY_TOOLS or tool_name in ("find_and_interact", "scroll_and_inspect", "scroll_active_window"):
        return ConfidenceScore.calculate(
            intent_c=1.0,
            entity_c=1.0,
            evidence_c=1.0,
            reasoning=f"Autonomous visual / ReAct loop tool '{tool_name}' assigned baseline confidence 1.0."
        )

    clean_cmd = user_cmd.strip().lower()

    # 1. Intent Clarity (C_intent)
    c_intent = 1.0
    intent_notes = []

    vague_patterns = [
        r'\b(?:something|kuch|karo|do it|kuch karo|anything|stuff)\b',
        r'^(?:check|karo|run|open|band|start|fix)$'
    ]
    if any(re.search(p, clean_cmd) for p in vague_patterns) and not target and (not args or all(not v for v in args.values())):
        c_intent = 0.30
        intent_notes.append("Vague or underspecified command intent")
    elif domain == SemanticDomain.UNKNOWN or action in (SemanticAction.CLARIFY, SemanticAction.UNSUPPORTED):
        if not tool_name or tool_name == "none":
            c_intent = 0.40
            intent_notes.append("Unmapped domain or ambiguous action")
        else:
            c_intent = 0.95
    elif not tool_name or tool_name == "none":
        c_intent = 0.35
        intent_notes.append("No executable tool identified")
    else:
        imperatives = ["open", "close", "launch", "kill", "delete", "check", "find", "search", "kholo", "band karo", "delete karo", "hatao", "dikhao", "show", "batao"]
        if any(w in clean_cmd for w in imperatives):
            c_intent = 1.0
        else:
            c_intent = 0.85

    # 2. Entity Certainty (C_entity)
    c_entity = 1.0
    entity_notes = []

    read_only_system_tools = {
        "diagnose_system", "get_cpu_status", "get_ram_status", "get_memory_status",
        "get_storage_status", "get_drive_status", "get_network_status", "get_wifi_status",
        "test_internet_connectivity", "get_system_diagnostic_snapshot", "get_drives",
        "get_connected_devices", "get_audio_devices", "analyze_multi_adapter_and_bands",
        "deep_scan_wifi_spectrum", "diagnose_network", "diagnose_network_health",
        "diagnose_performance", "diagnose_storage", "diagnose_cpu", "diagnose_memory",
        "audit_and_reclaim_ram", "audit_wifi_hardware_and_services", "discover_drives"
    }

    if tool_name in read_only_system_tools and not target:
        c_entity = 1.0
    elif not target and not args:
        c_entity = 0.25
        entity_notes.append("Missing target entity and arguments")
    elif not target and args:
        arg_val = args.get("name") or args.get("path") or args.get("name_or_pid") or args.get("query") or args.get("url")
        if not arg_val:
            c_entity = 0.30
            entity_notes.append("Empty target argument")
        else:
            c_entity = 0.95
    else:
        pronouns = {"it", "this", "that", "them", "woh", "usko", "isse", "ye", "yeh"}
        if target.lower() in pronouns:
            if context.last_verified_entity:
                c_entity = 0.85
                entity_notes.append(f"Pronoun resolved to last verified entity '{context.last_verified_entity}'")
            else:
                c_entity = 0.30
                entity_notes.append("Unresolved pronoun reference without active context")
        elif target.lower() in KNOWN_APP_NAMES or tool_name in ("open_folder", "open_file"):
            c_entity = 1.0
        else:
            c_entity = 0.85

    # 3. Telemetry / Sensory Support (C_evidence)
    c_evidence = 1.0
    evidence_notes = []

    is_diagnostic_claim = any(w in clean_cmd for w in [
        "slow", "stuck", "heavy", "eating", "failed", "down", "working", "problem", "issue", "masla", "kharaab", "chal raha"
    ])

    if is_diagnostic_claim or domain == SemanticDomain.DIAGNOSTICS:
        # Read-only diagnostic tools used for pure inspection (INSPECT action, no symptom
        # claim) are the evidence-gathering step — they don't need prior telemetry.
        # DIAGNOSE actions assert a problem exists and require telemetry backing.
        is_pure_inspection = (
            tool_name in read_only_system_tools
            and not is_diagnostic_claim
            and action != SemanticAction.DIAGNOSE
        )
        if is_pure_inspection:
            c_evidence = 1.0
        else:
            has_telemetry = (
                bool(getattr(context, "recent_evidence", None)) or
                getattr(context, "last_evidence_packet", None) is not None or
                getattr(context, "last_inference", None) is not None or
                getattr(context, "last_hypothesis_ledger", None) is not None or
                getattr(context, "last_root_cause_report", None) is not None
            )
            if has_telemetry:
                c_evidence = 0.95
            else:
                c_evidence = 0.40
                evidence_notes.append("Telemetry evidence absent prior to investigation")
    else:
        c_evidence = 1.0

    reasoning_parts = intent_notes + entity_notes + evidence_notes
    reasoning = "; ".join(reasoning_parts) if reasoning_parts else "All signals conclusive and verified"

    return ConfidenceScore.calculate(c_intent, c_entity, c_evidence, reasoning=reasoning)


def synthesize_cross_domain_report(
    plan: Plan,
    step_results: dict[int, dict[str, Any]],
    user_goal: str = "",
    session_context: Any = None
) -> str:
    """
    Synthesizes a unified, multi-domain problem solving report across involved subsystems (Bullet #27).
    Presents structured correlation of findings, cross-domain handoffs, and operational status.
    """
    is_urdu = any(w in user_goal.lower() for w in ["kya", "hua", "batao", "dikhao", "hai", "tha", "karo", "chalao", "dhoondo", "dhundo", "kholo", "padho", "karke", "saath", "parh"])

    domain_findings: dict[str, list[str]] = {}

    for step in plan.steps:
        s_res = step_results.get(step.step, {})
        lineage = getattr(step, "domain_lineage", [])
        step_dom = lineage[-1].upper() if lineage else "SYSTEM"
        if step_dom not in domain_findings:
            domain_findings[step_dom] = []

        tool = step.tool
        if tool in ("get_free_space", "get_drives", "get_storage_health_snapshot"):
            free_gb = s_res.get("free_gb", s_res.get("free_space_gb", "Verified"))
            drive = step.args.get("drive", "C")
            domain_findings[step_dom].append(f"Storage on {drive}: {free_gb} GB free verified." if not is_urdu else f"Drive {drive} par {free_gb} GB free space tasdeeq shuda.")
        elif tool == "extract_archive":
            dest = step.args.get("destination", "target directory")
            domain_findings[step_dom].append(f"Archive extracted to '{dest}'." if not is_urdu else f"Archive kamyabi se '{dest}' mein extract ho gaya.")
        elif tool in ("read_file", "read_document"):
            doc_path = step.args.get("path", "file")
            domain_findings[step_dom].append(f"Document content inspected at '{doc_path}'." if not is_urdu else f"Document '{doc_path}' kamyabi se parh liya gaya.")
        elif tool in ("search_files", "find_file"):
            matches = s_res.get("matches", s_res.get("files", []))
            cnt = len(matches) if isinstance(matches, list) else 1
            domain_findings[step_dom].append(f"Found {cnt} matching file(s)." if not is_urdu else f"{cnt} matching file(s) daryaft huin.")
        elif tool in ("open_url", "open_browser_profile"):
            url = step.args.get("url", "page")
            browser = step.args.get("browser", "browser")
            domain_findings[step_dom].append(f"Rendered in {browser.title()}: {url}." if not is_urdu else f"{browser.title()} mein display kiya gaya: {url}.")
        elif tool in ("take_screenshot", "inspect_screen"):
            domain_findings[step_dom].append("Captured visual screen confirmation." if not is_urdu else "Screen snapshot / tasweer mehfooz ki gayi.")
        elif tool in ("focus_window", "manage_window"):
            target_win = step.args.get("window", step.args.get("title", "application"))
            domain_findings[step_dom].append(f"Focused window '{target_win}'." if not is_urdu else f"Window '{target_win}' focus ki gayi.")
        elif tool in ("diagnose_system", "get_cpu_status", "get_system_health_snapshot"):
            status_desc = "telemetry healthy" if s_res.get("success", True) else "anomaly detected"
            domain_findings[step_dom].append(f"System diagnostics evaluated ({status_desc})." if not is_urdu else f"System diagnostics check ho gayi.")
        elif tool in ("test_internet_connectivity", "get_wifi_status", "get_network_status"):
            net_stat = s_res.get("status", "connected")
            domain_findings[step_dom].append(f"Network status verified ({net_stat})." if not is_urdu else f"Network connection tasdeeq shuda.")
        elif tool == "launch_app":
            app_name = step.args.get("name", "app")
            domain_findings[step_dom].append(f"Launched application '{app_name}'." if not is_urdu else f"Application '{app_name}' kholi gayi.")
        elif tool == "write_file":
            p = step.args.get("path", "file")
            domain_findings[step_dom].append(f"Exported diagnostic report to '{p}'." if not is_urdu else f"Report '{p}' par save ki gayi.")
        else:
            domain_findings[step_dom].append(f"Executed {tool} successfully." if not is_urdu else f"{tool} kamyabi se chal gaya.")

    lines = []
    if is_urdu:
        lines.append("Multi-Domain Task Kamyabi Se Mukammal:")
        for d, f_list in domain_findings.items():
            lines.append(f"• [{d}]: " + "; ".join(f_list))
        lines.append(f"Subsystems ({len(domain_findings)}): {', '.join(sorted(domain_findings.keys()))} kamyabi se coordinate huye.")
    else:
        lines.append("Cross-Domain Workflow Execution Complete:")
        for d, f_list in domain_findings.items():
            lines.append(f"• [{d}]: " + "; ".join(f_list))
        lines.append(f"Subsystems Coordinated ({len(domain_findings)}): {', '.join(sorted(domain_findings.keys()))}.")

    return "\n".join(lines)


def synthesize_long_horizon_report(
    plan: Plan,
    step_results: dict[int, dict[str, Any]],
    user_goal: str = "",
    session_context: Any = None
) -> str:
    """
    Synthesizes a formal post-exploration audit report for long-horizon autonomous workflows (Bullet #28).
    Summarizes explored nodes, depths, cycle invariants, budget consumption, and key findings.
    """
    frontier: Optional[SearchFrontier] = getattr(plan, "search_frontier", None)
    if not frontier and session_context and getattr(session_context, "frontier", None):
        frontier = session_context.frontier

    total_nodes = len(frontier.nodes) if (frontier and frontier.nodes) else len(step_results)
    max_depth_val = 1
    if frontier and frontier.nodes:
        max_depth_val = max((int(n.depth) for n in frontier.nodes.values()), default=1)

    dead_ends = len(frontier.dead_end_nodes) if frontier else 0
    cycles_avoided = 1 if (frontier and frontier.cycle_detected) else 0
    budget_consumed = (frontier.max_budget - frontier.budget_remaining) if frontier else len(step_results)

    solution_path = []
    summary_findings = []

    for step in plan.steps:
        s_res = step_results.get(step.step, {})
        if not s_res:
            continue
        tool = step.tool
        solution_path.append(f"{tool} (step {step.step})")

        if tool in ("diagnose_system", "get_system_health_snapshot"):
            stat = s_res.get("overall_status") or s_res.get("status", "healthy")
            summary_findings.append(f"System diagnostics evaluated: status={stat}")
        elif tool in ("get_top_processes", "get_process_status"):
            procs = s_res.get("processes", s_res.get("top_processes", []))
            count_p = len(procs) if isinstance(procs, list) else 0
            summary_findings.append(f"Monitored running applications: {count_p} heavy processes cataloged")
        elif tool in ("get_storage_status", "get_free_space", "get_drive_status"):
            free_gb = s_res.get("free_space_gb", s_res.get("free_gb", "Checked"))
            summary_findings.append(f"Storage verified: {free_gb} GB free on target volumes")
        elif tool in ("search_files", "find_file"):
            matches = s_res.get("matches", s_res.get("files", []))
            cnt = len(matches) if isinstance(matches, list) else 0
            summary_findings.append(f"File discovery: {cnt} items matched candidate patterns")
        elif tool == "write_file":
            p = step.args.get("path", "file")
            summary_findings.append(f"Audit report persisted to '{p}'")
        elif tool in ("focus_window", "manage_window"):
            win = step.args.get("window", "app")
            summary_findings.append(f"Window managed and focused: '{win}'")

    if not summary_findings:
        summary_findings.append("All exploratory actions executed and verified against environmental telemetry.")

    all_success = all(r.get("success", True) for r in step_results.values())
    if frontier and frontier.cycle_detected:
        verdict = "CYCLE_HALTED"
    elif frontier and frontier.budget_remaining <= 0 and not all_success:
        verdict = "BUDGET_EXHAUSTED"
    elif all_success:
        verdict = "SOLVED"
    else:
        verdict = "PARTIALLY_ACHIEVED"

    report = LongHorizonReport(
        macro_goal=user_goal or plan.goal or plan.explanation,
        total_nodes_evaluated=total_nodes,
        depth_reached=max_depth_val,
        dead_ends_encountered=dead_ends,
        cycles_avoided=cycles_avoided,
        budget_consumed=budget_consumed,
        solution_path=solution_path,
        outcome_verdict=verdict,
        summary_findings=summary_findings,
    )

    if session_context:
        session_context.last_long_horizon_report = report

    is_urdu = any(w in (user_goal or "").lower() for w in ["kya", "hua", "batao", "dikhao", "hai", "tha", "karo", "chalo", "chalao", "dhundo", "dhoondo", "safai", "pura", "tamam", "mukammal"])
    return report.to_markdown(lang="ur" if is_urdu else "en")


def get_conversational_response(text: str, category: str, lang: str, context: Any = None) -> str:
    """
    Produces immediate conversational responses for greetings, capabilities, user feedback,
    or queries local Ollama for general Q&A and nuanced conversational feedback.
    """
    if category == "greeting":
        if lang == "ur":
            return "Salam! Main aapki Windows system, files aur apps mein kya madad kar sakta hoon?"
        return "Hello! How can I assist you with your computer today?"

    if category == "capability":
        clean_lower = text.lower()
        if any(w in clean_lower for w in ["who i am", "who am i", "mera naam", "main kaun", "mai kaun"]):
            if lang == "ur":
                return "Aap mere user hain, aur main aapka Windows desktop AI assistant hoon. Main aapke computer tasks mein madad karta hoon."
            return "You are the user, and I am your local Windows desktop AI assistant. I help you control and automate your computer."
        if lang == "ur":
            return (
                "Main GOKU hoon, aapka Windows 11 offline autonomous assistant. "
                "Main applications chala sakta hoon, files aur folders dhoond aur manage kar sakta hoon, "
                "system health (CPU, RAM, disk) check kar sakta hoon, aur browser tasks automate kar sakta hoon."
            )
        return (
            "I am GOKU, your Windows 11 offline autonomous assistant. "
            "I can launch and close applications, search and manage files/folders, inspect system health (CPU, RAM, disk), "
            "control network settings, and automate browser tasks."
        )

    if category == "acknowledgment":
        if lang == "ur":
            return "Koi masla nahi! Agar kisi aur cheez mein madad chahiye to bataiye."
        return "You're welcome! Let me know what you would like to do next."

    if category == "feedback":
        try:
            from brain.llm import ask_conversational_llm
            last_tool = getattr(context, "last_tool_result", None) or getattr(context, "last_launched_application", None)
            ctx_note = f"User feedback on previous action. Previous tool result was: {last_tool}" if last_tool else None
            llm_reply = ask_conversational_llm(text, context_notes=ctx_note, timeout_seconds=6.0)
            if llm_reply:
                return llm_reply
        except Exception:
            pass
        if lang == "ur":
            return "Maazrat chahta hoon, ghalat samajh gaya tha. Aap bataiye ab kya open ya run karna hai?"
        return "I apologize for the misunderstanding. What would you like me to open or do instead?"

    if category == "general_qa":
        try:
            from brain.llm import ask_conversational_llm
            llm_reply = ask_conversational_llm(text, timeout_seconds=12.0)
            if llm_reply:
                return llm_reply
        except Exception:
            pass
        if lang == "ur":
            return f"Main offline Windows desktop assistant hoon. '{text}' jaise aam maloomat ke sawalon ke liye local Ollama service active rakhein. Main aapke computer ya programming tasks mein kya madad karoon?"
        return f"I am primarily a local Windows desktop assistant. For general questions like '{text}', please ensure the local Ollama service is active. How can I assist you with your computer or programming tasks?"

    return "How can I help you with your computer today?"


def evaluate_confidence_routing(
    text: str,
    context: Optional[SessionContext] = None
) -> dict[str, Any]:
    """
    Evaluates command confidence and routes according to 3 strict branches (Prompt P6 Item 3):
    - High confidence (>= CONFIDENCE_HIGH_THRESHOLD): execute plan steps
    - Medium confidence (CONFIDENCE_MEDIUM_THRESHOLD <= score < CONFIDENCE_HIGH_THRESHOLD): exactly ONE clarification question
    - Low confidence (< CONFIDENCE_MEDIUM_THRESHOLD): route to chat
    """
    if context is None:
        from command_layer.context import session_context as _default_ctx
        context = _default_ctx

    from config.settings import CONFIDENCE_HIGH_THRESHOLD, CONFIDENCE_MEDIUM_THRESHOLD
    from command_layer.semantic_parser import detect_conversational_intent
    from command_layer.context import resolve_references
    from command_layer.router_core import route_command

    clean_text = text.strip()

    # 1. Low Confidence / Conversational Intent -> Chat
    is_conv, conv_cat, conv_lang = detect_conversational_intent(clean_text)
    if is_conv:
        chat_msg = get_conversational_response(clean_text, conv_cat, conv_lang, context)
        score = ConfidenceScore.calculate(0.2, 0.2, 0.2, reasoning="Conversational query; routed to chat")
        return {
            "tier": "low",
            "action": "chat",
            "score": score,
            "response": chat_msg,
            "plan": None,
        }

    # 2. Check Ambiguity / Missing References -> Medium Confidence (Clarification)
    resolved_text, is_ambig, ambig_msg = resolve_references(clean_text, context)
    if is_ambig and ambig_msg:
        clarify_q = ambig_msg if ambig_msg.endswith("?") else f"{ambig_msg}?"
        score = ConfidenceScore.calculate(0.6, 0.5, 0.5, reasoning="Ambiguous reference or missing entity; clarification required")
        return {
            "tier": "medium",
            "action": "clarify",
            "score": score,
            "response": clarify_q,
            "question": clarify_q,
            "plan": None,
        }

    # 3. Check Deterministic Plan
    plan = route_command(clean_text, context=context)
    if plan and getattr(plan, "is_direct_message", False) and getattr(plan, "message_text", ""):
        msg = plan.message_text
        if "clarif" in msg.lower() or "which" in msg.lower() or msg.endswith("?"):
            clarify_q = msg if msg.endswith("?") else f"{msg}?"
            score = ConfidenceScore.calculate(0.65, 0.55, 0.5, reasoning="Ambiguous command intent; clarification required")
            return {
                "tier": "medium",
                "action": "clarify",
                "score": score,
                "response": clarify_q,
                "question": clarify_q,
                "plan": None,
            }
        else:
            score = ConfidenceScore.calculate(0.3, 0.3, 0.3, reasoning="Direct conversational message; routed to chat")
            return {
                "tier": "low",
                "action": "chat",
                "score": score,
                "response": msg,
                "plan": None,
            }

    if not plan or not plan.steps:
        # Check if vague/underspecified command
        score = compute_command_confidence(
            user_cmd=clean_text,
            domain=SemanticDomain.UNKNOWN,
            action=SemanticAction.CLARIFY,
            target="",
            tool_name="none",
            args={},
            context=context,
        )
        if score.overall_confidence >= CONFIDENCE_MEDIUM_THRESHOLD:
            clarify_q = f"Could you please clarify your request for '{clean_text}'?"
            return {
                "tier": "medium",
                "action": "clarify",
                "score": score,
                "response": clarify_q,
                "question": clarify_q,
                "plan": None,
            }
        else:
            chat_msg = get_conversational_response(clean_text, "general_qa", "en", context)
            return {
                "tier": "low",
                "action": "chat",
                "score": score,
                "response": chat_msg,
                "plan": None,
            }

    # Plan with steps
    first_step = plan.steps[0]
    score = compute_command_confidence(
        user_cmd=clean_text,
        domain=SemanticDomain.UNKNOWN,
        action=SemanticAction.LAUNCH,
        target=str(first_step.args.get("name") or first_step.args.get("path") or ""),
        tool_name=first_step.tool,
        args=first_step.args,
        context=context,
    )

    if score.overall_confidence >= CONFIDENCE_HIGH_THRESHOLD:
        return {
            "tier": "high",
            "action": "execute",
            "score": score,
            "response": "Executing plan",
            "plan": plan,
        }
    elif score.overall_confidence >= CONFIDENCE_MEDIUM_THRESHOLD:
        target_name = first_step.args.get("name") or first_step.args.get("path") or "target"
        clarify_q = f"Did you mean to run '{first_step.tool}' on {target_name}?"
        return {
            "tier": "medium",
            "action": "clarify",
            "score": score,
            "response": clarify_q,
            "question": clarify_q,
            "plan": None,
        }
    else:
        chat_msg = get_conversational_response(clean_text, "general_qa", "en", context)
        return {
            "tier": "low",
            "action": "chat",
            "score": score,
            "response": chat_msg,
            "plan": None,
        }

