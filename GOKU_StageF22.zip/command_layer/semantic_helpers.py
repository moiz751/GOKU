from __future__ import annotations
import os
import re
import sys
from typing import Any, Optional, Dict, List, Set, Tuple

from command_layer.semantic_model import (
    SemanticDomain,
    SemanticAction,
    RequestType,
    EntityType,
    CommandIntent,
    AmbiguityType,
    ClarificationRequest,
    SymptomCategory,
    SituationType,
    ConfidenceTier,
    RiskTier,
    ConfidenceScore,
    ConfirmationRequest,
    FailureType,
    AdaptiveStrategy,
    PlanAdaptation,
    TaskLifecycleState,
    TaskMilestone,
    TaskCheckpoint,
    DomainBridgeType,
    DomainBridgeLink,
    CrossDomainWorkflow,
    HorizonDepth,
    ExplorationNode,
    SearchFrontier,
    LongHorizonReport,
    HistoryQueryType,
    ExecutionTraceRecord,
    TraceSummary,
)
from brain.planner import Plan, PlanStep

def resolve_in_turn_correction(text: str) -> tuple[str, str | None, list[str]]:
    """
    Detects and resolves in-turn conversational self-repairs and contrastive replacements (Bullet #8).
    Handles:
      - 'X instead of Y' / 'X rather than Y' -> X
      - 'Y ke bajaye X' / 'Y ke bajaae X' -> X
      - '... nahi ...', ' are nahi ', ' no wait ', ' wait sorry ', ' sorry ', ' actually ', ' scratch that '
    Returns (effective_text, obsolete_intent_summary, prohibited_targets).
    """
    raw = text.strip()

    # Pattern A: 'X instead of Y' / 'X rather than Y'
    inst_m = re.search(r'^(.*?)\s+\b(?:instead\s+of|rather\s+than)\b\s+(.+)$', raw, flags=re.IGNORECASE)
    if inst_m:
        affirmative = inst_m.group(1).strip()
        discarded = inst_m.group(2).strip()
        return affirmative, f"Replaced '{discarded}' with '{affirmative}'", [discarded]

    # Pattern B: 'Y ke bajaye X' / 'Y ke bajaae X'
    bajaye_m = re.search(r'^(.*?)\s+\b(?:ke\s+bajaye|ke\s+bajaae)\b\s+(.+)$', raw, flags=re.IGNORECASE)
    if bajaye_m:
        discarded = bajaye_m.group(1).strip()
        affirmative = bajaye_m.group(2).strip()
        return affirmative, f"Replaced '{discarded}' with '{affirmative}'", [discarded]

    def _combine_prior_and_repair(prior: str, repair: str) -> str:
        repair_clean = re.sub(r'^(?:sirf|just|only)\s+', '', repair.strip(), flags=re.IGNORECASE).strip()
        repair_low = repair_clean.lower()
        has_verb = any(v in repair_low for v in [
            "kholo", "open", "launch", "run", "start", "delete", "hatao", "remove",
            "search", "find", "dhundo", "dhoondo", "list", "check", "inspect", "chalao",
            "space", "read", "minimize", "focus"
        ])
        prior_target_m = re.search(
            r'\b([a-zA-Z0-9_\-]+\.[a-zA-Z0-9]+|chrome|edge|firefox|notepad|calculator|calc|vlc|spotify|word|powerpoint|excel|system32|downloads|documents|desktop|files|file|folder|drive|process)\b',
            prior, flags=re.IGNORECASE
        )
        prior_target = prior_target_m.group(1) if prior_target_m else ""

        if not has_verb:
            for v in ["delete karo", "delete", "hatao", "open karo", "kholo", "open", "launch", "run", "start", "chalao", "search karo", "dhundo", "list karo"]:
                if v in prior.lower():
                    return f"{repair_clean} {v}"
            return repair_clean

        has_target = bool(re.search(r'\b([a-zA-Z0-9_\-]+\.[a-zA-Z0-9]+|chrome|edge|firefox|notepad|calculator|calc|vlc|spotify|word|powerpoint|excel|system32|downloads|documents|desktop|files|file|folder|drive)\b', repair_low))
        if not has_target and prior_target:
            if any(w in repair_low for w in ["search", "find", "dhundo"]):
                return f"{prior_target} search karo"
            elif any(w in repair_low for w in ["list"]):
                return f"{prior_target} list karo"
            elif any(w in repair_low for w in ["space", "free space"]):
                return f"{prior_target} space check karo"
            elif any(w in repair_low for w in ["status", "check"]):
                return f"{prior_target} status check karo"
            else:
                return f"{prior_target} {repair_clean}"
        return repair_clean

    # Pattern C: In-turn correction markers:
    corr_split = re.split(
        r'\s*(?:\.\.\.|\,\s*|\s+)\b(?:are\s+nahi|no\s+wait|wait\s+sorry|sorry|actually|scratch\s+that|rather)\b\s*',
        raw, flags=re.IGNORECASE
    )
    if len(corr_split) >= 2 and corr_split[-1].strip():
        prior = corr_split[0].strip()
        repair = corr_split[-1].strip()
        effective = _combine_prior_and_repair(prior, repair)
        return effective, f"Corrected from '{prior}' to '{effective}'", [prior]

    # Check for '... nahi ...', ', nahi ...', or 'nahi sirf ...' (avoiding rhetorical 'to nahi')
    nahi_split = re.split(
        r'(?<!\bto)(?:\s*(?:\.\.\.|\,)\s*\b(?:nahi)\b\s+|\s+\b(?:nahi\s+sirf|are\s+nahi)\b\s*)',
        raw, flags=re.IGNORECASE
    )
    if len(nahi_split) >= 2 and nahi_split[-1].strip():
        prior = nahi_split[0].strip()
        repair = nahi_split[-1].strip()
        if repair and repair.lower() not in ("karo", "karna", "hai", "tha", "hoga"):
            effective = _combine_prior_and_repair(prior, repair)
            return effective, f"Corrected from '{prior}' to '{effective}'", [prior]

    # Bare '<A> <verb> nahi <B> <verb>' (no comma/ellipsis): a repair only when BOTH sides carry an action verb, so plain negation ('nahi kholna') is untouched.
    _verb = r'(?:kholo|open(?:\s+karo)?|launch(?:\s+karo)?|chalao|start(?:\s+karo)?|run(?:\s+karo)?)'
    bare_m = re.match(r'^(.+?\b' + _verb + r')\s+nahi\s+(.+?\b' + _verb + r')\s*[.!?]*$', raw, flags=re.IGNORECASE)
    if bare_m:
        prior, repair = bare_m.group(1).strip(), bare_m.group(2).strip()
        return repair, f"Corrected from '{prior}' to '{repair}'", [prior]

    return raw, None, []


# Pre-compiled conversational noise patterns (Bullet #10 & #32)
_COMPILED_PREAMBLES = [
    re.compile(
        r'^(?:yaar\s+mujhe\s+lag\s+raha\s+hai\s+(?:ke\s+|ki\s+)?|yaar\s+mujhe\s+lagta\s+hai\s+(?:ke\s+|ki\s+)?|'
        r'bhai\s+ek\s+kaam\s+karo\s+(?:jaldi\s+se\s+)?|ek\s+kaam\s+karo\s+(?:jaldi\s+se\s+)?|'
        r'mera\s+ek\s+kaam\s+kar\s+do\s+(?:aur\s+)?|kya\s+tum\s+ek\s+kaam\s+kar\s+sakte\s+ho\s+(?:ke\s+|ki\s+)?|'
        r'kya\s+aap\s+ek\s+kaam\s+kar\s+sakte\s+hain\s+(?:ke\s+|ki\s+)?|'
        r'can\s+you\s+(?:please\s+)?do\s+me\s+a\s+favor\s+(?:and\s+)?|'
        r'could\s+you\s+(?:please\s+)?|would\s+you\s+(?:please\s+)?|'
        r'listen\s+carefully\s*,?\s*|listen\s*,?\s*|sun\s+yaar\s*,?\s*|suno\s*,?\s*|'
        r'hey\s+(?:agent|goku|computer)\s*,?\s*|hello\s+(?:agent|goku|computer)\s*,?\s*|'
        r'agent\s+please\s*,?\s*|please\s*,?\s*|kindly\s*,?\s*|meherbani\s+karke\s*,?\s*|'
        r'bhai\s*,?\s*|yaar\s*,?\s*)',
        re.IGNORECASE
    )
]

_COMPILED_FILLERS = [
    re.compile(r'\b(?:jaldi\s+se|thoda\s+jaldi|asap|quickly)\b', re.IGNORECASE),
]

_COMPILED_TRAILING = [
    re.compile(r'(?:,\s*|\s+)\b(?:aur\s+batao\s+kya\s+chal\s+raha\s+hai|aur\s+sab\s+kaisa\s+hai|samjhe\??|samjh\s+gaye\??|samajh\s+aya\??|theek\s+hai\??|ok\??|got\s+it\??|you\s+know\s+what\s+i\s+mean\??)\s*$', re.IGNORECASE),
]

_COMPILED_DOUBLE_SPACES = re.compile(r'\s{2,}')


def strip_conversational_noise(text: str) -> tuple[str, list[str]]:
    """
    Strips conversational preamble padding, verbal fillers, and trailing monologues (Bullet #10).
    Preserves core imperative verbs, entity literals, and query targets.
    Returns (cleaned_text, stripped_tokens).
    """
    raw = text.strip()
    if not raw:
        return raw, []

    stripped: list[str] = []
    current = raw

    for cp in _COMPILED_PREAMBLES:
        m = cp.match(current)
        if m:
            matched_str = m.group(0)
            remainder = current[len(matched_str):].strip()
            if remainder:
                stripped.append(matched_str.strip())
                current = remainder

    # 2. Verbal fillers (middle / start adverbs)
    for cp in _COMPILED_FILLERS:
        if cp.search(current):
            for match in cp.finditer(current):
                stripped.append(match.group(0))
            current = cp.sub('', current)

    # 3. Trailing monologues and rhetorical checks
    for cp in _COMPILED_TRAILING:
        m = cp.search(current)
        if m:
            matched_str = m.group(0)
            remainder = current[:current.rfind(matched_str)].strip()
            if remainder:
                stripped.append(matched_str.strip())
                current = remainder

    # Clean double spaces
    current = _COMPILED_DOUBLE_SPACES.sub(' ', current).strip()
    return current, stripped


# Pre-compiled multi titles and compound split pattern (Bullet #10 & #32)
_KNOWN_MULTI_TITLES_PATTERNS = {
    kt: re.compile(re.escape(kt), re.IGNORECASE)
    for kt in [
        "tom and jerry", "war and peace", "research and development",
        "rock and roll", "fast and furious", "command and control"
    ]
}

_COMPILED_SPLIT_PATTERN = re.compile(
    r'\s*(?:'
    r';\s*|'
    r',\s*(?:aur|and|phir|then|after\s+that)?\s*|'
    r'\s+and\s+then\s+|\s+after\s+that\s+|\s+then\s+|\s+phir\s+|\s+aur\s+phir\s+|\s+ke\s+baad\s+|\s+iske\s+baad\s+|\s+karke\s+|\s+saath\s+hi\s+|\s+as\s+well\s+as\s+|\s+along\s+with\s+|'
    r'\s+aur\s+|\s+and\s+|'
    r'\s+lekin\s+|\s+but\s+|\s+however\s+|'
    r'(?<!\bscreen)(?<!\bdesktop)(?<!\bdrive)(?<!\bdisk)(?<!\bvolume)(?<!\bpointer)\s+par\s+'
    r')\s*',
    flags=re.IGNORECASE
)


def split_compound_clauses(text: str) -> list[str]:
    """
    Decomposes compound sentences into ordered, discrete clauses while protecting
    quoted entities, filenames, colon payloads, and conjunctions inside titles (Bullet #10 & #32).
    Uses pre-compiled patterns for O(1) splitting without recompilation overhead.
    """
    raw = text.strip()
    if not raw:
        return []

    # 1. Protect quoted literals (e.g. "Tom and Jerry.mp4", 'War and Peace')
    quoted_map: dict[str, str] = {}
    def _mask_quotes(m):
        idx = len(quoted_map)
        token = f"__QUOTED_{idx}__"
        quoted_map[token] = m.group(0)
        return token

    masked_text = re.sub(r'["\']([^"\']+)["\']', _mask_quotes, raw)

    # 2. Protect colon dictation payloads (e.g. likho: Hello and welcome)
    colon_map: dict[str, str] = {}
    if ":" in masked_text:
        parts = masked_text.split(":", 1)
        if any(w in parts[0].lower() for w in ["likho", "type", "text", "search"]):
            token = "__COLON_PAYLOAD__"
            colon_map[token] = parts[1]
            masked_text = f"{parts[0]}: {token}"

    # 3. Protect known entities/titles containing conjunctions without quotes
    title_map: dict[str, str] = {}
    for kt, pat in _KNOWN_MULTI_TITLES_PATTERNS.items():
        if kt in masked_text.lower():
            idx = len(title_map)
            token = f"__TITLE_{idx}__"
            found = pat.search(masked_text)
            if found:
                title_map[token] = found.group(0)
                masked_text = pat.sub(token, masked_text)

    # 4. Split on conjunctions and punctuation boundaries using pre-compiled regex
    raw_clauses = _COMPILED_SPLIT_PATTERN.split(masked_text)

    # 5. Restore masked tokens
    clauses: list[str] = []
    for rc in raw_clauses:
        clause = rc.strip()
        if not clause:
            continue
        for tok, val in title_map.items():
            clause = clause.replace(tok, val)
        for tok, val in colon_map.items():
            clause = clause.replace(tok, val)
        for tok, val in quoted_map.items():
            clause = clause.replace(tok, val)

        clause = clause.strip()
        if clause:
            clauses.append(clause)

    return clauses if clauses else [raw]


# Pre-compiled symptom detection patterns (Bullet #11 & #32)
_COMPILED_THERMAL_1 = re.compile(r'\b(?:garam|heat|overheat|overheating|thermal|temperature|burning|hot|heating\s+up|processor\s+garam)\b', re.IGNORECASE)
_COMPILED_THERMAL_2 = re.compile(r'\b(?:fan|fans)\b.*\b(?:tez|speed|loud|running|spinning|shor|awaaz|full|high|crazy)\b|\b(?:tez|loud|full\s+speed)\b.*\b(?:fan|fans)\b|\b(?:fan|fans)\s+(?:bhi\s+)?(?:full\s+speed|tez|loud)\b', re.IGNORECASE)

_COMPILED_MEMORY_1 = re.compile(r'\b(?:ram|memory)\b.*\b(?:full|bhar|khatam|leak|crash|exhaust|pressure|bojh|zyada|choke)\b|\b(?:out\s+of\s+memory|memory\s+leak|ram\s+crash|memory\s+bhar\s+gayi|ram\s+full|memory\s+full)\b', re.IGNORECASE)

_COMPILED_NET_NEG = re.compile(r'\b(?:mat\s+|don\'t\s+|dont\s+|never\s+)\w*\s*disconnect\b|disconnect\s+mat\b', re.IGNORECASE)
_COMPILED_NET_1 = re.compile(r'\b(?:net|internet|wifi|wi-fi)\s+(?:bhi\s+)?(?:nahi\s+chal|band|disconnect|drop|down|nahi\s+aaraha|nahi\s+aara|nahi\s+chal\s+raha|issue|problem|masla|error|fail|stalled|disconnected)\b', re.IGNORECASE)
_COMPILED_NET_2 = re.compile(r'\b(?:kuch\s+open\s+nahi|no\s+internet|websites?\s+load\s+nahi|pages?\s+load\s+nahi|dns\s+error|connection\s+down|connection\s+lost|disconnected\s+lag\s+raha|ping\s+fail|net\s+disconnected|wifi\s+drop|site\s+nahi\s+chal|websites?\s+nahi\s+khul|link\s+down|gateway\s+issue|connection\s+fail)\b', re.IGNORECASE)
_COMPILED_NET_3 = re.compile(r'\b(?:dunya\s+se\s+rabta\s+toot\s+gaya|net\s+so\s+gaya|wifi\s+so\s+gaya|internet\s+mar\s+gaya|wifi\s+ne\s+jawab\s+de\s+diya|net\s+ne\s+jawab\s+de\s+diya|dunya\s+se\s+kat\s+gaye)\b', re.IGNORECASE)
_COMPILED_NET_4 = re.compile(r'\bcannot\s+access\b.*\bwebsite\b', re.IGNORECASE)

_COMPILED_STORAGE_1 = re.compile(r'\b(?:disk|storage|drive|hard\s*drive)\b.*\b(?:full|khatam|bhar|nahi\s+bachi|nahi\s+bacha|low|crunch|exhaust|exhaustion|kam|alert|warning)\b', re.IGNORECASE)
_COMPILED_STORAGE_2 = re.compile(r'\bspace\b.*\b(?:khatam|kam|alert|warning|exhaust|exhaustion|nahi\s+bachi)\b|\b(?:low\s+disk\s+space|no\s+space\s+left|space\s+khatam|disk\s+full|storage\s+full|jagah\s+nahi\s+bachi|drives\s+full|out\s+of\s+disk\s+space|disk\s+space\s+exhaustion)\b', re.IGNORECASE)
_COMPILED_STORAGE_3 = re.compile(r'\b(?:pet\s+bhar\s+gaya|jagah\s+(?:bilkul\s+)?nahi\s+bachi|disk\s+thak\s+gayi|storage\s+cheekh\s+rahi|disk\s+cheekh\s+rahi|dam\s+ghut\s+raha\s+disk\s+ka)\b', re.IGNORECASE)
_COMPILED_DRIVE_LETTER = re.compile(r'\b([a-zA-Z])(?:\s*drive|\s*disk|:)\b', re.IGNORECASE)

_COMPILED_APP_HANG = re.compile(r'\b(?:atk[a-z]*|atak|respond\s+nahi|not\s+responding|freeze|frozen|hang|stuck|unresponsive|jam\s+gaya|jam\s+gayi|bilkul\s+jam|crash)\b', re.IGNORECASE)

_COMPILED_SYS_SLUGGISH_1 = re.compile(r'\b(?:system|pc|computer|laptop|machine|desktop|sab\s+kuch|cursor)\b.*\b(?:slow|lag|laggy|freeze|stuck|atak|hang|jam|stutter|unresponsive|sluggish|heavy|delay)\b', re.IGNORECASE)
_COMPILED_SYS_SLUGGISH_2 = re.compile(r'\b(?:pc\s+slow|computer\s+slow|system\s+slow|sab\s+kuch\s+atak|cursor\s+freeze|stutter\s+kar\s+raha|slow\s+chal\s+raha|hang\s+ho\s+raha)\b', re.IGNORECASE)
_COMPILED_SYS_SLUGGISH_3 = re.compile(r'\b(?:delay\s+ho\s+raha|har\s+action\s+pe\s+delay|crawl\s+kar\s+raha|sluggish\s+machine|extreme\s+lag)\b', re.IGNORECASE)
_COMPILED_SYS_SLUGGISH_4 = re.compile(r'\b(?:dum\s+nikal\s+raha\s+hai|sa?ans\s+phool\s+rahi\s+hai|(?:system|laptop|pc|computer)\s+mar\s+gaya|cheekhein\s+maar\s+raha|cheekh\s+raha\s+hai|ro\s+raha\s+hai|laptop\s+cheekh|pc\s+cheekh)\b', re.IGNORECASE)


def detect_symptom_category(text: str) -> tuple[SymptomCategory, SituationType, list[str]]:
    """
    Identifies situational symptoms, informal problem complaints, and physical domains (Bullet #11 & #32).
    Supports English, Roman Urdu, Hinglish, and Code-switched colloquial expressions.
    Uses pre-compiled regex objects for sub-millisecond evaluation.
    Returns (SymptomCategory, SituationType, extracted_entities).
    """
    raw = text.strip()
    if not raw:
        return SymptomCategory.NONE, SituationType.UNKNOWN, []

    # Strip conversational noise first
    clean_text, _ = strip_conversational_noise(raw)
    lower = clean_text.lower()

    # Exclude causal/investigative and drive-usage queries handled by Bullet #5
    if any(w in lower for w in ["ki wajah se", "due to", "because of"]):
        return SymptomCategory.NONE, SituationType.UNKNOWN, []
    if any(w in lower for w in ["kitni full", "kitna full", "how full"]):
        return SymptomCategory.NONE, SituationType.UNKNOWN, []

    detected_cats: list[SymptomCategory] = []
    entities: list[str] = []

    # 1. Thermal & Fan Noise Symptoms
    is_thermal = bool(_COMPILED_THERMAL_1.search(lower)) or bool(_COMPILED_THERMAL_2.search(lower)) or any(w in lower for w in ["laptop garam", "pc garam", "computer garam", "running hot", "bohot garam", "boht garam"])
    if is_thermal:
        detected_cats.append(SymptomCategory.THERMAL_PERFORMANCE)

    # 2. Memory Pressure Symptoms
    is_memory = bool(_COMPILED_MEMORY_1.search(lower)) or ("apps" in lower and any(w in lower for w in ["crash ho rahi", "crashing", "band ho rahi"]))
    if is_memory:
        detected_cats.append(SymptomCategory.MEMORY_PRESSURE)

    # 3. Network & Browsing Failure Symptoms
    is_negated_disconnect = bool(_COMPILED_NET_NEG.search(lower))
    is_network = not is_negated_disconnect and (
        bool(_COMPILED_NET_1.search(lower))
        or bool(_COMPILED_NET_2.search(lower))
        or bool(_COMPILED_NET_3.search(lower))
        or bool(_COMPILED_NET_4.search(lower))
        or (any(w in lower for w in ["net nahi", "internet nahi", "wifi nahi", "websites nahi", "pages nahi", "site nahi"]) and any(w in lower for w in ["chal", "load", "open", "khul"]))
        or ("internet" in lower and any(w in lower for w in ["down", "disconnected", "stalled", "issue"]))
    )
    if is_network:
        detected_cats.append(SymptomCategory.NETWORK_CONNECTIVITY)

    # 4. Storage Crunch Symptoms
    is_storage = (
        bool(_COMPILED_STORAGE_1.search(lower))
        or bool(_COMPILED_STORAGE_2.search(lower))
        or bool(_COMPILED_STORAGE_3.search(lower))
        or ("c drive" in lower and any(w in lower for w in ["full", "bhar", "khatam", "alert", "warning"]))
        or ("storage alert" in lower or "disk space warning" in lower)
    )
    if is_storage:
        detected_cats.append(SymptomCategory.STORAGE_CRUNCH)
        d_m = _COMPILED_DRIVE_LETTER.search(lower)
        if d_m:
            entities.append(f"{d_m.group(1).upper()}:")

    # 5. App Hang & Unresponsive Symptoms
    app_words = ["chrome", "notepad", "edge", "firefox", "word", "excel", "powerpoint", "vs code", "vscode", "calculator", "calc", "vlc", "window", "application", "program"]
    has_app_target = any(a in lower for a in app_words)
    is_app_hang = (
        bool(_COMPILED_APP_HANG.search(lower))
        and (has_app_target or not any(w in lower for w in ["computer", "pc", "laptop", "system", "sab kuch", "entire", "disk", "drive", "wifi", "internet", "net"]))
    )
    if is_app_hang and has_app_target:
        detected_cats.append(SymptomCategory.APP_UNRESPONSIVE)
        for app in ["chrome", "notepad", "edge", "firefox", "word", "excel", "powerpoint", "vs code", "vscode", "calculator", "calc", "vlc"]:
            if app in lower:
                entities.append(app)
                break
    elif is_app_hang and not has_app_target and not any(w in lower for w in ["computer", "pc", "laptop", "system"]):
        detected_cats.append(SymptomCategory.APP_UNRESPONSIVE)

    # 6. System Sluggishness & Freezing Symptoms
    is_system_sluggish = (
        bool(_COMPILED_SYS_SLUGGISH_1.search(lower))
        or bool(_COMPILED_SYS_SLUGGISH_2.search(lower))
        or bool(_COMPILED_SYS_SLUGGISH_3.search(lower))
        or bool(_COMPILED_SYS_SLUGGISH_4.search(lower))
        or ("sluggish" in lower and not any(w in lower for w in ["disk", "storage"]))
    )
    if is_system_sluggish and not (is_app_hang and has_app_target and not any(w in lower for w in ["computer", "pc", "laptop", "system", "machine", "desktop"])):
        detected_cats.append(SymptomCategory.SYSTEM_SLUGGISHNESS)

    # Resolution
    if len(detected_cats) >= 2:
        return SymptomCategory.COMPOSITE, SituationType.DEGRADED_PERFORMANCE, entities
    elif len(detected_cats) == 1:
        cat = detected_cats[0]
        if cat in (SymptomCategory.THERMAL_PERFORMANCE, SymptomCategory.SYSTEM_SLUGGISHNESS):
            return cat, SituationType.DEGRADED_PERFORMANCE, entities
        elif cat in (SymptomCategory.MEMORY_PRESSURE, SymptomCategory.STORAGE_CRUNCH):
            return cat, SituationType.RESOURCE_EXHAUSTION, entities
        elif cat == SymptomCategory.NETWORK_CONNECTIVITY:
            return cat, SituationType.OUTAGE, entities
        elif cat == SymptomCategory.APP_UNRESPONSIVE:
            return cat, SituationType.PROCESS_HANG, entities

    return SymptomCategory.NONE, SituationType.UNKNOWN, entities


def normalize_adversarial_and_typo_input(text: str) -> str:
    """
    Bullet #30: Normalizes extreme typos, colloquial slangs, and unmasks deceptive
    adversarial negations before semantic parsing and intent classification.
    """
    if not text:
        return ""

    norm = text

    # 1. Unmask Deceptive Double Negations & Adversarial Imperatives
    deceptive_negations = [
        (r'\bdo\s+not\s+hesitate\s+to\s+', ''),
        (r'\bdon\'t\s+hesitate\s+to\s+', ''),
        (r'\bnever\s+hesitate\s+to\s+', ''),
        (r'\bnever\s+stop\s+(?:from\s+)?', ''),
        (r'\bdon\'t\s+refrain\s+from\s+', ''),
        (r'\bdo\s+not\s+refrain\s+from\s+', ''),
        (r'\bdo\s+not\s+fail\s+to\s+', ''),
        (r'\bnever\s+avoid\s+', ''),
        (r'\bi\s+forbid\s+you\s+from\s+not\s+', ''),
        (r'\bbalki\s+zara\s+bhi\s+mat\s+socho\s+aur\s+', ''),
    ]
    for pat, rep in deceptive_negations:
        norm = re.sub(pat, rep, norm, flags=re.IGNORECASE)

    # 2. Correct Common Entity and Action Typos
    typo_mappings = [
        (r'\bchorme\b', 'chrome'),
        (r'\bchromee\b', 'chrome'),
        (r'\bnotepda\b', 'notepad'),
        (r'\bnotepadd\b', 'notepad'),
        (r'\bfirexfox\b', 'firefox'),
        (r'\bforefox\b', 'firefox'),
        (r'\bedeg\b', 'edge'),
        (r'\bvld\b', 'vlc'),
        (r'\bcalclator\b', 'calc'),
        (r'\bclac\b', 'calc'),
        (r'\bwidnow\b', 'window'),
        (r'\bdiadnose\b', 'diagnose'),
        (r'\bdiganose\b', 'diagnose'),
        (r'\bproecss\b', 'process'),
        (r'\bstauts\b', 'status'),
        (r'\bstatsu\b', 'status'),
        (r'\bintrenet\b', 'internet'),
        (r'\bintrnet\b', 'internet'),
        (r'\bnetwrk\b', 'network'),
        (r'\bflie\b', 'file'),
        (r'\bfloder\b', 'folder'),
        (r'\bdokuments\b', 'documents'),
        (r'\bchla\s+do\b', 'chalao'),
        (r'\bchlao\b', 'chalao'),
        (r'\bkhl\s+do\b', 'kholo'),
        (r'\bmasla\s+he\b', 'masla hai'),
        (r'\bdekhna\s+zara\b', 'check karo'),
        (r'\bkrlena\b', 'karo'),
        (r'\bcheck\s+krdo\b', 'check karo'),
        (r'\bkrdo\b', 'karo'),
    ]
    for pat, rep in typo_mappings:
        norm = re.sub(pat, rep, norm, flags=re.IGNORECASE)

    return norm


def detect_conversational_intent(text: str) -> tuple[bool, str, str]:
    """
    Classifies conversational inputs, greetings, help queries, user feedback/criticism,
    and general knowledge questions that should bypass OS tool execution.

    Returns:
        (is_conversational: bool, category: str, language: str)
        category in ('greeting', 'capability', 'feedback', 'general_qa', 'none')
        language in ('en', 'ur')
    """
    if not text:
        return False, "none", "en"

    t = text.strip().lower()
    clean = re.sub(r'^[,\.\!\?\;\:\s]+|[,\.\!\?\;\:\s]+$', '', t)
    clean = re.sub(r'\s+', ' ', clean)

    # 1. Greetings & Pleasantries
    greetings_exact = {
        "hello", "hi", "hlo", "hey", "salam", "slaam", "assalam o alaikum", "assalam-o-alaikum",
        "assalamu alaikum", "assalamualaikum", "kaise ho", "kese ho", "kya haal hai", "kya hal hai",
        "kya haal hy", "kya hal hy", "good morning", "good afternoon", "good evening", "good night",
        "namaste", "adaab", "hey there", "hi there", "hello there", "kya scene hai", "kya chal raha hai",
        "sab theek", "kya haal", "kya hal", "kaisay ho", "kaisey ho", "hello goku", "hi goku",
        "hey goku", "hlo goku", "salam goku", "kya haal hai goku", "kya hal hai goku"
    }
    if clean in greetings_exact:
        is_ur = any(w in clean for w in ["salam", "kaise", "kese", "haal", "hal", "namaste", "adaab", "chal", "theek", "kaisay", "scene", "hai"])
        return True, "greeting", "ur" if is_ur else "en"

    # 2. Capabilities & Help Inquiries
    capabilities_exact = {
        "who are you", "tum kaun ho", "kaun ho tum", "what can you do", "kya kar sakte ho",
        "help", "help me", "madad karo", "madad chahiye", "introduce yourself",
        "apna taruf karao", "tell me about yourself", "apne bare mein batao",
        "what are your capabilities", "what are your features", "system capabilities",
        "what do you do", "aap kya kar sakte hain", "aap kaun hain", "tum kya ho",
        "what are you", "what is your name", "tumhara naam kya hai", "who made you"
    }
    if clean in capabilities_exact:
        is_ur = any(w in clean for w in ["tum", "kaun", "kya", "madad", "taruf", "bare", "aap", "naam"])
        return True, "capability", "ur" if is_ur else "en"

    # 3. Conversational Feedback / Criticism
    feedback_patterns = [
        r'\byou\s+(?:have\s+)?opened?\s+just\b',
        r'\byou\s+(?:just\s+)?open(?:ed)?\s+just\b',
        r'\byou\s+open\s+just\b',
        r'\byou\s+opened\b',
        r'\bwhy\s+did\s+you\s+open\b',
        r'\bwhy\s+(?:open|opened)\b',
        r'\byeh\s+kya\s+khol\s+diya\b',
        r'\byeh\s+kya\s+kiya\b',
        r'\byeh\s+kya\s+kar\s+diya\b',
        r'\bmaine\s+yeh\s+nahi\s+(?:kaha|bola)\b',
        r'\b(?:ma\s+na|maine|main\s+ne|mein\s+ne)\s+(?:ya|yeh|ye|yeh\s+to|ye\s+to)?\s*(?:ni|nahi|nhi)\s+(?:kha|kaha|bola|bola\s+tha|kaha\s+tha)\b',
        r'\b(?:abb|ab)\s+(?:tu|tum)\s+na\b',
        r'\b(?:abb|ab)\s+tu\s+na\b',
        r'\b(?:ya|yeh|ye)\s+(?:ni|nahi|nhi)\s+(?:kha|kaha|bola|bola\s+tha|kaha\s+tha)\b',
        r'\b(?:ye|yeh|ya)\s+(?:to\s+)?(?:nahi|ni)\s+(?:kaha|bola|kha)\b',
        r'\b(?:ma\s+na\s+ya\s+ni\s+kha|abb\s+tu\s+na)\b',
        r'\bthats\s+not\s+what\s+i\s+meant\b',
        r'\bthat\'s\s+not\s+what\s+i\s+meant\b',
        r'\bnot\s+that\b',
        r'^no\s+(?:thats|that\'s|it\'s|its|not|games)\b',
        r'^nahi\s+(?:wo|yeh|ye|woh|games)\b',
        r'\bthat\s+is\s+wrong\b',
        r'\bwrong\s+app\b',
        r'\bthat\'s\s+wrong\b',
        r'\byou\s+made\s+a\s+mistake\b',
        r'\byou\s+did\s+it\s+wrong\b',
        r'\bi\s+did\s+not\s+ask\s+for\b',
        r'\bnot\s+this\s+one\b',
        r'\bnot\s+this\b',
        r'\bgalat\s+hai\b',
        r'^wrong$',
    ]
    for pat in feedback_patterns:
        if re.search(pat, clean):
            is_ur = any(w in clean for w in ["yeh", "ye", "ya", "kya", "khol", "galat", "maine", "nahi", "ni", "kha", "tu", "abb", "ab", "kar", "dia", "tha"])
            return True, "feedback", "ur" if is_ur else "en"

    # 4. General Information Questions (Q&A)
    qa_starters = [
        "what is", "who is", "why is", "how does", "explain", "tell me about",
        "difference between", "meaning of", "define", "write a poem", "tell a joke",
        "tell me a joke", "what are the", "can you explain", "what does",
        "when was", "where is", "capital of", "who wrote"
    ]
    os_keywords = [
        "file", "files", "folder", "folders", "directory", "app", "apps", "application",
        "process", "processes", "wifi", "wi-fi", "network", "internet", "cpu", "ram",
        "memory", "disk", "drive", "storage", "battery", "device", "devices", "window",
        "screen", "volume", "brightness", "service", "services", "bluetooth", "mouse", "cursor",
        "fail", "failed", "failure", "step", "steps", "action", "actions", "task", "tasks",
        "status", "progress", "reasoning", "hypothesis", "hypotheses", "evidence", "drift",
        "pc", "system", "computer", "laptop", "gateway", "ip", "dns", "ping", "speed",
        "adapter", "ethernet", "port", "firewall", "connection", "connect",
        "lag", "lagging", "slow", "slowness", "stutter", "freeze", "hang", "crash",
        "root cause", "root", "cause", "wajah", "asal", "remediation", "remedy", "fix",
        "solution", "resolve", "subsystem", "subsystems", "frontier", "lineage",
        "telemetry", "diagnostic", "diagnostics", "performance", "usage", "temp", "temperature",
        "open", "close", "kholo", "band", "run", "start", "stop", "kill", "terminate",
        "delete", "remove", "install", "download", "search", "find", "read", "show",
        "dikhao", "batao", "history", "checkpoint", "undo", "rollback", "verify",
        "clipboard", "copy", "paste", "calc", "calculator", "browser", "tab", "chrome", "edge", "cmd", "powershell", "terminal"
    ]
    clean_words = set(re.findall(r'\b[a-zA-Z0-9_\-]+\b', clean))
    for qs in qa_starters:
        if clean.startswith(qs):
            has_os = any((k in clean_words if len(k) <= 4 else k in clean) for k in os_keywords)
            if not has_os:
                return True, "general_qa", "en"

    # Urdu general Q&A patterns
    if clean.endswith("kya hota hai") or clean.endswith("kya hai") or clean.endswith("kya cheez hai") or clean.endswith("kise kehte hain"):
        has_os = any((k in clean_words if len(k) <= 4 else k in clean) for k in os_keywords)
        if not has_os:
            return True, "general_qa", "ur"

    return False, "none", "en"


