from __future__ import annotations
import os
from pathlib import Path
import re
import sys
import time
from typing import Any, Optional, Union, List, Dict, Tuple
from dataclasses import dataclass, field

from brain.planner import (
    Plan,
    PlanStep,
    StructuredIntent,
    create_plan_from_decision,
    decompose_compound_command,
    parse_compound_request,
    resolve_step_variables,
    resolve_step_variables_with_guard,
    inject_plan_prerequisites,
    prune_plan_steps,
    build_hypothesis_investigation_plan,
    build_root_cause_investigation_plan,
    parse_conditional_goal,
    synthesize_adaptive_replan,
    decompose_into_milestones,
    restore_plan_from_checkpoint,
    build_cross_domain_plan,
    apply_cross_domain_transformation,
    build_long_horizon_exploration_plan,
    decompose_long_horizon_goal,
    compute_state_hash,
    detect_state_cycle,
    heuristic_node_score,
    expand_exploration_frontier,
    select_next_frontier_node,
    apply_reflective_history_pruning,
)
from command_layer.cognitive_reasoner import CognitiveReasoner
from command_layer.context import (
    EntityType,
    TypedEntity,
    ORDINAL_REFERENCES,
    SessionContext,
    resolve_references,
    session_context,
    update_context_from_result,
)
from command_layer.semantic_model import (
    SemanticDomain,
    SemanticAction,
    CommandIntent,
    AmbiguityType,
    ClarificationRequest,
    SymptomCategory,
    SituationType,
    ConfidenceTier,
    RiskTier,
    ConfidenceScore,
    ConfirmationRequest,
    FailureType,
    AdaptiveStrategy,
    PlanAdaptation,
    TaskLifecycleState,
    TaskMilestone,
    TaskCheckpoint,
    DomainBridgeType,
    DomainBridgeLink,
    CrossDomainWorkflow,
    HorizonDepth,
    ExplorationNode,
    SearchFrontier,
    LongHorizonReport,
    HistoryQueryType,
    ExecutionTraceRecord,
    TraceSummary,
)
from command_layer.semantic_parser import (
    parse_semantic_intent,
    create_plan_from_intent,
    resolve_in_turn_correction,
    strip_conversational_noise,
    split_compound_clauses,
    detect_symptom_category,
)
from command_layer.firewall import validate_tool_against_firewall, pre_execution_semantic_check, validate_long_horizon_action
from command_layer.state_machine import agent_state
from command_layer.validator import validate_and_sanitize_tool_arguments
from command_layer.lexer import UniversalLexer
from brain.runtime_bus import RuntimePipingBus
from security.state import confirmation_manager
from tools.utils.app_resolver import (
    APP_ALIASES,
    get_canonical_app_name,
    resolve_app,
)
from tools.utils.target_resolver import TargetType, resolve_universal_target, disambiguate_multi_candidates
from command_layer.router_base import (
    Step,
    run_tool_call,
    resolve_system_canonical_path,
    verify_post_recovery,
    verify_semantic_outcome,
    capture_environment_snapshot,
    capture_step_observation,
    detect_environment_drift,
    _entity_val,
    get_all_schemas,
    KNOWN_SITE_KEYS,
    KNOWN_APP_NAMES,
    _has_file_extension,
    _normalize_resolved_path,
    _is_conversational_folder_path,
)
from security.safety_firewall import is_safe_readonly_operation
from security.confirm import RISKY_TOOLS
from command_layer.decomposer import count_action_verbs
from brain.workflow_orchestrator import orchestrate_compound_workflow
from tools.browser import sanitize_search_query
from tools.search import parse_search_grammar
import executor.verifier
import executor.executor

from command_layer.router_sanitizer import (
    _isolate_browser_context,
    prune_negated_steps,
    sanitize_action_query,
    sanitize_url,
    _canonicalize_plan_tools,
    sanitize_ui_target,
    extract_clean_search_query,
)
from command_layer.router_cli_parser import (
    translate_cli_command,
    sanitize_cli_command,
    extract_pure_text_payload,
    parse_sequential_keyboard_actions,
    is_standalone_navigation_request,
    resolve_temporal_order,
    strip_idiomatic_conditions,
)
from command_layer.router_confidence import (
    determine_risk_tier,
    format_uncertainty_response,
    compute_command_confidence,
    synthesize_cross_domain_report,
    synthesize_long_horizon_report,
    get_conversational_response,
)
from command_layer.router_classifier_core import _classify_and_parse_command

from command_layer.router_interceptors import intercept_user_command
from command_layer.router_dispatch import dispatch_and_resolve_plan
from command_layer.router_step_executor import execute_step_precondition_and_dispatch
from command_layer.router_step_verifier import post_process_step_execution

def synthesize_final_execution_output(
    plan: Plan,
    session_context: Any,
    step_results: dict[int, dict],
    output_messages: list[str],
    executed_tools: list[str],
    intermediate_traces: list[dict[str, Any]],
    step_contract_records: list[dict[str, Any]],
    unverified_steps: dict[int, str],
    active_hypothesis_ledger: Any,
    agent_state: Any,
    raw_input: str,
    executed_args: list[dict] = None,
    step_idx: int = 0,
    early_exit_triggered: bool = False,
) -> str:
    if executed_args is None:
        executed_args = []
    normalized_input = raw_input
    active_domain = getattr(plan, "domain", None) or SemanticDomain.UNKNOWN
    active_action = getattr(plan, "action", None) or SemanticAction.OPEN
    semantic_intent = getattr(plan, "semantic_intent", None)
    trace_id = getattr(session_context, "current_trace_id", None) or f"trace_{int(time.time()*1000)}"
    print(f"[DEBUG_TRACE] STOP\n")
    
    # Bullet #26: Post-Execution Task Completion & Context Hygiene (4 GB RAM Invariant)
    if session_context.task_checkpoint or agent_state.task_state in (TaskLifecycleState.IN_PROGRESS, TaskLifecycleState.RESUMING):
        if step_idx >= len(plan.steps) or early_exit_triggered:
            agent_state.transition_task_state(TaskLifecycleState.COMPLETED)
            session_context.clear_task_checkpoint()
    
    # Bullet #25: Post-Execution Holistic Outcome Verification & Goal Auditing
    import executor.verifier
    from command_layer.semantic_model import OutcomeVerdict
    outcome_report = executor.verifier.verify_overall_outcome(
        plan=plan,
        execution_results=step_results,
        session_context=session_context
    )
    if outcome_report is not None:
        session_context.record_outcome_report(outcome_report)
    
    is_verified = (
        outcome_report.verdict == OutcomeVerdict.GOAL_ACHIEVED
        if outcome_report is not None and outcome_report.verdict != OutcomeVerdict.VERIFICATION_INCONCLUSIVE
        else (all(r.get("verified", False) for r in step_results.values()) if step_results else False)
    )
    
    agent_state.record_execution(
        trace_id=trace_id,
        user_cmd=raw_input,
        norm_cmd=normalized_input,
        domain=active_domain,
        action=active_action,
        tools=executed_tools,
        args=executed_args,
        success=True if (outcome_report is None or outcome_report.verdict != OutcomeVerdict.GOAL_UNFULFILLED) else False,
        verified=is_verified,
        status=(
            "early_exit_conclusive" if early_exit_triggered
            else "outcome_unfulfilled" if (outcome_report and outcome_report.verdict == OutcomeVerdict.GOAL_UNFULFILLED)
            else "completed"
        ),
        intermediate_traces=intermediate_traces
    )
    
    # Bullet #29: Self-History & Execution Trace Ledger Recording
    telemetry_snap: dict[str, Any] = {}
    for r in step_results.values():
        if isinstance(r, dict):
            for k in (
                "wifi_status", "is_connected", "connected", "ssid", "network_status",
                "free_gb", "free_space_gb", "free_space", "percent_used", "total_gb",
                "cpu_percent", "cpu_usage", "ram_percent", "memory_percent", "free_ram_gb",
                "status", "overall_status", "count", "processes_count"
            ):
                if k in r:
                    telemetry_snap[k] = r[k]
    
    trace_success = True if (outcome_report is None or outcome_report.verdict != OutcomeVerdict.GOAL_UNFULFILLED) and all(r.get("success", True) for r in step_results.values()) else False
    trace_err_type = None
    trace_err_msg = None
    if not trace_success:
        for r in step_results.values():
            if isinstance(r, dict) and (not r.get("success", True) or r.get("status") == "failed"):
                trace_err_type = r.get("error_type") or r.get("status") or "ExecutionError"
                trace_err_msg = r.get("error") or r.get("message") or "Step execution failed"
                break
        if not trace_err_type and outcome_report and outcome_report.verdict == OutcomeVerdict.GOAL_UNFULFILLED:
            trace_err_type = "GoalUnfulfilled"
            trace_err_msg = "; ".join(outcome_report.discrepancies) if outcome_report.discrepancies else "Physical goal outcome unfulfilled"
    
    trace_verdict = (
        "COMPLETED" if trace_success
        else ("EARLY_EXIT" if early_exit_triggered
        else ("CYCLE_HALTED" if getattr(plan, "search_frontier", None) and plan.search_frontier.cycle_detected
        else ("BUDGET_EXHAUSTED" if getattr(plan, "search_frontier", None) and plan.search_frontier.budget_remaining <= 0
        else "FAILED")))
    )
    
    turn_trace = ExecutionTraceRecord(
        turn_id=len(session_context.execution_trace_ledger) + 1,
        session_id=trace_id or "session_default",
        timestamp=time.time(),
        raw_command=raw_input,
        intent=getattr(plan, "explanation", "") or "direct_query",
        tools_called=list(executed_tools),
        tool_args=list(executed_args),
        results_summary=[str(r.get("summary") or r.get("message") or "") for r in step_results.values() if isinstance(r, dict)],
        success=trace_success,
        error_type=trace_err_type,
        error_message=trace_err_msg,
        outcome_verdict=trace_verdict,
        telemetry_snapshot=telemetry_snap,
    )
    session_context.record_turn_trace(turn_trace)
    
    # Bullet #28: Long-Horizon Autonomous Exploration Synthesis
    if getattr(plan, "is_long_horizon", False) or getattr(plan, "synthesis_mode", "") == "long_horizon_synthesis":
        return synthesize_long_horizon_report(plan, step_results, user_goal=raw_input, session_context=session_context)
    
    # Bullet #27: Cross-Domain Multi-Subsystem Synthesis
    if getattr(plan, "is_cross_domain", False) or getattr(plan, "synthesis_mode", "") == "cross_domain_synthesis":
        return synthesize_cross_domain_report(plan, step_results, user_goal=raw_input, session_context=session_context)
    
    # Bullet #17: Hypothesis Investigation Synthesis
    if getattr(plan, "synthesis_mode", "") == "hypothesis_investigation_synthesis":
        from tools.diagnostic_synthesizer import format_hypothesis_ledger
        if active_hypothesis_ledger is not None:
            return format_hypothesis_ledger(active_hypothesis_ledger)
        elif session_context.last_hypothesis_ledger is not None:
            return format_hypothesis_ledger(session_context.last_hypothesis_ledger)
    
    # Bullet #18: Root-Cause Analysis Synthesis
    if getattr(plan, "synthesis_mode", "") == "root_cause_analysis_synthesis":
        from tools.diagnostic_synthesizer import trace_root_cause, format_root_cause_report
        symptom_str = plan.explanation.replace("root_cause_investigation:", "")
        rc_report = trace_root_cause(symptom_str, step_results)
        session_context.record_root_cause_report(rc_report)
        return format_root_cause_report(rc_report)
    
    # Holistic Investigation Diagnostic Synthesis (Level 2 Consolidated & Bullet #12)
    if getattr(plan, "synthesis_mode", "") == "investigation_synthesis":
        from tools.diagnostic_synthesizer import (
            synthesize_investigation_report,
            format_investigation_report,
            correlate_symptom_evidence,
            format_evidence_packet,
        )
    
        inv_report = synthesize_investigation_report(step_results, user_goal=raw_input, domain=plan.explanation)
    
        # Bullet #12: Correlate and package distilled evidence
        telemetry_aggregate: dict[str, Any] = {}
        for r in step_results.values():
            if isinstance(r, dict):
                for k, v in r.items():
                    if k not in telemetry_aggregate:
                        telemetry_aggregate[k] = v
                    elif isinstance(v, dict) and isinstance(telemetry_aggregate[k], dict):
                        telemetry_aggregate[k].update(v)
                if "evidence" in r and isinstance(r["evidence"], dict):
                    telemetry_aggregate.update(r["evidence"])
    
        target_entity = None
        for ent in ["chrome", "edge", "firefox", "notepad", "code", "python", "teams", "explorer"]:
            if ent in raw_input.lower():
                target_entity = ent
                break
    
        total_ram = None
        mem_info = telemetry_aggregate.get("memory", telemetry_aggregate)
        if isinstance(mem_info, dict):
            total_ram = mem_info.get("total_gb")
    
        symp_cat = (
            getattr(semantic_intent, "symptom_category", None)
            or (SymptomCategory.RAM_EXHAUSTION if any(w in raw_input.lower() for w in ["ram", "memory"]) else SymptomCategory.CPU_SLUGGISHNESS)
        )
    
        evidence_packet = correlate_symptom_evidence(
            symptom_cat=symp_cat,
            raw_telemetry=telemetry_aggregate,
            user_goal=raw_input,
            target_entity=target_entity,
            total_ram_gb=total_ram,
        )
        session_context.set_evidence_packet(evidence_packet)
    
        # Bullet #16: Empirical Deductive Reasoning & Contradiction Detection
        from tools.diagnostic_synthesizer import (
            deduce_diagnostic_inference,
            format_inference_result,
            InferenceVerdict,
        )
        inference = deduce_diagnostic_inference(telemetry_aggregate, user_claim=raw_input)
        session_context.record_inference(inference)
    
        if inference.verdict == InferenceVerdict.CONTRADICTED:
            return inference.user_explanation
    
        # If targeted entity resource inquiry, return the concise authoritative EvidencePacket
        is_targeted_claim = target_entity or any(w in raw_input.lower() for w in [
            "eating", "saari ram", "consume", "kitni ram", "kitna cpu", "heavy", "all ram",
            "using ram", "using cpu", "memory use", "cpu use"
        ])
        if is_targeted_claim and plan.explanation == "entity_resource":
            return format_evidence_packet(evidence_packet)
    
        return format_investigation_report(inv_report)
    
    # Holistic Diagnostic Synthesis (Section 34 & 35)
    if getattr(plan, "synthesis_mode", "") == "diagnostic_synthesis" or any(t == "diagnose_system" for t in executed_tools):
        from tools.diagnostic_synthesizer import (
            deduce_diagnostic_inference,
            format_inference_result,
            InferenceVerdict,
        )
        inference = deduce_diagnostic_inference(step_results, user_claim=raw_input)
        session_context.record_inference(inference)
    
        if inference.verdict == InferenceVerdict.CONTRADICTED:
            return inference.user_explanation
    
        diag_res = None
        for res in step_results.values():
            if isinstance(res, dict) and ("overall_status" in res or "status" in res) and "evidence" in res:
                diag_res = res
                break
        if diag_res:
            stat = diag_res.get("overall_status") or diag_res.get("status", "OK")
            lines = [
                "=== SYSTEM HEALTH SYNTHESIS ===",
                f"Overall Status: {stat}",
                f"Severity: {stat}",
                f"Confidence: {diag_res.get('confidence', 'HIGH')}",
                f"Summary: {diag_res.get('summary', '')}",
            ]
            issues = diag_res.get("issues", [])
            if issues:
                lines.append("Detected Issues:")
                for iss in issues:
                    lines.append(f"  - Subsystem: {iss.get('subsystem', '').upper()} | Issue: {iss.get('issue')} | Cause: {iss.get('cause', 'N/A')}")
            elif diag_res.get("issue"):
                subsys = diag_res.get('affected_subsystems', ['SYSTEM'])
                s_name = subsys[0].upper() if subsys else 'SYSTEM'
                lines.append("Detected Issues:")
                lines.append(f"  - Subsystem: {s_name} | Issue: {diag_res.get('issue')} | Cause: {diag_res.get('cause', 'N/A')}")
            else:
                lines.append("Detected Issues: None. All monitored subsystems are healthy.")
            recs = diag_res.get("recommendations", [])
            if recs:
                lines.append("Recommended Actions:")
                for r in recs:
                    lines.append(f"  - {r}")
            lines.append("Evidence: Real-time telemetry collected across CPU, Memory, Storage, Network, and Applications.")
            return "\n".join(lines)
        else:
            from tools.diagnostic_synthesizer import synthesize_investigation_report, format_investigation_report
            inv_report = synthesize_investigation_report(step_results, user_goal=raw_input, domain=plan.explanation)
            return format_investigation_report(inv_report)
    
    # Bullet #16: Record diagnostic inference if any diagnostic tools executed in standard plan
    if any(t in ("get_network_status", "get_wifi_status", "test_internet_connectivity", "get_cpu_status", "get_ram_status", "get_memory_status", "get_storage_status", "get_drive_status", "get_process_status", "diagnose_system", "diagnose_network", "diagnose_cpu", "diagnose_memory", "diagnose_storage") for t in executed_tools):
        from tools.diagnostic_synthesizer import (
            deduce_diagnostic_inference,
            format_inference_result,
            InferenceVerdict,
        )
        inference = deduce_diagnostic_inference(step_results, user_claim=raw_input)
        session_context.record_inference(inference)
        if inference.verdict == InferenceVerdict.CONTRADICTED:
            return inference.user_explanation
    
    if step_contract_records and (len(plan.steps) > 1 or any(rec["status"] in ("FAILED", "UNVERIFIED") for rec in step_contract_records)):
        task_verified = all(rec["status"] == "VERIFIED" for rec in step_contract_records)
        overall_status = "VERIFIED" if task_verified else ("FAILED" if any(rec["status"] == "FAILED" for rec in step_contract_records) else "UNVERIFIED")
        lines = [f"Task Status: {overall_status}", "Steps:"]
        for rec in step_contract_records:
            st = rec["status"]
            ev = rec.get("evidence") or rec.get("reason")
            ev_str = str(ev)
            if isinstance(ev, dict) and "reason" in ev:
                ev_str = ev["reason"]
            elif isinstance(ev, dict) and "control_text" in ev:
                ev_str = f"read back: '{ev['control_text']}'"
            elif isinstance(ev, dict) and "path" in ev:
                if ev.get("exists") is False:
                    ev_str = rec.get("reason") or f"file does not exist at '{ev['path']}'"
                else:
                    ev_str = f"file on disk: '{ev['path']}' ({ev.get('size_bytes', 0)} bytes)"
            lines.append(f"{rec['step']}. {rec['tool']} -> {st} ({ev_str})")
        return "\n".join(lines)
    
    # False-Success Gating (Bullet #25): If tools reported superficial success but physical outcome audit failed
    if outcome_report is not None and outcome_report.verdict == OutcomeVerdict.GOAL_UNFULFILLED:
        disc_text = "; ".join(outcome_report.discrepancies) if outcome_report.discrepancies else "Physical goal outcome unfulfilled."
        rem_text = f" Suggested remediation: {outcome_report.remediation_suggested}" if outcome_report.remediation_suggested else ""
        return f"Outcome verification failed: {disc_text}.{rem_text}".strip()
    
    if outcome_report is not None and outcome_report.verdict == OutcomeVerdict.PARTIALLY_ACHIEVED:
        disc_text = "; ".join(outcome_report.discrepancies) if outcome_report.discrepancies else "Some targets unfulfilled."
        rem_text = f" Remediation: {outcome_report.remediation_suggested}" if outcome_report.remediation_suggested else ""
        output_messages.append(f"[Partially Achieved: {disc_text}.{rem_text}]")
    
    if len(output_messages) == 1:
        return output_messages[0]
    
    return "\n".join(f"- {m}" for m in output_messages)
    


def handle_command(user_text: str, session_context: Any = None, plan: Plan | None = None) -> str:
    """
    Main entry point for command execution.
    Normalizes input, checks pending confirmations, routes deterministically,
    falls back to LLM only if necessary, validates arguments, executes, and updates context.
    """
    os.environ.setdefault("GOKU_SANDBOX", "1")
    os.environ.setdefault("GOKU_MODE", "dev")

    if session_context is None:
        from command_layer.context import session_context as _default_ctx
        session_context = _default_ctx

    # Session-Scoped Rollbacks: Clear compensation / rollback stack per turn
    from executor.transaction_manager import clear_rollback_stack
    clear_rollback_stack(session_context)

    # Session-Scoped App Spawns: Clear turn-scoped spawned apps
    from tools.universal_operator import clear_spawned_apps
    clear_spawned_apps()

    try:
        import psutil
        session_context._turn_start_ram_mb = round(psutil.virtual_memory().used / (1024 * 1024), 2)
    except Exception:
        pass

    raw_input = re.sub(r'[\x00-\x1f\x7f]+$', '', user_text).strip()
    raw_input = re.sub(r'[\x13\x03\x1b]', '', raw_input).strip()
    raw_input = strip_idiomatic_conditions(raw_input)
    raw_input = resolve_temporal_order(raw_input)
    if not raw_input:
        return "Please provide a command."

    # Pre-interceptors
    inter_res = intercept_user_command(user_text, session_context=session_context, raw_input=raw_input, plan=plan)
    if isinstance(inter_res, tuple) and len(inter_res) == 3 and inter_res[0] is False:
        plan = inter_res[2]
    else:
        if isinstance(inter_res, tuple):
            return inter_res[1]
        return inter_res

    # Dispatch & Plan Resolution
    disp_res = dispatch_and_resolve_plan(user_text, session_context=session_context, plan=plan, raw_input=raw_input)
    if isinstance(disp_res, tuple):
        plan, direct_msg = disp_res
        if direct_msg is not None:
            return direct_msg
    else:
        return disp_res

    if plan is None or not getattr(plan, "steps", None):
        return "I am unsure how to assist with that request. Please provide more details."

    print(f"\n[DEBUG_TRACE] USER: \"{raw_input}\"")
    print("[DEBUG_TRACE] PLAN:")
    for idx, step in enumerate(plan.steps, 1):
        print(f"  {idx}. {step.tool}({step.args})")
    print(f"  {len(plan.steps) + 1}. STOP\n")

    step_results: dict[int, dict] = {}
    output_messages: list[str] = []
    executed_tools: list[str] = []
    executed_args: list[dict] = []
    intermediate_traces: list[dict[str, Any]] = []
    early_exit_triggered: bool = False
    early_exit_reason: str = ""
    dynamic_recovery_steps: int = 0
    step_contract_records: list[dict[str, Any]] = []
    unverified_steps: dict[int, str] = {}
    from brain.experience_memory import EpisodicExperienceMemory
    exp_memory = EpisodicExperienceMemory()

    active_hypothesis_ledger = None
    if getattr(plan, "synthesis_mode", "") == "hypothesis_investigation_synthesis":
        symptom_name = plan.explanation.replace("hypothesis_investigation:", "")
        from tools.diagnostic_synthesizer import generate_hypotheses_for_symptom
        active_hypothesis_ledger = session_context.last_hypothesis_ledger or generate_hypotheses_for_symptom(symptom_name)
    elif session_context.last_hypothesis_ledger is not None and getattr(plan, "synthesis_mode", "") in ("diagnostic_synthesis", "investigation_synthesis"):
        active_hypothesis_ledger = session_context.last_hypothesis_ledger
    elif getattr(plan, "synthesis_mode", "") in ("diagnostic_synthesis", "investigation_synthesis"):
        from tools.diagnostic_synthesizer import generate_hypotheses_for_symptom
        active_hypothesis_ledger = generate_hypotheses_for_symptom(raw_input)

    step_idx = 0
    while step_idx < len(plan.steps):
        step = plan.steps[step_idx]
        idx = step_idx + 1

        res1 = execute_step_precondition_and_dispatch(
            step=step,
            idx=idx,
            plan=plan,
            session_context=session_context,
            step_results=step_results,
            output_messages=output_messages,
            executed_tools=executed_tools,
            executed_args=executed_args,
            intermediate_traces=intermediate_traces,
            step_contract_records=step_contract_records,
            unverified_steps=unverified_steps,
            exp_memory=exp_memory,
            active_hypothesis_ledger=active_hypothesis_ledger,
            agent_state=agent_state,
            dynamic_recovery_steps=dynamic_recovery_steps,
            raw_input=raw_input,
        )
        if isinstance(res1, str):
            return res1
        action1, early_return_msg, result = res1
        if early_return_msg is not None:
            return early_return_msg
        if action1 == "BREAK":
            break
        elif action1 == "CONTINUE":
            step_idx += 1
            continue

        sanitized_args = executed_args[-1] if executed_args else step.args
        res2 = post_process_step_execution(
            step=step,
            idx=idx,
            plan=plan,
            session_context=session_context,
            step_results=step_results,
            output_messages=output_messages,
            executed_tools=executed_tools,
            executed_args=executed_args,
            intermediate_traces=intermediate_traces,
            step_contract_records=step_contract_records,
            unverified_steps=unverified_steps,
            exp_memory=exp_memory,
            active_hypothesis_ledger=active_hypothesis_ledger,
            agent_state=agent_state,
            dynamic_recovery_steps=dynamic_recovery_steps,
            raw_input=raw_input,
            sanitized_args=sanitized_args,
            result=result,
        )
        if isinstance(res2, str):
            return res2
        action2, early_msg2 = res2
        if early_msg2 is not None:
            return early_msg2
        if action2 == "BREAK":
            break
        elif action2 == "CONTINUE":
            step_idx += 1
            continue

        step_idx += 1

    print("[DEBUG_TRACE] STOP\n")

    return synthesize_final_execution_output(
        plan=plan,
        session_context=session_context,
        step_results=step_results,
        output_messages=output_messages,
        executed_tools=executed_tools,
        intermediate_traces=intermediate_traces,
        step_contract_records=step_contract_records,
        unverified_steps=unverified_steps,
        active_hypothesis_ledger=active_hypothesis_ledger,
        agent_state=agent_state,
        raw_input=raw_input,
        executed_args=executed_args,
        step_idx=step_idx,
        early_exit_triggered=early_exit_triggered,
    )

route_and_execute = handle_command
