import re
from typing import List, Dict, Any, Tuple


class UniversalLexer:
    """
    Universal Lexer & Stream Splitter.
    Splits user instructions into two isolated token streams:
    (A) Literal Payloads (inside quotes) and
    (B) Behavioral Directives (procedural verbs, hotkeys, conditions).
    Never permits behavioral verbs to contaminate typing payloads.
    """
    ACTION_VERBS = {
        'press_enter': [r'\benter\s+(?:daba\s*(?:kar|ke)?|dabao|press|karo)\b', r'\bnew\s*line\b'],
        'select_all': [r'\bctrl\s*\+\s*a\b', r'\btext\s*select\b', r'\bselect\s*all\b', r'\bpura\s*select\b'],
        'backspace': [r'\bbackspace\b', r'\berase\s*(?:karo|kardo)?\b', r'\bdelete\s*(?:karo|kardo)?\b'],
        'hover_only': [r'\bclick\s+(?:mat|nahi|bilkul\s*mat)\s*(?:karna|karo)?\b', r'\bhover\s*karo\s*lekin\s*click\s*nahi\b', r'\bclick\s+mat\b']
    }

    @staticmethod
    def extract_payloads_and_clauses(text: str) -> Tuple[List[str], List[Dict[str, Any]]]:
        """Separates quoted literal data from structural actions."""
        # 1. Extract string literals
        literals = re.findall(r'["\']([^"\']+)["\']', text)
        
        # 2. Tokenize clauses across compound boundary markers
        clauses_raw = re.split(r'[,;]|\baur\b|\bphir\b|\bthen\b|\buske\s*baad\b', text, flags=re.IGNORECASE)
        processed_clauses = []
        
        for c in clauses_raw:
            c_str = c.strip()
            if not c_str:
                continue
            
            # Check for negation
            is_negated = bool(re.search(r'\b(?:mat|nahi|never|don\'t|dont|stop|bilkul\s*mat)\b', c_str, re.IGNORECASE))
            
            # Detect hotkey actions
            hotkey_type = None
            for h_type, patterns in UniversalLexer.ACTION_VERBS.items():
                if any(re.search(p, c_str, re.IGNORECASE) for p in patterns):
                    hotkey_type = h_type
                    break
            
            processed_clauses.append({
                'raw': c_str,
                'negated': is_negated,
                'action_directive': hotkey_type
            })
            
        return literals, processed_clauses

    @staticmethod
    def is_negated_clause(clause: str) -> bool:
        """Returns True if the clause contains negation markers."""
        return bool(re.search(r'\b(?:mat|nahi|never|don\'t|dont|stop|bilkul\s*mat)\b', clause, re.IGNORECASE))

    @staticmethod
    def should_disarm_click(clause: str) -> bool:
        """Returns True if the clause contains negation of click actions."""
        return bool(re.search(r'\b(?:click\s+(?:mat|nahi|bilkul\s*mat)|hover\s*karo\s*lekin\s*click\s*nahi|click\s+nahi\s+karna)\b', clause, re.IGNORECASE))

    @staticmethod
    def is_action_noise(text: str) -> bool:
        """Returns True if the text is procedural/action noise rather than real typing content."""
        if not text:
            return True
        t_clean = re.sub(r'^(?:ye\s+|ko\s+|bhi\s+)', '', text.strip().lower())
        t_clean = re.sub(r'\s+(?:karo|kar\s*do|kardo|karke|karna|kar)$', '', t_clean).strip()
        noise_phrases = {
            'text select', 'pura select', 'select all', 'text ko select',
            'select', 'sara select', 'sab select', 'select text', 'all select',
            'pura text select', 'sara text select', 'sab text select'
        }
        if t_clean in noise_phrases:
            return True
        return bool(re.search(r'^(?:(?:text|pura|sara|sab|ye)\s+)?select(?:\s+(?:all|text|karo|kar\s*do|kardo))?$', text.strip(), re.IGNORECASE))

