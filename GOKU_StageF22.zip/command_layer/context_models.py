from __future__ import annotations
from dataclasses import dataclass, field
from enum import Enum
import time
from typing import Any

class EntityType(Enum):
    APPLICATION = "APPLICATION"
    FOLDER = "FOLDER"
    FILE = "FILE"
    DRIVE = "DRIVE"
    BROWSER = "BROWSER"
    BROWSER_PROFILE = "BROWSER_PROFILE"
    SEARCH_QUERY = "SEARCH_QUERY"
    SEARCH_RESULT = "SEARCH_RESULT"
    CLIPBOARD = "CLIPBOARD"
    UI_ELEMENT = "UI_ELEMENT"
    WINDOW = "WINDOW"
    DEVICE = "DEVICE"
    BLUETOOTH_DEVICE = "BLUETOOTH_DEVICE"
    PROCESS = "PROCESS"
    SERVICE = "SERVICE"

@dataclass
class TypedEntity:
    value: str
    entity_type: EntityType
    metadata: dict[str, Any] = field(default_factory=dict)
    timestamp: float = field(default_factory=time.time)
    verified: bool = True
    domain: str | None = None
