from __future__ import annotations
import os
from pathlib import Path
import re
import sys
import time
from typing import Any, Optional, Union, List, Dict, Tuple
from dataclasses import dataclass, field

from brain.planner import (
    Plan,
    PlanStep,
    StructuredIntent,
    create_plan_from_decision,
    decompose_compound_command,
    parse_compound_request,
    resolve_step_variables,
    resolve_step_variables_with_guard,
    inject_plan_prerequisites,
    prune_plan_steps,
    build_hypothesis_investigation_plan,
    build_root_cause_investigation_plan,
    parse_conditional_goal,
    synthesize_adaptive_replan,
    decompose_into_milestones,
    restore_plan_from_checkpoint,
    build_cross_domain_plan,
    apply_cross_domain_transformation,
    build_long_horizon_exploration_plan,
    decompose_long_horizon_goal,
    compute_state_hash,
    detect_state_cycle,
    heuristic_node_score,
    expand_exploration_frontier,
    select_next_frontier_node,
    apply_reflective_history_pruning,
)
from command_layer.cognitive_reasoner import CognitiveReasoner
from command_layer.context import (
    EntityType,
    TypedEntity,
    ORDINAL_REFERENCES,
    SessionContext,
    resolve_references,
    session_context,
    update_context_from_result,
)
from command_layer.semantic_model import (
    SemanticDomain,
    SemanticAction,
    CommandIntent,
    AmbiguityType,
    ClarificationRequest,
    SymptomCategory,
    SituationType,
    ConfidenceTier,
    RiskTier,
    ConfidenceScore,
    ConfirmationRequest,
    FailureType,
    AdaptiveStrategy,
    PlanAdaptation,
    TaskLifecycleState,
    TaskMilestone,
    TaskCheckpoint,
    DomainBridgeType,
    DomainBridgeLink,
    CrossDomainWorkflow,
    HorizonDepth,
    ExplorationNode,
    SearchFrontier,
    LongHorizonReport,
    HistoryQueryType,
    ExecutionTraceRecord,
    TraceSummary,
)
from command_layer.semantic_parser import (
    parse_semantic_intent,
    create_plan_from_intent,
    resolve_in_turn_correction,
    strip_conversational_noise,
    split_compound_clauses,
    detect_symptom_category,
)
from command_layer.firewall import validate_tool_against_firewall, pre_execution_semantic_check, validate_long_horizon_action
from command_layer.state_machine import agent_state
from command_layer.validator import validate_and_sanitize_tool_arguments
from command_layer.lexer import UniversalLexer
from brain.runtime_bus import RuntimePipingBus
from security.state import confirmation_manager
from tools.utils.app_resolver import (
    APP_ALIASES,
    get_canonical_app_name,
    resolve_app,
)
from tools.utils.target_resolver import TargetType, resolve_universal_target, disambiguate_multi_candidates
from command_layer.router_base import (
    Step,
    run_tool_call,
    resolve_system_canonical_path,
    verify_post_recovery,
    verify_semantic_outcome,
    capture_environment_snapshot,
    capture_step_observation,
    detect_environment_drift,
    _entity_val,
    get_all_schemas,
    KNOWN_SITE_KEYS,
    KNOWN_APP_NAMES,
    _has_file_extension,
    _normalize_resolved_path,
    _is_conversational_folder_path,
)
from security.safety_firewall import is_safe_readonly_operation
from security.confirm import RISKY_TOOLS
from command_layer.decomposer import count_action_verbs
from brain.workflow_orchestrator import orchestrate_compound_workflow
from tools.browser import sanitize_search_query
from tools.search import parse_search_grammar
import executor.verifier
import executor.executor

from command_layer.router_sanitizer import (
    _isolate_browser_context,
    prune_negated_steps,
    sanitize_action_query,
    sanitize_url,
    _canonicalize_plan_tools,
    sanitize_ui_target,
    extract_clean_search_query,
)
from command_layer.router_cli_parser import (
    translate_cli_command,
    sanitize_cli_command,
    extract_pure_text_payload,
    parse_sequential_keyboard_actions,
    is_standalone_navigation_request,
    resolve_temporal_order,
    strip_idiomatic_conditions,
)
from command_layer.router_confidence import (
    determine_risk_tier,
    format_uncertainty_response,
    compute_command_confidence,
    synthesize_cross_domain_report,
    synthesize_long_horizon_report,
    get_conversational_response,
)

def _classify_and_parse_command(text: str, context: SessionContext | None = None, is_compound_root: bool = True) -> Plan | None:
    from command_layer.router_classifier_core import _classify_and_parse_command as _real_fn
    return _real_fn(text, context, is_compound_root)

def classify_gui_intents_2(text: str, context: SessionContext | None = None, is_compound_root: bool = True) -> Plan | None:
    from command_layer.decomposer import count_action_verbs
    from brain.workflow_orchestrator import orchestrate_compound_workflow
    from tools.browser import sanitize_search_query
    from tools.search import parse_search_grammar
    from security.safety_firewall import is_safe_readonly_operation
    from security.confirm import RISKY_TOOLS
    cleaned = re.sub(r'[\x00-\x1f\x7f]+$', '', text).strip()
    cleaned = re.sub(r'[\x13\x03\x1b]', '', cleaned).strip()
    raw_lower = cleaned.lower()
    lower = text.lower()
    folder_ref_m = re.search(r"folder\s+'([^']+)'", text)
    file_ref_m = re.search(r"file\s+'([^']+)'", text)
    text_unwrapped = re.sub(r'[\'"]([^\'"]+)[\'"]', r'\1', text)
    try:
        symptom_cat, situation_type, symptom_entities = detect_symptom_category(raw_lower)
    except Exception:
        symptom_cat, situation_type, symptom_entities = SymptomCategory.NONE, SituationType.NORMAL, []
    _p2_is_compound_guard = False
    # Matches: "window move karo", "move window"
    if "window move" in lower or "move window" in lower:
        return Plan(steps=[PlanStep(step=1, tool="move_window", args={"x": 100, "y": 100})])

    # Matches: "move mouse to center", "cursor to center", "move the mouse toward the window"
    if any(p in lower for p in [
        "move mouse to center", "mouse to center", "move cursor to center", "cursor to center",
        "move the mouse toward", "move mouse toward", "move cursor toward", "move the mouse to window",
        "move mouse to window", "mouse toward the window"
    ]):
        return Plan(steps=[PlanStep(step=1, tool="move_mouse", args={"x": 683, "y": 384})], explanation="Moved mouse cursor toward target window.")

    # Matches: "where is the mouse cursor located right now?", "cursor position", "mouse position"
    if any(w in lower for w in ["cursor position", "mouse position", "where is the mouse", "cursor located", "mouse cursor located"]):
        return Plan(steps=[PlanStep(step=1, tool="get_cursor_position", args={})])

    # Matches: "point (805, 620) par smooth mouse move karo", "point (100, 200) par move karo", "mouse 500 500 par le jao", "move mouse to 500 300", "cursor 400 400 par le jao"
    coord_move_m = (
        re.search(r'(?:point\s*)?\(?(\d+)[\s,]+(\d+)\)?\s*(?:par|ko|to)?\s*(?:smooth\s*)?(?:mouse|cursor)?\s*(?:move|le\s+jao)', lower)
        or re.search(r'(?:mouse|cursor)\s*(?:move\s+karo|to|par\s+le\s+jao|le\s+jao)?\s*\(?(\d+)[\s,]+(\d+)\)?', lower)
        or re.search(r'move\s+(?:mouse|cursor)?\s*(?:to|par)?\s*(?:point\s*)?\(?(\d+)[\s,]+(\d+)\)?', lower)
    )
    if coord_move_m and ("mouse" in lower or "cursor" in lower or "move" in lower or "point" in lower):
        target_x = int(coord_move_m.group(1))
        target_y = int(coord_move_m.group(2))
        dur_m = re.search(r'(\d+(?:\.\d+)?)\s*(?:seconds?|s|second)\b', lower)
        args_move = {"x": target_x, "y": target_y}
        if "smooth" in lower or dur_m:
            args_move["duration"] = float(dur_m.group(1)) if dur_m else 0.2
        return Plan(steps=[PlanStep(step=1, tool="move_mouse", args=args_move)])

    # Matches: "new tab kholo", "open new tab", "tab kholo"
    if any(p in lower for p in ["new tab kholo", "open new tab", "tab kholo"]):
        return Plan(steps=[PlanStep(step=1, tool="open_url", args={"url": "about:blank", "browser": "chrome"})])

    # Directive 3: "scroll karo", "aur scroll karo", "thoda scroll karo"
    if re.search(r'^(?:aur\s+|thoda\s+)?scroll(?:\s+karo|\s+down)?$', lower.strip()) or lower.strip() in ("scroll karo", "aur scroll karo", "scroll down", "thoda scroll karo"):
        return Plan(steps=[PlanStep(step=1, tool="scroll_active_window", args={"direction": "down", "clicks": 3})])

    # Directive 4: "search karo <query>"
    if re.search(r'^(?:search\s+karo|search\s+kar\s+do)\s+(.+)', lower.strip()):
        q_search = re.sub(r'^(?:search\s+karo|search\s+kar\s+do)\s*', '', text, flags=re.IGNORECASE).strip().strip("'\"")
        return Plan(steps=[PlanStep(step=1, tool="find_and_interact", args={"target_query": q_search, "query": q_search, "action": "type", "text_to_type": q_search})])

    # Component C: Autonomous Visual ReAct Loop for open-ended Web and GUI workflows (Daraz, TikTok, AliExpress, Games, Gallery, etc.)
    # (e.g. "daraz open ker ya wali product find ker scroll kerta ja")
    has_site_or_app = (
        any(re.search(rf'\b{k}\b', lower) for k in KNOWN_SITE_KEYS)
        or any(re.search(rf'\b{k}\b', lower) for k in KNOWN_APP_NAMES)
        or any(k in lower for k in ["daraz", "tiktok", "aliexpress", "gallery", "website", "store", "product", "item"])
    )
    has_open_action = any(w in lower for w in ["open", "kholo", "chalao", "launch", "start", "khol"])
    has_find_or_browse = any(w in lower for w in ["find", "search", "dhundo", "product", "item", "video", "photo", "picture", "dekh"])
    has_scroll_action = any(w in lower for w in ["scroll", "niche", "neeche", "down"])

    if (
        has_site_or_app
        and (has_open_action or "daraz" in lower or "tiktok" in lower)
        and (has_find_or_browse or has_scroll_action)
        and not re.search(r'^[a-zA-Z]:[\\/]', lower)
        and not any(w in lower for w in ["explorer", "file explorer", "folder", "directory"])
    ):
        # Resolve target site or app
        target_site = None
        for k in KNOWN_SITE_KEYS:
            if re.search(rf'\b{k}\b', lower):
                target_site = k
                break
        if not target_site and "daraz" in lower:
            target_site = "daraz"
        elif not target_site and "tiktok" in lower:
            target_site = "tiktok"

        # Resolve find / product query
        find_query = "product"
        target_item_m = re.search(r'(?:ya\s+wali\s+product|product|item|video|photo|search\s+bar|[\w\s]+)\s+(?:find|search|dhundo)', lower)
        if target_item_m:
            matched_q = target_item_m.group(0)
            cleaned_q = re.sub(r'\b(find|search|dhundo|ker|karo|chalao|open)\b', '', matched_q).strip()
            if target_site:
                cleaned_q = re.sub(rf'\b{target_site}\b', '', cleaned_q, flags=re.IGNORECASE).strip()
            if cleaned_q:
                find_query = cleaned_q

        steps = []
        if target_site:
            steps.append(PlanStep(step=1, tool="open_url", args={"url": target_site, "browser": "chrome"}))
        else:
            target_app = "browser"
            for k in KNOWN_APP_NAMES:
                if re.search(rf'\b{k}\b', lower):
                    target_app = k
                    break
            steps.append(PlanStep(step=1, tool="launch_app", args={"name": target_app}))

        steps.append(PlanStep(step=len(steps) + 1, tool="wait_for_ui_settle", args={"timeout_ms": 1000}))
        steps.append(PlanStep(step=len(steps) + 1, tool="find_and_interact", args={"target_query": find_query, "query": find_query, "action": "click"}))
        steps.append(PlanStep(step=len(steps) + 1, tool="scroll_and_inspect", args={"direction": "down", "clicks": 3, "condition": find_query}))

        return Plan(steps=steps)

    # Matches: "neeche scroll karo", "scroll down", "upar scroll karo", "scroll up", "slowly scroll down", "fast scroll down", "slowly scroll for 5 seconds"
    if "scroll" in lower:
        direction = "up" if any(w in lower for w in ["up", "upar", "top"]) else "down"
        speed = "slow" if ("slow" in lower or "slowly" in lower or "ahista" in lower) else ("fast" if ("fast" in lower or "tez" in lower) else "normal")
        dur = 5.0 if ("5 second" in lower or "5s" in lower or "5 seconds" in lower) else 0.0
        clicks = 5 if speed == "slow" else (8 if speed == "fast" else 3)
        clicks_m = re.search(r'(\d+)\s*(?:times|bar|ticks|units|clicks)?', lower)
        if clicks_m and not ("5 second" in lower or "5s" in lower or "5 seconds" in lower):
            clicks = int(clicks_m.group(1))
        args_map = {"direction": direction, "clicks": clicks}
        if speed != "normal":
            args_map["speed"] = speed
        if dur > 0.0:
            args_map["duration"] = dur
        return Plan(steps=[PlanStep(step=1, tool="mouse_scroll", args=args_map)])

    # -------------------------------------------------------------
    # 6. KEYBOARD & TYPING AUTOMATION INTENTS (Phase 4B)
    # -------------------------------------------------------------
    # Matches: "hata do is window ko", "is window ko hata do", "close window", "Notepad ko zara side pe hata do"
    if any(p in lower for p in ["hata do is window", "is window ko hata do", "window hata do", "window close karo", "close this window", "side pe hata", "side par hata", "side pe kar", "side par kar"]):
        return Plan(steps=[PlanStep(step=1, tool="manage_window", args={"action": "minimize"})])

    # Matches: "chota karo window ko", "window ko chota karo", "minimize window"
    if any(p in lower for p in ["chota karo window", "choti karo window", "window ko chota karo", "window ko choti karo"]):
        return Plan(steps=[PlanStep(step=1, tool="manage_window", args={"action": "minimize"})])

    # Matches: "lao samne chrome ko", "chrome ko samne lao"
    if any(p in lower for p in ["lao samne", "samne lao"]):
        cand_app = lower
        cand_app = re.sub(r'\b(lao\s+samne|samne\s+lao|ko|app|program|window|please)\b', '', cand_app).strip()
        cand_app_lower = cand_app.lower().strip()
        is_store_token = cand_app_lower in ("store", "the store", "ms store", "store h", "store kiya", "store tha", "store hai") or (
            "store" in cand_app_lower.split() and not any(w in cand_app_lower for w in ["microsoft store", "windows store"])
        )
        if not is_store_token and (cand_app in KNOWN_APP_NAMES or resolve_app(cand_app) is not None):
            return Plan(steps=[PlanStep(step=1, tool="focus_app", args={"name": cand_app})])

    # Matches: "upar jao thoda", "thoda upar jao", "neeche jao thoda", "thoda neeche jao"
    if any(p in lower for p in ["upar jao", "neeche jao", "niche jao"]):
        direction = "up" if "upar" in lower else "down"
        return Plan(steps=[PlanStep(step=1, tool="mouse_scroll", args={"direction": direction, "clicks": 3})])

    # Matches: "Chrome ke address bar par jao", "address bar par jao", "focus address bar"
    if "address bar" in lower and any(w in lower for w in ["jao", "focus", "par", "click", "le jao", "select"]):
        return Plan(steps=[PlanStep(step=1, tool="press_hotkey", args={"keys": "ctrl+l"})])

    # Matches: "previous tab par jao", "previous tab", "pichli tab", "last tab"
    if any(p in lower for p in ["previous tab", "pichli tab", "last tab par"]):
        return Plan(steps=[PlanStep(step=1, tool="press_hotkey", args={"keys": "ctrl+shift+tab"})])

    # Matches: "webpage reload karo", "page reload", "reload karo", "hard reload karo", "refresh karo", "screen refresh"
    if any(p in lower for p in ["reload karo", "reload page", "webpage reload", "hard reload", "refresh karo", "screen refresh"]):
        hk = "ctrl+f5" if "hard" in lower else "f5"
        return Plan(steps=[PlanStep(step=1, tool="press_hotkey", args={"keys": hk})])

    # Matches: "page zoom in karo", "zoom in"
    if "zoom in" in lower:
        return Plan(steps=[PlanStep(step=1, tool="press_hotkey", args={"keys": "ctrl+plus"})])

    # Matches: "page zoom out karo", "zoom out"
    if "zoom out" in lower:
        return Plan(steps=[PlanStep(step=1, tool="press_hotkey", args={"keys": "ctrl+minus"})])

    # Matches: "zoom reset karo", "reset zoom"
    if "zoom reset" in lower or "reset zoom" in lower:
        return Plan(steps=[PlanStep(step=1, tool="press_hotkey", args={"keys": "ctrl+0"})])

    # Matches: "Bookmarks bar toggle karo", "bookmarks bar"
    if "bookmarks bar" in lower or "bookmark bar" in lower:
        return Plan(steps=[PlanStep(step=1, tool="press_hotkey", args={"keys": "ctrl+shift+b"})])

    # Matches: "page source view karo", "page source"
    if "page source" in lower or "view source" in lower:
        return Plan(steps=[PlanStep(step=1, tool="press_hotkey", args={"keys": "ctrl+u"})])

    # Matches: "document save karo", "file save karo", "kam save karo", "save kar do", "save karo"
    if any(k in lower for k in ["save karo", "save kar do", "save kardo", "save document", "document save", "file save", "kam save"]) and not any(ext in lower for ext in [".txt", ".docx", ".pdf", ".py"]):
        return Plan(steps=[PlanStep(step=1, tool="press_hotkey", args={"keys": "ctrl+s"})])

    # Matches: "wapas desktop par jao", "desktop par jao", "go to desktop", "show desktop"
    if any(p in lower for p in ["desktop par jao", "wapas desktop", "show desktop", "go to desktop"]):
        return Plan(steps=[PlanStep(step=1, tool="press_hotkey", args={"keys": "win+d"})])

    # Matches: "dusri window par jao", "pehle wali application kholo", "previous window", "switch window"
    if any(p in lower for p in ["dusri window", "pehle wali application", "previous window", "switch window par"]):
        return Plan(steps=[PlanStep(step=1, tool="press_hotkey", args={"keys": "alt+tab"})])

    # Matches: "current window ko full screen karo", "fullscreen karo", "full screen karo", "fullscreen exit karo"
    if "full screen" in lower or "fullscreen" in lower:
        return Plan(steps=[PlanStep(step=1, tool="press_hotkey", args={"keys": "f11"})])

    # Matches: "us window ko center mein lao", "center window"
    if "center" in lower and "window" in lower:
        return Plan(steps=[PlanStep(step=1, tool="move_window", args={"x": 200, "y": 150})])

    # Matches: "active window ka title batao", "window title", "focused window", "window focused"
    if any(p in lower for p in ["active window ka title", "active window", "window title", "focused window", "active focus", "focus check karo", "window focused", "focused hai", "kahan focus hai"]):
        return Plan(steps=[PlanStep(step=1, tool="get_active_window", args={})])

    # Visual inspection / Screen observation
    if (
        any(p in lower for p in ["visual delta", "window bounding box", "screen text ocr", "screen inspect", "inspect screen"])
        or ("screen" in lower and any(v in lower for v in ["kya hai", "dekho", "jaiza", "what is on", "what's on", "what is currently", "par kya", "pe kya"]))
    ) and not any(w in lower for w in ["screenshot", "size", "resolution", "lock", "record"]):
        return Plan(steps=[PlanStep(step=1, tool="inspect_screen", args={})])

    # Matches: "next tab par jao", "agli tab", "next tab"
    if any(p in lower for p in ["next tab", "agli tab"]):
        return Plan(steps=[PlanStep(step=1, tool="press_hotkey", args={"keys": "ctrl+tab"})])

    # Matches: "pehli tab par jao", "1st tab", "ctrl+1", "pehle tab", "tab par aao"
    if any(p in lower for p in ["pehli tab", "pehle tab", "pehla tab", "first tab", "tab 1", "ctrl+1", "ctrl + 1", "tab par aao", "tab pe aao"]):
        return Plan(steps=[PlanStep(step=1, tool="press_hotkey", args={"keys": "ctrl+1"})])

    # Matches: "dusri tab par switch karo", "2nd tab", "ctrl+2"
    if any(p in lower for p in ["dusri tab", "doosri tab", "second tab", "tab 2", "ctrl+2", "ctrl + 2"]):
        return Plan(steps=[PlanStep(step=1, tool="press_hotkey", args={"keys": "ctrl+2"})])

    # Matches: "teesri tab par switch karo", "3rd tab", "ctrl+3"
    if any(p in lower for p in ["teesri tab", "third tab", "tab 3", "ctrl+3", "ctrl + 3"]):
        return Plan(steps=[PlanStep(step=1, tool="press_hotkey", args={"keys": "ctrl+3"})])

    # Matches: "aakhri tab par switch karo", "last tab", "ctrl+9"
    if any(p in lower for p in ["aakhri tab", "last tab par switch", "last tab", "ctrl+9", "ctrl + 9"]):
        return Plan(steps=[PlanStep(step=1, tool="press_hotkey", args={"keys": "ctrl+9"})])

    # Matches: "tab band kardo", "close tab", "tab close", "doosra tab band kardo", "current tab close"
    if any(p in lower for p in ["tab band", "close tab", "tab close", "band kardo tab", "tab ko band"]) or (re.search(r'\btab\b', lower) and any(w in lower for w in ["band", "close", "khatam"])):
        return Plan(steps=[PlanStep(step=1, tool="press_hotkey", args={"keys": "ctrl+w"})])

    # Matches: "ctrl+a", "select all"
    if any(p in lower for p in ["ctrl+a", "ctrl + a", "select all", "select all karo", "select all text"]):
        return Plan(steps=[PlanStep(step=1, tool="press_hotkey", args={"keys": "ctrl+a"})])

    # Matches: "backspace", "erase karo"
    if any(p in lower for p in ["backspace", "backspace dabao", "erase karo", "erase kar do", "erase kardo", "erase text"]):
        return Plan(steps=[PlanStep(step=1, tool="press_hotkey", args={"keys": "backspace"})])

    # Matches: "enter dabao", "press enter"
    if any(p in lower for p in ["enter dabao", "press enter", "enter press karo", "enter daba kar", "enter key"]):
        return Plan(steps=[PlanStep(step=1, tool="press_hotkey", args={"keys": "enter"})])

    # Matches: "tab reopen karo", "reopen tab", "closed tab reopen"
    if "reopen" in lower and "tab" in lower:
        return Plan(steps=[PlanStep(step=1, tool="press_hotkey", args={"keys": "ctrl+shift+t"})])

    # Matches: "downloads page kholo", "browser downloads"
    if "downloads page" in lower or "downloads history" in lower:
        return Plan(steps=[PlanStep(step=1, tool="press_hotkey", args={"keys": "ctrl+j"})])

    # Matches: "history page open karo", "browser history"
    if "history page" in lower or "history kholo" in lower:
        return Plan(steps=[PlanStep(step=1, tool="press_hotkey", args={"keys": "ctrl+h"})])

    # Matches: "wo text copy karo", "copy karo", "text copy", "Saara text ek dafa copy kar lo"
    if any(p in lower for p in ["copy karo", "text copy", "copy text", "copy kar do", "clipboard copy", "copy kar lo", "copy kar lein", "copy kar"]) and not ("file" in lower or "folder" in lower):
        if any(w in lower for w in ["saara text", "sara text", "sab text"]):
            return Plan(steps=[
                PlanStep(step=1, tool="press_hotkey", args={"keys": "ctrl+a"}),
                PlanStep(step=2, tool="copy_selection_to_clipboard", args={}),
            ])
        return Plan(steps=[PlanStep(step=1, tool="copy_selection_to_clipboard", args={})])

    # Matches: "usko paste karo", "paste karo", "text paste", "paste into notepad"
    if any(p in lower for p in ["paste karo", "text paste", "paste text", "paste kar do", "clipboard paste", "paste into", "paste"]) and not ("file" in lower or "folder" in lower):
        target_app = None
        for app in ("notepad", "edge", "chrome", "word", "excel", "calculator", "explorer", "browser", "code"):
            if app in lower:
                target_app = "Notepad" if app == "notepad" else ("VS Code" if app == "code" else app.capitalize())
                break
        p_args = {}
        if target_app:
            p_args["target_app"] = target_app
        return Plan(steps=[PlanStep(step=1, tool="paste_clipboard_into_target", args=p_args)])

    # Matches: "sab select karo", "select all karo", "select all", "ye text select karo", "text select karo"
    if any(p in lower for p in ["sab select", "select all", "sara text select", "text select", "ye text select", "select text"]):
        return Plan(steps=[PlanStep(step=1, tool="press_hotkey", args={"keys": "ctrl+a"})])

    # Matches: "selection clear karo", "deselect karo", "clear selection"
    if any(p in lower for p in ["selection clear", "deselect", "clear selection"]):
        return Plan(steps=[PlanStep(step=1, tool="press_hotkey", args={"keys": "esc"})])

    # Matches: Calculator math operations ("usme 45 multiply by 2 karo", "45 multiply by 2", "45 * 2 karo")
    calc_math_m = re.search(r'(\d+)\s*(?:multiply(?:\s+by)?|\*|times|x|plus|\+|add(?:ed\s+to)?|minus|\-|subtract(?:ed\s+from)?|divide(?:\s+by)?|\/)\s*(\d+)', lower)
    if calc_math_m and any(w in lower for w in ["karo", "kar", "do", "calculate", "multiply", "divide", "plus", "minus", "calc", "usme"]):
        n1 = calc_math_m.group(1)
        n2 = calc_math_m.group(2)
        op = "*"
        if any(w in lower for w in ["plus", "+", "add"]):
            op = "+"
        elif any(w in lower for w in ["minus", "-", "subtract"]):
            op = "-"
        elif any(w in lower for w in ["divide", "/"]):
            op = "/"
        calc_expr = f"{n1}{op}{n2}="
        return Plan(steps=[PlanStep(step=1, tool="send_keyboard_input", args={"text": calc_expr, "app_name": "Calculator"})])

    # Matches: "undo karo", "undo kar do"
    if "undo karo" in lower or "undo kar do" in lower or lower == "undo":
        return Plan(steps=[PlanStep(step=1, tool="press_hotkey", args={"keys": "ctrl+z"})])

    # Matches: "redo karo", "redo kar do"
    if "redo karo" in lower or "redo kar do" in lower or lower == "redo":
        return Plan(steps=[PlanStep(step=1, tool="press_hotkey", args={"keys": "ctrl+y"})])

    # Matches: "bold karo", "bold toggle"
    if "bold karo" in lower or "bold kar do" in lower:
        return Plan(steps=[PlanStep(step=1, tool="press_hotkey", args={"keys": "ctrl+b"})])

    # Matches: "italic karo"
    if "italic karo" in lower or "italic kar do" in lower:
        return Plan(steps=[PlanStep(step=1, tool="press_hotkey", args={"keys": "ctrl+i"})])

    # Matches: "underline toggle karo", "underline karo"
    if "underline" in lower:
        return Plan(steps=[PlanStep(step=1, tool="press_hotkey", args={"keys": "ctrl+u"})])

    # Matches: "Cancel button dabao", "Next button dabao", "Back button dabao", "OK button click karo"
    btn_m = re.search(r'\b(ok|cancel|save|apply|yes|no|close|search|submit|next|back|finish)\s+(?:button|btn)?\s*(?:par)?\s*(?:physical\s+)?(?:click\s+karo|click\s+kar\s+do|click|dabao|press|hit)\b', lower)
    if btn_m:
        btn_name = btn_m.group(1).capitalize()
        return Plan(steps=[PlanStep(step=1, tool="find_and_interact", args={"target_query": btn_name, "query": btn_name, "action": "click"})])

    # Matches: "context menu mein Text Document par click karo", "context menu mein Large Icons par click karo"
    if "context menu mein" in lower and "click" in lower:
        target = re.sub(r'^(?:context\s+menu\s+mein\s*)', '', text, flags=re.IGNORECASE)
        target = re.sub(r'\s*(?:par\s+click\s+karo|click\s+karo|click\s+kar\s+do|click)\.?$', '', target, flags=re.IGNORECASE).strip()
        return Plan(steps=[PlanStep(step=1, tool="find_and_interact", args={"target_query": target, "query": target, "action": "click"})])

    # Matches: "agar Notepad open hai to focus karo warna kholo", "agar Chrome open hai to new tab kholo warna Chrome kholo"
    if lower.startswith("agar ") and ("open hai" in lower or "khula" in lower):
        app_m = re.search(r'\bagar\s+([a-z\s]+?)\s+(?:open|khula|running)\b', lower)
        if app_m:
            cand_app = app_m.group(1).strip()
            if cand_app in KNOWN_APP_NAMES or resolve_app(cand_app) is not None:
                return Plan(steps=[PlanStep(step=1, tool="focus_app", args={"name": cand_app})])

    # Matches: "I need the Windows search thing, not the browser search", "Windows search open karo", "Start search open karo"
    if ("windows search" in lower or "start search" in lower) or (
        ("search" in lower or "dhundo" in lower) and any(w in lower for w in ["not browser", "not the browser", "no browser", "browser search nahi", "browser nahi"])
    ):
        return Plan(steps=[PlanStep(step=1, tool="press_hotkey", args={"keys": "win+s"})])

    # Matches: "Ctrl C karo", "Ctrl V karo", "PageDown press karo", "Home dabao", "Spacebar press karo", "CapsLock toggle karo", "Ctrl+Shift+Esc"
    expanded_hk_m = re.search(
        r'\b((?:(?:ctrl|alt|win|shift)[\+\s]+)+(?:[a-z0-9]+|esc|escape|enter|tab|space|spacebar|delete|del|backspace|up|down|left|right)|'
        r'pagedown|page\s+down|pageup|page\s+up|home|end|spacebar|space\s+bar|capslock|caps\s+lock|'
        r'windows\s+key|win\s+key|enter|escape|esc|backspace|delete|del|tab|space|'
        r'arrow\s+up|arrow\s+down|arrow\s+left|arrow\s+right|up\s+arrow|down\s+arrow|left\s+arrow|right\s+arrow|f[1-9]|f1[0-2])\b',
        lower
    )
    if expanded_hk_m:
        cand_raw_key = expanded_hk_m.group(1).lower().strip()
        is_isolated_single = cand_raw_key in ("tab", "space", "enter", "delete", "del")
        has_direct_press_action = any(w in lower for w in ["press", "dabao", "hit", "keyboard"]) or ("key" in lower and not any(k in lower for k in ["wifi key", "api key", "product key"]))
        is_browser_or_app_tab = cand_raw_key == "tab" and any(w in lower for w in ["chrome", "browser", "edge", "firefox", "mat", "nayi", "new", "dont", "don't"])
        is_negated_clause = any(w in lower for w in ["mat", "dont", "don't", "nahi", "never"])
        if (
            (not is_isolated_single or (has_direct_press_action and not is_browser_or_app_tab and not is_negated_clause))
            and any(w in lower for w in ["press", "dabao", "karo", "kar do", "hit", "button", "keyboard se", "toggle", "key", "kholo", "open"])
            and not ("wifi" in lower or "window" in lower or "setting" in lower or "settings" in lower or "search" in lower or "folder" in lower or "file" in lower or "likho" in lower or "type" in lower or "downloads" in lower or "desktop" in lower or "isko" in lower or "usko" in lower or "ye" in lower or "yeh" in lower or _has_file_extension(lower) or ("delete" in lower and not ("key" in lower or "button" in lower or "press" in lower or "dabao" in lower or "ctrl" in lower or "shift" in lower or "alt" in lower)))
        ):
            raw_key = re.sub(r'\s+', '+', expanded_hk_m.group(1)).replace("arrow+", "").replace("+arrow", "").replace("windows+key", "win").replace("win+key", "win")
            raw_key = raw_key.replace("page+down", "pagedown").replace("page+up", "pageup").replace("space+bar", "space").replace("spacebar", "space").replace("caps+lock", "capslock")
            return Plan(steps=[PlanStep(step=1, tool="press_hotkey", args={"keys": raw_key})])

    # Phase 2 GUI Controller: direct text typing injection (e.g. "type hello")
    # HARDENED: never intercept if this is a compound command with lifecycle verbs.
    _LIFECYCLE_VERBS_P2 = {"launch", "open", "close", "read", "save", "scan", "kholo", "band", "padhao"}
    _has_any_conj_p2 = bool(re.search(r'\b(?:phir|aur|and|then|after\s+that|pehle)\b', lower))
    _has_lifecycle_p2 = any(v in lower.split() for v in _LIFECYCLE_VERBS_P2) or bool(re.search(r'\b(?:launch|open|close|read|save|scan)\b', lower))
    _p2_conj_count = len(re.findall(r'\b(?:phir|aur|and|then|after\s+that|pehle)\b', lower))
    _p2_is_compound_guard = (_p2_conj_count >= 2) or (count_action_verbs(lower) >= 3) or (_has_any_conj_p2 and _has_lifecycle_p2)


    return None
