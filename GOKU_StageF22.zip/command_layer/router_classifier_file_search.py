from __future__ import annotations
import os
from pathlib import Path
import re
import sys
import time
from typing import Any, Optional, Union, List, Dict, Tuple
from dataclasses import dataclass, field

from brain.planner import (
    Plan,
    PlanStep,
    StructuredIntent,
    create_plan_from_decision,
    decompose_compound_command,
    parse_compound_request,
    resolve_step_variables,
    resolve_step_variables_with_guard,
    inject_plan_prerequisites,
    prune_plan_steps,
    build_hypothesis_investigation_plan,
    build_root_cause_investigation_plan,
    parse_conditional_goal,
    synthesize_adaptive_replan,
    decompose_into_milestones,
    restore_plan_from_checkpoint,
    build_cross_domain_plan,
    apply_cross_domain_transformation,
    build_long_horizon_exploration_plan,
    decompose_long_horizon_goal,
    compute_state_hash,
    detect_state_cycle,
    heuristic_node_score,
    expand_exploration_frontier,
    select_next_frontier_node,
    apply_reflective_history_pruning,
)
from command_layer.cognitive_reasoner import CognitiveReasoner
from command_layer.context import (
    EntityType,
    TypedEntity,
    ORDINAL_REFERENCES,
    SessionContext,
    resolve_references,
    session_context,
    update_context_from_result,
)
from command_layer.semantic_model import (
    SemanticDomain,
    SemanticAction,
    CommandIntent,
    AmbiguityType,
    ClarificationRequest,
    SymptomCategory,
    SituationType,
    ConfidenceTier,
    RiskTier,
    ConfidenceScore,
    ConfirmationRequest,
    FailureType,
    AdaptiveStrategy,
    PlanAdaptation,
    TaskLifecycleState,
    TaskMilestone,
    TaskCheckpoint,
    DomainBridgeType,
    DomainBridgeLink,
    CrossDomainWorkflow,
    HorizonDepth,
    ExplorationNode,
    SearchFrontier,
    LongHorizonReport,
    HistoryQueryType,
    ExecutionTraceRecord,
    TraceSummary,
)
from command_layer.semantic_parser import (
    parse_semantic_intent,
    create_plan_from_intent,
    resolve_in_turn_correction,
    strip_conversational_noise,
    split_compound_clauses,
    detect_symptom_category,
)
from command_layer.firewall import validate_tool_against_firewall, pre_execution_semantic_check, validate_long_horizon_action
from command_layer.state_machine import agent_state
from command_layer.validator import validate_and_sanitize_tool_arguments
from command_layer.lexer import UniversalLexer
from brain.runtime_bus import RuntimePipingBus
from security.state import confirmation_manager
from tools.utils.app_resolver import (
    APP_ALIASES,
    get_canonical_app_name,
    resolve_app,
)
from tools.utils.target_resolver import TargetType, resolve_universal_target, disambiguate_multi_candidates
from command_layer.router_base import (
    Step,
    run_tool_call,
    resolve_system_canonical_path,
    verify_post_recovery,
    verify_semantic_outcome,
    capture_environment_snapshot,
    capture_step_observation,
    detect_environment_drift,
    _entity_val,
    get_all_schemas,
    KNOWN_SITE_KEYS,
    KNOWN_APP_NAMES,
    _has_file_extension,
    _normalize_resolved_path,
    _is_conversational_folder_path,
)
from security.safety_firewall import is_safe_readonly_operation
from security.confirm import RISKY_TOOLS
from command_layer.decomposer import count_action_verbs
from brain.workflow_orchestrator import orchestrate_compound_workflow
from tools.browser import sanitize_search_query
from tools.search import parse_search_grammar
import executor.verifier
import executor.executor

from command_layer.router_sanitizer import (
    _isolate_browser_context,
    prune_negated_steps,
    sanitize_action_query,
    sanitize_url,
    _canonicalize_plan_tools,
    sanitize_ui_target,
    extract_clean_search_query,
)
from command_layer.router_cli_parser import (
    translate_cli_command,
    sanitize_cli_command,
    extract_pure_text_payload,
    parse_sequential_keyboard_actions,
    is_standalone_navigation_request,
    resolve_temporal_order,
    strip_idiomatic_conditions,
)
from command_layer.router_confidence import (
    determine_risk_tier,
    format_uncertainty_response,
    compute_command_confidence,
    synthesize_cross_domain_report,
    synthesize_long_horizon_report,
    get_conversational_response,
)

def _classify_and_parse_command(text: str, context: SessionContext | None = None, is_compound_root: bool = True) -> Plan | None:
    from command_layer.router_classifier_core import _classify_and_parse_command as _real_fn
    return _real_fn(text, context, is_compound_root)

def classify_file_search_intents(text: str, context: SessionContext | None = None, is_compound_root: bool = True) -> Plan | None:
    from command_layer.decomposer import count_action_verbs
    from brain.workflow_orchestrator import orchestrate_compound_workflow
    from tools.browser import sanitize_search_query
    from tools.search import parse_search_grammar
    from security.safety_firewall import is_safe_readonly_operation
    from security.confirm import RISKY_TOOLS
    cleaned = re.sub(r'[\x00-\x1f\x7f]+$', '', text).strip()
    cleaned = re.sub(r'[\x13\x03\x1b]', '', cleaned).strip()
    raw_lower = cleaned.lower()
    lower = text.lower()
    folder_ref_m = re.search(r"folder\s+'([^']+)'", text)
    file_ref_m = re.search(r"file\s+'([^']+)'", text)
    text_unwrapped = re.sub(r'[\'"]([^\'"]+)[\'"]', r'\1', text)
    try:
        symptom_cat, situation_type, symptom_entities = detect_symptom_category(raw_lower)
    except Exception:
        symptom_cat, situation_type, symptom_entities = SymptomCategory.NONE, SituationType.NORMAL, []
    _p2_is_compound_guard = False
    # -------------------------------------------------------------
    # 9. FOLDER LISTING & ITEM COUNTING INTENTS
    # -------------------------------------------------------------
    # Matches: "Downloads mein folders dikhao", "list folders in Downloads", "list files in Downloads", "Downloads folder inspect karo"
    if (
        any(w in lower for w in [
            "list files", "files list", "file list", "files dikhao", "list folders", "folders dikhao",
            "list directory", "list karo", "folder contents", "folder ke contents", "contents dikhao",
            "folder dikhao", "directory dikhao", "folder inspect", "folder check karo", "folder mein kya hai"
        ])
        or ("list" in lower and any(f in lower for f in ["downloads", "desktop", "documents", "pictures", "file", "files"]))
        or ("folder" in lower and any(v in lower for v in ["dikhao", "show", "list", "inspect", "check"]))
        or (any(f in lower for f in ["downloads", "desktop", "documents", "pictures"]) and any(v in lower for v in ["inspect karo", "inspect kar", "files inspect", "khol ke dikhao", "khol kar dikhao", "open karke dikhao", "khol ke", "dikhao", "show"]))
    ):
        target_dir = folder_ref_m.group(1) if folder_ref_m else (context.last_active_directory or "Downloads")
        folder_in_text_m = re.search(r'\b(downloads|desktop|documents|pictures)\b', lower)
        if folder_in_text_m:
            target_dir = folder_in_text_m.group(1)
        return Plan(steps=[PlanStep(step=1, tool="list_folder", args={"path": target_dir})])

    # Matches: "is folder mein kitni files hain?", "count files in downloads", "Downloads mein PDF files count karo"
    if "count" in lower or "kitni files" in lower or "kitne items" in lower or "how many files" in lower:
        target_dir = folder_ref_m.group(1) if folder_ref_m else (context.last_active_directory or "Downloads")
        ext_pat = ""
        if "pdf" in lower:
            ext_pat = "pdf"
        elif "txt" in lower:
            ext_pat = "txt"
        elif "png" in lower:
            ext_pat = "png"
        return Plan(steps=[PlanStep(step=1, tool="count_files", args={"path": target_dir, "pattern": ext_pat})])

    # Matches: "wo wala folder khol jaha tu sara notepad save ker raha h", "open reports folder", "reports folder kholo", "open folder where files are saved", "saved folder kholo"
    is_saved_folder_intent = (
        bool(re.search(r'(?:folder\s+khol|open\s+folder|directory\s+khol|folder\s+kholo|directory\s+kholo|open\s+directory|khol\s+(?:wo|woh|us\s+)?wala\s+folder|khol\s+folder|kholo\s+folder).*?(?:save|notepad|reports)', lower))
        or bool(re.search(r'(?:save|notepad|reports).*?(?:folder\s+khol|open\s+folder|directory\s+khol|folder\s+kholo|directory\s+kholo|open\s+directory)', lower))
        or bool(re.search(r'\b(?:reports\s+folder|saved\s+folder|reports\s+directory|saved\s+directory)\b', lower) and any(w in lower for w in ['open', 'kholo', 'khol', 'show', 'dikhao', 'chalao', 'lao', 'dekho']))
        or bool(re.search(r'\b(?:open|kholo|khol|show|dikhao)\s+(?:the\s+)?(?:reports|saved)\s+(?:folder|dir|directory)\b', lower))
        or bool(re.search(r'(?:folder|directory)\s+(?:where|jaha|jahan|jahan\s+pe|jaha\s+pe)\s+.*?(?:save|saved|notepad|files|reports|documents)', lower))
        or bool(re.search(r'\b(?:wo|woh|us)\s+(?:wala\s+)?(?:folder|directory)\s+.*?(?:save|notepad|reports)', lower) and any(w in lower for w in ['khol', 'kholo', 'open', 'show', 'dikhao']))
    )
    if is_saved_folder_intent:
        dest_dir = "C:\\reports"
        if context is not None:
            if getattr(context, "last_saved_directory", None):
                dest_dir = str(context.last_saved_directory)
            elif getattr(context, "last_created_file", None):
                try:
                    dest_dir = str(Path(context.last_created_file).parent)
                except Exception:
                    pass
            elif getattr(context, "last_referenced_file", None):
                try:
                    dest_dir = str(Path(context.last_referenced_file).parent)
                except Exception:
                    pass
        dest_dir = _normalize_resolved_path(dest_dir)
        return Plan(steps=[PlanStep(step=1, tool="open_folder", args={"path": dest_dir})], explanation=f"Opened saved documents repository folder at '{dest_dir}'.")

    # Matches: "F drive mein CSS Paper folder kholo", "Local drive F: ma CSS Paper folder open ker"
    drive_folder_m = re.search(r'(?:local\s+drive\s+|drive\s+)?\b([a-zA-Z])(?:\s+drive|\s+disk|:)\s*(?:mein|ma|in|se|say)\s+([a-zA-Z0-9_\- ]+?)\s*(?:wala\s+)?folder\s*(?:open|kholo|ker|karo|kar\s+do)', text, re.IGNORECASE)
    if drive_folder_m:
        d_ltr = drive_folder_m.group(1).upper()
        f_name = drive_folder_m.group(2).strip()
        if not _is_conversational_folder_path(f_name):
            return Plan(steps=[PlanStep(step=1, tool="open_folder", args={"path": f"{d_ltr}:\\{f_name}"})])

    # Matches: "CSS Paper ke andar CSS Paper 2017 kholo", "CSS Paper mein CSS Paper 2017 wala folder open karo"
    nested_under_m = re.search(r'([a-zA-Z0-9_\- ]+?)\s+(?:ke\s+andar|mein|ma)\s+([a-zA-Z0-9_\- ]+?)\s+(?:wala\s+folder|folder)\s*(?:open|kholo|ker|karo|kar\s+do)$', text, re.IGNORECASE)
    if not nested_under_m:
        nested_under_m = re.search(r'([a-zA-Z0-9_\- ]+?)\s+ke\s+andar\s+([a-zA-Z0-9_\- ]+?)\s*(?:open|kholo|ker|karo|kar\s+do)$', text, re.IGNORECASE)
    if nested_under_m and not ("notepad" in lower or "chrome" in lower or "chatgpt" in lower or "file" in lower or "likho" in lower or "type" in lower or "download" in lower):
        parent_f = nested_under_m.group(1).strip()
        child_f = nested_under_m.group(2).strip()
        if not _is_conversational_folder_path(parent_f) and not _is_conversational_folder_path(child_f):
            return Plan(steps=[PlanStep(step=1, tool="open_folder", args={"path": f"{parent_f}/{child_f}"})])

    # Matches: "computer mein downloaded Angry Bird game open karo", "computer ma download h angry bird game waha say open ker"
    download_app_m = re.search(r'(?:computer|pc)\s+(?:ma|mein)\s+download(?:ed|\s+h)?\s+([a-zA-Z0-9_\- ]+?)(?:\s+game|\s+app)?\s*(?:waha\s+say|waha\s+se)?\s*(?:open|kholo|chalao|launch)\s*(?:ker|karo|kar\s+do)?', text, re.IGNORECASE)
    if download_app_m:
        target_item = download_app_m.group(1).strip()
        return Plan(steps=[PlanStep(step=1, tool="launch_app", args={"name": target_item})])

    # Matches: "find and open folder CSS paper 2017 form This pc", "search and open folder X"
    find_open_f_m = re.search(r'(?:find\s+and\s+open|search\s+and\s+open|dhundo\s+aur\s+kholo)\s+(?:folder\s+)?[\'"]?([a-zA-Z0-9_\- ]+?)[\'"]?(?:\s+(?:from|form|in|mein|se)\s+[a-zA-Z0-9_\- ]+)?$', text, re.IGNORECASE)
    if find_open_f_m:
        target_f = find_open_f_m.group(1).strip()
        if target_f.lower() not in ("this pc", "this_pc", "computer", "c drive") and not _is_conversational_folder_path(target_f):
            return Plan(steps=[PlanStep(step=1, tool="open_folder", args={"path": target_f})])

    # Matches: "computer ma say CSS paper 2017 wala folder open ker", "CSS paper 2017 wala folder kholo", "CSS Paper 2017 folder open karo"
    hindi_wala_folder = re.search(r'(?:computer\s+(?:ma|mein)\s+(?:say|se)\s+)?[\'"]?([a-zA-Z0-9_\- ]+?)[\'"]?\s+(?:wala\s+folder|folder)\s+(?:open|kholo)\s*(?:ker|karo|kar\s+do)?', text, re.IGNORECASE)
    if hindi_wala_folder:
        target_f = hindi_wala_folder.group(1).strip()
        if target_f.lower() not in ("this pc", "this_pc", "computer", "c drive") and not _is_conversational_folder_path(target_f):
            return Plan(steps=[PlanStep(step=1, tool="open_folder", args={"path": target_f})])

    # Direct open of contextual resolved file reference
    if file_ref_m and ("open" in lower or "kholo" in lower) and not any(w in raw_lower for w in ["dhundo", "dhoondo", "find", "search", "locate"]) and not bool(re.search(r'\bsave\s+(?:active\s+document\s+)?to\b', lower)):
        return Plan(steps=[PlanStep(step=1, tool="open_file", args={"path": _normalize_resolved_path(file_ref_m.group(1))})])

    # -------------------------------------------------------------
    # 10. REAL FILE SEARCH / LATEST / OLDEST / LARGEST INTENTS
    # -------------------------------------------------------------
    # Matches: "PDF files dhundo", "latest PDF kholo", "Downloads mein latest file locate karo", "sabse badi PDF dhundo", "5 MB se bari files dhundo", "aaj modify hui files dhundo", "Downloads folder mein latest PDF open karo", "second PDF open karo"
    is_search_intent = any(w in lower for w in [
        "dhundo", "dhoondo", "dhoond", "dhund", "talash", "khojo", "look for", "look", "find", "search", "locate", "matching", "bari files", "choti files", "modify hui", "modify hue",
        "sabse badi", "sabse bari", "sabse purani", "sabse bhari", "sab se bhari", "bhari file", "bhaari file",
        "sab se pehle banaya", "pehle banaya tha"
    ]) or (
        ("kholo" in lower or "open" in lower or "locate" in lower or "dikhao" in lower or "batao" in lower or "khol do" in lower or "khol" in lower)
        and ("latest" in lower or "second" in lower or "doosri" in lower or "doosra" in lower or "third" in lower or "teesri" in lower or "teesra" in lower or "3rd" in lower or "sabse purani" in lower or "sabse badi" in lower or "sabse choti" in lower or "recent" in lower or "taaza" in lower or "taza" in lower or "fresh" in lower or "sab se pehle" in lower or "sab se pehli" in lower or "sabse pehle" in lower or "sabse bhari" in lower or "bhari" in lower or "sab se recent" in lower or "sabse taaza" in lower)
        and ("pdf" in lower or "file" in lower or "image" in lower or "document" in lower or "doc" in lower)
    )

    is_pure_folder_open = bool(re.search(r'\b(open|kholo)\s+(the\s+)?folder\b|\bfolder\s+(open|kholo)\b', lower)) and not any(w in lower for w in ["mein", "in", "file", "pdf", "image", "txt", "latest", "oldest"])
    is_web_query = any(w in lower for w in [
        "web pe", "web par", "internet pe", "internet par", "google pe", "google par",
        "search web", "search the web", "search online", "search google", "online search"
    ]) or (re.search(r'\b(?:search|dhundo)\b', lower) and re.search(r'\b(?:web|internet|google|online)\b', lower))
    if is_search_intent and not ("banao" in lower or "create" in lower or is_pure_folder_open or is_web_query or bool(re.search(r'\bsave\s+(?:active\s+document\s+)?to\b', lower))):
        from tools.search import parse_search_grammar
        parsed = parse_search_grammar(text, context)

        if parsed["is_ambiguous"]:
            return Plan(is_direct_message=True, message_text=parsed["ambiguity_msg"])

        search_step = PlanStep(
            step=1,
            tool="search_files",
            args={
                "query": parsed["query"],
                "extension": parsed["extension"],
                "start_folder": parsed["start_folder"],
                "min_size_bytes": parsed["min_size_bytes"],
                "max_size_bytes": parsed["max_size_bytes"],
                "modified_after": parsed["modified_after"],
                "modified_before": parsed["modified_before"],
                "sort_by": parsed["sort_by"],
            }
        )

        # If user explicitly asked to OPEN the searched result (e.g. "latest PDF kholo", "sabse purani PDF kholo", "second PDF open karo", "Chrome mein kholo")
        if "kholo" in lower or "open" in lower or "khol do" in lower or "khol" in lower:
            rank = 0
            if any(w in lower for w in ["second", "doosri", "doosra", "2nd"]):
                rank = 1
            elif any(w in lower for w in ["third", "teesri", "teesra", "3rd"]):
                rank = 2
            elif "rank" in parsed:
                rank = parsed["rank"]
            target_expr = f"$step_1.matches[{rank}]"
            open_args = {"path": target_expr}
            if "chrome" in lower:
                open_args["browser"] = "chrome"
            elif "edge" in lower:
                open_args["browser"] = "edge"
            return Plan(steps=[
                search_step,
                PlanStep(step=2, tool="open_file", args=open_args),
            ], explanation="Found matching file and opened it.")

        return Plan(steps=[search_step])

    # -------------------------------------------------------------
    # 11. CREATE FILE INTENT
    # -------------------------------------------------------------
    # Matches: "is mein test.txt file banao", "create file test.txt"
    if ("file" in lower and ("banao" in lower or "create" in lower or "make" in lower)) or (_has_file_extension(lower) and ("banao" in lower or "create" in lower or "make" in lower)):
        q = re.sub(r"folder\s+'[^']+'", '', text)
        file_m = re.search(r'([a-zA-Z0-9_\-\\/.]+\.[a-zA-Z0-9]+)', q)
        if file_m:
            target_file_name = file_m.group(1).strip()
        else:
            q_clean = re.sub(r'\b(create|make|banao|kar[a-z]*|file|ek|par|in|inside|usmein|ismein|please)\b', '', q, flags=re.IGNORECASE)
            target_file_name = q_clean.strip().strip("'\"")

        target_dir = folder_ref_m.group(1) if folder_ref_m else (context.last_created_directory or context.last_active_directory)
        if target_dir and not Path(target_file_name).is_absolute():
            full_file_path = f"{target_dir}/{target_file_name}"
        else:
            full_file_path = target_file_name

        return Plan(steps=[PlanStep(step=1, tool="create_file", args={"path": full_file_path})])

    # -------------------------------------------------------------
    # 11.5 STEP VARIABLE REFERENCE CONSUMPTION (Bullet #10)
    # -------------------------------------------------------------
    step_var_m = re.search(r'(\$step_\d+\.matches(?:\[\d+\])?)', text)
    if step_var_m:
        var_ref = step_var_m.group(1)
        if any(w in lower for w in ["delete", "remove", "hatao", "ura do"]):
            return Plan(steps=[PlanStep(step=1, tool="delete_file", args={"path": var_ref})])
        elif any(w in lower for w in ["read", "padho", "parho"]):
            return Plan(steps=[PlanStep(step=1, tool="read_file", args={"path": var_ref})])
        elif any(w in lower for w in ["open", "kholo", "launch", "chalao"]):
            return Plan(steps=[PlanStep(step=1, tool="open_file", args={"path": _normalize_resolved_path(var_ref)})])

    # -------------------------------------------------------------
    # 12. OPEN FILE INTENT
    # -------------------------------------------------------------
    if file_ref_m:
        return Plan(steps=[PlanStep(step=1, tool="open_file", args={"path": _normalize_resolved_path(file_ref_m.group(1))})])

    if ("kholo" in lower or "open" in lower) and (_has_file_extension(lower) or "pdf" in lower or "file" in lower):
        if "latest" in lower and (context.last_selected_file or context.last_referenced_file):
            target = _entity_val(context.last_selected_file) if context.last_selected_file else context.last_referenced_file
            return Plan(steps=[PlanStep(step=1, tool="open_file", args={"path": _normalize_resolved_path(target)})])

        file_name_m = re.search(r'([a-zA-Z]:[\\/][^\s"\'>]+|["\']([^"\']+)["\']|[a-zA-Z0-9_:\-\\/.]+\.[a-zA-Z0-9]+)', text)
        if file_name_m:
            fname = (file_name_m.group(1) or file_name_m.group(2)).strip()
            target_dir = context.last_active_directory or context.last_created_directory
            full_path = _normalize_resolved_path(fname, base_dir=target_dir)
            return Plan(steps=[PlanStep(step=1, tool="open_file", args={"path": full_path})])

    # -------------------------------------------------------------
    # 13. CREATE FOLDER INTENT
    # -------------------------------------------------------------
    # Matches: "Desktop par Phase4Test folder banao", "TestProject folder banao", "frontend folder banao"
    if "folder" in lower and ("banao" in lower or "create" in lower or "make" in lower):
        hindi_create = re.search(r'([a-zA-Z0-9_:\-\\/.]+)\s+par\s+([a-zA-Z0-9_:\-\\/.]+)\s+(?:folder\s+)?banao', text, re.IGNORECASE)
        if hindi_create:
            loc = hindi_create.group(1).strip()
            name = hindi_create.group(2).strip().strip("'\"")
            if loc.lower() == "desktop":
                target_fld = os.path.join(os.path.expanduser('~'), 'Desktop', name)
            else:
                target_fld = f"{loc}/{name}"
            return Plan(steps=[PlanStep(step=1, tool="create_folder", args={"path": _normalize_resolved_path(target_fld)})])

        hindi_create_single = re.search(r'([a-zA-Z0-9_:\-\\/.]+)\s+folder\s+banao', text, re.IGNORECASE)
        if hindi_create_single and hindi_create_single.group(1).lower() not in ("ka", "se", "naam", "ek", "yeh", "woh"):
            name = hindi_create_single.group(1).strip()
            target_parent = folder_ref_m.group(1) if folder_ref_m else (context.last_created_directory or context.last_active_directory)
            full_f_path = f"{target_parent}/{name}" if target_parent and not Path(name).is_absolute() else name
            return Plan(steps=[PlanStep(step=1, tool="create_folder", args={"path": full_f_path})])

        create_m = re.match(r'^(?:create|make)\s+(?:folder|dir|directory)?\s*[\'"]?([a-zA-Z0-9_:\-\\/.]+)[\'"]?', text, re.IGNORECASE)
        if create_m:
            return Plan(steps=[PlanStep(step=1, tool="create_folder", args={"path": create_m.group(1).strip()})])

    # -------------------------------------------------------------
    # 14. OPEN FOLDER & LOCAL SEARCH INTENT
    # -------------------------------------------------------------
    # Matches: "wo wala folder khol jaha tu sara notepad save ker raha h", "open reports folder", "open folder where files are saved", "saved folder kholo"
    is_saved_folder_intent = (
        bool(re.search(r'(?:folder\s+khol|open\s+folder|directory\s+khol|folder\s+kholo|directory\s+kholo|open\s+directory|khol\s+(?:wo|woh|us\s+)?wala\s+folder|khol\s+folder|kholo\s+folder).*?(?:save|notepad|reports)', lower))
        or bool(re.search(r'(?:save|notepad|reports).*?(?:folder\s+khol|open\s+folder|directory\s+khol|folder\s+kholo|directory\s+kholo|open\s+directory)', lower))
        or bool(re.search(r'\b(?:reports\s+folder|saved\s+folder|reports\s+directory|saved\s+directory)\b', lower) and any(w in lower for w in ['open', 'kholo', 'khol', 'show', 'dikhao', 'chalao', 'lao', 'dekho']))
        or bool(re.search(r'\b(?:open|kholo|khol|show|dikhao)\s+(?:the\s+)?(?:reports|saved)\s+(?:folder|dir|directory)\b', lower))
        or bool(re.search(r'(?:folder|directory)\s+(?:where|jaha|jahan|jahan\s+pe|jaha\s+pe)\s+.*?(?:save|saved|notepad|files|reports|documents)', lower))
        or bool(re.search(r'\b(?:wo|woh|us)\s+(?:wala\s+)?(?:folder|directory)\s+.*?(?:save|notepad|reports)', lower) and any(w in lower for w in ['khol', 'kholo', 'open', 'show', 'dikhao']))
    )
    if is_saved_folder_intent:
        dest_dir = "C:\\reports"
        if context is not None:
            if getattr(context, "last_saved_directory", None):
                dest_dir = str(context.last_saved_directory)
            elif getattr(context, "last_created_file", None):
                try:
                    dest_dir = str(Path(context.last_created_file).parent)
                except Exception:
                    pass
            elif getattr(context, "last_referenced_file", None):
                try:
                    dest_dir = str(Path(context.last_referenced_file).parent)
                except Exception:
                    pass
        dest_dir = _normalize_resolved_path(dest_dir)
        return Plan(steps=[PlanStep(step=1, tool="open_folder", args={"path": dest_dir})], explanation=f"Opened saved documents repository folder at '{dest_dir}'.")

    if folder_ref_m and not _is_conversational_folder_path(folder_ref_m.group(1)):
        return Plan(steps=[PlanStep(step=1, tool="open_folder", args={"path": folder_ref_m.group(1)})])

    # Matches: "find and open folder CSS paper 2017 form This pc", "search and open folder X"
    find_open_f_m = re.search(r'(?:find\s+and\s+open|search\s+and\s+open|dhundo\s+aur\s+kholo)\s+(?:folder\s+)?[\'"]?([a-zA-Z0-9_\- ]+?)[\'"]?(?:\s+(?:from|form|in|mein|se)\s+[a-zA-Z0-9_\- ]+)?$', text, re.IGNORECASE)
    if find_open_f_m:
        target_f = find_open_f_m.group(1).strip()
        if target_f.lower() not in ("this pc", "this_pc", "computer", "c drive") and not _is_conversational_folder_path(target_f):
            return Plan(steps=[PlanStep(step=1, tool="open_folder", args={"path": target_f})])

    # Matches: "computer ma say CSS paper 2017 wala folder open ker", "CSS paper 2017 wala folder kholo"
    hindi_wala_folder = re.search(r'(?:computer\s+(?:ma|mein)\s+(?:say|se)\s+)?[\'"]?([a-zA-Z0-9_\- ]+?)[\'"]?\s+wala\s+folder\s+(?:open|kholo)\s*(?:ker|karo|kar\s+do)?', text, re.IGNORECASE)
    if hindi_wala_folder:
        target_f = hindi_wala_folder.group(1).strip()
        if not _is_conversational_folder_path(target_f):
            return Plan(steps=[PlanStep(step=1, tool="open_folder", args={"path": target_f})])

    # Matches: "mere computer mein Captain America ki movie hai, chalao", "movie chalao", "Kill Bill movie play karo"
    if ("movie" in lower or "film" in lower or "video" in lower) and any(w in lower for w in ["chalao", "play", "open", "kholo", "hai"]):
        media_name_m = re.search(r'(?:(?:mein|me|computer\s+mein)\s+|^)?([a-zA-Z0-9_\- ]+?)\s+(?:ki\s+movie|ki\s+film|movie|film|video)\s+(?:hai|chalao|kholo|open|play)', text, re.IGNORECASE)
        media_query = media_name_m.group(1).strip() if media_name_m else "movie"
        return Plan(steps=[
            PlanStep(step=1, tool="search_files", args={"query": media_query, "start_folder": "This PC"}),
            PlanStep(step=2, tool="open_file", args={"path": "$step_1.matches[0]"}),
        ], explanation="Discovered local media file and opened it in media player.")

    # Matches: "Maine Microsoft Store se Angry Birds download ki hui hai, open karo.", "Angry Birds game jo Microsoft Store se installed hai usko open karo", "Microsoft Store se jo Angry Birds game maine download ki hai woh open karo", "computer ma download h angry bird game waha say open ker"
    if not ("downloads" in lower or "folder" in lower or "directory" in lower) and (re.search(r'\b(?:downloaded|download\s+ki|download\s+h|installed)\b', lower) or "microsoft store" in lower) and any(w in lower for w in ["open", "kholo", "chalao", "launch"]):
        app_name_m = re.search(r'(?:se|mein|ma|download(?:ed|\s+h)?)\s+([a-zA-Z0-9_\- ]+?)(?:\s+game|\s+app)?\s+(?:download|installed|waha|open|kholo|chalao)', text, re.IGNORECASE)
        if not app_name_m:
            app_name_m = re.search(r'^([a-zA-Z0-9_\- ]+?)(?:\s+game|\s+app)?\s+(?:jo|installed|se|download)', text, re.IGNORECASE)
        if not app_name_m:
            app_name_m = re.search(r'(?:jo|mein|ma|download(?:ed|\s+h)?)\s+([a-zA-Z0-9_\- ]+?)(?:\s+game|\s+app)?\s+(?:maine\s+download\s+ki\s+hai|waha\s+say\s+open|open|kholo|chalao|installed)', text, re.IGNORECASE)
        app_target = app_name_m.group(1).strip() if app_name_m else "Angry Birds"
        app_target = re.sub(r'\b(microsoft\s+store|se|jo|maine|download|downloaded|installed|ki|hui|hai|game|app|waha|say|usko|woh)\b', '', app_target, flags=re.IGNORECASE).strip() or "Angry Birds"
        return Plan(steps=[PlanStep(step=1, tool="launch_app", args={"name": app_target})])

    # Matches: "computer ma download h angry bird game waha say open ker"
    download_app_m = re.search(r'(?:computer|pc)\s+(?:ma|mein)\s+download(?:ed|\s+h)?\s+([a-zA-Z0-9_\- ]+?)(?:\s+game|\s+app)?\s+waha\s+(?:say|se)\s+(?:open|kholo|chalao|launch)\s*(?:ker|karo|kar\s+do)?', text, re.IGNORECASE)
    if download_app_m:
        target_item = download_app_m.group(1).strip()
        return Plan(steps=[PlanStep(step=1, tool="find_file", args={"name": target_item, "start_folder": "Downloads"})])

    if any(w in lower for w in ["kholo", "open", "launch", "start", "chalao", "run", "khol do", "khol de", "khol"]):
        # Check hindi/urdu pattern: "main.py open karo", "Downloads kholo", "Angry Birds launch karo", "Close Call app open karo", "OpenAI website open karo", "kill.sh script run karo", "Chrome khol do"
        hindi_open = re.match(r'^(?:(?:open|launch|run|chalao|kholo|khol\s*do|khol\s*de|khol|start)\b\s+)?([a-zA-Z0-9_:\-\\/.\s]+?)\s*(?:(wali\s+app|wali|wala|app|game|folder|file|website|script)\s+)?(?:kholo|khol\s*do|khol\s*de|khol|open\s*kar[a-z]*|launch\s*kar[a-z]*|chalao|run\s*kar[a-z]*|run|start\s*kar[a-z]*|start)?$', text.strip(), re.IGNORECASE)
        if hindi_open:
            loc = hindi_open.group(1).strip()
            hint_raw = (hindi_open.group(2) or "").strip().lower()
            hint_type = "app" if "app" in hint_raw or "game" in hint_raw else ("website" if "website" in hint_raw else ("folder" if "folder" in hint_raw else ("file" if "file" in hint_raw or "script" in hint_raw else None)))
            for lead in ("open", "launch", "run", "start", "chalao", "abhi ke abhi", "abhi", "foran", "jaldi se", "jaldi", "zara", "bhai", "please"):
                if loc.lower().startswith(lead + " "):
                    loc = loc[len(lead):].strip()
            loc = re.sub(r'^(?:abhi\s+ke\s+abhi|abhi|foran|jaldi\s+se|jaldi|zara|bhai|please)\s+', '', loc, flags=re.IGNORECASE).strip()
            loc = re.sub(r'\s+(?:phir|dobara|wapas|again|bhi|please|bhai)$', '', loc, flags=re.IGNORECASE).strip()
            if loc and not _is_conversational_folder_path(loc):
                loc_lower = loc.lower().strip()
                is_store_tok = loc_lower in ("store", "the store", "ms store", "store h", "store kiya", "store tha", "store hai") or (
                    "store" in loc_lower.split() and not any(w in loc_lower for w in ["microsoft store", "windows store"])
                )
                if not is_store_tok:
                    if any(w in loc.lower() for w in ["router", "gateway"]):
                        return Plan(steps=[PlanStep(step=1, tool="get_default_gateway", args={})], explanation="Inspected default network gateway and router IP address.")
                    intent_verb = "launch" if any(w in lower for w in ["launch", "play", "run"]) else "open"
                    res = resolve_universal_target(loc, user_intent=intent_verb, hint_type=hint_type, context=context)
                    if res.target_type in (TargetType.AMBIGUOUS, TargetType.NOT_FOUND) and res.disambiguation_message:
                        if context is not None and "Did you mean '" in res.disambiguation_message:
                            sug_m = re.search(r"Did you mean '([^']+)'\?", res.disambiguation_message)
                            if sug_m:
                                context.last_clarification_suggestion = sug_m.group(1)
                        return Plan(is_direct_message=True, message_text=res.disambiguation_message)
                    if res.tool_to_use == "open_folder" and _is_conversational_folder_path(res.tool_args.get("path", "")):
                        pass
                    elif res.tool_to_use == "launch_app" and res.tool_args.get("name", "").lower() in ("store", "microsoft store") and not any(w in lower for w in ["microsoft store", "windows store"]):
                        pass
                    else:
                        return Plan(steps=[PlanStep(step=1, tool=res.tool_to_use, args=res.tool_args)], explanation=res.explanation)

        # Check english pattern: "open main.py", "open Downloads", "launch Angry Birds", "open Xbox app", "run script kill.sh"
        open_f_m = re.match(r'^(?:open|launch|start|run)\s+(?:(folder|dir|directory|file|app|game|website|script)\s+)?[\'"]?([a-zA-Z0-9_:\-\\/.\s]+?)[\'"]?$', text.strip(), re.IGNORECASE)
        if open_f_m:
            hint_raw = (open_f_m.group(1) or "").strip().lower()
            hint_type = "app" if hint_raw in ("app", "game") else ("website" if hint_raw == "website" else ("folder" if hint_raw in ("folder", "dir", "directory") else ("file" if hint_raw in ("file", "script") else None)))
            loc = open_f_m.group(2).strip()
            loc = re.sub(r'\s+(?:again|please)$', '', loc, flags=re.IGNORECASE).strip()
            if loc and not _is_conversational_folder_path(loc):
                loc_lower = loc.lower().strip()
                is_store_tok = loc_lower in ("store", "the store", "ms store", "store h", "store kiya", "store tha", "store hai") or (
                    "store" in loc_lower.split() and not any(w in loc_lower for w in ["microsoft store", "windows store"])
                )
                if not is_store_tok:
                    if context and getattr(context, "last_clarification_suggestion", None):
                        if re.match(r'^(?:becaus|because|coz|cause|i want to|to play)\b', loc, re.IGNORECASE) or loc in ("it", "this", "that"):
                            loc = context.last_clarification_suggestion
                            context.last_clarification_suggestion = None
                    if any(w in loc.lower() for w in ["router", "gateway"]):
                        return Plan(steps=[PlanStep(step=1, tool="get_default_gateway", args={})], explanation="Inspected default network gateway and router IP address.")
                    intent_verb = "launch" if any(w in lower for w in ["launch", "play", "run"]) else "open"
                    res = resolve_universal_target(loc, user_intent=intent_verb, hint_type=hint_type, context=context)
                    if res.target_type in (TargetType.AMBIGUOUS, TargetType.NOT_FOUND) and res.disambiguation_message:
                        if context is not None and "Did you mean '" in res.disambiguation_message:
                            sug_m = re.search(r"Did you mean '([^']+)'\?", res.disambiguation_message)
                            if sug_m:
                                context.last_clarification_suggestion = sug_m.group(1)
                        return Plan(is_direct_message=True, message_text=res.disambiguation_message)
                    if res.tool_to_use == "open_folder" and _is_conversational_folder_path(res.tool_args.get("path", "")):
                        pass
                    elif res.tool_to_use == "launch_app" and res.tool_args.get("name", "").lower() in ("store", "microsoft store") and not any(w in lower for w in ["microsoft store", "windows store"]):
                        pass
                    else:
                        return Plan(steps=[PlanStep(step=1, tool=res.tool_to_use, args=res.tool_args)], explanation=res.explanation)


    return None
