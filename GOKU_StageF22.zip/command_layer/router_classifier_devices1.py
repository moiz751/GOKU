from __future__ import annotations
import os
from pathlib import Path
import re
import sys
import time
from typing import Any, Optional, Union, List, Dict, Tuple
from dataclasses import dataclass, field

from brain.planner import (
    Plan,
    PlanStep,
    StructuredIntent,
    create_plan_from_decision,
    decompose_compound_command,
    parse_compound_request,
    resolve_step_variables,
    resolve_step_variables_with_guard,
    inject_plan_prerequisites,
    prune_plan_steps,
    build_hypothesis_investigation_plan,
    build_root_cause_investigation_plan,
    parse_conditional_goal,
    synthesize_adaptive_replan,
    decompose_into_milestones,
    restore_plan_from_checkpoint,
    build_cross_domain_plan,
    apply_cross_domain_transformation,
    build_long_horizon_exploration_plan,
    decompose_long_horizon_goal,
    compute_state_hash,
    detect_state_cycle,
    heuristic_node_score,
    expand_exploration_frontier,
    select_next_frontier_node,
    apply_reflective_history_pruning,
)
from command_layer.cognitive_reasoner import CognitiveReasoner
from command_layer.context import (
    EntityType,
    TypedEntity,
    ORDINAL_REFERENCES,
    SessionContext,
    resolve_references,
    session_context,
    update_context_from_result,
)
from command_layer.semantic_model import (
    SemanticDomain,
    SemanticAction,
    CommandIntent,
    AmbiguityType,
    ClarificationRequest,
    SymptomCategory,
    SituationType,
    ConfidenceTier,
    RiskTier,
    ConfidenceScore,
    ConfirmationRequest,
    FailureType,
    AdaptiveStrategy,
    PlanAdaptation,
    TaskLifecycleState,
    TaskMilestone,
    TaskCheckpoint,
    DomainBridgeType,
    DomainBridgeLink,
    CrossDomainWorkflow,
    HorizonDepth,
    ExplorationNode,
    SearchFrontier,
    LongHorizonReport,
    HistoryQueryType,
    ExecutionTraceRecord,
    TraceSummary,
)
from command_layer.semantic_parser import (
    parse_semantic_intent,
    create_plan_from_intent,
    resolve_in_turn_correction,
    strip_conversational_noise,
    split_compound_clauses,
    detect_symptom_category,
)
from command_layer.firewall import validate_tool_against_firewall, pre_execution_semantic_check, validate_long_horizon_action
from command_layer.state_machine import agent_state
from command_layer.validator import validate_and_sanitize_tool_arguments
from command_layer.lexer import UniversalLexer
from brain.runtime_bus import RuntimePipingBus
from security.state import confirmation_manager
from tools.utils.app_resolver import (
    APP_ALIASES,
    get_canonical_app_name,
    resolve_app,
)
from tools.utils.target_resolver import TargetType, resolve_universal_target, disambiguate_multi_candidates
from command_layer.router_base import (
    Step,
    run_tool_call,
    resolve_system_canonical_path,
    verify_post_recovery,
    verify_semantic_outcome,
    capture_environment_snapshot,
    capture_step_observation,
    detect_environment_drift,
    _entity_val,
    get_all_schemas,
    KNOWN_SITE_KEYS,
    KNOWN_APP_NAMES,
    _has_file_extension,
    _normalize_resolved_path,
    _is_conversational_folder_path,
)
from security.safety_firewall import is_safe_readonly_operation
from security.confirm import RISKY_TOOLS
from command_layer.decomposer import count_action_verbs
from brain.workflow_orchestrator import orchestrate_compound_workflow
from tools.browser import sanitize_search_query
from tools.search import parse_search_grammar
import executor.verifier
import executor.executor

from command_layer.router_sanitizer import (
    _isolate_browser_context,
    prune_negated_steps,
    sanitize_action_query,
    sanitize_url,
    _canonicalize_plan_tools,
    sanitize_ui_target,
    extract_clean_search_query,
)
from command_layer.router_cli_parser import (
    translate_cli_command,
    sanitize_cli_command,
    extract_pure_text_payload,
    parse_sequential_keyboard_actions,
    is_standalone_navigation_request,
    resolve_temporal_order,
    strip_idiomatic_conditions,
)
from command_layer.router_confidence import (
    determine_risk_tier,
    format_uncertainty_response,
    compute_command_confidence,
    synthesize_cross_domain_report,
    synthesize_long_horizon_report,
    get_conversational_response,
)

def _classify_and_parse_command(text: str, context: SessionContext | None = None, is_compound_root: bool = True) -> Plan | None:
    from command_layer.router_classifier_core import _classify_and_parse_command as _real_fn
    return _real_fn(text, context, is_compound_root)

def classify_device_intents_1(text: str, context: SessionContext | None = None, is_compound_root: bool = True) -> Plan | None:
    from command_layer.decomposer import count_action_verbs
    from brain.workflow_orchestrator import orchestrate_compound_workflow
    from tools.browser import sanitize_search_query
    from tools.search import parse_search_grammar
    from security.safety_firewall import is_safe_readonly_operation
    from security.confirm import RISKY_TOOLS
    cleaned = re.sub(r'[\x00-\x1f\x7f]+$', '', text).strip()
    cleaned = re.sub(r'[\x13\x03\x1b]', '', cleaned).strip()
    raw_lower = cleaned.lower()
    lower = text.lower()
    folder_ref_m = re.search(r"folder\s+'([^']+)'", text)
    file_ref_m = re.search(r"file\s+'([^']+)'", text)
    text_unwrapped = re.sub(r'[\'"]([^\'"]+)[\'"]', r'\1', text)
    try:
        symptom_cat, situation_type, symptom_entities = detect_symptom_category(raw_lower)
    except Exception:
        symptom_cat, situation_type, symptom_entities = SymptomCategory.NONE, SituationType.NORMAL, []
    _p2_is_compound_guard = False
    # 3.8 Deep Wi-Fi Spectrum Scanner & Latency Engine
    if any(p in raw_lower for p in [
        "deep scan wifi", "scan wifi spectrum", "check wifi signal interference",
        "full network latency scan", "fix and scan wifi adapter", "wifi spectrum",
        "signal interference", "latency scan", "jitter scan", "spectrum scan"
    ]) or (
        "wifi" in raw_lower and any(w in raw_lower for w in ["spectrum", "interference", "deep scan", "latency scan", "jitter"])
    ):
        return Plan(steps=[PlanStep(step=1, tool="deep_scan_wifi_spectrum", args={})], explanation="Executed deep Wi-Fi spectrum audit, ping jitter analysis, and adapter recovery check.")

    # 3.9 Deep Network & Wi-Fi Hybrid Diagnostic Engine
    if any(p in raw_lower for p in [
        "diagnose wifi", "check network problem", "wifi problem analysis",
        "network scan karo", "find wifi problem", "wifi problem", "diagnose network health",
        "wifi diagnostic", "network health", "wifi masla", "network scan",
        "hybrid network diagnostic", "check wifi problem"
    ]) or (
        ("wifi" in raw_lower or "network" in raw_lower)
        and any(w in raw_lower for w in ["problem analysis", "find wifi problem", "wifi problem", "network scan", "scan karo", "diagnose wifi"])
        and not any(act in raw_lower for act in ["reset", "restart", "disconnect", "connect", "fix", "kholo", "open", "settings", "setting"])
    ):
        return Plan(steps=[PlanStep(step=1, tool="diagnose_network_health", args={})], explanation="Executed deep hybrid network and Wi-Fi diagnostic health audit.")

    # 4. Network & Internet Diagnosis
    if (
        any(p in raw_lower for p in [
            "why is the internet slow", "why is my internet slow", "internet slow kyun hai",
            "internet ka masla check karo", "network diagnose karo", "diagnose internet",
            "check internet issues", "network slow kyun hai", "diagnose network",
            "connection theek hai ya nahi", "actual connection theek hai ya nahi"
        ]) or (
            (bool(re.search(r'\b(internet|pages|web pages|\bnet\b)\b', raw_lower)) and any(w in raw_lower for w in ["slow", "lag", "masla", "issue", "problem", "diagnose", "ajeeb"]))
            and not any(act in raw_lower for act in ["reset", "restart", "disconnect", "fix", "repair", "kholo", "open", "format"])
            and not re.search(r'\bconnect\b', raw_lower)
        )
    ):
        return Plan(steps=[PlanStep(step=1, tool="diagnose_network", args={})], explanation="Diagnosed network connectivity and adapter health.")

    # 5. Browser Slowness & Diagnosis
    if (
        any(b in raw_lower for b in ["chrome", "edge", "firefox", "browser"])
        and bool(re.search(r'\b(?:slow|lag|lagging|diagnose)\b', raw_lower))
        and not any(act in raw_lower for act in ["open", "kholo", "launch", "close", "band", "kill", "search"])
    ):
        b_name = "chrome"
        if "edge" in raw_lower:
            b_name = "edge"
        elif "firefox" in raw_lower:
            b_name = "firefox"
        elif context.last_browser:
            b_name = _entity_val(context.last_browser)
        return Plan(steps=[PlanStep(step=1, tool="diagnose_browser", args={"browser": b_name})], explanation=f"Diagnosed {b_name} browser performance and resource footprint.")

    # 6. Specific Subsystem Diagnostics (CPU, RAM/Memory, Disk/Storage)
    if "cpu" in raw_lower and any(w in raw_lower for w in ["problem check", "diagnose", "problem", "usage high", "high usage", "masla", "issue", "check"]):
        return Plan(steps=[PlanStep(step=1, tool="diagnose_cpu", args={})], explanation="Diagnosed CPU utilization and heavy threads.")


    if (bool(re.search(r'\bram\b', raw_lower)) or "memory" in raw_lower) and any(w in raw_lower for w in ["problem check", "diagnose", "problem", "masla", "high usage", "leak", "leakage"]):
        return Plan(steps=[PlanStep(step=1, tool="diagnose_memory", args={})], explanation="Diagnosed memory consumption and leaks.")

    if symptom_cat not in (SymptomCategory.COMPOSITE, SymptomCategory.THERMAL_PERFORMANCE) and (
        (any(d in raw_lower for d in ["disk", "storage"]) and any(w in raw_lower for w in ["problem check", "diagnose", "problem", "masla", "full", "status check", "status", "health"]))
        or raw_lower.strip().rstrip("?") in ("storage status", "disk status", "check the storage", "check storage", "storage check karo", "disk check karo")
    ) and not any(act in raw_lower for act in ["format", "wipe", "clean", "delete"]):
        if re.search(r'\bhealth\b', raw_lower) and 'problem' not in raw_lower:   # explicit health/check request -> the read-only SMART/health snapshot tool
            return Plan(steps=[PlanStep(step=1, tool="get_storage_health_snapshot", args={})], explanation="Read the storage health snapshot.")
        return Plan(steps=[PlanStep(step=1, tool="diagnose_storage", args={})], explanation="Diagnosed storage and drive health.")

    # 7. Specific Application Diagnosis
    if bool(re.search(r'\b(?:slow|lag|lagging|diagnose)\b', raw_lower)) and any(re.search(rf'\b{re.escape(app)}\b', raw_lower) for app in ["vs code", "vscode", "notepad", "calculator", "calc", "word", "excel", "powerpoint"]):
        app_name = "VS Code" if ("vs code" in raw_lower or "vscode" in raw_lower) else ("Notepad" if "notepad" in raw_lower else "app")
        return Plan(steps=[PlanStep(step=1, tool="diagnose_application", args={"name": app_name})], explanation=f"Diagnosed application {app_name}.")

    # -------------------------------------------------------------
    # 0.698 BULLET #11: SITUATION INTERPRETATION & SYMPTOM-BASED TELEMETRY ASSEMBLY
    # -------------------------------------------------------------
    if symptom_cat != SymptomCategory.NONE:
        if symptom_cat == SymptomCategory.THERMAL_PERFORMANCE:
            return Plan(
                steps=[
                    PlanStep(step=1, tool="get_cpu_status", args={}),
                    PlanStep(step=2, tool="get_top_processes", args={"metric": "cpu", "limit": 5}),
                    PlanStep(step=3, tool="diagnose_cpu", args={}),
                ],
                synthesis_mode="diagnostic_synthesis",
                explanation="Conducted thermal and high CPU utilization diagnostics for system overheating/fan noise."
            )
        elif symptom_cat == SymptomCategory.SYSTEM_SLUGGISHNESS:
            return Plan(
                steps=[
                    PlanStep(step=1, tool="get_cpu_status", args={}),
                    PlanStep(step=2, tool="get_memory_status", args={}),
                    PlanStep(step=3, tool="diagnose_performance", args={}),
                ],
                synthesis_mode="diagnostic_synthesis",
                explanation="Conducted holistic performance diagnostics across CPU, Memory, and Subsystem bottlenecks."
            )
        elif symptom_cat == SymptomCategory.NETWORK_CONNECTIVITY:
            if any(k in raw_lower for k in ["dns", "website", "webpage", "load nahi", "open nahi", "load"]):
                return Plan(
                    steps=[
                        PlanStep(step=1, tool="get_dns_servers", args={}),
                        PlanStep(step=2, tool="test_internet_connectivity", args={}),
                        PlanStep(step=3, tool="get_wifi_status", args={}),
                    ],
                    synthesis_mode="diagnostic_synthesis",
                    explanation="Conducted DNS, internet connectivity, and network interface diagnostic inspection."
                )
            else:
                return Plan(
                    steps=[
                        PlanStep(step=1, tool="get_wifi_status", args={}),
                        PlanStep(step=2, tool="get_network_interfaces", args={}),
                        PlanStep(step=3, tool="test_internet_connectivity", args={}),
                    ],
                    synthesis_mode="diagnostic_synthesis",
                    explanation="Conducted network interface, Wi-Fi link status, and internet reachability diagnostics."
                )
        elif symptom_cat == SymptomCategory.STORAGE_CRUNCH:
            if symptom_entities:
                drive_tgt = symptom_entities[0]
                return Plan(
                    steps=[
                        PlanStep(step=1, tool="get_free_space", args={"drive": drive_tgt}),
                        PlanStep(step=2, tool="get_storage_health_snapshot", args={}),
                        PlanStep(step=3, tool="diagnose_storage", args={}),
                    ],
                    synthesis_mode="diagnostic_synthesis",
                    explanation=f"Conducted targeted storage capacity diagnostics for drive {drive_tgt} and drive health snapshot."
                )
            else:
                return Plan(
                    steps=[
                        PlanStep(step=1, tool="get_storage_health_snapshot", args={}),
                        PlanStep(step=2, tool="discover_drives", args={"include_removable": True, "include_network": True}),
                        PlanStep(step=3, tool="diagnose_storage", args={}),
                    ],
                    synthesis_mode="diagnostic_synthesis",
                    explanation="Conducted storage health snapshot and multi-drive discovery diagnostics."
                )
        elif symptom_cat == SymptomCategory.APP_UNRESPONSIVE:
            if symptom_entities:
                app_tgt = symptom_entities[0]
                return Plan(
                    steps=[
                        PlanStep(step=1, tool="find_process", args={"query": app_tgt}),
                        PlanStep(step=2, tool="get_process_status", args={"name_or_pid": app_tgt}),
                        PlanStep(step=3, tool="diagnose_application", args={"name": app_tgt}),
                    ],
                    synthesis_mode="diagnostic_synthesis",
                    explanation=f"Conducted application hang and process status inspection for {app_tgt}."
                )
            else:
                return Plan(
                    steps=[
                        PlanStep(step=1, tool="get_active_window", args={}),
                        PlanStep(step=2, tool="diagnose_performance", args={}),
                    ],
                    synthesis_mode="diagnostic_synthesis",
                    explanation="Conducted active window hang and system performance diagnosis."
                )
        elif symptom_cat == SymptomCategory.MEMORY_PRESSURE:
            return Plan(
                steps=[
                    PlanStep(step=1, tool="get_memory_status", args={}),
                    PlanStep(step=2, tool="get_top_processes", args={"metric": "memory", "limit": 5}),
                    PlanStep(step=3, tool="diagnose_memory", args={}),
                ],
                synthesis_mode="diagnostic_synthesis",
                explanation="Conducted memory pressure, top consuming processes, and memory diagnostic analysis."
            )
        elif symptom_cat == SymptomCategory.COMPOSITE:
            steps = []
            step_idx = 1
            has_thermal = any(w in raw_lower for w in ["garam", "heat", "hot", "fan", "temperature", "overheat"])
            has_net = any(w in raw_lower for w in ["net", "wifi", "internet", "browse", "website", "disconnect", "down"])
            has_storage = any(w in raw_lower for w in ["disk", "drive", "storage", "space", "full"])
            has_mem = any(w in raw_lower for w in ["ram", "memory", "paging"])
            has_slow = any(w in raw_lower for w in ["slow", "lag", "atak", "hang", "freeze", "sluggish"])

            if has_thermal:
                steps.append(PlanStep(step=step_idx, tool="get_cpu_status", args={}))
                step_idx += 1
                steps.append(PlanStep(step=step_idx, tool="get_top_processes", args={"metric": "cpu", "limit": 5}))
                step_idx += 1

            if has_mem:
                steps.append(PlanStep(step=step_idx, tool="get_memory_status", args={}))
                step_idx += 1

            if has_slow and not has_thermal and not has_mem:
                steps.append(PlanStep(step=step_idx, tool="get_cpu_status", args={}))
                step_idx += 1
                steps.append(PlanStep(step=step_idx, tool="get_memory_status", args={}))
                step_idx += 1

            if has_storage:
                steps.append(PlanStep(step=step_idx, tool="get_storage_health_snapshot", args={}))
                step_idx += 1

            if has_net:
                steps.append(PlanStep(step=step_idx, tool="get_wifi_status", args={}))
                step_idx += 1
                steps.append(PlanStep(step=step_idx, tool="test_internet_connectivity", args={}))
                step_idx += 1

            if not steps:
                steps = [PlanStep(step=1, tool="diagnose_system", args={})]

            return Plan(
                steps=steps,
                synthesis_mode="diagnostic_synthesis",
                explanation="Conducted coordinated multi-domain diagnostic inspection for composite symptoms."
            )

    # Check destructive ambiguity for ambiguous pronouns (e.g. 'isko delete karo' when both file & folder are in context)
    if any(w in raw_lower for w in ["delete", "remove", "hatao", "erase"]) and any(p in raw_lower for p in ["isko", "usko", "ye", "yeh", "this", "it"]):
        if context.last_selected_file and context.last_selected_folder and not ("file" in raw_lower or "folder" in raw_lower):
            f_name = Path(_entity_val(context.last_selected_file)).name
            d_name = Path(_entity_val(context.last_selected_folder)).name
            return Plan(is_direct_message=True, message_text=f"Which one do you mean: {f_name} (file) or {d_name} (folder)?")

    # Check if user specifically asks to open the folder where files are saved / notepad saved / reports folder / agent stored:
    # e.g.: "wo wala folder khol jaha tu sara notepad save ker raha h", "wo wala folder open ker jaha tu store h", "open reports folder"
    is_saved_folder_intent = (
        bool(re.search(r'(?:folder\s+(?:open|khol|kholo|chalao)|open\s+(?:the\s+)?folder|directory\s+(?:open|khol|kholo)|open\s+(?:the\s+)?directory|khol\s+(?:wo|woh|us\s+)?wala\s+folder|open\s+(?:wo|woh|us\s+)?wala\s+folder|(?:wo|woh|us\s+)?wala\s+folder\s+(?:open|khol|kholo)).*?(?:save|notepad|reports|store|files)', raw_lower))
        or bool(re.search(r'(?:save|notepad|reports|store).*?(?:folder\s+(?:open|khol|kholo)|open\s+(?:the\s+)?folder|directory\s+(?:open|khol|kholo)|open\s+(?:the\s+)?directory|folder\s+kholo|directory\s+kholo)', raw_lower))
        or bool(re.search(r'\b(?:reports\s+folder|saved\s+folder|reports\s+directory|saved\s+directory)\b', raw_lower) and any(w in raw_lower for w in ['open', 'kholo', 'khol', 'show', 'dikhao', 'chalao', 'lao', 'dekho']))
        or bool(re.search(r'\b(?:open|kholo|khol|show|dikhao)\s+(?:the\s+)?(?:reports|saved)\s+(?:folder|dir|directory)\b', raw_lower))
        or bool(re.search(r'(?:folder|directory)\s+.*?(?:where|jaha|jahan|jahan\s+pe|jaha\s+pe)\s+.*?(?:save|saved|store|stored|notepad|files|reports|documents|tu\s+store|tu\s+hai|tu\s+h)', raw_lower))
        or bool(re.search(r'(?:jaha|jahan|where)\s+.*?(?:tu\s+store|tu\s+save|tu\s+hai|tu\s+h|save|store).*?(?:folder|directory)', raw_lower))
        or bool(re.search(r'\b(?:wo|woh|us)\s+(?:wala\s+)?(?:folder|directory)\s+.*?(?:save|notepad|reports|store)', raw_lower) and any(w in raw_lower for w in ['khol', 'kholo', 'open', 'show', 'dikhao']))
        or bool(re.search(r'\b(?:jaha|jahan|where)\s+.*?(?:tu\s+store|tu\s+hai|tu\s+h|store\s+kiya|store\s+tha|store\s+h)\b', raw_lower))
    )
    if is_saved_folder_intent:
        if bool(re.search(r'\b(?:tu\s+store|tu\s+hai|tu\s+h|you\s+are\s+stored|agent\s+store)\b', raw_lower)):
            dest_dir = str(Path(__file__).resolve().parent.parent)
        else:
            dest_dir = "C:\\reports"
            if context is not None:
                if getattr(context, "last_saved_directory", None):
                    dest_dir = str(context.last_saved_directory)
                elif getattr(context, "last_created_file", None):
                    try:
                        dest_dir = str(Path(context.last_created_file).parent)
                    except Exception:
                        pass
                elif getattr(context, "last_referenced_file", None):
                    try:
                        dest_dir = str(Path(context.last_referenced_file).parent)
                    except Exception:
                        pass
        dest_dir = _normalize_resolved_path(dest_dir)
        return Plan(steps=[PlanStep(step=1, tool="open_folder", args={"path": dest_dir})], explanation=f"Opened repository folder at '{dest_dir}'.")

    resolved_text, is_ambig, ambig_msg = resolve_references(text_unwrapped, context)
    if is_ambig:
        return Plan(is_direct_message=True, message_text=ambig_msg or "Ambiguous reference.")

    text = resolved_text
    lower = text.lower()


    # Extract explicit folder / file markers from reference resolution if present
    folder_ref_m = re.search(r"folder\s+'([^']+)'", text)
    file_ref_m = re.search(r"file\s+'([^']+)'", text)

    # -------------------------------------------------------------
    # 0.67 CLI CONSOLE UTILITY INTERCEPTION
    # (whoami, dir, ipconfig, netstat, ping, hostname, systeminfo, etc.)
    # -------------------------------------------------------------
    CLI_CONSOLE_UTILITIES = {
        "whoami", "dir", "ipconfig", "netstat", "ping", "hostname", "systeminfo",
        "tracert", "nslookup", "tasklist", "arp", "route", "chkdsk"
    }

    # 1. Matches: "<console> mein <cli> chalao", "cmd mein ipconfig chalao", "powershell mein dir chalao"
    cmd_mein_m = re.match(
        r'^(?:(?:pehle|first|zara|please)\s+)?(?P<shell>cmd|command\s+prompt|terminal|powershell|console|pwsh)\s+(?:mein|me|main|in)\s+(.+?)(?:\s+(?:chalao|run\s*(?:karo|kar\s*do)?|execute\s*(?:karo|kar\s*do)?))?$',
        lower.strip(),
        re.IGNORECASE
    )
    if cmd_mein_m:
        raw_cli = sanitize_cli_command(cmd_mein_m.group(2))
        raw_cli = re.sub(r'\s+(?:chalao|run\s*(?:karo|kar\s*do)?|execute\s*(?:karo|kar\s*do)?)$', '', raw_cli, flags=re.IGNORECASE).strip()
        sh_type = "powershell" if "powershell" in cmd_mein_m.group("shell").lower() or "pwsh" in cmd_mein_m.group("shell").lower() else "cmd"
        return Plan(steps=[
            PlanStep(step=1, tool="execute_system_command", args={"command": raw_cli, "shell": sh_type})
        ], explanation=f"Executed headless CLI command '{raw_cli}' via {sh_type}.")

    # 1b. Matches: "cmd kholo, usme <cmd> chalao", "cmd khol kar <cmd> chalao", "powershell kholo, usme <cmd> chalao"
    cmd_khol_m = re.match(
        r'^(?:(?:pehle|first|zara|please)\s+)?(?:launch\s+|open\s+|start\s+|kholo)?\s*(?P<shell>cmd|command\s+prompt|terminal|powershell|pwsh)\s*(?:khol\s*(?:kar|ke)|open\s*karke|kholo\s*aur|khol\s*ke\s*phir|khol\s*kar\s*phir|kholo)?\s*(?:,\s*)?(?:usme|usmein|mein|me|main)?\s*(?:(?:run|execute|chalao)\s+)?(.+?)(?:\s+(?:chalao|run\s*(?:karo|kar\s*do)?|execute\s*(?:karo|kar\s*do)?))?$',
        lower.strip(),
        re.IGNORECASE
    )
    if cmd_khol_m:
        raw_cli = sanitize_cli_command(cmd_khol_m.group(2))
        raw_cli = re.sub(r'^(?:kholo|open|start|usme|usmein|mein|me|main|run|execute|please|chalao)\s+', '', raw_cli, flags=re.IGNORECASE).strip()
        raw_cli = re.sub(r'\s+(?:chalao|run\s*(?:karo|kar\s*do)?|execute\s*(?:karo|kar\s*do)?)$', '', raw_cli, flags=re.IGNORECASE).strip()
        if raw_cli:
            sh_type = "powershell" if "powershell" in cmd_khol_m.group("shell").lower() or "pwsh" in cmd_khol_m.group("shell").lower() else "cmd"
            return Plan(steps=[
                PlanStep(step=1, tool="execute_system_command", args={"command": raw_cli, "shell": sh_type})
            ], explanation=f"Executed headless CLI command '{raw_cli}' via {sh_type}.")

    # 2. Standalone CLI utility or "<cmd> chalao" / "run <cmd>" / "execute <cmd>"
    cli_cand = sanitize_cli_command(lower.strip())
    for prefix in ("run", "execute", "chalao", "pehle", "phir", "please", "zara", "bhai", "jaldi se"):
        if cli_cand.startswith(prefix + " "):
            cli_cand = cli_cand[len(prefix):].strip()
    cli_cand = re.sub(r'\s+(?:chalao|run\s*(?:karo|kar\s*do)?|execute\s*(?:karo|kar\s*do)?|karo|kar\s*do|bhai|please)$', '', cli_cand, flags=re.IGNORECASE).strip()

    tokens = cli_cand.split()
    first_token = tokens[0].lower() if tokens else ""

    is_cli_match = False
    if first_token in CLI_CONSOLE_UTILITIES:
        if first_token == "dir":
            if any(w in lower for w in ["chalao", "run", "execute", "/"]) or (tokens == ["dir"]) or (
                context and str(getattr(context.last_application, "value", context.last_application) or "").lower() in ("cmd", "command prompt", "powershell", "terminal", "cmd.exe", "powershell.exe")
            ):
                is_cli_match = True
        elif first_token == "ping":
            if any(w in lower for w in ["chalao", "run", "execute"]) or (
                context and str(getattr(context.last_application, "value", context.last_application) or "").lower() in ("cmd", "command prompt", "powershell", "terminal", "cmd.exe", "powershell.exe")
            ):
                is_cli_match = True
        else:
            is_cli_match = True

    if is_cli_match:
        is_console_active = False
        active_console = "cmd"
        if context:
            last_app_val = str(getattr(context.last_application, "value", context.last_application) or "").lower()
            last_win_val = str(getattr(context.last_window, "value", context.last_window) or "").lower()
            for cand in (last_app_val, last_win_val):
                if cand in ("cmd", "command prompt", "powershell", "terminal", "cmd.exe", "powershell.exe", "windowsterminal"):
                    is_console_active = True
                    active_console = cand
                    break

        if is_console_active:
            return Plan(
                steps=[PlanStep(step=1, tool="send_keyboard_input", args={"text": cli_cand, "press_enter": True, "app_name": active_console})],
                explanation=f"Executed CLI command '{cli_cand}' inside active console '{active_console}'."
            )
        else:
            return Plan(
                steps=[PlanStep(step=1, tool="execute_command", args={"command": cli_cand})],
                explanation=f"Executed CLI console utility '{cli_cand}'."
            )



    return None
