from __future__ import annotations
import os
from pathlib import Path
import re
import sys
import time
from typing import Any, Optional, Union, List, Dict, Tuple
from dataclasses import dataclass, field

from brain.planner import (
    Plan,
    PlanStep,
    StructuredIntent,
    create_plan_from_decision,
    decompose_compound_command,
    parse_compound_request,
    resolve_step_variables,
    resolve_step_variables_with_guard,
    inject_plan_prerequisites,
    prune_plan_steps,
    build_hypothesis_investigation_plan,
    build_root_cause_investigation_plan,
    parse_conditional_goal,
    synthesize_adaptive_replan,
    decompose_into_milestones,
    restore_plan_from_checkpoint,
    build_cross_domain_plan,
    apply_cross_domain_transformation,
    build_long_horizon_exploration_plan,
    decompose_long_horizon_goal,
    compute_state_hash,
    detect_state_cycle,
    heuristic_node_score,
    expand_exploration_frontier,
    select_next_frontier_node,
    apply_reflective_history_pruning,
)
from command_layer.cognitive_reasoner import CognitiveReasoner
from command_layer.context import (
    EntityType,
    TypedEntity,
    ORDINAL_REFERENCES,
    SessionContext,
    resolve_references,
    session_context,
    update_context_from_result,
)
from command_layer.semantic_model import (
    SemanticDomain,
    SemanticAction,
    CommandIntent,
    AmbiguityType,
    ClarificationRequest,
    SymptomCategory,
    SituationType,
    ConfidenceTier,
    RiskTier,
    ConfidenceScore,
    ConfirmationRequest,
    FailureType,
    AdaptiveStrategy,
    PlanAdaptation,
    TaskLifecycleState,
    TaskMilestone,
    TaskCheckpoint,
    DomainBridgeType,
    DomainBridgeLink,
    CrossDomainWorkflow,
    HorizonDepth,
    ExplorationNode,
    SearchFrontier,
    LongHorizonReport,
    HistoryQueryType,
    ExecutionTraceRecord,
    TraceSummary,
)
from command_layer.semantic_parser import (
    parse_semantic_intent,
    create_plan_from_intent,
    resolve_in_turn_correction,
    strip_conversational_noise,
    split_compound_clauses,
    detect_symptom_category,
)
from command_layer.firewall import validate_tool_against_firewall, pre_execution_semantic_check, validate_long_horizon_action
from command_layer.state_machine import agent_state
from command_layer.validator import validate_and_sanitize_tool_arguments
from command_layer.lexer import UniversalLexer
from brain.runtime_bus import RuntimePipingBus
from security.state import confirmation_manager
from tools.utils.app_resolver import (
    APP_ALIASES,
    get_canonical_app_name,
    resolve_app,
)
from tools.utils.target_resolver import TargetType, resolve_universal_target, disambiguate_multi_candidates
from command_layer.router_base import (
    Step,
    run_tool_call,
    resolve_system_canonical_path,
    verify_post_recovery,
    verify_semantic_outcome,
    capture_environment_snapshot,
    capture_step_observation,
    detect_environment_drift,
    _entity_val,
    get_all_schemas,
    KNOWN_SITE_KEYS,
    KNOWN_APP_NAMES,
    _has_file_extension,
    _normalize_resolved_path,
    _is_conversational_folder_path,
)
from security.safety_firewall import is_safe_readonly_operation
from security.confirm import RISKY_TOOLS
from command_layer.decomposer import count_action_verbs
from brain.workflow_orchestrator import orchestrate_compound_workflow
from tools.browser import sanitize_search_query
from tools.search import parse_search_grammar
import executor.verifier
import executor.executor

from command_layer.router_sanitizer import (
    _isolate_browser_context,
    prune_negated_steps,
    sanitize_action_query,
    sanitize_url,
    _canonicalize_plan_tools,
    sanitize_ui_target,
    extract_clean_search_query,
)
from command_layer.router_cli_parser import (
    translate_cli_command,
    sanitize_cli_command,
    extract_pure_text_payload,
    parse_sequential_keyboard_actions,
    is_standalone_navigation_request,
    resolve_temporal_order,
    strip_idiomatic_conditions,
)
from command_layer.router_confidence import (
    determine_risk_tier,
    format_uncertainty_response,
    compute_command_confidence,
    synthesize_cross_domain_report,
    synthesize_long_horizon_report,
    get_conversational_response,
)

def _classify_and_parse_command(text: str, context: SessionContext | None = None, is_compound_root: bool = True) -> Plan | None:
    from command_layer.router_classifier_core import _classify_and_parse_command as _real_fn
    return _real_fn(text, context, is_compound_root)

def classify_app_intents_2(text: str, context: SessionContext | None = None, is_compound_root: bool = True) -> Plan | None:
    from command_layer.decomposer import count_action_verbs
    from brain.workflow_orchestrator import orchestrate_compound_workflow
    from tools.browser import sanitize_search_query
    from tools.search import parse_search_grammar
    from security.safety_firewall import is_safe_readonly_operation
    from security.confirm import RISKY_TOOLS
    cleaned = re.sub(r'[\x00-\x1f\x7f]+$', '', text).strip()
    cleaned = re.sub(r'[\x13\x03\x1b]', '', cleaned).strip()
    raw_lower = cleaned.lower()
    lower = text.lower()
    folder_ref_m = re.search(r"folder\s+'([^']+)'", text)
    file_ref_m = re.search(r"file\s+'([^']+)'", text)
    text_unwrapped = re.sub(r'[\'"]([^\'"]+)[\'"]', r'\1', text)
    try:
        symptom_cat, situation_type, symptom_entities = detect_symptom_category(raw_lower)
    except Exception:
        symptom_cat, situation_type, symptom_entities = SymptomCategory.NONE, SituationType.NORMAL, []
    _p2_is_compound_guard = False
    # 1. PROCESS & APP STATE INTENTS (Phase 4A & Phase 2 Part 3)
    # -------------------------------------------------------------
    # 1. Installed Applications Discovery: "mere laptop par kon kon si apps installed hain", "installed apps batao", "list installed applications"
    if (
        (any(w in lower for w in ["installed apps", "installed applications", "installed programs", "apps installed"]) or
        (any(p in lower for p in ["kon kon si", "kaun kaun si", "kon se", "kaun se", "list", "show", "batao", "what", "which"]) and any(w in lower for w in ["apps", "applications", "programs"]) and "installed" in lower))
        and not ("uninstall" in lower or "delete" in lower)
    ):
        return Plan(steps=[PlanStep(step=1, tool="discover_applications", args={"filter_type": "ALL"})])

    # 2. Background / System Processes: "background mein kon kon se processes chal rahe hain", "running processes batao", "background processes"
    if (
        any(p in lower for p in ["background mein", "background processes", "system processes", "running processes", "running process", "tamam processes", "processes batao", "process list", "processes check karo", "process check karo", "check processes", "check process", "processes check", "running processes dikhao", "running processes check", "processes list", "list all processes", "show all processes"])
        and not any(a.lower() in lower for a in KNOWN_APP_NAMES)
        and (
            not any(p in lower for p in ["'s", "ka ", "ki ", "ke "])
            or any(sys_ref in lower for sys_ref in ["computer ke", "laptop ke", "system ke", "pc ke", "machine ke"])
        )
    ):
        inc_sys = any(w in lower for w in ["background", "system", "all", "poora", "tamam", "saare"])
        return Plan(steps=[PlanStep(step=1, tool="discover_running_processes", args={"include_system": inc_sys})])

    # 3. Running Apps Discovery: "kaun kaun se apps chal rahe hain?", "kon kon se programs running hain", "list running apps", "running apps dikhao", "kon se apps open hain", "mere laptop par kon kon si apps chal rahi hain"
    if (
        (any(p in lower for p in ["kaun kaun se", "kon kon se", "kaun se", "kon se", "which", "what", "kon kon si", "kaun kaun si"])
        and any(w in lower for w in ["apps", "programs", "applications", "processes"])
        and any(w in lower for w in ["chal", "running", "open", "active"]))
        or any(p in lower for p in ["running apps", "running programs", "list running", "open apps", "apps chal rahe hain", "programs running hain", "running applications"])
    ):
        if not any(k in lower for k in ["chrome", "notepad", "code", "vscode", "vs code", "edge", "firefox", "paint", "calc", "calculator", "explorer"]):
            return Plan(steps=[PlanStep(step=1, tool="list_running_apps", args={})])

    # 4b. Contextual Process Lookup: "iska process batao", "uska process batao", "process batao", "iska process kya hai", "tell me its process"
    if "process" in lower and any(w in lower for w in ["batao", "dikhao", "status", "check", "info", "find", "search", "show", "kya hai", "phir batao", "tell me", "using", "is", "its"]):
        if any(w in lower for w in ["iska", "is app ka", "is ka", "uska", "us app ka", "us ka", "active", "current", "this", "its", "it"]):
            if context and context.last_application:
                app_name = context.last_application.value if hasattr(context.last_application, "value") else str(context.last_application)
                if str(app_name).lower() in ("chrome", "google chrome"):
                    app_name = "Chrome"
                elif str(app_name).lower() == "notepad":
                    app_name = "Notepad"
                elif str(app_name).lower() == "calculator":
                    app_name = "Calculator"
                elif str(app_name).lower() == "paint":
                    app_name = "Paint"
                elif str(app_name).lower() == "edge":
                    app_name = "Edge"
                return Plan(steps=[PlanStep(step=1, tool="find_process", args={"query": app_name})])

    # 4c. App Status & Name Lookup: "Notepad ka status batao", "iska status batao", "iska naam batao", "check its status", "isko check karo"
    if any(w in lower for w in ["status", "check karo", "check ker"]) and not (lower.startswith("save") or "save to" in lower or _has_file_extension(lower) or "network" in lower or "wifi" in lower or "drive" in lower or "disk" in lower or "battery" in lower or "system" in lower or "pc" in lower or "laptop" in lower or "computer" in lower or "folder" in lower or "file" in lower or "processes" in lower):
        # 1. Check for named application in command
        if "status" in lower:
            for app in sorted(KNOWN_APP_NAMES, key=len, reverse=True):
                m = re.search(rf'\b({re.escape(app)})\b', text, flags=re.IGNORECASE)
                if m:
                    app_val = app.title() if app.lower() in ("notepad", "chrome", "edge", "calculator", "paint", "wordpad") else m.group(1)
                    return Plan(steps=[PlanStep(step=1, tool="get_application_status", args={"name": app_val})])
        # 2. Check for ordinal in search results
        if context and getattr(context, "last_search_results", None) and str(getattr(context, "last_search_results_type", "")).lower() in ("application", "entitytype.application"):
            for pat, idx in ORDINAL_REFERENCES:
                if re.search(pat, lower):
                    t_idx = idx if idx >= 0 else len(context.last_search_results) + idx
                    if 0 <= t_idx < len(context.last_search_results):
                        app_name = str(context.last_search_results[t_idx])
                        return Plan(steps=[PlanStep(step=1, tool="get_application_status", args={"name": app_name})])
        # 3. Contextual application status
        if context and (context.last_application or getattr(context, "last_search_results", None)) and any(w in lower for w in ["iska", "uska", "is app ka", "us app ka", "active", "current", "its", "it", "this", "status", "check", "isko"]):
            app_name = (
                (context.last_application.value if hasattr(context.last_application, "value") else str(context.last_application))
                if context.last_application else str(context.last_search_results[0])
            )
            return Plan(steps=[PlanStep(step=1, tool="get_application_status", args={"name": app_name})])

    if any(w in lower for w in ["naam", "name"]) and (any(w in lower for w in ["iska", "uska", "is app ka", "us app ka", "pehli wali", "first one", "selected"]) or any(a.lower() in lower for a in KNOWN_APP_NAMES)):
        if context and context.last_application:
            app_name = context.last_application.value if hasattr(context.last_application, "value") else str(context.last_application)
            return Plan(is_direct_message=True, message_text=f"The active application is {app_name}.")

    # 4. Find Process Instance: "chrome ka process find karo", "find process python", "python process dhundo", "what process is Chrome using?", "tell me chrome's process", "chrome konsa process chala raha hai"
    if bool(re.search(r'\bprocess(?:es)?\b', lower)) and not any(w in lower for w in [
        "list processes", "all processes", "top processes", "show processes", "running processes batao",
        "kaun se processes", "health", "diagnos", "abnormality", "subsystem",
        "kill", "terminate", "band", "close", "end", "stop"
    ]):
        cand_p = lower
        cand_p = re.sub(
            r'\b(?:what\s+process\s+is|what\s+process|which\s+process|konsa\s+process|process\s+is|'
            r'tell\s+me|show\s+me|find\s+me|is\s+using|using|chala\s+raha\s+hai|chal\s+raha\s+hai|'
            r'running\s+process|running|ka\s+process|ki\s+process|ke\s+process|\'s\s+process|process|'
            r'find\s+karo|dhundo|search\s+karo|find|search|check|locate|batao|dikhao|karo|please|'
            r'pata\s+karo|dekh\s+zara|dekhna\s+zara|whether|alive\s+hai|alive|active\s+hai|active|zara|'
            r'ki|ka|ke|is|this|the|app|application|of|for)\b',
            '', cand_p
        ).strip().strip("?").strip(".").strip("'s").strip()
        for common_p in ["python", "chrome", "notepad", "calculator", "edge", "cmd", "powershell", "explorer"]:
            if re.search(rf'\b{common_p}\b', cand_p, re.IGNORECASE):
                cand_p = common_p
                break
        if cand_p in ("it", "this", "ye", "yeh", "wo", "woh", ""):
            if context and context.last_application:
                cand_p = context.last_application.value if hasattr(context.last_application, "value") else str(context.last_application)
            elif context and context.last_process:
                cand_p = context.last_process.value if hasattr(context.last_process, "value") else str(context.last_process)
            else:
                cand_p = ""
        if cand_p:
            if context and context.last_search_results:
                for r in context.last_search_results:
                    if str(r).lower() == cand_p.lower():
                        cand_p = str(r)
                        break
            for known in KNOWN_APP_NAMES:
                if known.lower() == cand_p.lower():
                    cand_p = known
                    break
            return Plan(steps=[PlanStep(step=1, tool="find_process", args={"query": cand_p})])

    # 5. Find Application: "chrome find karo", "notpad find karo", "find application notepad", "Find Chrome", "Find Google Chrome"
    # Exclude UI element phrases like "window", "icon", "dialog", "button", "tab", "box"
    if (
        not any(u in lower for u in ["window", "icon", "dialog", "button", "tab", "box", "menu"])
        and (
            (lower.startswith("find application ") or lower.startswith("search app ") or "app find karo" in lower or "application find karo" in lower)
            or (any(w in lower for w in ["find karo", "dhundo"]) and any(k in lower for k in ["chrome", "notpad", "notepad", "vscode", "antigravity", "firefox", "edge", "excel", "word"]) and not ("file" in lower or "folder" in lower or "pdf" in lower or "image" in lower or "video" in lower or "doc" in lower))
            or (lower.startswith("find ") and any(k in lower for k in ["chrome", "notepad", "calculator", "paint", "edge", "word", "excel", "store", "explorer"]))
            or (lower.startswith("search ") and any(k in lower for k in ["chrome", "notepad", "calculator", "paint", "edge", "word", "excel"]) and not any(w in lower for w in ["in ", "on ", "web", "google"]))
        )
    ):
        cand_a = lower
        cand_a = re.sub(r'\b(find\s+application|search\s+app|app\s+find\s+karo|application\s+find\s+karo|find\s+karo|dhundo|search|find|karo|please|ko|app|application)\b', '', cand_a).strip()
        if cand_a:
            return Plan(steps=[PlanStep(step=1, tool="find_application", args={"name": cand_a})])

    # 5.8 Filesystem / Folder Inspection
    if (
        any(w in lower for w in ["downloads", "desktop", "documents"])
        and any(w in lower for w in ["second latest", "latest file", "check karo", "inspect", "file check", "jaiza", "jaiza lo", "files dikhao", "contents"])
        and not any(w in lower for w in ["dhoondo", "dhundo", "find", "search", "locate"])
        and not _has_file_extension(lower)
        and not re.search(r'\b[\w-]+\.\w{1,5}\b', lower)
    ):
        target_f = "Downloads" if "downloads" in lower else ("Desktop" if "desktop" in lower else "Documents")
        return Plan(steps=[PlanStep(step=1, tool="list_folder", args={"path": target_f})], explanation=f"Inspected files in {target_f} directory.")

    # 5.9 File Authorship / Forensic History limitation
    if any(w in lower for w in ["who changed", "who modified", "kisne change kiya", "kisne modify kiya", "who created", "who deleted"]):
        return Plan(
            is_direct_message=True,
            message_text="Forensic Limitation: Standard filesystem metadata records timestamps (created/modified/accessed) but does not log specific user authorship without Windows Security Auditing (Event ID 4663) enabled."
        )

    # 5.10 Session Preservation / Tab Protection constraint
    if ("chrome already khula" in lower or "already open" in lower or "naya chrome mat banana" in lower or "current session" in lower) and any(w in lower for w in ["mat", "unnecessarily", "preserve", "use karna"]):
        return Plan(
            steps=[PlanStep(step=1, tool="is_app_running", args={"name": "chrome"})],
            explanation="Verified running Chrome instance to attach to current session without spawning duplicate windows."
        )

    # 6. Specific App Running Status: "Chrome chal raha hai?", "kya Chrome chal raha hai", "is VS Code running?", "is Notepad running?", "ye chal rahi hai?", "tell me whether it is currently running", "Chrome check karo", "check Chrome's status"
    # Exclude close/kill/exit commands, system hardware, files/folders, and network queries
    has_known_app = any(a in lower for a in KNOWN_APP_NAMES)
    if (
        (
            has_known_app
            or not any(w in lower for w in [
                "close", "band karo", "band kar do", "band karna", "kill", "exit", "restart", "dialog", "window", "tab",
                "net", "internet", "wifi", "network", "system", "computer", "fans", "drive", "disk", "storage", "ram", "memory", "cpu", "uptime", "kafi ajeeb",
                "file", "files", "folder", "downloads", "documents", "desktop", "who changed", "who modified", "yesterday",
                "bluetooth", "usb", "wireless", "device", "devices", "mouse", "keyboard", "headset", "service", "services"
            ])
        )
        and not any(w in lower for w in ["close", "band karo", "band kar do", "band karna", "kill", "exit", "restart", "delete", "format", "wipe"])
        and (
            any(p in lower for p in [
                "chal raha hai", "chal rahi hai", "chal rahe hain", "chal rha ha", "chal rhi ha", "chal rha hai",
                "running hai", "is running", "open hai", "running?", "running hai ya nahi", "open hai ya nahi",
                "currently running", "whether it is", "is it running", "is this running", "pehle se chal", "chal to nahi raha",
                "active hai ya", "band pada", "band hai", "run kar raha", "system pe chal raha", "alive", "is active", "active hai ya nahi"
            ])
            or (any(p in lower for p in ["check karo", "status", "status check", "check "]) and (any(a in lower for a in KNOWN_APP_NAMES) or any(w in lower for w in ["app", "program", "application"])))
        )
    ):
        for app_alias, std_name in [
            ("chrome", "chrome"), ("chrme", "chrome"), ("google chrome", "chrome"),
            ("notepad", "notepad"), ("calculator", "calculator"), ("calc", "calculator"),
            ("edge", "edge"), ("paint", "paint"), ("wordpad", "wordpad"),
            ("cmd", "cmd.exe"), ("powershell", "powershell.exe")
        ]:
            if re.search(rf'\b{re.escape(app_alias)}\b', lower):
                if context and context.last_search_results and context.last_search_results_type == EntityType.APPLICATION:
                    for res_app in context.last_search_results:
                        if res_app.lower() == app_alias:
                            std_name = res_app
                            break
                elif context and context.last_application and str(_entity_val(context.last_application)).lower() == app_alias:
                    std_name = _entity_val(context.last_application)
                return Plan(steps=[PlanStep(step=1, tool="is_app_running", args={"name": std_name})], explanation=f"Checked if {std_name} is running.")

        cand_app = lower
        cand_app = re.sub(
            r'\b(?:chal\s+raha\s+hai|chal\s+rahi\s+hai|chal\s+rahe\s+hain|chal\s+rha\s+ha|chal\s+rhi\s+ha|chal\s+rha\s+hai|chal\s+rha\s+h|'
            r'running\s+hai|is\s+running|open\s+hai|open\s+hai\s+ya\s+nahi|currently\s+running|running|'
            r'status\s+check|check\s+karo|check|karo|kar\s+do|ya\s+nahi|app\s+chal\s+rahi\s+hai|app\s+running\s+hai|app|'
            r'program|application|kya|batao|tell\s+me\s+whether|tell\s+me|whether|currently|is|status|\'s|'
            r'ka|ki|ke|konsa|kon\s+sa|vrsion|version|ya|h|dekho|zara|run\s+kar\s+raha\s+hai|run\s+kar\s+raha|alive|is\s+active|active)\b',
            '', cand_app
        )
        cand_app = cand_app.strip().strip("?").strip(".").strip("'s").strip()
        if cand_app in ("it", "this", "ye", "yeh", "wo", "woh", "", "sirf", "only", "kuch", "cheez", "irf", "koi", "sab"):
            if context and context.last_application:
                cand_app = context.last_application.value if hasattr(context.last_application, "value") else str(context.last_application)
            else:
                cand_app = ""
        if cand_app:
            cand_app_lower = cand_app.lower().strip()
            is_store_token = cand_app_lower in ("store", "the store", "ms store", "store h", "store kiya", "store tha", "store hai") or (
                "store" in cand_app_lower.split() and not any(w in cand_app_lower for w in ["microsoft store", "windows store"])
            )
            if not is_store_token:
                if cand_app.lower() in ("notepad", "chrome", "edge", "calculator", "paint", "wordpad"):
                    cand_app = cand_app.title()
                if cand_app in KNOWN_APP_NAMES or resolve_app(cand_app) is not None or (context and context.last_application):
                    return Plan(steps=[PlanStep(step=1, tool="is_app_running", args={"name": cand_app})])

    # -------------------------------------------------------------
    # 2. APP CONTROL INTENTS (Close, Restart, Focus)
    # -------------------------------------------------------------
    # Matches: "Chrome band karo", "close notepad", "notepad close karo", "sab notepad close karo",
    # "sab notepad windows close karo", "jo jo notepad open hain unko close kar do",
    # "pher sab notepad tabs close ker do", "phir notepad close kardo", "all notepad windows close karo",
    # "kill notepad", "terminate process python", "chrome process kill karo"
    is_open_run_intent = any(w in lower for w in ["open", "kholo", "launch", "run", "start", "chalao", "play"]) and not any(w in lower for w in [
        "band karo", "close karo", "kill karo", "terminate karo", "band kar", "close kar", "exit karo", "quit karo",
        "terminate kar", "quit kar", "exit kar", "kill kar"
    ])
    if not is_open_run_intent and (
        any(w in lower for w in [
            "band karo", "close karo", "band kar do", "band kardo", "band ker do", "band kerdo",
            "close kar do", "close kardo", "close ker do", "close kerdo", "exit karo", "kill karo",
            "terminate karo", "terminate kar do", "terminate kardo", "terminate ker do", "terminate kerdo",
            "exit kar do", "exit kardo", "exit ker do", "exit kerdo",
            "quit karo", "quit kar do", "quit kardo", "quit ker do", "quit kerdo",
            "kill kar do", "kill kardo", "kill ker do", "kill kerdo",
            "close app", "close all", "band kar", "close kar", "close ker",
            "khatam kar do", "khatam kardo", "khatam karo", "khatam ker do", "khatam kerdo",
            "shut down", "shut the "
        ])
        or (lower.startswith(("close ", "kill ", "terminate ", "quit ", "exit ", "shut ")) and "folder" not in lower and "file" not in lower and not any(w in lower for w in ["open", "kholo", "launch", "run", "start"]))
        or (lower.endswith((" close", " quit", " exit")) and "folder" not in lower and "file" not in lower)
        or ((lower.startswith("kill ") or lower.startswith("terminate ") or lower.startswith("quit ") or lower.startswith("exit ")) and "all" not in lower)
    ):
        is_force_kill = any(w in lower for w in [
            "kill", "terminate", "force close", "forcefully close", "forcefully band",
            "force kill", "force exit", "end process", "force terminate", "quit"
        ])
        cand = lower
        cand = re.sub(
            r'\b(band\s+karo|band\s+kar\s+do|band\s+kardo|band\s+ker\s+do|band\s+kerdo|band\s+kar|band\s+ker|'
            r'close\s+karo|close\s+kar\s+do|close\s+kardo|close\s+ker\s+do|close\s+kerdo|close\s+kar|close\s+ker|'
            r'terminate\s+karo|terminate\s+kar\s+do|terminate\s+kardo|terminate\s+ker\s+do|terminate\s+kerdo|terminate|'
            r'exit\s+karo|exit\s+kar\s+do|exit\s+kardo|exit\s+ker\s+do|exit\s+kerdo|exit|'
            r'quit\s+karo|quit\s+kar\s+do|quit\s+kardo|quit\s+ker\s+do|quit\s+kerdo|quit|'
            r'kill\s+karo|kill\s+kar\s+do|kill\s+kardo|kill\s+ker\s+do|kill\s+kerdo|kill|'
            r'shut\s+down\s+karo|shut\s+down\s+kar\s+do|shut\s+down|shut|'
            r'close\s+all|close|please|pher|phir|then|aur|and|right\s+now|now|abhi|'
            r'khatam\s+kar\s+do|khatam\s+kardo|khatam\s+karo|khatam\s+ker\s+do|khatam\s+kerdo)\b',
            '', cand
        ).strip()
        cand = re.sub(r'\b(karo|kar\s+do|kardo|kar|ker|kerdo|ker\s+do|please)\b', '', cand).strip()
        cand = re.sub(
            r'\b(ki\s+saari\s+windows|ki\s+sari\s+windows|ki\s+sabhi\s+windows|ki\s+all\s+windows|all\s+windows\s+of|'
            r'saari\s+windows|sari\s+windows|sabhi\s+windows|all\s+windows|windows|tabs|tab|processes|process|instances)\b',
            '', cand
        ).strip()
        cand = re.sub(r'\b(jo\s+jo|open\s+hain|unko|sab|sari|saari|sabhi|all|ko|app|application|program|programs|process|tamam|khule\s+hue)\b', '', cand).strip().strip("'\"")

        if cand:
            cand = get_canonical_app_name(cand) or cand

        is_known_app = (
            cand.lower() in ("chrome", "notepad", "calculator", "calc", "wordpad", "paint", "settings", "task manager", "file explorer", "firefox", "microsoft edge", "vs code", "terminal")
            or cand in KNOWN_APP_NAMES
        )

        if is_force_kill:
            tool_to_use = "kill_process"
            tool_arg = {"name_or_pid": cand}
        elif cand.endswith(".exe"):
            tool_to_use = "close_app"
            tool_arg = {"name": cand}
        elif is_known_app and "process" not in lower:
            tool_to_use = "close_app"
            tool_arg = {"name": cand.lower()}
        else:
            tool_to_use = "close_app"
            tool_arg = {"name": cand}

        if cand.lower() in ("", "usko", "ise", "isse", "use", "ye", "yeh", "it", "immediately", "now", "foran", "right now", "abhi"):
            target_app = ""
            if context:
                raw_target = context.last_application or context.last_window or getattr(context, "last_launched_application", "")
                target_app = _entity_val(raw_target) if raw_target else ""
            if not target_app:
                if "process" in lower or is_force_kill:
                    return Plan(is_direct_message=True, message_text="Which process would you like to terminate?")
                return Plan(is_direct_message=True, message_text="Which application or window would you like to close?")
            return Plan(steps=[PlanStep(step=1, tool=tool_to_use, args={"name": target_app})])
        elif cand:
            if cand in KNOWN_APP_NAMES or resolve_app(cand) is not None or cand.endswith(".exe") or "process" in lower or is_force_kill:
                return Plan(steps=[PlanStep(step=1, tool=tool_to_use, args=tool_arg)])
            return Plan(steps=[PlanStep(step=1, tool=tool_to_use, args=tool_arg)])

    # Matches: "Chrome restart karo", "restart Notepad", "VS Code restart karo", "notepad restart kar do"
    if "restart" in lower or "re-open" in lower or "relaunch" in lower:
        cand = lower
        cand = re.sub(r'\b(restart\s+karo|restart\s+kar\s+do|restart\s+kardo|restart|relaunch|re-open|reopen|app|program|please)\b', '', cand).strip()
        cand = re.sub(r'\b(ko|app|program)\b', '', cand).strip()
        if cand in KNOWN_APP_NAMES or resolve_app(cand) is not None:
            return Plan(steps=[PlanStep(step=1, tool="restart_app", args={"name": cand})])

    # Safety intercept for mass destruction / termination / system power / bulk deletion / registry tampering
    if any(p in lower for p in [
        "kill all", "terminate all", "format all", "wipe out all", "delete all system", "delete all temp",
        "temp files forcefully", "force restart", "shut down", "power off", "force shut down",
        "hard disk reset", "disk reset", "reset kar do completely", "registry wipe", "registry wipe out",
        "registry", "wipe out", "sara kachra mita", "kachra mita"
    ]):
        return Plan(is_direct_message=True, message_text="Blocked by safety layer: Destructive system actions, registry tampering, and mass deletion are restricted.")

    # Matches: "Notepad foreground mein lao", "notepad ko foreground mein lao", "focus VS Code", "VS Code samne lao", "Chrome window par switch karo", "Chrome par wapas jao", "Chrome par switch karo", "Notepad window par switch karo", "Task Manager window par switch karo", "File Explorer window par switch karo", "Notepad par focus karo abhi", "Chrome application ko samne le aao", "bring Notepad to front"
    if any(k in lower for k in ["foreground", "focus", "samne lao", "samne laao", "samne le aao", "switch karo", "wapas jao", "window par jao", "par switch", "focus karo", "le aao", "lao samne", "switch to", "bring to front", "to front", "to the front", "focus on", "par jao"]):
        cand = lower
        cand = re.sub(r'\b(foreground\s+mein\s+lao|foreground\s+ma\s+lao|focus\s+karo|focus\s+kar\s+do|focus|samne\s+le\s+aao|samne\s+laao|samne\s+lao|le\s+aao|lao\s+samne|in\s+foreground|to\s+foreground|to\s+the\s+foreground|to\s+(?:the\s+)?front|bring|bring\s+to\s+front|switch\s+to|focus\s+on|app|application|program|please)\b', '', cand).strip()
        cand = re.sub(r'\b(window\s+par\s+switch\s+karo|window\s+par\s+switch|par\s+switch\s+karo|par\s+switch|switch\s+karo|switch\s+to|window\s+par\s+jao|par\s+wapas\s+jao|wapas\s+jao|par\s+jao|window)\b', '', cand).strip()
        cand = re.sub(r'\b(screen\s+par|screen\s+pe|screen|abhi\s+ke\s+abhi|abhi|foran|jaldi\s+se|jaldi|zara|bhai|janab|meharbani|par|pe|ko|app|application|program)\b', '', cand).strip()
        if cand in KNOWN_APP_NAMES or resolve_app(cand) is not None:
            return Plan(steps=[PlanStep(step=1, tool="focus_app", args={"name": cand})])
        for a in sorted(KNOWN_APP_NAMES, key=len, reverse=True):
            if re.search(rf'\b{re.escape(a)}\b', cand, re.IGNORECASE):
                return Plan(steps=[PlanStep(step=1, tool="focus_app", args={"name": a.title()})])

    # -------------------------------------------------------------
    # 3. SCREEN & VISUAL UNDERSTANDING INTENTS (Phase 4B & 4C)
    # -------------------------------------------------------------
    # Matches: "screen dekho", "screen inspect karo", "inspect screen", "screen par kya hai?", "what is on the screen?", "screen analyze karo"
    if (
        any(w in lower for w in ["screen dekho", "screen inspect", "inspect screen", "screen par kya hai", "what is on the screen", "screen analyze", "screen par kya chal raha"])
        and not ("size" in lower or "resolution" in lower or "screenshot" in lower)
    ):
        return Plan(steps=[PlanStep(step=1, tool="inspect_screen", args={})])

    # Phase 2 GUI Controller: screen capture / screenshot
    has_screenshot_phrase = (
        "screenshot" in lower or
        "screen capture" in lower or
        "screen snapshot" in lower or
        "display snapshot" in lower or
        any(lower.startswith(p) or lower == p for p in ["take a screenshot", "screen capture", "capture screen", "capture the screen", "render current visual frame"]) or
        (("screen" in lower or "display" in lower or "desktop" in lower) and any(w in lower for w in [
            "snapshot", "photo", "picture", "tasveer", "snap", "grab", "capture"
        ]) and not any(w in lower for w in ["size", "resolution", "inspect", "dimension", "dimensions", "kitna bada", "wallpaper"]))
    )
    if has_screenshot_phrase:
        return Plan(steps=[PlanStep(step=1, tool="capture_screen", args={})])

    # Matches: "screen ka size batao", "screen resolution kya hai", "screen size kya hai", "get screen size"
    if "screen" in lower and any(w in lower for w in ["size", "resolution", "dimension", "dimensions", "kitna bada"]):
        return Plan(steps=[PlanStep(step=1, tool="get_screen_size", args={})])

    # Directive 1: "yahan click karo <target>"
    if "yahan click" in lower or "yahan pe click" in lower or "yahan par click" in lower:
        target = re.sub(r'\b(yahan\s+pe\s+click\s+karo|yahan\s+par\s+click\s+karo|yahan\s+click\s+karo|click\s+karo\s+yahan|yahan|pe|par|please)\b', '', text, flags=re.IGNORECASE).strip().strip("'\"")
        target_val = target or "active element"
        return Plan(steps=[PlanStep(step=1, tool="find_and_interact", args={"target_query": target_val, "query": target_val, "action": "click"})])

    # Directive 2: "rok do", "confirm karo"
    if lower.strip() in ("rok do", "stop", "ruk jao", "cancel karo", "rok lo"):
        return Plan(steps=[], is_direct_message=True, message_text="Action stopped.")
    if lower.strip() in ("confirm karo", "confirm", "haan confirm hai", "yes confirm"):
        return Plan(steps=[], is_direct_message=True, message_text="Action confirmed.")
    # -------------------------------------------------------------
    # NEGATIVE CONSTRAINT DETECTION: Click suppression & hover/move routing
    # "click mat karna", "click bilkul mat karna", "hover karo lekin click nahi", etc.
    # -------------------------------------------------------------
    is_neg_click = bool(re.search(
        r'\b(?:click\s+(?:bilkul\s+)?mat\s+kar(?:na|o)|hover\s+karo\s+(?:lekin\s+)?click\s+(?:nahi|mat)|hover\s+karo\s+click\s+nahi|lekin\s+click\s+(?:nahi|mat)|click\s+(?:bilkul\s+)?nahi\s+kar(?:na|o)|click\s+nahi\b|click\s+mat\b|mat\s+click\s+kar(?:na|o)|don\'?t\s+click|do\s+not\s+click|never\s+click)\b',
        lower
    ))
    if is_neg_click:
        coord_h = re.search(r'\(?(\d+)[\s,]+(\d+)\)?', lower)
        dur = 1.0
        dur_m = re.search(r'(\d+(?:\.\d+)?)\s*(?:seconds?|s|second)\b', lower)
        if dur_m:
            dur = float(dur_m.group(1))

        if coord_h:
            cx, cy = int(coord_h.group(1)), int(coord_h.group(2))
        else:
            cx, cy = 500, 300

        tool_to_use = "move_mouse_smooth" if any(w in lower for w in ["smooth", "move"]) else "hover_mouse"
        return Plan(
            steps=[PlanStep(step=1, tool=tool_to_use, args={"x": cx, "y": cy, "duration": dur})],
            explanation="Routed to hover_mouse/move_mouse_smooth with click explicitly suppressed due to negative constraint."
        )


    return None
