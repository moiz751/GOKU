import re
from typing import List, Dict, Any

class HCoTDecomposer:
    """
    Hierarchical Chain-of-Thought (H-CoT) Task Decomposer.
    Splits arbitrary-length instructions into a 10 to 25 stage atomic DAG
    with strict boolean constraint tracking.
    """

    CONJUNCTIONS = [
        r'\baur\b', r'\bphir\b', r'\band\s+then\b', r'\bthen\b',
        r'\buske\s*baad\b', r'\biske\s*baad\b', r'\bagli\s*line\s*mein\b',
        r'\baakhir\s*mein\b', r'[,;]'
    ]

    NEGATION_PATTERNS = {
        'suppress_click': [r'click\s+(?:mat|nahi|bilkul\s*mat)\s*(?:karna|karo)?', r'don\'t\s*click'],
        'suppress_save': [r'save\s+(?:mat|nahi|karne\s*ki\s*koshish\s*mat)\s*(?:karna|karo)?', r'don\'t\s*save'],
        'suppress_close': [r'bina\s*band\s*kiye', r'band\s+(?:mat|nahi)\s*(?:karna|kardo)?', r'open\s*rehne\s*do', r'chup\s*chaap'],
        'suppress_terminal_exec': [r'terminal\s*par\s*mat\s*chalana', r'cmd\s*par\s*mat\s*run\s*karna']
    }

    @staticmethod
    def extract_boolean_constraints(clause: str) -> Dict[str, bool]:
        """Maps natural language double/single negations to boolean flags."""
        constraints = {
            'allow_click': True,
            'allow_save': True,
            'allow_close': True,
            'allow_terminal': True,
            'allow_launch': True
        }
        cl = clause.lower()
        if any(re.search(p, cl) for p in HCoTDecomposer.NEGATION_PATTERNS['suppress_click']):
            constraints['allow_click'] = False
        if any(re.search(p, cl) for p in HCoTDecomposer.NEGATION_PATTERNS['suppress_save']):
            constraints['allow_save'] = False
        if any(re.search(p, cl) for p in HCoTDecomposer.NEGATION_PATTERNS['suppress_close']):
            constraints['allow_close'] = False
        if any(re.search(p, cl) for p in HCoTDecomposer.NEGATION_PATTERNS['suppress_terminal_exec']):
            constraints['allow_terminal'] = False
        return constraints

    @staticmethod
    def split_into_atomic_clauses(text: str) -> List[str]:
        """Segments compound instructions into atomic sub-intent clauses."""
        # Preserve quoted strings during initial segmentation
        quotes = []
        def repl(m):
            quotes.append(m.group(0))
            return f"__QUOTE_HOLDER_{len(quotes)-1}__"

        protected_text = re.sub(r'["\']([^"\']+)["\']', repl, text)

        pattern = '|'.join(HCoTDecomposer.CONJUNCTIONS)
        raw_parts = re.split(pattern, protected_text, flags=re.IGNORECASE)

        clauses = []
        for part in raw_parts:
            # Restore quotes
            restored = part
            for idx, q_val in enumerate(quotes):
                restored = restored.replace(f"__QUOTE_HOLDER_{idx}__", q_val)
            cleaned = restored.strip()
            if cleaned and len(cleaned) > 1:
                clauses.append(cleaned)
        return clauses

    @staticmethod
    def decompose_to_dag(raw_text: str) -> List[Dict[str, Any]]:
        """
        Decomposes complex goals into sequential sub-tasks with isolated context.
        """
        clauses = HCoTDecomposer.split_into_atomic_clauses(raw_text)
        global_constraints = HCoTDecomposer.extract_boolean_constraints(raw_text)

        sub_tasks = []
        for idx, clause in enumerate(clauses, start=1):
            local_constraints = HCoTDecomposer.extract_boolean_constraints(clause)
            merged_constraints = {
                k: global_constraints[k] and local_constraints[k]
                for k in global_constraints
            }

            sub_tasks.append({
                "stage_id": idx,
                "clause": clause,
                "constraints": merged_constraints,
                "ephemeral_token_budget": 350
            })

        return sub_tasks
