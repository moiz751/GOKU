"""
Compound Intent Decomposer for MARK/GOKU Autonomous Agent.
Decomposes compound, multi-intent paragraphs into discrete atomic tasks
across diverse English and Roman Urdu conjunctions while detecting
and preserving explicit sequential workflow flags.
"""
from __future__ import annotations
import re



# Action verb patterns to prevent collapsing multi-step workflows into single text macros
_ACTION_VERB_PATTERNS = [
    r'\blaunch(?:_app)?\b',
    r'\btype(?:_text)?\b',
    r'\bclose(?:_app)?\b',
    r'\bscan\b',
    r'\bopen(?:_folder|_file)?\b',
    r'\bsave(?:_active_document)?\b',
    r'\bread(?:_file)?\b',
    r'\bkholo\b',
    r'\bkhol\b',
    r'\blikho\b',
    r'\bband\b',
    r'\bchalao\b',
    r'\bruko\b',
    r'\bthehro\b',
    r'\bwait\b',
    r'\bsleep\b',
    r'\bdelay\b',
    r'\bpause\b',
    r'\bscreenshot\b',
]


def count_action_verbs(text: str) -> int:
    """Counts operational action verbs present in command string."""
    clean = (text or "").lower()
    return sum(len(re.findall(pat, clean)) for pat in _ACTION_VERB_PATTERNS)


# Conjunction patterns for splitting multi-intent requests
_LOOKAHEAD_VERBS = (
    r'(?:paste|save_active_document|save|deep\s+scan|scan|diagnose|audit|analyze|inspect|check|test|ping|'
    r'remediate|take|capture|screenshot|focus|drag|scroll|hover|select|pick|read|write|create|delete|copy|'
    r'move|get|list|minimize|minimise|maximize|restore|open|launch|start|run|close|kill|exit|band|kholo|'
    r'khol|likho|chalao|clean|flush|search|type|click|press|show|find|evaluate|wo\s+wala|wo\s+folder|'
    r'us\s+folder|folder|last\s+par|last\s+pe|last\s+mein|last|report|generate|proof|record|prepare|cleanup|'
    r'wait|ruko|thehro|sleep|pause|delay|tab|shortcut|wahan|wapis|memory|ram|system|cpu|battery|'
    r'\d+\s*(?:second|sec|s|minute|min)|(?:ek|do|teen|char|paanch|chhe|saat|aath|nau|das)\s*(?:second|sec|s|minute|min)|'
    r'usme|usmein|isme|ismein|usko|isko|unko|ispe|uspe|use|ise|[a-zA-Z0-9_\-]+\s+(?:khol|kholo|chalao|launch|open|band|close|likho|type|run|start|search|banao|aao))\b'
)

_ACTION_TAIL_LOOKAHEAD = r'(?:[^\n,;]{1,80}?\b(?:par|pe|se|mein|me)?\s*(?:click\s+karo|click\s+kar\s+do|click|select\s+karo|select|dabao|press|kholo|khol|banao|aao|chalao|likho|type|open|launch|run|band|close|le\s+jao|hover|check\s+karo|check)\b)'

_CONJUNCTION_PATTERN = re.compile(
    r'(?:'
    r'\b(?:and\s+also|and\s+then|after\s+that|ok\s+first|aur\s+sath\s+hi|aur\s+phir|iske\s+baad|uske\s+baad|ke\s+baad|phir\s+uske\s+baad|warna|otherwise)\b|'
    r'\b(?:but\s+first|lekin\s+pehle|magar\s+pehle)\b|'
    r'\b(?:then|phir|afterwards|next|finally|last\s+par|last\s+pe|last\s+mein)\b|'
    rf'(?<!\bfix\s)\b(?:and|aur)\s+(?=(?:{_LOOKAHEAD_VERBS}|{_ACTION_TAIL_LOOKAHEAD}))|'
    r'\s{3,}|\t+|\n+|'
    r'\s*;\s*|'
    rf'\s*,\s*(?=(?:then|phir|after|and|aur|next|click|type|search|open|launch|mouse|cursor|pointer|hover|minimize|minimise|maximize|restore|show|uske|iske|but|warna|otherwise|lekin|magar|mat|terminal|cmd|powershell|pwsh|take|scan|deep|diagnose|audit|inspect|copy|paste|save_active_document|save|close|kill|exit|band|kholo|khol|likho|chalao|clean|flush|start|run|delete|read|write|wo\s+wala|wo\s+folder|us\s+folder|folder|last\s+par|last\s+pe|last\s+mein|last|report|generate|proof|record|prepare|cleanup|usme|usmein|isme|ismein|usko|isko|unko|ispe|uspe|use|ise|screenshot|wait|ruko|thehro|sleep|pause|delay|tab|shortcut|wahan|wapis|\d+\s*(?:second|sec|s|minute|min)|\d+\b|(?:ek|do|teen|char|paanch|chhe|saat|aath|nau|das)\s*(?:second|sec|s|minute|min))\b|{_ACTION_TAIL_LOOKAHEAD})'
    r')',
    re.IGNORECASE
)


# Markers indicating the user specified an explicit sequential ordering
_EXPLICIT_WORKFLOW_PATTERNS = [
    r'\b(?:step\s+\d+|step\s+[a-z])\b',
    r'^\s*\d+[\.\)]\s+',
    r'\b(?:workflow\s*:|pipeline\s*:|sequence\s*:)',
    r'\b(?:first|firstly|pehle)\b.*\b(?:second|secondly|phir|then|next|teesra)\b',
    r'\b(?:in\s+order|strictly\s+follow|order\s+mein)\b',
    r'\b(?:after\s+that|and\s+then|aur\s+phir|uske\s+baad|iske\s+baad|phir\s+uske\s+baad)\b',
    r'\b(?:then|phir|afterwards)\b',
    r'\b(?:close|kill|terminate|exit|quit|band)\b.*?\b(?:launch|open|start|run|kholo|chalao|type|likho|write|send_keyboard_input)\b',
    r'\b(?:launch|open|start|kholo|chalao)\s+(\w+)\b.*?\b(?:launch|open|start|kholo|chalao)\s+\1\b',
    r'\b(?:enter\s+(?:daba\s+kar|dabakar|daba\s+ke|dabake|dabao|press\s+karke|press\s+kar|press\s+karo)|press\s+enter)\b',
    r'\b(?:ctrl\s*\+\s*a|ctrl\s+a)\b',
    r'\b(?:backspace|erase\s+karo|erase\s+kar\s+do|erase)\b',
]


def has_explicit_workflow(text: str) -> bool:
    """
    Detects whether the input text enforces a strict, user-specified execution sequence
    (e.g., 'step 1:', '1.', 'first ... then ...', 'workflow:').
    """
    clean = text.strip().lower()
    # Inverted prerequisite clauses ('do X but first do Y') explicitly require topological sorting
    if re.search(r'\b(?:but\s+first|lekin\s+pehle|magar\s+pehle)\b', clean):
        return False
    for pat in _EXPLICIT_WORKFLOW_PATTERNS:
        if re.search(pat, clean, re.IGNORECASE):
            return True
    return False


def decompose_compound_command(text: str) -> list[str]:
    """
    Decomposes a compound, multi-intent command or paragraph into a list of
    discrete atomic sub-commands.

    Examples:
        - "minimize all, then launch store, after that click search, and also type asphalt 9"
          -> ["minimize all", "launch store", "click search", "type asphalt 9"]
        - "step 1: open store. step 2: click search. step 3: type minecraft"
          -> ["open store", "click search", "type minecraft"]
    """
    if not text or not text.strip():
        return []

    cleaned = text.strip()

    # 0. Basic Conditional Sequence Flattening:
    # When an instruction contains agar <condition> ... warna <alternative> where <condition> is a check (e.g. "agar notepad nahi chal raha to calc kholo"),
    # decompose linearly into the active consequence workflow and bind target application context.
    m_cond_decomp = re.search(r'\b(?:agar|if)\s+(.+?)\s+(?:to|phir|then)\s+(.+)', cleaned, re.IGNORECASE)
    if m_cond_decomp:
        c_pred = m_cond_decomp.group(1).strip().lower()
        c_rest = m_cond_decomp.group(2).strip()
        if re.search(r'\b(?:nahi\s+chal|nahi\s+khula|band\s+hai|closed|not\s+running|not\s+open)\b', c_pred):
            warna_split = re.split(r'\b(?:warna|else|otherwise|agar\s+nahi\s+to)\b', c_rest, flags=re.IGNORECASE)
            active_branch = warna_split[0].strip(" ,;.-")
            if len(warna_split) > 1:
                after_warna = warna_split[1].strip()
                trailing_m = re.search(r',\s*(?:phir\s+)?(.+)$', after_warna)
                if trailing_m and any(w in trailing_m.group(1).lower() for w in ["type", "likho", "click", "press", "save"]):
                    active_branch = f"{active_branch}, {trailing_m.group(1).strip()}"

            decomposed = decompose_compound_command(active_branch)
            cand_app = ""
            for item in decomposed:
                app_m = re.search(r'\b(calc|calculator|notepad|wordpad|chrome|edge|vlc)\b', item, re.IGNORECASE)
                if app_m:
                    cand_app = app_m.group(1)
                    break
            if cand_app:
                bound_decomposed = []
                for item in decomposed:
                    if any(w in item.lower() for w in ["type", "likho", "write"]) and not any(a in item.lower() for a in ["calc", "calculator", "notepad", "wordpad", "chrome", "edge", "vlc", "editor", "box", "bar"]):
                        bound_decomposed.append(f"{cand_app} mein {item}")
                    else:
                        bound_decomposed.append(item)
                return bound_decomposed
            return decomposed

    # 1. Handle explicit numbered or step-prefixed workflows
    step_chunks = re.split(r'(?:step\s+\d+[:\-\s]+|\b\d+[\.\)]\s+)', cleaned, flags=re.IGNORECASE)
    if len(step_chunks) > 1:
        raw_candidates = [c.strip() for c in step_chunks if c.strip()]
    elif re.search(r'\b(?:workflow|pipeline|sequence)\s*:\s*', cleaned, re.IGNORECASE):
        after_header = re.sub(r'^(?:workflow|pipeline|sequence)\s*:\s*', '', cleaned, flags=re.IGNORECASE).strip()
        raw_candidates = [c.strip() for c in re.split(r'->|;|\n', after_header) if c.strip()]
    else:
        # 2. Split on natural language conjunction tokens
        # Replace arrow sequences if present
        norm_text = re.sub(r'\s*->\s*', ' then ', cleaned)

        # Protect headless CLI commands like "cmd kholo, usme hostname chalao" from being split into GUI open + open folder
        norm_text = re.sub(
            r'\b(?P<sh>cmd|command\s+prompt|powershell|pwsh|terminal|console)\s+(?P<v>kholo|khol|open)\s*,\s*(?P<prep>usme|usmein|mein|me|main)\b',
            r'\g<sh> \g<v> \g<prep>',
            norm_text,
            flags=re.IGNORECASE
        )

        # Preprocess Roman Urdu compound conjunction sequences
        # e.g. "cmd khol kar whoami chalao" -> "cmd khol, phir whoami chalao"
        norm_text = re.sub(r'\b(?!(?:cmd|powershell|terminal|console)\b)([a-zA-Z0-9_\-]+)\s+khol\s+(?:kar|ke)\b', r'\1 kholo, phir', norm_text, flags=re.IGNORECASE)
        norm_text = re.sub(r'(?<!\bcmd\s)(?<!\bpowershell\s)(?<!\bterminal\s)(?<!\bconsole\s)\bkhol\s+(?:kar|ke)\b', r'kholo, phir', norm_text, flags=re.IGNORECASE)
        norm_text = re.sub(r'\bchalao\s+aur\b', r'chalao, aur', norm_text, flags=re.IGNORECASE)
        norm_text = re.sub(
            r'\b([a-zA-Z0-9_\-]+)\s+(open|kholo|launch|start|chalao)\s*(?:karo|kar|ker|do)?\s+aur\s+(?=[^\n,;]+?\b(?:click|select|dabao|press)\b)',
            r'\1 \2 karo, phir ',
            norm_text,
            flags=re.IGNORECASE
        )
        norm_text = re.sub(r'\blikho\s+phir\b', r'likho, phir', norm_text, flags=re.IGNORECASE)
        norm_text = re.sub(r'\b(?:karke|kar\s+ke)\s+phir\b', r'karo, phir', norm_text, flags=re.IGNORECASE)

        # Multi-line / modifier action intent splitting:
        norm_text = re.sub(
            r'[,;]?\s*\b(?:enter\s+(?:daba\s+kar|dabakar|daba\s+ke|dabake|mar\s+kar|marke|maar\s+kar|maaro|press\s+karke|press\s+kar|press\s+karo|dabao|hit\s+karo|key\s+dabao|key\s+press\s+karo)|press\s+enter|hit\s+enter)\b\s*(?:phir|aur|ke\s+baad)?\s*[,;]?',
            r' then enter dabao then ',
            norm_text,
            flags=re.IGNORECASE
        )
        norm_text = re.sub(
            r'[,;]?\s*\b(?:ctrl\s*\+\s*a|ctrl\s+a|select\s+all)\s*(?:dabao|press\s*karo|press\s*kar|dabakar|daba\s*kar|karo|kar\s*do|kardo)?\b\s*(?:phir|aur|ke\s+baad)?\s*[,;]?',
            r' then press ctrl+a then ',
            norm_text,
            flags=re.IGNORECASE
        )
        norm_text = re.sub(
            r'[,;]?\s*\b(?:backspace\s*(?:dabao|press\s*karo|press\s*kar|dabakar|daba\s*kar|karo|kar\s*do|kardo)?|erase\s+(?:karo|kar\s*do|kardo|kar|karke|kar\s*ke)|erase)\b\s*(?:phir|aur|ke\s+baad)?\s*[,;]?',
            r' then press backspace then ',
            norm_text,
            flags=re.IGNORECASE
        )

        # Protect conditional consequence markers (e.g., if ... then ..., agar ... to/phir ...)
        # so the predicate is not prematurely severed from its conditional consequence action.
        m_cond = re.search(r'\b(if|agar|check\s+if|in\s+case|jab|agar\s+kabhi)\b', norm_text, re.IGNORECASE)
        masked = norm_text
        replacements: dict[str, str] = {}
        if m_cond:
            post_cond = masked[m_cond.end():]
            m_then = re.search(r'\b(then|to|phir|tab)\b', post_cond, re.IGNORECASE)
            if m_then:
                t_start = m_cond.end() + m_then.start()
                t_end = m_cond.end() + m_then.end()
                word = masked[t_start:t_end]
                ph = f"__COND_CONSEQUENCE_{t_start}__"
                replacements[ph] = word
                masked = masked[:t_start] + ph + masked[t_end:]

        # Protect inner quoted CLI arguments / literal entities (e.g. "ESTABLISHED LISTENING")
        quote_replacements: dict[str, str] = {}
        def _mask_quotes(m_match: re.Match) -> str:
            ph = f"__QUOTED_ENTITY_{len(quote_replacements)}__"
            quote_replacements[ph] = m_match.group(0)
            return ph

        masked = re.sub(r'("[^"]*"|\'[^\']*\')', _mask_quotes, masked)

        raw_candidates = [c.strip() for c in _CONJUNCTION_PATTERN.split(masked) if c.strip()]
        if replacements or quote_replacements:
            restored_candidates = []
            for c in raw_candidates:
                for ph, word in replacements.items():
                    c = c.replace(ph, word)
                for ph, word in quote_replacements.items():
                    c = c.replace(ph, word)
                restored_candidates.append(c)
            raw_candidates = restored_candidates


    # 3. Clean and normalize each atomic sub-command
    sub_commands: list[str] = []
    has_enter_or_newline = bool(re.search(r'\b(?:enter\s+(?:daba|press|hit|mar)|press\s+enter|hit\s+enter|ctrl\s*\+\s*a|ctrl\s+a|backspace|erase)\b|\n', cleaned, re.IGNORECASE))
    for cand in raw_candidates:
        # Strip leading conjunction artifacts
        s = cand.strip(" ,;.-")
        s = re.sub(
            r'^(?:and\s+also|and\s+then|after\s+that|ok\s+first|aur\s+sath\s+hi|aur\s+phir|iske\s+baad|uske\s+baad|ke\s+baad|phir\s+uske\s+baad|but\s+first|lekin\s+pehle|magar\s+pehle|then|phir|afterwards|next|finally|firstly|(?:first|pehle)(?!\s+(?:tab|window|app|step|result|file|folder|document|application))|and|aur|also|ok|please|but|lekin|magar|last\s+par|last\s+pe|last\s+mein)\s+',
            '',
            s,
            flags=re.IGNORECASE
        ).strip(" ,;.-")
        
        # Strip trailing connector artifacts
        s = re.sub(
            r'\s+(?:aur|and|then|phir|after\s+that|afterwards|last\s+par|last\s+pe|last\s+mein)$',
            '',
            s,
            flags=re.IGNORECASE
        ).strip(" ,;.-")

        # Strip remaining step markers if any
        s = re.sub(r'^(?:step\s+\d+[:\-\s]*|\d+[\.\)][:\-\s]*)', '', s, flags=re.IGNORECASE).strip()

        # Ensure 'save to <path>' is never fused with preceding or subsequent network/other instructions
        save_m = re.search(r'\b(save\s+(?:active\s+document\s+)?to\s+([a-zA-Z]:[^\s"\'<>|?*]+|[^\s"\'<>|?*]+\.[a-zA-Z0-9]+))\b', s, re.IGNORECASE)
        if save_m and (save_m.start() > 0 or save_m.end() < len(s)):
            start_idx, end_idx = save_m.span()
            before_part = s[:start_idx].strip(" ,;.-")
            save_part = save_m.group(1).strip(" ,;.-")
            after_part = s[end_idx:].strip(" ,;.-")

            before_part = re.sub(r'\s+(?:aur|and|then|phir)$', '', before_part, flags=re.IGNORECASE).strip(" ,;.-")
            after_part = re.sub(r'^(?:aur|and|then|phir)\s+', '', after_part, flags=re.IGNORECASE).strip(" ,;.-")

            if before_part:
                sub_commands.append(before_part)
            if save_part:
                sub_commands.append(save_part)
            if after_part:
                sub_commands.append(after_part)
            continue

        # Drop standalone conjunction or filler fragments (e.g. "karke", "phir", "aur", "karo")
        if s.lower() in ("karke", "kar ke", "karo", "phir", "aur", "and", "then", "please", "ok", "bhai", "zara"):
            continue

        # If sub-command is a bare text fragment produced from multi-line/enter splitting without action verbs:
        if has_enter_or_newline and s and count_action_verbs(s) == 0:
            if not any(k in s.lower() for k in ["enter", "hotkey", "ctrl", "backspace", "erase", "screenshot", "save", "minimize", "restore", "close", "launch", "open"]):
                s = f"type {s}"

        if s:
            sub_commands.append(s)

    # If splitting collapsed everything or yielded fewer than 2 segments when 3+ action verbs or conjunctions present,
    # force explicit conjunction boundary splitting to prevent collapsed text typing macro fallback
    has_conjs = len(re.findall(r'\b(?:pehle|phir|aur|and|then|after\s+that|last\s+par)\b', cleaned, re.IGNORECASE)) >= 2
    if (len(sub_commands) <= 1 or not sub_commands) and (count_action_verbs(cleaned) >= 3 or has_conjs):
        forced = re.split(r'\b(?:pehle|phir|aur|and|then|after\s+that|last\s+par|last\s+pe|last\s+mein)\b', cleaned, flags=re.IGNORECASE)
        forced_cmds = [f.strip(" ,;.-") for f in forced if f.strip(" ,;.-") and f.strip(" ,;.-").lower() not in ("karke", "kar ke", "karo", "phir", "aur", "and", "then", "please", "ok")]
        if len(forced_cmds) > len(sub_commands):
            return forced_cmds

    # If splitting collapsed everything, return the single cleaned text
    if not sub_commands and cleaned:
        return [cleaned]

    return sub_commands
