import re
from typing import Dict, Any

class CognitiveReasoner:
    """
    Infers latent user intentions, predicts logical next steps,
    and expands high-level goals into multi-stage execution graphs.
    """

    @staticmethod
    def infer_domain_intent(prompt: str) -> Dict[str, Any]:
        p = prompt.lower()

        # 1. High-Level Synthesis: Game Creation
        if any(w in p for w in ["game banani", "game banao", "make a game", "create game", "snake game"]):
            return {
                "type": "ABSTRACT_SYNTHESIS_GAME",
                "target_runtime": "html_browser",
                "description": "User wants a playable game. Requires synthesizing complete single-file interactive code, saving to disk, and launching in browser."
            }

        # 2. High-Level Synthesis: Blog / Article Writing
        if any(w in p for w in ["blog likh", "article likh", "write a blog", "essay likh", "content likh"]):
            topic_match = re.search(r"""(?:blog|article|essay)\s*(?:likh\s*kar\s*do|likho|banao)?\s*(?:on|par|about)?\s*['"]?([^'"]+)?""", prompt, re.IGNORECASE)
            topic = topic_match.group(1).strip() if (topic_match and topic_match.group(1)) else "Artificial Intelligence & Future Tech"
            return {
                "type": "ABSTRACT_SYNTHESIS_BLOG",
                "topic": topic,
                "target_app": "Notepad",
                "description": "User wants an end-to-end written publication. Requires structuring header, body, takeaways, and streaming to editor."
            }

        # 3. Conversational Arithmetic with Calculator Affordance
        if any(w in p for w in ["calculator kholo", "calc kholo", "hisab karo", "multiply", "jama karo"]):
            # Check if arithmetic expression is present or implied
            math_expr = None
            m = re.search(r'(\d+)\s*(?:multiply|zarb|times|x|\*)\s*(?:by\s*)?(\d+)', p)
            if m:
                math_expr = f"{m.group(1)}*{m.group(2)}="
            m_add = re.search(r'(\d+)\s*(?:plus|jama|aur|and|mein|me|\+)\s*(\d+)', p)
            if m_add and not math_expr:
                math_expr = f"{m_add.group(1)}+{m_add.group(2)}="

            return {
                "type": "AFFORDANCE_CALCULATOR",
                "math_expr": math_expr,
                "predict_next": "keyboard_input_arithmetic"
            }

        # 4. Standard Operational / Procedural
        return {"type": "DIRECT_OPERATION"}
