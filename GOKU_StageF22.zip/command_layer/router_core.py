from __future__ import annotations
import os
from pathlib import Path
import re
import sys
import time
from typing import Any, Optional, Union, List, Dict, Tuple
from dataclasses import dataclass, field

from brain.planner import (
    Plan,
    PlanStep,
    StructuredIntent,
    create_plan_from_decision,
    decompose_compound_command,
    parse_compound_request,
    resolve_step_variables,
    resolve_step_variables_with_guard,
    inject_plan_prerequisites,
    prune_plan_steps,
    build_hypothesis_investigation_plan,
    build_root_cause_investigation_plan,
    parse_conditional_goal,
    synthesize_adaptive_replan,
    decompose_into_milestones,
    restore_plan_from_checkpoint,
    build_cross_domain_plan,
    apply_cross_domain_transformation,
    build_long_horizon_exploration_plan,
    decompose_long_horizon_goal,
    compute_state_hash,
    detect_state_cycle,
    heuristic_node_score,
    expand_exploration_frontier,
    select_next_frontier_node,
    apply_reflective_history_pruning,
)
from command_layer.cognitive_reasoner import CognitiveReasoner
from command_layer.context import (
    EntityType,
    TypedEntity,
    ORDINAL_REFERENCES,
    SessionContext,
    resolve_references,
    session_context,
    update_context_from_result,
)
from command_layer.semantic_model import (
    SemanticDomain,
    SemanticAction,
    CommandIntent,
    AmbiguityType,
    ClarificationRequest,
    SymptomCategory,
    SituationType,
    ConfidenceTier,
    RiskTier,
    ConfidenceScore,
    ConfirmationRequest,
    FailureType,
    AdaptiveStrategy,
    PlanAdaptation,
    TaskLifecycleState,
    TaskMilestone,
    TaskCheckpoint,
    DomainBridgeType,
    DomainBridgeLink,
    CrossDomainWorkflow,
    HorizonDepth,
    ExplorationNode,
    SearchFrontier,
    LongHorizonReport,
    HistoryQueryType,
    ExecutionTraceRecord,
    TraceSummary,
)
from command_layer.semantic_parser import (
    parse_semantic_intent,
    create_plan_from_intent,
    resolve_in_turn_correction,
    strip_conversational_noise,
    split_compound_clauses,
    detect_symptom_category,
)
from command_layer.firewall import validate_tool_against_firewall, pre_execution_semantic_check, validate_long_horizon_action
from command_layer.state_machine import agent_state
from command_layer.validator import validate_and_sanitize_tool_arguments
from command_layer.lexer import UniversalLexer
from brain.runtime_bus import RuntimePipingBus
from security.state import confirmation_manager
from tools.utils.app_resolver import (
    APP_ALIASES,
    get_canonical_app_name,
    resolve_app,
)
from tools.utils.target_resolver import TargetType, resolve_universal_target, disambiguate_multi_candidates
from command_layer.router_base import (
    Step,
    run_tool_call,
    resolve_system_canonical_path,
    verify_post_recovery,
    verify_semantic_outcome,
    capture_environment_snapshot,
    capture_step_observation,
    detect_environment_drift,
    _entity_val,
    get_all_schemas,
    KNOWN_SITE_KEYS,
    KNOWN_APP_NAMES,
    _has_file_extension,
    _normalize_resolved_path,
    _is_conversational_folder_path,
)
from security.safety_firewall import is_safe_readonly_operation
from security.confirm import RISKY_TOOLS
from command_layer.decomposer import count_action_verbs
from brain.workflow_orchestrator import orchestrate_compound_workflow
from tools.browser import sanitize_search_query
from tools.search import parse_search_grammar
import executor.verifier
import executor.executor

from command_layer.router_sanitizer import (
    _isolate_browser_context,
    prune_negated_steps,
    sanitize_action_query,
    sanitize_url,
    _canonicalize_plan_tools,
    sanitize_ui_target,
    extract_clean_search_query,
)
from command_layer.router_cli_parser import (
    translate_cli_command,
    sanitize_cli_command,
    extract_pure_text_payload,
    parse_sequential_keyboard_actions,
    is_standalone_navigation_request,
    resolve_temporal_order,
    strip_idiomatic_conditions,
)
from command_layer.router_confidence import (
    determine_risk_tier,
    format_uncertainty_response,
    compute_command_confidence,
    synthesize_cross_domain_report,
    synthesize_long_horizon_report,
    get_conversational_response,
)
from command_layer.router_classifier_core import _classify_and_parse_command



def decompose_deterministic_plan(user_text: str) -> Plan | None:
    raw = strip_idiomatic_conditions(user_text.strip())
    # Apply temporal inversion resolution before phase detection
    raw = resolve_temporal_order(raw)
    raw_lower = raw.lower()
    
    # Priority: Explicit CLI Output to Notepad sequence
    try:
        from command_layer.context import session_context
        from brain.workflow_orchestrator import create_cli_to_notepad_plan
        cli_np_plan = create_cli_to_notepad_plan(raw, session_context)
        if cli_np_plan is not None:
            return cli_np_plan
    except Exception:
        pass

    # Identify active phases and their start positions
    detected_phases = []
    
    m_cli = None
    quoted_spans = [q.span() for q in re.finditer(r'["\']([^"\']+)["\']', raw)]
    for m in re.finditer(r'\b(?:cmd|powershell|pwsh|terminal|command\s+prompt|services\s+count|running\s+services|hostname|whoami|echo)\b', raw, re.IGNORECASE):
        # Skip if match is inside quotes
        if any(qs <= m.start() and m.end() <= qe for qs, qe in quoted_spans):
            continue
        # Skip if match is inside warning/negation phrase
        surround = raw[max(0, m.start()-35):min(len(raw), m.end()+50)]
        if re.search(r'\b(?:mat\s+chalana|par\s+mat\s+chalana|terminal\s+par\s+mat|command\s+mat\s+do|command\s+terminal\s+par\s+mat|mat\s+chalao|don\'t\s+run|do\s+not\s+run)\b', surround, re.IGNORECASE):
            continue
        m_cli = m
        break

    if m_cli:
        detected_phases.append(('cli', m_cli.start()))
        
    m_dom = re.search(r'(https?://[^\s\]\)]+|\b[a-zA-Z0-9-]+\.(?:com|pk|org|net|io|edu)(?:/[^\s\]\)]*)?\b)', raw, re.IGNORECASE)
    m_browser = re.search(r'\b(?:chrome|browser)\b', raw, re.IGNORECASE)
    if m_dom or (m_browser and any(k in raw_lower for k in ['kholo', 'open', 'jao'])):
        if m_browser and m_dom:
            b_pos = min(m_browser.start(), m_dom.start())
        elif m_browser:
            b_pos = m_browser.start()
        else:
            b_pos = m_dom.start()
        detected_phases.append(('browser', b_pos))
        
    m_np = re.search(r'\bnotepad\b', raw, re.IGNORECASE)
    if m_np:
        detected_phases.append(('notepad', m_np.start()))
        
    m_calc = re.search(r'\b(?:calculator|calc)\b', raw, re.IGNORECASE)
    if m_calc:
        surround_c = raw[max(0, m_calc.start()-20):min(len(raw), m_calc.end()+45)].lower()
        if not any(neg in surround_c for neg in ["mat karna", "mat kholna", "mat chhoona", "bilkul mat", "ghalti mat", "don't"]):
            detected_phases.append(('calculator', m_calc.start()))

    m_game = re.search(r'\b(?:angry\s*birds?|slingshot|game\s*khelo|play\s*game|canvas)\b', raw, re.IGNORECASE)
    if m_game and not any(k in raw.lower() for k in ['downloaded', 'find', 'search', 'dhoondo']):
        detected_phases.append(('game', m_game.start()))
        
    # Deduplicate positions if any overlap and sort chronologically
    detected_phases.sort(key=lambda p: p[1])
    
    # If compound workflow across multiple phases (e.g. CLI + Browser + Notepad):
    if len(detected_phases) >= 2:
        steps = []
        for i in range(len(detected_phases)):
            ptype, start_idx = detected_phases[i]
            end_idx = detected_phases[i+1][1] if i + 1 < len(detected_phases) else len(raw)
            ptext = raw[start_idx:end_idx].strip()
            # Strip trailing connectors
            ptext = re.sub(r'\s+(?:aur|phir|and|then|uske\s+baad|iske\s+baad)\s*$', '', ptext, flags=re.IGNORECASE).strip()
            
            if ptype == 'cli':
                clean_cmd = sanitize_cli_command(ptext)
                if clean_cmd.startswith('powershell'):
                    shell = 'powershell'
                elif clean_cmd.startswith('cmd'):
                    shell = 'cmd'
                else:
                    shell = 'powershell' if any(p in ptext.lower() for p in ['powershell', 'pwsh']) else 'cmd'
                steps.append(PlanStep(step=len(steps)+1, tool='execute_system_command', args={'command': clean_cmd, 'shell': shell}))
                
            elif ptype == 'browser':
                u_m = re.search(r'(https?://[^\s\]\)]+|\b[a-zA-Z0-9-]+\.(?:com|pk|org|net|io|edu)(?:/[^\s\]\)]*)?\b)', ptext, re.IGNORECASE)
                if not u_m:
                    u_m = re.search(r'(https?://[^\s\]\)]+|\b[a-zA-Z0-9-]+\.(?:com|pk|org|net|io|edu)(?:/[^\s\]\)]*)?\b)', raw, re.IGNORECASE)
                url = sanitize_url(u_m.group(1)) if u_m else 'https://www.google.com'
                steps.append(PlanStep(step=len(steps)+1, tool='launch_app', args={'name': 'chrome'}))
                steps.append(PlanStep(step=len(steps)+1, tool='open_url', args={'url': url, 'browser': 'chrome'}))
                if hasattr(session_context, 'agent_opened_tabs'):
                    session_context.agent_opened_tabs += 1
                else:
                    session_context.agent_opened_tabs = 1
                if any(k in ptext.lower() for k in ['tab close', 'tab band', 'close kardo', 'band karo']):
                    steps.append(PlanStep(step=len(steps)+1, tool='wait_for_visual_event', args={'event_type': 'settled', 'timeout': 6.0}))
                    steps.append(PlanStep(step=len(steps)+1, tool='press_hotkey', args={'keys': 'ctrl+w'}))
                    
            elif ptype == 'notepad':
                seq_actions = parse_sequential_keyboard_actions(ptext, app_name="Notepad")
                is_close_only = any(k in ptext.lower() for k in ['close', 'band kardo']) and not seq_actions
                if is_close_only:
                    steps.append(PlanStep(step=len(steps)+1, tool='close_app', args={'name_or_pid': 'Notepad'}))
                elif seq_actions:
                    steps.append(PlanStep(step=len(steps)+1, tool='launch_app', args={'name': 'Notepad'}))
                    steps.append(PlanStep(step=len(steps)+1, tool='focus_app_window', args={'app_name': 'Notepad'}))
                    for act_tool, act_args in seq_actions:
                        steps.append(PlanStep(step=len(steps)+1, tool=act_tool, args=act_args))
                else:
                    steps.append(PlanStep(step=len(steps)+1, tool='launch_app', args={'name': 'Notepad'}))
                    if any(k in ptext.lower() for k in ['notepad close', 'notepad band', 'close notepad', 'band karo notepad']):
                        steps.append(PlanStep(step=len(steps)+1, tool='close_app', args={'name_or_pid': 'Notepad'}))
                if any(k in ptext.lower() for k in ['calculator ko foran close', 'calculator ko close', 'close calculator', 'calculator close', 'calculator band']):
                    if not any(s.tool == 'close_app' and s.args.get('name_or_pid') == 'Calculator' for s in steps):
                        steps.append(PlanStep(step=len(steps)+1, tool='close_app', args={'name_or_pid': 'Calculator'}))
                        
            elif ptype == 'calculator':
                steps.append(PlanStep(step=len(steps)+1, tool='launch_app', args={'name': 'Calculator'}))
                steps.append(PlanStep(step=len(steps)+1, tool='focus_app_window', args={'app_name': 'Calculator'}))
                math_m = re.search(r'(\d+)\s*(?:multiply\s+by|\*|x|plus|\+|minus|\-|divide\s+by|\/|aur|and)\s*(\d+)', ptext, re.IGNORECASE)
                if math_m:
                    op = '*' if any(w in ptext.lower() for w in ['multiply', '*', 'x', 'zarb']) else ('+' if any(w in ptext.lower() for w in ['plus', '+', 'jama', 'add']) else ('-' if any(w in ptext.lower() for w in ['minus', '-']) else '/'))
                    expr = f"{math_m.group(1)}{op}{math_m.group(2)}="
                    steps.append(PlanStep(step=len(steps)+1, tool='send_keyboard_input', args={'text': expr, 'app_name': 'Calculator'}))
                if any(k in ptext.lower() for k in ['close', 'band kardo', 'band karo']):
                    steps.append(PlanStep(step=len(steps)+1, tool='close_app', args={'name_or_pid': 'Calculator'}))

            elif ptype == 'game':
                steps.append(PlanStep(step=len(steps)+1, tool='run_autonomous_agent', args={'task_type': 'game', 'query': ptext or raw}))
                
        return Plan(steps=steps)

    # Priority 0: Dynamic System Path Normalizer ("desktop/downloads/documents par 'X' banao")
    m_path_banao = re.search(
        r'\b(?:desktop|downloads?|documents?)\s+(?:par|pe|mein|me|ma)\s+(?:ek\s+)?(?:["\']([^"\']+)["\']|([a-zA-Z0-9_:\-\\/.]+))\s*(?:ke\s+naam\s+se\s+)?(?:folder|file)?\s*(?:banao|banayein|create\s+karo|create|make)?\b',
        raw,
        re.IGNORECASE
    )
    if m_path_banao and any(w in raw_lower for w in ["banao", "banayein", "create", "make"]) and not any(w in raw_lower for w in ["aur uske andar", "uske andar", "and inside it", "and in it", "dhoondo", "dhundo", "search", "find", "talash", "khojo", "locate", "look for", "open", "kholo", "read"]):
        t_name = (m_path_banao.group(1) or m_path_banao.group(2)).strip().strip("'\"")
        if t_name and t_name.lower() not in ("folder", "file", "ek", "par", "pe", "mein", "me", "ma"):
            target_path = resolve_system_canonical_path(raw)
            steps = []
            if _has_file_extension(t_name) or ("file" in raw_lower and "folder" not in raw_lower):
                steps.append(PlanStep(step=1, tool="create_file", args={"path": target_path}))
            else:
                steps.append(PlanStep(step=1, tool="create_folder", args={"path": target_path}))

            # Compound Continuation: inspect remaining clauses
            from command_layer.decomposer import decompose_compound_command
            clauses = decompose_compound_command(raw)
            folder_clause_found = False
            for c in clauses:
                c_str = c.strip(" ,;.-")
                c_low = c_str.lower()
                if not folder_clause_found:
                    if any(w in c_low for w in ["desktop", "downloads", "documents"]) and any(w in c_low for w in ["banao", "create", "make"]):
                        folder_clause_found = True
                    continue

                if "notepad" in c_low and any(w in c_low for w in ["kholo", "open", "launch"]):
                    steps.append(PlanStep(step=len(steps) + 1, tool="launch_app", args={"name": "Notepad"}))
                    steps.append(PlanStep(step=len(steps) + 1, tool="focus_app_window", args={"app_name": "Notepad"}))
                elif any(w in c_low for w in ["mouse", "cursor", "pointer", "le jao", "hover"]):
                    t_m = re.search(r'\b(minimize\s+button|minimize|close\s+button|close|save|button)\b', c_low)
                    btn_target = t_m.group(0) if t_m else "minimize"
                    steps.append(PlanStep(step=len(steps) + 1, tool="hover_mouse", args={"target": btn_target, "action": "hover", "x": 683, "y": 384, "duration": 1.0}))
                elif any(w in c_low for w in ["mat chalana", "chhoona bhi mat", "mat karna", "bilkul mat", "mat chhedna"]):
                    continue
                else:
                    from command_layer.context import session_context
                    sub_p = route_command(c_str, session_context, is_compound_root=False)
                    if sub_p and sub_p.steps:
                        for s in sub_p.steps:
                            s.step = len(steps) + 1
                            steps.append(s)

            return Plan(steps=steps)

    # Standalone single-phase checks
    # Priority 1: Multi-line / Sequential Notepad Intent Isolation
    has_close = any(k in raw_lower for k in ['close', 'band'])
    if not has_close and 'notepad' in raw_lower and not any(k in raw_lower for k in ['folder', 'banao', 'create folder', 'create file', 'desktop par', 'downloads par', 'documents par']) and ('enter' in raw_lower or 'line' in raw_lower or '"' in raw or "'" in raw or 'ctrl' in raw_lower or 'backspace' in raw_lower or 'erase' in raw_lower or 'likho' in raw_lower or 'type' in raw_lower) and not any(k in raw_lower for k in ['click', 'screenshot', 'capture', 'press element']):
        seq_actions = parse_sequential_keyboard_actions(raw, app_name="Notepad")
        if seq_actions:
            steps = [
                PlanStep(step=1, tool='launch_app', args={'name': 'Notepad'}),
                PlanStep(step=2, tool='focus_app_window', args={'app_name': 'Notepad'}),
            ]
            for act_tool, act_args in seq_actions:
                steps.append(PlanStep(step=len(steps)+1, tool=act_tool, args=act_args))
            return Plan(steps=steps)

    # Priority 2: Standalone Web Domain Navigation
    if is_standalone_navigation_request(raw):
        d_match = re.search(r'(https?://[^\s\]\)]+|\b[a-zA-Z0-9-]+\.(?:com|pk|org|net|io|edu)(?:/[^\s\]\)]*)?\b)', raw, re.IGNORECASE)
        if d_match and any(k in raw_lower for k in ['kholo', 'open', 'jao', 'browser', 'chrome']):
            url = sanitize_url(d_match.group(1))
            steps = [
                PlanStep(step=1, tool='launch_app', args={'name': 'chrome'}),
                PlanStep(step=2, tool='open_url', args={'url': url, 'browser': 'chrome'})
            ]
            if hasattr(session_context, 'agent_opened_tabs'):
                session_context.agent_opened_tabs += 1
            else:
                session_context.agent_opened_tabs = 1
            if any(k in raw_lower for k in ['tab close', 'tab band', 'close kardo', 'band karo']):
                steps.append(PlanStep(step=3, tool='wait_for_visual_event', args={'event_type': 'settled', 'timeout': 6.0}))
                steps.append(PlanStep(step=4, tool='press_hotkey', args={'keys': 'ctrl+w'}))
            return Plan(steps=steps)

    # Priority 3: Autonomous Game vs. Downloaded Local App Search
    if 'downloaded' in raw_lower and 'angry bird' in raw_lower:
        return Plan(steps=[
            PlanStep(step=1, tool='find_file', args={'name': 'Angry Bird', 'start_folder': 'Downloads'})
        ], explanation="Search local Downloads for downloaded Angry Bird executable without web redirect.")

    if any(k in raw_lower for k in ['angry bird', 'slingshot', 'game khelo', 'play game', 'canvas']) and not any(k in raw_lower for k in ['downloaded', 'find', 'search', 'dhoondo']):
        return Plan(steps=[
            PlanStep(step=1, tool='run_autonomous_agent', args={'task_type': 'game', 'query': raw})
        ])

    # Priority 4: Standalone Headless CLI Execution
    trans = translate_cli_command(raw)
    if trans:
        shell = 'powershell' if trans.startswith('powershell') else 'cmd'
        return Plan(steps=[
            PlanStep(step=1, tool='execute_system_command', args={'command': trans, 'shell': shell})
        ])
    if any(k in raw_lower for k in ['cmd', 'powershell', 'terminal']) and any(k in raw_lower for k in ['chalao', 'run', 'nikalo', 'execute']) and not re.search(r'\b(?:mat\s+chalana|mat\s+chalao|don\'t\s+run|do\s+not\s+run|par\s+mat\s+chalana)\b', raw_lower):
        shell = 'powershell' if 'powershell' in raw_lower else 'cmd'
        clean_cmd = sanitize_cli_command(raw)
        return Plan(steps=[
            PlanStep(step=1, tool='execute_system_command', args={'command': clean_cmd, 'shell': shell})
        ])

    # Priority 5: Semantic Negation Disarm Filter ("click mat karna", "click bilkul mat karna", "hover karo lekin click nahi")
    has_negative_click = UniversalLexer.should_disarm_click(raw_lower) or bool(re.search(
        r'\b(?:click\s+(?:bilkul\s+)?mat\s+kar(?:na|o)|hover\s+karo\s+(?:lekin\s+)?click\s+(?:nahi|mat)|hover\s+karo\s+click\s+nahi|lekin\s+click\s+(?:nahi|mat)|click\s+(?:bilkul\s+)?nahi\s+kar(?:na|o)|click\s+nahi\b|click\s+mat\b|mat\s+click\s+kar(?:na|o)|don\'?t\s+click|do\s+not\s+click|never\s+click)\b',
        raw_lower
    ))
    has_mouse_intent = any(w in raw_lower for w in ["hover", "mouse", "cursor", "pointer", "move", "le jao"]) or bool(re.search(r'\(?\d+[\s,]+\d+\)?', raw_lower))
    if has_negative_click and has_mouse_intent and not any(app in raw_lower for app in ['notepad', 'chrome', 'calculator', 'cmd', 'powershell', 'browser']):
        coord_h = re.search(r'\(?(\d+)[\s,]+(\d+)\)?', raw_lower)
        dur = 1.0
        dur_m = re.search(r'(\d+(?:\.\d+)?)\s*(?:seconds?|s|second)\b', raw_lower)
        if dur_m:
            dur = float(dur_m.group(1))
        cx, cy = (int(coord_h.group(1)), int(coord_h.group(2))) if coord_h else (500, 300)
        tool_name = "move_mouse_smooth" if any(w in raw_lower for w in ["smooth", "move"]) else "hover_mouse"
        return Plan(
            steps=[PlanStep(step=1, tool=tool_name, args={"x": cx, "y": cy, "duration": dur})],
            explanation="Routed to hover_mouse/move_mouse_smooth with click explicitly suppressed due to negative constraint."
        )

    return None


def _route_command_impl(text: str, context: SessionContext, is_compound_root: bool = True) -> Plan | None:
    """Internal deterministic intent classifier and plan generator."""
    # Phase 3: Headless Web Research Intercept
    clean_lower = text.lower()
    if "research" in clean_lower and ("duckduckgo" in clean_lower or "web" in clean_lower):
        q_m = re.search(r'["\']([^"\']+)["\']', text)
        if q_m:
            query = q_m.group(1).strip()
        else:
            query = re.sub(r'\b(?:research\s+karo|duckduckgo\s+se|duckduckgo|aur\s+summary\s+display\s+karo|summary\s+display\s+karo|summary\s+karo)\b', '', text, flags=re.IGNORECASE).strip()
        return Plan(
            steps=[PlanStep(step=1, tool="research_web_solution", args={"query": query})],
            explanation="Headless socket research query via DuckDuckGo Lite under 10MB RAM."
        )

    # Deterministic Conjunction Decomposer (Priority 0 - 3)
    if is_compound_root:
        det_plan = decompose_deterministic_plan(text)
        if det_plan is not None and det_plan.steps:
            return _isolate_browser_context(_canonicalize_plan_tools(det_plan), text)

    # Priority 0: Web Domain Navigation Intercept (Strictly standalone only)
    if is_standalone_navigation_request(text):
        domain_match = re.search(r'(https?://[^\s\]\)]+|\b[a-zA-Z0-9-]+\.(?:com|pk|org|net|io|edu)(?:/[^\s\]\)]*)?\b)', text, re.IGNORECASE)
        if domain_match and not any(w in text.lower() for w in ['search karo', 'search kardo', 'dhoondo']):
            return _classify_and_parse_command(text, context, is_compound_root)

    
    # Autonomous Visual Re-Act Engine Intercept vs. Local Downloaded App Search
    if "downloaded" in text.lower() and "angry bird" in text.lower():
        return Plan(
            steps=[
                PlanStep(step=1, tool="find_file", args={"name": "Angry Bird", "start_folder": "Downloads"})
            ],
            explanation="Search local paths for downloaded Angry Bird executable."
        )

    if re.search(r'\b(?:(?:play\s+)?angry\s+birds?|daily\s+mission|game\s+(?:shoot|jeeto|khelo|play)|puzzle|slingshot\s+(?:se\s+)?shoot|slingshot\s+strike)\b', text.lower()):
        return Plan(
            steps=[
                PlanStep(step=1, tool="run_autonomous_agent", args={"task_type": "game", "query": text})
            ],
            explanation="Autonomous closed-loop visual Re-Act engine engaged for continuous gameplay."
        )

    if is_compound_root:
        from command_layer.decomposer import decompose_compound_command as decomp_intents
        sub_intents = decomp_intents(text)
        if len(sub_intents) > 1:
            from brain.workflow_orchestrator import orchestrate_compound_workflow
            orch_plan = orchestrate_compound_workflow(text, context)
            if orch_plan is not None and orch_plan.steps:
                final_orch = _isolate_browser_context(_canonicalize_plan_tools(orch_plan), text)
                has_neg = bool(re.search(r'\b(?:click\s+(?:bilkul\s+)?mat\s+kar(?:na|o)|hover\s+karo\s+(?:lekin\s+)?click\s+(?:nahi|mat)|hover\s+karo\s+click\s+nahi|lekin\s+click\s+(?:nahi|mat)|click\s+(?:bilkul\s+)?nahi\s+kar(?:na|o)|click\s+nahi\b|click\s+mat\b|mat\s+click\s+kar(?:na|o)|don\'?t\s+click|do\s+not\s+click|never\s+click)\b', text.lower()))
                if has_neg and final_orch and final_orch.steps:
                    for s in final_orch.steps:
                        if s.tool in ("click_ui_element", "click_mouse", "mouse_click", "click_element_by_text"):
                            s.tool = "move_mouse_smooth" if "move" in text.lower() else "hover_mouse"
                            cx = s.args.get("x", 500) if isinstance(s.args, dict) else 500
                            cy = s.args.get("y", 300) if isinstance(s.args, dict) else 300
                            dur = s.args.get("duration", 1.0) if isinstance(s.args, dict) else 1.0
                            s.args = {"x": cx, "y": cy, "duration": dur}
                return final_orch

    plan = _classify_and_parse_command(text, context, is_compound_root)
    if plan is not None:
        final_p = _isolate_browser_context(_canonicalize_plan_tools(plan), text)
        has_neg = bool(re.search(r'\b(?:click\s+(?:bilkul\s+)?mat\s+kar(?:na|o)|hover\s+karo\s+(?:lekin\s+)?click\s+(?:nahi|mat)|hover\s+karo\s+click\s+nahi|lekin\s+click\s+(?:nahi|mat)|click\s+(?:bilkul\s+)?nahi\s+kar(?:na|o)|click\s+nahi\b|click\s+mat\b|mat\s+click\s+kar(?:na|o)|don\'?t\s+click|do\s+not\s+click|never\s+click)\b', text.lower()))
        if has_neg and final_p and final_p.steps:
            for s in final_p.steps:
                if s.tool in ("click_ui_element", "click_mouse", "mouse_click", "click_element_by_text"):
                    s.tool = "move_mouse_smooth" if "move" in text.lower() else "hover_mouse"
                    cx = s.args.get("x", 500) if isinstance(s.args, dict) else 500
                    cy = s.args.get("y", 300) if isinstance(s.args, dict) else 300
                    dur = s.args.get("duration", 1.0) if isinstance(s.args, dict) else 1.0
                    s.args = {"x": cx, "y": cy, "duration": dur}
        return final_p
    return None


def route_command(text: str, context: Optional[SessionContext] = None, is_compound_root: bool = True) -> Plan:
    """
    Proactive cognitive router: Identifies high-level intent, infers missing steps,
    and constructs fully-realized end-to-end actuation plans.
    """
    if context is None:
        from command_layer.context import session_context as _default_ctx
        context = _default_ctx

    # Pre-process: strip conversational noise and resolve temporal inversions
    text = strip_idiomatic_conditions(text)
    text = resolve_temporal_order(text)
    if not text:
        return Plan(steps=[])

    # Cognitive intent inference
    try:
        from command_layer.cognitive_reasoner import CognitiveReasoner
        intent = CognitiveReasoner.infer_domain_intent(text)
    except Exception:
        intent = {"type": "DIRECT_OPERATION"}

    t_lower = text.lower()

    # --------------------------------------------------------------------------
    # BRANCH A: HIGH-LEVEL GOAL -> DYNAMIC GAME SYNTHESIS & LAUNCH (Tree-of-Thought)
    # --------------------------------------------------------------------------
    if intent.get("type") == "ABSTRACT_SYNTHESIS_GAME":
        from brain.dynamic_thinking_engine import DynamicThinkingEngine
        engine = DynamicThinkingEngine()
        game_html_code = engine.synthesize_code_asset(text)
        desktop_dir = os.path.join(os.path.expanduser("~"), "Desktop")
        game_file = os.path.join(desktop_dir, "goku_game.html")
        fallback_file = os.path.join(os.path.expanduser("~"), "goku_fallback_game.html")

        # Primary Pathway: Write to desktop -> Launch in browser
        primary_steps = [
            Step("write_file", {"filepath": game_file, "content": game_html_code}, step=1),
            Step("open_url", {"url": f"file:///{game_file.replace(os.sep, '/')}"}, step=2)
        ]
        # Alternative Contingency Pathway: Write to user profile -> Launch via system command
        fallback_steps = [
            Step("write_file", {"filepath": fallback_file, "content": game_html_code}, step=1),
            Step("execute_system_command", {"command": f"start {game_file}", "shell": "cmd"}, step=2)
        ]
        fallback_plan = Plan(steps=fallback_steps, explanation="Tree-of-Thought contingency pathway for game execution.")
        tot_nodes = engine.explode_intent_to_tot(text)
        return Plan(steps=primary_steps, intent_metadata=intent, fallback_plan=fallback_plan, tot_nodes=tot_nodes)

    # --------------------------------------------------------------------------
    # BRANCH B: HIGH-LEVEL GOAL -> DYNAMIC DOCUMENT / BLOG SYNTHESIS (Tree-of-Thought)
    # --------------------------------------------------------------------------
    if intent.get("type") == "ABSTRACT_SYNTHESIS_BLOG":
        from brain.dynamic_thinking_engine import DynamicThinkingEngine
        engine = DynamicThinkingEngine()
        topic = intent.get("topic", "Technology Evolution")
        blog_content = engine.synthesize_document_asset(topic, text)
        primary_steps = [
            Step("launch_app", {"name": "Notepad"}, step=1),
            Step("focus_app_window", {"app_name": "Notepad"}, step=2),
            Step("type_text", {"text": blog_content, "press_enter": True, "app_name": "Notepad"}, step=3)
        ]
        fallback_steps = [
            Step("execute_system_command", {"command": "notepad.exe", "shell": "cmd"}, step=1),
            Step("type_text", {"text": blog_content, "press_enter": True, "app_name": "Notepad"}, step=2)
        ]
        fallback_plan = Plan(steps=fallback_steps, explanation="Tree-of-Thought contingency pathway for document synthesis.")
        return Plan(steps=primary_steps, intent_metadata=intent, fallback_plan=fallback_plan)

    # --------------------------------------------------------------------------
    # BRANCH C: PROACTIVE CALCULATOR REASONING (App Affordance + Predicted Input)
    # (Only standalone / non-compound to preserve compound workflows & temporal chains)
    # --------------------------------------------------------------------------
    has_neg_or_compound = any(w in t_lower for w in ["mat kholo", "mat kholna", "mat chalao", "bilkul mat", "phir socha", "pehle", "se pehle", "agar", "warna", "chhor kar"])
    if intent.get("type") == "AFFORDANCE_CALCULATOR" and not has_neg_or_compound and not any(w in t_lower for w in ["notepad", "browser", "chrome", "cmd", "file"]):
        steps = [
            Step("launch_app", {"name": "Calculator"}, step=1),
            Step("focus_app_window", {"app_name": "Calculator"}, step=2)
        ]
        if intent.get("math_expr"):
            steps.append(Step("send_keyboard_input", {"keys": intent["math_expr"], "text": intent["math_expr"], "app_name": "Calculator"}, step=3))
        return Plan(steps=steps, intent_metadata=intent)

    # Standard / Advanced Deterministic Routing Engine
    plan = _route_command_impl(text, context, is_compound_root=is_compound_root)
    if plan is None:
        try:
            import brain.llm
            tool_schemas = get_all_schemas() if "get_all_schemas" in globals() else []
            decision = brain.llm.ask_llm(text, tool_schemas)
            plan = create_plan_from_decision(decision)
        except Exception:
            pass

    if plan is None:
        return Plan(steps=[])

    filtered_plan = prune_negated_steps(plan, text)
    return filtered_plan if filtered_plan is not None else plan
