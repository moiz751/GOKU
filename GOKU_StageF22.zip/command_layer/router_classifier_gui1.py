from __future__ import annotations
import os
from pathlib import Path
import re
import sys
import time
from typing import Any, Optional, Union, List, Dict, Tuple
from dataclasses import dataclass, field

from brain.planner import (
    Plan,
    PlanStep,
    StructuredIntent,
    create_plan_from_decision,
    decompose_compound_command,
    parse_compound_request,
    resolve_step_variables,
    resolve_step_variables_with_guard,
    inject_plan_prerequisites,
    prune_plan_steps,
    build_hypothesis_investigation_plan,
    build_root_cause_investigation_plan,
    parse_conditional_goal,
    synthesize_adaptive_replan,
    decompose_into_milestones,
    restore_plan_from_checkpoint,
    build_cross_domain_plan,
    apply_cross_domain_transformation,
    build_long_horizon_exploration_plan,
    decompose_long_horizon_goal,
    compute_state_hash,
    detect_state_cycle,
    heuristic_node_score,
    expand_exploration_frontier,
    select_next_frontier_node,
    apply_reflective_history_pruning,
)
from command_layer.cognitive_reasoner import CognitiveReasoner
from command_layer.context import (
    EntityType,
    TypedEntity,
    ORDINAL_REFERENCES,
    SessionContext,
    resolve_references,
    session_context,
    update_context_from_result,
)
from command_layer.semantic_model import (
    SemanticDomain,
    SemanticAction,
    CommandIntent,
    AmbiguityType,
    ClarificationRequest,
    SymptomCategory,
    SituationType,
    ConfidenceTier,
    RiskTier,
    ConfidenceScore,
    ConfirmationRequest,
    FailureType,
    AdaptiveStrategy,
    PlanAdaptation,
    TaskLifecycleState,
    TaskMilestone,
    TaskCheckpoint,
    DomainBridgeType,
    DomainBridgeLink,
    CrossDomainWorkflow,
    HorizonDepth,
    ExplorationNode,
    SearchFrontier,
    LongHorizonReport,
    HistoryQueryType,
    ExecutionTraceRecord,
    TraceSummary,
)
from command_layer.semantic_parser import (
    parse_semantic_intent,
    create_plan_from_intent,
    resolve_in_turn_correction,
    strip_conversational_noise,
    split_compound_clauses,
    detect_symptom_category,
)
from command_layer.firewall import validate_tool_against_firewall, pre_execution_semantic_check, validate_long_horizon_action
from command_layer.state_machine import agent_state
from command_layer.validator import validate_and_sanitize_tool_arguments
from command_layer.lexer import UniversalLexer
from brain.runtime_bus import RuntimePipingBus
from security.state import confirmation_manager
from tools.utils.app_resolver import (
    APP_ALIASES,
    get_canonical_app_name,
    resolve_app,
)
from tools.utils.target_resolver import TargetType, resolve_universal_target, disambiguate_multi_candidates
from command_layer.router_base import (
    Step,
    run_tool_call,
    resolve_system_canonical_path,
    verify_post_recovery,
    verify_semantic_outcome,
    capture_environment_snapshot,
    capture_step_observation,
    detect_environment_drift,
    _entity_val,
    get_all_schemas,
    KNOWN_SITE_KEYS,
    KNOWN_APP_NAMES,
    _has_file_extension,
    _normalize_resolved_path,
    _is_conversational_folder_path,
)
from security.safety_firewall import is_safe_readonly_operation
from security.confirm import RISKY_TOOLS
from command_layer.decomposer import count_action_verbs
from brain.workflow_orchestrator import orchestrate_compound_workflow
from tools.browser import sanitize_search_query
from tools.search import parse_search_grammar
import executor.verifier
import executor.executor

from command_layer.router_sanitizer import (
    _isolate_browser_context,
    prune_negated_steps,
    sanitize_action_query,
    sanitize_url,
    _canonicalize_plan_tools,
    sanitize_ui_target,
    extract_clean_search_query,
)
from command_layer.router_cli_parser import (
    translate_cli_command,
    sanitize_cli_command,
    extract_pure_text_payload,
    parse_sequential_keyboard_actions,
    is_standalone_navigation_request,
    resolve_temporal_order,
    strip_idiomatic_conditions,
)
from command_layer.router_confidence import (
    determine_risk_tier,
    format_uncertainty_response,
    compute_command_confidence,
    synthesize_cross_domain_report,
    synthesize_long_horizon_report,
    get_conversational_response,
)

def _classify_and_parse_command(text: str, context: SessionContext | None = None, is_compound_root: bool = True) -> Plan | None:
    from command_layer.router_classifier_core import _classify_and_parse_command as _real_fn
    return _real_fn(text, context, is_compound_root)

def classify_gui_intents_1(text: str, context: SessionContext | None = None, is_compound_root: bool = True) -> Plan | None:
    from command_layer.decomposer import count_action_verbs
    from brain.workflow_orchestrator import orchestrate_compound_workflow
    from tools.browser import sanitize_search_query
    from tools.search import parse_search_grammar
    from security.safety_firewall import is_safe_readonly_operation
    from security.confirm import RISKY_TOOLS
    cleaned = re.sub(r'[\x00-\x1f\x7f]+$', '', text).strip()
    cleaned = re.sub(r'[\x13\x03\x1b]', '', cleaned).strip()
    raw_lower = cleaned.lower()
    lower = text.lower()
    folder_ref_m = re.search(r"folder\s+'([^']+)'", text)
    file_ref_m = re.search(r"file\s+'([^']+)'", text)
    text_unwrapped = re.sub(r'[\'"]([^\'"]+)[\'"]', r'\1', text)
    try:
        symptom_cat, situation_type, symptom_entities = detect_symptom_category(raw_lower)
    except Exception:
        symptom_cat, situation_type, symptom_entities = SymptomCategory.NONE, SituationType.NORMAL, []
    _p2_is_compound_guard = False
    # Matches: "YouTube icon par click karo", "is button par click karo", "'YouTube' click karo", "Chrome icon par click karo", "search box par click karo"
    if (
        "click" in lower
        and (any(w in lower for w in ["icon", "button", "box", "field", "text"]) or re.search(r"['\"][^'\"]+['\"]\s*(par\s+)?click", lower))
        and not ("double click file" in lower or "mouse ka" in lower or "mouse button" in lower or "right button" in lower or "middle button" in lower or "left button" in lower)
    ):
        q_target = re.sub(r'\b(par\s+click\s+karo|par\s+click\s+kar\s+do|click\s+karo|click\s+on|click|please)\b', '', text, flags=re.IGNORECASE).strip().strip("'\"")
        if q_target:
            return Plan(steps=[PlanStep(step=1, tool="click_ui_element", args={"query": q_target})])

    # Matches: "Chrome icon locate karo", "search box locate karo", "Notepad window find karo", "screen par jo Chrome hai usko identify karo", "is text ko screen par find karo"
    if (
        (any(w in lower for w in ["locate karo", "locate", "identify karo", "identify"]) and not any(sep in lower for sep in [",", " aur ", " and ", " phir ", " then "]))
        and not ("file" in lower or "pdf" in lower or "txt" in lower or "folder" in lower or _has_file_extension(lower) or "downloads" in lower or "desktop" in lower or "documents" in lower)
    ) or (
        ("find karo" in lower or "dhundo" in lower) and any(w in lower for w in ["icon", "box", "button", "window", "text"]) and not ("file" in lower or "pdf" in lower or "folder" in lower)
    ):
        q = text
        # Extract target query
        clean_q = re.sub(r'\b(screen\s+par\s+jo|screen\s+par|usko\s+identify\s+karo|identify\s+karo|locate\s+karo|find\s+karo|dhundo|locate|identify|find|hai|please)\b', '', q, flags=re.IGNORECASE).strip().strip("'\"")
        el_type = None
        if "icon" in lower:
            el_type = "icon"
            clean_q = re.sub(r'\bicon\b', '', clean_q, flags=re.IGNORECASE).strip()
        elif "button" in lower:
            el_type = "button"
            clean_q = re.sub(r'\bbutton\b', '', clean_q, flags=re.IGNORECASE).strip()
        elif "box" in lower or "search" in lower or "input" in lower:
            el_type = "input"
            clean_q = re.sub(r'\b(box|field|input)\b', '', clean_q, flags=re.IGNORECASE).strip()
        elif "window" in lower:
            el_type = "window"
            clean_q = re.sub(r'\bwindow\b', '', clean_q, flags=re.IGNORECASE).strip()
        if clean_q:
            args_map = {"query": clean_q}
            if el_type:
                args_map["element_type"] = el_type
            return Plan(steps=[PlanStep(step=1, tool="locate_ui_element", args=args_map)])

    # -------------------------------------------------------------
    # 3.5 COMPOUND WORKFLOW AUTOMATION INTENTS (Phase 4D)
    # -------------------------------------------------------------
    # Matches: "WiFi networks kitne detect ho rahe hain?", "Available WiFi networks ke naam batao", "Current WiFi connection status batao", "Current WiFi ka SSID aur signal strength batao", "Network connection active hai ya nahi check karo"
    if any(k in lower for k in ["wifi", "wi-fi", "network", "ssid", "internet connection"]) and any(w in lower for w in ["kitne", "count", "naam", "available", "detect", "status", "active", "signal", "strength", "check", "batao"]):
        q_type = "networks" if any(w in lower for w in ["kitne", "count", "naam", "available", "detect", "list"]) else "status"
        return Plan(steps=[PlanStep(step=1, tool="get_network_state", args={"query_type": q_type})])

    # Matches: "screen par koi dialog open hai kya?", "active dialog info batao", "is there any open dialog?"
    if "dialog" in lower and any(w in lower for w in ["open hai", "hai kya", "batao", "active", "is there", "check", "info", "dekho"]):
        return Plan(steps=[PlanStep(step=1, tool="get_active_dialog", args={})])

    # Matches: "Save button aane ka wait karo", "wait for Save button", "wait for 'Save'", "Notepad aane ka intezar karo"
    if any(w in lower for w in ["wait karo", "wait for", "intezar karo", "aane ka wait", "aane ka intezar"]):
        q = re.sub(r'\b(aane\s+ka\s+wait\s+karo|aane\s+ka\s+intezar\s+karo|wait\s+karo|wait\s+for|intezar\s+karo|button|window|dialog|please)\b', '', text, flags=re.IGNORECASE).strip().strip("'\"")
        if q:
            return Plan(steps=[PlanStep(step=1, tool="wait_for_ui_element", args={"query": q, "timeout_seconds": 5.0})])

    # Matches: "Chrome search bar mein TEST CHROME likho", "search bar mein GTA 6 likho", "address bar mein google.com type karo"
    if ("search bar mein" in lower or "search box mein" in lower or "address bar mein" in lower or "search input mein" in lower) and ("likho" in lower or "type" in lower) and not any(k in lower for k in ["locate", "type karke enter", "'", '"']):
        target = "address bar" if "address" in lower else "search bar"
        txt_m = re.search(r'\b(?:mein|me|par)\b\s+([a-zA-Z0-9_\-\s]+?)(?:\s+likho|\s+type|\s+enter|$)', text, re.IGNORECASE)
        txt = txt_m.group(1).strip() if txt_m else "TEST"
        txt = re.sub(r'\b(likho|type|karo|kar\s+do|please)\b', '', txt, flags=re.IGNORECASE).strip() or "TEST"
        return Plan(steps=[
            PlanStep(step=1, tool="find_and_interact", args={"target_query": target, "query": target, "action": "type", "input_text": txt})
        ])

    # Matches: "Search box locate karke click karo", "Search box mein 'Google' type karke Enter dabao"
    if any(k in lower for k in ["locate karke click", "locate karke type", "locate and click", "locate and type", "type karke enter", "type karke enter dabao"]):
        target = "Search"
        t_m = re.search(r'\b([a-zA-Z0-9_\-]+(\s+[a-zA-Z0-9_\-]+)?)\s+(locate\s+karke|mein|par)', text, flags=re.IGNORECASE)
        if t_m:
            target = t_m.group(1).strip()
            target = re.sub(r'\b(box|field|input|button|icon)\b', '', target, flags=re.IGNORECASE).strip() or target

        # Extract text to type if present
        txt_m = re.search(r"['\"]([^'\"]+)['\"]", text)
        input_txt = txt_m.group(1) if txt_m else None
        has_enter = "enter" in lower

        args_map = {"target_query": target, "query": target}
        if input_txt:
            args_map["input_text"] = input_txt
            args_map["action"] = "type"
        else:
            args_map["action"] = "click"
        if has_enter:
            args_map["post_key"] = "enter"

        return Plan(steps=[PlanStep(step=1, tool="find_and_interact", args=args_map)])

    # Matches: "is document ko scratch par notes.txt ke naam se save karo", "save as test.txt", "save test.txt", "test.txt naam se save karo"
    if (("save" in lower and any(w in lower for w in ["dialog", "save as", "save karo", "ke naam se", "naam se"])) or (lower.startswith("save ") and any(w in lower for w in [".txt", ".docx", ".pdf", ".py", ".md", ".json"]))) and not ("to " in lower or "active document" in lower or "\\" in text or "/" in text):
        fname_m = re.search(r"['\"]?([a-zA-Z0-9_\-]+\.[a-zA-Z0-9]+)['\"]?", text)
        if not fname_m:
            return Plan(
                is_direct_message=True,
                message_text="Please specify which file name you would like to save, or specify the destination path."
            )
        fname = fname_m.group(1)
        folder = "scratch"  # Prompt D: Default working folder is scratch/ inside project, never Desktop
        if "downloads" in lower:
            folder = "Downloads"
        elif "documents" in lower:
            folder = "Documents"
        args_map = {"filename": fname, "destination_folder": folder}
        return Plan(steps=[PlanStep(step=1, tool="save_file_dialog", args=args_map)])

    # -------------------------------------------------------------
    # 4. WINDOW MANAGEMENT & INSPECTION INTENTS (Phase 4B & Phase 1)
    # -------------------------------------------------------------
    # Matches: "title bar par double click karke maximize karo", "title bar par double click karo"
    if "title bar" in lower and "double click" in lower:
        return Plan(steps=[PlanStep(step=1, tool="manage_window", args={"action": "title_bar_double_click"})])

    # Matches: "window ko left side snap karo", "window ko right side snap karo", "left snap karo", "right snap karo"
    if (bool(re.search(r'\bsnap\b', lower)) and "snapshot" not in lower) or ("side" in lower and ("left" in lower or "right" in lower) and "lagao" in lower):
        side = "right" if "right" in lower else ("top" if "top" in lower or "upar" in lower else "left")
        return Plan(steps=[PlanStep(step=1, tool="snap_window_drag", args={"side": side})])

    # Matches: "window corner se drag karke resize karo", "window corner drag", "border drag"
    if "drag" in lower and ("corner" in lower or "border" in lower or "edge" in lower or "resize" in lower):
        return Plan(steps=[PlanStep(step=1, tool="drag_window_border", args={"edge": "bottom_right", "delta_x": 120, "delta_y": 90})])

    # Matches: "window info batao", "active window ki info batao", "Notepad window info batao"
    if "window" in lower and any(w in lower for w in ["info", "information", "details", "properties"]) and not any(w in lower for w in ["minimize", "maximize", "restore", "close"]):
        app_cand = None
        for app in KNOWN_APP_NAMES:
            if re.search(rf'\b{re.escape(app)}\b', lower):
                app_cand = get_canonical_app_name(app)
                break
        args = {"app_name": app_cand} if app_cand else {}
        return Plan(steps=[PlanStep(step=1, tool="get_window_info", args=args)])

    if any(b in lower for b in ["minimize button", "maximize button", "close button", "titlebar button", "window button"]):
        if any(w in lower for w in ["chhoona bhi mat", "mat chhoona", "mat chhedna", "bilkul mat", "mat touch"]):
            return None
        action = "click" if "click" in lower else "move"
        t_query = "minimize button" if "minimize" in lower else ("maximize button" if "maximize" in lower else "close button")
        app_prefix_m = re.search(r'([a-zA-Z0-9_\-]+)\s+(?:ke|ki|ka)?\s*(?:minimize|maximize|close)\s+button', text, flags=re.IGNORECASE)
        if app_prefix_m and app_prefix_m.group(1).lower() not in ("mouse", "cursor", "is", "us", "ye", "wo"):
            t_query = f"{app_prefix_m.group(1)} {t_query}"
        return Plan(steps=[PlanStep(step=1, tool="find_and_interact", args={"target_query": t_query, "query": t_query, "action": action})])

    # Matches: "Notepad ki doosri window close karo", "Notepad ki pehli window close karo", "Notepad minimize karo", "usko minimise kardo", "Chrome maximize karo"
    if any(w in lower for w in ["minimize", "minimise", "maximize", "restore", "chhota", "bada", "close", "band"]) and not ("search" in lower or "button" in lower or "mouse" in lower or "tab" in lower or (("close" in lower or "band" in lower) and ("file" in lower or "folder" in lower))):
        action = "minimize" if ("minimize" in lower or "minimise" in lower or "chhota" in lower) else ("maximize" if ("maximize" in lower or "bada" in lower) else ("close" if ("close" in lower or "band" in lower) else "restore"))
        if action == "close" and any(neg in lower for neg in ["mat karna", "mat karo", "bilkul mat", "band mat", "close mat", "don't close", "dont close", "open rehne do", "chup chaap", "rehne do"]):
            return None
        if action == "minimize" and any(neg in lower for neg in ["mat karna", "mat karo", "bilkul mat", "minimize mat", "don't minimize", "dont minimize"]):
            return None
        app_cand = None
        for app in KNOWN_APP_NAMES:
            if re.search(rf'\b{re.escape(app)}\b', lower):
                app_cand = get_canonical_app_name(app)
                break
        if not app_cand and context and (context.last_application or context.last_window or context.last_launched_application):
            if context.last_application:
                app_cand = getattr(context.last_application, "value", context.last_application)
            elif context.last_window:
                app_cand = getattr(context.last_window, "value", context.last_window)
            elif context.last_launched_application:
                app_cand = getattr(context.last_launched_application, "value", context.last_launched_application)
        instance_idx = 0
        if "doosri" in lower or "second" in lower or "2nd" in lower or "doosra" in lower:
            instance_idx = 1
        elif "teesri" in lower or "third" in lower or "3rd" in lower:
            instance_idx = 2

        if action == "close" and not app_cand and not (context and (context.last_window or context.last_application)):
            return Plan(is_direct_message=True, message_text="Which application or window would you like to close?")

        args = {"action": action}
        if instance_idx > 0:
            args["instance_index"] = instance_idx
        if app_cand:
            args["app_name"] = app_cand
        return Plan(steps=[PlanStep(step=1, tool="manage_window", args=args)])

    # -------------------------------------------------------------
    # 5. MOUSE AUTOMATION & SCROLLING INTENTS (Phase 4B & Phase 1)
    # -------------------------------------------------------------
    # Matches: "context menu se 'New' -> 'Text Document' select karo", "context menu se New Text Document select karo"
    if "context menu" in lower and any(w in lower for w in ["select", "new", "click", "chuno"]):
        parent = "New"
        sub = "Text Document"
        if "folder" in lower:
            sub = "Folder"
        return Plan(steps=[PlanStep(step=1, tool="navigate_context_menu", args={"parent_item": parent, "sub_item": sub})])

    # Matches: "specific element aane tak scroll karo", "target aane tak scroll karo", "scroll until visible"
    if "scroll" in lower and any(w in lower for w in ["aane tak", "until", "jab tak", "visible"]):
        t_target = "Comments" if "comment" in lower else ("result" if "result" in lower else "element")
        return Plan(steps=[PlanStep(step=1, tool="scroll_until_visible", args={"target_query": t_target})])

    # Matches: "mouse ka left button daba kar rakho", "left click hold karo", "mouse button release karo", "mouse button chhor do"
    if ("daba kar rakho" in lower or "press and hold" in lower or "hold karo" in lower or "hold" in lower) and ("mouse" in lower or "button" in lower or "click" in lower):
        btn = "right" if "right" in lower else ("middle" if "middle" in lower else "left")
        dur = 2.0
        dur_m = re.search(r'(\d+)\s*(?:seconds?|s|second)\b', lower)
        if dur_m:
            dur = float(dur_m.group(1))
        return Plan(steps=[PlanStep(step=1, tool="hold_mouse", args={"button": btn, "duration": dur})])

    if ("release" in lower or "chhor do" in lower or "chhod do" in lower) and ("mouse" in lower or "button" in lower or "click" in lower):
        btn = "right" if "right" in lower else ("middle" if "middle" in lower else "left")
        return Plan(steps=[PlanStep(step=1, tool="mouse_up", args={"button": btn})])

    # Matches: "window right border se expand karo", "window left border se resize karo", "drag border"
    if "window" in lower and ("border" in lower or "corner" in lower) and ("expand" in lower or "resize" in lower or "drag" in lower or "badi karo" in lower or "bari karo" in lower):
        edge = "right" if "right" in lower else ("left" if "left" in lower else ("bottom" if "bottom" in lower else "bottom_right"))
        dx = -100 if "left" in lower else 100
        dy = 100 if "bottom" in lower else 0
        return Plan(steps=[PlanStep(step=1, tool="drag_window_border", args={"edge": edge, "delta_x": dx, "delta_y": dy})])

    # Matches: "mouse ko center mein le jao aur 3 seconds hover karo", "center hover"
    if ("center" in lower or "darmiyan" in lower) and ("hover" in lower or "le jao" in lower):
        dur = 3.0
        dur_m = re.search(r'(\d+)\s*(?:seconds?|s|second)\b', lower)
        if dur_m:
            dur = float(dur_m.group(1))
        return Plan(steps=[PlanStep(step=1, tool="hover_mouse", args={"x": 683, "y": 384, "duration": dur})])

    # Matches mouse motion patterns (e.g. "top-left corner", "bottom-right corner", "clockwise", "anticlockwise", "left se right", "5 seconds", "10 seconds")
    if ("mouse" in lower or "cursor" in lower) and any(w in lower for w in ["move", "chalao", "ghuma", "circle", "corner", "left", "right", "upar", "neeche", "seconds", "second", "top", "bottom"]):
        dur = 1.0
        dur_m = re.search(r'(\d+)\s*(?:seconds?|s|second)\b', lower)
        if dur_m:
            dur = float(dur_m.group(1))

        if "top-left" in lower or "top left" in lower or ("top" in lower and "left" in lower and "corner" in lower):
            return Plan(steps=[PlanStep(step=1, tool="move_mouse_pattern", args={"pattern": "top_left", "duration": dur})])
        elif "top-right" in lower or "top right" in lower or ("top" in lower and "right" in lower and "corner" in lower):
            return Plan(steps=[PlanStep(step=1, tool="move_mouse_pattern", args={"pattern": "top_right", "duration": dur})])
        elif "bottom-left" in lower or "bottom left" in lower or ("bottom" in lower and "left" in lower and "corner" in lower):
            return Plan(steps=[PlanStep(step=1, tool="move_mouse_pattern", args={"pattern": "bottom_left", "duration": dur})])
        elif "bottom-right" in lower or "bottom right" in lower or ("bottom" in lower and "right" in lower and "corner" in lower):
            return Plan(steps=[PlanStep(step=1, tool="move_mouse_pattern", args={"pattern": "bottom_right", "duration": dur})])
        elif "anticlockwise" in lower or "counterclockwise" in lower or "anti-clockwise" in lower or "anti clockwise" in lower:
            return Plan(steps=[PlanStep(step=1, tool="move_mouse_pattern", args={"pattern": "anticlockwise", "duration": max(2.0, dur)})])
        elif "clockwise" in lower:
            return Plan(steps=[PlanStep(step=1, tool="move_mouse_pattern", args={"pattern": "clockwise", "duration": max(2.0, dur)})])
        elif "circle" in lower or "circular" in lower or "gol" in lower:
            return Plan(steps=[PlanStep(step=1, tool="move_mouse_pattern", args={"pattern": "circle", "duration": max(2.0, dur)})])
        elif ("left" in lower and "right" in lower and "upar" in lower and "neeche" in lower) or "left se right phir upar se neeche" in lower:
            return Plan(steps=[PlanStep(step=1, tool="move_mouse_pattern", args={"pattern": "left_right_then_top_bottom", "duration": 1.5})])
        elif "left se right" in lower or "left to right" in lower:
            return Plan(steps=[PlanStep(step=1, tool="move_mouse_pattern", args={"pattern": "left_to_right", "duration": dur})])
        elif "right se left" in lower or "right to left" in lower:
            return Plan(steps=[PlanStep(step=1, tool="move_mouse_pattern", args={"pattern": "right_to_left", "duration": dur})])
        elif "upar se neeche" in lower or "top to bottom" in lower:
            return Plan(steps=[PlanStep(step=1, tool="move_mouse_pattern", args={"pattern": "top_to_bottom", "duration": dur})])
        elif "neeche se upar" in lower or "bottom to top" in lower:
            return Plan(steps=[PlanStep(step=1, tool="move_mouse_pattern", args={"pattern": "bottom_to_top", "duration": dur})])
        elif "right" in lower:
            return Plan(steps=[PlanStep(step=1, tool="move_mouse_pattern", args={"pattern": "left_to_right", "duration": dur})])
        elif "left" in lower:
            return Plan(steps=[PlanStep(step=1, tool="move_mouse_pattern", args={"pattern": "right_to_left", "duration": dur})])
        elif "upar" in lower or "up" in lower:
            return Plan(steps=[PlanStep(step=1, tool="move_mouse_pattern", args={"pattern": "bottom_to_top", "duration": dur})])
        elif "neeche" in lower or "down" in lower:
            return Plan(steps=[PlanStep(step=1, tool="move_mouse_pattern", args={"pattern": "top_to_bottom", "duration": dur})])
        elif "move karte raho" in lower or "lagatar" in lower or dur >= 3.0:
            return Plan(steps=[PlanStep(step=1, tool="move_mouse_pattern", args={"pattern": "continuous", "duration": dur})])

    # Matches: "desktop par kisi empty area par right click karo", "empty area par right click"
    if "right click" in lower and ("empty" in lower or "khali" in lower or "desktop" in lower) and not ("file" in lower or "folder" in lower or "icon" in lower):
        return Plan(steps=[PlanStep(step=1, tool="click_mouse", args={"x": 500, "y": 500, "button": "right"})])

    # Matches ranked element clicks: "first result", "pehli video", "second search result click karo", "second video click karo", "third link par click karo"
    if any(r in lower for r in ["first", "pehla", "pehli", "1st", "second", "doosra", "doosri", "2nd", "third", "teesra", "teesri", "3rd"]) and any(w in lower for w in ["result", "video", "link", "card", "item", "search"]):
        if any(r in lower for r in ["first", "pehla", "pehli", "1st"]):
            rank_val = 1
        elif any(r in lower for r in ["second", "doosra", "doosri", "2nd"]):
            rank_val = 2
        else:
            rank_val = 3
        if "video" in lower:
            t_query = f"video_result_{rank_val}"
        elif "link" in lower:
            t_query = f"link_item_{rank_val}"
        else:
            t_query = f"result_item_{rank_val}"
        steps = [PlanStep(step=1, tool="find_and_interact", args={"target_query": t_query, "query": t_query, "action": "click", "rank": rank_val})]
        refocus_app = getattr(context, "last_target_app", None) if context else None
        if not refocus_app and context:
            refocus_app = getattr(context, "last_application", None)
            if hasattr(refocus_app, "value"):
                refocus_app = refocus_app.value
        if refocus_app:
            steps.insert(0, PlanStep(step=1, tool="focus_app", args={"name": refocus_app}))
            for i, s in enumerate(steps, 1):
                s.step = i
        return Plan(steps=steps)

    # Matches: "double click karo", "double click", "right click karo", "right click", "middle button click", "click karo", "yahan click karo", "left click karo"
    if "click" in lower and not ("click mat" in lower or "mat click" in lower or "don't click" in lower or "do not click" in lower or "double click file" in lower or "link" in lower or ("button" in lower and ("minimize" in lower or "close" in lower))):
        is_double = "double" in lower or "do baar" in lower or "2 baar" in lower
        is_middle = "middle" in lower or "beech" in lower
        is_right = "right" in lower or "dayen" in lower
        clicks_cnt = 2 if is_double else 1
        btn = "middle" if is_middle else ("right" if is_right else "left")

        # Coordinate click detection (e.g. "click at 500 500", "500 500 par click", "mouse click at 100 200")
        coord_click_m = (
            re.search(r'\b(?:mouse\s+)?click\s+(?:at\s+|on\s+)?\(?(\d+)[\s,]+(\d+)\)?', lower)
            or re.search(r'\(?(\d+)[\s,]+(\d+)\)?\s*(?:par)?\s*(?:mouse\s+)?click', lower)
        )
        if coord_click_m:
            cx = int(coord_click_m.group(1))
            cy = int(coord_click_m.group(2))
            return Plan(steps=[PlanStep(step=1, tool="mouse_click", args={"x": cx, "y": cy, "button": btn, "clicks": clicks_cnt})])

        return Plan(steps=[PlanStep(step=1, tool="click_mouse", args={"button": btn, "clicks": clicks_cnt})])

    # Matches: "file ko desktop par drag karo", "file ko folder ke andar drag karo", "drag karo from 100 200 to 500 500"
    if "drag" in lower and not ("dragon" in lower):
        if "file" in lower and "folder" in lower:
            return Plan(steps=[PlanStep(step=1, tool="drag_element_to_element", args={"source_query": "file", "target_query": "folder"})])
        elif "file" in lower and "desktop" in lower:
            return Plan(steps=[PlanStep(step=1, tool="drag_element_to_element", args={"source_query": "file", "target_query": "desktop"})])
        coord_drag = re.search(r'\(?(\d+)[\s,]+(\d+)\)?\s*(?:to|se|par)?\s*\(?(\d+)[\s,]+(\d+)\)?', lower)
        if coord_drag:
            return Plan(steps=[PlanStep(step=1, tool="drag_mouse", args={"from_x": int(coord_drag.group(1)), "from_y": int(coord_drag.group(2)), "to_x": int(coord_drag.group(3)), "to_y": int(coord_drag.group(4))})])
        return Plan(steps=[PlanStep(step=1, tool="drag_mouse", args={"to_x": 600, "to_y": 600})])

    # Matches: "ye text select karo", "mouse se is text ko select karo", "search bar ka sara text select karo", "paragraph select karo"
    if "select" in lower and ("text" in lower or "paragraph" in lower or "sara" in lower or "all" in lower) and not ("profile" in lower or "file" in lower or "folder" in lower or "app" in lower):
        if "all" in lower or "sara" in lower or "pura" in lower or "ctrl+a" in lower or "ctrl a" in lower:
            return Plan(steps=[PlanStep(step=1, tool="press_hotkey", args={"keys": "ctrl+a"})])
        return Plan(steps=[PlanStep(step=1, tool="select_text_range", args={"from_x": 200, "from_y": 300, "to_x": 500, "to_y": 300})])

    # Matches: "dropdown open karo aur Option 2 select karo", "checkbox click karo 'Agree'", "radio button select karo 'Option A'"
    if any(k in lower for k in ["dropdown", "checkbox", "radio button", "radio"]):
        ctrl_type = "dropdown" if "dropdown" in lower else ("checkbox" if "checkbox" in lower else "radio")
        opt_m = re.search(r'(?:select|chose|choose)\s+["\']?([^"\']+)["\']?', text, re.IGNORECASE)
        opt = opt_m.group(1).strip() if opt_m else None
        target_el = "dropdown" if ctrl_type == "dropdown" else ("checkbox" if ctrl_type == "checkbox" else "radio button")
        return Plan(steps=[PlanStep(step=1, tool="interact_form_element", args={"element_query": target_el, "control_type": ctrl_type, "option_to_select": opt})])

    # Matches: "Shift daba kar pehli se teesri file select karo", "select file range from 'file 1' to 'file 3'"
    if "shift" in lower and ("select" in lower or "choose" in lower) and any(w in lower for w in ["se", "from", "to", "tak"]):
        start_m = re.search(r'(?:kar\s+|from\s+)(pehli\s+file|first\s+file|[a-zA-Z0-9_\.\-]+)', lower)
        end_m = re.search(r'(?:se\s+|to\s+)(teesri\s+file|third\s+file|doosri\s+file|second\s+file|[a-zA-Z0-9_\.\-]+)', lower)
        start_q = start_m.group(1).strip() if start_m else "pehli file"
        end_q = end_m.group(1).strip() if end_m else "teesri file"
        return Plan(steps=[PlanStep(step=1, tool="select_file_range", args={"start_query": start_q, "end_query": end_q})])

    # Matches: "hover karo", "mouse hover karo", "is button par hover karo"
    if "hover" in lower:
        coord_h = re.search(r'\(?(\d+)[\s,]+(\d+)\)?', lower)
        if coord_h:
            return Plan(steps=[PlanStep(step=1, tool="hover_mouse", args={"x": int(coord_h.group(1)), "y": int(coord_h.group(2))})])
        return Plan(steps=[PlanStep(step=1, tool="hover_mouse", args={"x": 500, "y": 300})])

    # Matches: "cursor position batao", "mouse kahan hai", "where is mouse", "cursor coordinates", "mouse pointer kahan pe hai abhi?"
    if (
        "cursor position" in lower or "mouse kahan hai" in lower or "where is mouse" in lower or "cursor coordinates" in lower
        or (("mouse" in lower or "cursor" in lower or "pointer" in lower) and any(w in lower for w in ["kahan hai", "kahan pe hai", "kahan", "located", "position", "coordinates", "where", "placed"]))
    ):
        return Plan(steps=[PlanStep(step=1, tool="get_cursor_position", args={})])

    # Matches: "window chhoti karo", "window bari karo", "window resize karo", "resize window"
    if "resize" in lower or "window chhoti" in lower or "window bari" in lower or "window choti" in lower:
        w = 640 if ("chhoti" in lower or "choti" in lower or "small" in lower) else 1024
        h = 480 if ("chhoti" in lower or "choti" in lower or "small" in lower) else 768
        return Plan(steps=[PlanStep(step=1, tool="resize_window", args={"width": w, "height": h})])


    return None
