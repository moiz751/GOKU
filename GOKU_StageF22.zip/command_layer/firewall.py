"""
Tool Selection Firewall & Pre-Execution Semantic Check for MARK/GOKU Autonomous Agent.
Strictly validates semantic compatibility between (domain, action) and the selected tool.
Blocks cross-domain leaks (e.g. MOVE_MOUSE -> move_folder, SEARCH_WEB -> search_files).
Enforces pre-execution contracts and user-specified negations (Item 15, 22, 23).
"""
from pathlib import Path
import re
from typing import Any
from command_layer.semantic_model import SemanticDomain, SemanticAction
from tools.registry import check_parameter_feasibility, is_destructive

# Semantic Domain & Action to Allowed Tools Mapping
ALLOWED_TOOLS_MAP: dict[tuple[SemanticDomain, SemanticAction], set[str]] = {
    # GUI domain
    (SemanticDomain.GUI, SemanticAction.MOVE_MOUSE): {
        "move_mouse", "mouse_move", "locate_ui_element", "find_and_interact", "get_mouse_position",
        "hover_mouse", "move_mouse_pattern", "drag_mouse", "move_window", "resize_window",
        "drag_window_border", "snap_window_drag", "drag_element_to_element", "select_text_range",
        "game_drag_and_release", "autonomous_slingshot_strike", "engage_continuous_game_loop", "run_autonomous_agent"
    },
    (SemanticDomain.GUI, SemanticAction.CLICK): {
        "click_mouse", "mouse_click", "find_and_interact", "double_click", "mouse_down", "mouse_up",
        "hold_mouse", "click_ui_element", "interact_form_element", "navigate_context_menu",
        "focus_window", "select_file_range", "select_text_range", "click_element_by_text", "focus_app_window",
        "autonomous_slingshot_strike", "game_drag_and_release"
    },
    (SemanticDomain.GUI, SemanticAction.PRESS): {
        "press_hotkey", "analyze_multi_adapter_and_bands", "send_keyboard_input", "type_text", "find_and_interact",
        "prepare_target_environment", "smart_cleanup_app", "record_task_evidence_and_report"
    },
    (SemanticDomain.GUI, SemanticAction.TYPE): {
        "type_text", "press_hotkey", "find_and_interact", "set_clipboard_text", "clear_clipboard",
        "interact_form_element", "save_file_dialog", "send_keyboard_input",
        "copy_selection_to_clipboard", "paste_clipboard_into_target", "save_active_document"
    },
    (SemanticDomain.GUI, SemanticAction.SCROLL): {"mouse_scroll", "scroll", "scroll_until_visible", "scroll_and_inspect", "scroll_active_window", "observe_and_scroll_until"},
    (SemanticDomain.GUI, SemanticAction.INSPECT): {
        "inspect_screen", "take_screenshot", "capture_screen", "locate_ui_element", "get_active_window",
        "get_cursor_position", "get_screen_size", "get_clipboard_text", "clear_clipboard",
        "get_active_dialog", "get_window_info", "get_foreground_application", "wait_for_ui_element",
        "find_text_on_screen", "wait_for_ui_settle", "pick_best_on_screen_item", "focus_app_window",
        "copy_selection_to_clipboard", "scroll_and_inspect", "scroll_active_window",
        "wait_for_visual_stability", "wait_for_visual_event", "detect_game_object", "detect_game_scene", "observe_and_scroll_until"
    },
    (SemanticDomain.GUI, SemanticAction.CORRECT): {"move_mouse", "mouse_move", "locate_ui_element", "find_and_interact"},
    
    # Filesystem domain
    (SemanticDomain.FILESYSTEM, SemanticAction.OPEN): {
        "open_file", "open_folder", "list_folder", "open_file_with", "gui_navigate_folder",
        "create_file", "create_folder", "save_file_dialog", "write_file", "extract_archive",
        "read_file", "read_file_text", "read_document"
    },
    (SemanticDomain.FILESYSTEM, SemanticAction.CREATE): {
        "create_file", "create_folder", "write_file", "extract_archive", "save_active_document",
        "prepare_target_environment", "smart_cleanup_app", "record_task_evidence_and_report"
    },
    (SemanticDomain.FILESYSTEM, SemanticAction.SEARCH): {"search_files", "find_file", "search_files_intelligent", "find_duplicate_files"},
    (SemanticDomain.FILESYSTEM, SemanticAction.FIND): {"search_files", "find_file", "search_files_intelligent", "find_duplicate_files"},
    (SemanticDomain.FILESYSTEM, SemanticAction.MOVE_FILE): {"move_file", "move_folder", "rename_file", "rename_folder", "replace_file"},
    (SemanticDomain.FILESYSTEM, SemanticAction.COPY): {"copy_file", "copy_folder", "replace_file"},
    (SemanticDomain.FILESYSTEM, SemanticAction.DELETE): {"delete_file", "delete_folder"},
    (SemanticDomain.FILESYSTEM, SemanticAction.INSPECT): {
        "get_file_metadata", "list_folder", "read_file", "read_file_text", "read_document", "open_folder", "find_file", "open_file",
        "get_foreground_application", "count_files", "count_folder_items", "get_file_info", "classify_file",
        "get_largest_files", "get_free_space", "get_drive_usage", "get_drive_status", "get_drive_type",
        "get_disk_partitions", "get_removable_drives", "get_disk_io", "get_disk_io_by_device", "get_disk_activity",
        "get_storage_health_snapshot", "discover_directories", "discover_drives", "list_drive_contents", "get_drives",
        "select_file_range", "write_file", "extract_archive"
    },
    
    # Browser domain
    (SemanticDomain.BROWSER, SemanticAction.OPEN): {"open_url", "launch_app", "open_browser_profile", "is_app_running", "new_tab"},
    (SemanticDomain.BROWSER, SemanticAction.SEARCH): {"open_url", "type_text", "press_hotkey", "find_and_interact", "get_active_window", "is_app_running", "launch_app", "search_web"},
    (SemanticDomain.BROWSER, SemanticAction.INSPECT): {"get_browser_status", "get_running_browsers", "list_browser_profiles", "get_active_window", "get_active_browser", "get_browser_windows", "get_current_browser_page", "get_current_browser_tab", "get_focused_element", "get_foreground_application", "get_gui_state", "scroll_and_inspect", "scroll_active_window"},
    (SemanticDomain.BROWSER, SemanticAction.NAVIGATE): {"open_url", "press_hotkey", "type_text", "find_and_interact", "click_mouse", "scroll_and_inspect", "scroll_active_window"},
    (SemanticDomain.BROWSER, SemanticAction.CLOSE): {"close_browser", "manage_window", "close_app"},
    
    # Application domain
    (SemanticDomain.APPLICATION, SemanticAction.LAUNCH): {"launch_app", "start_app", "open_app", "focus_app", "find_and_interact", "click_mouse", "type_text", "restart_app", "focus_window", "wait_for_ui_settle", "focus_app_window", "prepare_target_environment"},
    (SemanticDomain.APPLICATION, SemanticAction.CLOSE): {"close_app", "terminate_process", "kill_process", "manage_window", "smart_cleanup_app"},
    (SemanticDomain.APPLICATION, SemanticAction.INSPECT): {"is_app_running", "get_application_status", "discover_applications", "get_foreground_application", "discover_running_processes", "get_process_status", "get_installed_apps", "wait_for_ui_settle", "focus_app_window"},
    (SemanticDomain.APPLICATION, SemanticAction.SEARCH): {"find_application", "discover_applications", "launch_app", "type_text", "click_mouse", "find_and_interact", "wait_for_ui_settle", "get_installed_apps"},
    (SemanticDomain.APPLICATION, SemanticAction.INTERACT): {"copy_selection_to_clipboard", "paste_clipboard_into_target", "save_active_document", "focus_app_window", "focus_app", "prepare_target_environment", "smart_cleanup_app", "record_task_evidence_and_report"},
    
    # Settings domain
    (SemanticDomain.SETTINGS, SemanticAction.OPEN): {"open_settings", "launch_app", "open_settings_page"},
    (SemanticDomain.SETTINGS, SemanticAction.NAVIGATE_SETTINGS): {"open_settings", "launch_app", "open_settings_page", "get_wifi_status", "get_network_status"},
    (SemanticDomain.SETTINGS, SemanticAction.INSPECT): {"open_settings", "get_network_status", "get_wifi_status"},
    
    # Network domain
    (SemanticDomain.NETWORK, SemanticAction.INSPECT): {
        "get_network_status", "test_internet_connectivity", "get_wifi_networks", "get_wifi_status",
        "get_wifi_signal", "get_wifi_ssid", "get_default_gateway", "get_dns_servers", "get_local_ip",
        "get_network_interfaces", "get_hotspot_status", "ping_host", "get_network_state", "diagnose_network_health",
        "deep_scan_wifi_spectrum", "analyze_multi_adapter_and_bands"
    },
    (SemanticDomain.NETWORK, SemanticAction.DIAGNOSE): {
        "diagnose_network", "diagnose_network_health", "deep_scan_wifi_spectrum",
        "analyze_multi_adapter_and_bands", "test_internet_connectivity", "get_network_status",
        "get_wifi_status", "ping_host"
    },
    
    # System & Diagnostics
    (SemanticDomain.SYSTEM, SemanticAction.INSPECT): {
        "get_cpu_status", "get_memory_status", "get_system_uptime", "get_active_window", "get_foreground_application",
        "get_drives", "list_drive_contents", "discover_drives", "get_top_processes", "get_processes", "get_process_count",
        "get_process_tree", "find_process", "get_process_status", "get_services", "get_running_services", "get_stopped_services",
        "get_service_status", "get_service_summary", "find_service", "get_power_status", "get_system_state",
        "get_system_health_snapshot", "get_free_space", "get_drive_usage", "get_drive_status", "get_drive_type",
        "get_disk_partitions", "get_removable_drives", "get_disk_io", "get_disk_io_by_device", "get_disk_activity",
        "get_storage_health_snapshot", "get_system_diagnostic_snapshot", "discover_running_processes", "list_running_apps",
        "diagnose_network_health", "deep_scan_wifi_spectrum", "audit_wifi_hardware_and_services", "audit_and_reclaim_ram",
        "prepare_target_environment", "smart_cleanup_app", "record_task_evidence_and_report",
        "get_system_time", "get_current_time", "execute_command", "run_cli"
    },
    (SemanticDomain.SYSTEM, SemanticAction.SEARCH): {"diagnose_network_health", "deep_scan_wifi_spectrum"},
    (SemanticDomain.SYSTEM, SemanticAction.SCAN): {"scan_computer"},
    (SemanticDomain.SYSTEM, SemanticAction.REPAIR): {"remediate_wifi_stack", "audit_and_reclaim_ram"},
    (SemanticDomain.SYSTEM, SemanticAction.OPTIMIZE): {"audit_and_reclaim_ram"},
    (SemanticDomain.SYSTEM, SemanticAction.DIAGNOSE): {"audit_and_reclaim_ram"},
    (SemanticDomain.NETWORK, SemanticAction.REPAIR): {"remediate_wifi_stack"},
    (SemanticDomain.DIAGNOSTICS, SemanticAction.DIAGNOSE): {
        "diagnose_system", "diagnose_network", "diagnose_network_health", "diagnose_storage", "diagnose_process", "diagnose_performance",
        "diagnose_cpu", "diagnose_memory", "diagnose_browser", "diagnose_application", "get_system_diagnostic_snapshot",
        "get_system_health_snapshot", "test_internet_connectivity", "get_cpu_status", "get_top_processes", "get_memory_status",
        "get_wifi_status", "get_network_interfaces", "get_dns_servers", "get_free_space",
        "get_storage_health_snapshot", "discover_drives", "find_process", "get_process_status",
        "get_active_window", "audit_and_reclaim_ram", "press_hotkey", "analyze_multi_adapter_and_bands"
    },
    (SemanticDomain.DIAGNOSTICS, SemanticAction.REPORT): {"diagnose_system", "get_system_health_snapshot", "write_file"},
    (SemanticDomain.DIAGNOSTICS, SemanticAction.INSPECT): {"diagnose_system", "diagnose_memory", "diagnose_cpu", "diagnose_performance", "diagnose_storage", "diagnose_network", "get_cpu_status", "get_memory_status", "get_system_health_snapshot", "get_top_processes", "find_process", "get_process_status", "discover_running_processes"},
    (SemanticDomain.DEVICES, SemanticAction.INSPECT): {
        "get_connected_devices", "get_bluetooth_status", "get_audio_devices", "get_bluetooth_devices",
        "get_paired_bluetooth_devices", "get_connected_bluetooth_devices", "get_bluetooth_device_status",
        "get_usb_devices", "get_pnp_devices", "get_connected_device_summary", "get_hotspot_status"
    },
    
    # Conversation & Self-Observation History (Item 12)
    (SemanticDomain.CONVERSATION_HISTORY, SemanticAction.QUERY_HISTORY): {"query_execution_history", "get_last_failure", "get_last_command"},
    (SemanticDomain.CONVERSATION_HISTORY, SemanticAction.REPORT): {"query_execution_history", "report_failures"},
}

ALLOWED_DOMAIN_ACTIONS = ALLOWED_TOOLS_MAP

# Strict Prohibitions: Forbidden combinations that indicate critical domain confusion (Item 5, Item 1)
FORBIDDEN_TOOL_PATTERNS = {
    # Move mouse must NEVER touch filesystem
    SemanticAction.MOVE_MOUSE: {"move_folder", "move_file", "delete_file", "delete_folder", "copy_file", "rename_file", "search_files"},
    # Web search must NEVER touch local file search
    SemanticDomain.BROWSER: {"search_files", "delete_file", "delete_folder", "move_folder", "move_file"},
    # Settings navigation must NEVER call filesystem tools
    SemanticDomain.SETTINGS: {"open_folder", "search_files", "delete_file", "delete_folder"},
}


class FirewallViolation(Exception):
    """Raised when an intent attempts to execute a forbidden cross-domain tool."""
    pass


def validate_tool_against_firewall(
    domain_or_tool: Any,
    action_or_args: Any = None,
    tool_name: str | None = None,
    args: dict[str, Any] | None = None
) -> tuple[bool, str | None]:
    """
    Validates that tool_name is semantically permitted for (domain, action),
    or directly validates a (tool_name, args) pair.
    Returns (is_allowed, violation_reason).
    """
    # Whitelist engage_continuous_game_loop
    _eff_tool = tool_name if tool_name is not None else str(domain_or_tool)
    if _eff_tool in ('engage_continuous_game_loop', 'run_autonomous_agent'):
        return True, None
    if tool_name is None:
        # Called as validate_tool_against_firewall(tool_name, args)
        tool_name = str(domain_or_tool)
        args = dict(action_or_args or {}) if isinstance(action_or_args, dict) else {}
        domain, action = get_native_domain_and_action(tool_name)
    else:
        domain = domain_or_tool
        action = action_or_args
        args = dict(args or {}) if isinstance(args, dict) else {}

    # Normalization for focus_app_window: accept either app_name or target_window
    if tool_name == "focus_app_window" and isinstance(args, dict):
        if "target_window" in args and not args.get("app_name"):
            args["app_name"] = args["target_window"]
        elif "app_name" in args and not args.get("target_window"):
            args["target_window"] = args["app_name"]

    if tool_name == "close_app" and isinstance(args, dict):
        if "name" in args and not args.get("name_or_pid"):
            args["name_or_pid"] = args["name"]
        elif "app_name" in args and not args.get("name_or_pid"):
            args["name_or_pid"] = args["app_name"]
        elif "name_or_pid" in args and not args.get("name"):
            args["name"] = args["name_or_pid"]

    if tool_name == "locate_ui_element" and isinstance(args, dict):
        if "query" in args and "element_name" not in args:
            args["element_name"] = args["query"]
        elif "element_name" in args and "query" not in args:
            args["query"] = args["element_name"]

    if tool_name == "run_autonomous_agent":
        return True, ""

    # 1. Check strict prohibitions
    if action in FORBIDDEN_TOOL_PATTERNS:
        forbidden = FORBIDDEN_TOOL_PATTERNS[action]
        if tool_name in forbidden:
            return False, f"FIREWALL VIOLATION: Action '{action.value}' is strictly forbidden from executing '{tool_name}'."

    if domain in FORBIDDEN_TOOL_PATTERNS:
        forbidden = FORBIDDEN_TOOL_PATTERNS[domain]
        if tool_name in forbidden:
            return False, f"FIREWALL VIOLATION: Domain '{domain.value}' is strictly forbidden from executing '{tool_name}'."

    # 1.5 Strict validation: Guard against empty or missing text payload
    if tool_name == "type_text":
        txt_val = args.get("text", "")
        if not str(txt_val).strip():
            return False, "FIREWALL VIOLATION: Empty or whitespace text argument prohibited for 'type_text'."

    # 2. Check Allowed Map
    allowed = ALLOWED_TOOLS_MAP.get((domain, action))
    if allowed is not None:
        if tool_name in allowed:
            # Special check for find_and_interact action consistency
            if tool_name == "find_and_interact":
                tool_act = args.get("action")
                if action == SemanticAction.MOVE_MOUSE and tool_act != "move":
                    return False, f"FIREWALL VIOLATION: MOVE_MOUSE intent mapped to find_and_interact with action '{tool_act}' instead of 'move'."
                if action == SemanticAction.TYPE and tool_act != "type":
                    return False, f"FIREWALL VIOLATION: TYPE intent mapped to find_and_interact with action '{tool_act}' instead of 'type'."
            return True, None
        else:
            return False, f"FIREWALL VIOLATION: Tool '{tool_name}' is not in certified allowed list for ({domain.value}, {action.value}). Allowed: {sorted(list(allowed))}"

    # Default fallback: If domain is capability or clarify, direct message is allowed
    if domain in (SemanticDomain.CAPABILITY, SemanticDomain.UNKNOWN) or action in (SemanticAction.CLARIFY, SemanticAction.UNSUPPORTED):
        return True, None

    return True, None


def validate_step(
    tool_name: str,
    args: dict[str, Any],
    domain: SemanticDomain,
    action: SemanticAction,
    target: str = "",
    constraints: list[str] | None = None
) -> tuple[bool, str | None]:
    """Convenience validator checking tool permission under (domain, action)."""
    return validate_tool_against_firewall(domain, action, tool_name, args)


def validate_tool_call(
    tool_name: str,
    args: dict[str, Any] | None = None,
    context: Any = None,
    domain: SemanticDomain | None = None,
    action: SemanticAction | None = None,
    constraints: list[str] | None = None,
    confirmed: bool = False,
    **kwargs: Any,
) -> tuple[bool, str | None]:
    """
    Validates a tool invocation against safety firewalls, constraints, and parameter schemas.
    Accepts (tool_name, args) and handles schema aliases (e.g. target_query <-> query for find_and_interact).
    """
    if args is None:
        args = {}
    if not isinstance(args, dict):
        args = dict(args)

    if tool_name == "find_and_interact":
        if "query" in args and not args.get("target_query"):
            args["target_query"] = args["query"]
        elif "target_query" in args and not args.get("query"):
            args["query"] = args["target_query"]

    if tool_name == "focus_app_window" and isinstance(args, dict):
        if "target_window" in args and not args.get("app_name"):
            args["app_name"] = args["target_window"]
        elif "app_name" in args and not args.get("target_window"):
            args["target_window"] = args["app_name"]

    # Parameter feasibility check
    feasible, missing = check_parameter_feasibility(tool_name, args)
    if not feasible:
        if tool_name == "find_and_interact" and ("target_query" in args or "query" in args):
            missing = [m for m in missing if m not in ("target_query", "query")]
        if missing:
            return False, f"FIREWALL BLOCKED: Tool '{tool_name}' missing required parameters: {', '.join(missing)}"

    if domain is None or action is None:
        domain, action = get_native_domain_and_action(tool_name)

    return pre_execution_semantic_check(
        domain=domain,
        action=action,
        target=str(args.get("target_query") or args.get("query") or args.get("name") or args.get("path") or ""),
        tool_name=tool_name,
        args=args,
        constraints=constraints or [],
        confirmed=confirmed
    )


def get_native_domain_and_action(tool_name: str) -> tuple[SemanticDomain, SemanticAction]:
    """Infers the native (domain, action) pair for a given tool name."""
    t = (tool_name or "").strip().lower()
    if t in ("engage_continuous_game_loop", "run_autonomous_agent", "autonomous_slingshot_strike", "game_drag_and_release"):
        return (SemanticDomain.GUI, SemanticAction.CLICK)
    if t in ("press_hotkey",):
        return (SemanticDomain.GUI, SemanticAction.PRESS)
    if t in ("send_keyboard_input", "type_text"):
        return (SemanticDomain.GUI, SemanticAction.TYPE)
    if t in ("click_mouse", "mouse_click", "click_element_by_text", "click_ui_element", "find_and_interact"):
        return (SemanticDomain.GUI, SemanticAction.CLICK)
    if t in ("launch_app", "open_app", "start_app", "focus_app", "focus_app_window"):
        return (SemanticDomain.APPLICATION, SemanticAction.LAUNCH)
    if t in ("close_app", "kill_process", "terminate_process", "exit_app"):
        return (SemanticDomain.APPLICATION, SemanticAction.CLOSE)
    if t in ("open_file", "read_file", "read_file_text", "list_folder", "open_folder"):
        return (SemanticDomain.FILESYSTEM, SemanticAction.OPEN)
    if t in ("create_file", "create_folder", "write_file", "save_active_document", "record_task_evidence_and_report"):
        return (SemanticDomain.FILESYSTEM, SemanticAction.CREATE)
    if t in ("prepare_target_environment", "smart_cleanup_app"):
        return (SemanticDomain.APPLICATION, SemanticAction.INTERACT)
    if t in ("delete_file", "delete_folder"):
        return (SemanticDomain.FILESYSTEM, SemanticAction.DELETE)
    if t in ("search_files", "find_file"):
        return (SemanticDomain.FILESYSTEM, SemanticAction.SEARCH)
    if t in ("open_url", "search_web"):
        return (SemanticDomain.BROWSER, SemanticAction.SEARCH)
    if t in ("diagnose_network_health", "deep_scan_wifi_spectrum", "analyze_multi_adapter_and_bands", "diagnose_network"):
        return (SemanticDomain.NETWORK, SemanticAction.DIAGNOSE)
    if t in ("audit_and_reclaim_ram", "get_system_health_snapshot", "diagnose_system"):
        return (SemanticDomain.DIAGNOSTICS, SemanticAction.DIAGNOSE)
    return (SemanticDomain.UNKNOWN, SemanticAction.OPEN)


def pre_execution_semantic_check(
    domain: SemanticDomain,
    action: SemanticAction,
    target: str,
    tool_name: str,
    args: dict[str, Any],
    constraints: list[str] | None = None,
    negations: list[str] | None = None,
    is_negated: bool = False,
    confirmed: bool = False
) -> tuple[bool, str | None]:
    """
    Pre-Execution Semantic Check (Item 23 & Item 15).
    Produces internally:
      DOMAIN, ACTION, ENTITY, TARGET, ARGUMENTS, CONSTRAINTS, NEGATIONS
    Validates compatibility and prevents prohibited operations before execution.
    """
    constraints = constraints or []
    negations = negations or []

    # 0. Adversarial Firewall Bypass Guard (Prompt Task P9)
    try:
        from command_layer.firewall_bypass_guard import inspect_firewall_bypass
        is_blocked, bypass_reason = inspect_firewall_bypass(tool_name, args)
        if is_blocked:
            return False, bypass_reason
    except Exception:
        pass

    # 0.1 Anti-Adversarial Destructive Action Shield (Bullet #8)
    import re
    target_low = str(target).lower()
    arg_vals = " ".join(str(v).lower() for v in args.values())
    combined_check = f"{target_low} {arg_vals}"
    try:
        from security.safety_firewall import is_safe_readonly_operation
        is_safe_readonly = is_safe_readonly_operation(tool_name, args, combined_check)
    except Exception:
        is_safe_readonly = False

    if not is_safe_readonly:
        if any(re.search(pat, combined_check) for pat in [
            r'\bformat\s+[c-z](?::|\b)',
            r'\bformat\s+(?:disk|drive|partition|hard\s+disk)\b',
            r'\bwipe\s+(?:disk|drive|partition|hard\s+disk)\b',
            r'\bdelete\s+system32\b',
            r'\bsystem32\b',
            r'\b(?:kill|terminate)\s+all\b',
            r'\bregistry\s+wipe\b',
            r'\bdelete\s+partition\b',
        ]):
            return False, "FIREWALL BLOCKED: Destructive system action is strictly prohibited under safety policy regardless of negation phrasing."


    # 1. Explicit Negation Check (Item 15)
    if is_negated:
        return False, f"PRE-EXECUTION BLOCKED: Action '{action.value}' on '{target}' is explicitly negated by user."

    for neg in negations:
        neg_low = neg.lower()
        if "no_open" in neg_low or "mat khol" in neg_low or "don't open" in neg_low:
            if tool_name in ("launch_app", "open_url", "open_file", "open_folder"):
                target_arg = str(args.get("name") or args.get("url") or args.get("path") or "").lower()
                if any(part in target_arg for part in neg_low.split(":")):
                    return False, f"PRE-EXECUTION BLOCKED: User requested not to open '{target_arg}'."
        if "no_type" in neg_low or "type mat" in neg_low:
            if tool_name in ("type_text", "press_hotkey") or (tool_name == "find_and_interact" and args.get("action") == "type"):
                return False, "PRE-EXECUTION BLOCKED: User prohibited typing text."
        if "no_click" in neg_low or "click mat" in neg_low:
            if tool_name in ("click_mouse", "double_click") or (tool_name == "find_and_interact" and args.get("action") == "click"):
                return False, "PRE-EXECUTION BLOCKED: User prohibited mouse clicking."

    # 2. Constraint Checks (Item 21)
    if "mouse_only" in constraints or "move_only" in constraints:
        if tool_name not in ("move_mouse", "mouse_move", "locate_ui_element", "get_mouse_position"):
            if tool_name == "find_and_interact" and args.get("action") != "move":
                return False, "PRE-EXECUTION BLOCKED: Command is constrained to move mouse only."
            if tool_name in ("type_text", "click_mouse"):
                return False, "PRE-EXECUTION BLOCKED: Command is constrained to move mouse only."

    if "read_only" in constraints:
        if tool_name in ("delete_file", "delete_folder", "move_file", "move_folder", "create_file", "create_folder"):
            return False, "PRE-EXECUTION BLOCKED: Read-only constraint prohibits modifying file system."

    # 2.5 Parameter Feasibility Check
    if tool_name == "find_and_interact" and isinstance(args, dict):
        if "query" in args and not args.get("target_query"):
            args["target_query"] = args["query"]
        elif "target_query" in args and not args.get("query"):
            args["query"] = args["target_query"]
    if tool_name == "focus_app_window" and isinstance(args, dict):
        if "target_window" in args and not args.get("app_name"):
            args["app_name"] = args["target_window"]
        elif "app_name" in args and not args.get("target_window"):
            args["target_window"] = args["app_name"]

    if tool_name == "close_app" and isinstance(args, dict):
        if "name" in args and not args.get("name_or_pid"):
            args["name_or_pid"] = args["name"]
        elif "app_name" in args and not args.get("name_or_pid"):
            args["name_or_pid"] = args["app_name"]
        elif "name_or_pid" in args and not args.get("name"):
            args["name"] = args["name_or_pid"]

    if tool_name == "locate_ui_element" and isinstance(args, dict):
        if "query" in args and "element_name" not in args:
            args["element_name"] = args["query"]
        elif "element_name" in args and "query" not in args:
            args["query"] = args["element_name"]

    if tool_name == "run_autonomous_agent":
        return True, None
    feasible, missing = check_parameter_feasibility(tool_name, args)
    if not feasible:
        if tool_name == "find_and_interact" and ("target_query" in args or "query" in args):
            missing = [m for m in missing if m not in ("target_query", "query")]
        if missing:
            return False, f"PRE-EXECUTION BLOCKED: Tool '{tool_name}' missing required parameters: {', '.join(missing)}"

    # 2.6 Least-Disruptive Action Gating
    if ("read_only" in constraints or action in (SemanticAction.INSPECT, SemanticAction.QUERY_HISTORY)):
        if is_destructive(tool_name):
            return False, f"PRE-EXECUTION BLOCKED: Destructive tool '{tool_name}' violates read-only inspection intent."

    # 2.7 Confusable Pair Enforcement
    if tool_name == "launch_app" and any(p in str(args.get("name", "")).lower() for p in ["http://", "https://", "www.", ".com", ".org", ".net", ".io"]):
        return False, f"PRE-EXECUTION BLOCKED: URL target '{args.get('name')}' must use 'open_url', not 'launch_app'."

    # 2.8 Invasive Action Gating during Diagnostic / Inquiry Intents (Bullet #15)
    is_diagnostic_inquiry = (
        action in (SemanticAction.INSPECT, SemanticAction.DIAGNOSE)
        or "diagnostic" in constraints
        or "read_only" in constraints
        or "investigation" in constraints
    )
    if is_diagnostic_inquiry:
        invasive_diagnostic_tools = {
            "terminate_process", "kill_process", "close_app",
            "disable_network_adapter", "enable_network_adapter", "restart_adapter", "disconnect_wifi",
            "delete_file", "delete_folder", "clear_cache", "empty_recycle_bin",
            "restart_computer", "shutdown_computer", "format_disk"
        }
        if tool_name in invasive_diagnostic_tools or is_destructive(tool_name):
            return False, f"PRE-EXECUTION BLOCKED: Invasive/state-mutating tool '{tool_name}' is strictly prohibited during read-only diagnostic inquiries."

    # 2.9 Risk-Confidence Destructive Tool Gating (Bullet #20)
    DESTRUCTIVE_TOOLS = {"delete_file", "delete_folder", "kill_process", "terminate_process"}
    if tool_name in DESTRUCTIVE_TOOLS and not confirmed and "confirmed" not in constraints:
        target_str = str(args.get("path") or args.get("name") or "").lower().replace("\\", "/")
        is_scratch = "scratch/" in target_str and not any(p in target_str for p in ("protected", "decoy", "system", "windows"))
        if not (tool_name == "delete_file" and is_scratch):
            return False, f"CONFIRMATION_REQUIRED: Destructive operation '{tool_name}' requires explicit user confirmation."

    # 3. Domain & Action Firewall
    return validate_tool_against_firewall(domain, action, tool_name, args)


def validate_dynamic_step(
    tool_name: str,
    args: dict[str, Any],
    domain: SemanticDomain | None = None,
    action: SemanticAction | None = None,
    target: str = "",
    constraints: list[str] | None = None,
    confirmed: bool = False,
    injection_reason: str = "",
) -> tuple[bool, str | None]:
    """Bullet #21 & Bullet #22: Firewall validation for dynamically injected/adapted plan steps.

    Dynamically injected steps must pass standard pre-execution semantic checks,
    plus an additional guard: dynamically injected steps cannot perform HIGH_DESTRUCTIVE
    operations unless the parent step or context was explicitly confirmed.
    """
    constraints = constraints or []

    # Deduce domain and action if not explicitly supplied
    if domain is None or action is None:
        if tool_name in ("launch_app", "start_app", "restart_app", "focus_app", "find_application", "discover_applications"):
            eff_domain = SemanticDomain.APPLICATION
            eff_action = SemanticAction.LAUNCH if ("launch" in tool_name or "start" in tool_name) else SemanticAction.SEARCH
        elif tool_name in ("close_app", "terminate_process", "kill_process"):
            eff_domain = SemanticDomain.APPLICATION
            eff_action = SemanticAction.CLOSE
        elif tool_name in ("click_ui_element", "click_mouse", "double_click", "mouse_click", "find_and_interact", "click_element_by_text"):
            eff_domain = SemanticDomain.GUI
            eff_action = SemanticAction.CLICK
        elif tool_name in ("press_hotkey", "type_text", "send_keyboard_input"):
            eff_domain = SemanticDomain.GUI
            eff_action = SemanticAction.TYPE
        elif tool_name in ("inspect_screen", "locate_ui_element", "take_screenshot", "capture_screen", "find_text_on_screen", "wait_for_ui_settle", "pick_best_on_screen_item"):
            eff_domain = SemanticDomain.GUI
            eff_action = SemanticAction.INSPECT
        elif tool_name in ("open_url", "new_tab"):
            eff_domain = SemanticDomain.BROWSER
            eff_action = SemanticAction.OPEN
        elif tool_name in ("search_web",):
            eff_domain = SemanticDomain.BROWSER
            eff_action = SemanticAction.SEARCH
        elif tool_name in ("close_browser",):
            eff_domain = SemanticDomain.BROWSER
            eff_action = SemanticAction.CLOSE
        elif tool_name in ("create_file", "create_folder"):
            eff_domain = SemanticDomain.FILESYSTEM
            eff_action = SemanticAction.CREATE
        elif tool_name in ("delete_file", "delete_folder"):
            eff_domain = SemanticDomain.FILESYSTEM
            eff_action = SemanticAction.DELETE
        elif tool_name in ("move_file", "move_folder", "rename_file", "rename_folder", "replace_file"):
            eff_domain = SemanticDomain.FILESYSTEM
            eff_action = SemanticAction.MOVE_FILE
        elif tool_name in ("copy_file", "copy_folder"):
            eff_domain = SemanticDomain.FILESYSTEM
            eff_action = SemanticAction.COPY
        elif tool_name in ("search_files", "find_file"):
            eff_domain = SemanticDomain.FILESYSTEM
            eff_action = SemanticAction.SEARCH
        else:
            eff_domain = SemanticDomain.FILESYSTEM
            eff_action = SemanticAction.INSPECT
        domain = domain or eff_domain
        action = action or eff_action

    # Check negative constraints on dynamically injected steps
    if constraints:
        for c in constraints:
            c_low = c.lower()
            if any(kw in c_low for kw in ["without", "no", "mat", "don't", "dont", "avoid", "never", "prohibit"]):
                for arg_val in args.values():
                    val_str = str(arg_val).lower()
                    if val_str and val_str in c_low:
                        return False, (
                            f"PRE-EXECUTION BLOCKED: Dynamically injected step '{tool_name}' violates "
                            f"user constraint: '{c}' prohibits '{arg_val}'."
                        )

    # Remediation / permission retries inherit parent authorization
    if "permission retry" in injection_reason.lower() or "permission_denied" in injection_reason.lower():
        confirmed = True

    # Check destructive guard on dynamically injected steps
    HIGH_DESTRUCTIVE_TOOLS = {
        "delete_file", "delete_folder", "kill_process", "terminate_process",
        "format_disk", "restart_computer", "shutdown_computer", "empty_recycle_bin"
    }
    if tool_name in HIGH_DESTRUCTIVE_TOOLS and not confirmed and "confirmed" not in constraints:
        return False, (
            f"DYNAMIC_PLANNING_BLOCKED: Dynamically injected step '{tool_name}' is destructive "
            f"and requires explicit confirmation. (Reason: {injection_reason})"
        )

    return pre_execution_semantic_check(
        tool_name=tool_name,
        args=args,
        domain=domain,
        action=action,
        target=target,
        is_negated=False,
        negations=[],
        constraints=constraints,
        confirmed=confirmed
    )


def validate_compensation_action(
    tool_name: str,
    args: dict[str, Any],
    session_context: Any = None
) -> tuple[bool, str | None]:
    """
    Bullet #23: Validate compensation / rollback actions to ensure safety.
    Ensures that compensation actions do not inadvertently damage the host system,
    delete critical system directories/files, or kill non-target critical system processes.
    """
    import os

    # 1. Critical System Processes protection
    CRITICAL_PROCESSES = {
        "explorer.exe", "csrss.exe", "lsass.exe", "services.exe", "smss.exe",
        "svchost.exe", "winlogon.exe", "system", "idle", "taskhostw.exe",
        "dwm.exe", "conhost.exe", "runtimebroker.exe", "searchhost.exe"
    }
    if tool_name in ("close_app", "terminate_process", "kill_process"):
        proc_name = str(args.get("name") or args.get("process_name") or args.get("app_name") or "").lower()
        if proc_name in CRITICAL_PROCESSES or (proc_name + ".exe") in CRITICAL_PROCESSES:
            return False, f"CRITICAL_PROCESS_PROTECTION: Cannot terminate critical system process '{proc_name}' during rollback."

    # 2. Critical Filesystem Paths protection
    system_drive = os.environ.get("SystemDrive", "C:")
    users_parent = os.path.normpath(str(Path.home().parent)).lower()
    CRITICAL_PATH_PARTS = [
        os.path.normpath(f"{system_drive}\\windows").lower(),
        os.path.normpath(f"{system_drive}\\program files").lower(),
        os.path.normpath(f"{system_drive}\\program files (x86)").lower(),
        os.path.normpath(os.environ.get("ProgramData", f"{system_drive}\\programdata")).lower(),
        os.path.normpath(f"{users_parent}\\default").lower(),
        os.path.normpath(os.environ.get("PUBLIC", f"{users_parent}\\public")).lower(),
    ]
    if tool_name in ("delete_file", "delete_folder", "move_file", "move_folder"):
        target_path = str(args.get("path") or args.get("file_path") or args.get("folder_path") or "")
        if target_path:
            norm_path = os.path.normpath(target_path).lower()

            # Root drive protection (e.g. C:\ or C: or /)
            if norm_path in (f"{system_drive.lower()}\\", system_drive.lower(), "\\", "/", "c:\\", "c:", "d:\\", "d:"):
                return False, f"CRITICAL_PATH_PROTECTION: Cannot delete root drive '{target_path}' during rollback."

            # Direct user home protection (e.g. C:\Users\<name>)
            home_dir = os.path.normpath(os.path.expanduser("~")).lower()
            if norm_path == home_dir or norm_path == users_parent:
                return False, f"CRITICAL_PATH_PROTECTION: Cannot delete root user home '{target_path}' during rollback."

            # System directories
            for crit in CRITICAL_PATH_PARTS:
                if norm_path == crit or norm_path.startswith(crit + "\\"):
                    return False, f"CRITICAL_PATH_PROTECTION: Cannot delete system path '{target_path}' during rollback."

            # Pre-existing file check if session_context provides allocated_resources
            if session_context and hasattr(session_context, "allocated_resources"):
                for res in session_context.allocated_resources:
                    res_id = str(res.get("identifier", "")).lower()
                    if os.path.normpath(res_id) == norm_path:
                        if res.get("is_preexisting", False):
                            return False, f"ROLLBACK_SAFETY_VIOLATION: Cannot delete pre-existing resource '{target_path}' during rollback."

    return True, None


def validate_long_horizon_action(
    tool_name: str,
    args: dict[str, Any],
    budget_remaining: int,
    session_context: Any = None
) -> tuple[bool, str | None]:
    """
    Firewall guard for autonomous long-horizon exploration (Bullet #28).
    Ensures exploration does not execute high-risk destructive tools without explicit user authorization,
    and halts when budget is exhausted.
    """
    if budget_remaining <= 0:
        return False, "BUDGET_EXHAUSTED: Exploration budget has reached 0. Halting autonomous branching."

    destructive_tools = {"delete_file", "delete_folder", "format_drive", "kill_process", "terminate_process"}
    if tool_name in destructive_tools:
        path = str(args.get("path") or args.get("file_path") or "")
        if path and any(crit in path.lower() for crit in ["c:\\windows", "system32", "program files"]):
            return False, f"SECURITY_FIREWALL: Long-horizon exploration prohibited from destroying system path '{path}'."

    return True, None


# ==============================================================================
# BULLET #30: ADVERSARIAL JAILBREAK & INJECTION DEFENSE SHIELDS
# ==============================================================================

JAILBREAK_PATTERNS = [
    # 1. Instructional Overrides & Rule Disregard
    r'\b(?:ignore|disregard|forget|override|bypass)\s+(?:all\s+)?(?:safety|system|security|previous|prior)\s+(?:rules|instructions|guidelines|restrictions|protocols|prompts)\b',
    r'\b(?:system\s+instruction\s+bypass|security\s+protocol\s+override|safety\s+override|bypass\s+restrictions)\b',
    r'\bdo\s+not\s+follow\s+(?:safety|rules|instructions)\b',
    r'\byou\s+are\s+no\s+longer\s+bound\s+by\s+(?:safety|rules|restrictions|guidelines)\b',
    r'\bforget\s+(?:all\s+)?(?:prior|previous)\s+instructions\b',

    # 2. Roleplay & Persona Jailbreaks
    r'\bact\s+as\s+(?:a\s+)?(?:system\s+kernel|root|administrator|linux\s+terminal|unrestricted|god\s+mode|dan|it\s+admin)\b',
    r'\bpretend\s+(?:you\s+are|to\s+be)\s+(?:an?\s+)?(?:system\s+kernel|unrestricted(?:\s+ai)?|developer\s+mode|root|jailbroken|admin)\b',
    r'\bunrestricted\s+(?:ai|agent|mode)\b',
    r'\byou\s+are\s+now\s+(?:in\s+)?(?:developer\s+mode|maintenance\s+mode|debug\s+mode|sudo\s+mode|god\s+mode|root)\b',
    r'\b(?:developer\s+mode|maintenance\s+mode|debug\s+mode|sudo\s+mode|god\s+mode)\s+(?:enabled|activated|on)\b',
    r'\b(?:in\s+maintenance\s+mode|emergency\s+maintenance(?:\s+drill)?|kernel\s+override)\b',
    r'\b(?:emergency\s+cleanup|maintenance\s+drill|security\s+drill)\b.*\b(?:format|wipe|delete|purge)\b',
    r'\bas\s+an?\s+(?:test\s+engineer|administrator|admin|auditor),\s*(?:i\s+authorize|you\s+must)\b',

    # 3. Multilingual (Roman Urdu / Hinglish) Jailbreak Traps
    r'\b(?:safety\s+rules?|security\s+checks?)\s+(?:ko\s+)?(?:ignore|bypass)\s+karo\b',
    r'\bpichli\s+(?:instructions?|hidayat)\s+(?:ko\s+)?bhool\s+jao\b',
    r'\bmaintenance\s+mode\s+mein\b.*\b(?:format|delete|khatam|urwa|urra|wipe)\b',
    r'\bdeveloper\s+mode\s+on\s+hai\b',
    r'\badmin\s+hoon\b.*\b(?:format|wipe|delete|khatam)\b',
]


# Pre-compiled regexes for hot-path sub-second evaluation
_COMPILED_JAILBREAK_PATTERNS: list[re.Pattern] = [re.compile(p, re.IGNORECASE) for p in JAILBREAK_PATTERNS]


def check_adversarial_jailbreak(text: str) -> tuple[bool, str | None]:
    """
    Bullet #30 & #32: Detects adversarial prompt injection, persona manipulation,
    and instructional override attempts across English, Roman Urdu, and Hinglish.
    Uses pre-compiled regexes for sub-second, zero-recompilation performance.
    """
    if not text:
        return False, None

    lower = text.lower().strip()

    for cp in _COMPILED_JAILBREAK_PATTERNS:
        m = cp.search(lower)
        if m:
            return True, f"Adversarial jailbreak/override detected: '{m.group(0)}'"

    return False, None


def is_path_traversal_attack(path_str: str) -> bool:
    """
    Bullet #30: Detects directory traversal attacks targeting protected system roots.
    """
    if not path_str or not isinstance(path_str, str):
        return False

    raw_lower = path_str.lower().strip()

    # Check for relative traversal notation
    if ".." in raw_lower:
        if any(crit in raw_lower for crit in ["system32", "windows", "program files", "programdata"]):
            return True
        try:
            import os
            norm = os.path.normpath(path_str).lower()
            for crit in ["c:\\windows", "c:\\program files", "system32"]:
                if norm == crit or norm.startswith(crit + "\\") or crit in norm:
                    return True
        except Exception:
            return True

    return False


def sanitize_filename_literal(filename: str) -> str:
    """
    Bullet #30: Masks and strips command injection delimiters from filename strings,
    ensuring they are treated as harmless literal identifiers rather than shell expressions.
    """
    if not filename or not isinstance(filename, str):
        return ""

    cleaned = filename.replace("\0", "").replace("\r", "").replace("\n", " ")
    return cleaned.strip()




