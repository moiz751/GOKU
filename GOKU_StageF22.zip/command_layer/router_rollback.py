from __future__ import annotations
import os
from pathlib import Path
import re
import sys
import time
from typing import Any, Optional, Union, List, Dict, Tuple
from dataclasses import dataclass, field

from brain.planner import (
    Plan,
    PlanStep,
    StructuredIntent,
    create_plan_from_decision,
    decompose_compound_command,
    parse_compound_request,
    resolve_step_variables,
    resolve_step_variables_with_guard,
    inject_plan_prerequisites,
    prune_plan_steps,
    build_hypothesis_investigation_plan,
    build_root_cause_investigation_plan,
    parse_conditional_goal,
    synthesize_adaptive_replan,
    decompose_into_milestones,
    restore_plan_from_checkpoint,
    build_cross_domain_plan,
    apply_cross_domain_transformation,
    build_long_horizon_exploration_plan,
    decompose_long_horizon_goal,
    compute_state_hash,
    detect_state_cycle,
    heuristic_node_score,
    expand_exploration_frontier,
    select_next_frontier_node,
    apply_reflective_history_pruning,
)
from command_layer.cognitive_reasoner import CognitiveReasoner
from command_layer.context import (
    EntityType,
    TypedEntity,
    ORDINAL_REFERENCES,
    SessionContext,
    resolve_references,
    session_context,
    update_context_from_result,
)
from command_layer.semantic_model import (
    SemanticDomain,
    SemanticAction,
    CommandIntent,
    AmbiguityType,
    ClarificationRequest,
    SymptomCategory,
    SituationType,
    ConfidenceTier,
    RiskTier,
    ConfidenceScore,
    ConfirmationRequest,
    FailureType,
    AdaptiveStrategy,
    PlanAdaptation,
    TaskLifecycleState,
    TaskMilestone,
    TaskCheckpoint,
    DomainBridgeType,
    DomainBridgeLink,
    CrossDomainWorkflow,
    HorizonDepth,
    ExplorationNode,
    SearchFrontier,
    LongHorizonReport,
    HistoryQueryType,
    ExecutionTraceRecord,
    TraceSummary,
)
from command_layer.semantic_parser import (
    parse_semantic_intent,
    create_plan_from_intent,
    resolve_in_turn_correction,
    strip_conversational_noise,
    split_compound_clauses,
    detect_symptom_category,
)
from command_layer.firewall import validate_tool_against_firewall, pre_execution_semantic_check, validate_long_horizon_action
from command_layer.state_machine import agent_state
from command_layer.validator import validate_and_sanitize_tool_arguments
from command_layer.lexer import UniversalLexer
from brain.runtime_bus import RuntimePipingBus
from security.state import confirmation_manager
from tools.utils.app_resolver import (
    APP_ALIASES,
    get_canonical_app_name,
    resolve_app,
)
from tools.utils.target_resolver import TargetType, resolve_universal_target, disambiguate_multi_candidates
from command_layer.router_base import (
    Step,
    run_tool_call,
    resolve_system_canonical_path,
    verify_post_recovery,
    verify_semantic_outcome,
    capture_environment_snapshot,
    capture_step_observation,
    detect_environment_drift,
    _entity_val,
    get_all_schemas,
    KNOWN_SITE_KEYS,
    KNOWN_APP_NAMES,
    _has_file_extension,
    _normalize_resolved_path,
    _is_conversational_folder_path,
)
from security.safety_firewall import is_safe_readonly_operation
from security.confirm import RISKY_TOOLS
from command_layer.decomposer import count_action_verbs
from brain.workflow_orchestrator import orchestrate_compound_workflow
from tools.browser import sanitize_search_query
from tools.search import parse_search_grammar
import executor.verifier
import executor.executor

def execute_transactional_rollback(
    session_context: Any,
    failure_step: int = -1,
    failed_step_tool: str = "",
    error_code: str = "",
    failure_msg: str = ""
) -> tuple[bool, str]:
    """
    Bullet #23: Executes transactional rollback of partially completed multi-step plans.
    Inverses mutative actions (create_file -> delete_file, create_folder -> delete_folder,
    launch_app -> close_app, copy_file -> delete_file) in strict LIFO order, validates them
    via safety firewall, and physically verifies post-recovery state.
    """
    from executor.transaction_manager import should_suppress_rollback
    from brain.planner import generate_rollback_plan
    from command_layer.firewall import validate_compensation_action

    executed_steps = getattr(session_context, "executed_steps", [])
    allocated = getattr(session_context, "allocated_resources", [])

    eff_tool = failed_step_tool
    eff_code = error_code
    eff_msg = failure_msg
    if not eff_tool and executed_steps:
        for r in executed_steps:
            if (r.get("step") or r.get("step_id")) == failure_step:
                eff_tool = r.get("tool") or r.get("tool_name") or ""
                eff_msg = eff_msg or str(r.get("result", {}).get("message", ""))
                eff_code = eff_code or str(r.get("result", {}).get("error_code", ""))
                break
        if not eff_tool and executed_steps:
            last_rec = executed_steps[-1]
            eff_tool = last_rec.get("tool") or last_rec.get("tool_name") or ""
            eff_msg = eff_msg or str(last_rec.get("result", {}).get("message", ""))
            eff_code = eff_code or str(last_rec.get("result", {}).get("error_code", ""))

    if should_suppress_rollback(eff_tool, error_code=eff_code, error_message=eff_msg):
        print(f"[DEBUG_TRACE] TRANSACTIONAL ROLLBACK SUPPRESSED for UI lookup miss: {eff_tool}")
        return False, ""

    if not executed_steps and not allocated:
        return False, ""

    rollback_plan = generate_rollback_plan(
        executed_steps,
        session_context,
        failure_step=failure_step,
        failure_tool=eff_tool,
        failure_error=eff_msg,
        failure_error_code=eff_code
    )
    if not rollback_plan or not rollback_plan.steps:
        return False, ""

    print(f"[DEBUG_TRACE] INITIATING TRANSACTIONAL ROLLBACK for {len(rollback_plan.steps)} compensation steps...")
    rollback_summary = []
    rb_success_count = 0
    rb_fail_count = 0

    for rb_step in rollback_plan.steps:
        is_safe, rb_err = validate_compensation_action(rb_step.tool, rb_step.args, session_context)
        if not is_safe:
            print(f"[DEBUG_TRACE] COMPENSATION BLOCKED BY FIREWALL: {rb_err}")
            session_context.record_compensation_action(
                original_step=rb_step.step,
                tool_name=rb_step.tool,
                args=rb_step.args,
                success=False,
                verified=False,
                error=rb_err
            )
            rb_fail_count += 1
            rollback_summary.append(f"Blocked by policy: {rb_err}")
            continue

        rb_res = run_tool_call(rb_step.tool, rb_step.args)
        rb_target = rb_step.args.get("path") or rb_step.args.get("name") or rb_step.args.get("name_or_pid") or ""

        # Post-recovery physical state verification
        if rb_step.tool in ("delete_file", "delete_folder"):
            post_ver = verify_post_recovery("filesystem", rb_target, expected_state="deleted")
        elif rb_step.tool in ("close_app", "terminate_process", "kill_process"):
            post_ver = verify_post_recovery("process", rb_target, expected_state="stopped")
        else:
            post_ver = {"verified": rb_res.get("success", False)}

        verified = post_ver.get("verified", False)
        if rb_res.get("success") and verified:
            rb_success_count += 1
            session_context.record_compensation_action(
                original_step=rb_step.step,
                tool_name=rb_step.tool,
                args=rb_step.args,
                success=True,
                verified=True
            )
            rollback_summary.append(f"Reverted {rb_step.tool} on '{rb_target}'")
        else:
            rb_fail_count += 1
            err_msg = rb_res.get("error") or rb_res.get("message") or post_ver.get("error") or "Verification failed"
            session_context.record_compensation_action(
                original_step=rb_step.step,
                tool_name=rb_step.tool,
                args=rb_step.args,
                success=False,
                verified=False,
                error=err_msg
            )
            rollback_summary.append(f"Failed to revert {rb_step.tool} on '{rb_target}': {err_msg}")

    # Record overall outcome in SessionContext
    if rb_fail_count == 0 and rb_success_count > 0:
        session_context.record_recovery_outcome(
            outcome="ROLLBACK_SUCCESSFUL",
            details={"reverted_count": rb_success_count, "summary": rollback_summary}
        )
        overall_success = True
    elif rb_success_count > 0:
        session_context.record_recovery_outcome(
            outcome="ROLLBACK_FAILED",
            details={"reverted_count": rb_success_count, "failed_count": rb_fail_count, "summary": rollback_summary}
        )
        overall_success = False
    else:
        session_context.record_recovery_outcome(
            outcome="UNRECOVERABLE",
            details={"summary": rollback_summary}
        )
        overall_success = False

    # Flush rolled-back entities from SessionContext
    reverted_targets = {
        str(s.args.get("path") or s.args.get("name") or "").lower()
        for s in rollback_plan.steps if s.args
    }
    session_context.entities = [
        e for e in session_context.entities
        if str(_entity_val(e)).lower() not in reverted_targets
    ]

    summary_text = "Transactional Rollback executed:\n" + "\n".join(f"- {s}" for s in rollback_summary)
    return overall_success, summary_text
def _is_step_dependent_on(curr_step: PlanStep, prev_step_id: int, plan: Plan) -> bool:
    """
    Prompt D Step 3 Dependency Graph:
    Determines whether curr_step depends on a preceding step prev_step_id.
    - Explicit variable or candidate references ($step_X, $last_output)
    - Sequential GUI session lifecycle (launch -> focus -> type -> save -> close)
    - File lifecycle (create/save -> read/rename/delete)
    """
    for v in curr_step.args.values():
        if isinstance(v, str) and (f"$step_{prev_step_id}" in v or "$last_output" in v):
            return True

    prev_step = next((s for s in plan.steps if s.step == prev_step_id), None)
    if not prev_step:
        return False

    gui_tools = {
        "launch_app", "open_app", "focus_window", "focus_app_window",
        "type_text", "send_keyboard_input", "save_file_dialog", "save_file",
        "close_app", "manage_window", "click_mouse", "click_ui_element"
    }
    if curr_step.tool in gui_tools and prev_step.tool in gui_tools:
        if prev_step.tool in ("launch_app", "open_app"):
            return True
        if prev_step.tool in ("type_text", "send_keyboard_input") and curr_step.tool in ("save_file_dialog", "save_file", "close_app"):
            return True
        if prev_step.tool in ("save_file_dialog", "save_file") and curr_step.tool in ("close_app",):
            return True

    if prev_step.tool in ("create_file", "save_file", "save_file_dialog", "rename_file") and curr_step.tool in ("read_file", "rename_file", "delete_file"):
        p_prev = str(prev_step.args.get("path") or prev_step.args.get("filename") or "").lower()
        p_curr = str(curr_step.args.get("path") or curr_step.args.get("old_path") or curr_step.args.get("filename") or "").lower()
        if p_prev and p_curr and (Path(p_prev).name == Path(p_curr).name or p_prev in p_curr or p_curr in p_prev):
            return True

    return False
