from __future__ import annotations
from command_layer.context_models import EntityType, TypedEntity
import gc
import json
import os
from pathlib import Path
import re
import time
from typing import Any, Optional, Dict, List, Set, Tuple, TYPE_CHECKING
if TYPE_CHECKING:
    from command_layer.context import SessionContext

from command_layer.semantic_model import (
    PlanMutationType,
    PlanDAGNode,
    PlanMutation,
    FailureType,
    AdaptiveStrategy,
    PlanAdaptation,
    RecoveryStatus,
    CompensationAction,
    RollbackLedger,
    ObservationType,
    StepObservation,
    EnvironmentSnapshot,
    OutcomeVerdict,
    OutcomeCriteria,
    OutcomeReport,
    TaskLifecycleState,
    TaskMilestone,
    TaskCheckpoint,
    DomainBridgeType,
    DomainBridgeLink,
    CrossDomainWorkflow,
    HorizonDepth,
    ExplorationNode,
    SearchFrontier,
    LongHorizonReport,
    HistoryQueryType,
    ExecutionTraceRecord,
    TraceSummary,
    FirewallVerdict,
    AdversarialAttackRecord,
)

DIRECTORY_REFERENCES = [
    r"\busmein\b",
    r"\bus\s+mein\b",
    r"\bis\s*mein\b",
    r"\bis\s+ma\b",
    r"\bus\s+ma\b",
    r"\binside\s+it\b",
    r"\binside\s+that\s+folder\b",
    r"\binside\s+this\s+folder\b",
    r"\bthis\s+folder\b",
    r"\bthat\s+folder\b",
    r"\bye\s+folder\b",
    r"\byeh\s+folder\b",
    r"\bus\s+folder\b",
    r"\bis\s+folder\b",
    r"\bwoh\s+folder\b",
    r"\bwo\s+folder\b",
    r"\bwahan\b",
    r"\bthere\b",
]

FILE_REFERENCES = [
    r"\bthat\s+file\b",
    r"\bthis\s+file\b",
    r"\byeh\s+file\b",
    r"\bye\s+file\b",
    r"\bis\s+file\b",
    r"\bus\s+file\b",
    r"\bis\s+document\b",
    r"\bus\s+document\b",
    r"\bisko\b",
    r"\busko\b",
    r"\biski\b",
    r"\buski\b",
    r"\blatest\s+wali\b",
    r"\blatest\s+wala\b",
    r"\bsabse\s+latest\s+wali\b",
    r"\bsabse\s+latest\s+wala\b",
    r"\blatest\s+one\b",
    r"\blatest\s+pdf\b",
    r"\bsabse\s+latest\s+pdf\b",
    r"\blatest\s+file\b",
    r"\bsabse\s+latest\s+file\b",
]

APP_REFERENCES = [
    r"\bthis\s+app\b",
    r"\bthat\s+app\b",
    r"\bye\s+app\b",
    r"\byeh\s+app\b",
    r"\bwoh\s+app\b",
    r"\bwo\s+app\b",
    r"\bus\s+app\s+ko\b",
    r"\bis\s+app\s+ko\b",
    r"\bus\s+app\b",
    r"\bis\s+app\b",
    r"\bthe\s+app\b",
    r"\bthe\s+application\b",
    r"\bthis\s+application\b",
    r"\bthat\s+application\b",
    r"\bwoh\s+application\b",
    r"\bus\s+application\b",
]

# Bullet #7 Reference Resolution: Type-Constrained Noun Phrases
APP_NOUN_REFERENCES = [
    r"\b(?:is|us|this|that|ye|yeh|wo|woh|iss|uss|yahi|wohi)\s+(?:app|application|software|program)(?:\s+ko)?\b",
    r"\b(?:the)\s+(?:app|application|software|program)\b",
]

FILE_NOUN_REFERENCES = [
    r"\b(?:is|us|this|that|ye|yeh|wo|woh|iss|uss|yahi|wohi)\s+(?:file|document|doc|pdf|txt)(?:\s+ko)?\b",
    r"\b(?:the)\s+(?:file|document|doc|pdf|txt)\b",
]

FOLDER_NOUN_REFERENCES = [
    r"\b(?:is|us|this|that|ye|yeh|wo|woh|iss|uss|yahi|wohi)\s+(?:folder|directory|dir)(?:\s+(?:ko|mein|me))?\b",
    r"\b(?:the)\s+(?:folder|directory|dir)\b",
]

WINDOW_NOUN_REFERENCES = [
    r"\b(?:is|us|this|that|ye|yeh|wo|woh|iss|uss|yahi|wohi)\s+(?:window|tab|screen)(?:\s+ko)?\b",
    r"\b(?:the)\s+(?:window|tab|screen)\b",
]

PROCESS_NOUN_REFERENCES = [
    r"\b(?:is|us|this|that|ye|yeh|wo|woh|iss|uss|yahi|wohi)\s+(?:process|service)(?:\s+ko)?\b",
    r"\b(?:the)\s+(?:process|service)\b",
]

DRIVE_NOUN_REFERENCES = [
    r"\b(?:is|us|this|that|ye|yeh|wo|woh|iss|uss|yahi|wohi)\s+(?:drive|disk)(?:\s+ko)?\b",
    r"\b(?:the)\s+(?:drive|disk)\b",
]

# Bullet #7: Contrastive & Alternative References
CONTRASTIVE_REFERENCES = [
    r"\bthe\s+other\s+one\b",
    r"\bother\s+one\b",
    r"\bdifferent\s+one\b",
    r"\bthe\s+different\s+one\b",
    r"\balternate\s+one\b",
    r"\bthe\s+alternate\s+one\b",
    r"\bdusra\s+wala\b",
    r"\bdoosra\s+wala\b",
    r"\bdusri\s+wali\b",
    r"\bdoosri\s+wali\b",
    r"\bdusra\b",
    r"\bdoosra\b",
]

# Bullet #7: Multilingual Demonstratives & Pronouns with Strict Boundary Safety
MULTILINGUAL_PRONOUNS = [
    r"\bisko\b",
    r"\busko\b",
    r"\biski\b",
    r"\buski\b",
    r"\bisse\b",
    r"\busse\b",
    r"\biska\b",
    r"\buska\b",
    r"\bispe\b",
    r"\buspe\b",
    r"\binhe\b",
    r"\bunhe\b",
    r"\binka\b",
    r"\bunka\b",
    r"\bthis\b",
    r"\bthat\b",
    r"\bthese\b",
    r"\bthose\b",
    r"\bthe\s+same\b",
    r"\bthem\b",
    r"\bits\b",
    r"\bit\b",
    r"\byeh\b",
    r"\bye\b",
    r"\bwoh\b",
    r"\bwo\b",
    r"\byahi\b",
    r"\bwohi\b",
    r"\biss\b",
    r"\buss\b",
]

ORDINAL_REFERENCES = [
    (r"\b(?:pehli\s+wali|pehla\s+wala|first\s+one|first\s+result|1st\s+one|1st\s+wali|first\s+app|first\s+application|pehli\s+app|pehla\s+app|pehli\s+application|1st\s+app|1st\s+application|pehli\s+file|first\s+file)\b", 0),
    (r"\b(?:dusri\s+wali|doosri\s+wali|second\s+one|second\s+result|2nd\s+one|2nd\s+wali|second\s+app|second\s+application|doosri\s+app|dusri\s+app|dusra\s+app|doosra\s+app|2nd\s+app|2nd\s+application|dusri\s+file|second\s+file)\b", 1),
    (r"\b(?:teesri\s+wali|tisri\s+wali|third\s+one|third\s+result|3rd\s+one|3rd\s+wali|third\s+app|third\s+application|teesri\s+app|tisri\s+app|teesra\s+app|tisra\s+app|3rd\s+app|3rd\s+application|teesri\s+file|third\s+file)\b", 2),
    (r"\b(?:chauthi\s+wali|chothi\s+wali|fourth\s+one|fourth\s+result|4th\s+one|4th\s+wali|fourth\s+app|fourth\s+application|fourth\s+file)\b", 3),
    (r"\b(?:paanchvi\s+wali|panchvi\s+wali|fifth\s+one|fifth\s+result|5th\s+one|5th\s+wali|fifth\s+app|fifth\s+application|fifth\s+file)\b", 4),
    (r"\b(?:chhati\s+wali|chati\s+wali|sixth\s+one|sixth\s+result|6th\s+one|6th\s+wali|sixth\s+app|sixth\s+application|sixth\s+file)\b", 5),
    (r"\b(?:saatvi\s+wali|seventh\s+one|seventh\s+result|7th\s+one|7th\s+wali|seventh\s+app|seventh\s+application|seventh\s+file)\b", 6),
    (r"\b(?:aathvi\s+wali|athvi\s+wali|eighth\s+one|eighth\s+result|8th\s+one|8th\s+wali|eighth\s+app|eighth\s+application|eighth\s+file)\b", 7),
    (r"\b(?:nauvi\s+wali|ninth\s+one|ninth\s+result|9th\s+one|9th\s+wali|ninth\s+app|ninth\s+application|ninth\s+file)\b", 8),
    (r"\b(?:dasvi\s+wali|tenth\s+one|tenth\s+result|10th\s+one|10th\s+wali|tenth\s+app|tenth\s+application|tenth\s+file)\b", 9),
    (r"\b(?:aakhri\s+wali|akhri\s+wali|last\s+one|last\s+result|last\s+app|last\s+application|aakhri\s+file|last\s+file)\b", -1),
    (r"\b(?:previous\s+one|pichla\s+wala|pichli\s+wali|pehle\s+wala|pehle\s+wali)\b", -1),
]

VISUAL_REFERENCES = [
    r"\bis\s+button\s+par\b",
    r"\bus\s+button\s+par\b",
    r"\bis\s+icon\s+par\b",
    r"\bus\s+icon\s+par\b",
    r"\bis\s+element\s+par\b",
    r"\bus\s+element\s+par\b",
    r"\bthis\s+button\b",
    r"\bthat\s+button\b",
    r"\bthis\s+icon\b",
    r"\bthat\s+icon\b",
]
_COMPILED_VISUAL_REFERENCES = [re.compile(p, re.IGNORECASE) for p in VISUAL_REFERENCES]

_COMPILED_TYPO_FIXES = [
    (re.compile(r"\btaht\b", re.IGNORECASE), "that", r"\btaht\b"),
    (re.compile(r"\blasts\b", re.IGNORECASE), "last", r"\blasts\b"),
    (re.compile(r"\bengrybirds?\b", re.IGNORECASE), "angry birds", r"\bengrybirds?\b"),
    (re.compile(r"\bengry\s+birds?\b", re.IGNORECASE), "angry birds", r"\bengry\s+birds?\b"),
    (re.compile(r"\bchorme\b", re.IGNORECASE), "chrome", r"\bchorme\b"),
    (re.compile(r"\bnotpad\b", re.IGNORECASE), "notepad", r"\bnotpad\b"),
]


def _safe_val(entity: Any) -> Any:
    if entity is None:
        return None
    return getattr(entity, "value", entity)


def resolve_references(user_text: str, context: SessionContext) -> tuple[str, bool, str | None]:
    """
    Resolves conversational references in user text based on current SessionContext.
    Distinguishes files vs folders vs apps vs browser profiles vs visual elements cleanly.

    Returns:
        (resolved_text, is_ambiguous, clarification_message)
    """
    text = user_text
    is_search_intent = any(w in user_text.lower() for w in ["find", "search", "dhundo", "dhoondo"])
    # Typo normalization (Item 18) using pre-compiled regexes
    for cp, fix_word, orig_pat in _COMPILED_TYPO_FIXES:
        if is_search_intent and orig_pat in (r"\bnotpad\b", r"\bchorme\b"):
            continue
        text = cp.sub(fix_word, text)
    lower = text.lower()

    # Multi-turn clarification inheritance: e.g. "internet per", "google par" (Item 3)
    clean_strip = lower.strip().rstrip(".?!")
    if clean_strip in ("internet per", "internet par", "on the internet", "google par", "google pe", "web par", "online"):
        from command_layer.state_machine import agent_state
        active_q = context.last_search_query or (agent_state.current_search.get("query") if agent_state.current_search else None)
        if active_q:
            return f"Google par '{active_q}' search karo", False, None

    # Anaphoric continuation on clarification suggestions (e.g. "start becaus i want to play", "start", "play", "haan", "open it")
    if getattr(context, "last_clarification_suggestion", None):
        sug = context.last_clarification_suggestion
        proceed_intent = False
        if clean_strip in ("start", "play", "open", "launch", "run", "haan", "yes", "yeah", "yep", "ok", "sure", "khol do", "open it", "start it", "play it", "chalao", "chala do", "theek hai"):
            proceed_intent = True
        elif re.match(r'^(?:start|play|open|launch|run|chalao|kholo|khol do)\b(?:\s+(?:becaus|because|coz|cause|i want to|mujhe|plz|please|it|karo).*)?$', clean_strip):
            proceed_intent = True
        elif re.match(r'^(?:becaus|because|coz|cause)\b.*\b(?:play|khelna|chalao|start|open)\b', clean_strip):
            proceed_intent = True

        if proceed_intent:
            context.last_clarification_suggestion = None
            return f"open '{sug}'", False, None

    # Multi-turn reference: "that i say", "taht i say", "jo maine kaha"
    if any(p in lower for p in ["that i say", "taht i say", "jo maine kaha", "same one", "wohi wala", "wohi wali"]):
        from command_layer.state_machine import agent_state
        active_q = context.last_search_query or (agent_state.current_search.get("query") if agent_state.current_search else None)
        if active_q:
            text = re.sub(r'\b(?:that\s+i\s+say|taht\s+i\s+say|jo\s+maine\s+kaha|same\s+one|wohi\s+wala|wohi\s+wali)\b', f"'{active_q}'", text, flags=re.IGNORECASE)
            lower = text.lower()

    # Memory Reference Binding: Calculation results ("jo abhi calculate kiya", "calculation result", etc.)
    CALC_PATTERNS = [
        r"\b(?:jo\s+abhi\s+calculate\s+kiya|calculation\s+result|calculated\s+value|last\s+calculation|jo\s+calculate\s+kiya)\b",
    ]
    for pat in CALC_PATTERNS:
        if re.search(pat, lower):
            calc_val = context.last_calculation or (context.extracted_metrics.get("last_calculation") if context.extracted_metrics else None) or context.last_output
            if calc_val:
                text = re.sub(pat, str(calc_val), text, flags=re.IGNORECASE)
                lower = text.lower()
            else:
                return text, True, "Ambiguous reference: No calculation result found in recent session memory."

    # Memory Reference Binding: Previous / saved file references ("pichli file", "previous file", "last saved file", etc.)
    PAST_FILE_PATTERNS = [
        r"\b(?:pichli\s+file(?:\s+ka\s+path)?|previous\s+file|last\s+saved\s+file|last\s+saved|pichli\s+saved\s+file)\b",
    ]
    for pat in PAST_FILE_PATTERNS:
        if re.search(pat, lower):
            t_file = None
            if context.saved_files:
                t_file = context.saved_files[-1]
            elif context.last_created_file:
                t_file = context.last_created_file
            elif context.last_referenced_file:
                t_file = context.last_referenced_file
            elif context.last_file:
                t_file = _safe_val(context.last_file)

            if t_file:
                if "path" in lower or "location" in lower:
                    text = re.sub(pat, lambda m, f=t_file: f"'{f}'", text, flags=re.IGNORECASE)
                else:
                    text = re.sub(pat, lambda m, f=t_file: f"file '{f}'", text, flags=re.IGNORECASE)
                lower = text.lower()
            else:
                return text, True, "Ambiguous reference: No previously saved or referenced file found in session memory."

    # Bullet #6: Continuity modifiers: "same app", "wahi app", "same file", "wahi file", "same folder", "wahi folder"
    if re.search(r'\b(?:same|wahi|wohi)\s+app\b', lower):
        if context.last_application:
            text = re.sub(r'\b(?:same|wahi|wohi)\s+app\b', lambda m: str(_safe_val(context.last_application)), text, flags=re.IGNORECASE)
            lower = text.lower()
        else:
            return text, True, "Ambiguous reference: No active application found in recent context."

    if re.search(r'\b(?:same|wahi|wohi)\s+file\b', lower):
        t_file = _safe_val(context.last_file) if context.last_file else (_safe_val(context.last_selected_file) if context.last_selected_file else context.last_referenced_file)
        if t_file:
            text = re.sub(r'\b(?:same|wahi|wohi)\s+file\b', lambda m, f=t_file: f"file '{f}'", text, flags=re.IGNORECASE)
            lower = text.lower()
        else:
            return text, True, "Ambiguous reference: No active file found in recent context."

    if re.search(r'\b(?:same|wahi|wohi)\s+folder\b', lower):
        t_dir = _safe_val(context.last_folder) if context.last_folder else (_safe_val(context.last_selected_folder) if context.last_selected_folder else context.last_active_directory)
        if t_dir:
            text = re.sub(r'\b(?:same|wahi|wohi)\s+folder\b', lambda m, d=t_dir: f"folder '{d}'", text, flags=re.IGNORECASE)
            lower = text.lower()
        else:
            return text, True, "Ambiguous reference: No active folder found in recent context."

    if re.search(r'\b(?:same|wahi|wohi|yahi|yehi)\b', lower) and not re.search(r'\b(?:same|wahi|wohi|yahi|yehi)\s+(?:app|file|folder)\b', lower):
        if context.last_verified_entity:
            ent = context.last_verified_entity
            ent_val = _safe_val(ent)
            if ent.entity_type == EntityType.APPLICATION:
                text = re.sub(r'\b(?:same|wahi|wohi|yahi|yehi)\b', lambda m, v=ent_val: str(v), text, flags=re.IGNORECASE)
            elif ent.entity_type == EntityType.FILE:
                text = re.sub(r'\b(?:same|wahi|wohi|yahi|yehi)\b', lambda m, v=ent_val: f"file '{v}'", text, flags=re.IGNORECASE)
            elif ent.entity_type == EntityType.FOLDER:
                text = re.sub(r'\b(?:same|wahi|wohi|yahi|yehi)\b', lambda m, v=ent_val: f"folder '{v}'", text, flags=re.IGNORECASE)
            elif ent.entity_type == EntityType.UI_ELEMENT:
                text = re.sub(r'\b(?:same|wahi|wohi|yahi|yehi)\b', lambda m, v=ent_val: f"'{v}'", text, flags=re.IGNORECASE)
            lower = text.lower()

    # Step 0: Check for Contrastive & Alternative References (Bullet #7)
    has_contrastive = any(re.search(pat, lower) for pat in CONTRASTIVE_REFERENCES)
    has_noun_np = any(re.search(pat, lower) for pat in APP_NOUN_REFERENCES + FILE_NOUN_REFERENCES + FOLDER_NOUN_REFERENCES + WINDOW_NOUN_REFERENCES + PROCESS_NOUN_REFERENCES) or bool(re.search(r'\btabs?\b', lower))
    if has_contrastive and not has_noun_np:
        if context.last_search_results and len(context.last_search_results) >= 2:
            active_val = None
            if context.last_verified_entity:
                active_val = str(_safe_val(context.last_verified_entity)).lower()
            elif context.last_application:
                active_val = str(_safe_val(context.last_application)).lower()
            elif context.last_file:
                active_val = str(_safe_val(context.last_file)).lower()

            cand = context.last_search_results[1]
            if active_val and str(context.last_search_results[0]).lower() != active_val:
                cand = context.last_search_results[0]
            elif active_val and str(context.last_search_results[1]).lower() == active_val and len(context.last_search_results) > 2:
                cand = context.last_search_results[2]

            is_app_cand = (
                context.last_search_results_type == EntityType.APPLICATION
                or any(w in lower for w in ["process", "status", "app", "program", "launch", "chal", "running", "band", "naam", "name"])
            )
            for pat in CONTRASTIVE_REFERENCES:
                if is_app_cand:
                    text = re.sub(pat, lambda m, c=cand: str(c), text, flags=re.IGNORECASE)
                else:
                    text = re.sub(pat, lambda m, c=cand: f"file '{c}'", text, flags=re.IGNORECASE)
            return text, False, None
        elif context.last_search_results:
            return text, True, "Ambiguous reference: Only 1 search result available, no alternative candidate."
        else:
            return text, True, "Ambiguous reference: No alternative candidate available in search results."

    # Step 0.2: Check for Ordinal References (e.g. "pehli wali open karo", "second one open karo")
    for pat, idx in ORDINAL_REFERENCES:
        if re.search(pat, lower):
            if context.last_search_results:
                target_idx = idx if idx >= 0 else len(context.last_search_results) + idx
                if 0 <= target_idx < len(context.last_search_results):
                    target_res = context.last_search_results[target_idx]
                    is_file_res = (
                        context.last_search_results_type == EntityType.FILE
                        or any(str(target_res).lower().endswith(ext) for ext in ('.pdf', '.txt', '.doc', '.docx', '.csv', '.xlsx', '.png', '.jpg', '.jpeg', '.py', '.json', '.html', '.zip', '.md'))
                        or ("\\" in str(target_res) or "/" in str(target_res))
                    )
                    is_app_context = (
                        not is_file_res and (
                            context.last_search_results_type == EntityType.APPLICATION
                            or any(w in lower for w in ["process", "status", "app", "program", "launch", "chal", "running", "band", "naam", "name"])
                        )
                    )
                    if is_app_context:
                        text = re.sub(pat, lambda m, f=target_res: f"{f}", text, flags=re.IGNORECASE)
                    else:
                        text = re.sub(pat, lambda m, f=target_res: f"file '{f}'", text, flags=re.IGNORECASE)
                    return text, False, None
                else:
                    return text, True, f"Ambiguous reference: Only {len(context.last_search_results)} search results available in context."
            elif context.last_application and idx in (0, -1) and any(w in lower for w in ["process", "status", "app", "program", "kholo", "launch", "close"]):
                target_app = _safe_val(context.last_application)
                text = re.sub(pat, lambda m, f=target_app: f"{f}", text, flags=re.IGNORECASE)
                return text, False, None
            elif context.last_selected_file or context.last_referenced_file:
                target_file = _safe_val(context.last_selected_file) if context.last_selected_file else context.last_referenced_file
                text = re.sub(pat, lambda m, f=target_file: f"file '{f}'", text, flags=re.IGNORECASE)
                return text, False, None

            return text, True, "Ambiguous reference: No search results or matched items found in context to select ordinal from."

    # Step 0.5: Check for Visual Element References (e.g. "is button par click karo")
    has_vis_ref = any(re.search(pat, lower) for pat in VISUAL_REFERENCES)
    if has_vis_ref:
        if context.last_visual_element:
            target_el = _safe_val(context.last_visual_element)
            for pat in VISUAL_REFERENCES:
                text = re.sub(pat, f"'{target_el}'", text, flags=re.IGNORECASE)
        else:
            return text, True, "Ambiguous reference: No target UI element found in recent visual context."

    lower = text.lower()

    # Step 1: Check for named folder entities in context (e.g. "Frontend folder kholo")
    named_folder_m = re.search(r'\b([a-zA-Z0-9_\-]+)\s+folder\b', text, flags=re.IGNORECASE)
    if named_folder_m:
        cand_name = named_folder_m.group(1).lower()
        if cand_name not in ("this", "that", "ye", "yeh", "is", "us", "create", "make", "banao", "open", "kholo", "delete", "hatao"):
            for entity in reversed(context.recent_entities):
                p = Path(entity)
                if p.name.lower() == cand_name:
                    text = re.sub(
                        rf'\b{re.escape(named_folder_m.group(0))}\b',
                        lambda m, full=str(p): f"folder '{full}'",
                        text,
                        flags=re.IGNORECASE,
                    )
                    break
            else:
                parent_dir = context.last_created_directory or context.last_active_directory
                if parent_dir:
                    child_cand = Path(parent_dir) / cand_name
                    if child_cand.exists():
                        text = re.sub(
                            rf'\b{re.escape(named_folder_m.group(0))}\b',
                            lambda m, full=str(child_cand): f"folder '{full}'",
                            text,
                            flags=re.IGNORECASE,
                        )

    lower = text.lower()

    # Special check: If user mentions "profile", "dialog", explicit filename with save, visual identification, or in-app typing
    is_typing_action = ("likho" in lower or "type" in lower) and not ("banao" in lower or "create" in lower or "make" in lower or "folder" in lower)
    is_screen_inspection = "screen" in lower and any(w in lower for w in ["what", "inspect", "dekho", "kya", "identify", "locate", "jaiza", "currently", "show"])
    is_screenshot_action = any(w in lower for w in ["screenshot", "tasveer", "picture", "snapshot", "photo", "image", "capture"]) and ("screen" in lower or "display" in lower)
    has_explicit_named_target = bool(re.search(r'\b(?:named|called|jiska\s+naam|ka\s+naam)\s+[\'"][^\'"]+[\'"]', text, flags=re.IGNORECASE))
    is_mouse_action = bool(re.search(r'\b(?:mouse|cursor)\b', lower))

    if (
        "profile" in lower
        or "dialog" in lower
        or is_typing_action
        or is_screen_inspection
        or is_screenshot_action
        or has_explicit_named_target
        or is_mouse_action
        or ("save" in lower and re.search(r'\.[a-zA-Z0-9]+', text))
        or "screen par jo" in lower
        or (("identify" in lower or "locate" in lower) and "screen" in lower)
    ):
        return text, False, None

    # Bullet #7: Step 2 — Type-Constrained Anaphora (Noun-Phrase References)
    # These MUST evaluate before generic pronouns so that "is app ko band karo" never binds to a file!
    if any(re.search(pat, lower) for pat in APP_NOUN_REFERENCES):
        t_app = (
            _safe_val(context.last_application)
            or context.get_typed_target(EntityType.APPLICATION)
            or context.last_launched_application
        )
        if t_app:
            val = str(t_app)
            if (
                val.endswith(":")
                or (len(val) == 2 and val[1] == ":")
                or re.search(r'\.[a-zA-Z0-9]{2,4}$', val)
                or any(net in val.lower() for net in ["wi-fi", "ethernet", "adapter", "192.168"])
            ):
                return text, True, f"Type mismatch: '{val}' is not an application."
            for pat in APP_NOUN_REFERENCES:
                text = re.sub(pat, lambda m, a=val: str(a), text, flags=re.IGNORECASE)
            lower = text.lower()
        else:
            return text, True, "Ambiguous reference: No active application found in recent context."

    has_explicit_file = bool(
        re.search(r'\b(?:file|document|doc)\s+(?:named|called)\s+', lower)
        or re.search(r'\b(?:file|document|doc)\s+[\'"][^\'"]+[\'"]', text)
        or re.search(r'[\'"][^\'"]+\.[a-zA-Z0-9]{2,4}[\'"]', text)
        or re.search(r'\b[a-zA-Z0-9_\-]+\.[a-zA-Z0-9]{2,4}\b', text)
    )
    if not has_explicit_file and any(re.search(pat, lower) for pat in FILE_NOUN_REFERENCES):
        t_file = (
            _safe_val(context.last_selected_file)
            or _safe_val(context.last_file)
            or context.get_typed_target(EntityType.FILE)
            or context.last_referenced_file
            or context.last_created_file
            or context.last_opened_file
        )
        if t_file:
            for pat in FILE_NOUN_REFERENCES:
                text = re.sub(pat, lambda m, f=t_file: f"file '{f}'", text, flags=re.IGNORECASE)
            lower = text.lower()
        else:
            return text, True, "Ambiguous reference: No target file found in recent context."

    has_explicit_folder = bool(
        re.search(r'\b(?:folder|directory|dir)\s+(?:named|called)\s+', lower)
        or re.search(r'\b(?:folder|directory|dir)\s+[\'"][^\'"]+[\'"]', text)
    )
    if not has_explicit_folder and any(re.search(pat, lower) for pat in FOLDER_NOUN_REFERENCES):
        t_dir = (
            _safe_val(context.last_selected_folder)
            or _safe_val(context.last_folder)
            or context.get_typed_target(EntityType.FOLDER)
            or context.last_active_directory
            or context.last_opened_directory
            or context.last_created_directory
            or context.last_referenced_directory
        )
        if t_dir:
            for pat in FOLDER_NOUN_REFERENCES:
                text = re.sub(pat, lambda m, d=t_dir: f"folder '{d}'", text, flags=re.IGNORECASE)
            lower = text.lower()
        else:
            return text, True, "Ambiguous reference: No active folder found in recent context."

    if any(re.search(pat, lower) for pat in WINDOW_NOUN_REFERENCES):
        t_win = (
            _safe_val(context.last_window)
            or _safe_val(context.last_browser)
            or context.get_typed_target(EntityType.WINDOW)
            or context.get_typed_target(EntityType.BROWSER)
        )
        if t_win:
            for pat in WINDOW_NOUN_REFERENCES:
                text = re.sub(pat, lambda m, w=t_win: f"'{w}'", text, flags=re.IGNORECASE)
            lower = text.lower()
        else:
            return text, True, "Ambiguous reference: No active window or tab found in recent context."

    if any(re.search(pat, lower) for pat in PROCESS_NOUN_REFERENCES):
        t_proc = (
            _safe_val(context.last_process)
            or _safe_val(context.last_service)
            or context.get_typed_target(EntityType.PROCESS)
            or context.get_typed_target(EntityType.SERVICE)
        )
        if t_proc:
            for pat in PROCESS_NOUN_REFERENCES:
                if any(w in lower for w in ["service", "services"]):
                    text = re.sub(pat, lambda m, p=t_proc: f"service {p}", text, flags=re.IGNORECASE)
                else:
                    text = re.sub(pat, lambda m, p=t_proc: f"process '{p}'", text, flags=re.IGNORECASE)
            lower = text.lower()
        else:
            return text, True, "Ambiguous reference: No active process or service found in recent context."

    if any(re.search(pat, lower) for pat in DRIVE_NOUN_REFERENCES):
        t_drv = (
            _safe_val(context.last_drive)
            or context.get_typed_target(EntityType.DRIVE)
        )
        if t_drv:
            for pat in DRIVE_NOUN_REFERENCES:
                text = re.sub(pat, lambda m, d=t_drv: f"drive '{d}'", text, flags=re.IGNORECASE)
            lower = text.lower()
        else:
            return text, True, "Ambiguous reference: No active drive found in recent context."

    # Bullet #7: Step 3 — Container vs Target Prepositional References ("usmein", "inside it")
    CONTAINER_PREPS = [
        r"\busmein\b", r"\bus\s+mein\b", r"\bismein\b", r"\bis\s+mein\b",
        r"\bis\s+ma\b", r"\bus\s+ma\b", r"\binside\s+it\b", r"\binside\s+that\b"
    ]
    has_container_prep = any(re.search(pat, lower) for pat in CONTAINER_PREPS)
    if has_container_prep:
        has_file_payload = any(ext in lower for ext in [".txt", ".pdf", ".py", ".doc", ".docx", ".png", ".jpg", ".csv", ".xlsx", ".json", ".html", ".md", ".zip"]) or any(w in lower for w in ["file", "document", "files", "banao", "create", "make", "find", "search", "list"])
        has_web_payload = any(w in lower for w in [".com", ".org", ".net", "fast.com", "google", "youtube", "url", "site", "website", "tab", "page", "browse"])
        
        t_fld = (
            _safe_val(context.last_selected_folder)
            or _safe_val(context.last_folder)
            or context.last_active_directory
            or context.parent_container
            or context.last_opened_directory
            or context.last_created_directory
            or context.last_referenced_directory
        )
        t_brw = (
            _safe_val(context.last_browser)
            or (_safe_val(context.last_application) if context.last_application and any(b in str(_safe_val(context.last_application)).lower() for b in ["chrome", "edge", "firefox", "browser"]) else None)
        )

        if has_file_payload and t_fld:
            for pat in CONTAINER_PREPS:
                text = re.sub(pat, lambda m, d=t_fld: f"folder '{d}'", text, flags=re.IGNORECASE)
            lower = text.lower()
        elif has_web_payload and t_brw:
            for pat in CONTAINER_PREPS:
                text = re.sub(pat, lambda m, b=t_brw: str(b), text, flags=re.IGNORECASE)
            lower = text.lower()
        elif t_fld:
            for pat in CONTAINER_PREPS:
                text = re.sub(pat, lambda m, d=t_fld: f"folder '{d}'", text, flags=re.IGNORECASE)
            lower = text.lower()
        elif t_brw:
            for pat in CONTAINER_PREPS:
                text = re.sub(pat, lambda m, b=t_brw: str(b), text, flags=re.IGNORECASE)
            lower = text.lower()
        else:
            return text, True, "Ambiguous reference: No active folder found in recent context."

    # Bullet #7: Step 4 — Multilingual Demonstratives & Pronouns with Strict Boundary Safety
    has_pronoun = any(re.search(pat, lower) for pat in MULTILINGUAL_PRONOUNS)
    has_qualifier = any(w in lower for w in ["file", "folder", "pdf", "doc", "txt", "text", "clipboard", "app", "application", "window", "tab", "process", "service", "directory", "drive", "disk"])

    if has_pronoun and not has_qualifier:
        target_f = (
            _safe_val(context.last_selected_file)
            or _safe_val(context.last_file)
            or (_safe_val(context.last_verified_entity) if context.last_verified_entity and getattr(context.last_verified_entity, "entity_type", None) == EntityType.FILE else None)
            or context.last_referenced_file
            or context.last_opened_file
            or context.last_created_file
        )
        target_d = (
            _safe_val(context.last_selected_folder)
            or _safe_val(context.last_folder)
            or (_safe_val(context.last_verified_entity) if context.last_verified_entity and getattr(context.last_verified_entity, "entity_type", None) == EntityType.FOLDER else None)
            or context.last_referenced_directory
            or context.last_opened_directory
            or context.last_created_directory
        )
        target_a = (
            _safe_val(context.last_application)
            or (_safe_val(context.last_verified_entity) if context.last_verified_entity and getattr(context.last_verified_entity, "entity_type", None) == EntityType.APPLICATION else None)
            or context.last_launched_application
        )
        target_w = (
            getattr(context.last_window, 'value', context.last_window)
            or getattr(context.last_browser, 'value', context.last_browser)
            or (_safe_val(context.last_verified_entity) if context.last_verified_entity and getattr(context.last_verified_entity, "entity_type", None) in (EntityType.WINDOW, EntityType.BROWSER) else None)
        )
        target_drv = (
            _safe_val(context.last_drive)
            or context.get_typed_target(EntityType.DRIVE)
            or (_safe_val(context.last_verified_entity) if context.last_verified_entity and getattr(context.last_verified_entity, "entity_type", None) == EntityType.DRIVE else None)
        )
        target_vis = (
            _safe_val(context.last_visual_element)
            or (_safe_val(context.last_verified_entity) if context.last_verified_entity and getattr(context.last_verified_entity, "entity_type", None) == EntityType.UI_ELEMENT else None)
        )

        # Action-aware Pronoun Resolution: Window/App actions (minimise, minimize, close, band) resolve to preceding active app/window
        is_window_app_action = any(w in lower for w in ["minimize", "minimise", "maximize", "restore", "chhota", "bada"]) or (
            any(w in lower for w in ["close", "band", "exit", "terminate", "kill"]) and not any(w in lower for w in ["delete", "remove", "hatao", "erase", "trash", "recycle", "file", "folder", "directory"])
        )
        if is_window_app_action:
            last_owned = getattr(context, "last_owned_app", None)
            t_app_win = last_owned or target_a or target_w
            if t_app_win:
                for pat in MULTILINGUAL_PRONOUNS:
                    text = re.sub(pat, lambda m, a=t_app_win: f"'{a}'", text, flags=re.IGNORECASE)
                return text, False, None
            else:
                # No app/window to bind the pronoun to: never hand "isko"/"this" to close_app as if it were an app name.
                return text, True, "Ambiguous reference: No active application or window found in recent context. Which one do you want to close?"

        # Multi-Entity Collision Checks
        if target_f and target_d:
            if context.last_verified_entity:
                if getattr(context.last_verified_entity, "entity_type", None) == EntityType.FILE and Path(target_f).name.lower() == Path(str(_safe_val(context.last_verified_entity))).name.lower():
                    target_d = None
                elif getattr(context.last_verified_entity, "entity_type", None) == EntityType.FOLDER and Path(target_d).name.lower() == Path(str(_safe_val(context.last_verified_entity))).name.lower():
                    target_f = None
                else:
                    return text, True, f"Ambiguous reference: Both file '{Path(target_f).name}' and folder '{Path(target_d).name}' are present in context. Which one do you mean?"
            else:
                return text, True, f"Ambiguous reference: Both file '{Path(target_f).name}' and folder '{Path(target_d).name}' are present in context. Which one do you mean?"

        if target_f and target_a and any(w in lower for w in ["delete", "hatao", "check", "status", "remove", "open", "kholo", "close", "band", "exit", "terminate", "shut"]):
            return text, True, f"Ambiguous reference: Both file '{Path(target_f).name}' and application '{target_a}' are present in context. Which one do you mean?"
        if target_d and target_a and any(w in lower for w in ["delete", "hatao", "open", "kholo", "close", "band", "exit", "terminate", "shut"]):
            return text, True, f"Ambiguous reference: Both folder '{Path(target_d).name}' and application '{target_a}' are present in context. Which one do you mean?"

        if target_vis and (any(w in lower for w in ["click", "press", "dabao", "select", "tap"]) or not (target_f or target_d or target_a or target_w or target_drv)):
            for pat in MULTILINGUAL_PRONOUNS:
                text = re.sub(pat, lambda m, v=target_vis: f"'{v}'", text, flags=re.IGNORECASE)
            return text, False, None
        elif target_drv and any(w in lower for w in ["free space", "space", "full", "usage", "drive", "disk"]):
            for pat in MULTILINGUAL_PRONOUNS:
                text = re.sub(pat, lambda m, d=target_drv: f"drive '{d}'", text, flags=re.IGNORECASE)
            return text, False, None
        elif target_f:
            for pat in MULTILINGUAL_PRONOUNS:
                text = re.sub(pat, lambda m, f=target_f: f"file '{f}'", text, flags=re.IGNORECASE)
            return text, False, None
        elif target_d:
            for pat in MULTILINGUAL_PRONOUNS:
                text = re.sub(pat, lambda m, d=target_d: f"folder '{d}'", text, flags=re.IGNORECASE)
            return text, False, None
        elif target_a:
            for pat in MULTILINGUAL_PRONOUNS:
                text = re.sub(pat, lambda m, a=target_a: str(a), text, flags=re.IGNORECASE)
            return text, False, None
        elif target_w:
            for pat in MULTILINGUAL_PRONOUNS:
                text = re.sub(pat, lambda m, w=target_w: f"'{w}'", text, flags=re.IGNORECASE)
            return text, False, None
        elif target_vis:
            for pat in MULTILINGUAL_PRONOUNS:
                text = re.sub(pat, lambda m, v=target_vis: f"'{v}'", text, flags=re.IGNORECASE)
            return text, False, None
        else:
            return text, True, "Ambiguous reference: No active entity found in recent context to resolve pronoun."

    # Step 5: Remaining Directory & File References
    has_dir_ref = not has_explicit_folder and any(re.search(pat, lower) for pat in DIRECTORY_REFERENCES)
    has_file_ref = not has_explicit_file and any(re.search(pat, lower) for pat in FILE_REFERENCES) and not ("text" in lower or "clipboard" in lower or "folder" in lower or "directory" in lower)
    has_app_ref = any(re.search(pat, lower) for pat in APP_REFERENCES)

    if not has_dir_ref and not has_file_ref and not has_app_ref:
        return text, False, None

    if has_dir_ref:
        target_dir = (
            _safe_val(context.last_selected_folder)
            or _safe_val(context.last_folder)
            or context.last_active_directory
            or context.last_opened_directory
            or context.last_created_directory
            or context.last_referenced_directory
        )
        if not target_dir and context.last_created_file:
            target_dir = str(Path(context.last_created_file).parent)
        elif not target_dir and context.last_opened_file:
            target_dir = str(Path(context.last_opened_file).parent)
        elif not target_dir and context.last_referenced_file:
            target_dir = str(Path(context.last_referenced_file).parent)

        if not target_dir:
            target_app = (
                _safe_val(context.last_application)
                or context.last_launched_application
            )
            if target_app and any(w in lower for w in ["open", "kholo", "launch", "chalao", "focus", "close", "band"]):
                for pat in DIRECTORY_REFERENCES:
                    text = re.sub(pat, str(target_app), text, flags=re.IGNORECASE)
            elif any(w in lower for w in ["chrome", "browser", "tab", "session", "page", "window"]):
                pass
            else:
                return text, True, "Ambiguous reference: No active folder found in recent context."
        else:
            for pat in DIRECTORY_REFERENCES:
                text = re.sub(pat, lambda m, d=target_dir: f"folder '{d}'", text, flags=re.IGNORECASE)

    lower = text.lower()
    if has_file_ref:
        target_file = (
            _safe_val(context.last_selected_file)
            or _safe_val(context.last_file)
            or _safe_val(context.last_search_result)
            or context.last_referenced_file
            or context.last_created_file
            or context.last_opened_file
        )

        if not target_file:
            target_app = (
                _safe_val(context.last_application)
                or context.last_launched_application
            )
            if target_app and any(w in lower for w in ["open", "kholo", "khol", "launch", "start", "restart", "chalao", "focus", "close", "band", "status", "process", "naam", "chal", "run", "maximize", "minimize", "restore", "bada", "chhota", "resize"]):
                for pat in FILE_REFERENCES:
                    text = re.sub(pat, str(target_app), text, flags=re.IGNORECASE)
            elif any(w in lower for w in ["downloads", "desktop", "documents", "dikhao", "show", "list", "dhoondo", "dhundo", "find", "search", "locate", "kholo", "open"]):
                pass
            elif not has_dir_ref:
                return text, True, "Ambiguous reference: No target file found in recent context."
        else:
            for pat in FILE_REFERENCES:
                text = re.sub(pat, lambda m, f=target_file: f"file '{f}'", text, flags=re.IGNORECASE)

    if has_app_ref:
        target_app = (
            _safe_val(context.last_application)
            or context.last_launched_application
        )
        if target_app:
            val = str(target_app)
            if (
                not val.endswith(":")
                and not (len(val) == 2 and val[1] == ":")
                and not re.search(r'\.[a-zA-Z0-9]{2,4}$', val)
                and not any(net in val.lower() for net in ["wi-fi", "ethernet", "adapter", "192.168"])
            ):
                for pat in APP_REFERENCES:
                    text = re.sub(pat, val, text, flags=re.IGNORECASE)
            else:
                return text, True, f"Type mismatch: '{val}' is not an application."
        else:
            return text, True, "Ambiguous reference: No active application found in recent context."

    return text, False, None

