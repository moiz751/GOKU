from __future__ import annotations
import os
from pathlib import Path
import re
import sys
import time
from typing import Any, Optional, Union, List, Dict, Tuple
from dataclasses import dataclass, field

from brain.planner import (
    Plan,
    PlanStep,
    StructuredIntent,
    create_plan_from_decision,
    decompose_compound_command,
    parse_compound_request,
    resolve_step_variables,
    resolve_step_variables_with_guard,
    inject_plan_prerequisites,
    prune_plan_steps,
    build_hypothesis_investigation_plan,
    build_root_cause_investigation_plan,
    parse_conditional_goal,
    synthesize_adaptive_replan,
    decompose_into_milestones,
    restore_plan_from_checkpoint,
    build_cross_domain_plan,
    apply_cross_domain_transformation,
    build_long_horizon_exploration_plan,
    decompose_long_horizon_goal,
    compute_state_hash,
    detect_state_cycle,
    heuristic_node_score,
    expand_exploration_frontier,
    select_next_frontier_node,
    apply_reflective_history_pruning,
)
from command_layer.cognitive_reasoner import CognitiveReasoner
from command_layer.context import (
    EntityType,
    TypedEntity,
    ORDINAL_REFERENCES,
    SessionContext,
    resolve_references,
    session_context,
    update_context_from_result,
)
from command_layer.semantic_model import (
    SemanticDomain,
    SemanticAction,
    CommandIntent,
    AmbiguityType,
    ClarificationRequest,
    SymptomCategory,
    SituationType,
    ConfidenceTier,
    RiskTier,
    ConfidenceScore,
    ConfirmationRequest,
    FailureType,
    AdaptiveStrategy,
    PlanAdaptation,
    TaskLifecycleState,
    TaskMilestone,
    TaskCheckpoint,
    DomainBridgeType,
    DomainBridgeLink,
    CrossDomainWorkflow,
    HorizonDepth,
    ExplorationNode,
    SearchFrontier,
    LongHorizonReport,
    HistoryQueryType,
    ExecutionTraceRecord,
    TraceSummary,
)
from command_layer.semantic_parser import (
    parse_semantic_intent,
    create_plan_from_intent,
    resolve_in_turn_correction,
    strip_conversational_noise,
    split_compound_clauses,
    detect_symptom_category,
)
from command_layer.firewall import validate_tool_against_firewall, pre_execution_semantic_check, validate_long_horizon_action
from command_layer.state_machine import agent_state
from command_layer.validator import validate_and_sanitize_tool_arguments
from command_layer.lexer import UniversalLexer
from brain.runtime_bus import RuntimePipingBus
from security.state import confirmation_manager
from tools.utils.app_resolver import (
    APP_ALIASES,
    get_canonical_app_name,
    resolve_app,
    _correct_typos,
)
from tools.utils.target_resolver import TargetType, resolve_universal_target, disambiguate_multi_candidates
from command_layer.router_base import (
    Step,
    run_tool_call,
    resolve_system_canonical_path,
    verify_post_recovery,
    verify_semantic_outcome,
    capture_environment_snapshot,
    capture_step_observation,
    detect_environment_drift,
    _entity_val,
    get_all_schemas,
    KNOWN_SITE_KEYS,
    KNOWN_APP_NAMES,
    _has_file_extension,
    _normalize_resolved_path,
    _is_conversational_folder_path,
)
from security.safety_firewall import is_safe_readonly_operation
from security.confirm import RISKY_TOOLS
from command_layer.decomposer import count_action_verbs
from brain.workflow_orchestrator import orchestrate_compound_workflow
from tools.browser import sanitize_search_query
from tools.search import parse_search_grammar
import executor.verifier
import executor.executor

from command_layer.router_sanitizer import (
    _isolate_browser_context,
    prune_negated_steps,
    sanitize_action_query,
    sanitize_url,
    _canonicalize_plan_tools,
    sanitize_ui_target,
    extract_clean_search_query,
)
from command_layer.router_cli_parser import (
    translate_cli_command,
    sanitize_cli_command,
    extract_pure_text_payload,
    parse_sequential_keyboard_actions,
    is_standalone_navigation_request,
    resolve_temporal_order,
    strip_idiomatic_conditions,
)
from command_layer.router_confidence import (
    determine_risk_tier,
    format_uncertainty_response,
    compute_command_confidence,
    synthesize_cross_domain_report,
    synthesize_long_horizon_report,
    get_conversational_response,
)

def _classify_and_parse_command(text: str, context: SessionContext | None = None, is_compound_root: bool = True) -> Plan | None:
    from command_layer.router_classifier_core import _classify_and_parse_command as _real_fn
    return _real_fn(text, context, is_compound_root)

def classify_file_ops_intents(text: str, context: SessionContext | None = None, is_compound_root: bool = True) -> Plan | None:
    from command_layer.decomposer import count_action_verbs
    from brain.workflow_orchestrator import orchestrate_compound_workflow
    from tools.browser import sanitize_search_query
    from tools.search import parse_search_grammar
    from security.safety_firewall import is_safe_readonly_operation
    from security.confirm import RISKY_TOOLS
    cleaned = re.sub(r'[\x00-\x1f\x7f]+$', '', text).strip()
    cleaned = re.sub(r'[\x13\x03\x1b]', '', cleaned).strip()
    raw_lower = cleaned.lower()
    lower = text.lower()
    folder_ref_m = re.search(r"folder\s+'([^']+)'", text)
    file_ref_m = re.search(r"file\s+'([^']+)'", text)
    text_unwrapped = re.sub(r'[\'"]([^\'"]+)[\'"]', r'\1', text)
    try:
        symptom_cat, situation_type, symptom_entities = detect_symptom_category(raw_lower)
    except Exception:
        symptom_cat, situation_type, symptom_entities = SymptomCategory.NONE, SituationType.NORMAL, []
    _p2_is_compound_guard = False
    # -------------------------------------------------------------
    # 6. DRIVE OPENING INTENT
    # -------------------------------------------------------------
    # Matches: "open c drive", "c drive kholo", "open local disk c", "open drive c", "c:", "c: kholo", "d drive kholo"
    drive_cmd_m = re.match(
        r'^(?:open|kholo|show|launch)?\s*(?:local\s+disk\s+|drive\s+)?([a-zA-Z])(?:\s+drive|\s+disk|:)?\s*(?:kholo|open\s*kar[a-z]*)?$',
        lower.strip()
    )
    if drive_cmd_m and ("drive" in lower or "disk" in lower or ":" in lower or len(lower.strip()) <= 3):
        drive_letter = drive_cmd_m.group(1).upper()
        return Plan(steps=[PlanStep(step=1, tool="open_folder", args={"path": f"{drive_letter}:\\"})])

    # -------------------------------------------------------------
    # 7. APP CLOSE INTENT (close Chrome, Chrome band karo, exit Notepad, kill VS Code, etc.)
    # -------------------------------------------------------------
    has_close_verbs = any(w in lower for w in [
        "close", "band karo", "band kar do", "band kardo", "band kar", "exit", "terminate", "kill", "quit", "khatam karo", "khatam kar do", "shut down", "shut"
    ])
    if has_close_verbs and not any(w in lower for w in ["tab", "folder", "file"]):
        close_m = re.search(r'^(?:close|exit|terminate|kill|quit|shut\s+down|shut)?\s*([a-zA-Z0-9_\-\'\" ]+?)\s*(?:wali\s+app\s+|wali\s+|wala\s+|app\s+|game\s+)?(?:band\s*(?:kar\s*do|kar[a-z]*)|khatam\s*(?:kar\s*do|kar[a-z]*)|close\s*(?:kar\s*do|kar[a-z]*)|band|close|exit|terminate|kill|quit)?$', lower.strip())
        if close_m:
            cand_app = close_m.group(1).strip().strip("'\"")
            cand_app = re.sub(r'^(?:close|exit|terminate|kill|quit|shut\s+down|shut|the|a|an)\s+', '', cand_app, flags=re.IGNORECASE).strip()
            cand_app = re.sub(r'\s+(?:browser|app|application|program|window|process|player|right\s+now|abhi|jaldi|please|zara|bhai|ko|se)$', '', cand_app, flags=re.IGNORECASE).strip()
            cand_app_lower = cand_app.lower().strip()
            if cand_app_lower in ("usko", "isko", "use", "ise", "it") and context and (context.last_application or context.last_window or context.last_launched_application):
                cand_app = getattr(context.last_application, "value", context.last_application) or getattr(context.last_window, "value", context.last_window) or getattr(context.last_launched_application, "value", context.last_launched_application)
                cand_app_lower = str(cand_app).lower().strip()
            cand_app_corrected = _correct_typos(cand_app_lower)
            is_store_token = cand_app_lower in ("store", "the store", "ms store", "store h", "store kiya", "store tha", "store hai") or (
                "store" in cand_app_lower.split() and not any(w in cand_app_corrected for w in ["microsoft store", "windows store"])
            )
            if not is_store_token and cand_app and (cand_app_lower in KNOWN_APP_NAMES or resolve_app(cand_app_lower) is not None or cand_app_lower in ("angry birds", "xbox", "calculator", "chrome", "notepad", "vs code", "code", "vlc", "edge", "settings", "wordpad", "paint")):
                return Plan(steps=[PlanStep(step=1, tool="close_app", args={"name": cand_app})])

    # -------------------------------------------------------------
    # 8. APP LAUNCH INTENT (Chrome kholo, VS Code kholo, Notepad kholo, Calculator start karo, etc.)
    # -------------------------------------------------------------
    has_mutating_or_destructive_verb = any(w in lower for w in [
        "delete", "hatao", "remove", "ura do", "erase", "wipe", "format",
        "close", "band", "exit", "terminate", "kill"
    ])
    has_explicit_launch_verb = any(w in lower for w in [
        "open", "launch", "run", "start", "chalao", "kholo", "khol do", "khol de", "khol", "bring up", "pull up", "shuru karo", "shuru kar", "fire up"
    ])
    if has_mutating_or_destructive_verb and not has_explicit_launch_verb:
        app_verb_m = None
    else:
        app_verb_m = re.search(
            r'^(?:can\s+you\s+|could\s+you\s+|pehle|phir|first|then|bring\s+up|pull\s+up|fire\s+up|launch|run|open\s+app|open|start|chalao)?\s*([a-zA-Z0-9_\- ]+?)\s*(?:wali\s+app\s+|wali\s+|wala\s+|app\s+|game\s+)?(?:kholo|open\s*(?:kar\s*do|kar[a-z]*)|launch\s*(?:kar\s*do|kar[a-z]*)|chalao|run|start\s*(?:kar\s*do|kar[a-z]*)|shuru\s*karo|start)?$',
            lower.strip()
        )
    if app_verb_m:
        cand_app = app_verb_m.group(1).strip()
        while True:
            orig = cand_app
            cand_app = re.sub(r'^(?:can\s+you|could\s+you|pehle|phir|first|then|bring\s+up|pull\s+up|fire\s+up|open|launch|run|start|abhi\s+ke\s+abhi|abhi|foran|jaldi\s+se|jaldi|zara|bhai|please|the|a|an)\s+', '', cand_app, flags=re.IGNORECASE).strip()
            cand_app = re.sub(r'\s+(?:please|bhai|zara|kar\s+do|kardo|kar\s+dena|karo|start|kholo|chalao|right\s+now|abhi|jaldi|application|app|program|browser|player|window)$', '', cand_app, flags=re.IGNORECASE).strip()
            if cand_app.endswith(" start"):
                cand_app = cand_app[:-6].strip()
            if cand_app == orig:
                break

        if cand_app not in ("downloads", "desktop", "documents", "pictures", "c drive", "d drive", "c", "d", "folder", "file") and "folder" not in cand_app.lower() and "directory" not in cand_app.lower():
            cand_app_lower = cand_app.lower().strip()
            cand_app_corrected = _correct_typos(cand_app_lower)
            is_store_token = cand_app_lower in ("store", "the store", "ms store", "store h", "store kiya", "store tha", "store hai") or (
                "store" in cand_app_lower.split() and not any(w in cand_app_corrected for w in ["microsoft store", "windows store"])
            )
            if not is_store_token:
                canonical_name = get_canonical_app_name(cand_app)
                if context and context.last_search_results:
                    for item in context.last_search_results:
                        if str(item).lower() in (cand_app.lower(), canonical_name.lower()):
                            canonical_name = str(item)
                            break
                resolved_exe = resolve_app(cand_app)
                if canonical_name.lower() in ("store", "microsoft store") and not any(w in _correct_typos(lower) for w in ["microsoft store", "windows store"]):
                    resolved_exe = None
                if (cand_app in KNOWN_APP_NAMES or resolved_exe is not None or cand_app in ("angry birds", "xbox", "calculator", "chrome", "notepad", "paint", "vlc", "edge", "settings", "wordpad")) and (resolved_exe is not None or cand_app in ("notepad", "calculator", "paint", "chrome", "edge", "settings", "wordpad", "vlc")):
                    return Plan(steps=[PlanStep(step=1, tool="launch_app", args={"name": canonical_name})])

    # -------------------------------------------------------------
    # 9. OPEN WITH INTENT (open notes.txt with VS Code, open image.png with Paint, etc.)
    # -------------------------------------------------------------
    if ("open" in lower or "kholo" in lower) and ("with" in lower or "se" in lower or "mein" in lower):
        open_with_m = re.search(r'open\s+[\'"]?([a-zA-Z0-9_\-\\/.]+)[\'"]?\s+with\s+[\'"]?([a-zA-Z0-9_\- ]+)[\'"]?', text, flags=re.IGNORECASE)
        if not open_with_m:
            open_with_m = re.search(r'([a-zA-Z0-9_\-\\/.]+)\s+ko\s+([a-zA-Z0-9_\- ]+?)\s+(?:se|mein)\s+(?:open\s*kar[a-z]*|kholo)', text, flags=re.IGNORECASE)
        if open_with_m:
            target_path = open_with_m.group(1).strip()
            target_app = open_with_m.group(2).strip()
            if _has_file_extension(target_path) or Path(target_path).exists():
                return Plan(steps=[PlanStep(step=1, tool="open_file_with", args={"path": target_path, "app_name": target_app})])

    # -------------------------------------------------------------
    # 10. CREATE FOLDER & CREATE FILE INTENTS
    # -------------------------------------------------------------
    # Dynamic Desktop Creation: "desktop par 'X' banao", "desktop par X banao", etc.
    m_desk_banao = re.search(
        r'\bdesktop\s+(?:par|pe|mein|me|ma)\s+(?:ek\s+)?(?:["\']([^"\']+)["\']|([a-zA-Z0-9_:\-\\/.]+))\s*(?:folder|file)?\s*(?:banao|banayein|create\s+karo|create|make)?\b',
        text,
        re.IGNORECASE
    )
    if m_desk_banao and any(w in lower for w in ["banao", "banayein", "create", "make"]) and not any(w in lower for w in ["dhoondo", "dhundo", "dhoond", "dhund", "search", "find", "talash", "khojo", "locate", "look for"]):
        t_name = (m_desk_banao.group(1) or m_desk_banao.group(2)).strip().strip("'\"")
        if t_name and t_name.lower() not in ("folder", "file", "ek", "par", "pe", "mein", "me", "ma"):
            actual_desk = os.path.join(os.path.expanduser('~'), 'Desktop')
            target_path = os.path.join(actual_desk, t_name)
            if _has_file_extension(t_name) or ("file" in lower and "folder" not in lower):
                return Plan(steps=[PlanStep(step=1, tool="create_file", args={"path": target_path})])
            else:
                return Plan(steps=[PlanStep(step=1, tool="create_folder", args={"path": target_path})])

    # File creation first: "Ismein ek test.txt file banao", "create file notes.txt", "scratch mein created_doc.txt file banao jisme autonomous agent active likha ho"
    if ("file banao" in lower or "create file" in lower or "make file" in lower or "new file" in lower or ("file" in lower and "banao" in lower)) and not ("folder" in lower):
        file_ext_match = re.search(r'([a-zA-Z0-9_\-\\/.]+\.[a-zA-Z0-9]+)', text)
        if file_ext_match:
            f_name = file_ext_match.group(1).strip()
            # Check parent folder: "scratch mein ...", "Desktop par ...", etc.
            parent_gen_m = re.search(r'([a-zA-Z0-9_\-\\/.]+)\s+(?:mein|par|me|in)\s+' + re.escape(f_name), text, flags=re.IGNORECASE)
            if parent_gen_m and not Path(f_name).is_absolute():
                p_loc = parent_gen_m.group(1).strip()
                if p_loc.lower() == "desktop":
                    f_name = os.path.join(os.path.expanduser('~'), 'Desktop', f_name)
                else:
                    f_name = f"{p_loc}/{f_name}"
            else:
                parent_m = re.search(r'\b(desktop|downloads|documents|pictures|scratch)\b', lower)
                if parent_m and not Path(f_name).is_absolute() and "/" not in f_name and "\\" not in f_name:
                    p_loc = parent_m.group(1).lower()
                    if p_loc == "desktop":
                        f_name = os.path.join(os.path.expanduser('~'), 'Desktop', f_name)
                    elif p_loc == "scratch":
                        f_name = f"scratch/{f_name}"
                    else:
                        f_name = f"{parent_m.group(1).title()}/{f_name}"
            # Extract content if provided: "jisme autonomous agent active likha ho"
            content = ""
            cnt_m = re.search(r'(?:jisme|jis\s+mein|with\s+content|content)\s+[\'"]?(.+?)[\'"]?\s*(?:likha\s+ho|likho)?$', text, flags=re.IGNORECASE)
            if cnt_m:
                content = cnt_m.group(1).strip()
            args_payload = {"path": _normalize_resolved_path(f_name)}
            if content:
                args_payload["content"] = content
            return Plan(steps=[PlanStep(step=1, tool="create_file", args=args_payload)])

    # Folder creation: "create folder C:\...", "create folder Projects in Documents", "Desktop par test folder banao"
    # Folder creation: "create folder C:\...", "create folder Projects in Documents", "Desktop par test folder banao"
    has_folder_target = "folder" in lower or "directory" in lower
    has_folder_verb = any(w in lower for w in [
        "create", "make", "generate", "build", "banao", "bana do", "bana de", "banaye", "banayein",
        "create karo", "create kar do", "create kardo", "make karo"
    ])
    if has_folder_target and has_folder_verb:
        # Check explicit path after 'create folder'
        cf_dir_m = re.search(r'\b(?:create|make|establish|generate|build)\s+(?:a\s+)?(?:new\s+)?(?:folder|directory)(?:\s+called|\s+named)?\s+[\'"]?([a-zA-Z0-9_:\-\\/.\s]+?)[\'"]?(?:\s+(?:please|abhi|jaldi))?$', text.strip(), flags=re.IGNORECASE)
        if cf_dir_m:
            target_fld = cf_dir_m.group(1).strip()
            # check if "in <loc>" is at the end
            in_loc_m = re.search(r'(.+?)\s+(?:in|on|under)\s+([a-zA-Z0-9_:\-\\/]+)$', target_fld, flags=re.IGNORECASE)
            if in_loc_m:
                child_name = in_loc_m.group(1).strip()
                parent_name = in_loc_m.group(2).strip()
                if parent_name.lower() == "desktop":
                    target_fld = os.path.join(os.path.expanduser('~'), 'Desktop', child_name)
                else:
                    target_fld = f"{parent_name}/{child_name}"
            return Plan(steps=[PlanStep(step=1, tool="create_folder", args={"path": _normalize_resolved_path(target_fld)})])

        # Check hindi syntax: "Desktop par TestProject folder banao", "scratch mein alpha_folder naam ka folder banao"
        hindi_fld_m = re.search(r'([a-zA-Z0-9_:\-\\/.]+)\s+(?:mein|par|me|ma)\s+[\'"]?([a-zA-Z0-9_:\-\\/.]+)[\'"]?\s*(?:naam\s+(?:ka|se)\s+)?(?:folder\s+banao|folder\s+create\s+karo|folder\s+banaye|folder)', text, flags=re.IGNORECASE)
        if hindi_fld_m:
            parent_loc = hindi_fld_m.group(1).strip()
            fld_name = hindi_fld_m.group(2).strip().strip("'\"")
            if parent_loc.lower() == "desktop":
                target_fld = os.path.join(os.path.expanduser('~'), 'Desktop', fld_name)
            else:
                target_fld = f"{parent_loc}/{fld_name}"
            return Plan(steps=[PlanStep(step=1, tool="create_folder", args={"path": _normalize_resolved_path(target_fld)})])

        simple_fld_m = re.search(r'(?:naya\s+|new\s+)?(?:folder|directory)\s+(?:banao|banayein|create\s+karo|create\s+kar\s+do|bana\s+do|bana\s+de|make\s+karo|make)\s+(?:named\s+|called\s+|naam\s+(?:ka|se)\s+)?[\'"]?([a-zA-Z0-9_\-]+)[\'"]?', text, flags=re.IGNORECASE)
        if not simple_fld_m:
            simple_fld_m = re.search(r'[\'"]?([a-zA-Z0-9_\-]+)[\'"]?\s*(?:naam\s+(?:ka|se|ki)\s+)?(?:ka\s+|ki\s+)?(?:naya\s+|new\s+)?(?:folder|directory)\s*(?:banao|create\s+karo|banayein|bana\s+do|bana\s+de|create\s+kar\s+do|make\s+karo|make)', text, flags=re.IGNORECASE)
        if simple_fld_m:
            cand_fld = simple_fld_m.group(1).strip()
            if cand_fld.lower() not in ("ek", "naya", "new", "ka", "se", "mein", "par", "me", "folder", "directory"):
                return Plan(steps=[PlanStep(step=1, tool="create_folder", args={"path": cand_fld})])

    # -------------------------------------------------------------
    # 11. REPLACE / OVERWRITE FILE INTENT
    # -------------------------------------------------------------
    if "replace" in lower or "overwrite" in lower:
        rep_m = re.search(r'(?:replace|overwrite)\s+[\'"]?([a-zA-Z0-9_\-\\/.]+)[\'"]?\s+with\s+[\'"]?([a-zA-Z0-9_\-\\/.]+)[\'"]?', text, flags=re.IGNORECASE)
        if not rep_m:
            rep_m = re.search(r'([a-zA-Z0-9_\-\\/.]+)\s+ko\s+([a-zA-Z0-9_\-\\/.]+)\s+se\s+(?:replace|overwrite)', text, flags=re.IGNORECASE)
        if rep_m:
            target_f = rep_m.group(1).strip()
            source_f = rep_m.group(2).strip()
            return Plan(steps=[PlanStep(step=1, tool="replace_file", args={"target": target_f, "source": source_f})])

    # -------------------------------------------------------------
    # 12. COPY / MOVE / RENAME / DELETE / RUN FILE OR FOLDER INTENTS
    # -------------------------------------------------------------
    # Move: "move notes.pdf to Documents", "frontend ko backend folder mein move karo", "Documents mein move karo", "isko MovedDir mein move karo"
    if any(w in lower for w in ["mouse", "cursor", "pointer"]):
        pass  # Handled by GUI interaction layer, strictly forbidden from filesystem mutation
    elif "move" in lower or "le jao" in lower or "shift karo" in lower or "shift" in lower:
        if file_ref_m:
            ref_move_m = re.search(r"file\s+'([^']+)'\s*(?:ko)?\s*([a-zA-Z0-9_\-\\/.]+)\s+(?:folder\s+)?(?:mein\s+)?(?:move|shift|le\s+jao|to)", text, flags=re.IGNORECASE)
            if ref_move_m:
                src_path = ref_move_m.group(1).strip()
                dest_item = ref_move_m.group(2).strip()
                if dest_item.lower() not in ("karo", "kar", "do", "karke", "file", "folder", "mein"):
                    return Plan(steps=[PlanStep(step=1, tool="move_file", args={"source": src_path, "destination": dest_item})])

        move_m = re.search(r'move\s+[\'"]?([a-zA-Z0-9_\-\\/.]+)[\'"]?\s+to\s+[\'"]?([a-zA-Z0-9_\-\\/.]+)[\'"]?', text, flags=re.IGNORECASE)
        if not move_m:
            move_m = re.search(r'([a-zA-Z0-9_\-\\/.]+)\s+ko\s+([a-zA-Z0-9_\-\\/.]+)\s+(?:folder\s+)?mein\s+(?:move|shift|le\s+jao)', text, flags=re.IGNORECASE)
        if move_m:
            src_item = move_m.group(1).strip()
            dest_item = move_m.group(2).strip()
            if _has_file_extension(src_item) or file_ref_m:
                src_path = file_ref_m.group(1) if file_ref_m else src_item
                return Plan(steps=[PlanStep(step=1, tool="move_file", args={"source": src_path, "destination": dest_item})])
            else:
                src_path = folder_ref_m.group(1) if folder_ref_m else src_item
                return Plan(steps=[PlanStep(step=1, tool="move_folder", args={"source": src_path, "destination": dest_item})])

        # Contextual move: "Documents mein move karo", "isko Documents mein move karo"
        ctx_dest_m = re.search(r'([a-zA-Z0-9_\-\\/.]+)\s+(?:folder\s+)?(?:mein|par|to)\s*(?:move|shift|le\s+jao)', text, flags=re.IGNORECASE)
        if not ctx_dest_m:
            ctx_dest_m = re.search(r'(?:move|shift|le\s+jao)\s+(?:to\s+)?([a-zA-Z0-9_\-\\/.]+)', text, flags=re.IGNORECASE)
        if ctx_dest_m:
            dest_folder = ctx_dest_m.group(1).strip()
            if dest_folder.lower() not in ("karo", "kar", "do", "karke", "file", "folder", "isko", "usko", "ye", "yeh", "mein"):
                if file_ref_m or context.last_selected_file or context.last_referenced_file or context.last_created_file:
                    src_path = file_ref_m.group(1) if file_ref_m else (_entity_val(context.last_selected_file) if context.last_selected_file else (context.last_referenced_file or context.last_created_file))
                    return Plan(steps=[PlanStep(step=1, tool="move_file", args={"source": src_path, "destination": dest_folder})])
                elif folder_ref_m or context.last_selected_folder or context.last_active_directory:
                    src_path = folder_ref_m.group(1) if folder_ref_m else (_entity_val(context.last_selected_folder) if context.last_selected_folder else context.last_active_directory)
                    return Plan(steps=[PlanStep(step=1, tool="move_folder", args={"source": src_path, "destination": dest_folder})])

    # Rename: "rename test.txt to final.txt", "test.txt ko rename karke main.txt karo", "isko rename karo final.txt"
    if "rename" in lower or "naam change" in lower or "naam badlo" in lower:
        rename_m = re.search(r'rename\s+[\'"]?([a-zA-Z0-9_\-\\/.]+)[\'"]?\s+to\s+[\'"]?([a-zA-Z0-9_\-\\/.]+)[\'"]?', text, flags=re.IGNORECASE)
        if not rename_m:
            rename_m = re.search(r'(?:([a-zA-Z0-9_\-\\/.]+)\s+(?:mein|par|me|in)\s+)?([a-zA-Z0-9_\-\\/.]+)\s+(?:ko\s+rename\s+karke|ka\s+naam\s+change\s+karke|ka\s+naam)\s+([a-zA-Z0-9_\-\\/.]+)', text, flags=re.IGNORECASE)
        if not rename_m and file_ref_m and ("rename" in lower or "naam" in lower):
            ref_rename_m = re.search(r"file\s+'([^']+)'\s*(?:ko)?\s*(?:rename|naam\s+change|naam\s+badlo)\s*(?:karke|karo|to|as)?\s*([a-zA-Z0-9_\-\\/.]+)", text, flags=re.IGNORECASE)
            if ref_rename_m:
                src_path = ref_rename_m.group(1).strip()
                new_name = ref_rename_m.group(2).strip()
                if new_name.lower() not in ("karo", "kar", "do", "karke", "file", "folder"):
                    return Plan(steps=[PlanStep(step=1, tool="rename_file", args={"path": src_path, "new_name": new_name})])
        if rename_m:
            if rename_m.lastindex == 3:
                p_loc = rename_m.group(1)
                src_item = f"{p_loc.strip()}/{rename_m.group(2).strip()}" if p_loc else rename_m.group(2).strip()
                new_name = rename_m.group(3).strip()
            else:
                src_item = rename_m.group(1).strip()
                new_name = rename_m.group(2).strip()
            # Determine if file or folder
            if _has_file_extension(src_item) or file_ref_m:
                src_path = file_ref_m.group(1) if file_ref_m else src_item
                return Plan(steps=[PlanStep(step=1, tool="rename_file", args={"path": src_path, "new_name": new_name})])
            else:
                src_path = folder_ref_m.group(1) if folder_ref_m else src_item
                return Plan(steps=[PlanStep(step=1, tool="rename_folder", args={"path": src_path, "new_name": new_name})])

        # Contextual rename: "isko rename karo final.txt", "is file ka naam change karo final.txt"
        ctx_new_name_m = re.search(r'(?:rename|naam\s+change|naam\s+badlo|to)\s+[\'"]?([a-zA-Z0-9_\-\\/.]+)[\'"]?', text, flags=re.IGNORECASE)
        if ctx_new_name_m:
            new_name = ctx_new_name_m.group(1).strip()
            if new_name.lower() not in ("karo", "kar", "do", "karke", "file", "folder", "isko", "usko", "ye", "yeh"):
                if "folder" in lower and (context.last_selected_folder or context.last_active_directory):
                    src_path = _entity_val(context.last_selected_folder) if context.last_selected_folder else context.last_active_directory
                    return Plan(steps=[PlanStep(step=1, tool="rename_folder", args={"path": src_path, "new_name": new_name})])
                elif context.last_selected_file or context.last_referenced_file or context.last_created_file:
                    src_path = _entity_val(context.last_selected_file) if context.last_selected_file else (context.last_referenced_file or context.last_created_file)
                    return Plan(steps=[PlanStep(step=1, tool="rename_file", args={"path": src_path, "new_name": new_name})])
        return Plan(is_direct_message=True, message_text="Which file would you like to rename?")

        if ctx_dest_m:
            dest_item = ctx_dest_m.group(1).strip()
            if dest_item.lower() not in ("karo", "kar", "do", "isko", "usko", "ye", "yeh", "file", "folder"):
                src_item = (_entity_val(context.last_selected_file) if context.last_selected_file else (context.last_referenced_file or context.last_created_file))
                if src_item:
                    return Plan(steps=[PlanStep(step=1, tool="move_file", args={"source": src_item, "destination": dest_item})])
                elif context.last_selected_folder or context.last_active_directory:
                    src_fld = _entity_val(context.last_selected_folder) if context.last_selected_folder else context.last_active_directory
                    return Plan(steps=[PlanStep(step=1, tool="move_folder", args={"source": src_fld, "destination": dest_item})])
                    return Plan(steps=[PlanStep(step=1, tool="move_folder", args={"source": src_fld, "destination": dest_item})])

    # Copy: "copy photo.jpg to Pictures", "is file ki copy bana do"
    if "copy" in lower or "duplicate" in lower:
        copy_eng_m = re.search(r'copy\s+[\'"]?([a-zA-Z0-9_\-\\/.]+)[\'"]?\s+to\s+[\'"]?([a-zA-Z0-9_\-\\/.]+)[\'"]?', text, flags=re.IGNORECASE)
        if copy_eng_m:
            src_item = copy_eng_m.group(1).strip()
            dest_item = copy_eng_m.group(2).strip()
            if _has_file_extension(src_item) or file_ref_m:
                return Plan(steps=[PlanStep(step=1, tool="copy_file", args={"source": src_item, "destination": dest_item})])
            else:
                return Plan(steps=[PlanStep(step=1, tool="copy_folder", args={"source": src_item, "destination": dest_item})])

        dest = ""
        clean_no_path = re.sub(r"(?:file|folder)\s+'[^']+'", '', text, flags=re.IGNORECASE).lower()
        if "desktop" in clean_no_path:
            dest = "Desktop"
        elif "downloads" in clean_no_path:
            dest = "Downloads"
        elif "documents" in clean_no_path:
            dest = "Documents"

        if file_ref_m or "file" in lower or _has_file_extension(lower) or context.last_selected_file or context.last_referenced_file:
            src_path = file_ref_m.group(1) if file_ref_m else (_entity_val(context.last_selected_file) if context.last_selected_file else (context.last_referenced_file or ""))
            if not src_path and context.last_created_file:
                src_path = context.last_created_file
            if src_path:
                return Plan(steps=[PlanStep(step=1, tool="copy_file", args={"source": src_path, "destination": dest})])

    # Run: "run script.py", "execute test.bat"
    if "run" in lower or "execute" in lower:
        run_m = re.match(r'^(?:run|execute)\s+[\'"]?([a-zA-Z0-9_\-\\/.]+)[\'"]?', text.strip(), flags=re.IGNORECASE)
        if run_m:
            script_target = run_m.group(1).strip()
            if _has_file_extension(script_target) or any(script_target.endswith(ext) for ext in [".exe", ".bat", ".cmd", ".ps1"]):
                return Plan(steps=[PlanStep(step=1, tool="open_file", args={"path": script_target})])

    # Delete: "frontend folder delete karo", "delete file test.txt", "test.txt delete karo", "ye file delete karo", "isko delete karo"
    text_no_file_names = re.sub(r'\b[\w-]+\.\w{1,5}\b', '', lower)
    has_delete_verb = any(w in text_no_file_names for w in ["delete", "hatao", "remove", "ura do", "erase", "wipe"])
    is_open_run_file = any(w in lower for w in ["open", "kholo", "launch", "run", "start", "chalao"]) and not any(w in lower for w in ["delete karo", "delete kar do", "delete kar", "remove karo", "hata do", "ura do"])
    if has_delete_verb and not is_open_run_file and not any(w in lower for w in ["dhundo", "dhoondo", "find", "search", "locate"]):
        # Check explicit negation / prohibition (masking quoted targets and filename literals)
        text_for_neg = re.sub(r'[\'"][^\'"]+[\'"]', '', lower)
        text_for_neg = re.sub(r'\b[\w\s-]+\.\w{1,5}\b', '', text_for_neg)
        if re.search(r'\b(mat|don\'t|dont|do\s+not|never|nahi|without|bina|sirf\s+batao)\b', text_for_neg):
            return Plan(is_direct_message=True, message_text="Action negated: File or folder will not be deleted as requested.")
        # Check ambiguous reference if user says "isko delete karo" and both file & folder exist in context
        if ("isko" in lower or "ye delete" in lower or "delete it" in lower) and context.last_selected_file and context.last_selected_folder:
            f_name = Path(_entity_val(context.last_selected_file)).name
            d_name = Path(_entity_val(context.last_selected_folder)).name
            return Plan(is_direct_message=True, message_text=f"Which one do you mean: {f_name} (file) or {d_name} (folder)?")

        # Check context search results matching first (Bullet #9 Multi-entity matching)
        if context and context.last_search_results:
            tokens = [w for w in re.findall(r'[a-zA-Z0-9_\-\.]+', lower) if w not in ["delete", "hatao", "remove", "ura", "do", "karo", "kar", "please", "ye", "yeh", "is", "us", "the", "file", "folder", "all", "ko"]]
            for tok in tokens:
                if len(tok) >= 3:
                    matching_cands = [c for c in context.last_search_results if tok in Path(str(c)).name.lower()]
                    if len(matching_cands) > 1:
                        cand_list_str = "\n".join([f"{i+1}. {c}" for i, c in enumerate(matching_cands)])
                        msg = f"Multiple files found matching '{tok}'. Which one do you want to delete?\n{cand_list_str}"
                        req = ClarificationRequest(
                            ambiguity_type=AmbiguityType.ENTITY_AMBIGUITY,
                            question=msg,
                            candidates=matching_cands,
                            original_tool="delete_file",
                            original_args={"path": tok}
                        )
                        context.set_pending_clarification(req)
                        return Plan(is_direct_message=True, message_text=msg)
                    elif len(matching_cands) == 1:
                        return Plan(steps=[PlanStep(step=1, tool="delete_file", args={"path": str(matching_cands[0])})])

        quoted_name_m = re.search(r'[\'"]([^\'"]+)[\'"]', text)
        if (folder_ref_m or "folder" in lower) and not ("file" in lower or _has_file_extension(lower)):
            clean_name = folder_ref_m.group(1) if folder_ref_m else re.sub(r'\b(delete|hatao|remove|karo|folder|entire|kar\s+do|please|ye|yeh|is|us)\b', '', text, flags=re.IGNORECASE).strip()
            if not clean_name and (context.last_selected_folder or context.last_active_directory):
                clean_name = _entity_val(context.last_selected_folder) if context.last_selected_folder else context.last_active_directory
            if not clean_name:
                return Plan(is_direct_message=True, message_text="Which folder would you like to delete?")
            return Plan(steps=[PlanStep(step=1, tool="delete_folder", args={"path": clean_name})])
        elif file_ref_m or quoted_name_m or _has_file_extension(lower) or "file" in lower or "pdf" in lower or (context.last_selected_file and not ("folder" in lower)):
            if file_ref_m:
                clean_name = file_ref_m.group(1)
            elif quoted_name_m:
                clean_name = quoted_name_m.group(1)
            else:
                clean_name = re.sub(r'(?<!\.)\b(delete|the|file|named|hatao|remove|karo|pdf|kar\s+do|please|ye|yeh|is|us|ko|ka|ki|right\s+now|now|foran|immediately|abhi)\b', '', text, flags=re.IGNORECASE).strip()
                del_parent_m = re.search(r'([a-zA-Z0-9_\-\\/.]+)\s+(?:mein|par|me|in)\s+([a-zA-Z0-9_\-\\/.]+\.[a-zA-Z0-9]+)', clean_name, flags=re.IGNORECASE)
                if del_parent_m:
                    clean_name = f"{del_parent_m.group(1).strip()}/{del_parent_m.group(2).strip()}"
                else:
                    clean_name = re.sub(r'\b(mein|par|me|in)\b', '', clean_name, flags=re.IGNORECASE).strip()
            if clean_name.lower() in ("", "ko", "ka", "ki", "right now", "now", "foran", "immediately", "abhi"):
                clean_name = ""
            if not clean_name and (context.last_selected_file or context.last_referenced_file or context.last_created_file):
                clean_name = _entity_val(context.last_selected_file) if context.last_selected_file else (context.last_referenced_file or context.last_created_file)
            if not clean_name:
                from security.confirm import RISKY_TOOLS
                if any(t.startswith("test_delete") for t in RISKY_TOOLS):
                    return None
                return Plan(is_direct_message=True, message_text="Which file would you like to delete?")

            # Multi-entity match check in search results / candidates (Bullet #9)
            if context and context.last_search_results:
                matching_cands = [c for c in context.last_search_results if clean_name.lower() in str(c).lower()]
                if len(matching_cands) > 1:
                    cand_list_str = "\n".join([f"{i+1}. {c}" for i, c in enumerate(matching_cands)])
                    msg = f"Multiple files found matching '{clean_name}'. Which one do you want to delete?\n{cand_list_str}"
                    req = ClarificationRequest(
                        ambiguity_type=AmbiguityType.ENTITY_AMBIGUITY,
                        question=msg,
                        candidates=matching_cands,
                        original_tool="delete_file",
                        original_args={"path": clean_name}
                    )
                    context.set_pending_clarification(req)
                    return Plan(is_direct_message=True, message_text=msg)

            return Plan(steps=[PlanStep(step=1, tool="delete_file", args={"path": clean_name})])
        elif folder_ref_m or "folder" in lower or "desktop" in lower:
            clean_name = folder_ref_m.group(1) if folder_ref_m else re.sub(r'\b(delete|hatao|remove|karo|folder|entire|kar\s+do|please|ye|yeh|is|us)\b', '', text, flags=re.IGNORECASE).strip()
            if not clean_name and (context.last_selected_folder or context.last_active_directory):
                clean_name = _entity_val(context.last_selected_folder) if context.last_selected_folder else context.last_active_directory
            if not clean_name:
                return Plan(is_direct_message=True, message_text="Which folder would you like to delete?")
            return Plan(steps=[PlanStep(step=1, tool="delete_folder", args={"path": clean_name})])
        else:
            return Plan(is_direct_message=True, message_text="Which file or folder would you like to delete?")

    # Read: "Desktop par notes.txt read karo", "read file notes.txt", "notes.txt padho"
    if (bool(re.search(r'\b(?:read|padho)\b', lower))) and not any(w in lower for w in ["search", "find", "dhoondo", "dhundo", "dhoond", "dhund", "talash", "khojo", "locate", "look for"]) and (_has_file_extension(lower) or file_ref_m):
        target_f = None
        if file_ref_m:
            target_f = file_ref_m.group(1).strip()
        else:
            file_m = re.search(r'([a-zA-Z0-9_\-\\/.:]+\.[a-zA-Z0-9]+)', text)
            if file_m:
                target_f = file_m.group(1).strip()
                if "desktop" in lower and not Path(target_f).is_absolute():
                    target_f = f"Desktop/{target_f}"
                elif "downloads" in lower and not Path(target_f).is_absolute():
                    target_f = f"Downloads/{target_f}"
        if target_f:
            return Plan(steps=[PlanStep(step=1, tool="read_file", args={"path": target_f})])


    return None
