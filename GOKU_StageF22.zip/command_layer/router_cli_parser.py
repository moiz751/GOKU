from __future__ import annotations
import os
from pathlib import Path
import re
import sys
import time
from typing import Any, Optional, Union, List, Dict, Tuple
from dataclasses import dataclass, field

from brain.planner import (
    Plan,
    PlanStep,
    StructuredIntent,
    create_plan_from_decision,
    decompose_compound_command,
    parse_compound_request,
    resolve_step_variables,
    resolve_step_variables_with_guard,
    inject_plan_prerequisites,
    prune_plan_steps,
    build_hypothesis_investigation_plan,
    build_root_cause_investigation_plan,
    parse_conditional_goal,
    synthesize_adaptive_replan,
    decompose_into_milestones,
    restore_plan_from_checkpoint,
    build_cross_domain_plan,
    apply_cross_domain_transformation,
    build_long_horizon_exploration_plan,
    decompose_long_horizon_goal,
    compute_state_hash,
    detect_state_cycle,
    heuristic_node_score,
    expand_exploration_frontier,
    select_next_frontier_node,
    apply_reflective_history_pruning,
)
from command_layer.cognitive_reasoner import CognitiveReasoner
from command_layer.context import (
    EntityType,
    TypedEntity,
    ORDINAL_REFERENCES,
    SessionContext,
    resolve_references,
    session_context,
    update_context_from_result,
)
from command_layer.semantic_model import (
    SemanticDomain,
    SemanticAction,
    CommandIntent,
    AmbiguityType,
    ClarificationRequest,
    SymptomCategory,
    SituationType,
    ConfidenceTier,
    RiskTier,
    ConfidenceScore,
    ConfirmationRequest,
    FailureType,
    AdaptiveStrategy,
    PlanAdaptation,
    TaskLifecycleState,
    TaskMilestone,
    TaskCheckpoint,
    DomainBridgeType,
    DomainBridgeLink,
    CrossDomainWorkflow,
    HorizonDepth,
    ExplorationNode,
    SearchFrontier,
    LongHorizonReport,
    HistoryQueryType,
    ExecutionTraceRecord,
    TraceSummary,
)
from command_layer.semantic_parser import (
    parse_semantic_intent,
    create_plan_from_intent,
    resolve_in_turn_correction,
    strip_conversational_noise,
    split_compound_clauses,
    detect_symptom_category,
)
from command_layer.firewall import validate_tool_against_firewall, pre_execution_semantic_check, validate_long_horizon_action
from command_layer.state_machine import agent_state
from command_layer.validator import validate_and_sanitize_tool_arguments
from command_layer.lexer import UniversalLexer
from brain.runtime_bus import RuntimePipingBus
from security.state import confirmation_manager
from tools.utils.app_resolver import (
    APP_ALIASES,
    get_canonical_app_name,
    resolve_app,
)
from tools.utils.target_resolver import TargetType, resolve_universal_target, disambiguate_multi_candidates
from command_layer.router_base import (
    Step,
    run_tool_call,
    resolve_system_canonical_path,
    verify_post_recovery,
    verify_semantic_outcome,
    capture_environment_snapshot,
    capture_step_observation,
    detect_environment_drift,
    _entity_val,
    get_all_schemas,
    KNOWN_SITE_KEYS,
    KNOWN_APP_NAMES,
    _has_file_extension,
    _normalize_resolved_path,
    _is_conversational_folder_path,
)
from security.safety_firewall import is_safe_readonly_operation
from security.confirm import RISKY_TOOLS
from command_layer.decomposer import count_action_verbs
from brain.workflow_orchestrator import orchestrate_compound_workflow
from tools.browser import sanitize_search_query
from tools.search import parse_search_grammar
import executor.verifier
import executor.executor

def translate_cli_command(raw_cmd: str) -> str | None:
    """
    Rule-based Natural Language to CLI command mapper:
    - "running services count" / "services count" -> powershell -Command "(Get-Service | Where-Object {$_.Status -eq 'Running'}).Count"
    - "hostname aur ipconfig" -> cmd /c "hostname && ipconfig"
    - "whoami aur hostname" -> cmd /c "whoami && hostname"
    - "echo [TEXT]" -> cmd /c "echo [TEXT]"
    """
    if not raw_cmd:
        return None
    c = raw_cmd.strip()
    c_low = c.lower()

    # 1. Services count
    if any(k in c_low for k in ["running services count", "services count", "running services ka count", "services count nikalo", "running services kitni", "service count"]):
        return 'powershell -Command "(Get-Service | Where-Object {$_.Status -eq \'Running\'}).Count"'

    # 2. Hostname + ipconfig
    if re.search(r'\bhostname\b', c_low) and re.search(r'\bipconfig\b', c_low):
        return 'cmd /c "hostname && ipconfig"'

    # 3. Whoami + hostname
    if re.search(r'\bwhoami\b', c_low) and re.search(r'\bhostname\b', c_low):
        return 'cmd /c "whoami && hostname"'

    # 4. Whoami + ipconfig
    if re.search(r'\bwhoami\b', c_low) and re.search(r'\bipconfig\b', c_low):
        return 'cmd /c "whoami && ipconfig"'

    # 5. Echo [TEXT]
    m_echo = re.search(r'^\s*echo\s+(.+)$', c, re.IGNORECASE)
    if m_echo:
        payload = m_echo.group(1).strip().strip("'\"")
        payload = re.sub(r'\s+(?:karo|kar\s*do|chalao)$', '', payload, flags=re.IGNORECASE).strip()
        return f'cmd /c "echo {payload}"'

    return None


def sanitize_cli_command(raw_cmd: str) -> str:
    trans = translate_cli_command(raw_cmd)
    if trans:
        return trans

    cleaned = re.sub(
        r'^(?:(?:pehle\s+|first\s+|zara\s+|please\s+)?(?:cmd|powershell|pwsh|terminal|command\s+prompt|headless)\s*(?:kholo|khol\s*(?:kar|ke)?|open|launch|start|run|chalao|mein|me)?\s*)+',
        '', raw_cmd, flags=re.IGNORECASE
    ).strip()
    cleaned = re.sub(
        r'^(?:se\s+|aur\s+|phir\s+|usme\s+|usmein\s+|mein\s+|me\s+|command\s+do\s+|command\s+|run\s+|execute\s+|please\s+|zara\s+|kholo\s+|chalao\s+|headless\s+|do\s+)+',
        '', cleaned, flags=re.IGNORECASE
    ).strip()
    while True:
        sub = re.sub(
            r'(?:\s+(?:command\s+do|chalao|run\s*karo|execute\s*karo|nikalo|check\s*karo|kardo|kar\s*do|karo|do|headless|please|zara))+$',
            '', cleaned, flags=re.IGNORECASE
        ).strip()
        if sub == cleaned:
            break
        cleaned = sub
    return cleaned


def extract_pure_text_payload(instruction: str) -> str:
    quoted = re.findall(r'["\']([^"\']+)["\']', instruction)
    if quoted:
        return quoted[0].strip()
    fillers = [
        r'^(?:notepad\s+(?:kholo|launch\s+karo)\s+aur\s+usme\s+likho|usme\s+likho|wahan\s+type\s+karo|type\s+karo|likho|type|write)\s*',
        r'^(?:(?:notepad|editor|document|app|file)\s+(?:mein|me|main)\s+)',
        r'^(?:pehle|phir|aur|bhi|next|then|uske\s+baad|iske\s+baad|usme|usmein|wahan)\s*',
        r'^(?:search\s+bar\s+mein\s+likho|search\s+karo)\s*',
        r'\s*(?:likh\s*kar\s*enter\s*karo|type\s*karke\s*enter\s*daba\s*do|enter\s*karo)$',
        r'\s*(?:likho|likh\s*do|likhdo|type\s*karo|type\s*kardo|type|write|karo|kardo)$',
    ]
    cleaned = instruction.strip()
    for pat in fillers:
        cleaned = re.sub(pat, '', cleaned, flags=re.IGNORECASE).strip()
    return cleaned


def parse_sequential_keyboard_actions(text: str, app_name: str = "Notepad") -> list[tuple[str, dict]]:
    """
    Iteratively parses arbitrary-length keyboard sequences:
    - Match all string payloads in order.
    - Detect modifier actions: enter daba kar -> press_hotkey('enter').
    - Detect ctrl+a -> press_hotkey('ctrl+a').
    - Detect backspace / erase karo -> press_hotkey('backspace').
    - Sequentially chain PlanSteps for every clause found in the user prompt.
    """
    from command_layer.decomposer import decompose_compound_command

    clauses = decompose_compound_command(text)
    actions: list[tuple[str, dict]] = []

    def _extract_clause_action(c: str) -> list[tuple[str, dict]]:
        c_str = c.strip(" ,;.-")
        if not c_str:
            return []
        c_lower = c_str.lower()
        res = []

        # Check for enter / newline prefix in clause (e.g. "enter daba kar likho...", "agli line mein likho...")
        has_enter = bool(re.search(r'\b(?:enter\s+(?:daba\s+kar|dabakar|daba\s+ke|dabake|mar\s+kar|marke|maar\s+kar|maaro|press\s+karke|press\s+kar|press\s+karo|dabao|hit\s+karo|key\s+dabao|key\s+press\s+karo)|press\s+enter|hit\s+enter|enter\s+dabao|agli\s+line|next\s+line|new\s+line)\b', c_lower))
        has_pure_enter = has_enter and not any(k in c_lower for k in ['likho', 'type', 'write', '"', "'"]) and not re.search(r'\bline\s*\d+\b', c_lower)
        if has_pure_enter:
            return [('press_hotkey', {'keys': 'enter'})]
        if has_enter:
            res.append(('press_hotkey', {'keys': 'enter'}))

        # Close app action
        if re.search(r'\b(?:close|band\s*kardo|band\s*karo|band\s*kar\s*do|exit|quit)\b', c_lower):
            if not any(k in c_lower for k in ['likho', 'type', 'write', '"', "'"]):
                target_to_close = app_name
                for other_app in ['calculator', 'calc', 'chrome', 'edge', 'cmd', 'powershell', 'browser']:
                    if other_app in c_lower:
                        target_to_close = 'Calculator' if other_app in ('calculator', 'calc') else other_app.capitalize()
                        break
                return [('close_app', {'name_or_pid': target_to_close})]

        # Ctrl+A modifier action
        if re.search(r'\b(?:ctrl\s*\+\s*a|ctrl\s+a|select\s+all|pura\s+select|text\s+select|sara\s+select|sab\s+select)\b', c_lower):
            if not any(k in c_lower for k in ['likho', 'type', 'write', '"', "'"]):
                return [('press_hotkey', {'keys': 'ctrl+a'})]

        # Backspace / Erase modifier action
        if re.search(r'\b(?:backspace|erase\s+karo|erase\s+kar\s+do|erase\s+kardo|erase)\b', c_lower):
            if not any(k in c_lower for k in ['likho', 'type', 'write', '"', "'"]):
                return [('press_hotkey', {'keys': 'backspace'})]

        # App launch only - skip since caller launches and focuses target app
        if re.search(r'\b(?:kholo|open|launch|start)\b', c_lower) and not any(k in c_lower for k in ['likho', 'type', 'write', '"', "'"]):
            return []

        # Text typing payload extraction
        quoted = re.findall(r'["\']([^"\']+)["\']', c_str)
        if quoted:
            payload = quoted[0].strip()
        else:
            payload = extract_pure_text_payload(c_str)

        if payload:
            from command_layer.lexer import UniversalLexer
            if not UniversalLexer.is_action_noise(payload):
                if payload.lower() not in ("notepad", "kholo", "open", "launch", "chalao", "start", "app", "file"):
                    res.append(('type_text', {'text': payload, 'press_enter': False, 'app_name': app_name}))

        return res

    for cl in clauses:
        acts = _extract_clause_action(cl)
        actions.extend(acts)

    # Fallback if clause decomposition produced no actions
    if not actions:
        pos_actions = []
        for m in re.finditer(r'["\']([^"\']+)["\']', text):
            pos_actions.append((m.start(), m.end(), 'type_text', {'text': m.group(1), 'press_enter': False, 'app_name': app_name}))

        for m in re.finditer(r'\b(?:enter\s+(?:daba\s+kar|dabakar|daba\s+ke|dabake|mar\s+kar|marke|press\s+karke|press\s+kar|press\s+karo|dabao|hit\s+karo|key\s+dabao|key\s+press\s+karo)|press\s+enter|hit\s+enter|enter\s+dabao)\b', text, re.IGNORECASE):
            pos_actions.append((m.start(), m.end(), 'press_hotkey', {'keys': 'enter'}))

        for m in re.finditer(r'\b(?:ctrl\s*\+\s*a|ctrl\s+a|select\s+all)\b', text, re.IGNORECASE):
            pos_actions.append((m.start(), m.end(), 'press_hotkey', {'keys': 'ctrl+a'}))

        for m in re.finditer(r'\b(?:backspace|erase\s+karo|erase\s+kar\s+do|erase\s+kardo|erase)\b', text, re.IGNORECASE):
            pos_actions.append((m.start(), m.end(), 'press_hotkey', {'keys': 'backspace'}))

        for m in re.finditer(r'\b(?:close|band\s*kardo|band\s*karo|band\s*kar\s*do|exit|quit)\b', text, re.IGNORECASE):
            pos_actions.append((m.start(), m.end(), 'close_app', {'name_or_pid': app_name}))

        pos_actions.sort(key=lambda x: x[0])
        actions = [(a[2], a[3]) for a in pos_actions]

    return actions


def is_standalone_navigation_request(user_text: str) -> bool:
    """
    Returns True only if the prompt is strictly a standalone navigation request.
    Prevents domain regex from capturing the whole plan if the input contains
    compound instructions ('aur', 'phir', 'notepad', 'cmd', etc.).
    """
    raw_lower = user_text.lower()
    compound_markers = ['aur', 'phir', 'notepad', 'cmd', 'powershell', 'terminal', 'pwsh']
    for marker in compound_markers:
        if re.search(rf'\b{re.escape(marker)}\b', raw_lower):
            return False
    if re.search(r'\b(?:and\s+also|and\s+then|after\s+that|aur\s+phir|uske\s+baad|iske\s+baad|then)\b', raw_lower):
        return False
    return True


def resolve_temporal_order(text: str) -> str:
    """
    Resolves 'X se pehle Y karo' (before X do Y) temporal inversion patterns.
    Converts: 'A se pehle B karo, B se pehle C karo' -> 'C, B, A'
    This ensures chronological execution order even when the user states
    pre-conditions in reverse (top-down goal) order.
    """
    # Detect 'X se pehle Y karo' pattern
    # e.g.: "Notepad mein final summary likhne se pehle desktop check karo,
    #         lekin desktop check karne se pehle cmd se whoami chalao"
    # semantic: whoami -> desktop check -> notepad summary
    
    se_pehle_pattern = re.compile(
        r'([^,]+?)\s+se\s+pehle\s+([^,]+?)(?=\s*(?:,|lekin\s|aur\s|$))',
        re.IGNORECASE
    )
    
    if not re.search(r'\bse\s+pehle\b', text, re.IGNORECASE):
        return text
    
    # Parse dependency chain: (goal, prerequisite) pairs
    # "A se pehle B karo" means: do B before A => B -> A
    inverted_pairs = []  # list of (goal_clause, prereq_clause)
    for m in se_pehle_pattern.finditer(text):
        goal = m.group(1).strip().rstrip(',').strip()
        prereq = m.group(2).strip().rstrip(',').strip()
        inverted_pairs.append((goal, prereq))
    
    if not inverted_pairs:
        return text
    
    # Build linear topological order by reversing the dependency chain
    ordered_clauses = []
    seen = set()
    
    # Work backwards: last prerequisite first
    for goal, prereq in reversed(inverted_pairs):
        if prereq not in seen:
            ordered_clauses.append(prereq)
            seen.add(prereq)
    for goal, prereq in inverted_pairs:
        if goal not in seen:
            ordered_clauses.append(goal)
            seen.add(goal)
    
    # Detect any "sabse aakhir mein X" (finally do X) suffix and append
    final_m = re.search(r'(?:aur\s+)?(?:sabse\s+)?(?:aakhir\s+mein|finally)\s+(.+)$', text, re.IGNORECASE)
    if final_m:
        final_clause = final_m.group(1).strip().rstrip('.')
        if final_clause not in seen:
            ordered_clauses.append(final_clause)
    
    return ', '.join(ordered_clauses)


def sanitize_cli_command(raw_cmd: str) -> str:
    """Strips Roman Urdu conversational prepositions, headless flags, and filler words from CLI instructions."""
    cleaned = raw_cmd.strip()
    cleaned = re.sub(
        r'^(?:(?:pehle\s+|first\s+|zara\s+|please\s+)?(?:cmd|powershell|pwsh|terminal|command\s+prompt|headless)\s*(?:kholo|khol\s*(?:kar|ke)?|open|launch|start|run|chalao|mein|me)?\s*)+',
        '', cleaned, flags=re.IGNORECASE
    ).strip()
    cleaned = re.sub(
        r'^(?:se\s+|aur\s+|phir\s+|usme\s+|usmein\s+|mein\s+|me\s+|command\s+do\s+|command\s+|run\s+|execute\s+|please\s+|zara\s+|kholo\s+|chalao\s+|headless\s+|do\s+)+',
        '', cleaned, flags=re.IGNORECASE
    ).strip()
    for _ in range(5):
        cleaned = re.sub(
            r'\s+(?:command\s+do|command|chalao|run\s*karo|execute\s*karo|nikalo|check\s*karo|kardo|kar\s*do|karo|do|headless|please|zara)$',
            '', cleaned, flags=re.IGNORECASE
        ).strip()
    return cleaned

def extract_pure_text_payload(instruction: str) -> str:
    """Extracts strictly the text intended for typing, discarding all instructional fluff."""
    if not instruction or not isinstance(instruction, str):
        return ""
    quoted = re.findall(r'["\']([^"\']+)["\']', instruction)
    if quoted:
        return quoted[0].strip()
    fillers = [
        r'^(?:notepad\s+(?:kholo|launch\s+karo)\s+aur\s+usme\s+likho|usme\s+likho|wahan\s+type\s+karo|type\s+karo|likho|type|write)\s*',
        r'^(?:(?:notepad|editor|document|app|file)\s+(?:mein|me|main)\s+)',
        r'^(?:pehle|phir|aur|bhi|next|then|uske\s+baad|iske\s+baad|usme|usmein|wahan)\s*',
        r'^(?:search\s+bar\s+mein\s+likho|search\s+karo)\s*',
        r'\s*(?:likh\s*kar\s*enter\s*karo|type\s*karke\s*enter\s*daba\s*do|enter\s*karo)$',
        r'\s*(?:likho|likh\s*do|likhdo|type\s*karo|type\s*kardo|type|write|karo|kardo)$',
    ]
    cleaned = instruction.strip()
    for pat in fillers:
        cleaned = re.sub(pat, '', cleaned, flags=re.IGNORECASE).strip()
    return cleaned

def strip_idiomatic_conditions(text: str) -> str:
    """Strips conversational negative conditions and idle instructions like 'open rehne do', 'chup raho', etc."""
    if not text:
        return ""
    idioms = [
        r'aur\s+notepad\s+ko\s+open\s+rehne\s+do',
        r'(?:aur\s+)?chup\s+chaap\s+(?:notepad|app|window|screen)?\s*open\s+rehne\s+do',
        r'open\s+rehne\s+do',
        r'chup\s+raho',
        r'kuch\s+mat\s+karo',
        r'dhyan\s+rahe.*?(?=,|$)',
        # Full conversational noise clauses — stop before actionable pivot words (lekin abhi, phir, aur)
        r'(?:^|(?<=,)\s*)suno\s+yaar\s+(?:(?!lekin\s+abhi|phir\s+abhi|aur\s+abhi).)*?(?=lekin\s+abhi|phir\s+abhi|aur\s+abhi|,|$)',
        r'(?:^|(?<=,)\s*)kal\s+\w+\s+jana\s+hai\s+(?:(?!lekin\s+abhi|phir|aur\s+abhi).)*?(?=lekin|phir|aur\s+abhi|,|$)',
        # Isolated mid-sentence noise: "waise mausam kafi thanda hai" as a comma-separated clause
        r',\s*waise\s+(?:mausam|abhi|bhi)\s+\w+(?:\s+\w+)*?\s+hai\b',
        r',\s*mausam\s+\w+(?:\s+\w+)*?\s+hai\b',
        r',\s*suno\s+[^,]+',
    ]
    cleaned = text
    for pattern in idioms:
        cleaned = re.sub(pattern, '', cleaned, flags=re.IGNORECASE).strip()
    # Clean leftover leading/trailing commas and whitespace
    cleaned = re.sub(r'^[\s,;]+|[\s,;]+$', '', cleaned)
    cleaned = re.sub(r',\s*,', ',', cleaned)
    return cleaned
