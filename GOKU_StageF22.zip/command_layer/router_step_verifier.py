from __future__ import annotations
import os
from pathlib import Path
import re
import sys
import time
from typing import Any, Optional, Union, List, Dict, Tuple
from dataclasses import dataclass, field

from brain.planner import (
    Plan,
    PlanStep,
    StructuredIntent,
    create_plan_from_decision,
    decompose_compound_command,
    parse_compound_request,
    resolve_step_variables,
    resolve_step_variables_with_guard,
    inject_plan_prerequisites,
    prune_plan_steps,
    build_hypothesis_investigation_plan,
    build_root_cause_investigation_plan,
    parse_conditional_goal,
    synthesize_adaptive_replan,
    decompose_into_milestones,
    restore_plan_from_checkpoint,
    build_cross_domain_plan,
    apply_cross_domain_transformation,
    build_long_horizon_exploration_plan,
    decompose_long_horizon_goal,
    compute_state_hash,
    detect_state_cycle,
    heuristic_node_score,
    expand_exploration_frontier,
    select_next_frontier_node,
    apply_reflective_history_pruning,
)
from command_layer.cognitive_reasoner import CognitiveReasoner
from command_layer.context import (
    EntityType,
    TypedEntity,
    ORDINAL_REFERENCES,
    SessionContext,
    resolve_references,
    session_context,
    update_context_from_result,
)
from command_layer.semantic_model import (
    SemanticDomain,
    SemanticAction,
    CommandIntent,
    AmbiguityType,
    ClarificationRequest,
    SymptomCategory,
    SituationType,
    ConfidenceTier,
    RiskTier,
    ConfidenceScore,
    ConfirmationRequest,
    FailureType,
    AdaptiveStrategy,
    PlanAdaptation,
    TaskLifecycleState,
    TaskMilestone,
    TaskCheckpoint,
    DomainBridgeType,
    DomainBridgeLink,
    CrossDomainWorkflow,
    HorizonDepth,
    ExplorationNode,
    SearchFrontier,
    LongHorizonReport,
    HistoryQueryType,
    ExecutionTraceRecord,
    TraceSummary,
)
from command_layer.semantic_parser import (
    parse_semantic_intent,
    create_plan_from_intent,
    resolve_in_turn_correction,
    strip_conversational_noise,
    split_compound_clauses,
    detect_symptom_category,
)
from command_layer.firewall import validate_tool_against_firewall, pre_execution_semantic_check, validate_long_horizon_action
from command_layer.state_machine import agent_state
from command_layer.validator import validate_and_sanitize_tool_arguments
from command_layer.lexer import UniversalLexer
from brain.runtime_bus import RuntimePipingBus
from security.state import confirmation_manager
from tools.utils.app_resolver import (
    APP_ALIASES,
    get_canonical_app_name,
    resolve_app,
)
from tools.utils.target_resolver import TargetType, resolve_universal_target, disambiguate_multi_candidates
from command_layer.router_base import (
    Step,
    run_tool_call,
    resolve_system_canonical_path,
    verify_post_recovery,
    verify_semantic_outcome,
    capture_environment_snapshot,
    capture_step_observation,
    detect_environment_drift,
    _entity_val,
    get_all_schemas,
    KNOWN_SITE_KEYS,
    KNOWN_APP_NAMES,
    _has_file_extension,
    _normalize_resolved_path,
    _is_conversational_folder_path,
)
from security.safety_firewall import is_safe_readonly_operation
from security.confirm import RISKY_TOOLS
from command_layer.decomposer import count_action_verbs
from brain.workflow_orchestrator import orchestrate_compound_workflow
from tools.browser import sanitize_search_query
from tools.search import parse_search_grammar
import executor.verifier
import executor.executor

from command_layer.router_sanitizer import (
    _isolate_browser_context,
    prune_negated_steps,
    sanitize_action_query,
    sanitize_url,
    _canonicalize_plan_tools,
    sanitize_ui_target,
    extract_clean_search_query,
)
from command_layer.router_cli_parser import (
    translate_cli_command,
    sanitize_cli_command,
    extract_pure_text_payload,
    parse_sequential_keyboard_actions,
    is_standalone_navigation_request,
    resolve_temporal_order,
    strip_idiomatic_conditions,
)
from command_layer.router_confidence import (
    determine_risk_tier,
    format_uncertainty_response,
    compute_command_confidence,
    synthesize_cross_domain_report,
    synthesize_long_horizon_report,
    get_conversational_response,
)
from command_layer.router_classifier_core import _classify_and_parse_command

from command_layer.router_rollback import execute_transactional_rollback

def post_process_step_execution(
    step: PlanStep,
    idx: int,
    plan: Plan,
    session_context: Any,
    step_results: dict[int, dict],
    output_messages: list[str],
    executed_tools: list[str],
    executed_args: list[dict],
    intermediate_traces: list[dict[str, Any]],
    step_contract_records: list[dict[str, Any]],
    unverified_steps: dict[int, str],
    exp_memory: Any,
    active_hypothesis_ledger: Any,
    agent_state: Any,
    dynamic_recovery_steps: int,
    raw_input: str,
    sanitized_args: dict[str, Any],
    result: dict[str, Any],
) -> tuple[str, str | None]:
    """
    Handles post-execution recording, cross-domain bridges, observation capture, outcome verification,
    mistake memory, hypothesis ledger updates, and early-exit triggers.
    Returns: (action, early_exit_reason)
    action is one of 'NEXT', 'CONTINUE', 'BREAK'
    """
    _time = time
    step_idx = idx - 1
    from command_layer.router_rollback import _is_step_dependent_on, execute_transactional_rollback
    from executor.executor import supervise_step_execution
    active_domain = getattr(plan, "domain", None) or SemanticDomain.UNKNOWN
    active_action = getattr(plan, "action", None) or SemanticAction.OPEN
    active_target = getattr(plan, "target", "") or ""
    normalized_input = raw_input
    trace_id = getattr(session_context, "current_trace_id", None) or f"trace_{int(time.time()*1000)}"
    constraints = getattr(step, "constraints", []) or []
    step_caveat = result.get("step_caveat", "") if isinstance(result, dict) else ""
    active_remedy = exp_memory.lookup(
        tool=step.tool,
        args=sanitized_args,
        app=str(sanitized_args.get("name") or sanitized_args.get("app_name") or ""),
    ) if exp_memory else None
    active_remedy_action = active_remedy.get("remedy_action", "") if active_remedy else ""
    active_remedy_args = active_remedy.get("remedy_args", {}) if active_remedy else None
    early_exit_triggered = False
    early_exit_reason = ""
    step_results[step.step] = result
    session_context.record_step_execution(step.step, step.tool, sanitized_args, result)
    update_context_from_result(session_context, step.tool, sanitized_args, result)
    
    # Bullet #27: Cross-Domain Bridge Tracking & Subsystem Coordination
    if (getattr(plan, "is_cross_domain", False) or len(getattr(plan, "primary_domains", [])) >= 2) and getattr(plan, "data_bridges", None):
        for bridge in plan.data_bridges:
            t_step = getattr(bridge, "target_step_id", bridge.get("target_step_id") if isinstance(bridge, dict) else 0)
            if t_step == step.step:
                s_dom = getattr(bridge, "source_domain", bridge.get("source_domain") if isinstance(bridge, dict) else "")
                t_dom = getattr(bridge, "target_domain", bridge.get("target_domain") if isinstance(bridge, dict) else "")
                b_type = getattr(bridge, "bridge_type", bridge.get("bridge_type") if isinstance(bridge, dict) else "")
                s_step = getattr(bridge, "source_step_id", bridge.get("source_step_id") if isinstance(bridge, dict) else 0)
                t_param = getattr(bridge, "target_param", bridge.get("target_param") if isinstance(bridge, dict) else "")
                payload_val = sanitized_args.get(t_param, "") if t_param else ""
                session_context.record_cross_domain_bridge(
                    source_domain=str(s_dom),
                    target_domain=str(t_dom),
                    bridge_type=str(b_type),
                    source_step=s_step,
                    target_step=t_step,
                    payload_summary=str(payload_val)[:80]
                )
    
    # Bullet #28: Long-Horizon Frontier Tracking, Cycle Detection, and Budget Decrement
    if getattr(plan, "is_long_horizon", False) and getattr(plan, "search_frontier", None):
        frontier: SearchFrontier = plan.search_frontier
        session_context.frontier = frontier
    
        curr_state_hash = f"{step.tool}:{compute_state_hash(result)}"
        if detect_state_cycle(frontier.history_state_hashes, curr_state_hash, max_threshold=2):
            frontier.cycle_detected = True
            print(f"[DEBUG_TRACE] CYCLE DETECTED on state hash {curr_state_hash}. Halting exploration loop.")
            early_exit_triggered = True
            early_exit_reason = f"Cycle detected on repetitive state hash {curr_state_hash}"
            return "BREAK", None
    
        frontier.mark_visited(curr_state_hash)
        frontier.consume_budget(1)
    
        curr_node_id = f"node_{step.step}"
        if curr_node_id in frontier.nodes:
            c_node = frontier.nodes[curr_node_id]
            c_node.status = "SOLVED" if result.get("success", True) else "DEAD_END"
            c_node.state_hash = curr_state_hash
            if not result.get("success", True):
                frontier.dead_end_nodes.append(curr_node_id)
    
        if frontier.budget_remaining <= 0:
            print(f"[DEBUG_TRACE] LONG-HORIZON BUDGET EXHAUSTED ({frontier.max_budget} steps). Halting exploration.")
            early_exit_triggered = True
            early_exit_reason = "Exploration budget exhausted"
            return "BREAK", None
    
        # Compact working memory (4 GB RAM Guard)
        session_context.compact_working_memory(max_steps=10)
    
    step_dom = (step.domain_lineage[-1] if getattr(step, "domain_lineage", None) else "")
    if step_dom:
        session_context.decay_stale_domain(step_dom)
    
    # Bullet #24: Closed-Loop Physical Observation Capture & Drift Gating
    step_obs = executor.verifier.capture_step_observation(step, result, session_context)
    session_context.record_step_observation(step_obs)
    
    if getattr(step, "expected_observation", None):
        drift_detected, drift_reason = executor.verifier.detect_environment_drift(step.expected_observation, step_obs)
        if drift_detected:
            step_obs.drift_detected = True
            step_obs.drift_reason = drift_reason
            print(f"[DEBUG_TRACE] ENVIRONMENT DRIFT DETECTED after step {step.step}: {drift_reason}")
            if "Focus mismatch" in drift_reason or "active window" in drift_reason.lower() or "drift" in drift_reason.lower():
                exp_win = step.expected_observation.get("active_window")
                if exp_win:
                    try:
                        import tools.window
                        tools.window.focus_window(app_name=exp_win)
                    except Exception:
                        pass
    
    if result.get("success"):
        if step.tool in ("create_file", "write_file", "replace_file"):
            target_p = sanitized_args.get("path") or sanitized_args.get("file_path")
            if target_p:
                session_context.record_allocated_resource(
                    resource_type="file",
                    identifier=str(target_p),
                    created_by_step=step.step,
                    metadata={"tool": step.tool, "args": sanitized_args}
                )
        elif step.tool == "create_folder":
            target_p = sanitized_args.get("path") or sanitized_args.get("folder_path")
            if target_p:
                session_context.record_allocated_resource(
                    resource_type="folder",
                    identifier=str(target_p),
                    created_by_step=step.step,
                    metadata={"tool": step.tool, "args": sanitized_args}
                )
        elif step.tool == "copy_file":
            dest_p = sanitized_args.get("dest") or sanitized_args.get("destination") or sanitized_args.get("dest_path")
            if dest_p:
                session_context.record_allocated_resource(
                    resource_type="file",
                    identifier=str(dest_p),
                    created_by_step=step.step,
                    metadata={"tool": step.tool, "args": sanitized_args}
                )
        elif step.tool in ("launch_app", "start_app"):
            app_n = sanitized_args.get("name") or sanitized_args.get("app_name")
            pid = result.get("pid")
            if app_n:
                session_context.record_allocated_resource(
                    resource_type="process",
                    identifier=str(pid or app_n),
                    created_by_step=step.step,
                    metadata={"tool": step.tool, "name": app_n, "pid": pid}
                )
    
    # Bullet #21: Dynamic Plan Expansion from Observation
    from brain.planner import expand_plan_from_observation
    plan, was_mutated = expand_plan_from_observation(plan, step.step, result, session_context)
    if was_mutated and plan.mutations:
        latest_mutation = plan.mutations[-1]
        session_context.record_dynamic_plan_mutation(
            mutation_type=latest_mutation.get("mutation_type", "DYNAMIC_EXPANSION"),
            affected_step_ids=latest_mutation.get("affected_step_ids", []),
            reason=latest_mutation.get("reason", ""),
            injected_tools=latest_mutation.get("injected_tools", []),
            before_step_count=latest_mutation.get("before_step_count", 0),
            after_step_count=latest_mutation.get("after_step_count", 0),
        )
        # Firewall gating on dynamically injected steps (Bullet #21)
        from command_layer.firewall import validate_dynamic_step
        dynamic_blocked = False
        dynamic_block_msg = ""
        for affected_id in latest_mutation.get("affected_step_ids", []):
            aff_step = next((s for s in plan.steps if s.step == affected_id), None)
            if aff_step:
                is_dyn_allowed, dyn_fw_err = validate_dynamic_step(
                    tool_name=aff_step.tool,
                    args=aff_step.args,
                    domain=active_domain,
                    action=active_action,
                    target=active_target,
                    constraints=constraints,
                    confirmed="confirmed" in constraints or getattr(step, "is_confirmed", False),
                    injection_reason=latest_mutation.get("reason", "")
                )
                if not is_dyn_allowed:
                    dynamic_blocked = True
                    dynamic_block_msg = dyn_fw_err or "Safety violation in dynamically injected step"
                    return "BREAK", None
        if dynamic_blocked:
            rb_ok, rb_msg = execute_transactional_rollback(session_context, failure_step=step.step)
            halt_reason = f"Execution halted: Dynamically injected step blocked by safety policy ({dynamic_block_msg})"
            if rb_msg:
                halt_reason = f"{halt_reason}\n{rb_msg}"
            agent_state.record_execution(
                trace_id=trace_id,
                user_cmd=raw_input,
                norm_cmd=normalized_input,
                domain=active_domain,
                action=active_action,
                tools=executed_tools,
                args=executed_args,
                success=False,
                verified=False,
                status="firewall_blocked",
                failure_reason=halt_reason,
                intermediate_traces=intermediate_traces
            )
            print(f"[DEBUG_TRACE] DYNAMIC STEP BLOCKED BY FIREWALL: {dynamic_block_msg}")
            return halt_reason
    
    # Synchronize agent_state active domain & task
    if step.tool in ("open_url", "search_web", "open_browser_profile") or (step.tool == "launch_app" and "chrome" in str(sanitized_args.get("name", "")).lower()):
        agent_state.current_domain = SemanticDomain.BROWSER
        agent_state.current_task = "web_browsing"
    elif step.tool in ("open_folder", "find_file", "search_files", "list_folder"):
        agent_state.current_domain = SemanticDomain.FILESYSTEM
        agent_state.current_task = "filesystem"
    elif step.tool in ("find_and_interact", "move_mouse", "click_mouse"):
        agent_state.current_domain = SemanticDomain.GUI
    
    # 3. Semantic Outcome Verification & Prompt D Independent Postcondition Contracts
    from executor.truth_oracle import evaluate_step_postcondition, get_on_fail_policy
    contract_post_obs = evaluate_step_postcondition(step.tool, sanitized_args, session_context, result)
    contract_status = contract_post_obs.status  # "VERIFIED", "FAILED", or "UNVERIFIED"
    contract_evidence = contract_post_obs.evidence or contract_post_obs.reason
    
    # On-fail policy: retry_same once
    if not contract_post_obs.is_verified and get_on_fail_policy(step.tool) == "retry_same" and getattr(step, "retry_count", 0) == 0:
        step.retry_count = 1
        print(f"[DEBUG_TRACE] CONTRACT POSTCONDITION {contract_status} for step {step.step} ({step.tool}). Retrying once under contract policy 'retry_same'...")
        time.sleep(0.5)
        retry_res = supervise_step_execution(step, session_context, sanitized_args=sanitized_args)
        result = retry_res
        contract_post_obs = evaluate_step_postcondition(step.tool, sanitized_args, session_context, result)
        contract_status = contract_post_obs.status
        contract_evidence = contract_post_obs.evidence or contract_post_obs.reason
    
    if result.get("success") is False or result.get("status") in ("not_found", "failed", "error", "blocked"):
        contract_status = "FAILED"
        is_verified = False
    else:
        is_verified = (contract_status == "VERIFIED" and result.get("success") is True)
    tool_err = None
    if not result.get("success"):
        if isinstance(result.get("tool_result"), dict) and result["tool_result"].get("message"):
            tool_err = result["tool_result"]["message"]
        elif isinstance(result.get("tool_result"), dict) and result["tool_result"].get("reason"):
            tool_err = result["tool_result"]["reason"]
        else:
            tool_err = result.get("error") or result.get("reason") or result.get("message")
    eff_reason = contract_post_obs.reason
    if tool_err and not contract_post_obs.is_verified:
        eff_reason = f"{contract_post_obs.reason} (Tool error: {tool_err})"
    step_contract_records.append({
        "step": step.step,
        "tool": step.tool,
        "args": sanitized_args,
        "status": contract_status,
        "evidence": contract_evidence,
        "reason": eff_reason,
    })
    exp_memory.record_step_contract_outcome(
        step=step.step,
        tool=step.tool,
        parameters=sanitized_args,
        status=contract_status,
        evidence_summary=contract_evidence,
    )
    
    # Prompt I Step 1, 2, 5: Record step outcome with mistake memory
    target_hwnd = result.get("hwnd") or getattr(step, "target_hwnd", 0)
    is_owned = True
    if target_hwnd:
        try:
            from tools.input_guard import is_window_owned
            is_owned, _ = is_window_owned(target_hwnd)
        except Exception:
            pass
    
    exp_memory.record(
        tool=step.tool,
        args=sanitized_args,
        app=str(sanitized_args.get("name") or sanitized_args.get("app_name") or ""),
        oracle_status=contract_status,
        tool_success=bool(result.get("success")),
        error=eff_reason or "",
        remedy_applied=active_remedy_action,
        remedy_args=active_remedy_args,
        target_signature=active_remedy.get("signature", "") if active_remedy else "",
        is_owned_window=is_owned,
        guard_passed=True,
        command=raw_input,
    )
    
    session_context.last_user_command = raw_input
    session_context.last_executed_tool = step.tool
    session_context.last_executed_args = sanitized_args
    if contract_status != "VERIFIED":
        unverified_steps[step.step] = contract_status
    
    status_msg = result.get("message", "OK")
    safe_status_msg = str(status_msg).encode("ascii", errors="replace").decode("ascii")
    print(f"[DEBUG_TRACE] VERIFY: {'PASSED' if is_verified else 'FAILED'} - {safe_status_msg}")
    
    intermediate_traces.append({
        "step": step.step,
        "tool": step.tool,
        "args": sanitized_args,
        "result_status": result.get("status", "completed" if result.get("success") else "failed"),
        "verified": is_verified,
        "observation": step_obs.to_dict() if (step_obs and hasattr(step_obs, "to_dict")) else None
    })
    
    if not result.get("success"):
        if step.tool == "find_application":
            app_target = sanitized_args.get("name") or sanitized_args.get("app_name") or ""
            halt_reason = f"Application '{app_target}' was not found on this computer."
            print(f"[DEBUG_TRACE] STOP ({halt_reason})\n")
            return halt_reason
    
        dynamic_recovery_steps += 1
        if dynamic_recovery_steps > 2:
            failure_msg = result.get("message") or result.get("error") or "unknown error"
            halt_reason = f"Maximum recovery attempts exceeded for step {step.step}: {failure_msg}. Halting safely."
            print(f"[DEBUG_TRACE] STOP ({halt_reason})\n")
            return halt_reason
    
        if was_mutated:
            print(f"[DEBUG_TRACE] Dynamic plan expansion injected prerequisite to recover from step {step.step} failure. Continuing.\n")
        else:
            # Bullet #23: Process & Lock Contention Self-Healing check
            from brain.planner import synthesize_self_healing_plan
            healing_plan = synthesize_self_healing_plan(step.tool, sanitized_args, result, session_context)
            if healing_plan and healing_plan.steps:
                print(f"[DEBUG_TRACE] SELF-HEALING INITIATED for step {step.step}: {len(healing_plan.steps)} steps...")
                healing_ok = True
                for h_step in healing_plan.steps:
                    h_res = run_tool_call(h_step.tool, h_step.args)
                    if not h_res.get("success"):
                        healing_ok = False
                        return "BREAK", None
                if healing_ok:
                    print(f"[DEBUG_TRACE] SELF-HEALING PREREQUISITES COMPLETED. Retrying original step {step.step}...")
                    retry_res = run_tool_call(step.tool, sanitized_args)
                    if retry_res.get("success"):
                        result = retry_res
                        step_results[step.step] = result
                        session_context.record_step_execution(step.step, step.tool, sanitized_args, result)
                        update_context_from_result(session_context, step.tool, sanitized_args, result)
                        session_context.record_recovery_outcome(
                            outcome="RECOVERED",
                            details={"self_healed": True, "step": step.step, "tool": step.tool}
                        )
                        pass  # step_idx handled by caller
                        return "CONTINUE", None
    
            # Bullet #22: Adaptive Replanning Interception
            from executor.truth_oracle import get_on_fail_policy
            step_on_fail = get_on_fail_policy(step.tool)
            curr_retry = getattr(step, "retry_count", 0)
            if curr_retry < 2 and step_on_fail != "abort":
                from command_layer.router import synthesize_adaptive_replan as _router_synth
                plan, adaptation = _router_synth(plan, step, result, session_context)
                if adaptation is not None:
                    # Firewall gating on adapted steps (Bullet #22)
                    from command_layer.firewall import validate_dynamic_step
                    adaptation_blocked = False
                    adaptation_block_err = ""
                    for inj in adaptation.injected_steps:
                        inj_tool = getattr(inj, "tool", inj.get("tool") if isinstance(inj, dict) else "")
                        inj_args = getattr(inj, "args", inj.get("args") if isinstance(inj, dict) else {})
                        is_allowed, fw_err = validate_dynamic_step(
                            tool_name=inj_tool,
                            args=inj_args,
                            domain=active_domain,
                            action=active_action,
                            target=active_target,
                            constraints=constraints,
                            confirmed="confirmed" in constraints or getattr(step, "is_confirmed", False),
                            injection_reason=adaptation.rationale
                        )
                        if not is_allowed:
                            adaptation_blocked = True
                            adaptation_block_err = fw_err or "Safety firewall violation in adapted step"
                            break
    
                    if adaptation_blocked:
                        print(f"[DEBUG_TRACE] ADAPTATION BLOCKED BY FIREWALL: {adaptation_block_err}")
                        rb_ok, rb_msg = execute_transactional_rollback(session_context, failure_step=step.step)
                        halt_reason = f"Execution halted: Dynamically adapted step blocked by safety policy ({adaptation_block_err})"
                        if rb_msg:
                            halt_reason = f"{halt_reason}\n{rb_msg}"
                        agent_state.record_execution(
                            trace_id=trace_id,
                            user_cmd=raw_input,
                            norm_cmd=normalized_input,
                            domain=active_domain,
                            action=active_action,
                            tools=executed_tools,
                            args=executed_args,
                            success=False,
                            verified=False,
                            status="firewall_blocked",
                            failure_reason=halt_reason,
                            intermediate_traces=intermediate_traces
                        )
                        return halt_reason
    
                    # Record adaptation in session context
                    session_context.record_plan_adaptation(adaptation)
                    strat_str = getattr(adaptation.strategy, "value", str(adaptation.strategy))
                    fail_str = getattr(adaptation.failure_type, "value", str(adaptation.failure_type))
                    print(f"[DEBUG_TRACE] ADAPTIVE REPLANNING: Step {step.step} failed ({fail_str}). Adapted via {strat_str} -> {adaptation.adapted_tool}. Continuing.\n")
                    # Do NOT increment step_idx so the newly spliced step at step_idx executes on next iteration
                    return "CONTINUE", None
    
            # Bounded retries exhausted or adaptation not possible: halt cleanly with transparent message
            failure_msg = result.get("message") or result.get("error") or "unknown error"
            if curr_retry >= 2:
                halt_reason = f"Adaptive replanning exhausted for step {step.step}: {failure_msg}. Halting safely."
            else:
                halt_reason = f"Step {step.step} failed: {failure_msg}. Halting remaining steps."
    
            # Bullet #23: Trigger Transactional Rollback
            err_code = result.get("error_code") or ("resource_not_found" if "not found" in str(failure_msg).lower() else "")
            rb_ok, rb_msg = execute_transactional_rollback(
                session_context,
                failure_step=step.step,
                failed_step_tool=step.tool,
                error_code=err_code,
                failure_msg=str(failure_msg)
            )
            if rb_msg:
                halt_reason = f"{halt_reason}\n{rb_msg}"
    
            agent_state.record_execution(
                trace_id=trace_id,
                user_cmd=raw_input,
                norm_cmd=normalized_input,
                domain=active_domain,
                action=active_action,
                tools=executed_tools,
                args=executed_args,
                success=False,
                verified=False,
                status="adaptation_exhausted" if curr_retry >= 2 else "step_failed_rolled_back" if rb_ok else "step_failed",
                failure_reason=halt_reason,
                intermediate_traces=intermediate_traces
            )
            print(f"[DEBUG_TRACE] STOP ({halt_reason})\n")
            if step_contract_records:
                for rem_step in plan.steps[step_idx + 1:]:
                    if _is_step_dependent_on(rem_step, step.step, plan):
                        skip_reason = f"Dependency not verified (Step {step.step} was FAILED)"
                        step_contract_records.append({
                            "step": rem_step.step,
                            "tool": rem_step.tool,
                            "args": getattr(rem_step, "args", {}),
                            "status": "SKIPPED",
                            "evidence": skip_reason,
                            "reason": skip_reason,
                        })
                task_verified = all(rec["status"] == "VERIFIED" for rec in step_contract_records)
                overall_status = "VERIFIED" if task_verified else ("FAILED" if any(rec["status"] == "FAILED" for rec in step_contract_records) else "UNVERIFIED")
                lines = [f"Task Status: {overall_status}", "Steps:"]
                for rec in step_contract_records:
                    st = rec["status"]
                    ev = rec.get("evidence") or rec.get("reason")
                    ev_str = str(ev)
                    if isinstance(ev, dict) and "reason" in ev:
                        ev_str = ev["reason"]
                    elif isinstance(ev, dict) and "control_text" in ev:
                        ev_str = f"read back: '{ev['control_text']}'"
                    elif isinstance(ev, dict) and "path" in ev:
                        if ev.get("exists") is False:
                            ev_str = rec.get("reason") or f"file does not exist at '{ev['path']}'"
                        else:
                            ev_str = f"file on disk: '{ev['path']}' ({ev.get('size_bytes', 0)} bytes)"
                    lines.append(f"{rec['step']}. {rec['tool']} -> {st} ({ev_str})")
                if halt_reason:
                    lines.append(halt_reason)
                return "\n".join(lines)
            return halt_reason
    
    
    msg = result.get("message")
    if not msg:
        if step.tool in ("diagnose_network", "diagnose_system", "diagnose_cpu", "diagnose_ram", "diagnose_storage", "diagnose_application"):
            st = result.get("status", "HEALTHY")
            iss = result.get("issue")
            if iss:
                msg = f"{step.tool.replace('_', ' ').title()}: {st} - {iss}"
            else:
                msg = f"{step.tool.replace('_', ' ').title()}: {st}. Subsystem is operating normally."
        else:
            msg = f"Step {step.step} completed."
    if not result.get("success") and was_mutated:
        msg = f"{msg} (Dynamic plan adaptation triggered: prerequisite injected)"
    if not result.get("verified", False) and result.get("status") == "opened_unverified":
        msg = f"{msg} (unverified)"
    if step_caveat:
        msg = f"{msg}{step_caveat}"
    output_messages.append(msg)
    
    # Bullet #26: Update Milestone and Checkpoint Progress
    if getattr(plan, "milestones", None):
        for m in plan.milestones:
            m_step_nums = [s.step for s in m.steps]
            if all(sn in step_results for sn in m_step_nums) and not m.is_completed:
                m.is_completed = True
                m.completed_at = _time.time()
                m.result_summary = f"Phase {m.milestone_id} executed successfully."
                session_context.update_milestone_status(m.milestone_id, True, m.result_summary)
    
        if session_context.task_checkpoint:
            comp_ids = list(step_results.keys())
            tot = len(plan.steps)
            pct = (len(comp_ids) / tot) * 100.0 if tot > 0 else 100.0
            session_context.task_checkpoint.progress_percent = pct
            session_context.task_checkpoint.completed_step_ids = comp_ids
    
    # Bullet #17: Active Hypothesis Ledger Step Evaluation
    if active_hypothesis_ledger is not None:
        from tools.diagnostic_synthesizer import evaluate_hypotheses_against_telemetry
        from command_layer.semantic_model import HypothesisStatus
        active_hypothesis_ledger = evaluate_hypotheses_against_telemetry(
            active_hypothesis_ledger,
            step.tool,
            result
        )
        session_context.record_hypothesis_ledger(active_hypothesis_ledger)
        if active_hypothesis_ledger.is_conclusive and active_hypothesis_ledger.surviving_root_cause:
            surviving_hyp = active_hypothesis_ledger.get_hypothesis(active_hypothesis_ledger.surviving_root_cause)
            survivor_tool = getattr(surviving_hyp, "test_tool", "")
            has_test_for_survivor = any(
                s.tool == survivor_tool
                for s in plan.steps[idx:]
            )
            if has_test_for_survivor and survivor_tool not in executed_tools:
                pass
            elif idx < len(plan.steps):
                print(f"[DEBUG_TRACE] HYPOTHESIS CONCLUDED: Root cause isolated: {active_hypothesis_ledger.surviving_root_cause}. Pruning downstream steps.\n")
                early_exit_triggered = True
                early_exit_reason = f"Conclusive root cause isolated: {active_hypothesis_ledger.surviving_root_cause}"
                return "BREAK", None
    
    # 4. Bullet #15: Early-Exit / Short-Circuit on Conclusive Diagnostic Evidence
    from tools.diagnostic_synthesizer import evaluate_early_exit_criteria
    should_early_exit, exit_reason = evaluate_early_exit_criteria(
        step.tool,
        result,
        early_exit_cond=step.early_exit_condition
    )
    if not getattr(plan, "is_cross_domain", False) and not getattr(plan, "is_long_horizon", False) and should_early_exit and idx < len(plan.steps):
        remaining_steps = plan.steps[idx:]
        has_conditional = any(s.condition is not None or s.on_condition_false != "halt" for s in remaining_steps)
        has_piping = any(any(isinstance(v, str) and v.startswith("$step_") for v in s.args.values()) for s in remaining_steps)
        has_mutation = any(s.tool in ("launch_app", "close_app", "manage_window", "open_url", "type_text", "click_mouse", "delete_file") for s in remaining_steps)
    
        if not has_conditional and not has_piping and not has_mutation:
            print(f"[DEBUG_TRACE] EARLY_EXIT: {exit_reason} (Pruning downstream steps {idx+1}..{len(plan.steps)})\n")
            early_exit_triggered = True
            early_exit_reason = exit_reason
            return "BREAK", None
    
    pass  # step_idx handled by caller
    

    return "NEXT", None
