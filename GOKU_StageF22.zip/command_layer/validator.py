"""
Pre-Execution Argument Sanitizer and Semantic Domain Validator for GOKU Agent.
Rejects intent leakage, natural language conversational clauses in arguments,
length/type anomalies, generic keyword hallucinations, and cross-domain tool mismatches.
"""
import os
import re
from typing import Any

from tools.registry import TOOLS, discover_tools

# Conversational phrases and natural language instructions that should NEVER leak into entity arguments
CONVERSATIONAL_LEAK_PATTERNS = [
    r'\b(?:run\s+karo|chalao|kholo|band\s+karo|close\s+karo|delete\s+karo|check\s+karo)\b',
    r'\b(?:batao|dikhao|explain\s+karo|samjhao|dhundo|search\s+karo|find\s+karo)\b',
    r'\b(?:system\s+health|health\s+check|overall\s+health|diagnosis\s+run|system\s+diagnosis)\b',
    r'\b(?:supporting\s+evidence|evidence\s+do|reason\s+batao|cause\s+identify)\b',
    r'\b(?:complete\s+live\s+status|live\s+status|sab\s+kuch\s+check|saare\s+subsystems)\b',
    r'\b(?:active\s+window|foreground\s+application|running\s+processes|windows\s+services)\b',
    r'\b(?:agar\s+.*?to|warna|otherwise|lekin|par|magar|but)\b',
    r'\b(?:mat\s+karna|mat\s+kholo|mat\s+close|disturb\s+mat|modify\s+kiye\s+baghair)\b',
]

RESERVED_DOMAIN_WORDS_NOT_APPS = {
    "storage", "disk", "drives", "drive", "wifi", "internet", "network",
    "bluetooth", "devices", "device", "overall health", "health", "system health",
    "diagnosis", "system diagnosis", "active window", "foreground app",
    "processes", "process", "services", "service", "cpu", "ram", "memory", "uptime"
}

RESERVED_BROWSER_WORDS_NOT_PROFILES = {
    "channel", "video", "latest video", "latest uploaded video", "tab",
    "window", "page", "website", "search", "youtube channel", "profile video"
}


def is_conversational_leak(text: str) -> bool:
    """Returns True if text contains natural-language instruction clauses."""
    if not isinstance(text, str):
        return False
    lower = text.lower().strip()
    if len(lower) > 60 and (" " in lower):
        # Long strings with conversational spaces
        for pat in CONVERSATIONAL_LEAK_PATTERNS:
            if re.search(pat, lower):
                return True
    else:
        for pat in CONVERSATIONAL_LEAK_PATTERNS:
            if re.search(pat, lower):
                return True
    return False


def validate_and_sanitize_tool_arguments(
    tool_name: str,
    args: dict[str, Any],
    domain: str = ""
) -> tuple[bool, dict[str, Any], str | None]:
    """
    Validates tool name, argument types, semantic domains, and prevents conversational intent leakage.

    Returns:
        (is_valid, sanitized_args, error_message)
    """
    if not tool_name:
        return False, args, "Empty tool name provided."

    # Validate registry existence
    if not TOOLS:
        discover_tools()
    if TOOLS and tool_name not in TOOLS:
        return False, args, f"Tool '{tool_name}' is not registered in tools registry."

    sanitized = dict(args)

    # Bullet #30: Parameter Injection & Delimiter Sanitization
    COMMAND_INJECTION_PATTERNS = [
        r'[;&|`]\s*(?:rm\s+-rf|del\b|format\b|shutdown\b|taskkill\b|powershell\b|cmd\.exe|calc\.exe|rmdir\b)',
        r'\$\([^\)]+\)',
        r'`[^`]+`',
        r'[\r\n]+(?:shutdown|del\b|format\b|rmdir\b|taskkill\b)',
    ]
    for k, v in sanitized.items():
        val_str = str(v)
        if "\0" in val_str:
            return False, args, f"Security violation: Null byte injection detected in argument '{k}'."
        for inj_pat in COMMAND_INJECTION_PATTERNS:
            if re.search(inj_pat, val_str, flags=re.IGNORECASE):
                return False, args, f"Security violation: Command injection pattern detected in argument '{k}': '{val_str}'."

    # 1. Filesystem Tools Validation (open_folder, open_file, delete_file, list_folder, etc.)
    if tool_name in ("open_folder", "open_file", "delete_file", "delete_folder", "list_folder", "get_file_metadata", "extract_archive", "read_file", "write_file", "create_file", "save_active_document"):
        from command_layer.firewall import is_path_traversal_attack, sanitize_filename_literal
        for path_key in ("path", "folder_path", "file_path", "destination", "source", "filepath"):
            if path_key in sanitized:
                val = str(sanitized[path_key]).strip()
                if is_path_traversal_attack(val):
                    return False, args, f"Security violation: Illegal directory traversal targeting protected system path '{val}'."
                # Check intent leakage into path
                if is_conversational_leak(val) or any(w in val.lower() for w in ["diagnosis", "system health", "explain", "evidence", "check karo"]):
                    return False, args, f"Intent leakage rejected: Natural language instruction leaked into filesystem path '{val}'."
                # Reject domain confusion (e.g. 'system health diagnosis' routed to open_folder)
                if val.lower() in RESERVED_DOMAIN_WORDS_NOT_APPS or "diagnosis" in val.lower() or "health" in val.lower():
                    return False, args, f"Domain confusion rejected: Diagnostic/system intent '{val}' cannot be passed to filesystem tool '{tool_name}'."
                clean_val = sanitize_filename_literal(val)
                norm = os.path.normpath(clean_val)
                parts = norm.split(os.sep)
                new_parts = []
                for part in parts:
                    if new_parts and part and part.lower() == new_parts[-1].lower():
                        continue
                    new_parts.append(part)
                res_path = os.sep.join(new_parts)
                if "/" in val and "\\" not in val:
                    res_path = res_path.replace("\\", "/")
                sanitized[path_key] = res_path

    # 2. Process & Application Tools Validation
    if tool_name in ("get_process_status", "find_process", "terminate_process", "kill_process", "get_process_tree"):
        for proc_key in ("name_or_pid", "query", "process_name", "name", "pid"):
            if proc_key in sanitized:
                val = str(sanitized[proc_key]).strip()
                if is_conversational_leak(val):
                    return False, args, f"Intent leakage rejected: Conversational clause leaked into process identifier '{val}'."
                if val.lower() in ("supporting evidence do", "explain karo", "evidence", "karo", "batao", "dikhao"):
                    return False, args, f"Intent leakage rejected: Conversational clause '{val}' is not a valid process name."

    # 3. Application Domain Tools Validation
    if tool_name in ("get_application_status", "is_app_running", "launch_app", "close_app", "restart_app", "focus_app", "find_application", "diagnose_application"):
        for app_key in ("name", "app_name", "application", "query"):
            if app_key in sanitized:
                val = str(sanitized[app_key]).strip()
                if is_conversational_leak(val):
                    return False, args, f"Intent leakage rejected: Conversational clause leaked into application name '{val}'."
                if val.lower() in RESERVED_DOMAIN_WORDS_NOT_APPS:
                    return False, args, f"Domain confusion rejected: System subsystem '{val}' is not an application name."

    # 4. Browser Profile Domain Tools Validation
    if tool_name in ("open_browser_profile", "list_browser_profiles"):
        for prof_key in ("profile_name", "profile"):
            if prof_key in sanitized:
                val = str(sanitized[prof_key]).strip()
                if val.lower() in RESERVED_BROWSER_WORDS_NOT_PROFILES:
                    return False, args, f"Browser semantic gap: '{val}' is a video/content concept, not a local browser profile."

    # 5. Network Domain Tools Validation
    if tool_name in ("ping_host", "test_internet_connectivity"):
        for host_key in ("host", "target_host"):
            if host_key in sanitized:
                val = str(sanitized[host_key]).strip()
                if is_conversational_leak(val) or any(w in val.lower() for w in ["check karo", "batao", "status", "dikhao"]):
                    return False, args, f"Intent leakage rejected: Conversational clause leaked into network target '{val}'."

    return True, sanitized, None
