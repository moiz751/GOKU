from __future__ import annotations
import os
import re
import sys
from typing import Any, Optional, Dict, List, Set, Tuple

from command_layer.semantic_model_base import RiskLevel
from command_layer.semantic_model import (
    SemanticDomain,
    SemanticAction,
    RequestType,
    EntityType,
    CommandIntent,
    AmbiguityType,
    ClarificationRequest,
    SymptomCategory,
    SituationType,
    ConfidenceTier,
    RiskTier,
    ConfidenceScore,
    ConfirmationRequest,
    FailureType,
    AdaptiveStrategy,
    PlanAdaptation,
    TaskLifecycleState,
    TaskMilestone,
    TaskCheckpoint,
    DomainBridgeType,
    DomainBridgeLink,
    CrossDomainWorkflow,
    HorizonDepth,
    ExplorationNode,
    SearchFrontier,
    LongHorizonReport,
    HistoryQueryType,
    ExecutionTraceRecord,
    TraceSummary,
)
from brain.planner import Plan, PlanStep

def _extract_system_capabilities(text: str, lower: str, quoted_strings: list[str]) -> Optional[CommandIntent]:
    # 0. Destructive Safety Guards (Security Enforcement)
    if (
        any(p in lower for p in [
            "format c:", "format disk", "format drive", "wipe disk", "wipe hard disk",
            "delete partition", "kill all", "terminate all", "stop firewall", "disable adapter", "unpair all"
        ])
        or bool(re.search(r'\b(disable|stop)\b.*\b(adapter|network|firewall)\b', lower))
        or bool(re.search(r'\b(format|wipe)\b.*\b(disk|drive|c:|d:)\b', lower))
        or bool(re.search(r'\b(kill|terminate)\b.*\ball\b', lower))
    ):
        return CommandIntent(
            domain=SemanticDomain.SYSTEM,
            action=SemanticAction.UNSUPPORTED,
            target="security_prohibited",
            request_type=RequestType.CONFIRMATION,
            is_negated=True,
            risk_level=RiskLevel.DESTRUCTIVE,
            raw_clause=text,
            selected_tool="DIRECT_MESSAGE",
            tool_args={"message": "Operation restricted for safety and security: Destructive system actions are prohibited."}
        )

    # 1. Wireless / Local Network Connection State
    if (
        (any(w in lower for w in ["wireless", "wifi", "wi-fi", "wlan", "over-the-air"])
         or ("local" in lower and "connection" in lower)
         or "cable or" in lower)
        and any(w in lower for w in ["alive", "status", "haal", "state", "connect", "link", "chal raha", "working", "disconnect", "stable", "drop", "kaisa", "dekhna", "batao", "relying"])
        and not any(w in lower for w in ["signal", "ssid", "password", "settings", "setting"])
    ):
        return CommandIntent(
            domain=SemanticDomain.NETWORK,
            action=SemanticAction.INSPECT,
            target="wifi_status",
            request_type=RequestType.QUERY,
            entity_type=EntityType.NETWORK_CONNECTION,
            selected_tool="get_wifi_status",
            tool_args={},
            raw_clause=text
        )

    # 2. Wi-Fi Signal
    if (
        ("signal" in lower or "quality" in lower or "reception" in lower or "strength" in lower or "antenna" in lower or "transmission" in lower or "whisper" in lower)
        and any(w in lower for w in ["wifi", "wi-fi", "wireless", "wlan", "network"])
    ):
        return CommandIntent(
            domain=SemanticDomain.NETWORK,
            action=SemanticAction.INSPECT,
            target="wifi_signal",
            request_type=RequestType.QUERY,
            entity_type=EntityType.NETWORK_CONNECTION,
            selected_tool="get_wifi_signal",
            tool_args={},
            raw_clause=text
        )

    # 3. Wi-Fi SSID
    if (
        ("ssid" in lower or "network name" in lower or "network ka naam" in lower or "kis se connect" in lower or "kis wifi" in lower)
        and not any(w in lower for w in ["password", "key"])
    ):
        return CommandIntent(
            domain=SemanticDomain.NETWORK,
            action=SemanticAction.INSPECT,
            target="wifi_ssid",
            request_type=RequestType.QUERY,
            entity_type=EntityType.NETWORK_CONNECTION,
            selected_tool="get_wifi_ssid",
            tool_args={},
            raw_clause=text
        )

    # 4. Outbound Ping & Latency
    is_save_target = bool(re.search(r'\b(?:save|write)\b', lower) and any(w in lower for w in ["to", "file", "document", ":\\", ":/"]))
    if not is_save_target and (
        bool(re.search(r'\bping\b', lower))
        or (any(w in lower for w in ["latency", "packet loss", "rtt", "response time"]) and not any(w in lower for w in ["storage", "disk", "drive", "read", "write"]))
    ):
        host = "google.com"
        m = re.search(r'\b([a-zA-Z0-9_\-]+\.[a-zA-Z]{2,}|(?:\d{1,3}\.){3}\d{1,3})\b', text)
        if m:
            host = m.group(1)
        return CommandIntent(
            domain=SemanticDomain.NETWORK,
            action=SemanticAction.DIAGNOSE,
            target=host,
            request_type=RequestType.DIAGNOSTIC,
            entity_type=EntityType.NETWORK_CONNECTION,
            selected_tool="ping_host",
            tool_args={"host": host},
            raw_clause=text
        )

    # 5. External Internet Reachability
    if (
        any(w in lower for w in ["internet", "online", "reachability", "outbound", "bahar reach", "connectivity", "tak reach", "net ka scene", "bhai net", "mera net"])
        and any(w in lower for w in ["alive", "check", "verify", "haal", "chal raha", "reachable", "working", "disconnect", "access", "test", "dekho", "scene", "reach", "off hai ya on", "on hai ya off", "maar"])
        and not any(w in lower for w in ["slow", "lag", "speed", "diagnose"])
    ):
        return CommandIntent(
            domain=SemanticDomain.NETWORK,
            action=SemanticAction.DIAGNOSE,
            target="internet_reachability",
            request_type=RequestType.DIAGNOSTIC,
            entity_type=EntityType.NETWORK_CONNECTION,
            selected_tool="test_internet_connectivity",
            tool_args={},
            raw_clause=text
        )

    # 6. Network Gateway / Router IP
    if any(w in lower for w in ["gateway", "router ka ip", "router address", "default gateway", "router ip"]):
        return CommandIntent(
            domain=SemanticDomain.NETWORK,
            action=SemanticAction.INSPECT,
            target="default_gateway",
            request_type=RequestType.QUERY,
            entity_type=EntityType.NETWORK_CONNECTION,
            selected_tool="get_default_gateway",
            tool_args={},
            raw_clause=text
        )

    # 7. DNS Servers
    if any(w in lower for w in ["dns", "domain name server", "name resolution"]):
        return CommandIntent(
            domain=SemanticDomain.NETWORK,
            action=SemanticAction.INSPECT,
            target="dns_servers",
            request_type=RequestType.QUERY,
            entity_type=EntityType.NETWORK_CONNECTION,
            selected_tool="get_dns_servers",
            tool_args={},
            raw_clause=text
        )

    # 8. Local IP Address
    if any(w in lower for w in ["local ip", "assigned ip", "internal ip", "private ip", "meri ip", "my ip"]):
        return CommandIntent(
            domain=SemanticDomain.NETWORK,
            action=SemanticAction.INSPECT,
            target="local_ip",
            request_type=RequestType.QUERY,
            entity_type=EntityType.NETWORK_CONNECTION,
            selected_tool="get_local_ip",
            tool_args={},
            raw_clause=text
        )

    # 9. Network Interfaces / Adapters
    if (
        bool(re.search(r'\bnetwork\s+(?:interface|adapter)s?\b', lower))
        or any(w in lower for w in ["network adapters", "network interfaces", "ethernet adapter", "network link pe dependent", "kis network link", "interface adapters"])
    ):
        return CommandIntent(
            domain=SemanticDomain.NETWORK,
            action=SemanticAction.INSPECT,
            target="network_interfaces",
            request_type=RequestType.QUERY,
            entity_type=EntityType.NETWORK_CONNECTION,
            selected_tool="get_network_interfaces",
            tool_args={},
            raw_clause=text
        )

    # 10. Processor / CPU Utilization
    if (
        any(w in lower for w in ["processor utilization", "cpu utilization", "processor usage", "cpu usage", "processor load", "cpu load", "khapat"])
        or ((any(w in lower for w in ["cpu", "processor", "processing side"]) or "processor" in lower) and any(w in lower for w in ["load", "usage", "utilization", "percentage", "bottleneck", "status", "dekh ke confirm", "khapat"]))
    ) and not any(w in lower for w in ["top", "highest"]):
        return CommandIntent(
            domain=SemanticDomain.SYSTEM,
            action=SemanticAction.INSPECT,
            target="cpu_status",
            request_type=RequestType.QUERY,
            entity_type=EntityType.PROCESS,
            selected_tool="get_cpu_status",
            tool_args={},
            raw_clause=text
        )

    # 11. Top Processes (CPU / Memory load)
    if (
        any(w in lower for w in ["sabse zyada load", "top processes", "top cpu", "top memory", "highest consumer", "sabse zyada memory", "kaun si process", "konsi process", "highest resource", "juice pee", "sabse zyada juice"])
        or (bool(re.search(r'\bprocesses?\b', lower)) and any(w in lower for w in ["heavy", "consume", "load", "top"]))
    ):
        metric = "memory" if "memory" in lower or "ram" in lower else "cpu"
        return CommandIntent(
            domain=SemanticDomain.SYSTEM,
            action=SemanticAction.INSPECT,
            target="top_processes",
            request_type=RequestType.QUERY,
            entity_type=EntityType.PROCESS,
            selected_tool="get_top_processes",
            tool_args={"metric": metric},
            raw_clause=text
        )

    # 11.5 Process Count
    if (
        any(w in lower for w in ["process count", "total processes", "total kitni processes", "kitni processes chal rahi", "crowded is the task manager"])
        or (any(w in lower for w in ["kitni", "total", "count"]) and "process" in lower)
    ):
        return CommandIntent(
            domain=SemanticDomain.SYSTEM,
            action=SemanticAction.INSPECT,
            target="process_count",
            request_type=RequestType.QUERY,
            entity_type=EntityType.PROCESS,
            selected_tool="get_process_count",
            tool_args={},
            raw_clause=text
        )

    # 12. RAM / Memory Status
    if (
        any(w in lower for w in ["ram", "memory"])
        and any(w in lower for w in ["usage", "utilization", "kitni bachi", "khali", "free", "load", "status", "leak", "consumption", "available", "consuming", "swapping", "thrashing"])
        and not any(w in lower for w in ["top", "process", "processes"])
    ):
        return CommandIntent(
            domain=SemanticDomain.SYSTEM,
            action=SemanticAction.INSPECT,
            target="memory_status",
            request_type=RequestType.QUERY,
            entity_type=EntityType.PROCESS,
            selected_tool="get_memory_status",
            tool_args={},
            raw_clause=text
        )

    # 13. Battery & Power Status
    if any(w in lower for w in ["battery", "power status", "charging", "charger", "plugged in", "battery kitni", "battery health", "battery percentage"]):
        return CommandIntent(
            domain=SemanticDomain.SYSTEM,
            action=SemanticAction.INSPECT,
            target="power_status",
            request_type=RequestType.QUERY,
            entity_type=EntityType.PROCESS,
            selected_tool="get_power_status",
            tool_args={},
            raw_clause=text
        )

    # 14. System Uptime
    if any(w in lower for w in ["uptime", "kitni der se on", "kab restart", "running time", "system uptime", "jaag raha", "running continuously", "without a shutdown"]):
        return CommandIntent(
            domain=SemanticDomain.SYSTEM,
            action=SemanticAction.INSPECT,
            target="system_uptime",
            request_type=RequestType.QUERY,
            entity_type=EntityType.PROCESS,
            selected_tool="get_system_uptime",
            tool_args={},
            raw_clause=text
        )

    # 14.5 System State & Specs
    if any(w in lower for w in ["system state", "runtime state", "hardware specs", "system specs", "specs batao"]):
        return CommandIntent(
            domain=SemanticDomain.SYSTEM,
            action=SemanticAction.INSPECT,
            target="system_state",
            request_type=RequestType.QUERY,
            entity_type=EntityType.PROCESS,
            selected_tool="get_system_state",
            tool_args={},
            raw_clause=text
        )

    # 15. Storage Free Space
    if (
        any(w in lower for w in ["free space", "space bachi", "free maal", "kitni khali", "gb bachi", "free gb", "space kitni hai", "remaining storage", "storage capacity", "drive capacity", "disk capacity", "available storage", "available disk space", "remaining capacity"])
        or (any(w in lower for w in ["drive", "disk", "storage"]) and any(w in lower for w in ["free", "khali", "space", "capacity", "remaining"]))
    ):
        drive = "C:"
        dm = re.search(r'\b([a-zA-Z]):(?:\b|\\)', text)
        if dm:
            drive = f"{dm.group(1).upper()}:"
        else:
            m_drv = re.search(r'\b([a-zA-Z])\s*drive\b|\bdrive\s*([a-zA-Z])\b', lower)
            if m_drv:
                let = m_drv.group(1) or m_drv.group(2)
                drive = f"{let.upper()}:"
        return CommandIntent(
            domain=SemanticDomain.FILESYSTEM,
            action=SemanticAction.INSPECT,
            target=drive,
            request_type=RequestType.QUERY,
            entity_type=EntityType.FOLDER,
            selected_tool="get_free_space",
            tool_args={"drive": drive},
            raw_clause=text
        )

    # 15.5 Drive Usage (Fullness)
    if (
        any(w in lower for w in ["pet kitna bhara", "kitna bhara", "kitni full", "drive usage", "how full"])
        or (any(w in lower for w in ["drive", "disk"]) and any(w in lower for w in ["full", "bhara", "usage"]))
    ):
        drive = "C:"
        dm = re.search(r'\b([a-zA-Z]):(?:\b|\\)', text)
        if dm:
            drive = f"{dm.group(1).upper()}:"
        return CommandIntent(
            domain=SemanticDomain.FILESYSTEM,
            action=SemanticAction.INSPECT,
            target=drive,
            request_type=RequestType.QUERY,
            entity_type=EntityType.FOLDER,
            selected_tool="get_drive_usage",
            tool_args={"drive": drive},
            raw_clause=text
        )

    # 15.6 Mounted Drives
    if any(w in lower for w in ["kitni drives", "mounted drives", "drives mounted", "total drives", "mounted hain"]):
        return CommandIntent(
            domain=SemanticDomain.FILESYSTEM,
            action=SemanticAction.INSPECT,
            target="drives",
            request_type=RequestType.QUERY,
            entity_type=EntityType.FOLDER,
            selected_tool="get_drives",
            tool_args={},
            raw_clause=text
        )

    # 16. Storage Health & Diagnostics
    if (
        ("diagnose" in lower and any(w in lower for w in ["storage", "drive", "disk"]))
        or any(w in lower for w in ["diagnose storage", "diagnose disk", "storage diagnostics"])
    ):
        return CommandIntent(
            domain=SemanticDomain.DIAGNOSTICS,
            action=SemanticAction.DIAGNOSE,
            target="storage",
            request_type=RequestType.DIAGNOSTIC,
            entity_type=EntityType.FOLDER,
            selected_tool="diagnose_storage",
            tool_args={},
            raw_clause=text
        )

    if any(w in lower for w in ["storage health", "storage pressure", "which drive is full", "low storage pop-up", "disk condition", "disk health"]):
        return CommandIntent(
            domain=SemanticDomain.FILESYSTEM,
            action=SemanticAction.DIAGNOSE,
            target="storage_health",
            request_type=RequestType.DIAGNOSTIC,
            entity_type=EntityType.FOLDER,
            selected_tool="get_storage_health_snapshot",
            tool_args={},
            raw_clause=text
        )

    # 17. Disk IO & Activity
    if any(w in lower for w in ["disk io", "disk i/o", "read write", "disk activity", "disk busy"]):
        return CommandIntent(
            domain=SemanticDomain.FILESYSTEM,
            action=SemanticAction.INSPECT,
            target="disk_io",
            request_type=RequestType.QUERY,
            entity_type=EntityType.FOLDER,
            selected_tool="get_disk_io",
            tool_args={},
            raw_clause=text
        )

    # 18. Removable Drives / USB Storage
    if any(w in lower for w in ["removable drives", "usb drives", "external drives", "flash drive", "pendrive"]):
        return CommandIntent(
            domain=SemanticDomain.FILESYSTEM,
            action=SemanticAction.INSPECT,
            target="removable_drives",
            request_type=RequestType.QUERY,
            entity_type=EntityType.FOLDER,
            selected_tool="get_removable_drives",
            tool_args={},
            raw_clause=text
        )

    # 19. Background Services
    if any(w in lower for w in ["services", "service", "daemon"]) and any(w in lower for w in ["running", "active", "chalu", "stopped", "band", "inactive", "summary", "count", "handling", "responsible"]):
        if ("spooler" in lower or "print" in lower):
            return CommandIntent(
                domain=SemanticDomain.SYSTEM,
                action=SemanticAction.INSPECT,
                target="Spooler",
                request_type=RequestType.QUERY,
                entity_type=EntityType.SERVICE,
                selected_tool="get_service_status",
                tool_args={"name": "Spooler"},
                raw_clause=text
            )
        tool_name = "get_running_services" if any(w in lower for w in ["running", "active", "chalu"]) else ("get_stopped_services" if any(w in lower for w in ["stopped", "band", "inactive"]) else "get_service_summary")
        return CommandIntent(
            domain=SemanticDomain.SYSTEM,
            action=SemanticAction.INSPECT,
            target="services",
            request_type=RequestType.QUERY,
            entity_type=EntityType.SERVICE,
            selected_tool=tool_name,
            tool_args={},
            raw_clause=text
        )

    # 20. Bluetooth Devices & Status
    if any(w in lower for w in ["bluetooth", "bt"]):
        tool_name = "get_bluetooth_devices" if any(w in lower for w in ["devices", "peripherals", "list", "paired", "connected"]) else "get_bluetooth_status"
        return CommandIntent(
            domain=SemanticDomain.DEVICES,
            action=SemanticAction.INSPECT,
            target="bluetooth",
            request_type=RequestType.QUERY,
            entity_type=EntityType.DEVICE,
            selected_tool=tool_name,
            tool_args={},
            raw_clause=text
        )

    # 21. Hardware & Peripherals Summary
    if any(w in lower for w in ["peripherals", "connected peripherals", "hardware peripherals", "connected devices"]):
        return CommandIntent(
            domain=SemanticDomain.DEVICES,
            action=SemanticAction.INSPECT,
            target="peripherals",
            request_type=RequestType.QUERY,
            entity_type=EntityType.DEVICE,
            selected_tool="get_connected_device_summary",
            tool_args={},
            raw_clause=text
        )


    return None
