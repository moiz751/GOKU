from __future__ import annotations
from command_layer.context_models import EntityType, TypedEntity
import gc
import json
import os
from pathlib import Path
import re
import time
from typing import Any, Optional, Dict, List, Set, Tuple

from command_layer.semantic_model import (
    PlanMutationType,
    PlanDAGNode,
    PlanMutation,
    FailureType,
    AdaptiveStrategy,
    PlanAdaptation,
    RecoveryStatus,
    CompensationAction,
    RollbackLedger,
    ObservationType,
    StepObservation,
    EnvironmentSnapshot,
    OutcomeVerdict,
    OutcomeCriteria,
    OutcomeReport,
    TaskLifecycleState,
    TaskMilestone,
    TaskCheckpoint,
    DomainBridgeType,
    DomainBridgeLink,
    CrossDomainWorkflow,
    HorizonDepth,
    ExplorationNode,
    SearchFrontier,
    LongHorizonReport,
    HistoryQueryType,
    ExecutionTraceRecord,
    TraceSummary,
    FirewallVerdict,
    AdversarialAttackRecord,
)

class SessionTelemetryMixin:

    def record_dynamic_plan_mutation(
        self,
        mutation_type: str,
        affected_step_ids: list[int],
        reason: str,
        injected_tools: list[str] | None = None,
        before_step_count: int = 0,
        after_step_count: int = 0,
    ) -> None:
        """Records a dynamic plan mutation event in context (Bullet #21)."""
        import time as _time
        entry = {
            "mutation_type": mutation_type,
            "affected_step_ids": affected_step_ids,
            "reason": reason,
            "injected_tools": injected_tools or [],
            "before_step_count": before_step_count,
            "after_step_count": after_step_count,
            "timestamp": _time.time(),
        }
        self.dynamic_plan_history.append(entry)
        self.last_dynamic_plan = entry

    def get_mutation_explanation(self, step_id: int | None = None) -> str:
        """
        Returns a human-readable explanation for a dynamic plan mutation (Bullet #21).
        If step_id is given, explains that specific injected step.
        Otherwise, summarizes the last mutation.
        """
        if not self.dynamic_plan_history:
            return "No dynamic plan mutations in this session."

        if step_id is not None:
            for entry in reversed(self.dynamic_plan_history):
                if step_id in entry.get("affected_step_ids", []):
                    tools = entry.get("injected_tools", [])
                    return (
                        f"Step {step_id} was dynamically injected ({entry['mutation_type']}): "
                        f"{entry['reason']}. Tools: {tools}"
                    )
            return f"Step {step_id} was not dynamically injected."

        last = self.dynamic_plan_history[-1]
        return (
            f"Last plan mutation ({last['mutation_type']}): {last['reason']}. "
            f"Affected steps: {last.get('affected_step_ids', [])}. "
            f"Plan grew from {last.get('before_step_count', '?')} to {last.get('after_step_count', '?')} steps."
        )

    def clear_replanning_state(self) -> None:
        """Clears replanning audit history and failed step cache (Bullet #22)."""
        self.replanning_history.clear()
        self.failed_step_cache.clear()
        self.last_adaptation = None

    def record_plan_adaptation(
        self,
        adaptation_or_step_id: Any,
        failure_type: Any = None,
        strategy: Any = None,
        injected_steps: list[Any] | None = None,
        pruned_steps: list[int] | None = None,
        retry_count: int = 1,
        rationale: str = "",
        original_tool: str = "",
        adapted_tool: str = "",
        resolved: bool = False,
    ) -> None:
        """Records a mid-flight plan adaptation event in context (Bullet #22)."""
        import time as _time
        if hasattr(adaptation_or_step_id, "to_dict"):
            entry = adaptation_or_step_id.to_dict()
        elif isinstance(adaptation_or_step_id, dict):
            entry = dict(adaptation_or_step_id)
        else:
            inj = []
            for s in (injected_steps or []):
                if hasattr(s, "to_dict"):
                    inj.append(s.to_dict())
                elif isinstance(s, dict):
                    inj.append(s)
                else:
                    inj.append(str(s))
            entry = {
                "failed_step_id": int(adaptation_or_step_id),
                "failure_type": str(getattr(failure_type, "value", failure_type)),
                "strategy": str(getattr(strategy, "value", strategy)),
                "injected_steps": inj,
                "pruned_steps": pruned_steps or [int(adaptation_or_step_id)],
                "retry_count": retry_count,
                "rationale": rationale,
                "original_tool": original_tool,
                "adapted_tool": adapted_tool,
                "timestamp": _time.time(),
                "resolved": resolved,
            }

        self.replanning_history.append(entry)
        self.last_adaptation = entry
        step_id = entry.get("failed_step_id")
        if step_id is not None:
            self.failed_step_cache[step_id] = entry

    def get_replanning_explanation(self, step_id: int | None = None) -> str:
        """
        Returns a human-readable explanation for an adaptive replanning event (Bullet #22).
        If step_id is given, explains why that specific step failed and what adaptation was chosen.
        Otherwise, explains the most recent adaptation.
        """
        if not self.replanning_history:
            return "No plan adaptations have occurred during this session."

        if step_id is not None:
            for entry in reversed(self.replanning_history):
                if entry.get("failed_step_id") == step_id:
                    orig = entry.get("original_tool", f"Step {step_id}")
                    ftype = entry.get("failure_type", "failure")
                    strat = entry.get("strategy", "adaptation")
                    adapt = entry.get("adapted_tool", "alternative")
                    rat = entry.get("rationale", "")
                    return (
                        f"Step {step_id} ({orig}) failed due to {ftype}. "
                        f"Adapted using {strat} to '{adapt}'. Rationale: {rat}"
                    )
            return f"Step {step_id} did not undergo adaptive replanning."

        last = self.replanning_history[-1]
        return (
            f"Last plan adaptation at Step {last.get('failed_step_id')} ({last.get('original_tool', 'unknown')}): "
            f"failed due to {last.get('failure_type', 'error')}. "
            f"Strategy: {last.get('strategy', 'unknown')}, substituted with '{last.get('adapted_tool', 'unknown')}'. "
            f"Rationale: {last.get('rationale', '')}"
        )

    # ==========================================================================
    # BULLET #23: FAILURE RECOVERY & TRANSACTIONAL ROLLBACK METHODS
    # ==========================================================================

    def record_allocated_resource(
        self,
        resource_type: str = "file",
        identifier: str = "",
        created_by_step: int | None = None,
        step_id: int | None = None,
        tool_name: str = "",
        args: dict[str, Any] | None = None,
        is_preexisting: bool = False,
        metadata: dict[str, Any] | None = None,
        **kwargs
    ) -> dict[str, Any]:
        """
        Records a newly allocated system resource (file, directory, spawned process)
        during multi-step plan execution for potential transactional rollback (Bullet #23).
        """
        import time as _time
        eff_step = created_by_step if created_by_step is not None else (step_id if step_id is not None else 0)
        eff_id = identifier or kwargs.get("resource_id", "")
        entry = {
            "step_id": eff_step,
            "created_by_step": eff_step,
            "tool_name": tool_name or (metadata.get("tool") if metadata else ""),
            "resource_type": resource_type,  # "file", "folder", "process", "window"
            "resource_id": eff_id,
            "identifier": eff_id,      # path or process name/pid
            "args": dict(args or (metadata.get("args") if metadata else {}) or {}),
            "metadata": dict(metadata or {}),
            "is_preexisting": is_preexisting,
            "timestamp": _time.time(),
        }
        self.allocated_resources.append(entry)
        return entry

    def record_compensation_action(
        self,
        action: Any = None,
        original_step: int | None = None,
        tool_name: str = "",
        args: dict[str, Any] | None = None,
        success: bool = True,
        verified: bool = False,
        error: str | None = None,
        **kwargs
    ) -> None:
        """Records an executed or pending compensation action into the active recovery session (Bullet #23)."""
        from command_layer.semantic_model import CompensationAction
        if action is not None:
            if isinstance(action, CompensationAction):
                self.pending_compensations.append(action)
                return
            entry = action.to_dict() if hasattr(action, "to_dict") else dict(action)
            comp = CompensationAction(
                step_id=entry.get("step_id", 0),
                original_step_id=entry.get("original_step_id", entry.get("step_id", 0)),
                action_name=entry.get("action_name", ""),
                tool=entry.get("tool", entry.get("compensation_tool", "")),
                compensation_tool=entry.get("compensation_tool", entry.get("tool", "")),
                args=entry.get("args", entry.get("arguments", {})),
                arguments=entry.get("arguments", entry.get("args", {})),
                reason=entry.get("reason", ""),
                status=entry.get("status", "executed" if entry.get("success") else "pending"),
                result=entry.get("result"),
                verified=entry.get("verified", False),
                success=entry.get("success", True),
                error=entry.get("error")
            )
            self.pending_compensations.append(comp)
        else:
            comp = CompensationAction(
                step_id=original_step or 0,
                original_step_id=original_step or 0,
                tool=tool_name,
                compensation_tool=tool_name,
                args=args or {},
                arguments=args or {},
                success=success,
                verified=verified,
                error=error,
                status="executed" if success else "failed"
            )
            self.pending_compensations.append(comp)

    def record_recovery_outcome(
        self,
        ledger_or_status: Any = None,
        error_reason: str = "",
        outcome: Any = None,
        details: dict[str, Any] | None = None,
        **kwargs
    ) -> Any:
        """Records a completed rollback or self-healing recovery event in recovery_ledger (Bullet #23)."""
        from command_layer.semantic_model import RollbackLedger, RecoveryStatus
        import time as _time
        if isinstance(ledger_or_status, RollbackLedger):
            self.recovery_ledger.append(ledger_or_status)
            self.last_recovery = ledger_or_status
            return ledger_or_status

        eff_status = outcome or ledger_or_status or RecoveryStatus.IDLE
        if isinstance(eff_status, str):
            for st in RecoveryStatus:
                if st.value.lower() == eff_status.lower():
                    eff_status = st
                    break
            else:
                eff_status = RecoveryStatus.ROLLBACK_SUCCESSFUL if "success" in str(eff_status).lower() else RecoveryStatus.IDLE

        eff_details = details or kwargs.get("outcome_details", {})
        ledger = RollbackLedger(
            task_id=kwargs.get("task_id", ""),
            trigger_failure_step=kwargs.get("failure_step", kwargs.get("trigger_failure_step", -1)),
            trigger_error=error_reason or kwargs.get("trigger_error", ""),
            executed_steps=[s.get("step", 0) for s in getattr(self, "executed_steps", [])],
            pending_compensations=list(self.pending_compensations),
            completed_compensations=[
                c.to_dict() if hasattr(c, "to_dict") else c for c in self.pending_compensations
            ],
            actions=list(self.pending_compensations),
            status=eff_status,
            outcome_details=dict(eff_details),
            error_reason=error_reason,
            timestamp=_time.time()
        )
        self.recovery_ledger.append(ledger)
        self.last_recovery = ledger
        return ledger

    def get_pending_compensations(self) -> list[Any]:
        """Returns the list of pending compensation actions (Bullet #23)."""
        if self.pending_compensations:
            return list(self.pending_compensations)
        from command_layer.semantic_model import CompensationAction
        comps = []
        for alloc in self.allocated_resources:
            if alloc.get("is_preexisting"):
                continue
            r_type = alloc.get("resource_type", "")
            r_id = alloc.get("resource_id") or alloc.get("identifier", "")
            step_id = alloc.get("step_id") or alloc.get("created_by_step") or 0
            if r_type in ("file", "replace_file"):
                tool = "delete_file"
                act_name = "rollback_created_file"
                args = {"path": str(r_id)}
            elif r_type in ("folder", "directory"):
                tool = "delete_folder"
                act_name = "rollback_created_folder"
                args = {"path": str(r_id)}
            elif r_type in ("process", "app"):
                tool = "close_app"
                act_name = "rollback_spawned_app"
                args = {"name": str(r_id)}
            else:
                tool = "delete_file"
                act_name = f"rollback_{r_type}"
                args = {"path": str(r_id)}

            comps.append(CompensationAction(
                step_id=step_id,
                original_step_id=step_id,
                action_name=act_name,
                tool=tool,
                compensation_tool=tool,
                args=args,
                arguments=args,
                reason=f"Rollback compensation for {r_type} {r_id}",
                status="pending"
            ))
        return comps

    def clear_recovery_state(self) -> None:
        """Clears all failure recovery and rollback state ledgers (Bullet #23)."""
        self.allocated_resources.clear()
        self.recovery_ledger.clear()
        self.last_recovery = None
        self.pending_compensations.clear()

    def get_recovery_explanation(self, task_id: str | None = None) -> str:
        """
        Returns a human-readable explanation of failure recovery / transactional rollback (Bullet #23).
        """
        if not self.recovery_ledger:
            return "No failure recovery or rollback operations have occurred during this session."

        target_entry = None
        if task_id:
            for entry in reversed(self.recovery_ledger):
                e_task = getattr(entry, "task_id", entry.get("task_id") if isinstance(entry, dict) else "")
                if e_task == task_id:
                    target_entry = entry
                    break
            if not target_entry:
                return f"No recovery operation found for task '{task_id}'."
        else:
            target_entry = self.recovery_ledger[-1]

        status = getattr(target_entry, "status", target_entry.get("status") if isinstance(target_entry, dict) else "unknown")
        status_val = status.value if hasattr(status, "value") else str(status)
        details = getattr(target_entry, "outcome_details", target_entry.get("outcome_details") if isinstance(target_entry, dict) else {})
        details_str = str(details) if details else ""

        completed = getattr(target_entry, "actions", getattr(target_entry, "completed_compensations", []))
        comp_summaries = []
        for c in completed:
            tool = getattr(c, "tool_name", c.get("tool", "unknown_tool") if isinstance(c, dict) else str(c))
            args = getattr(c, "args", c.get("args", {}) if isinstance(c, dict) else {})
            target = args.get("path") or args.get("name") or str(args)
            comp_summaries.append(f"{tool} on '{target}'")

        summary_str = f"Completed compensations ({len(completed)}): {', '.join(comp_summaries)}." if comp_summaries else ""
        return (
            f"Recovery Status: {status_val.upper()}. "
            f"{details_str} "
            f"{summary_str}"
        ).strip()

    # ==========================================================================
    # BULLET #24: OBSERVATION-DRIVEN EXECUTION & CLOSED-LOOP SENSING
    # ==========================================================================

    def record_step_observation(self, observation: Any) -> None:
        """
        Records a physical state observation captured post-execution (Bullet #24).
        Updates observed filesystem deltas and live context tracking.
        """
        if observation is not None:
            self.observation_history.append(observation)
            if len(self.observation_history) > 20:
                self.observation_history = self.observation_history[-20:]
            state = getattr(observation, "physical_state", observation.get("physical_state", {}) if isinstance(observation, dict) else {})
            p = state.get("path")
            if p and "size_bytes" in state:
                self.observed_filesystem_stats[str(p)] = {
                    "size_bytes": state.get("size_bytes", 0),
                    "mtime": state.get("mtime", 0.0),
                    "exists": state.get("exists", False),
                    "is_directory": state.get("is_directory", False),
                }

    def record_environment_snapshot(self, snapshot: Any) -> None:
        """Records the latest full environmental snapshot (Bullet #24)."""
        self.last_environment_snapshot = snapshot

    def get_last_observation(self) -> Any | None:
        """Returns the most recent StepObservation (Bullet #24)."""
        return self.observation_history[-1] if self.observation_history else None

    def get_observation_for_step(self, step_num: int) -> Any | None:
        """Returns the StepObservation for a specific step sequence number (Bullet #24)."""
        for obs in reversed(self.observation_history):
            s_id = getattr(obs, "step_num", getattr(obs, "step_id", obs.get("step_num") if isinstance(obs, dict) else None))
            if s_id == step_num:
                return obs
        return None

    def get_observation_explanation(self, step_num: int | None = None, lang: str = "en") -> str:
        """
        Returns a human-readable, multilingual physical state explanation (Bullet #24).
        Answers queries such as 'Pehle step ke baad screen/file ki kya halat thi?'.
        """
        if not self.observation_history:
            return "Pichli execution mein koi physical observation capture nahi hui thi." if lang == "ur" else "No physical observations were recorded from the previous execution."

        target_obs = None
        if step_num is not None:
            target_obs = self.get_observation_for_step(step_num)
            if not target_obs:
                return f"Step {step_num} ke liye koi physical observation record nahi hui." if lang == "ur" else f"No physical observation recorded for step {step_num}."
        else:
            target_obs = self.get_last_observation()

        tool = getattr(target_obs, "tool", target_obs.get("tool", "action") if isinstance(target_obs, dict) else "")
        s_num = getattr(target_obs, "step_num", target_obs.get("step_num", 0) if isinstance(target_obs, dict) else 0)
        state = getattr(target_obs, "physical_state", target_obs.get("physical_state", {}) if isinstance(target_obs, dict) else {})
        obs_type = getattr(target_obs, "obs_type", target_obs.get("obs_type", "") if isinstance(target_obs, dict) else "")
        obs_type_val = obs_type.value if hasattr(obs_type, "value") else str(obs_type)

        verified = getattr(target_obs, "state_verified", target_obs.get("state_verified", True) if isinstance(target_obs, dict) else True)
        drift = getattr(target_obs, "drift_detected", target_obs.get("drift_detected", False) if isinstance(target_obs, dict) else False)
        drift_reason = getattr(target_obs, "drift_reason", target_obs.get("drift_reason", "") if isinstance(target_obs, dict) else "")

        if lang == "ur":
            details = []
            if "active_window" in state and state.get("active_window"):
                foc = "focus mein hai" if state.get("focus_state", state.get("is_focused", True)) else "focus mein nahi tha"
                details.append(f"Active window: '{state.get('active_window')}' ({foc})")
            if "exists" in state:
                sz = state.get("size_bytes", 0)
                delta = state.get("size_delta")
                delta_str = f" (delta: {delta:+d} bytes)" if delta is not None and delta != 0 else ""
                ex_str = "file mojood hai" if state.get("exists") else "file mojood nahi hai"
                details.append(f"{ex_str}, size: {sz} bytes{delta_str}")
            if "cpu_percent" in state or "memory_mb" in state:
                cpu = state.get("cpu_percent", 0.0)
                mem = state.get("memory_mb", 0.0)
                details.append(f"CPU usage: {cpu}%, Memory: {mem} MB")
            if "pid" in state and state.get("pid"):
                alive_str = "chal raha hai" if state.get("is_alive") else "band/terminated hai"
                details.append(f"Process PID {state.get('pid')} {alive_str}")
            if "network_up" in state:
                details.append("Network connected hai" if state.get("network_up") else "Network down hai")

            detail_joined = ", ".join(details) if details else "Koi tabdeeli record nahi hui"
            drift_str = f" [DRIFT DETECTED: {drift_reason}]" if drift else ""
            ver_str = "Physical state verify ho chuki hai" if verified else "Physical state verify nahi ho saki"
            return f"Step {s_num} ({tool}) Observation [{obs_type_val}]: {detail_joined}. {ver_str}.{drift_str}".strip()

        details = []
        if "active_window" in state and state.get("active_window"):
            details.append(f"Active Window: '{state.get('active_window')}'")
        if "focus_state" in state or "is_focused" in state:
            foc = state.get("focus_state", state.get("is_focused"))
            details.append("Focused" if foc else "Not focused")
        if "path" in state and state.get("path"):
            exists_str = "exists" if state.get("exists") else "deleted/absent"
            sz = state.get("size_bytes", 0)
            delta = state.get("size_delta")
            delta_str = f" (delta: {delta:+d} bytes)" if delta is not None and delta != 0 else ""
            details.append(f"Path '{state.get('path')}': {exists_str}, size: {sz} bytes{delta_str}")
        elif "exists" in state:
            exists_str = "exists" if state.get("exists") else "deleted/absent"
            sz = state.get("size_bytes", 0)
            details.append(f"File {exists_str}, size: {sz} bytes")
        if "cpu_percent" in state or "memory_mb" in state:
            cpu = state.get("cpu_percent", 0.0)
            mem = state.get("memory_mb", 0.0)
            details.append(f"CPU: {cpu}%, Memory: {mem} MB")
        if "pid" in state and state.get("pid"):
            alive_str = "alive" if state.get("is_alive") else "terminated/dead"
            details.append(f"Process PID {state.get('pid')}: {alive_str}")
        if "network_up" in state:
            details.append("Network connected" if state.get("network_up") else "Network down")

        drift_str = f" [DRIFT DETECTED: {drift_reason}]" if drift else ""
        detail_joined = ", ".join(details) if details else "No physical changes"
        return (
            f"Step {s_num} ({tool}) Observation [{obs_type_val.upper()}]: "
            f"{detail_joined}. "
            f"Physical state verified: {verified}.{drift_str}"
        ).strip()

    # ==========================================================================
    # BULLET #25: OUTCOME VERIFICATION & GOAL AUDITING
    # ==========================================================================

    def record_outcome_report(self, report: Any) -> None:
        """
        Records an OutcomeReport certifying overall goal fulfillment (Bullet #25).
        """
        if report is not None:
            self.last_outcome_report = report
            self.outcome_history.append(report)

    def get_last_outcome(self) -> Any | None:
        """Returns the most recent OutcomeReport (Bullet #25)."""
        return self.last_outcome_report

    def clear_outcome_state(self) -> None:
        """Clears outcome verification history and last report (Bullet #25)."""
        self.last_outcome_report = None
        self.outcome_history.clear()

    def get_outcome_explanation(self, lang: str = "en") -> str:
        """
        Returns a human-readable, multilingual physical goal outcome explanation (Bullet #25).
        Answers inquiries like 'Did it actually work?' or 'Kya kaam waqayi complete ho gaya?'.
        """
        if not self.last_outcome_report:
            return "Pichli execution ke liye koi outcome report mojood nahi hai." if lang == "ur" else "No outcome report is available for the previous execution."

        rep = self.last_outcome_report
        goal = getattr(rep, "goal_text", rep.get("goal_text", "") if isinstance(rep, dict) else "")
        verdict = getattr(rep, "verdict", rep.get("verdict", "") if isinstance(rep, dict) else "")
        verdict_val = (verdict.value if hasattr(verdict, "value") else str(verdict)).upper()
        evidence = getattr(rep, "verified_evidence", rep.get("verified_evidence", []) if isinstance(rep, dict) else [])
        discrepancies = getattr(rep, "discrepancies", rep.get("discrepancies", []) if isinstance(rep, dict) else [])
        remediation = getattr(rep, "remediation_suggested", rep.get("remediation_suggested", None) if isinstance(rep, dict) else None)

        if isinstance(evidence, dict):
            ev_str = ", ".join(f"{k}: {v}" if not isinstance(v, dict) else k for k, v in evidence.items())
        elif isinstance(evidence, (list, tuple)):
            ev_str = ", ".join(str(e) for e in evidence)
        else:
            ev_str = str(evidence)

        if lang == "ur":
            ev_str = ev_str if ev_str else "Koi suboot mojood nahi"
            if verdict_val == "GOAL_ACHIEVED":
                return f"Hadaf Mukammal Ho Gaya: '{goal}'. Physical suboot: {ev_str}."
            elif verdict_val == "PARTIALLY_ACHIEVED":
                disc_str = "; ".join(discrepancies) if discrepancies else "Kuch steps namukammal hain"
                rem_str = f" Tajveez: {remediation}" if remediation else ""
                return f"Hadaf Juzwi Taur Par Mukammal Hua: '{goal}'. Suboot: {ev_str}. Khala/Nuqs: {disc_str}.{rem_str}"
            elif verdict_val == "GOAL_UNFULFILLED":
                disc_str = "; ".join(discrepancies) if discrepancies else "Physical reality match nahi karti"
                rem_str = f" Tajveez: {remediation}" if remediation else ""
                return f"Hadaf Mukammal Nahi Hua: '{goal}'. Khala/Nuqs: {disc_str}.{rem_str}"
            else:
                return f"Hadaf Ki Verification Ghair-Yaqeeni Hai: '{goal}'. Physical suboot na-kafi hain."

        # Default English
        ev_str = ev_str if ev_str else "None"
        if verdict_val == "GOAL_ACHIEVED":
            return f"Goal Achieved: '{goal}'. Physical evidence: {ev_str}."
        elif verdict_val == "PARTIALLY_ACHIEVED":
            disc_str = "; ".join(discrepancies) if discrepancies else "Incomplete steps"
            rem_str = f" Remediation: {remediation}" if remediation else ""
            return f"Goal Partially Achieved: '{goal}'. Verified: {ev_str}. Discrepancies: {disc_str}.{rem_str}"
        elif verdict_val == "GOAL_UNFULFILLED":
            disc_str = "; ".join(discrepancies) if discrepancies else "Physical outcome not found"
            rem_str = f" Remediation: {remediation}" if remediation else ""
            return f"Goal Unfulfilled: '{goal}'. Discrepancies: {disc_str}.{rem_str}"
        else:
            return f"Verification Inconclusive for goal: '{goal}'. Insufficient physical signals."

    # ==========================================================================
    # BULLET #26: MULTI-STEP TASK MANAGEMENT & LIFECYCLE TRACKING
    # ==========================================================================

    def save_task_checkpoint(self, checkpoint: Any) -> None:
        """Saves active TaskCheckpoint in context (Bullet #26)."""
        self.task_checkpoint = checkpoint
        if checkpoint is not None:
            plan = getattr(checkpoint, "pending_plan", None)
            if plan and hasattr(plan, "milestones") and plan.milestones:
                self.active_milestones = list(plan.milestones)

    def get_task_checkpoint(self) -> Any | None:
        """Returns the active TaskCheckpoint or None (Bullet #26)."""
        return self.task_checkpoint

    def clear_task_checkpoint(self) -> None:
        """Flushes active TaskCheckpoint and resets pause requests (Bullet #26)."""
        self.task_checkpoint = None
        self.task_pause_requested = False

    def request_task_pause(self) -> None:
        """Sets cooperative in-flight task pause flag (Bullet #26)."""
        self.task_pause_requested = True

    def is_task_pause_requested(self) -> bool:
        """Returns True if task pause has been requested (Bullet #26)."""
        return self.task_pause_requested

    def clear_task_pause_request(self) -> None:
        """Clears cooperative task pause flag (Bullet #26)."""
        self.task_pause_requested = False

    def record_active_milestones(self, milestones: list[Any]) -> None:
        """Records active milestones for current multi-step task (Bullet #26)."""
        self.active_milestones = list(milestones)
        for m in milestones:
            self.milestone_history.append(m)

    def update_milestone_status(self, milestone_id: str, is_completed: bool, result_summary: str = "") -> None:
        """Updates completion status of a specific milestone (Bullet #26)."""
        import time as _time
        for m in self.active_milestones:
            m_id = getattr(m, "milestone_id", m.get("milestone_id") if isinstance(m, dict) else "")
            if m_id == milestone_id:
                if hasattr(m, "is_completed"):
                    m.is_completed = is_completed
                    if is_completed:
                        m.completed_at = _time.time()
                        if result_summary:
                            m.result_summary = result_summary
                elif isinstance(m, dict):
                    m["is_completed"] = is_completed
                    if is_completed:
                        m["completed_at"] = _time.time()
                        if result_summary:
                            m["result_summary"] = result_summary
                break

    def get_task_progress_summary(self, lang: str = "en") -> str:
        """
        Returns a quantitative human-readable progress summary (0%...100%) (Bullet #26).
        Answers queries like 'status', 'progress', 'kitna kaam hua'.
        """
        if not self.task_checkpoint and not self.active_milestones:
            return "Koi fa'al (active) multi-step task mojood nahi hai." if lang == "ur" else "No active multi-step task in progress."

        cp = self.task_checkpoint
        goal = getattr(cp, "task_goal", "Autonomous Task") if cp else "Autonomous Task"
        state = getattr(cp, "lifecycle_state", None) if cp else None
        state_str = state.value if hasattr(state, "value") else (str(state) if state else "IN_PROGRESS")
        progress = getattr(cp, "progress_percent", 0.0) if cp else 0.0

        total_milestones = len(self.active_milestones)
        completed_milestones = 0
        active_title = ""
        for m in self.active_milestones:
            is_comp = getattr(m, "is_completed", m.get("is_completed", False) if isinstance(m, dict) else False)
            if is_comp:
                completed_milestones += 1
            elif not active_title:
                active_title = getattr(m, "title", m.get("title", "") if isinstance(m, dict) else "")

        if total_milestones > 0 and not progress:
            progress = (completed_milestones / total_milestones) * 100.0

        if not active_title:
            active_title = "Completed" if progress >= 100.0 else "In Progress"

        plan = getattr(cp, "pending_plan", None) if cp else None
        remaining_steps = len(getattr(plan, "steps", [])) if plan else 0

        if lang == "ur":
            state_ur = {
                "NOT_STARTED": "Shuru Nahi Hua",
                "IN_PROGRESS": "Jaari Hai",
                "PAUSED": "Ruka Hua (Paused)",
                "RESUMING": "Dobara Shuru Ho Raha Hai",
                "COMPLETED": "Mukammal",
                "CANCELLED": "Mansookh (Cancelled)",
            }.get(state_str.upper(), state_str)
            return (
                f"Task '{goal}' ki taraqqi: {progress:.0f}% ({state_ur}). "
                f"{completed_milestones}/{total_milestones} marhalay mukammal. "
                f"Fa'al marhala: '{active_title}'. Baqi iqdamat: {remaining_steps}."
            )

        # Default English
        return (
            f"Task '{goal}' progress: {progress:.0f}% ({state_str.upper()}). "
            f"Milestones: {completed_milestones}/{total_milestones} completed. "
            f"Active stage: '{active_title}'. Remaining action(s): {remaining_steps}."
        )

    # ==========================================================================
    # BULLET #27: CROSS-DOMAIN PROBLEM SOLVING & DATA BRIDGING
    # ==========================================================================

