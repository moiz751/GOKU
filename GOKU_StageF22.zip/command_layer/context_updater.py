from __future__ import annotations
from command_layer.context_models import EntityType, TypedEntity
import gc
import json
import os
from pathlib import Path
import re
import time
from typing import TYPE_CHECKING, Any, Optional, Dict, List, Set, Tuple

if TYPE_CHECKING:
    from command_layer.context import SessionContext

from command_layer.semantic_model import (
    PlanMutationType,
    PlanDAGNode,
    PlanMutation,
    FailureType,
    AdaptiveStrategy,
    PlanAdaptation,
    RecoveryStatus,
    CompensationAction,
    RollbackLedger,
    ObservationType,
    StepObservation,
    EnvironmentSnapshot,
    OutcomeVerdict,
    OutcomeCriteria,
    OutcomeReport,
    TaskLifecycleState,
    TaskMilestone,
    TaskCheckpoint,
    DomainBridgeType,
    DomainBridgeLink,
    CrossDomainWorkflow,
    HorizonDepth,
    ExplorationNode,
    SearchFrontier,
    LongHorizonReport,
    HistoryQueryType,
    ExecutionTraceRecord,
    TraceSummary,
    FirewallVerdict,
    AdversarialAttackRecord,
)

from command_layer.context_references import ORDINAL_REFERENCES
def update_context_from_result(
    context: SessionContext,
    tool_name: str,
    args: dict[str, Any],
    result: dict[str, Any],
) -> None:
    """Updates session context after a tool call with typed tracking."""
    context.last_tool_result = result
    context.record_action(tool_name, args, result)
    if not result.get("success"):
        context.save_memory_to_disk()
        return

    is_ver = bool(result.get("verified", result.get("success", False)))
    now_ts = time.time()

    def _track(typed_ent: TypedEntity, domain_name: str | None = None) -> None:
        typed_ent.verified = is_ver
        typed_ent.timestamp = now_ts
        typed_ent.domain = domain_name
        context.record_typed_entity(typed_ent)
        if is_ver:
            context.last_verified_entity = typed_ent
        else:
            context.unverified_entities.append(typed_ent)
        if domain_name:
            context.last_domain = domain_name
            context.domain_timestamps[domain_name] = now_ts

    # CLI / Text Buffer / Calculator output extraction
    if any(k in result for k in ("stdout", "output", "cli_output", "console_output")):
        out_val = result.get("stdout") or result.get("output") or result.get("cli_output") or result.get("console_output")
        if out_val is not None:
            context.last_output = str(out_val).strip()
    if tool_name in ("calculator", "calculate", "calc") or "calculate" in tool_name or "calc" in tool_name:
        calc_val = result.get("result") or result.get("output") or result.get("answer") or result.get("value")
        if calc_val is not None:
            context.last_calculation = str(calc_val).strip()
            context.last_output = str(calc_val).strip()
            context.extracted_metrics["last_calculation"] = context.last_calculation
    elif tool_name in ("execute_system_command", "run_headless_shell", "execute_command", "run_command", "run_powershell", "cmd", "powershell", "execute_cli", "run_cli", "ping_host", "diagnose_network"):
        raw_stdout = result.get("stdout") if result.get("stdout") is not None else (result.get("output") or result.get("cli_output") or result.get("result") or result.get("message"))
        if raw_stdout is not None:
            out_val = str(raw_stdout).strip()
            context.last_output = out_val
            context.last_cli_output = out_val
            if not hasattr(context, "captured_values") or context.captured_values is None:
                context.captured_values = {}
            context.captured_values["output"] = out_val
            context.captured_values["last_cli_output"] = out_val
            if hasattr(context, "runtime_memory") and context.runtime_memory is not None:
                context.runtime_memory["output"] = out_val
                context.runtime_memory["last_cli_output"] = out_val
        else:
            out_val = None
        cmd_text = str(args.get("command") or args.get("cmd") or args.get("script") or args.get("host") or "").lower()
        if out_val:
            str_out = str(out_val)
            if "netstat" in cmd_text:
                context.extracted_metrics["netstat"] = str_out[:1000]
            elif "systeminfo" in cmd_text:
                context.extracted_metrics["systeminfo"] = str_out[:1000]
            elif "wmic" in cmd_text:
                context.extracted_metrics["wmic"] = str_out[:1000]
            elif "ipconfig" in cmd_text:
                context.extracted_metrics["ipconfig"] = str_out[:1000]

            # Phase C: Deep CLI Telemetry Parsing (Ping, Ipconfig, Netstat)
            try:
                from tools.cli_executor import parse_cli_telemetry
                parse_cli_telemetry(str_out, cmd_text, context=context)
            except Exception:
                pass

    # Structured file content extraction
    if tool_name in ("read_file", "read_file_text", "read_document"):
        content_val = result.get("content") or result.get("text") or result.get("data")
        if content_val is not None:
            context.last_read_content = str(content_val)

    # Phase B: Live Telemetry Extraction — screen, UI vision, terminal buffers
    # Pipe capture_screen dimensions and path into extracted_metrics for analytical queries
    if tool_name in ("capture_screen", "take_screenshot") and result.get("success"):
        scr_w = result.get("width") or result.get("screen_width")
        scr_h = result.get("height") or result.get("screen_height")
        scr_path = result.get("file_path") or result.get("path")
        if scr_w and scr_h:
            context.extracted_metrics["last_screenshot_size"] = f"{scr_w}x{scr_h}"
        if scr_path:
            context.extracted_metrics["last_screenshot_path"] = str(scr_path)

    # Pipe find_text_on_screen matches into extracted_metrics so analytical queries
    # can reference on-screen text without re-scanning the display
    if tool_name in ("find_text_on_screen",) and result.get("found"):
        matched = result.get("matched_text")
        x_coord = result.get("x")
        y_coord = result.get("y")
        if matched:
            context.extracted_metrics["last_found_ui_text"] = str(matched)
        if x_coord is not None and y_coord is not None:
            context.extracted_metrics["last_found_ui_coords"] = f"({x_coord}, {y_coord})"

    # Pipe click_element_by_text results — visual diff summary into metrics
    if tool_name in ("click_element_by_text", "click_ui_element") and result.get("success"):
        diff_summary = result.get("visual_diff") or ""
        if diff_summary:
            context.extracted_metrics["last_click_visual_diff"] = str(diff_summary)[:200]

    # Pipe send_keyboard_input text into last_output for terminal commands
    if tool_name in ("send_keyboard_input",) and result.get("success"):
        typed_text = result.get("text") or args.get("text") or ""
        is_terminal_cmd = bool(result.get("is_terminal") or args.get("press_enter"))
        if typed_text and is_terminal_cmd:
            context.last_output = str(typed_text).strip()
            # Classify well-known CLI telemetry commands
            low = typed_text.lower()
            if "netstat" in low:
                context.extracted_metrics["last_terminal_cmd"] = typed_text[:500]
            elif "ipconfig" in low:
                context.extracted_metrics["last_terminal_cmd"] = typed_text[:500]
            elif "systeminfo" in low:
                context.extracted_metrics["last_terminal_cmd"] = typed_text[:500]
            elif "tasklist" in low or "wmic" in low:
                context.extracted_metrics["last_terminal_cmd"] = typed_text[:500]


    # Folder operations
    if tool_name in ("open_folder", "create_folder", "rename_folder", "move_folder", "copy_folder"):
        path = result.get("path") or args.get("path") or args.get("destination")
        if path:
            str_path = str(path)
            context.last_active_directory = str_path
            context.last_referenced_directory = str_path
            context.parent_container = str_path
            context.record_entity(str_path)
            typed = TypedEntity(value=str_path, entity_type=EntityType.FOLDER)
            context.last_folder = typed
            context.last_selected_folder = typed
            _track(typed, "filesystem")

            if tool_name == "create_folder":
                context.last_created_directory = str_path
                context.last_created_item = typed
            elif tool_name == "open_folder":
                context.last_opened_directory = str_path
            elif tool_name == "copy_folder":
                context.last_copied_item = typed
            elif tool_name == "move_folder":
                context.last_moved_item = typed
            elif tool_name == "rename_folder":
                context.last_renamed_item = typed

    # File operations
    elif tool_name in ("open_file", "create_file", "write_file", "append_file", "save_file", "save_document", "save_active_document", "copy_file", "move_file", "rename_file", "read_file", "read_document", "get_file_info", "classify_file", "get_file_metadata"):
        path = result.get("path") or result.get("file_path") or args.get("path") or args.get("file_path") or args.get("destination") or args.get("save_to") or args.get("filepath")
        if path:
            str_path = str(path)
            context.last_referenced_file = str_path
            parent_dir = Path(str_path).parent.as_posix()
            context.last_active_directory = parent_dir
            context.parent_container = parent_dir
            context.record_entity(str_path)
            typed = TypedEntity(value=str_path, entity_type=EntityType.FILE)
            context.last_file = typed
            context.last_selected_file = typed
            _track(typed, "filesystem")

            if tool_name in ("write_file", "append_file", "save_file", "save_document", "save_active_document", "create_file") or args.get("save_to") or "save" in tool_name:
                if str_path not in context.saved_files:
                    context.saved_files.append(str_path)
                else:
                    context.saved_files.remove(str_path)
                    context.saved_files.append(str_path)
                if len(context.saved_files) > 50:
                    context.saved_files = context.saved_files[-50:]

            if tool_name == "create_file":
                context.last_created_file = str_path
                context.last_created_item = typed
            elif tool_name == "open_file":
                context.last_opened_file = str_path
            elif tool_name == "copy_file":
                context.last_copied_item = typed
            elif tool_name == "move_file":
                context.last_moved_item = typed
            elif tool_name == "rename_file":
                context.last_renamed_item = typed

    # Search operations
    elif tool_name in ("find_file", "search_files", "list_folder", "search_files_intelligent", "get_largest_files", "find_duplicate_files"):
        start_folder = args.get("start_folder") or args.get("location") or args.get("path")
        if start_folder:
            context.last_active_directory = str(start_folder)
            context.parent_container = str(start_folder)
        query_val = args.get("query") or args.get("name") or ""
        if query_val:
            context.last_search_query = TypedEntity(value=str(query_val), entity_type=EntityType.SEARCH_QUERY)

        matches = result.get("matches", []) or result.get("files", []) or result.get("items", [])
        if not matches and "duplicate_groups" in result:
            matches = [f for grp in result.get("duplicate_groups", []) for f in grp.get("files", [])]

        if matches and isinstance(matches, list):
            context.last_search_results = [str(m) for m in matches]
            context.last_search_results_type = EntityType.FILE
            first_match = str(matches[0])
            context.last_referenced_file = first_match
            typed = TypedEntity(value=first_match, entity_type=EntityType.FILE)
            context.last_file = typed
            context.last_selected_file = typed
            context.last_search_result = typed
            _track(typed, "filesystem")
            for m in matches[:5]:
                context.record_entity(str(m))
                context.record_typed_entity(TypedEntity(value=str(m), entity_type=EntityType.FILE, timestamp=now_ts, verified=is_ver))

    # Application & Process operations (Phase 4A & Phase 2 Part 3)
    elif tool_name in ("launch_app", "close_app", "restart_app", "focus_app", "is_app_running", "find_application", "get_application_status", "discover_applications"):
        app_name = (
            result.get("application") if isinstance(result.get("application"), str)
            else (
                result.get("application_name")
                or result.get("app_name")
                or (result.get("application", {}).get("name") if isinstance(result.get("application"), dict) else None)
                or args.get("name")
            )
        )
        if app_name:
            if tool_name == "is_app_running" and not result.get("running", True):
                pass
            else:
                str_app = str(app_name)
                if str_app.lower() in ("notepad", "chrome", "edge", "calculator", "paint"):
                    str_app = str_app.title()
                context.last_launched_application = str_app
                context.record_entity(str_app)
                typed = TypedEntity(value=str_app, entity_type=EntityType.APPLICATION)
                context.last_application = typed
                _track(typed, "application")
                if str_app.lower() in ("chrome", "edge", "firefox", "browser"):
                    typed_b = TypedEntity(value=str_app.lower(), entity_type=EntityType.BROWSER)
                    context.last_browser = typed_b
                    context.parent_container = str_app.lower()
                    _track(typed_b, "browser")

        # Track search results for ordinal references ("pehli wali", "first one")
        app_matches = result.get("applications") or result.get("matches")
        if app_matches and isinstance(app_matches, list):
            app_names = [a.get("name") for a in app_matches if isinstance(a, dict) and a.get("name")]
            if app_names:
                context.last_search_results = app_names
                context.last_search_results_type = EntityType.APPLICATION
                first_app = app_names[0]
                typed = TypedEntity(value=first_app, entity_type=EntityType.APPLICATION)
                context.last_application = typed
                _track(typed, "application")

        pid = result.get("pid")
        if not pid and "pids" in result and result["pids"]:
            pid = result["pids"][0]
        if pid:
            context.last_referenced_process = pid

    elif tool_name in ("find_process", "discover_running_processes", "get_processes", "get_top_processes", "get_process_status"):
        proc_names = []
        if "processes" in result and isinstance(result["processes"], list):
            proc_names = [p.get("name") for p in result["processes"] if isinstance(p, dict) and p.get("name")]
        elif "process" in result and isinstance(result["process"], dict) and result["process"].get("name"):
            proc_names = [result["process"]["name"]]
        elif "name" in result and isinstance(result.get("name"), str):
            proc_names = [result["name"]]

        if proc_names:
            context.last_search_results = proc_names
            context.last_search_results_type = EntityType.PROCESS
            first_p = proc_names[0]
            typed_proc = TypedEntity(value=first_p, entity_type=EntityType.PROCESS)
            context.last_process = typed_proc
            _track(typed_proc, "process")

        pids = result.get("pids")
        if pids and isinstance(pids, list):
            context.last_referenced_process = pids[0]
        elif result.get("pid"):
            context.last_referenced_process = result["pid"]

    # Windows Service operations
    elif tool_name in ("get_services", "get_running_services", "get_stopped_services", "find_service", "get_service_status"):
        srv_names = []
        if "services" in result and isinstance(result["services"], list):
            srv_names = [s.get("name") for s in result["services"] if isinstance(s, dict) and s.get("name")]
        elif "service" in result and isinstance(result["service"], dict) and result["service"].get("name"):
            srv_names = [result["service"]["name"]]
        elif "name" in result and isinstance(result.get("name"), str):
            srv_names = [result["name"]]

        if srv_names:
            context.last_search_results = srv_names
            context.last_search_results_type = EntityType.SERVICE
            first_srv = srv_names[0]
            typed_srv = TypedEntity(value=first_srv, entity_type=EntityType.SERVICE)
            context.last_service = typed_srv
            context.last_referenced_service = first_srv
            _track(typed_srv, "system")

    # Connected Device & Bluetooth operations
    elif tool_name in ("get_bluetooth_devices", "get_paired_bluetooth_devices", "get_connected_bluetooth_devices", "get_connected_devices", "get_usb_devices", "get_pnp_devices", "get_bluetooth_device_status"):
        dev_names = []
        if "devices" in result and isinstance(result["devices"], list):
            dev_names = [d.get("name") for d in result["devices"] if isinstance(d, dict) and d.get("name")]
        elif "device" in result and isinstance(result["device"], dict) and result["device"].get("name"):
            dev_names = [result["device"]["name"]]
        elif "name" in result and isinstance(result.get("name"), str):
            dev_names = [result["name"]]

        if dev_names:
            context.last_search_results = dev_names
            context.last_search_results_type = EntityType.DEVICE
            first_dev = dev_names[0]
            typed_dev = TypedEntity(value=first_dev, entity_type=EntityType.DEVICE)
            context.last_device = typed_dev
            context.last_bluetooth_device = typed_dev
            _track(typed_dev, "devices")

    # Storage & Drive operations
    elif tool_name in ("get_drives", "get_free_space", "get_drive_usage", "get_drive_status", "get_removable_drives"):
        drv_names = []
        if "drives" in result and isinstance(result["drives"], list):
            drv_names = [d.get("drive_letter") for d in result["drives"] if isinstance(d, dict) and d.get("drive_letter")]
        elif "drive" in result and isinstance(result["drive"], str):
            drv_names = [result["drive"]]
        elif args.get("drive"):
            drv_names = [str(args["drive"])]

        if drv_names:
            context.last_search_results = drv_names
            context.last_search_results_type = EntityType.DRIVE
            first_drv = drv_names[0]
            typed_drv = TypedEntity(value=first_drv, entity_type=EntityType.DRIVE)
            context.last_drive = typed_drv
            _track(typed_drv, "storage")

    # Network operations
    elif tool_name in ("get_network_interfaces", "get_wifi_status", "test_internet_connectivity", "ping_host", "get_local_ip", "get_default_gateway", "get_dns_servers", "get_network_status"):
        context.last_domain = "network"
        context.domain_timestamps["network"] = now_ts

    elif tool_name in ("get_active_window", "get_foreground_application"):
        if result.get("has_active_window") or result.get("application_name"):
            title = result.get("title") or result.get("window_title") or str(result.get("hwnd", "Active Window"))
            typed_w = TypedEntity(value=title, entity_type=EntityType.WINDOW, metadata=result)
            context.last_window = typed_w
            _track(typed_w, "gui")
            if result.get("application_name"):
                app_n = result["application_name"]
                typed_app = TypedEntity(value=app_n, entity_type=EntityType.APPLICATION)
                context.last_application = typed_app
                _track(typed_app, "application")
            if result.get("is_browser") and result.get("browser_name"):
                typed_b = TypedEntity(value=result["browser_name"], entity_type=EntityType.BROWSER, metadata={"key": result.get("browser_name")})
                context.last_browser = typed_b
                _track(typed_b, "browser")

    # Browser operations
    elif tool_name in ("open_browser_profile", "open_url", "search_web", "new_tab", "list_browser_profiles", "close_browser"):
        browser_name = result.get("browser") or args.get("browser", "chrome")
        typed_b = TypedEntity(value=str(browser_name), entity_type=EntityType.APPLICATION)
        context.last_browser = typed_b
        context.last_launched_application = str(browser_name)
        context.parent_container = str(browser_name)
        _track(typed_b, "browser")
        prof_name = result.get("profile_name") or args.get("profile_name")
        if prof_name:
            typed_prof = TypedEntity(value=str(prof_name), entity_type=EntityType.BROWSER_PROFILE)
            context.last_browser_profile = typed_prof
            _track(typed_prof, "browser")

    # Visual inspection & UI element operations (Phase 4C)
    elif tool_name in ("locate_ui_element", "click_ui_element", "inspect_screen"):
        el_name = result.get("name") or result.get("element_name") or args.get("query")
        if el_name:
            typed = TypedEntity(value=str(el_name), entity_type=EntityType.UI_ELEMENT, metadata=result)
            context.last_visual_element = typed
            context.record_entity(str(el_name))
            _track(typed, "gui")

    context.save_memory_to_disk()


VISUAL_REFERENCES = [
    r"\bis\s+button\s+par\b",
    r"\bus\s+button\s+par\b",
    r"\bis\s+icon\s+par\b",
    r"\bus\s+icon\s+par\b",
    r"\bis\s+element\s+par\b",
    r"\bus\s+element\s+par\b",
    r"\bthis\s+button\b",
    r"\bthat\s+button\b",
    r"\bthis\s+icon\b",
    r"\bthat\s+icon\b",
]
_COMPILED_VISUAL_REFERENCES = [re.compile(p, re.IGNORECASE) for p in VISUAL_REFERENCES]

_COMPILED_TYPO_FIXES = [
    (re.compile(r"\btaht\b", re.IGNORECASE), "that", r"\btaht\b"),
    (re.compile(r"\blasts\b", re.IGNORECASE), "last", r"\blasts\b"),
    (re.compile(r"\bengrybirds?\b", re.IGNORECASE), "angry birds", r"\bengrybirds?\b"),
    (re.compile(r"\bengry\s+birds?\b", re.IGNORECASE), "angry birds", r"\bengry\s+birds?\b"),
    (re.compile(r"\bchorme\b", re.IGNORECASE), "chrome", r"\bchorme\b"),
    (re.compile(r"\bnotpad\b", re.IGNORECASE), "notepad", r"\bnotpad\b"),
]



def init_session_immunity(ctx: SessionContext | None = None) -> None:
    """
    Scans running processes and top-level HWNDs to populate immune_pids and immune_hwnds.
    Protects user-opened browser sessions, IDE instances, explorer windows, and terminal sessions
    from accidental termination or window closure.
    """
    if ctx is None:
        from command_layer.context import session_context
        ctx = session_context
    if ctx is None:
        return

    try:
        import psutil
        for proc in psutil.process_iter(['pid', 'name']):
            try:
                pname = (proc.info.get('name') or '').lower()
                pid = proc.info.get('pid')
                if pid and pid > 4:
                    if any(target in pname for target in [
                        'chrome', 'msedge', 'edge', 'firefox', 'code', 'cursor',
                        'antigravity', 'explorer', 'devenv', 'terminal', 'powershell', 'cmd'
                    ]):
                        ctx.immune_pids.add(pid)
            except Exception:
                pass
    except Exception:
        pass

    try:
        import win32gui
        import win32process
        def enum_win_cb(hwnd, _):
            try:
                if win32gui.IsWindow(hwnd) and win32gui.IsWindowVisible(hwnd):
                    title = (win32gui.GetWindowText(hwnd) or '').strip()
                    if title:
                        ctx.immune_hwnds.add(int(hwnd))
                        _, w_pid = win32process.GetWindowThreadProcessId(hwnd)
                        if w_pid and w_pid > 4:
                            ctx.immune_pids.add(int(w_pid))
            except Exception:
                pass
            return True

        win32gui.EnumWindows(enum_win_cb, None)
    except Exception:
        pass


# Global singleton instance for session


def compact_working_memory(max_steps: int = 10) -> int:
    """Module-level helper to compact working memory of active session_context (Bullet #28)."""
    from command_layer.context import session_context
    return session_context.compact_working_memory(max_steps=max_steps)

def get_frontier_summary(lang: str = "en") -> str:
    """Module-level helper to get frontier summary from active session_context (Bullet #28)."""
    from command_layer.context import session_context
    return session_context.get_frontier_summary(lang=lang)

def clear_frontier_state() -> None:
    """Module-level helper to clear frontier state from active session_context (Bullet #28)."""
    from command_layer.context import session_context
    session_context.clear_frontier_state()

def record_turn_trace(record: Any) -> None:
    """Module-level helper to record a turn trace into active session_context (Bullet #29)."""
    from command_layer.context import session_context
    session_context.record_turn_trace(record)

def get_failed_tool_actions(time_window_seconds: float = 600.0) -> set[tuple[str, str]]:
    """Module-level helper to get failed tool actions from active session_context (Bullet #29)."""
    from command_layer.context import session_context
    return session_context.get_failed_tool_actions(time_window_seconds=time_window_seconds)

def get_historical_metric(metric_name: str) -> list[tuple[float, Any]]:
    """Module-level helper to get historical telemetry from active session_context (Bullet #29)."""
    from command_layer.context import session_context
    return session_context.get_historical_metric(metric_name)

def compare_historical_metric(metric_name: str, current_value: Any = None) -> dict[str, Any]:
    """Module-level helper to compare historical telemetry in active session_context (Bullet #29)."""
    from command_layer.context import session_context
    return session_context.compare_historical_metric(metric_name, current_value=current_value)

def get_trace_summary() -> Any:
    """Module-level helper to get trace summary from active session_context (Bullet #29)."""
    from command_layer.context import session_context
    return session_context.get_trace_summary()

def get_history_explanation(query_type: Any, param: str = "", lang: str = "en") -> str:
    """Module-level helper to get history explanation from active session_context (Bullet #29)."""
    from command_layer.context import session_context
    return session_context.get_history_explanation(query_type, param=param, lang=lang)

def record_adversarial_attack(record: Any) -> None:
    """Module-level helper to record an adversarial attack in active session_context (Bullet #30)."""
    from command_layer.context import session_context
    session_context.record_adversarial_attack(record)
