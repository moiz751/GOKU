from __future__ import annotations
import os
from pathlib import Path
import re
import sys
import time
from typing import Any, Optional, Union, List, Dict, Tuple
from dataclasses import dataclass, field

from brain.planner import (
    Plan,
    PlanStep,
    StructuredIntent,
    create_plan_from_decision,
    decompose_compound_command,
    parse_compound_request,
    resolve_step_variables,
    resolve_step_variables_with_guard,
    inject_plan_prerequisites,
    prune_plan_steps,
    build_hypothesis_investigation_plan,
    build_root_cause_investigation_plan,
    parse_conditional_goal,
    synthesize_adaptive_replan,
    decompose_into_milestones,
    restore_plan_from_checkpoint,
    build_cross_domain_plan,
    apply_cross_domain_transformation,
    build_long_horizon_exploration_plan,
    decompose_long_horizon_goal,
    compute_state_hash,
    detect_state_cycle,
    heuristic_node_score,
    expand_exploration_frontier,
    select_next_frontier_node,
    apply_reflective_history_pruning,
)
from command_layer.cognitive_reasoner import CognitiveReasoner
from command_layer.context import (
    EntityType,
    TypedEntity,
    ORDINAL_REFERENCES,
    SessionContext,
    resolve_references,
    session_context,
    update_context_from_result,
)
from command_layer.semantic_model import (
    SemanticDomain,
    SemanticAction,
    CommandIntent,
    AmbiguityType,
    ClarificationRequest,
    SymptomCategory,
    SituationType,
    ConfidenceTier,
    RiskTier,
    ConfidenceScore,
    ConfirmationRequest,
    FailureType,
    AdaptiveStrategy,
    PlanAdaptation,
    TaskLifecycleState,
    TaskMilestone,
    TaskCheckpoint,
    DomainBridgeType,
    DomainBridgeLink,
    CrossDomainWorkflow,
    HorizonDepth,
    ExplorationNode,
    SearchFrontier,
    LongHorizonReport,
    HistoryQueryType,
    ExecutionTraceRecord,
    TraceSummary,
)
from command_layer.semantic_parser import (
    parse_semantic_intent,
    create_plan_from_intent,
    resolve_in_turn_correction,
    strip_conversational_noise,
    split_compound_clauses,
    detect_symptom_category,
)
from command_layer.firewall import validate_tool_against_firewall, pre_execution_semantic_check, validate_long_horizon_action
from command_layer.state_machine import agent_state
from command_layer.validator import validate_and_sanitize_tool_arguments
from command_layer.lexer import UniversalLexer
from brain.runtime_bus import RuntimePipingBus
from security.state import confirmation_manager
from tools.utils.app_resolver import (
    APP_ALIASES,
    get_canonical_app_name,
    resolve_app,
)
from tools.utils.target_resolver import TargetType, resolve_universal_target, disambiguate_multi_candidates
from command_layer.router_base import (
    Step,
    run_tool_call,
    resolve_system_canonical_path,
    verify_post_recovery,
    verify_semantic_outcome,
    capture_environment_snapshot,
    capture_step_observation,
    detect_environment_drift,
    _entity_val,
    get_all_schemas,
    KNOWN_SITE_KEYS,
    KNOWN_APP_NAMES,
    _has_file_extension,
    _normalize_resolved_path,
    _is_conversational_folder_path,
)
from security.safety_firewall import is_safe_readonly_operation
from security.confirm import RISKY_TOOLS
from command_layer.decomposer import count_action_verbs
from brain.workflow_orchestrator import orchestrate_compound_workflow
from tools.browser import sanitize_search_query
from tools.search import parse_search_grammar
import executor.verifier
import executor.executor

from command_layer.router_sanitizer import (
    _isolate_browser_context,
    prune_negated_steps,
    sanitize_action_query,
    sanitize_url,
    _canonicalize_plan_tools,
    sanitize_ui_target,
    extract_clean_search_query,
)
from command_layer.router_cli_parser import (
    translate_cli_command,
    sanitize_cli_command,
    extract_pure_text_payload,
    parse_sequential_keyboard_actions,
    is_standalone_navigation_request,
    resolve_temporal_order,
    strip_idiomatic_conditions,
)
from command_layer.router_confidence import (
    determine_risk_tier,
    format_uncertainty_response,
    compute_command_confidence,
    synthesize_cross_domain_report,
    synthesize_long_horizon_report,
    get_conversational_response,
)

def _classify_and_parse_command(text: str, context: SessionContext | None = None, is_compound_root: bool = True) -> Plan | None:
    from command_layer.router_classifier_core import _classify_and_parse_command as _real_fn
    return _real_fn(text, context, is_compound_root)

def classify_device_intents_2(text: str, context: SessionContext | None = None, is_compound_root: bool = True) -> Plan | None:
    from command_layer.decomposer import count_action_verbs
    from brain.workflow_orchestrator import orchestrate_compound_workflow
    from tools.browser import sanitize_search_query
    from tools.search import parse_search_grammar
    from security.safety_firewall import is_safe_readonly_operation
    from security.confirm import RISKY_TOOLS
    cleaned = re.sub(r'[\x00-\x1f\x7f]+$', '', text).strip()
    cleaned = re.sub(r'[\x13\x03\x1b]', '', cleaned).strip()
    raw_lower = cleaned.lower()
    lower = text.lower()
    folder_ref_m = re.search(r"folder\s+'([^']+)'", text)
    file_ref_m = re.search(r"file\s+'([^']+)'", text)
    text_unwrapped = re.sub(r'[\'"]([^\'"]+)[\'"]', r'\1', text)
    try:
        symptom_cat, situation_type, symptom_entities = detect_symptom_category(raw_lower)
    except Exception:
        symptom_cat, situation_type, symptom_entities = SymptomCategory.NONE, SituationType.NORMAL, []
    _p2_is_compound_guard = False
    # -------------------------------------------------------------
    # 0.68 CONTEXTUAL PRONOUN RESOLUTION FOR ENTITIES
    # -------------------------------------------------------------
    matched_ord_idx = None
    for ord_pat, ord_idx in ORDINAL_REFERENCES:
        if re.search(ord_pat, lower) or re.search(ord_pat, raw_lower):
            matched_ord_idx = ord_idx
            break

    if matched_ord_idx is not None or any(w in lower for w in ["iska", "uska", "pehli wali", "first one", "is ka", "us ka", "ye drive", "is drive", "ye service", "is service", "us app", "is app", "ye app", "wo app", "woh app", "this app"]) or any(w in raw_lower for w in ["iska", "uska", "pehli wali", "first one", "is ka", "us ka", "us app", "is app", "ye app", "wo app", "woh app", "this app"]):
        if context and (context.last_search_results_type == EntityType.APPLICATION or context.last_application) and "process" in lower:
            if matched_ord_idx is not None and context and context.last_search_results:
                app_n = context.last_search_results[min(matched_ord_idx, len(context.last_search_results) - 1)]
            else:
                app_n = (context.last_search_results[0] if context and context.last_search_results and context.last_search_results_type == EntityType.APPLICATION else None) or \
                        (_entity_val(context.last_application) if context and context.last_application else "Notepad")
            return Plan(steps=[PlanStep(step=1, tool="find_process", args={"query": app_n})], explanation=f"Found process instance for active application '{app_n}'.")

        has_active_app = context and (context.last_search_results_type == EntityType.APPLICATION or (context.last_application and not context.last_search_results_type))
        if not has_active_app:
            if context and (context.last_search_results_type == EntityType.SERVICE or context.last_service) and any(w in lower for w in ["status", "chal rahi", "startup", "info"]):
                srv_n = _entity_val(context.last_service) if context.last_service else (context.last_search_results[0] if context.last_search_results else "wuauserv")
                return Plan(steps=[PlanStep(step=1, tool="get_service_status", args={"name": srv_n})], explanation=f"Retrieved contextual status for service '{srv_n}'.")
            if context and (context.last_search_results_type == EntityType.PROCESS or context.last_process) and any(w in lower for w in ["process", "status", "pid", "memory", "cpu"]):
                proc_n = _entity_val(context.last_process) if context.last_process else (context.last_search_results[0] if context.last_search_results else "chrome.exe")
                return Plan(steps=[PlanStep(step=1, tool="get_process_status", args={"name_or_pid": proc_n})], explanation=f"Retrieved contextual process telemetry for '{proc_n}'.")
            if context and (context.last_search_results_type == EntityType.DRIVE or context.last_drive) and any(w in lower for w in ["full", "usage", "free space", "space", "khali"]):
                drv_n = _entity_val(context.last_drive) if context.last_drive else (context.last_search_results[0] if context.last_search_results else "C:")
                if "full" in lower or "usage" in lower:
                    return Plan(steps=[PlanStep(step=1, tool="get_drive_usage", args={"drive": drv_n})], explanation=f"Retrieved drive usage for contextual drive '{drv_n}'.")
                return Plan(steps=[PlanStep(step=1, tool="get_free_space", args={"drive": drv_n})], explanation=f"Retrieved free space for contextual drive '{drv_n}'.")

    # -------------------------------------------------------------
    # 0.69 CROSS-DOMAIN GENERALIZED ACTIVE / STATUS DISPATCHER
    # Matches novel phrasing: "check whether <X> is active", "<X> active hai ya nahi", "pata karo <X> alive hai"
    # -------------------------------------------------------------
    # Questions about "what is open/in front" are browser/foreground-state queries, not "is <app> running" probes.
    if re.search(r'^\s*(?:what|which)\s+(?:web\s*)?(?:site|page|url)\s+(?:is|am\s+i)\s+(?:open|on|viewing|using)\b', raw_lower):
        return Plan(steps=[PlanStep(step=1, tool="get_current_browser_page", args={})], explanation="Read the page currently open in the browser.")
    if re.search(r'^\s*(?:what|which)\s+(?:application|app|program)\s+is\s+(?:active|in\s+front|focused|in\s+the\s+foreground)\b', raw_lower):
        return Plan(steps=[PlanStep(step=1, tool="get_foreground_application", args={})], explanation="Read the foreground application.")
    if re.search(r'^\s*which\s+browser\s+(?:is|am\s+i)\s+(?:open|active|using)\b', raw_lower):
        return Plan(steps=[PlanStep(step=1, tool="get_active_browser", args={})], explanation="Identified the active browser.")

    active_m = (
        re.search(r'\b(?:check\s+whether|check\s+if|pata\s+karo|dekh(?:na)?\s+zara|see\s+if|verify\s+if|wonder\s+if|is)\s+([a-zA-Z0-9_\-\s]+?)\s+(?:is\s+)?(?:currently\s+)?(?:active|running|alive|open|chal\s+raha\s+hai|chal\s+rahi\s+hai)\b', raw_lower)
        or re.search(r'\b([a-zA-Z0-9_\-\s]+?)\s+(?:active|alive|chal\s+raha|chal\s+rahi)\s+hai\s+ya\s+nahi\b', raw_lower)
        or re.search(r'\b([a-zA-Z0-9_\-\s]+?)\s+is\s+(?:currently\s+)?(?:open|running|active|alive)\b', raw_lower)
    )
    if active_m and not any(w in raw_lower for w in ["dialog", "window", "tab", "file", "folder", "drive", "disk", "running hot", "garam", "hot", "then", "warna", "otherwise", "else"]):
        target_ent = active_m.group(1).strip()
        target_ent = re.sub(r'\b(?:check|whether|if|pata|karo|dekhna|zara|is|the|mera|meri|abhi|system\s+pe|system\s+par|currently|in\s+background)\b', '', target_ent).strip()
        
        # 1. WiFi / Wireless
        if any(k in target_ent for k in ["wifi", "wi-fi", "wireless", "internet"]):
            return Plan(steps=[PlanStep(step=1, tool="get_wifi_status", args={})], explanation="Retrieved active Wi-Fi status.")
        
        # 2. Bluetooth
        if "bluetooth" in target_ent:
            return Plan(steps=[PlanStep(step=1, tool="get_bluetooth_status", args={})], explanation="Retrieved active Bluetooth status.")
            
        # 3. Service
        if "service" in target_ent or target_ent.lower() in ("wuauserv", "spooler", "bits", "dnscache"):
            srv_n = re.sub(r'\b(?:service|services)\b', '', target_ent).strip() or "wuauserv"
            return Plan(steps=[PlanStep(step=1, tool="get_service_status", args={"name": srv_n})], explanation=f"Retrieved status for service '{srv_n}'.")
            
        # 4. Process
        if "process" in target_ent:
            proc_n = re.sub(r'\b(?:process|processes)\b', '', target_ent).strip()
            for common_p in ["python", "chrome", "notepad", "calculator", "edge", "cmd", "powershell", "explorer"]:
                if common_p in proc_n.lower():
                    proc_n = common_p
                    break
            return Plan(steps=[PlanStep(step=1, tool="find_process", args={"query": proc_n})], explanation=f"Checked process instance for '{proc_n}'.")
            
        # 5. Application
        for app in sorted(KNOWN_APP_NAMES, key=len, reverse=True):
            if re.search(rf'\b{re.escape(app)}\b', target_ent):
                app_val = app.title() if app.lower() in ("notepad", "chrome", "edge", "calculator", "paint", "wordpad") else app
                return Plan(steps=[PlanStep(step=1, tool="is_app_running", args={"name": app_val})], explanation=f"Checked if {app_val} is running.")
                
        if target_ent and target_ent.lower() not in ("system", "computer", "pc", "laptop", "machine"):
            return Plan(steps=[PlanStep(step=1, tool="is_app_running", args={"name": target_ent.title()})], explanation=f"Checked if {target_ent} is running.")

    # -------------------------------------------------------------
    # -0.3 Multi-Adapter & Radio Band Conflict Analyzer
    if any(p in raw_lower for p in [
        "diagnose multi adapter conflict", "multi adapter conflict", "adapter conflict",
        "scan wifi 2.4ghz vs 5ghz", "scan wifi 2.4ghz", "wifi 2.4ghz vs 5ghz",
        "2.4ghz vs 5ghz", "band compatibility", "wifi band conflict", "adapter routing conflict"
    ]) or (
        ("adapter" in raw_lower or "wifi" in raw_lower or "wi-fi" in raw_lower)
        and any(w in raw_lower for w in ["conflict", "2.4ghz", "5ghz", "metric collision", "multi adapter", "multi-adapter"])
    ):
        return Plan(steps=[PlanStep(step=1, tool="analyze_multi_adapter_and_bands", args={})], explanation="Audited multi-adapter routing metrics and 2.4GHz vs 5GHz band compatibility.")

    # -0.25 ARP Cache Audit
    if any(p in raw_lower for p in ["audit arp cache", "arp cache", "check arp", "scan arp"]):
        return Plan(steps=[PlanStep(step=1, tool="diagnose_network_health", args={})], explanation="Audited ARP cache and network interface health.")

    # -0.2 Ultra-Deep Hardware/Service Wi-Fi Stack Diagnoser & Auto-Healer
    if any(p in raw_lower for p in [
        "auto fix wifi stack", "remediate and repair wifi connection",
        "fix wifi stack", "repair wifi stack", "remediate wifi stack"
    ]):
        return Plan(steps=[PlanStep(step=1, tool="remediate_wifi_stack", args={})], explanation="Executed autonomous Wi-Fi stack remediation.")

    if any(p in raw_lower for p in [
        "why is wifi not showing", "deep audit wifi hardware and services",
        "check wifi driver error and wlan service", "wifi not showing"
    ]):
        return Plan(steps=[PlanStep(step=1, tool="audit_wifi_hardware_and_services", args={})], explanation="Audited Wi-Fi hardware, WLAN AutoConfig service, driver errors, and RF kill-switch.")

    # -0.1 Deep Wi-Fi Spectrum Scanner & Latency Engine
    if any(p in raw_lower for p in [
        "deep scan wifi", "scan wifi spectrum", "check wifi signal interference",
        "full network latency scan", "fix and scan wifi adapter"
    ]):
        return Plan(steps=[PlanStep(step=1, tool="deep_scan_wifi_spectrum", args={})], explanation="Executed deep Wi-Fi spectrum audit, ping jitter analysis, and adapter recovery check.")

    if any(p in raw_lower for p in [
        "fix wifi", "repair wifi", "fix network", "repair network", "restart router",
        "change dns", "reset network", "network reset karo", "wifi reset karo"
    ]):
        return Plan(is_direct_message=True, message_text="Network modification or reset operations are restricted for safety and security; only read-only diagnostics are permitted.")

    # 0. Deep Network & Wi-Fi Diagnostics
    if any(p in raw_lower for p in [
        "diagnose wifi", "check network problem", "wifi problem analysis",
        "network scan karo", "find wifi problem", "wifi problem", "diagnose network health"
    ]):
        return Plan(steps=[PlanStep(step=1, tool="diagnose_network_health", args={})], explanation="Executed deep hybrid network and Wi-Fi diagnostic health audit.")

    # 0.1 End-to-End Network Diagnostics
    if any(p in raw_lower for p in [
        "network diagnose", "diagnose network", "diagnose my network", "diagnose my internet",
        "why is my internet not working", "network ka masla", "internet ka masla",
        "network problem", "network issue"
    ]):
        return Plan(steps=[PlanStep(step=1, tool="diagnose_network", args={})], explanation="Executed end-to-end network diagnostic suite.")

    # 1. Wi-Fi SSID
    if ("ssid" in raw_lower or "wifi name" in raw_lower or "wifi ka naam" in raw_lower or "mera wifi konsa hai" in raw_lower or "what wifi" in raw_lower or "kon se wifi se" in raw_lower) and not any(w in raw_lower for w in ["signal", "strength", "settings"]):
        return Plan(steps=[PlanStep(step=1, tool="get_wifi_ssid", args={})], explanation="Retrieved active Wi-Fi SSID.")

    # 2. Wi-Fi Signal
    if any(p in raw_lower for p in ["wifi signal", "wifi strength", "signal kitna hai", "signal kitni thi", "how strong is my wifi", "signal check karo", "strength batao", "signal strength", "signal quality"]):
        return Plan(steps=[PlanStep(step=1, tool="get_wifi_signal", args={})], explanation="Retrieved Wi-Fi signal quality.")

    # 3. Wi-Fi Status
    is_wifi_entity = (
        any(w in raw_lower for w in ["wifi", "wi-fi", "wireless"])
        or ("network" in raw_lower and any(w in raw_lower for w in ["wireless", "se juda", "se connected", "juda hua", "laga hua"]))
    )
    is_wifi_status_intent = (
        any(p in raw_lower for p in [
            "check wifi", "wifi check", "status", "connected", "connection", "laga hua", "juda hua",
            "active", "chal raha", "chal rha", "chal rhi", "theek hai", "state", "disconnect mat", "sirf status"
        ])
        or "wireless adapter" in raw_lower
        or raw_lower.startswith("check ")
        or raw_lower.endswith(" check")
        or re.match(r'^\s*(?:show|display)\s+(?:my\s+|the\s+)?(?:wi-?fi|wireless)\s*[?.!]*\s*$', raw_lower)
    )
    if is_wifi_entity and is_wifi_status_intent and not any(w in raw_lower for w in ["section", "settings kholo", "open settings", "signal", "ssid", "name", "speed", "diagnose", "problem", "issue", "reset", "repair"]):
        return Plan(steps=[PlanStep(step=1, tool="get_wifi_status", args={})], explanation="Retrieved active Wi-Fi status.")

    # 4. Internet Connectivity
    if any(p in raw_lower for p in [
        "is my internet working", "check my internet", "internet chal raha hai", "mera internet check karo",
        "internet connectivity test karo", "test connectivity", "internet check karo", "internet connected hai",
        "am i connected to internet", "internet connectivity", "internet access", "internet reachability", "reachability",
        "outbound internet", "internet connection", "internet check", "internet actually connected", "actually connected"
    ]) and not any(w in raw_lower for w in ["slow", "lag", "diagnose", "ping"]):
        return Plan(steps=[PlanStep(step=1, tool="test_internet_connectivity", args={})], explanation="Tested internet connectivity.")

    # 5. Local IP Address
    if any(p in raw_lower for p in [
        "what is my ip", "what's my ip", "show my ip", "show local ip", "mera ip batao",
        "mera ip address batao", "ip address dikhao", "ip batao", "ip check karo", "apna ip batao", "local ip"
    ]) and not ("router" in raw_lower or "gateway" in raw_lower or "dns" in raw_lower):
        return Plan(steps=[PlanStep(step=1, tool="get_local_ip", args={})], explanation="Retrieved local IP address.")

    # 6. Default Gateway
    is_save_cmd = bool(re.search(r'\b(?:save|save_active_document|save_document|write_file)\b', raw_lower) and any(w in raw_lower for w in ["to", "file", "document", ":\\", ":/"] or _has_file_extension(raw_lower)))
    if not is_save_cmd and any(p in raw_lower for p in [
        "what's my gateway", "what is my default gateway", "gateway batao", "default gateway batao",
        "router ka ip kya hai", "router ip batao", "gateway ip batao", "show gateway", "default gateway",
        "gateway check karo", "check gateway", "gateway check", "gateway status", "gateway"
    ]):
        if not re.search(r'gateway[^\s]*\.[a-zA-Z0-9]+', raw_lower):
            return Plan(steps=[PlanStep(step=1, tool="get_default_gateway", args={})], explanation="Retrieved default gateway.")

    # 7. DNS Servers
    if any(p in raw_lower for p in [
        "what's my dns", "what dns am i using", "show dns", "check dns", "dns batao", "dns check karo",
        "dns servers batao", "show dns servers", "dns working hai", "dns servers", "dns status",
        "dns resolution speed", "dns speed", "dns resolution"
    ]) or ("dns" in raw_lower and any(w in raw_lower for w in ["speed", "resolution"])):
        return Plan(steps=[PlanStep(step=1, tool="get_dns_servers", args={})], explanation="Retrieved DNS server configuration.")

    # 8. Network Interfaces / Adapters
    if any(p in raw_lower for p in [
        "show network interfaces", "show network adapters", "list network adapters",
        "network adapters batao", "network interfaces batao", "network interface check karo",
        "show adapters", "adapters batao", "network adapters", "network interfaces"
    ]):
        return Plan(steps=[PlanStep(step=1, tool="get_network_interfaces", args={})], explanation="Enumerated network interfaces.")

    # 9. General Network Status
    if any(p in raw_lower for p in [
        "check network", "show network information", "show connection status", "network status batao",
        "network information do", "network check karo", "overall network status", "network summary",
        "test network connectivity", "network connectivity", "test network"
    ]) and not any(w in raw_lower for w in ["diagnose", "reset", "repair"]):
        return Plan(steps=[PlanStep(step=1, tool="get_network_status", args={})], explanation="Retrieved overall network status.")

    # 10. Ping Host
    # Do not let trailing substrings or document save commands (e.g. save to C:\reports\ping_telemetry.txt) trigger ping_host
    is_save_cmd_ping = bool(
        re.search(r'\b(?:save|save_active_document|save_document|write_file)\b', raw_lower)
        and (any(w in raw_lower for w in ["to", "file", "document", ":\\", ":/"]) or _has_file_extension(raw_lower))
    )
    if not is_save_cmd_ping and (re.search(r'\bping\b', raw_lower) or "latency to" in raw_lower):
        host_m = re.search(r'\b(?:ping\s+(?:karo\s+)?([a-zA-Z0-9\.\-]+)|([a-zA-Z0-9\.\-]+)\s+(?:ko|par)\s+ping|latency to\s+([a-zA-Z0-9\.\-]+))\b', raw_lower)
        target_h = "google.com"
        if host_m:
            target_h = host_m.group(1) or host_m.group(2) or host_m.group(3) or "google.com"
            target_h = target_h.strip()
        else:
            cand_tokens = [t.strip("?,.!") for t in raw_lower.split() if "." in t and not t.endswith(".py") and not t.endswith(".txt")]
            if cand_tokens:
                target_h = cand_tokens[0]
        if target_h.lower() in {"chalao", "karo", "do", "kro", "karna", "test", "check", "run", "batao", "dikhao", "lagao", "internet", "host"}:
            target_h = "google.com"
        elif target_h.lower() == "google":
            target_h = "google.com"
        elif target_h.lower() == "cloudflare":
            target_h = "1.1.1.1"
        return Plan(steps=[PlanStep(step=1, tool="ping_host", args={"host": target_h})], explanation=f"Pinged host {target_h}.")

    # -------------------------------------------------------------
    # 0.8 BLUETOOTH / HOTSPOT / CONNECTED DEVICES INTENTS (Phase 2 Part 5)
    # -------------------------------------------------------------
    if any(p in raw_lower for p in [
        "turn bluetooth on", "turn bluetooth off", "enable bluetooth", "disable bluetooth",
        "connect mouse", "disconnect headset", "pair device", "unpair device",
        "enable hotspot", "disable hotspot", "remove bluetooth device", "bluetooth band karo", "bluetooth on karo",
        "hotspot on karo", "hotspot band karo", "disconnect wifi", "turn off wifi", "disable wifi", "wifi disconnect", "turn wifi off"
    ]) and not any(neg in raw_lower for neg in ["mat", "don't", "dont", "do not", "never", "without"]):
        return Plan(is_direct_message=True, message_text="Network and device state modification is restricted for safety and security; only read-only diagnostics are permitted.")

    # 1. Specific Bluetooth Device Status
    if (
        (any(w in raw_lower for w in ["connected", "connected hai", "is my", "is the", "is keyboard", "buds connected", "kya connected hai", "check", "status", "batao", "dikhao", "link hai", "link", "linked"])
         or raw_lower.startswith("check "))
        and any(d in raw_lower for d in ["mouse", "headset", "headphones", "keyboard", "earbuds", "buds", "speaker"])
        and not any(w in raw_lower for w in ["cursor", "move", "pattern", "wheel", "scroll", "clicks", "located", "where is", "darmiyan", "kahan pe", "kahan hai"])
    ):
        dev_cand = "mouse" if "mouse" in raw_lower else ("headset" if ("headset" in raw_lower or "headphones" in raw_lower) else ("keyboard" if "keyboard" in raw_lower else ("buds" if ("buds" in raw_lower or "earbuds" in raw_lower) else "device")))
        return Plan(steps=[PlanStep(step=1, tool="get_bluetooth_device_status", args={"device": dev_cand})], explanation=f"Checked Bluetooth device status for '{dev_cand}'.")

    # 2. Bluetooth Status
    if (
        any(p in raw_lower for p in [
            "check bluetooth", "is bluetooth on", "is bluetooth enabled", "show bluetooth status",
            "bluetooth status", "bluetooth on hai", "bluetooth check karo", "bluetooth chal raha hai",
            "bluetooth ka status batao", "bluetooth enabled hai", "mera bluetooth check karo"
        ])
        or ("bluetooth" in raw_lower and any(w in raw_lower for w in ["active", "is active", "chal raha", "enabled", "on hai", "status", "check"]))
    ) and not any(w in raw_lower for w in ["devices", "device", "paired", "connected"]):
        return Plan(steps=[PlanStep(step=1, tool="get_bluetooth_status", args={})], explanation="Retrieved Bluetooth status.")

    # 3. Paired Bluetooth Devices
    if any(p in raw_lower for p in [
        "show paired bluetooth devices", "which bluetooth devices are paired", "bluetooth ke paired devices dikhao",
        "paired devices batao", "paired bluetooth devices", "bluetooth paired devices", "paired devices"
    ]):
        return Plan(steps=[PlanStep(step=1, tool="get_paired_bluetooth_devices", args={})], explanation="Listed paired Bluetooth devices.")

    # 4. Connected Bluetooth Devices
    if (
        any(p in raw_lower for p in [
            "what bluetooth devices are connected", "show connected bluetooth devices", "bluetooth par kya connected hai",
            "bluetooth se kya connected hai", "bluetooth se konsa device connected hai", "connected bluetooth devices"
        ])
        or ("bluetooth" in raw_lower and any(w in raw_lower for w in ["connected", "juda hua", "jude"]) and any(w in raw_lower for w in ["device", "devices", "kya", "konsa", "koi"]))
    ):
        return Plan(steps=[PlanStep(step=1, tool="get_connected_bluetooth_devices", args={})], explanation="Listed connected Bluetooth devices.")

    # 5. All Bluetooth Devices
    if any(p in raw_lower for p in [
        "show bluetooth devices", "find bluetooth devices", "scan bluetooth devices", "bluetooth devices dikhao",
        "bluetooth devices find karo", "bluetooth par devices", "bluetooth devices batao", "list bluetooth devices", "bluetooth devices"
    ]):
        return Plan(steps=[PlanStep(step=1, tool="get_bluetooth_devices", args={})], explanation="Listed all Bluetooth devices.")

    # 6. Mobile Hotspot
    if any(p in raw_lower for p in [
        "is mobile hotspot on", "is hotspot on", "check hotspot", "show hotspot status", "mobile hotspot chal raha hai",
        "hotspot on hai", "mera hotspot check karo", "hotspot status", "hotspot check karo", "mobile hotspot"
    ]):
        return Plan(steps=[PlanStep(step=1, tool="get_hotspot_status", args={})], explanation="Retrieved mobile hotspot status.")

    # 7. USB Devices
    if (
        any(p in raw_lower for p in [
            "show usb devices", "list usb devices", "check usb devices", "usb devices batao",
            "usb devices dikhao", "kya kya usb connected hai", "connected usb devices", "usb devices"
        ])
        or ("usb" in raw_lower and any(w in raw_lower for w in ["ports", "devices", "cheezein", "connected", "lagi", "plugged"]))
    ):
        return Plan(steps=[PlanStep(step=1, tool="get_usb_devices", args={})], explanation="Listed connected USB devices.")

    # 8. PnP Devices
    if any(p in raw_lower for p in [
        "show pnp devices", "list pnp devices", "check pnp devices", "pnp devices batao", "pnp devices dikhao", "pnp devices"
    ]):
        return Plan(steps=[PlanStep(step=1, tool="get_pnp_devices", args={})], explanation="Listed PnP hardware devices.")

    # 9. Hardware Summary
    if any(p in raw_lower for p in [
        "show all connected devices", "device summary", "connected device summary", "tamam connected devices ka summary", "device summary dikhao"
    ]):
        return Plan(steps=[PlanStep(step=1, tool="get_connected_device_summary", args={})], explanation="Retrieved connected device summary.")

    # 10. Connected Categorized Devices
    if any(p in raw_lower for p in [
        "show connected devices", "what devices are connected", "show my devices", "mere computer se kya connected hai",
        "computer se kya connected hai", "connected devices batao", "connected devices"
    ]) and not any(w in raw_lower for w in ["bluetooth", "usb", "wifi"]):
        return Plan(steps=[PlanStep(step=1, tool="get_connected_devices", args={})], explanation="Listed connected physical devices.")

    # -------------------------------------------------------------
    # 0.9 PROCESS, SERVICE & SYSTEM STATE INTENTS (Phase 2 Part 6)
    # -------------------------------------------------------------
    if any(p in raw_lower for p in [
        "start service", "stop service", "restart service", "disable service", "enable service",
        "service start karo", "service band karo", "service stop karo", "kill all", "terminate all", "kill all processes"
    ]):
        return Plan(is_direct_message=True, message_text="Process and service termination or modification is restricted for security and restricted for safety; only read-only diagnostics are permitted.")

    # 1. Top CPU / Memory Processes
    if any(p in raw_lower for p in [
        "top cpu processes", "kaun sa process sabse zyada cpu le raha hai", "sabse zyada cpu", "highest cpu process",
        "dimag zyada khaa", "dimag khaa", "zyada resource", "most cpu"
    ]):
        return Plan(steps=[PlanStep(step=1, tool="get_top_processes", args={"metric": "cpu"})], explanation="Retrieved top CPU-consuming processes.")

    if any(p in raw_lower for p in [
        "top memory processes", "top ram processes", "kaun sa process sabse zyada ram le raha hai", "sabse zyada ram", "highest memory process"
    ]):
        return Plan(steps=[PlanStep(step=1, tool="get_top_processes", args={"metric": "memory"})], explanation="Retrieved top memory-consuming processes.")

    # 2. Process Count
    if any(p in raw_lower for p in ["kitne processes chal rahe hain", "process count", "total processes"]):
        return Plan(steps=[PlanStep(step=1, tool="get_process_count", args={})], explanation="Retrieved total process count.")

    # 3. Process Tree
    if any(p in raw_lower for p in ["process tree", "process tree dikhao"]):
        return Plan(steps=[PlanStep(step=1, tool="get_process_tree", args={})], explanation="Retrieved process hierarchy tree.")

    # 4. Process List
    if any(p in raw_lower for p in [
        "kaun se processes running hain", "mere computer mein kya kya running hai", "show running processes",
        "list processes", "processes batao", "all processes"
    ]) and not any(w in raw_lower for w in ["services", "service"]) and "running processes" not in raw_lower:
        return Plan(steps=[PlanStep(step=1, tool="get_processes", args={})], explanation="Enumerated running processes.")

    # 5. Specific Process Status / Resource Usage (e.g. "Chrome ka process batao", "PID of Chrome kya hai?")
    if any(p in lower for p in ["ka process batao", "ka process status", "pid of", "kitni memory use kar raha hai", "kitna cpu use kar raha hai", "kitna ram le raha hai"]) and not any(pr in lower for pr in ["iska", "is ka", "uska", "us ka", "pehli wali", "pahli wali", "first one", "last one", "dusri wali", "second one", "is app ka", "us app ka"]):
        proc_cand = lower
        proc_cand = re.sub(r'\b(ka\s+process\s+batao|ka\s+process\s+status\s+kya\s+hai|pid\s+of|kya\s+hai|kitni\s+memory\s+use\s+kar\s+raha\s+hai|kitna\s+cpu\s+use\s+kar\s+raha\s+hai|kitna\s+ram\s+le\s+raha\s+hai|process|batao|status)\b', '', proc_cand).strip()
        proc_cand = proc_cand.strip("?").strip()
        if not proc_cand and context and context.last_process:
            proc_cand = _entity_val(context.last_process)
        if proc_cand and context and context.last_search_results:
            for item in context.last_search_results:
                if str(item).lower() == proc_cand.lower():
                    proc_cand = str(item)
                    break
        if proc_cand:
            return Plan(steps=[PlanStep(step=1, tool="get_process_status", args={"name_or_pid": proc_cand})], explanation=f"Retrieved process telemetry for {proc_cand}.")

    # 6. Service Summary
    if any(p in raw_lower for p in ["service summary", "services summary", "services ka summary"]):
        return Plan(steps=[PlanStep(step=1, tool="get_service_summary", args={})], explanation="Retrieved Windows services summary.")

    # 7. Running Services
    if any(p in raw_lower for p in ["kaun si services running hain", "running services batao", "running services"]):
        return Plan(steps=[PlanStep(step=1, tool="get_running_services", args={})], explanation="Listed active running Windows services.")

    # 8. Stopped Services
    if any(p in raw_lower for p in ["stopped services", "stopped services batao"]):
        return Plan(steps=[PlanStep(step=1, tool="get_stopped_services", args={})], explanation="Listed stopped Windows services.")

    # 9. Services List
    if any(p in raw_lower for p in [
        "windows services ka status batao", "show services", "list services", "windows services", "services batao", "windows ki services"
    ]) and not any(w in raw_lower for w in ["running", "stopped"]):
        return Plan(steps=[PlanStep(step=1, tool="get_services", args={})], explanation="Enumerated Windows services.")


    return None
