from __future__ import annotations
import os
from pathlib import Path
import re
import sys
import time
from typing import Any, Optional, Union, List, Dict, Tuple
from dataclasses import dataclass, field

from brain.planner import (
    Plan,
    PlanStep,
    StructuredIntent,
    create_plan_from_decision,
    decompose_compound_command,
    parse_compound_request,
    resolve_step_variables,
    resolve_step_variables_with_guard,
    inject_plan_prerequisites,
    prune_plan_steps,
    build_hypothesis_investigation_plan,
    build_root_cause_investigation_plan,
    parse_conditional_goal,
    synthesize_adaptive_replan,
    decompose_into_milestones,
    restore_plan_from_checkpoint,
    build_cross_domain_plan,
    apply_cross_domain_transformation,
    build_long_horizon_exploration_plan,
    decompose_long_horizon_goal,
    compute_state_hash,
    detect_state_cycle,
    heuristic_node_score,
    expand_exploration_frontier,
    select_next_frontier_node,
    apply_reflective_history_pruning,
)
from command_layer.cognitive_reasoner import CognitiveReasoner
from command_layer.context import (
    EntityType,
    TypedEntity,
    ORDINAL_REFERENCES,
    SessionContext,
    resolve_references,
    session_context,
    update_context_from_result,
)
from command_layer.semantic_model import (
    SemanticDomain,
    SemanticAction,
    CommandIntent,
    AmbiguityType,
    ClarificationRequest,
    SymptomCategory,
    SituationType,
    ConfidenceTier,
    RiskTier,
    ConfidenceScore,
    ConfirmationRequest,
    FailureType,
    AdaptiveStrategy,
    PlanAdaptation,
    TaskLifecycleState,
    TaskMilestone,
    TaskCheckpoint,
    DomainBridgeType,
    DomainBridgeLink,
    CrossDomainWorkflow,
    HorizonDepth,
    ExplorationNode,
    SearchFrontier,
    LongHorizonReport,
    HistoryQueryType,
    ExecutionTraceRecord,
    TraceSummary,
)
from command_layer.semantic_parser import (
    parse_semantic_intent,
    create_plan_from_intent,
    resolve_in_turn_correction,
    strip_conversational_noise,
    split_compound_clauses,
    detect_symptom_category,
)
from command_layer.firewall import validate_tool_against_firewall, pre_execution_semantic_check, validate_long_horizon_action
from command_layer.state_machine import agent_state
from command_layer.validator import validate_and_sanitize_tool_arguments
from command_layer.lexer import UniversalLexer
from brain.runtime_bus import RuntimePipingBus
from security.state import confirmation_manager
from tools.utils.app_resolver import (
    APP_ALIASES,
    get_canonical_app_name,
    resolve_app,
)
from tools.utils.target_resolver import TargetType, resolve_universal_target, disambiguate_multi_candidates
from command_layer.router_base import (
    Step,
    run_tool_call,
    resolve_system_canonical_path,
    verify_post_recovery,
    verify_semantic_outcome,
    capture_environment_snapshot,
    capture_step_observation,
    detect_environment_drift,
    _entity_val,
    get_all_schemas,
    KNOWN_SITE_KEYS,
    KNOWN_APP_NAMES,
    _has_file_extension,
    _normalize_resolved_path,
    _is_conversational_folder_path,
)
from security.safety_firewall import is_safe_readonly_operation
from security.confirm import RISKY_TOOLS
from command_layer.decomposer import count_action_verbs
from brain.workflow_orchestrator import orchestrate_compound_workflow
from tools.browser import sanitize_search_query
from tools.search import parse_search_grammar
import executor.verifier
import executor.executor

from command_layer.router_sanitizer import (
    _isolate_browser_context,
    prune_negated_steps,
    sanitize_action_query,
    sanitize_url,
    _canonicalize_plan_tools,
    sanitize_ui_target,
    extract_clean_search_query,
)
from command_layer.router_cli_parser import (
    translate_cli_command,
    sanitize_cli_command,
    extract_pure_text_payload,
    parse_sequential_keyboard_actions,
    is_standalone_navigation_request,
    resolve_temporal_order,
    strip_idiomatic_conditions,
)
from command_layer.router_confidence import (
    determine_risk_tier,
    format_uncertainty_response,
    compute_command_confidence,
    synthesize_cross_domain_report,
    synthesize_long_horizon_report,
    get_conversational_response,
)

def _classify_and_parse_command(text: str, context: SessionContext | None = None, is_compound_root: bool = True) -> Plan | None:
    from command_layer.router_classifier_core import _classify_and_parse_command as _real_fn
    return _real_fn(text, context, is_compound_root)

def classify_web_intents(text: str, context: SessionContext | None = None, is_compound_root: bool = True) -> Plan | None:
    from command_layer.decomposer import count_action_verbs
    from brain.workflow_orchestrator import orchestrate_compound_workflow
    from tools.browser import sanitize_search_query
    from tools.search import parse_search_grammar
    from security.safety_firewall import is_safe_readonly_operation
    from security.confirm import RISKY_TOOLS
    cleaned = re.sub(r'[\x00-\x1f\x7f]+$', '', text).strip()
    cleaned = re.sub(r'[\x13\x03\x1b]', '', cleaned).strip()
    raw_lower = cleaned.lower()
    lower = text.lower()
    folder_ref_m = re.search(r"folder\s+'([^']+)'", text)
    file_ref_m = re.search(r"file\s+'([^']+)'", text)
    text_unwrapped = re.sub(r'[\'"]([^\'"]+)[\'"]', r'\1', text)
    try:
        symptom_cat, situation_type, symptom_entities = detect_symptom_category(raw_lower)
    except Exception:
        symptom_cat, situation_type, symptom_entities = SymptomCategory.NONE, SituationType.NORMAL, []
    _p2_is_compound_guard = False
    is_inquiry_for_typing = (
        any(lower.startswith(p) for p in ["can you", "tell me", "give me", "list", "how many", "show me", "what is", "what are", "which", "kya", "batao", "dikhao"])
        or bool(re.search(r'\b(?:can you|tell me|give me|list|how many|show me)\b', lower))
    )

    type_direct_m = re.match(r'^type\s+(.+)$', cleaned, re.IGNORECASE)
    if (
        type_direct_m
        and not is_inquiry_for_typing
        and not _p2_is_compound_guard
        and not any(w in lower for w in ["karo", "kardo", "kar do", "mein", "me", "inside", "into"])
        and not any(app in lower for app in ["notepad", "chrome", "chatgpt", "word", "vs code", "vscode", "editor", "search bar", "search box", "address bar"])
    ):
        raw_text_payload = type_direct_m.group(1).strip()
        with_enter = False
        if re.search(r'\s+(?:aur|and)\s+enter(?:\s+press|\s+karo)?$', raw_text_payload, re.IGNORECASE):
            raw_text_payload = re.sub(r'\s+(?:aur|and)\s+enter(?:\s+press|\s+karo)?$', '', raw_text_payload, flags=re.IGNORECASE).strip()
            with_enter = True
        if (raw_text_payload.startswith('"') and raw_text_payload.endswith('"')) or (raw_text_payload.startswith("'") and raw_text_payload.endswith("'")):
            raw_text_payload = raw_text_payload[1:-1]
        return Plan(steps=[PlanStep(step=1, tool="send_keyboard_input", args={"text": raw_text_payload, "press_enter": with_enter})])

    # Prioritize compound workflow orchestration before generic typing matcher.
    # HARDENED: also guard on 1 conjunction + lifecycle verb (not just >=2 conjunctions or 3+ verbs).
    has_multiple_conjs_typ = len(re.findall(r'\b(?:phir|aur|and|then|after\s+that|pehle)\b', lower)) >= 2
    _LIFECYCLE_VERBS_P3 = {"launch", "open", "close", "read", "save", "scan", "kholo", "band", "padhao"}
    _has_any_conj_p3 = bool(re.search(r'\b(?:phir|aur|and|then|after\s+that|pehle)\b', lower))
    _has_lifecycle_p3 = any(v in lower.split() for v in _LIFECYCLE_VERBS_P3) or bool(re.search(r'\b(?:launch|open|close|read|save|scan)\b', lower))
    has_3_plus_verbs_typ = count_action_verbs(lower) >= 3
    _p3_is_compound_guard = has_multiple_conjs_typ or has_3_plus_verbs_typ or (_has_any_conj_p3 and _has_lifecycle_p3)
    if _p3_is_compound_guard and is_compound_root:
        from brain.workflow_orchestrator import orchestrate_compound_workflow
        orch_plan = orchestrate_compound_workflow(cleaned, context)
        if orch_plan is not None and orch_plan.steps and not getattr(orch_plan, "is_direct_message", False):
            return orch_plan

    # Matches: "Notepad ke andar Hello Computer likho", "ChatGPT ki chat box mein 'how to download NFS' likho", "type karo 'Hello World'", "'Hello World' likho", "type 'Hello World'", "search input mein 'latest movies' likho", "Text 'Meeting Notes' Notepad mein type kardo", "In Notepad, type 'Conference Call at 5 PM'"
    if (
        not is_inquiry_for_typing
        and not _p3_is_compound_guard
        and (lower.startswith("type ") or "type karo" in lower or "type kardo" in lower or "type kar do" in lower or "likho" in lower or "ye text type karo" in lower or "chat box mein" in lower or "ke andar" in lower or "search input" in lower or "search bar" in lower or "search box" in lower or (re.search(r'\btype\b', lower) and any(w in lower for w in ["mein", "me", "in", "into", "inside", "on"])))
        and not ((lower.startswith("search ") and not ("mein" in lower or "me" in lower or "input" in lower or "box" in lower or "bar" in lower)) or "google par" in lower or "web search" in lower or "folder" in lower or "click" in lower or "banao" in lower or "open" in lower or "kholo" in lower or "mouse" in lower or "move" in lower)
    ):

        quoted_m = re.search(r'["\']([^"\']+)["\']', text)
        if quoted_m:
            text_to_type = quoted_m.group(1)
        else:
            text_to_type = text.strip()
            for _ in range(3):
                # Strip leading prefixes
                text_to_type = re.sub(r'^(?:exactly\s+)?(?:ye\s+text\s+type\s+karo|type\s+karo|type\s+kar\s+do|type|search\s+karo|search):?\s*', '', text_to_type, flags=re.IGNORECASE).strip()
                text_to_type = re.sub(r'^(?:chrome|notepad|chatgpt|wordpad|vs\s+code|code|edge|youtube|github|wikipedia|google|bing|browser|calc|calculator)\s*(?:\bke\b|\bki\b|\bka\b|\bmein\b|\bma\b|\bme\b|\bpar\b)?\s*', '', text_to_type, flags=re.IGNORECASE).strip()
                text_to_type = re.sub(r'^(?:search\s+bar|search\s+box|search\s+input|address\s+bar|chat\s+box|chatbox|editor)\s*', '', text_to_type, flags=re.IGNORECASE).strip()
                text_to_type = re.sub(r'^(?:ke\s+andar|ki\s+chat\s+box\s+mein|ki\s+chatbox\s+mein|\bmein\b|\bma\b|\bme\b|\bpar\b|\bin\b|\bismein\b|\bisme\b|\busmein\b|\busme\b)\s*', '', text_to_type, flags=re.IGNORECASE).strip()
                text_to_type = re.sub(r'^(?:usme|usmein|isme|ismein)?\s*(?:likho|type|write|type\s+karo|type\s+kar\s+do|type\s+kardo):?\s*', '', text_to_type, flags=re.IGNORECASE).strip()
                # Strip trailing verbs and container descriptions
                text_to_type = re.sub(r'\s*(?:video\s+tutorial|tutorial|repository|repo|article|page|query|search\s+query)?\s*(?:search\s+karo|search\s+kar\s+do|search|likho|type\s+karo|type\s+kar\s+do|type)\.?$', '', text_to_type, flags=re.IGNORECASE).strip()
                text_to_type = re.sub(r'\s+(?:in\s+it|into\s+it|inside\s+it|in\s+there|usme|usmein|isme|ismein|there)$', '', text_to_type, flags=re.IGNORECASE).strip()

            if text_to_type.lower() in ("karke", "kar ke", "karo", "phir", "aur"):
                text_to_type = ""

        # Telemetry / Formatting Directive Guard:
        # Prevent instructional directives (e.g. "dono alag lines par") or raw CLI commands (e.g. "systeminfo")
        # from being treated as text typing payloads on Notepad / WordPad.
        _instructional_or_cli = [
            r'^(?:dono\s+)?alag\s+lines?\s*(?:par|pe|mein)?$',
            r'^separate\s+lines?$',
            r'^new\s+lines?$',
            r'^both\s+(?:on\s+)?separate\s+lines?$',
            r'^(?:systeminfo|ipconfig|netstat|tasklist|hostname|whoami|ping|tracert)$',
        ]
        if any(re.search(pat, text_to_type.strip().lower()) for pat in _instructional_or_cli):
            return Plan(
                steps=[],
                is_direct_message=True,
                message_text=f"Unmapped complex query or formatting directive '{text_to_type}'. Please specify the exact content to write."
            )

        with_enter = "aur enter" in lower or "and enter" in lower or "enter press" in lower

        # Check if targeting browser search bar or search input
        if "search bar" in lower or "search box" in lower or "search input" in lower or "address bar" in lower:
            target_field = "address bar" if "address" in lower else "search bar"
            return Plan(steps=[
                PlanStep(step=1, tool="find_and_interact", args={"target_query": target_field, "query": target_field, "action": "type", "input_text": text_to_type})
            ])

        # Check if targeting ChatGPT or browser chat input
        if "chatgpt" in lower or "chat box" in lower or "chatbox" in lower:
            steps = [
                PlanStep(step=1, tool="focus_app", args={"name": "Chrome"}),
                PlanStep(step=2, tool="find_and_interact", args={"target_query": "Ask anything", "query": "Ask anything", "action": "type", "input_text": text_to_type}),
            ]
            return Plan(steps=steps)

        # Check if targeting WordPad
        if "wordpad" in lower:
            if not text_to_type:
                return Plan(steps=[PlanStep(step=1, tool="focus_app", args={"name": "WordPad"})])
            steps = [
                PlanStep(step=1, tool="focus_app", args={"name": "WordPad"}),
                PlanStep(step=2, tool="type_text", args={"text": text_to_type, "press_enter": with_enter, "app_name": "WordPad"}),
            ]
            return Plan(steps=steps)

        # Check if targeting Calc / Calculator
        if any(w in lower for w in ["calc", "calculator"]):
            if not text_to_type:
                return Plan(steps=[PlanStep(step=1, tool="focus_app", args={"name": "Calculator"})])
            steps = [
                PlanStep(step=1, tool="focus_app_window", args={"app_name": "Calculator"}),
                PlanStep(step=2, tool="send_keyboard_input", args={"text": text_to_type, "press_enter": with_enter, "app_name": "Calculator"}),
            ]
            return Plan(steps=steps)

        # Check if targeting Notepad
        if "notepad" in lower:
            if not text_to_type:
                return Plan(steps=[PlanStep(step=1, tool="focus_app", args={"name": "Notepad"})])
            steps = [
                PlanStep(step=1, tool="focus_app", args={"name": "Notepad"}),
                PlanStep(step=2, tool="type_text", args={"text": text_to_type, "press_enter": with_enter}),
            ]
            return Plan(steps=steps)

        # Check if targeting VS Code
        if "vs code" in lower or "vscode" in lower or "code" in lower:
            if not text_to_type:
                return Plan(steps=[PlanStep(step=1, tool="focus_app", args={"name": "VS Code"})])
            steps = [
                PlanStep(step=1, tool="focus_app", args={"name": "VS Code"}),
                PlanStep(step=2, tool="type_text", args={"text": text_to_type, "press_enter": with_enter}),
            ]
            return Plan(steps=steps)

        if text_to_type:
            return Plan(steps=[PlanStep(step=1, tool="type_text", args={"text": text_to_type, "press_enter": with_enter})])

    # -------------------------------------------------------------
    # 7. CLIPBOARD INTENTS
    # -------------------------------------------------------------
    # Matches: "clipboard mein kya hai?", "what is on the clipboard", "show clipboard"
    if "clipboard" in lower and ("kya" in lower or "show" in lower or "read" in lower or "content" in lower or "dikhao" in lower or "batao" in lower):
        return Plan(steps=[PlanStep(step=1, tool="get_clipboard_text", args={})])

    # Matches: "clipboard clear karo", "clear clipboard", "empty clipboard"
    if "clipboard" in lower and ("clear" in lower or "empty" in lower or "khali" in lower or "saaf" in lower):
        return Plan(steps=[PlanStep(step=1, tool="clear_clipboard", args={})])

    # Matches: "copy text", "copy selection", "copy selected text", "selection copy karo"
    if lower in ("copy text", "copy selection", "copy", "selection copy karo", "text copy karo", "copy selected text") or (
        lower.startswith("copy")
        and not any(k in lower for k in ("file", "folder", "directory", "drive"))
        and not (" to " in lower or " par " in lower or ":" in text or "'" in text or '"' in text)
    ):
        return Plan(steps=[PlanStep(step=1, tool="copy_selection_to_clipboard", args={})])

    # Matches: "ye text copy karo", "copy to clipboard: ...", "copy 'hello' to clipboard"
    if ("clipboard" in lower and "copy" in lower) or (lower.startswith("copy text") or "ye text copy karo" in lower):
        text_to_copy = re.sub(r'\b(copy\s+to\s+clipboard|clipboard\s+par\s+copy\s+karo|ye\s+text\s+copy\s+karo|copy\s+text|clipboard\s+mein\s+copy\s+karo|copy)\b', '', text, flags=re.IGNORECASE).strip().strip("'\"")
        if not text_to_copy:
            return Plan(steps=[PlanStep(step=1, tool="copy_selection_to_clipboard", args={})])
        return Plan(steps=[PlanStep(step=1, tool="set_clipboard_text", args={"text": text_to_copy})])

    # Matches: "paste into notepad", "paste text into notepad", "paste text", "paste clipboard into notepad"
    if "paste" in lower:
        target_app = None
        for app in ("notepad", "edge", "chrome", "word", "excel", "calculator", "explorer", "browser", "code"):
            if app in lower:
                target_app = "Notepad" if app == "notepad" else ("VS Code" if app == "code" else app.capitalize())
                break
        txt_m = re.search(r'["\']([^"\']+)["\']', text)
        text_arg = txt_m.group(1) if txt_m else None
        p_args = {}
        if text_arg:
            p_args["text"] = text_arg
        if target_app:
            p_args["target_app"] = target_app
        return Plan(steps=[PlanStep(step=1, tool="paste_clipboard_into_target", args=p_args)])

    # Matches: "save document to C:\reports\summary.txt", "save to C:\notes\output.txt", "save active document"
    if "save" in lower and ("document" in lower or "to " in lower or "\\" in text or "/" in text or any(lower.endswith(ext) for ext in (".txt", ".pdf", ".docx", ".doc", ".log", ".json"))):
        path_m = re.search(r'([a-zA-Z]:\\[^\s"\'>]+|[a-zA-Z]:/[^\s"\'>]+|["\']([^"\']+)["\'])', text)
        if path_m:
            filepath = path_m.group(1) or path_m.group(2)
        else:
            parts = re.split(r'\bto\b', text, flags=re.IGNORECASE)
            filepath = parts[-1].strip(" ,;.-'\"") if len(parts) > 1 else ""
        if filepath:
            filepath = _normalize_resolved_path(filepath.strip(" ,;.-'\""))
            app_target = "Notepad"
            if context and getattr(context, "last_focused_app", None):
                app_target = context.last_focused_app
            elif context and getattr(context, "active_application", None):
                app_target = context.active_application
            return Plan(steps=[PlanStep(step=1, tool="save_active_document", args={"filepath": filepath, "app_name": app_target})])

    # -------------------------------------------------------------
    # 4. BROWSER SPECIFIC INTENTS (URLs, Web Search, Tabs, Profiles)
    # -------------------------------------------------------------
    # Matches: "new tab kholo", "open new tab", "create new tab", "Chrome mein nayi tab kholo", "Edge mein new tab open karo"
    if "new tab" in lower or "nayi tab" in lower or "naya tab" in lower:
        browser = "edge" if "edge" in lower else "chrome"
        return Plan(steps=[PlanStep(step=1, tool="new_tab", args={"browser": browser})])

    # Matches: "Chrome ki profiles list karo", "Edge ki profiles dikhao"
    if "profile" in lower and ("list" in lower or "dikhao" in lower or "show" in lower):
        browser = "edge" if "edge" in lower else "chrome"
        return Plan(steps=[PlanStep(step=1, tool="list_browser_profiles", args={"browser": browser})])

    # Matches: "is ma latest profile chose karo", "Chrome ki latest profile kholo", "work profile kholo"
    if "profile" in lower and ("chose" in lower or "select" in lower or "open" in lower or "kholo" in lower or "kero" in lower or "karo" in lower):
        browser = "edge" if "edge" in lower else "chrome"
        profile_query = "latest"
        if "latest" not in lower and "sabse latest" not in lower:
            prof_m = re.search(r'([a-zA-Z0-9_\-]+)\s+profile', lower)
            if prof_m and prof_m.group(1) not in ("chrome", "edge", "browser", "ki", "ka", "is", "us"):
                profile_query = prof_m.group(1)
        return Plan(steps=[PlanStep(step=1, tool="open_browser_profile", args={"browser": browser, "profile_name": profile_query})])

    # Matches: "Google par 'weather today' search karo", "web search karo 'Python async tutorial'", "Chrome mein web development search karo", "Google par Python search karo"
    if (
        "web search" in lower
        or "google par" in lower
        or "edge par" in lower
        or "google pe" in lower
        or "edge pe" in lower
        or "web pe" in lower
        or "web par" in lower
        or "internet pe" in lower
        or "internet par" in lower
        or "search web" in lower
        or "search the web" in lower
        or "search online" in lower
        or "online search" in lower
        or (("search" in lower or "dhundo" in lower) and ("chrome" in lower or "edge" in lower or "browser" in lower or "internet" in lower or "google" in lower or "web" in lower))
    ):
        from tools.browser import sanitize_search_query
        q = sanitize_search_query(re.sub(
            r'\b(web\s+search\s+karo|chrome\s+mein|browser\s+mein|edge\s+mein|google\s+par|edge\s+par|google\s+pe|edge\s+pe|web\s+pe|web\s+par|internet\s+pe|internet\s+par|'
            r'search\s+the\s+web\s+for|search\s+web\s+for|search\s+web|search\s+online\s+for|search\s+online|search\s+google\s+for|online\s+web\s+search\s+karo|online\s+search|'
            r'search\s+karo|search\s+kar\s+do|search\s+kardo|dhundo|search|on\s+google|on\s+edge|in\s+chrome|in\s+edge|for|please|ke\s+liye)\b',
            '', text, flags=re.IGNORECASE
        ).strip().strip("'\""))
        if q:
            b_target = "edge" if any(b in lower for b in ["edge", "msedge"]) else "chrome"
            return Plan(steps=[PlanStep(step=1, tool="search_web", args={"query": q, "browser": b_target})])

    # Matches: "Chrome mein YouTube kholo", "YouTube kholo", "Google kholo", "open https://..."
    if not any(w in lower for w in ["search", "dhundo", "likh", "type", "enter"]):
        for site_key in KNOWN_SITE_KEYS:
            if site_key == "google" and ("google chrome" in lower or "chrome" in lower):
                continue
            if site_key == "x" and re.search(r'\b[xX]\s*(?:drive|disk|:)\b', lower):
                continue
            if re.search(rf'\b{site_key}\b', lower) and ("kholo" in lower or "open" in lower or "chalao" in lower):
                b_target = "edge" if any(b in lower for b in ["edge", "msedge"]) else "chrome"
                return Plan(steps=[PlanStep(step=1, tool="open_url", args={"url": site_key, "browser": b_target})])

    # -------------------------------------------------------------
    # 5. DOCUMENT READING & SUMMARY INTENTS
    # -------------------------------------------------------------
    # Prevent compound pipeline dropping and premature read short-circuit:
    # Before evaluating Section 5, verify if compound conjunctions ('phir', 'aur', 'and', 'then')
    # or multiple action verbs ('launch', 'type', 'save', etc.) exist.
    # If multiple clauses exist, FORBID single-intent short-circuiting to read_file/read_document.
    # Route the entire query directly to orchestrate_compound_workflow so all steps
    # (cmd -> notepad -> save -> read -> scan -> folder -> report) are preserved sequentially.
    has_compound_conjs = bool(re.search(r'\b(?:phir|aur|and|then|after\s+that|uske\s+baad|iske\s+baad)\b|[,;\n]', raw_lower))
    from command_layer.decomposer import count_action_verbs
    action_verb_count = count_action_verbs(raw_lower)
    has_multiple_verbs = (
        action_verb_count >= 2
        or len(re.findall(r'\b(?:launch|type|save|read|scan|open|close|kholo|khol|likho|band|chalao)\b', raw_lower)) >= 2
        or (any(w in raw_lower for w in ["launch", "type", "save"]) and any(w in raw_lower for w in ["read", "scan", "khol", "kholo", "folder"]))
    )
    if is_compound_root and (has_compound_conjs or has_multiple_verbs):
        from brain.workflow_orchestrator import orchestrate_compound_workflow
        orch_plan = orchestrate_compound_workflow(cleaned, context)
        if orch_plan is not None and orch_plan.steps and not getattr(orch_plan, "is_direct_message", False):
            return orch_plan

    # Matches: "is file mein kya likha hai?", "read this file", "is document ko summarize karo", "is PDF mein 'result' search karo", "is file ka naam batao"
    if (any(p in lower for p in ["kya likha hai", "read file", "read document", "summarize", "naam batao"]) or (re.search(r'["\'][^"\']+["\']\s+search\s+karo', lower) and ("file" in lower or "pdf" in lower or "document" in lower))) and (file_ref_m or "file" in lower or "document" in lower or "pdf" in lower or _has_file_extension(lower)):
        target_path = ""
        # 1. Dynamically parse the exact filepath specified after 'read file <path>', 'read document <path>', etc.
        read_explicit_m = re.search(
            r'\bread\s+(?:file\s+|document\s+)?["\']?([a-zA-Z]:[^\s"\'<>|?*]+|[a-zA-Z0-9_\-\\/.]+\.[a-zA-Z0-9]{1,10})["\']?',
            text,
            flags=re.IGNORECASE
        )
        if read_explicit_m:
            cand = read_explicit_m.group(1).strip(" ,;.-'\"")
            if cand.lower() not in ("file", "document", "pdf", "txt", "doc"):
                target_path = cand
            elif "." in cand:
                target_path = cand
        if not target_path and file_ref_m:
            target_path = file_ref_m.group(1).strip(" ,;.-'\"")
        if not target_path:
            gen_path_m = re.search(
                r'([a-zA-Z]:\\[^\s"\'<>|?*]+|[a-zA-Z]:/[^\s"\'<>|?*]+|["\']([^"\']+\.[a-zA-Z0-9]+)["\']|\b[a-zA-Z0-9_\-\\/.]+\.[a-zA-Z0-9]{1,10}\b)',
                text
            )
            if gen_path_m:
                cand = (gen_path_m.group(1) or gen_path_m.group(2)).strip(" ,;.-'\"")
                if cand.lower() not in ("file", "document", "pdf", "txt", "doc"):
                    target_path = cand

        # 2. Only fall back to context if no explicit path was provided in the command
        if not target_path:
            target_path = _entity_val(context.last_selected_file) if (context and context.last_selected_file) else (getattr(context, "last_referenced_file", "") or "")

        if target_path:
            target_path = _normalize_resolved_path(target_path)
            if context is not None:
                context.last_referenced_file = target_path

        # Check if user asked to search a word inside the file
        search_kw_m = re.search(r'["\']([^"\']+)["\']\s+search\s+karo', text, flags=re.IGNORECASE)
        query_word = search_kw_m.group(1) if search_kw_m else ""

        is_summarize = "summarize" in lower or "summary" in lower
        if "naam batao" in lower or "name of file" in lower:
            fname = Path(target_path).name if target_path else "unknown"
            return Plan(is_direct_message=True, message_text=f"The current file name is '{fname}'.")

        if target_path:
            return Plan(steps=[PlanStep(step=1, tool="read_document", args={"path": target_path, "query": query_word, "summarize": is_summarize})])


    return None
