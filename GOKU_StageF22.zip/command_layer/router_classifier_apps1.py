from __future__ import annotations
import os
from pathlib import Path
import re
import sys
import time
from typing import Any, Optional, Union, List, Dict, Tuple
from dataclasses import dataclass, field

from brain.planner import (
    Plan,
    PlanStep,
    StructuredIntent,
    create_plan_from_decision,
    decompose_compound_command,
    parse_compound_request,
    resolve_step_variables,
    resolve_step_variables_with_guard,
    inject_plan_prerequisites,
    prune_plan_steps,
    build_hypothesis_investigation_plan,
    build_root_cause_investigation_plan,
    parse_conditional_goal,
    synthesize_adaptive_replan,
    decompose_into_milestones,
    restore_plan_from_checkpoint,
    build_cross_domain_plan,
    apply_cross_domain_transformation,
    build_long_horizon_exploration_plan,
    decompose_long_horizon_goal,
    compute_state_hash,
    detect_state_cycle,
    heuristic_node_score,
    expand_exploration_frontier,
    select_next_frontier_node,
    apply_reflective_history_pruning,
)
from command_layer.cognitive_reasoner import CognitiveReasoner
from command_layer.context import (
    EntityType,
    TypedEntity,
    ORDINAL_REFERENCES,
    SessionContext,
    resolve_references,
    session_context,
    update_context_from_result,
)
from command_layer.semantic_model import (
    SemanticDomain,
    SemanticAction,
    CommandIntent,
    AmbiguityType,
    ClarificationRequest,
    SymptomCategory,
    SituationType,
    ConfidenceTier,
    RiskTier,
    ConfidenceScore,
    ConfirmationRequest,
    FailureType,
    AdaptiveStrategy,
    PlanAdaptation,
    TaskLifecycleState,
    TaskMilestone,
    TaskCheckpoint,
    DomainBridgeType,
    DomainBridgeLink,
    CrossDomainWorkflow,
    HorizonDepth,
    ExplorationNode,
    SearchFrontier,
    LongHorizonReport,
    HistoryQueryType,
    ExecutionTraceRecord,
    TraceSummary,
)
from command_layer.semantic_parser import (
    parse_semantic_intent,
    create_plan_from_intent,
    resolve_in_turn_correction,
    strip_conversational_noise,
    split_compound_clauses,
    detect_symptom_category,
)
from command_layer.firewall import validate_tool_against_firewall, pre_execution_semantic_check, validate_long_horizon_action
from command_layer.state_machine import agent_state
from command_layer.validator import validate_and_sanitize_tool_arguments
from command_layer.lexer import UniversalLexer
from brain.runtime_bus import RuntimePipingBus
from security.state import confirmation_manager
from tools.utils.app_resolver import (
    APP_ALIASES,
    get_canonical_app_name,
    resolve_app,
)
from tools.utils.target_resolver import TargetType, resolve_universal_target, disambiguate_multi_candidates
from command_layer.router_base import (
    Step,
    run_tool_call,
    resolve_system_canonical_path,
    verify_post_recovery,
    verify_semantic_outcome,
    capture_environment_snapshot,
    capture_step_observation,
    detect_environment_drift,
    _entity_val,
    get_all_schemas,
    KNOWN_SITE_KEYS,
    KNOWN_APP_NAMES,
    _has_file_extension,
    _normalize_resolved_path,
    _is_conversational_folder_path,
)
from security.safety_firewall import is_safe_readonly_operation
from security.confirm import RISKY_TOOLS
from command_layer.decomposer import count_action_verbs
from brain.workflow_orchestrator import orchestrate_compound_workflow
from tools.browser import sanitize_search_query
from tools.search import parse_search_grammar
import executor.verifier
import executor.executor

from command_layer.router_sanitizer import (
    _isolate_browser_context,
    prune_negated_steps,
    sanitize_action_query,
    sanitize_url,
    _canonicalize_plan_tools,
    sanitize_ui_target,
    extract_clean_search_query,
)
from command_layer.router_cli_parser import (
    translate_cli_command,
    sanitize_cli_command,
    extract_pure_text_payload,
    parse_sequential_keyboard_actions,
    is_standalone_navigation_request,
    resolve_temporal_order,
    strip_idiomatic_conditions,
)
from command_layer.router_confidence import (
    determine_risk_tier,
    format_uncertainty_response,
    compute_command_confidence,
    synthesize_cross_domain_report,
    synthesize_long_horizon_report,
    get_conversational_response,
)

def _classify_and_parse_command(text: str, context: SessionContext | None = None, is_compound_root: bool = True) -> Plan | None:
    from command_layer.router_classifier_core import _classify_and_parse_command as _real_fn
    return _real_fn(text, context, is_compound_root)

def classify_app_intents_1(text: str, context: SessionContext | None = None, is_compound_root: bool = True) -> Plan | None:
    from command_layer.decomposer import count_action_verbs
    from brain.workflow_orchestrator import orchestrate_compound_workflow
    from tools.browser import sanitize_search_query
    from tools.search import parse_search_grammar
    from security.safety_firewall import is_safe_readonly_operation
    from security.confirm import RISKY_TOOLS
    cleaned = re.sub(r'[\x00-\x1f\x7f]+$', '', text).strip()
    cleaned = re.sub(r'[\x13\x03\x1b]', '', cleaned).strip()
    raw_lower = cleaned.lower()
    lower = text.lower()
    folder_ref_m = re.search(r"folder\s+'([^']+)'", text)
    file_ref_m = re.search(r"file\s+'([^']+)'", text)
    text_unwrapped = re.sub(r'[\'"]([^\'"]+)[\'"]', r'\1', text)
    try:
        symptom_cat, situation_type, symptom_entities = detect_symptom_category(raw_lower)
    except Exception:
        symptom_cat, situation_type, symptom_entities = SymptomCategory.NONE, SituationType.NORMAL, []
    _p2_is_compound_guard = False
    # 10. Specific Service Status (e.g. "Windows Update service chal rahi hai?", "service ka startup type kya hai?")
    if ("service" in raw_lower or "services" in raw_lower) and any(w in raw_lower for w in ["chal rahi hai", "startup type", "status", "ka status", "active", "is active"]):
        srv_cand = raw_lower
        srv_cand = re.sub(r'\b(check\s+whether|check|whether|is\s+active|active|service\s+chal\s+rahi\s+hai|service\s+ka\s+startup\s+type\s+kya\s+hai|windows\s+update\s+service|windows\s+update|service|services|ka\s+status|status|batao|kya\s+hai)\b', '', srv_cand).strip()
        srv_cand = srv_cand.strip("?").strip()
        if "windows update" in raw_lower or not srv_cand:
            srv_cand = "Windows Update" if "windows update" in raw_lower else (_entity_val(context.last_service) if context and context.last_service else "wuauserv")
        return Plan(steps=[PlanStep(step=1, tool="get_service_status", args={"name": srv_cand})], explanation=f"Retrieved status for service '{srv_cand}'.")

    # 11. System Uptime
    if any(p in raw_lower for p in [
        "computer kitni der se on hai", "system uptime", "uptime batao", "system kab se chal raha hai", "uptime"
    ]):
        return Plan(steps=[PlanStep(step=1, tool="get_system_uptime", args={})], explanation="Retrieved system uptime.")

    # 11.5 Direct Offline System Time & Date Query
    if (
        any(p in raw_lower for p in [
            "system ka time", "kya time hua hai", "current time", "system time", "time kya hua",
            "time batao", "waqt kya hua", "kya waqt hua", "aaj ki date", "current date", "system date",
            "date batao", "date kya hai", "aaj kya tareekh hai", "tareekh batao", "what time is it",
            "what is the time", "current system time", "system clock", "get time", "get date",
            "system time batao", "mujhay system ka time batao", "mujhe system ka time batao",
            "aaj ka din", "today's date", "todays date", "what is today's date"
        ])
        or (("time" in raw_lower or "date" in raw_lower or "waqt" in raw_lower or "tareekh" in raw_lower) and any(w in raw_lower for w in ["system", "current", "aaj", "kya", "batao", "now", "tell me", "what"]))
    ) and not any(w in raw_lower for w in ["timeout", "uptime", "sleep", "wait", "ping", "delay"]):
        return Plan(steps=[PlanStep(step=1, tool="get_system_time", args={})], explanation="Retrieved current system time and date.")

    # 12. System State
    if any(p in raw_lower for p in [
        "system ka current state batao", "system state", "system info", "current state of system"
    ]):
        if is_compound_root and any(sep in raw_lower for sep in [",", ";", " phir ", " aur ", " then ", " and ", " ke baad ", " after that ", " iske baad ", " uske baad "]):
            from brain.workflow_orchestrator import orchestrate_compound_workflow
            orch_plan = orchestrate_compound_workflow(text, context)
            if orch_plan is not None and orch_plan.steps and len(orch_plan.steps) > 1:
                return orch_plan
        return Plan(steps=[PlanStep(step=1, tool="get_system_state", args={})], explanation="Retrieved system hardware and runtime state.")

    # 12.5 RAM & Process Memory Janitor (Low-Spec Hardening & Working Set Trim)
    if (
        any(p in raw_lower for p in [
            "clean ram", "free memory", "optimize memory", "ram pressure", "flush cache",
            "free background ram", "reclaim ram", "clean memory", "flush ram", "audit and reclaim ram",
            "audit_and_reclaim_ram", "memory optimize", "memory cleaner", "clear ram", "clear memory",
            "trim memory", "trim working set", "empty working set", "purge ram", "ram clean",
            "memory flush", "flush memory", "optimize ram"
        ])
        or (("ram" in raw_lower or "memory" in raw_lower) and any(w in raw_lower for w in ["clean", "optimize", "flush", "reclaim", "trim", "purge", "janitor"]))
    ):
        if is_compound_root and any(sep in raw_lower for sep in [",", ";", " phir ", " aur ", " then ", " and ", " ke baad ", " after that ", " iske baad ", " uske baad "]):
            from brain.workflow_orchestrator import orchestrate_compound_workflow
            orch_plan = orchestrate_compound_workflow(text, context)
            if orch_plan is not None and orch_plan.steps and len(orch_plan.steps) > 1:
                return orch_plan
        target_usage = 80.0
        pct_match = re.search(r'(\d+(?:\.\d+)?)\s*%', raw_lower)
        if pct_match:
            try:
                target_usage = float(pct_match.group(1))
            except ValueError:
                target_usage = 80.0
        return Plan(
            steps=[PlanStep(step=1, tool="audit_and_reclaim_ram", args={"target_usage_percent": target_usage})],
            explanation="Audited memory pressure and trimmed dormant process working sets."
        )

    # 13. System RAM / Memory Status
    if (
        any(p in raw_lower for p in ["ram kitni use ho rahi hai", "memory usage kya hai", "ram batao", "memory status", "ram kitni used hai", "memory usage", "ram used"])
        or ((bool(re.search(r'\bram\b', raw_lower)) or "memory" in raw_lower) and any(w in raw_lower for w in ["use", "used", "usage", "load", "status", "khali", "free", "utilization", "bachi", "available", "left", "check"]))
    ) and not any(w in raw_lower for w in ["process", "processes", "top", "disk", "storage"]):
        return Plan(steps=[PlanStep(step=1, tool="get_memory_status", args={})], explanation="Retrieved system memory utilization.")

    # 14. System CPU Status
    if (
        any(p in raw_lower for p in ["cpu usage kya hai", "cpu load batao", "cpu status", "computer ka cpu load check karo", "cpu load", "cpu ka load", "processor par kitna bojh", "garam ho raha"])
        or (("cpu" in raw_lower or "processor" in raw_lower) and any(w in raw_lower for w in ["load", "usage", "status", "percent", "percentage", "utilization", "bojh", "burden", "overload"]))
        or ("garam" in raw_lower and any(w in raw_lower for w in ["computer", "laptop", "pc", "machine", "system"]))
        or (any(w in raw_lower for w in ["garam", "running hot", "overheating", "thermal", "heating up"]) and any(w in raw_lower for w in ["computer", "laptop", "pc", "machine", "system"]))
    ) and not any(w in raw_lower for w in ["process", "processes", "top"]):
        return Plan(steps=[PlanStep(step=1, tool="get_cpu_status", args={})], explanation="Retrieved CPU status.")

    # 15. Power / Battery Status
    if "battery" in raw_lower or "power status" in raw_lower or "energy reserve" in raw_lower:
        return Plan(steps=[PlanStep(step=1, tool="get_battery_status", args={})], explanation="Retrieved power/battery status.")

    # 16. System Health Snapshot / Performance
    if ("system" in raw_lower or "computer" in raw_lower) and any(w in raw_lower for w in ["performance", "health", "health snapshot", "sluggish", "slow", "theek chal raha", "kaise chal raha"]):
        return Plan(steps=[PlanStep(step=1, tool="get_system_health_snapshot", args={})], explanation="Retrieved system health snapshot.")

    # -------------------------------------------------------------
    # 0.95 STORAGE, DRIVE & DISK PERFORMANCE INTENTS (Phase 2 Part 7)
    # -------------------------------------------------------------
    if any(p in raw_lower for p in [
        "format drive", "format disk", "format c:", "format d:", "partition drive", "delete partition",
        "create partition", "chkdsk /f", "chkdsk /r", "defrag drive", "wipe disk"
    ]):
        return Plan(is_direct_message=True, message_text="Disk modification, formatting, and partitioning operations are restricted for security and restricted for safety; only read-only diagnostics are permitted.")

    # 1. Storage Health & Slow Computer Diagnostics
    if any(p in raw_lower for p in [
        "storage health batao", "disk ki condition batao", "which drive is almost full", "kaunsa drive sabse zyada full hai",
        "meri sabse full drive kaunsi hai", "disk ki wajah se computer slow hai", "disk check karo", "hard drive slow kyun hai",
        "storage ki wajah se system slow hai", "storage health", "disk condition", "bhar to nahi gayi", "bhar gayi", "almost full"
    ]):
        return Plan(steps=[PlanStep(step=1, tool="get_storage_health_snapshot", args={})], explanation="Retrieved storage health snapshot.")

    # 2. Disk Activity
    if any(p in raw_lower for p in [
        "disk activity batao", "disk activity kya hai", "disk kitni busy hai", "is my disk active", "disk activity"
    ]):
        return Plan(steps=[PlanStep(step=1, tool="get_disk_activity", args={})], explanation="Retrieved disk activity metrics.")

    # 3. Disk I/O Statistics
    if any(p in raw_lower for p in [
        "disk i/o kya hai", "disk io", "disk read write", "disk i/o batao", "read write activity batao", "disk i/o"
    ]):
        return Plan(steps=[PlanStep(step=1, tool="get_disk_io", args={})], explanation="Retrieved disk I/O statistics.")

    # 4. Removable / USB Drives
    if any(p in raw_lower for p in [
        "usb drives batao", "removable drives show karo", "kaun si removable drives connected hain",
        "usb drive batao", "removable drive ka status batao", "removable drives", "usb drives"
    ]):
        return Plan(steps=[PlanStep(step=1, tool="get_removable_drives", args={})], explanation="Enumerated removable drives.")

    # 5. Disk Partitions
    if any(p in raw_lower for p in [
        "show disk partitions", "partitions batao", "meri partitions dikhao", "disk partitions", "partitions dikhao"
    ]):
        return Plan(steps=[PlanStep(step=1, tool="get_disk_partitions", args={})], explanation="Enumerated disk partitions.")

    # 6. Drive Type (e.g. "C drive ka type kya hai?", "is C drive removable?")
    if ("drive" in raw_lower or "drive:" in raw_lower or "c:" in raw_lower) and any(w in raw_lower for w in ["type kya hai", "type", "removable"]):
        drv_m = re.search(r'\b([a-zA-Z]):?\s*(?:drive)?\b', raw_lower)
        drv_cand = f"{drv_m.group(1).upper()}:" if drv_m and drv_m.group(1).upper() in "CDEFGHIJKLMNOPQRSTUVWXYZ" else "C:"
        return Plan(steps=[PlanStep(step=1, tool="get_drive_type", args={"drive": drv_cand})], explanation=f"Retrieved drive type for {drv_cand}.")

    # 7. Drive Status (e.g. "C drive ka status batao", "C: status", "drive C status", "C drive ka free space aur status inspect")
    if (
        re.search(r'\b(?:([a-zA-Z]):?\s*drive\s+ka\s+status|drive\s+([a-zA-Z]):?\s*status|([a-zA-Z]):\s*status)\b', raw_lower)
        or (("c drive" in raw_lower or "c:" in raw_lower or "drive" in raw_lower) and any(w in raw_lower for w in ["status inspect", "free space aur status", "low storage", "pop-up", "volume status"]))
    ):
        drv_m = re.search(r'\b(?:on\s+)?([a-zA-Z]):?\s*(?:drive)?\b', raw_lower)
        let = drv_m.group(1) if drv_m and drv_m.group(1).upper() in "CDEFGHIJKLMNOPQRSTUVWXYZ" else "C"
        drv_cand = f"{let.upper()}:"
        return Plan(steps=[PlanStep(step=1, tool="get_drive_status", args={"drive": drv_cand})], explanation=f"Retrieved drive status for {drv_cand}.")

    # 8. Drive Usage (e.g. "C drive kitni full hai?", "C drive usage", "disk usage kya hai?")
    if any(w in raw_lower for w in ["kitni full", "drive usage", "disk usage"]):
        drv_m = re.search(r'\b([a-zA-Z]):?\s*(?:drive)?\b', raw_lower)
        drv_cand = f"{drv_m.group(1).upper()}:" if drv_m and drv_m.group(1).upper() in "CDEFGHIJKLMNOPQRSTUVWXYZ" else ("C:" if not (context and context.last_drive) else _entity_val(context.last_drive))
        return Plan(steps=[PlanStep(step=1, tool="get_drive_usage", args={"drive": drv_cand})], explanation=f"Retrieved drive usage for {drv_cand}.")

    # 9. Free Space (e.g. "C drive mein kitni space hai?", "how much free space is on C?", "D drive ka free space batao", "hard drive ki space batao", "hard drive mein jagah kitni bachi hai?")
    if (
        any(w in raw_lower for w in ["kitni space hai", "free space", "space is left", "space remains", "how much space", "kitni jagah bachi", "kitni khali hai", "drive ki space", "free gb", "jagah kitni bachi", "drive space", "disk space"])
        or (("hard drive" in raw_lower or "disk" in raw_lower or "storage" in raw_lower or "drive" in raw_lower) and any(w in raw_lower for w in ["jagah", "space", "khali", "free"]) and any(w in raw_lower for w in ["kitni", "bachi", "remaining", "left", "remains", "check", "batao", "dikhao", "status"]))
        or (("c:" in raw_lower or "d:" in raw_lower or "c drive" in raw_lower or "d drive" in raw_lower) and any(w in raw_lower for w in ["space", "khali", "free"]))
    ):
        drv_m = re.search(r'\b(?:on\s+)?([a-zA-Z]):?\s*(?:drive)?\b', raw_lower)
        drv_cand = f"{drv_m.group(1).upper()}:" if drv_m and drv_m.group(1).upper() in "CDEFGHIJKLMNOPQRSTUVWXYZ" else ("C:" if not (context and context.last_drive) else _entity_val(context.last_drive))
        return Plan(steps=[PlanStep(step=1, tool="get_free_space", args={"drive": drv_cand})], explanation=f"Retrieved free space for {drv_cand}.")

    # 10. Drives Listing (e.g. "show my drives", "list drives", "mere drives batao", "drives dikhao", "all drives")
    if any(p in raw_lower for p in [
        "show my drives", "list drives", "mere drives batao", "computer mein kaun kaun se drives hain",
        "mere computer mein kitni drives hain", "drives dikhao", "all drives", "show drives"
    ]):
        return Plan(steps=[PlanStep(step=1, tool="get_drives", args={})], explanation="Enumerated system drives.")

    # -------------------------------------------------------------
    # 0.96 BROWSER & GUI STATE INTELLIGENCE (Phase 2 Part 8)
    # -------------------------------------------------------------
    # 1. Active / Foreground Window
    if any(any(p in c for p in [
        "which window is active", "what is the current window", "what is the active window title",
        "current window batao", "abhi ka active window batao", "active window ka title batao",
        "jo window abhi open hai uska naam batao", "current window", "active window"
    ]) for c in (lower, raw_lower)) and not any(w in lower for w in ["browser", "chrome", "edge", "firefox", "app", "application", "tab", "focused", "state", "close", "band", "minimize", "maximize", "resize", "move"]):
        return Plan(steps=[PlanStep(step=1, tool="get_active_window")])

    # 2. Foreground Application
    if any(any(p in c for p in [
        "what application is in front", "which application is active", "foreground application",
        "samnay konsa app", "samne konsa app", "konsa app active hai", "foreground app batao"
    ]) for c in (lower, raw_lower)) and not any(w in lower for w in ["close", "band", "kill", "terminate", "launch", "kholo", "open karo"]):
        return Plan(steps=[PlanStep(step=1, tool="get_foreground_application")])

    # 3. Active / Current Browser
    if any(any(p in c for p in [
        "which browser is open", "what browser am i using", "current browser", "active browser",
        "konsa browser open hai", "konsa browser chal raha hai", "konsa browser hai",
        "current browser batao", "active browser batao"
    ]) for c in (lower, raw_lower)) and not any(w in lower for w in ["page", "website", "tab", "window", "windows", "status", "close", "band", "kholo", "open karo"]):
        return Plan(steps=[PlanStep(step=1, tool="get_active_browser")])

    # 4. Running Browsers Listing
    if any(any(p in c for p in [
        "list running browsers", "show running browsers", "show browser status",
        "kon kon se browsers chal rahe hain", "running browsers batao", "kaun se browsers open hain"
    ]) for c in (lower, raw_lower)):
        return Plan(steps=[PlanStep(step=1, tool="get_running_browsers")])

    # 5. Specific Browser Status Check (including contextual: "iska status batao")
    if any(p in lower or p in raw_lower for p in [
        "is chrome open", "is edge running", "chrome open hai", "edge open hai",
        "chrome browser ka status", "edge browser ka status",
        "chrome ka status batao", "edge ka status batao", "chrome status batao", "edge status batao",
        "check if chrome is running", "is chrome running", "check chrome status"
    ]) and not any(w in lower for w in ["page", "tab", "kholo", "band", "open karo"]) and not (context and context.last_application and not context.last_browser and any(p in raw_lower for p in ["is it", "is this", "tell me its", "ye app", "woh app", "us app", "iska", "uska", "isko", "this app", "that app", "pehli wali", "first one", "doosri wali", "second one", "teesri wali", "third one"])):
        b_name = "chrome" if "chrome" in lower else "msedge"
        return Plan(steps=[PlanStep(step=1, tool="get_browser_status", args={"browser": b_name})])

    if any(p in lower or p in raw_lower for p in ["iska status batao", "uska status batao", "iska status", "uska status"]) or (lower.strip().rstrip("?") in ("status batao", "status check karo")):
        if context.last_browser:
            lb_val = str(_entity_val(context.last_browser)).lower()
            b_name = "msedge" if "edge" in lb_val else lb_val
            return Plan(steps=[PlanStep(step=1, tool="get_browser_status", args={"browser": b_name})])
        elif context.last_application:
            return Plan(steps=[PlanStep(step=1, tool="get_application_status", args={"name": _entity_val(context.last_application)})])

    # 6. Current Browser Page / Website State (including contextual: "iska current page batao")
    if any(any(p in c for p in [
        "what is the current browser page", "what website is open", "current browser page batao",
        "konsa website open hai", "chrome ka current page batao", "current website batao",
        "konsi website khuli hai", "konsa page open hai"
    ]) for c in (lower, raw_lower)) and not any(w in lower for w in ["kholo", "launch", "band", "close", "open karo"]):
        b_name = "chrome" if "chrome" in lower else ("msedge" if "edge" in lower else "")
        if not b_name and context.last_browser:
            lb_val = str(_entity_val(context.last_browser)).lower()
            b_name = "msedge" if "edge" in lb_val else lb_val
        args = {"browser": b_name} if b_name else {}
        return Plan(steps=[PlanStep(step=1, tool="get_current_browser_page", args=args)])

    if any(p in lower or p in raw_lower for p in ["iska current page", "uska current page", "iska page batao", "current page batao", "iski website batao"]):
        b_name = str(_entity_val(context.last_browser)).lower() if context.last_browser else "chrome"
        if "edge" in b_name:
            b_name = "msedge"
        return Plan(steps=[PlanStep(step=1, tool="get_current_browser_page", args={"browser": b_name})])

    # 7. Current Tab State
    if any(any(p in c for p in [
        "what tab is currently active", "active tab", "current tab", "browser ki current tab batao",
        "active tab batao", "current tab batao", "browser ki active tab kya hai", "chrome ki tab batao"
    ]) for c in (lower, raw_lower)) and not any(w in lower for w in ["switch", "jao", "kholo", "open", "close", "band", "new tab", "nayi tab"]):
        b_name = "chrome" if "chrome" in lower else ""
        if not b_name and context.last_browser:
            lb_val = str(_entity_val(context.last_browser)).lower()
            b_name = "msedge" if "edge" in lb_val else lb_val
        args = {"browser": b_name} if b_name else {}
        return Plan(steps=[PlanStep(step=1, tool="get_current_browser_tab", args=args)])

    # 8. Browser Windows Enumeration
    if any(any(p in c for p in [
        "which browser windows are open", "show browser windows", "list browser windows",
        "browser windows batao", "chrome ki windows dikhao"
    ]) for c in (lower, raw_lower)):
        b_name = "chrome" if "chrome" in lower else ""
        if not b_name and context.last_browser:
            lb_val = str(_entity_val(context.last_browser)).lower()
            b_name = "msedge" if "edge" in lb_val else lb_val
        args = {"browser": b_name} if b_name else {}
        return Plan(steps=[PlanStep(step=1, tool="get_browser_windows", args=args)])

    # 9. GUI State & Focused Element
    if any(any(p in c for p in [
        "what gui element is focused", "focused element", "focused element batao",
        "focused control batao", "focused element kya hai", "abhi focused control"
    ]) for c in (lower, raw_lower)):
        return Plan(steps=[PlanStep(step=1, tool="get_focused_element")])

    if any(any(p in c for p in [
        "current gui state", "gui state batao"
    ]) for c in (lower, raw_lower)):
        return Plan(steps=[PlanStep(step=1, tool="get_gui_state")])

    # -------------------------------------------------------------
    # 0.5 COMPUTER / DRIVE / DIRECTORY DISCOVERY INTENTS (Phase 2 Part 1)
    # -------------------------------------------------------------
    # 1. Drive Discovery: "meri drives check karo", "drives discover karo", "computer mein kya kya drives hain?", "list drives", "show drives", "mere laptop ki drives check karo"
    if (
        (any(w in lower for w in ["drives", "drive"]) and any(w in lower for w in ["check karo", "discover", "list", "show", "batao", "kya kya", "tamam", "saari", "sari", "all", "dikhao", "check"]))
        and not (any(d in lower for d in ["c drive", "d drive", "e drive", "f drive", "g drive", "c:", "d:", "e:", "f:", "g:"]) and any(w in lower for w in ["open", "kholo", "scan", "mein kya", "ke andar", "contents"]))
    ):
        if not ("open" in lower or "kholo" in lower):
            return Plan(steps=[PlanStep(step=1, tool="discover_drives", args={"include_removable": True, "include_network": True})])

    # 2. Computer Scan: "mere computer ko scan karo", "mera computer scan karo", "full laptop scan karo", "scan my computer", "poora system scan karo"
    if any(p in lower for p in ["computer scan", "laptop scan", "system scan", "scan computer", "scan laptop", "scan my computer", "scan pc", "computer ko scan"]):
        mode = "FULL" if any(w in lower for w in ["full", "poora", "pura", "tamam", "saara", "sara", "all", "complete"]) else "QUICK"
        return Plan(steps=[PlanStep(step=1, tool="scan_computer", args={"mode": mode})])

    # 3. Targeted Drive Scan: "C drive scan karo", "poora C drive scan karo", "D drive scan karo", "scan C drive"
    drive_scan_m = re.search(r'(?:scan\s+)?(?:local\s+)?(?:poora\s+|pura\s+|full\s+)?([a-zA-Z])\s*(?::\s*|\s+drive|\s+disk)\s*(?:ko\s+)?scan\s*(?:karo|kar\s+do|kardo)?', text, flags=re.IGNORECASE)
    if drive_scan_m and "scan" in lower:
        d_let = drive_scan_m.group(1).upper() + ":"
        return Plan(steps=[PlanStep(step=1, tool="scan_computer", args={"mode": "TARGETED", "target": d_let})])

    # 4. Drive Contents / Directory listing on Drive: "D drive mein kya kya hai?", "D drive ke contents", "C drive ke folders", "D drive mein kya kya folders hain", "D drive ke andar kya hai"
    drive_content_m = re.search(r'(?:local\s+)?([a-zA-Z])\s*(?::\s*|\s+drive|\s+disk)\s*(?:mein|me|ke\s+andar|ma|par)?\s*(?:kya\s+kya\s+hai|kya\s+hai|contents|folders\s+batao|ke\s+folders|folders\s+hain)', text, flags=re.IGNORECASE)
    if drive_content_m and not ("open" in lower or "kholo" in lower or "banao" in lower or "create" in lower):
        d_let = drive_content_m.group(1).upper()
        return Plan(steps=[PlanStep(step=1, tool="list_drive_contents", args={"drive": d_let, "depth": 1})])

    # 5. Targeted Folder Directory Discovery: "Downloads ke andar kya kya folders hain?", "Downloads ke folders discover karo", "Program Files mein kya installed hai?"
    dir_disc_m = re.search(r'([a-zA-Z0-9_\-\\/.\s]+?)\s*(?:ke\s+andar|mein|me|ma)?\s*(?:kya\s+kya\s+folders\s+hain|kya\s+folders\s+hain|folders\s+discover\s+karo|folders\s+find\s+karo|kya\s+installed\s+hai|ke\s+tamam\s+folders)', text, flags=re.IGNORECASE)
    if dir_disc_m and not ("file" in lower and not "folder" in lower) and not ("delete" in lower or "remove" in lower):
        tgt = dir_disc_m.group(1).strip()
        tgt = re.sub(r'^(?:mere|meri|computer|laptop|system|mein|ma|se|say)\s+', '', tgt, flags=re.IGNORECASE).strip()
        if tgt and tgt.lower() not in ("computer", "laptop", "pc", "system"):
            return Plan(steps=[PlanStep(step=1, tool="discover_directories", args={"mode": "TARGETED", "target": tgt, "max_depth": 2})])

    # 6. General Directory Discovery: "mere computer ke tamam folders find karo", "tamam folders discover karo", "mere system ki directories discover karo"
    if ("tamam folders" in lower or "saare folders" in lower or "sare folders" in lower or "directories discover" in lower or "folders discover" in lower) and not ("delete" in lower or "banao" in lower):
        return Plan(steps=[PlanStep(step=1, tool="discover_directories", args={"mode": "STANDARD", "max_depth": 2})])

    # -------------------------------------------------------------
    # 0.6 FILE INTELLIGENCE INTENTS (Phase 2 Part 2)
    # -------------------------------------------------------------
    # 1. Duplicate Files: "mere computer mein duplicate files find karo", "Downloads mein duplicate files dhundo", "find duplicate files"
    if "duplicate" in lower and any(w in lower for w in ["find", "dhundo", "search", "check", "batao", "karo"]):
        loc = "home"
        for folder_name in ["downloads", "desktop", "documents", "pictures", "videos", "music"]:
            if folder_name in lower:
                loc = folder_name.capitalize()
                break
        drive_m = re.search(r'\b([a-zA-Z])(?:\s*drive|\s*disk|:)', lower)
        if drive_m and loc == "home":
            loc = drive_m.group(1).upper() + ":"
        return Plan(steps=[PlanStep(step=1, tool="find_duplicate_files", args={"location": loc, "match_by": "hash"})])

    # 2. Largest Files: "largest files find karo", "top 10 largest files", "top 20 largest files", "sabse bari files dhundo"
    if (
        (any(p in lower for p in ["largest files", "top largest", "bari files", "badi files", "sabse bari files", "sabse badi files", "bari ho", "badi ho"])
         or (("bari" in lower or "badi" in lower) and any(w in lower for w in ["file", "files"])))
        and ("top" in lower or "largest" in lower or "find" in lower or "dhundo" in lower or "batao" in lower or "dekh" in lower or "pari" in lower)
        and not ("open" in lower or "kholo" in lower)
    ):
        top_n = 10
        top_m = re.search(r'\btop\s+(\d+)\b', lower)
        if top_m:
            top_n = int(top_m.group(1))
        loc = "home"
        for folder_name in ["downloads", "desktop", "documents", "pictures", "videos", "music"]:
            if folder_name in lower:
                loc = folder_name.capitalize()
                break
        drive_m = re.search(r'\b([a-zA-Z])(?:\s*drive|\s*disk|:)', lower)
        if drive_m and loc == "home":
            loc = drive_m.group(1).upper() + ":"
        return Plan(steps=[PlanStep(step=1, tool="get_largest_files", args={"location": loc, "top_n": top_n})])

    # 3. File Metadata / Classification Inspection: "classify file ...", "is file ki metadata dikhao", "file info batao"
    if (
        (any(p in lower for p in ["classify file", "classify", "file metadata", "file details", "file info", "file information", "metadata dikhao", "details batao"])
        and any(w in lower for w in ["file", "document", "pdf", "image", "photo"]))
        and not ("delete" in lower or "create" in lower or "banao" in lower or "kholo" in lower or "open" in lower)
    ):
        target_f = ""
        if file_ref_m:
            target_f = file_ref_m.group(1)
        elif context.last_selected_file:
            target_f = _entity_val(context.last_selected_file)
        else:
            q = re.sub(r'\b(classify\s+file|classify|file\s+metadata|file\s+details|file\s+info|metadata|details|info|dikhao|batao|check|karo|please|ki|ka|ke|is|this)\b', '', lower).strip().strip("'\"")
            if q:
                target_f = q
        if target_f:
            return Plan(steps=[PlanStep(step=1, tool="get_file_metadata", args={"path": target_f})])

    # -------------------------------------------------------------

    return None
