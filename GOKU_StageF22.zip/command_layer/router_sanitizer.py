from __future__ import annotations
import os
from pathlib import Path
import re
import sys
import time
from typing import Any, Optional, Union, List, Dict, Tuple
from dataclasses import dataclass, field

from brain.planner import (
    Plan,
    PlanStep,
    StructuredIntent,
    create_plan_from_decision,
    decompose_compound_command,
    parse_compound_request,
    resolve_step_variables,
    resolve_step_variables_with_guard,
    inject_plan_prerequisites,
    prune_plan_steps,
    build_hypothesis_investigation_plan,
    build_root_cause_investigation_plan,
    parse_conditional_goal,
    synthesize_adaptive_replan,
    decompose_into_milestones,
    restore_plan_from_checkpoint,
    build_cross_domain_plan,
    apply_cross_domain_transformation,
    build_long_horizon_exploration_plan,
    decompose_long_horizon_goal,
    compute_state_hash,
    detect_state_cycle,
    heuristic_node_score,
    expand_exploration_frontier,
    select_next_frontier_node,
    apply_reflective_history_pruning,
)
from command_layer.cognitive_reasoner import CognitiveReasoner
from command_layer.context import (
    EntityType,
    TypedEntity,
    ORDINAL_REFERENCES,
    SessionContext,
    resolve_references,
    session_context,
    update_context_from_result,
)
from command_layer.semantic_model import (
    SemanticDomain,
    SemanticAction,
    CommandIntent,
    AmbiguityType,
    ClarificationRequest,
    SymptomCategory,
    SituationType,
    ConfidenceTier,
    RiskTier,
    ConfidenceScore,
    ConfirmationRequest,
    FailureType,
    AdaptiveStrategy,
    PlanAdaptation,
    TaskLifecycleState,
    TaskMilestone,
    TaskCheckpoint,
    DomainBridgeType,
    DomainBridgeLink,
    CrossDomainWorkflow,
    HorizonDepth,
    ExplorationNode,
    SearchFrontier,
    LongHorizonReport,
    HistoryQueryType,
    ExecutionTraceRecord,
    TraceSummary,
)
from command_layer.semantic_parser import (
    parse_semantic_intent,
    create_plan_from_intent,
    resolve_in_turn_correction,
    strip_conversational_noise,
    split_compound_clauses,
    detect_symptom_category,
)
from command_layer.firewall import validate_tool_against_firewall, pre_execution_semantic_check, validate_long_horizon_action
from command_layer.state_machine import agent_state
from command_layer.validator import validate_and_sanitize_tool_arguments
from command_layer.lexer import UniversalLexer
from brain.runtime_bus import RuntimePipingBus
from security.state import confirmation_manager
from tools.utils.app_resolver import (
    APP_ALIASES,
    get_canonical_app_name,
    resolve_app,
)
from tools.utils.target_resolver import TargetType, resolve_universal_target, disambiguate_multi_candidates
from command_layer.router_base import (
    Step,
    run_tool_call,
    resolve_system_canonical_path,
    verify_post_recovery,
    verify_semantic_outcome,
    capture_environment_snapshot,
    capture_step_observation,
    detect_environment_drift,
    _entity_val,
    get_all_schemas,
    KNOWN_SITE_KEYS,
    KNOWN_APP_NAMES,
    _has_file_extension,
    _normalize_resolved_path,
    _is_conversational_folder_path,
)
from security.safety_firewall import is_safe_readonly_operation
from security.confirm import RISKY_TOOLS
from command_layer.decomposer import count_action_verbs
from brain.workflow_orchestrator import orchestrate_compound_workflow
from tools.browser import sanitize_search_query
from tools.search import parse_search_grammar
import executor.verifier
import executor.executor

from command_layer.router_cli_parser import strip_idiomatic_conditions, extract_pure_text_payload



def _isolate_browser_context(plan: Plan, raw_input: str) -> Plan:
    """
    Hardens browser context routing:
    If user input mentions 'edge' or 'msedge':
    - Sets browser='edge' for all search_web, open_url, open_browser_profile actions.
    - Suppresses redundant secondary launch_app({'name': 'chrome'}) calls.
    """
    if not plan or not getattr(plan, "steps", None):
        return plan

    lower = raw_input.lower()
    if any(b in lower for b in ["edge", "msedge"]):
        filtered_steps = []
        for step in plan.steps:
            tool_name = getattr(step, "tool", "")
            args = getattr(step, "args", {}) or {}
            # Suppress redundant secondary chrome launch
            if tool_name in ("launch_app", "open_app") and str(args.get("name", "")).lower() in ("chrome", "google chrome"):
                continue
            if tool_name in ("search_web", "open_url", "open_browser_profile", "get_current_browser_page", "get_browser_status"):
                args["browser"] = "edge"
            filtered_steps.append(step)

        plan.steps = filtered_steps
        for idx, s in enumerate(plan.steps, start=1):
            s.step = idx

    # Prune negated or cancelled launches
    final_steps = []
    text_lower = raw_input.lower()
    for s in (plan.steps if plan else []):
        if getattr(s, 'tool', '') == 'launch_app':
            app_n = str(s.args.get('name', '') or s.args.get('app_name', '')).lower()
            # If prompt says not to launch this app, drop it
            neg_patterns = [
                rf"{app_n}\s+(?:ko\s+)?(?:bilkul\s+)?(?:mat|nahi)\s+(?:kholna|kholo|launch|run)",
                rf"{app_n}\s+(?:ko\s+)?(?:kholne|launch|run)\s+ki\s+ghalti\s+mat",
                rf"{app_n}\s+(?:mat|nahi)\s+(?:kholo|launch|kholna)",
                rf"(?:mat|nahi)\s+(?:kholo|launch)\s+{app_n}\b(?!\s+(?:kholo|open|launch|run))"
            ]
            if any(re.search(pat, text_lower) for pat in neg_patterns):
                continue
            # If app name itself contains procedural negation words, drop it
            if any(w in app_n for w in ['mat', 'nahi', 'bilkul', 'kholna', 'kholo']):
                continue
        final_steps.append(s)
    if plan:
        plan.steps = final_steps
    return plan


def prune_negated_steps(plan: Plan | None, text: str) -> Plan | None:
    """
    Built-in App-Launch Negation & Active Cancellation Filter.
    - Cancelled apps (e.g. 'Chrome kholo, phir socha Chrome mat kholo Calculator kholo')
      drop the cancelled app ('Chrome' and associated web navigation) and retain only 'Calculator'.
    - Explicit launch negations (e.g. 'calculator ko bilkul launch mat karna', 'Notepad app ko run mat karna')
      do NOT emit launch_app for the negated app.
    - Explicit action negations (e.g. 'desktop par save mat karna', 'window band mat karna')
      suppress forbidden tools (save_file, close_app).
    """
    if not plan or not getattr(plan, "steps", None):
        return plan

    text_lower = text.lower()
    
    # 1. Identify cancelled or negated apps
    cancelled_apps = set()
    
    # Cancellation clauses: "phir socha <app> mat kholo", "socha <app> nahi kholte", "pehle <app> ... phir socha <app> mat"
    for m in re.finditer(r'(?:phir\s+socha|socha|nahi\s+balki|waise\s+hi|lekin\s+phir)\s+([a-zA-Z0-9_-]+)\s+(?:ko\s+)?(?:bilkul\s+)?(?:mat|nahi)\s+(?:kholna|kholo|launch|run|open)', text_lower):
        app_cand = m.group(1).lower().strip()
        if app_cand not in ('yeh', 'woh', 'is', 'us'):
            cancelled_apps.add(app_cand)

    # Direct negations: "<app> ko bilkul launch mat karna", "<app> app ko run mat karna", "<app> mat kholo"
    for m in re.finditer(r'\b([a-zA-Z0-9_-]+)(?:\s+app)?\s+(?:ko\s+)?(?:bilkul\s+)?(?:mat|nahi)\s+(?:kholna|kholo|launch|run|open|karna)', text_lower):
        app_cand = m.group(1).lower().strip()
        if app_cand not in ('bilkul', 'ko', 'app', 'se', 'par', 'pe', 'mein', 'me', 'save', 'band', 'close', 'click', 'hover'):
            cancelled_apps.add(app_cand)

    # Forward negations: "mat kholo <app>" (only if NOT immediately followed by another "kholo" / "open")
    for m in re.finditer(r'(?:mat|nahi)\s+(?:kholna|kholo|launch|run|open)\s+([a-zA-Z0-9_-]+)\b(?!\s+(?:kholo|open|launch|run))', text_lower):
        app_cand = m.group(1).lower().strip()
        if app_cand not in ('bilkul', 'ko', 'app', 'se', 'par', 'pe', 'mein', 'me', 'save', 'band', 'close', 'click', 'hover'):
            cancelled_apps.add(app_cand)

    # Explicit tool negations
    negate_save = bool(re.search(r'\b(?:save\s+(?:mat|nahi|bilkul\s+mat)|mat\s+save|don\'?t\s+save)\b', text_lower))
    negate_close = bool(re.search(r'\b(?:band\s+(?:mat|nahi|bilkul\s+mat)|close\s+(?:mat|nahi|bilkul\s+mat)|mat\s+band|mat\s+close|don\'?t\s+close)\b', text_lower))

    new_steps = []
    for s in plan.steps:
        tool_name = getattr(s, "tool", "")
        args = getattr(s, "args", {}) or {}
        
        # Tool negations
        if negate_save and tool_name in ("save_file", "save_document", "press_hotkey") and args.get("keys") == "ctrl+s":
            continue
        if negate_close and tool_name in ("close_app", "terminate_process"):
            continue

        target_app = str(args.get("name") or args.get("app_name") or args.get("browser") or "").lower().strip()
        
        # Drop launch_app / open_app for cancelled or negated app
        if tool_name in ("launch_app", "open_app"):
            if any(ca == target_app or ca in target_app or target_app in ca for ca in cancelled_apps):
                continue
            if any(w in target_app for w in ['mat', 'nahi', 'bilkul', 'kholna', 'kholo']):
                continue

        # Drop focus_app_window for cancelled app
        if tool_name == "focus_app_window" and any(ca == target_app or ca in target_app or target_app in ca for ca in cancelled_apps):
            continue

        # If chrome / browser was cancelled, drop browser search / navigation
        if any(ca in ("chrome", "browser", "edge", "firefox") for ca in cancelled_apps):
            if tool_name in ("open_url", "search_web", "open_browser_profile"):
                continue

        new_steps.append(s)

    plan.steps = new_steps
    for idx, s in enumerate(plan.steps, start=1):
        if hasattr(s, "step"):
            s.step = idx
        elif isinstance(s, dict):
            s["step"] = idx

    return plan


def sanitize_action_query(q: str) -> str:
    """
    Sanitizes search_web and type_text arguments by stripping command filler phrases.
    Strips: 'mein type karo', 'aur search kardo', 'search kardo', 'kardo', 'aur', 'likh kar', etc.
    Never returns trailing 'kardo'.
    """
    if not q or not isinstance(q, str):
        return ""
    cleaned_q = q.strip()
    m_quoted = re.search(r'[\'"]([^\'"]+)[\'"]', cleaned_q)
    if m_quoted and any(f in cleaned_q.lower() for f in ["type karo", "mein type", "search", "kardo", "likh"]):
        return m_quoted.group(1).strip()

    prefixes = [
        r'^(?:please\s+)?(?:mein\s+type\s+karo|type\s+karo\s+mein|type\s+karo|likh\s+kar|likho\s+ke|likho|enter\s+karo)\s*',
        r'^(?:aur\s+search\s+kardo|aur\s+search\s+karo|aur\s+type\s+karo|aur)\s*',
        r'^(?:search\s+mein\s+type\s+karo|search\s+bar\s+mein\s+type\s+karo|search\s+kardo|search\s+karo|search)\s*',
    ]
    for _ in range(3):
        changed = False
        for pat in prefixes:
            sub = re.sub(pat, '', cleaned_q, flags=re.IGNORECASE).strip()
            if sub != cleaned_q:
                cleaned_q = sub
                changed = True
        if not changed:
            break

    suffixes = [
        r'\s*(?:aur\s+search\s+kardo|aur\s+search\s+karo|search\s+kardo|search\s+karo|aur\s+kardo|kardo|kar\s+do|aur)$',
        r'\s*(?:likh\s+kar|type\s+karo|type\s+kar\s+do)$',
    ]
    for _ in range(3):
        changed = False
        for pat in suffixes:
            sub = re.sub(pat, '', cleaned_q, flags=re.IGNORECASE).strip()
            if sub != cleaned_q:
                cleaned_q = sub
                changed = True
        if not changed:
            break

    cleaned_q = cleaned_q.strip("'\"").strip()
    if cleaned_q.lower() in ("kardo", "kar do", "karo", "aur", "search", "search kardo", "search karo"):
        return ""
    return cleaned_q


def sanitize_url(raw_url: str) -> str:
    """Sanitizes raw URLs by stripping conversational prefixes, cleaning Markdown syntax, and formatting schemes."""
    if not raw_url:
        return ""
    raw_str = str(raw_url).strip().strip("'\"")
    # Clean URLs from Markdown link syntax: e.g. https://site](https://site) or [https://site](https://site)
    m_md = re.search(r'(https?://[^\s\]\)]+)', raw_str)
    if m_md:
        clean_url = m_md.group(1).rstrip('.,;!?')
        clean_url = re.sub(r'^https?://(?:browser|chrome|edge|firefox|brave)\s+mein\s+', '', clean_url, flags=re.IGNORECASE)
        clean_url = re.sub(r'^https?://(?:open|launch|kholo)\s+', '', clean_url, flags=re.IGNORECASE)
        if not clean_url.startswith(("http://", "https://")):
            clean_url = "https://" + clean_url
        return clean_url

    u = raw_str
    # If starts with http(s):// followed by conversational filler
    u = re.sub(r'^https?://(?:browser|chrome|edge|firefox|brave)\s+mein\s+', '', u, flags=re.IGNORECASE)
    u = re.sub(r'^https?://(?:open|launch|kholo)\s+', '', u, flags=re.IGNORECASE)
    # Strip conversational prefixes
    u = re.sub(
        r'^(?:browser\s+mein|chrome\s+mein|edge\s+mein|firefox\s+mein|in\s+browser|in\s+chrome|open|launch|kholo|chalao|start|please|zara|bhai)\s+',
        '',
        u,
        flags=re.IGNORECASE
    ).strip()
    # Strip conversational suffixes
    u = re.sub(
        r'\s+(?:kholo|open\s*kar[a-z]*|chalao|launch|start|khol\s*do|khol\s*de|khol|karo|kar\s*do|please|zara|bhai)$',
        '',
        u,
        flags=re.IGNORECASE
    ).strip()
    u = u.strip("'\"")
    if u.startswith(("http://", "https://", "about:")):
        return u
    if u.startswith("www.") or any(u.endswith(tld) or f"{tld}/" in u for tld in [".com", ".org", ".net", ".io", ".gov", ".edu", ".co", ".ai", ".app", ".dev", ".info", ".pk"]):
        return f"https://{u}"
    return u


def _canonicalize_plan_tools(plan: Plan | None) -> Plan | None:
    """Canonicalize legacy/alias tools to standard tools (e.g. read_file_text -> read_file) and sanitize conversational targets."""
    if plan and getattr(plan, "steps", None):
        sanitized_steps = []
        for s in plan.steps:
            tool_name = getattr(s, "tool", "") if hasattr(s, "tool") else (s.get("tool", "") if isinstance(s, dict) else "")
            tool_args = getattr(s, "args", {}) if hasattr(s, "args") else (s.get("args", {}) if isinstance(s, dict) else {})
            if tool_name == "read_file_text":
                if hasattr(s, "tool"):
                    s.tool = "read_file"
                elif isinstance(s, dict):
                    s["tool"] = "read_file"
                tool_name = "read_file"
            if tool_name == "launch_app" and isinstance(tool_args, dict):
                app_n = str(tool_args.get("name") or tool_args.get("app_name") or "").strip().lower()
                disallowed_shells = {"cmd", "cmd.exe", "command prompt", "powershell", "powershell.exe", "pwsh", "terminal"}
                if any(sh == app_n or app_n.startswith(sh) for sh in disallowed_shells):
                    sh_type = "powershell" if ("powershell" in app_n or "pwsh" in app_n) else "cmd"
                    if hasattr(s, "tool"):
                        s.tool = "execute_system_command"
                        s.args = {"command": "dir" if sh_type == "cmd" else "ls", "shell": sh_type}
                    elif isinstance(s, dict):
                        s["tool"] = "execute_system_command"
                        s["args"] = {"command": "dir" if sh_type == "cmd" else "ls", "shell": sh_type}
                    tool_name = "execute_system_command"
                    tool_args = s.args if hasattr(s, "args") else s["args"]
            if tool_name in ("wait_for_ui_element", "click_ui_element", "find_and_interact") and isinstance(tool_args, dict):
                q_val = str(tool_args.get("query") or tool_args.get("target_query") or tool_args.get("element") or "").strip()
                if q_val:
                    words = q_val.split()
                    conv_markers = ["active karo", "settle hone ka", "settle hone", "load hone", "intezar", "ruko", "thehro", "hone tak", "wait for"]
                    if len(words) > 5 and any(marker in q_val.lower() for marker in conv_markers):
                        if hasattr(s, "tool"):
                            s.tool = "wait_for_visual_event"
                            s.args = {"event_type": "settled"}
                        elif isinstance(s, dict):
                            s["tool"] = "wait_for_visual_event"
                            s["args"] = {"event_type": "settled"}
                        tool_name = "wait_for_visual_event"
                        tool_args = s.args if hasattr(s, "args") else s["args"]

            if tool_name in ("close_app", "manage_window") and isinstance(tool_args, dict):
                act = str(tool_args.get("action", "")).lower()
                target_name = str(tool_args.get("app_name") or tool_args.get("name") or "").lower()
                is_close = tool_name == "close_app" or act in ("close", "band karo", "terminate", "kill")
                is_browser = any(b in target_name for b in ("chrome", "google chrome", "edge", "firefox", "browser"))
                is_explicit_tab = "tab" in target_name
                if is_close and is_explicit_tab:
                    if hasattr(s, "tool"):
                        s.tool = "press_hotkey"
                        s.args = {"keys": "ctrl+w"}
                    elif isinstance(s, dict):
                        s["tool"] = "press_hotkey"
                        s["args"] = {"keys": "ctrl+w"}
                    tool_name = "press_hotkey"
                    tool_args = s.args if hasattr(s, "args") else s["args"]

            if tool_name == "find_and_interact" and isinstance(tool_args, dict):
                if "target_query" in tool_args and not tool_args.get("query"):
                    tool_args["query"] = tool_args["target_query"]
                elif "query" in tool_args and not tool_args.get("target_query"):
                    tool_args["target_query"] = tool_args["query"]
                t_raw = tool_args.get("target_query") or tool_args.get("query") or ""
                if t_raw:
                    t_san = sanitize_ui_target(t_raw)
                    tool_args["target_query"] = t_san
                    tool_args["query"] = t_san
                if tool_args.get("action") == "type":
                    sit = sanitize_action_query(tool_args.get("input_text", ""))
                    sit = extract_clean_search_query(sit) if sit else sit
                    if sit:
                        tool_args["input_text"] = sit
            if tool_name == "search_web" and isinstance(tool_args, dict):
                sq = sanitize_action_query(tool_args.get("query", ""))
                if not sq or sq.lower() in ("kardo", "kar do"):
                    continue
                tool_args["query"] = sq
            elif tool_name == "type_text" and isinstance(tool_args, dict):
                raw_text = tool_args.get("text")
                if raw_text is not None and not (str(raw_text).startswith("$") or str(raw_text).startswith("[")):
                    from command_layer.lexer import UniversalLexer
                    if UniversalLexer.is_action_noise(str(raw_text)):
                        continue
                    # Strip conversational noise clauses that leaked into payload
                    raw_text = strip_idiomatic_conditions(str(raw_text))
                    # Inline noise fragment removal (waise mausam..., suno yaar...)
                    raw_text = re.sub(r'\bwaise\s+(?:mausam|abhi|bhi)\s+\w+\s+\w+\s+hai\b[^,]*', '', raw_text, flags=re.IGNORECASE).strip()
                    raw_text = re.sub(r'\bmausam\s+\w+\s+\w+\s+hai\b', '', raw_text, flags=re.IGNORECASE).strip()
                    raw_text = re.sub(r'\bsuno\s+yaar\b[^,]*', '', raw_text, flags=re.IGNORECASE).strip()
                    raw_text = re.sub(r'\bkal\s+\w+\s+jana\s+hai\b[^,]*', '', raw_text, flags=re.IGNORECASE).strip()
                    raw_text = re.sub(r'^[\s,;]+|[\s,;]+$', '', raw_text)
                    st = extract_pure_text_payload(str(raw_text))
                    if UniversalLexer.is_action_noise(st):
                        continue
                    st = sanitize_action_query(st) if st else sanitize_action_query(str(raw_text))
                    if st and any(w in st.lower() for w in ["fast.com", "reddit.com", "daraz.pk", "wikipedia.org", "youtube.com", "search bar", "browser mein"]):
                        st = extract_clean_search_query(st)
                    if not st or st.lower() in ("kardo", "kar do"):
                        continue
                    tool_args["text"] = st
            elif tool_name == "open_url" and isinstance(tool_args, dict):
                su = sanitize_url(tool_args.get("url", ""))
                if su:
                    tool_args["url"] = su
            if tool_name == "open_folder" and _is_conversational_folder_path(tool_args.get("path", "")):
                continue
            sanitized_steps.append(s)
        plan.steps = sanitized_steps
        for idx, s in enumerate(plan.steps, start=1):
            if hasattr(s, "step"):
                s.step = idx
            elif isinstance(s, dict):
                s["step"] = idx
    return plan

def sanitize_ui_target(raw_query: str) -> str:
    if not raw_query:
        return ""
    q = raw_query.strip()
    
    # 1. Quoted string priority: if "Directions" or 'Close' exists, extract it directly
    quoted = re.findall(r'["\']([^"\']+)["\']', q)
    if quoted:
        # Filter out long sentences accidentally quoted; prefer short labels
        short_quotes = [item.strip() for item in quoted if len(item.split()) <= 4]
        if short_quotes:
            # If the user query explicitly mentions a disjunction with Close/Cancel/etc outside the quotes
            # e.g. "Accept Cookies" modal ke cross (X) ya Close button
            if any(k in q.lower() for k in ["close", "cross (x)", "cross", "cancel", "dismiss"]) and "close" not in short_quotes[0].lower():
                pass
            else:
                return short_quotes[0]

    # 2. Split on disjunctions ('ya', 'or', '/') and inspect candidate targets
    disjunctions = re.split(r'\s+(?:ya|or|/)\s+', q, flags=re.IGNORECASE)
    if len(disjunctions) > 1:
        for cand in disjunctions:
            cleaned_cand = sanitize_ui_target(cand)
            if cleaned_cand.lower() in ["close", "x", "cancel", "don't save", "accept", "dismiss", "done", "ok", "submit"]:
                return cleaned_cand
        first_cand = sanitize_ui_target(disjunctions[0])
        if first_cand:
            return first_cand

    # 3. Strip conversational and filler prefixes/suffixes
    fillers = [
        r'^(?:screen\s+par\s+aane\s+wale\s+kisi\s+bhi|screen\s+par\s+jo|upar|niche|wahan)\s+',
        r'^(?:page\s+ke|browser\s+ke|window\s+ke)\s+',
        r'\s+(?:modal/dialog\s+ke|dialog\s+box\s+ke|popup\s+ke|modal\s+ke)',
        r'\s+(?:cross\s*\(X\)\s*ya\s*|cross\s*icon\s*ya\s*)',
        r'\s+(?:button\s*aaye\s*us|button\s*ko|icon\s*ko|button\b|btn\b|icon\b)',
        r'\s+(?:locate\s+karke|dhoond\s+kar|select\s+karke|click\s+karo|par\s+click\s+karo|pe\s+click\s+karo|click\s+kardo|par\s+jao)$',
        r'\s+(?:par\s+switch\s+karo|select\s+karo|daba\s+do)$'
    ]
    for pattern in fillers:
        q = re.sub(pattern, '', q, flags=re.IGNORECASE).strip()

    # 4. Canonicalize known targets
    low = q.lower()
    if "direction" in low:
        return "Directions"
    if any(k in low for k in ["close", "cross (x)", "cross"]):
        return "Close"
    if "accept" in low:
        return "Accept"
    if "sign in" in low:
        return "Sign In"
    if "processes" in low:
        return "Processes"
    if "details" in low:
        return "Details"
    if "large icons" in low:
        return "Large icons"
    
    return q.strip(' "\'')


def extract_clean_search_query(text: str) -> str:
    """Extract clean entity query, stripping conversational instructions and search bar prefixes."""
    if not text:
        return ""
    # 1. Quoted substring priority: e.g. "ssd 512gb" or 'Coke Studio'
    q_match = re.search(r"['\"]([^'\"]+)['\"]", text)
    if q_match:
        return q_match.group(1).strip()

    # 2. Strip conversational noise and clauses
    patterns_to_remove = [
        r'\b(?:browser|chrome|edge)\s+(?:mein|me|in)\b',
        r'\b(?:https?://)?(?:www\.)?[a-zA-Z0-9_\-\.]+\.(?:com|org|net|pk|edu|gov|io|co|in|ai)\b(?:\s*(?:kholo|open|par\s+jao))?',
        r'\b(?:page\s+load\s+hone\s+tak\s+ruko|wait\s+(?:for|until)\s+page\s+load(?:ed)?)\b',
        r'\b(?:aur\s+phir|aur|phir|then|and|ke\s+baad)\b',
        r'\b(?:search\s+bar|search\s+box|search\s+input|address\s+bar)\s*(?:mein|me|par|pe)?\b',
        r'\b(?:click\s+karo|click\s+kar\s+do|tap\s+karo)\b',
        r'\b(?:search\s+karo|search\s+kar\s+do|dhundo|find\s+karo)\b',
        r'\b(?:type\s+karo|likho|likh\s+do|enter\s+karo)\b',
        r'\b(?:locate\s+karke|dhund\s+kar)\b',
        r'\b(?:please|bhi|kisi|karo|kar\s+do)\b',
    ]
    cleaned = text
    for p in patterns_to_remove:
        cleaned = re.sub(p, ' ', cleaned, flags=re.IGNORECASE)
    cleaned = re.sub(r'\s+', ' ', cleaned).strip(' ,.-"\'')
    return cleaned or "search"


