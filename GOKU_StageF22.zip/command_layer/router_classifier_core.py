from __future__ import annotations
import os
from pathlib import Path
import re
import sys
import time
from typing import Any, Optional, Union, List, Dict, Tuple
from dataclasses import dataclass, field

from brain.planner import (
    Plan,
    PlanStep,
    StructuredIntent,
    create_plan_from_decision,
    decompose_compound_command,
    parse_compound_request,
    resolve_step_variables,
    resolve_step_variables_with_guard,
    inject_plan_prerequisites,
    prune_plan_steps,
    build_hypothesis_investigation_plan,
    build_root_cause_investigation_plan,
    parse_conditional_goal,
    synthesize_adaptive_replan,
    decompose_into_milestones,
    restore_plan_from_checkpoint,
    build_cross_domain_plan,
    apply_cross_domain_transformation,
    build_long_horizon_exploration_plan,
    decompose_long_horizon_goal,
    compute_state_hash,
    detect_state_cycle,
    heuristic_node_score,
    expand_exploration_frontier,
    select_next_frontier_node,
    apply_reflective_history_pruning,
)
from command_layer.cognitive_reasoner import CognitiveReasoner
from command_layer.context import (
    EntityType,
    TypedEntity,
    ORDINAL_REFERENCES,
    SessionContext,
    resolve_references,
    session_context,
    update_context_from_result,
)
from command_layer.semantic_model import (
    SemanticDomain,
    SemanticAction,
    CommandIntent,
    AmbiguityType,
    ClarificationRequest,
    SymptomCategory,
    SituationType,
    ConfidenceTier,
    RiskTier,
    ConfidenceScore,
    ConfirmationRequest,
    FailureType,
    AdaptiveStrategy,
    PlanAdaptation,
    TaskLifecycleState,
    TaskMilestone,
    TaskCheckpoint,
    DomainBridgeType,
    DomainBridgeLink,
    CrossDomainWorkflow,
    HorizonDepth,
    ExplorationNode,
    SearchFrontier,
    LongHorizonReport,
    HistoryQueryType,
    ExecutionTraceRecord,
    TraceSummary,
)
from command_layer.semantic_parser import (
    parse_semantic_intent,
    create_plan_from_intent,
    resolve_in_turn_correction,
    strip_conversational_noise,
    split_compound_clauses,
    detect_symptom_category,
)
from command_layer.firewall import validate_tool_against_firewall, pre_execution_semantic_check, validate_long_horizon_action
from command_layer.state_machine import agent_state
from command_layer.validator import validate_and_sanitize_tool_arguments
from command_layer.lexer import UniversalLexer
from brain.runtime_bus import RuntimePipingBus
from security.state import confirmation_manager
from tools.utils.app_resolver import (
    APP_ALIASES,
    get_canonical_app_name,
    resolve_app,
)
from tools.utils.target_resolver import TargetType, resolve_universal_target, disambiguate_multi_candidates
from command_layer.router_base import (
    Step,
    run_tool_call,
    resolve_system_canonical_path,
    verify_post_recovery,
    verify_semantic_outcome,
    capture_environment_snapshot,
    capture_step_observation,
    detect_environment_drift,
    _entity_val,
    get_all_schemas,
    KNOWN_SITE_KEYS,
    KNOWN_APP_NAMES,
    _has_file_extension,
    _normalize_resolved_path,
    _is_conversational_folder_path,
)
from security.safety_firewall import is_safe_readonly_operation
from security.confirm import RISKY_TOOLS
from command_layer.decomposer import count_action_verbs
from brain.workflow_orchestrator import orchestrate_compound_workflow
from tools.browser import sanitize_search_query
from tools.search import parse_search_grammar
import executor.verifier
import executor.executor

from command_layer.router_sanitizer import (
    _isolate_browser_context,
    prune_negated_steps,
    sanitize_action_query,
    sanitize_url,
    _canonicalize_plan_tools,
    sanitize_ui_target,
    extract_clean_search_query,
)
from command_layer.router_cli_parser import (
    translate_cli_command,
    sanitize_cli_command,
    extract_pure_text_payload,
    parse_sequential_keyboard_actions,
    is_standalone_navigation_request,
    resolve_temporal_order,
    strip_idiomatic_conditions,
)
from command_layer.router_confidence import (
    determine_risk_tier,
    format_uncertainty_response,
    compute_command_confidence,
    synthesize_cross_domain_report,
    synthesize_long_horizon_report,
    get_conversational_response,
)

from command_layer.router_classifier_special1 import classify_special_intents_1
from command_layer.router_classifier_special2 import classify_special_intents_2
from command_layer.router_classifier_system1 import classify_system_intents_1
from command_layer.router_classifier_system2 import classify_system_intents_2
from command_layer.router_classifier_devices1 import classify_device_intents_1
from command_layer.router_classifier_devices2 import classify_device_intents_2
from command_layer.router_classifier_apps1 import classify_app_intents_1
from command_layer.router_classifier_apps2 import classify_app_intents_2
from command_layer.router_classifier_gui1 import classify_gui_intents_1
from command_layer.router_classifier_gui2 import classify_gui_intents_2
from command_layer.router_classifier_web import classify_web_intents
from command_layer.router_classifier_file_ops import classify_file_ops_intents
from command_layer.router_classifier_file_search import classify_file_search_intents

_PRONOUN_RX = re.compile(
    r"^\s*(?:(?:isko|usko|ise|use|pehli\s+wali|pichli\s+wali|wohi\s+wali|wo\s+wali)\s+(?:abhi\s+|phir\s+|dobara\s+|wapas\s+)?"
    r"(?:kholo|khol\s*do|khol\s*de|chalao|chala\s*do|run\s+karo|open\s+karo|launch\s+karo|start\s+karo)"
    r"|(?:open|launch|start|run)\s+(?:it|this|that|the\s+(?:app|application))(?:\s+(?:please|now|again))?)\s*[.!?]*\s*$", re.IGNORECASE)   # launch-by-reference only


_PRONOUN_CLOSE_RX = re.compile(
    r"^\s*(?:(?:isko|usko|ise|use|this|that|it)\s+(?:abhi\s+|immediately\s+|right\s+now\s+|phir\s+)?(?:band\s*(?:karo|kar\s*do|kardo)|close(?:\s+karo)?|kill\s+karo)"
    r"|(?:close|exit)\s+(?:it|this|that)(?:\s+(?:immediately|now|please))?)\s*[.!?]*\s*$", re.IGNORECASE)


def _close_by_reference(context) -> "Plan | None":
    """A bare close-pronoun is never an app name. With a file AND an app in play it is ambiguous (ask); with nothing in play it asks which app."""
    def _v(e):
        return str(getattr(e, "value", "") or "")
    f, a = _v(getattr(context, "last_file", None)), _v(getattr(context, "last_application", None))
    if f and a:
        import os as _os
        return Plan(is_direct_message=True, message_text=f"Ambiguous reference: Both file '{_os.path.basename(f.replace(chr(92), '/'))}' and application '{a}' are present in context. Which one do you mean?")
    if a:
        return Plan(steps=[PlanStep(step=1, tool="close_app", args={"name": a})])
    if not (_v(getattr(context, "last_window", None)) or _v(getattr(context, "last_launched_application", None))):
        return Plan(is_direct_message=True, message_text="Ambiguous reference: No active application or window found in recent context. Which one do you want to close?")
    return None


def _launch_by_reference(context) -> "Plan | None":
    """Bind a bare launch pronoun to the most recently active entity of its own type; types never mix (a file named Chrome.txt opens as a file)."""
    cands = []
    for kind, ent in (("app", getattr(context, "last_application", None)), ("file", getattr(context, "last_file", None)), ("folder", getattr(context, "last_folder", None))):
        val = getattr(ent, "value", None)
        if val:
            cands.append((float(getattr(ent, "timestamp", 0) or 0), kind, str(val)))
    if not cands:
        la = getattr(context, "last_launched_application", None)
        return Plan(steps=[PlanStep(step=1, tool="launch_app", args={"name": str(la)})]) if la else None
    cands.sort(reverse=True)
    _, kind, val = cands[0]
    tool, arg = {"app": ("launch_app", "name"), "file": ("open_file", "path"), "folder": ("open_folder", "path")}[kind]
    return Plan(steps=[PlanStep(step=1, tool=tool, args={arg: val})])


def _classify_and_parse_command(text: str, context: SessionContext | None = None, is_compound_root: bool = True) -> Plan | None:
    """
    Comprehensive deterministic intent classifier for Windows desktop agent.
    Routes apps, processes, files, folders, search, clipboard, browser, and document reading.
    """
    if context is None:
        from command_layer.context import session_context as _default_ctx
        context = _default_ctx

    # Conversational references ("isko kholo", "open it", "iska status batao") are bound to the active entity BEFORE classification, exactly as
    # router_dispatch does for real input. Without this, a caller that reaches the classifier directly sees the bare pronoun, and "isko kholo"
    # fell through to the folder opener (open_folder path='isko'). Ambiguous references are left untouched for the clarification path.
    if is_compound_root and _PRONOUN_CLOSE_RX.search(text):
        _cplan = _close_by_reference(context)
        if _cplan is not None:
            return _cplan
    if is_compound_root and _PRONOUN_RX.search(text):
        _plan = _launch_by_reference(context)
        if _plan is not None:
            return _plan

    for classifier in (
        classify_special_intents_1,
        classify_special_intents_2,
        classify_system_intents_1,
        classify_system_intents_2,
        classify_device_intents_1,
        classify_device_intents_2,
        classify_app_intents_1,
        classify_app_intents_2,
        classify_gui_intents_1,
        classify_gui_intents_2,
        classify_web_intents,
        classify_file_ops_intents,
        classify_file_search_intents,
    ):
        plan = classifier(text, context=context, is_compound_root=is_compound_root)
        if plan is not None:
            return plan
        if classifier is classify_special_intents_1:
            # special1 owns the safety guards and ran on the RAW text above. Self-repairs ("Chrome kholo... nahi Edge open karo", "Y ke bajaye X",
            # "X instead of Y") that it could not route itself must still reach the later classifiers as the corrected command, never as the
            # abandoned half (which used to end up as open_file/open_folder 'Chrome kholo... nahi Edge').
            _eff, _note, _ = resolve_in_turn_correction(text)
            if _note:
                text = _eff

    return None
