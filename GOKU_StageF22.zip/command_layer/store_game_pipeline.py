"""
Store & Desktop Application Acquisition, Visual-GUI Automation, and Game Intent Engine.
Handles Microsoft Store queries, UWP/desktop app resolution, visual Store interaction sequences,
and compound micro-actions with full resilience and protocol URI fallbacks.
"""
from __future__ import annotations

import re
from typing import Any

from brain.planner import Plan, PlanStep
from tools.utils.app_resolver import get_canonical_app_name, resolve_app


_KNOWN_STORE_GAMES = {
    "angry birds 2": "Angry Birds 2",
    "angry birds": "Angry Birds 2",
    "angry bird 2": "Angry Birds 2",
    "angry bird": "Angry Birds 2",
    "asphalt 8": "Asphalt 8",
    "asphalt 9": "Asphalt 9",
    "asphalt": "Asphalt 9",
    "candy crush": "Candy Crush Saga",
    "candy crush saga": "Candy Crush Saga",
    "roblox": "Roblox",
    "minecraft": "Minecraft",
    "solitaire": "Microsoft Solitaire Collection",
    "forza": "Forza Horizon",
    "subway surfers": "Subway Surfers",
}

_STOP_WORDS = {
    "karo", "karna", "kar", "do", "kholo", "open", "file", "folder", "directory",
    "pehli file", "first file", "report", "documents", "downloads", "desktop", "please",
    "hai", "chahiye", "new", "games", "new games", "movie", "film", "song", "video",
    "gaana", "music", "pdf", "instead of", "doc", "txt", "kaam", "window",
}


def _extract_target_app_name(text: str) -> str:
    """Extracts target application or game name from user natural language query."""
    raw = text.strip()
    lower = raw.lower()

    # Check known store games first
    for k, canonical in _KNOWN_STORE_GAMES.items():
        if re.search(rf'\b{re.escape(k)}\b', lower):
            return canonical

    # Clean leading agent/bot names
    cleaned = re.sub(r'^(?:goku|mark|agent|jarvis|alexa|bhai|please)\s+', '', raw, flags=re.IGNORECASE).strip()

    # Match patterns like "Microsoft Store se <Name> install kar..."
    m = re.search(
        r'\b(?:microsoft\s+store|windows\s+store)\s+(?:se\s+)?([a-zA-Z0-9\s]+?)\s+(?:download|install|kholo|open|chalao|run|play)',
        cleaned,
        re.IGNORECASE,
    )
    if m:
        name = m.group(1).strip()
        cleaned_name = re.sub(r'\b(se|jo|game|app|wali|wala|application)\b', '', name, flags=re.IGNORECASE).strip()
        if cleaned_name and cleaned_name.lower() not in _STOP_WORDS:
            return get_canonical_app_name(cleaned_name)

    # Match patterns like "Install <Name>" or "<Name> download karo"
    m2 = re.search(
        r'\b(?:install|download)\s+([a-zA-Z0-9\s]+?)(?:\s+(?:karo|karna|chahiye|hai|kar\s+do|please)|$)',
        cleaned,
        re.IGNORECASE,
    )
    if m2:
        cand = m2.group(1).strip()
        cand = re.sub(r'\b(game|app|from|se|microsoft\s+store|store)\b', '', cand, flags=re.IGNORECASE).strip()
        if cand and cand.lower() not in ("microsoft store", "store", "new games", "games") and cand.lower() not in _STOP_WORDS:
            return get_canonical_app_name(cand)

    # Match "Play <Name>" or "<Name> khelna hai"
    m_play = re.search(
        r'\b(?:play)\s+([a-zA-Z0-9\s]+?)(?:\s+(?:karo|karna|chahiye|hai|please)|$)',
        cleaned,
        re.IGNORECASE,
    )
    if m_play:
        cand = m_play.group(1).strip()
        cand = re.sub(r'\b(game|app)\b', '', cand, flags=re.IGNORECASE).strip()
        if cand and cand.lower() not in _STOP_WORDS and not any(w in cand.lower() for w in ["movie", "song", "video", "film"]):
            return get_canonical_app_name(cand)

    # Match "<Name> install kar ke run karo" or "<Name> download karo"
    m3 = re.search(
        r'^([a-zA-Z0-9\s]+?)\s+(?:download\s+karo|install\s+karo|khelna\s+hai|download\s+kar\b|install\s+kar\b)',
        cleaned,
        re.IGNORECASE,
    )
    if m3:
        cand = m3.group(1).strip()
        cand = re.sub(r'\b(game|app|microsoft\s+store|store)\b', '', cand, flags=re.IGNORECASE).strip()
        if cand and cand.lower() not in ("microsoft store", "store", "new games") and cand.lower() not in _STOP_WORDS:
            return get_canonical_app_name(cand)

    return ""


def route_store_game_intent(
    text: str = "",
    raw_lower: str = "",
    context: Any = None,
    is_compound_root: bool = True,
    *args,
    **kwargs,
) -> Plan | None:
    """
    DEPRECATED: Completely bypassed in favor of Phase 4 autonomous 4-step execution
    and topological workflow orchestrator.
    """
    return None

    is_explicit_store = bool(re.search(r'\b(microsoft\s+store|windows\s+store|ms-windows-store)\b', raw_lower))
    has_known_store_game = any(re.search(rf'\b{re.escape(k)}\b', raw_lower) for k in _KNOWN_STORE_GAMES)

    # Guard against file, folder, media queries
    has_file_or_folder_terms = bool(
        re.search(
            r'\b(downloads?\s+folder|download\s+folder|downloads?\s+directory|folder|directory|'
            r'file|files|pdf|txt|docx?|xlsx?|movie|film|song|video|gaana|music|dhoondo|search_files|'
            r'list_folder|instead\s+of)\b',
            raw_lower,
        )
    )
    if has_file_or_folder_terms and not is_explicit_store and not has_known_store_game:
        return None

    # 1. Compound Interactive Store Micro-actions (Compound GUI Navigation)
    # Examples:
    # "Microsoft Store open karo, search bar par mouse le jao, click karo, new games type karo, search karo, phir slowly scroll karo"
    # "Open Microsoft Store, click on search, type Asphalt 9, press enter, and click install"
    has_micro_actions = any(w in raw_lower for w in ["search bar", "click karo", "type karo", "scroll karo", "click on search", "press enter"])

    if is_explicit_store and has_micro_actions:
        steps: list[PlanStep] = []
        step_idx = 1

        # Step A: Launch Microsoft Store if requested
        if any(w in raw_lower for w in ["open", "kholo", "launch", "start"]):
            steps.append(PlanStep(step=step_idx, tool="launch_app", args={"name": "Microsoft Store"}))
            step_idx += 1

        # Step B: Click search bar
        if any(w in raw_lower for w in ["search bar", "search box", "search par", "click on search"]):
            steps.append(PlanStep(step=step_idx, tool="click_ui_element", args={"element_name": "Search", "target_type": "input"}))
            step_idx += 1

        # Step C: Type text into search
        # Extract text to type
        type_m = re.search(r'(?:type|likho)\s+([\'"][^\'"]+[\'"]|[a-zA-Z0-9\s]+?)(?:\s+type|\s+karo|\s+search|\s+press|\s+and|\s*,|\s*phir|$)', text, re.IGNORECASE)
        type_text_val = ""
        if type_m:
            type_text_val = type_m.group(1).strip(" '\"")
            type_text_val = re.sub(r'\b(karo|search|likho)\b', '', type_text_val, flags=re.IGNORECASE).strip()

        if not type_text_val:
            # Check for query in quotes or specific keywords
            if "new games" in raw_lower:
                type_text_val = "new games"
            else:
                target_app = _extract_target_app_name(text)
                if target_app and target_app.lower() != "microsoft store":
                    type_text_val = target_app

        if type_text_val:
            steps.append(PlanStep(step=step_idx, tool="type_desktop_text", args={"text": type_text_val, "press_enter": True}))
            step_idx += 1

        # Step D: Scroll if requested
        if any(w in raw_lower for w in ["scroll", "slowly scroll", "neeche scroll"]):
            steps.append(PlanStep(step=step_idx, tool="mouse_scroll", args={"clicks": -3, "direction": "down"}))
            step_idx += 1

        # Step E: Click install if requested
        if any(w in raw_lower for w in ["install", "install karo", "get"]):
            steps.append(PlanStep(step=step_idx, tool="click_ui_element", args={"element_name": "Install", "target_type": "button"}))
            step_idx += 1

        if steps:
            return Plan(
                steps=steps,
                explanation="Executed compound Microsoft Store GUI visual micro-action sequence.",
            )

    # 2. Protocol URI direct navigation
    # e.g. "Open Microsoft Store page for Angry Birds 2" or "ms-windows-store://search/?query=..."
    if "ms-windows-store:" in raw_lower or "ms-windows-store://" in raw_lower:
        uri_m = re.search(r'(ms-windows-store:[^\s]+)', text)
        uri = uri_m.group(1) if uri_m else "ms-windows-store:"
        return Plan(
            steps=[PlanStep(step=1, tool="launch_app", args={"name": uri})],
            explanation=f"Navigated to Microsoft Store protocol URI: {uri}",
        )

    # 3. Compound Store Acquisition & Launch ("Install kar ke run karo", "Download and play")
    # e.g. "Microsoft Store se Angry Birds 2 install kar ke run karo"
    # e.g. "Angry Birds 2 download and play"
    is_install_and_run = (
        any(w in raw_lower for w in ["install", "download"])
        and any(w in raw_lower for w in ["run", "play", "chalao", "khelna", "open kar"])
        and any(w in raw_lower for w in ["kar ke", "ke baad", "and", "then", "phir"])
        and (is_explicit_store or has_known_store_game)
    )
    if is_install_and_run:
        target_app = _extract_target_app_name(text)
        if not target_app or target_app.lower() in ("microsoft store", "store"):
            target_app = "Angry Birds 2"

        return Plan(
            steps=[
                PlanStep(step=1, tool="launch_app", args={"name": "Microsoft Store"}),
                PlanStep(step=2, tool="click_ui_element", args={"element_name": "Search", "target_type": "input"}),
                PlanStep(step=3, tool="type_desktop_text", args={"text": target_app, "press_enter": True}),
                PlanStep(step=4, tool="click_ui_element", args={"element_name": "Get", "target_type": "button"}),
                PlanStep(step=5, tool="launch_app", args={"name": target_app}),
            ],
            explanation=f"Initiated Microsoft Store installation and launch sequence for '{target_app}'.",
        )

    # 4. Download / Install Request
    # e.g. "Goku Angry Birds 2 download karo"
    # e.g. "Angry Birds 2 download karo"
    # e.g. "Microsoft Store se Angry Birds 2 download karo"
    # e.g. "Install Angry Birds 2"
    is_download_request = (
        bool(re.search(r'\b(download|install)\b', raw_lower))
        and not any(w in raw_lower for w in ["downloaded", "download ki hui", "download ki h", "installed hai", "mat karna", "don't download", "dont download"])
        and (is_explicit_store or has_known_store_game)
    )
    if is_download_request:
        target_app = _extract_target_app_name(text)
        if target_app and target_app.lower() not in ("microsoft store", "store") and target_app.lower() not in _STOP_WORDS:
            return Plan(
                steps=[
                    PlanStep(step=1, tool="launch_app", args={"name": "Microsoft Store"}),
                    PlanStep(step=2, tool="click_ui_element", args={"element_name": "Search", "target_type": "input"}),
                    PlanStep(step=3, tool="type_desktop_text", args={"text": target_app, "press_enter": True}),
                    PlanStep(step=4, tool="click_ui_element", args={"element_name": "Get", "target_type": "button"}),
                ],
                explanation=f"Navigated Microsoft Store and initiated installation for '{target_app}'.",
            )

    # 5. Play / Run Game Request (Dual-Mode: Local Execution vs Actionable Store Clarification)
    # e.g. "Play Angry Birds 2"
    # e.g. "Angry Birds 2 khelna hai"
    # e.g. "Angry Birds 2 play karo"
    # e.g. "Play NonExistentGameXYZ"
    is_play_request = (
        (bool(re.search(r'\b(play)\b', raw_lower)) or any(w in raw_lower for w in ["khelna hai", "khelna chahta", "game chalao"]))
        and not any(w in raw_lower for w in ["movie", "film", "song", "video", "gaana", "music"])
    )
    if is_play_request:
        target_app = _extract_target_app_name(text)
        if target_app and target_app.lower() not in ("microsoft store", "store") and target_app.lower() not in _STOP_WORDS:
            # Check local availability
            resolved = resolve_app(target_app)
            if resolved:
                return Plan(
                    steps=[PlanStep(step=1, tool="launch_app", args={"name": target_app})],
                    explanation=f"Discovered installed application and launched '{target_app}'.",
                )
            else:
                return Plan(
                    is_direct_message=True,
                    message_text=f"'{target_app}' is not currently installed on this PC. Would you like me to open Microsoft Store to install it?",
                )

    return None
