from __future__ import annotations
from command_layer.context_models import EntityType, TypedEntity
import gc
import json
import os
from pathlib import Path
import re
import time
from typing import Any, Optional, Dict, List, Set, Tuple

from command_layer.semantic_model import (
    PlanMutationType,
    PlanDAGNode,
    PlanMutation,
    FailureType,
    AdaptiveStrategy,
    PlanAdaptation,
    RecoveryStatus,
    CompensationAction,
    RollbackLedger,
    ObservationType,
    StepObservation,
    EnvironmentSnapshot,
    OutcomeVerdict,
    OutcomeCriteria,
    OutcomeReport,
    TaskLifecycleState,
    TaskMilestone,
    TaskCheckpoint,
    DomainBridgeType,
    DomainBridgeLink,
    CrossDomainWorkflow,
    HorizonDepth,
    ExplorationNode,
    SearchFrontier,
    LongHorizonReport,
    HistoryQueryType,
    ExecutionTraceRecord,
    TraceSummary,
    FirewallVerdict,
    AdversarialAttackRecord,
)

class SessionHistoryMixin:
    def record_cross_domain_bridge(
        self,
        source_domain: str,
        target_domain: str,
        bridge_type: str,
        source_step: int,
        target_step: int,
        payload_summary: str = ""
    ) -> None:
        """
        Records an audit entry of an inter-subsystem data bridge (Bullet #27).
        """
        entry = {
            "source_domain": str(source_domain),
            "target_domain": str(target_domain),
            "bridge_type": str(bridge_type),
            "source_step": source_step,
            "target_step": target_step,
            "payload_summary": payload_summary,
            "timestamp": time.time(),
        }
        self.cross_domain_history.append(entry)

    def get_cross_domain_lineage_summary(self, lang: str = "en") -> str:
        """
        Synthesizes an audit breakdown of coordinated subsystems and data bridges (Bullet #27).
        Answers multi-turn queries like 'Kaun kaun se systems use huye?' or 'Which subsystems were used?'.
        """
        if not self.cross_domain_history:
            return (
                "Koi cross-domain subsystem bridging record nahi mila."
                if lang == "ur"
                else "No cross-domain subsystem interactions recorded in recent session."
            )

        unique_sources = set()
        unique_targets = set()
        bridge_descriptions = []

        for b in self.cross_domain_history:
            src = b["source_domain"].upper()
            tgt = b["target_domain"].upper()
            unique_sources.add(src)
            unique_targets.add(tgt)
            b_type = b["bridge_type"]
            p_sum = b.get("payload_summary", "")
            bridge_descriptions.append(f"• {src} -> {tgt} ({b_type})" + (f": {p_sum}" if p_sum else ""))

        all_domains = sorted(list(unique_sources | unique_targets))
        domain_list_str = ", ".join(all_domains)

        if lang == "ur":
            return (
                f"Multi-Domain Coordination Report:\n"
                f"Istemaal shuda subsystems ({len(all_domains)}): {domain_list_str}\n"
                f"Data Bridges:\n" + "\n".join(bridge_descriptions)
            )

        return (
            f"Multi-Domain Subsystem Coordination Summary:\n"
            f"Active Subsystems ({len(all_domains)}): {domain_list_str}\n"
            f"Inter-Domain Bridges ({len(self.cross_domain_history)}):\n" + "\n".join(bridge_descriptions)
        )

    def clear_cross_domain_state(self) -> None:
        """Clears active cross-domain workflow and history (Bullet #27)."""
        self.cross_domain_history.clear()
        self.active_cross_domain_workflow = None

    # ==========================================================================
    # BULLET #28: LONG-HORIZON PROBLEM SOLVING & MEMORY COMPACTION
    # ==========================================================================

    def record_frontier_node(self, node: Any) -> None:
        """Records an exploration node into the session frontier (Bullet #28)."""
        if self.frontier is None:
            from command_layer.semantic_model import SearchFrontier
            self.frontier = SearchFrontier()
        if hasattr(self.frontier, "add_node"):
            self.frontier.add_node(node)
        self.long_horizon_history.append(node.to_dict() if hasattr(node, "to_dict") else dict(node))

    def compact_working_memory(self, max_steps: int = 10) -> int:
        """
        Collapses raw tool observations older than max_steps into compact factual summaries (Bullet #28 & #32).
        Purges bulky payloads while preserving typed entities and key findings.
        Enforces 4 GB RAM guard with zero memory growth and execution latency strictly < 5 ms.
        Enforces strict circular buffer hygiene:
          - execution_trace_ledger <= 25
          - adversarial_attack_history <= 25
          - observation_history <= 20
        Returns the number of compacted step entries.
        """
        compacted_count = 0
        if self.step_output_cache:
            sorted_steps = sorted(self.step_output_cache.keys())
            if len(sorted_steps) > max_steps:
                cutoff_steps = sorted_steps[:-max_steps]
                for s_idx in cutoff_steps:
                    val = self.step_output_cache[s_idx]
                    if isinstance(val, dict):
                        if not val.get("_compacted"):
                            summary_msg = val.get("summary") or val.get("message") or f"Executed step {s_idx}"
                            compacted = {
                                "success": val.get("success", True),
                                "status": val.get("status", "compacted"),
                                "summary": str(summary_msg)[:120],
                                "_compacted": True,
                            }
                            if "count" in val:
                                compacted["count"] = val["count"]
                            self.step_output_cache[s_idx] = compacted
                            compacted_count += 1

        # Bound step_lineage_trace and observation window
        if len(self.step_lineage_trace) > max_steps * 2:
            self.step_lineage_trace = self.step_lineage_trace[-max_steps * 2:]
        if len(self.observation_history) > 20:
            self.observation_history = self.observation_history[-20:]
        elif len(self.observation_history) > max_steps * 2:
            self.observation_history = self.observation_history[-max_steps * 2:]

        # Enforce circular buffer bounds for Bullet #32
        if len(self.execution_trace_ledger) > 25:
            self.execution_trace_ledger = self.execution_trace_ledger[-25:]
        if len(self.adversarial_attack_history) > 25:
            self.adversarial_attack_history = self.adversarial_attack_history[-25:]

        # Fast non-blocking generation 0 collection to purge unreachable cycles
        gc.collect(generation=0)

        return compacted_count

    def get_frontier_summary(self, lang: str = "en") -> str:
        """
        Returns a summary of the current search frontier and exploration status (Bullet #28).
        Answers queries like 'frontier status', 'kitne nodes explore huye'.
        """
        if not self.frontier or not getattr(self.frontier, "nodes", None):
            return "Koi active exploration frontier mojood nahi hai." if lang == "ur" else "No active exploration frontier in progress."

        frontier = self.frontier
        total_nodes = len(frontier.nodes)
        unexplored = sum(1 for n in frontier.nodes.values() if getattr(n, "status", "") == "UNEXPLORED")
        expanded = sum(1 for n in frontier.nodes.values() if getattr(n, "status", "") == "EXPANDED")
        dead_ends = len(frontier.dead_end_nodes)
        budget = frontier.budget_remaining

        if lang == "ur":
            return (
                f"Search Frontier Jaiza:\n"
                f"- Kul Nodes: {total_nodes}\n"
                f"- Expanded: {expanded} | Unexplored: {unexplored}\n"
                f"- Dead-Ends: {dead_ends}\n"
                f"- Baqi Budget: {budget}/{frontier.max_budget}\n"
                f"- Cycle Status: {'Cycle Detected!' if frontier.cycle_detected else 'Normal'}"
            )

        return (
            f"Search Frontier Status:\n"
            f"- Total Nodes: {total_nodes}\n"
            f"- Expanded: {expanded} | Unexplored: {unexplored}\n"
            f"- Dead-Ends: {dead_ends}\n"
            f"- Remaining Budget: {budget}/{frontier.max_budget}\n"
            f"- Loop Invariant: {'Cycle Detected' if frontier.cycle_detected else 'Stable (No cycles)'}"
        )

    def clear_frontier_state(self) -> None:
        """Clears active search frontier and long-horizon history (Bullet #28)."""
        self.frontier = None
        self.long_horizon_history.clear()
        self.last_long_horizon_report = None

    # ==============================================================================
    # BULLET #29: SELF-HISTORY & EXECUTION TRACE UTILIZATION
    # ==============================================================================

    def record_turn_trace(self, record: Any) -> None:
        """
        Appends an ExecutionTraceRecord to the active in-memory ledger and disk log (Bullet #29).
        Enforces 4 GB RAM Guard: strict circular buffer bounding at max 25 recent turns.
        """
        if record is None:
            return

        self.execution_trace_ledger.append(record)
        # Bounded circular buffer: max 25 turns in active memory
        if len(self.execution_trace_ledger) > 25:
            self.execution_trace_ledger = self.execution_trace_ledger[-25:]

        # Append-only persistent JSONL logging with 2 MB cap rotation
        try:
            rec_dict = record.to_dict() if hasattr(record, "to_dict") else dict(record)
            p = Path(self.trace_disk_log_path)
            if p.exists() and p.stat().st_size >= 2 * 1024 * 1024:
                from tools.log_rotator import rotate_log_file
                rotate_log_file(p)
            with open(self.trace_disk_log_path, "a", encoding="utf-8") as f:
                f.write(json.dumps(rec_dict) + "\n")
        except Exception:
            pass

    def get_failed_tool_actions(self, time_window_seconds: float = 600.0) -> set[tuple[str, str]]:
        """
        Returns a set of (tool_name, target) pairs that failed within the specified time window (Bullet #29).
        Used by reflective planner to avoid repeating known mistakes.
        """
        failed_set: set[tuple[str, str]] = set()
        now = time.time()

        for rec in reversed(self.execution_trace_ledger):
            rec_ts = getattr(rec, "timestamp", 0.0)
            if now - rec_ts > time_window_seconds:
                continue

            rec_success = getattr(rec, "success", True)
            if not rec_success or getattr(rec, "error_type", None):
                tools = getattr(rec, "tools_called", [])
                args_list = getattr(rec, "tool_args", [])
                for i, tool in enumerate(tools):
                    args = args_list[i] if i < len(args_list) and isinstance(args_list[i], dict) else {}
                    target = (
                        args.get("name")
                        or args.get("app")
                        or args.get("path")
                        or args.get("process")
                        or args.get("query")
                        or args.get("window")
                        or ""
                    )
                    failed_set.add((str(tool).lower(), str(target).lower()))

        # Also inspect failed_step_cache if present
        if hasattr(self, "failed_step_cache") and isinstance(self.failed_step_cache, dict):
            for f_entry in self.failed_step_cache.values():
                if isinstance(f_entry, dict):
                    tool = f_entry.get("failed_tool") or f_entry.get("original_tool") or ""
                    target = f_entry.get("target") or ""
                    if tool:
                        failed_set.add((str(tool).lower(), str(target).lower()))

        return failed_set

    def get_historical_metric(self, metric_name: str) -> list[tuple[float, Any]]:
        """
        Retrieves historical values of a metric with timestamps in chronological order (Bullet #29).
        Supported aliases:
        - wifi / wifi_status / network / internet
        - cpu / cpu_percent / cpu_usage
        - ram / ram_percent / memory
        - disk / storage / free_gb / space
        """
        norm_metric = (metric_name or "").lower().strip()
        results: list[tuple[float, Any]] = []

        for rec in self.execution_trace_ledger:
            ts = getattr(rec, "timestamp", 0.0)
            snap = getattr(rec, "telemetry_snapshot", {}) or {}
            val = None

            if norm_metric in ("wifi", "wifi_status", "network", "internet"):
                for k in ("wifi_status", "is_connected", "connected", "ssid", "network_status"):
                    if k in snap:
                        val = snap[k]
                        break
            elif norm_metric in ("cpu", "cpu_percent", "cpu_usage"):
                for k in ("cpu_percent", "cpu_usage", "cpu_status"):
                    if k in snap:
                        val = snap[k]
                        break
            elif norm_metric in ("ram", "ram_percent", "memory", "memory_percent"):
                for k in ("ram_percent", "memory_percent", "ram_status", "free_ram_gb"):
                    if k in snap:
                        val = snap[k]
                        break
            elif norm_metric in ("disk", "storage", "free_gb", "space", "free_space_gb"):
                for k in ("free_gb", "free_space_gb", "free_space", "percent_used", "storage_status"):
                    if k in snap:
                        val = snap[k]
                        break
            else:
                val = snap.get(norm_metric)

            if val is not None:
                results.append((ts, val))

        return results

    def compare_historical_metric(self, metric_name: str, current_value: Any = None) -> dict[str, Any]:
        """
        Compares past telemetry vs current value to compute delta and trend (Bullet #29).
        """
        history = self.get_historical_metric(metric_name)
        past_val = None
        past_ts = None

        if history:
            past_ts, past_val = history[-1]

        if current_value is None and past_val is not None:
            if len(history) >= 2:
                past_ts, past_val = history[-2]
                curr_ts, current_value = history[-1]

        delta = None
        trend = "unknown"
        if past_val is not None and current_value is not None:
            try:
                p_num = float(past_val)
                c_num = float(current_value)
                delta = round(c_num - p_num, 3)
                if delta > 0:
                    trend = "increased"
                elif delta < 0:
                    trend = "decreased"
                else:
                    trend = "unchanged"
            except (ValueError, TypeError):
                trend = "changed" if str(past_val) != str(current_value) else "unchanged"

        return {
            "metric": metric_name,
            "past_value": past_val,
            "past_timestamp": past_ts,
            "current_value": current_value,
            "delta": delta,
            "trend": trend,
            "history_count": len(history),
        }

    def get_trace_summary(self) -> Any:
        """
        Computes high-level factual TraceSummary aggregation (Bullet #29).
        """
        from command_layer.semantic_model import TraceSummary
        total = len(self.execution_trace_ledger)
        success_count = sum(1 for r in self.execution_trace_ledger if getattr(r, "success", True))
        fail_count = total - success_count
        unique_tools: list[str] = []
        recent_errs: list[str] = []
        last_id = self.execution_trace_ledger[-1].turn_id if self.execution_trace_ledger else 0

        for r in self.execution_trace_ledger:
            for t in getattr(r, "tools_called", []):
                if t not in unique_tools:
                    unique_tools.append(t)
            err = getattr(r, "error_message", None)
            if err and err not in recent_errs:
                recent_errs.append(err)

        return TraceSummary(
            total_turns=total,
            successful_turns=success_count,
            failed_turns=fail_count,
            unique_tools_used=unique_tools,
            recent_errors=recent_errs,
            last_turn_id=last_id,
        )

    def get_history_explanation(self, query_type: Any, param: str = "", lang: str = "en") -> str:
        """
        Authoritatively answers retrospective inquiries from trace ledger (Bullet #29).
        Supports English and Roman Urdu.
        """
        is_ur = (lang.lower() in ("ur", "urdu"))
        q_type_val = query_type.value if hasattr(query_type, "value") else str(query_type).lower()

        if not self.execution_trace_ledger:
            if is_ur:
                return "Pichli execution history mein abhi tak koi record mojood nahi hai."
            return "No previous execution records found in history."

        if q_type_val in ("recent_actions", "actions"):
            limit = 3
            try:
                if param and str(param).isdigit():
                    limit = int(param)
            except Exception:
                limit = 3
            recent = self.execution_trace_ledger[-limit:]
            if is_ur:
                lines = [f"Pichle {len(recent)} Actions Ka Jaiza:"]
                for i, r in enumerate(recent, start=1):
                    tools_str = ", ".join(r.tools_called) if r.tools_called else "No tools"
                    stat = "Kamyab" if r.success else f"Nakam ({r.error_type or 'Error'})"
                    lines.append(f"{i}. Command: '{r.raw_command}' -> Tools: [{tools_str}] | Status: {stat}")
                return "\n".join(lines)
            else:
                lines = [f"Last {len(recent)} Execution Actions:"]
                for i, r in enumerate(recent, start=1):
                    tools_str = ", ".join(r.tools_called) if r.tools_called else "None"
                    stat = "Success" if r.success else f"Failed ({r.error_type or 'Error'})"
                    lines.append(f"{i}. Command: '{r.raw_command}' -> Tools: [{tools_str}] | Status: {stat}")
                return "\n".join(lines)

        elif q_type_val in ("past_telemetry", "telemetry"):
            target_metric = param or "wifi"
            history = self.get_historical_metric(target_metric)
            if not history:
                if is_ur:
                    return f"Pehle '{target_metric}' ke mutalliq koi telemetry record nahi hui thi."
                return f"No prior telemetry recorded for '{target_metric}'."
            last_ts, last_val = history[-1]
            if is_ur:
                return f"Pichli baar '{target_metric}' check kiya tha to status yeh tha: {last_val}."
            return f"Previous recorded telemetry for '{target_metric}': {last_val}."

        elif q_type_val in ("failure_reason", "failure", "error"):
            failed_rec = None
            for r in reversed(self.execution_trace_ledger):
                if not getattr(r, "success", True) or getattr(r, "error_type", None):
                    failed_rec = r
                    break
            if not failed_rec:
                if is_ur:
                    return "Pichli execution history mein koi failed command nahi mili. Tamam tasks kamyab rahe."
                return "No failed commands found in recent execution history. All tasks succeeded."
            err_type = failed_rec.error_type or "UnknownError"
            err_msg = failed_rec.error_message or "Execution failed"
            if is_ur:
                return f"Pichli command '{failed_rec.raw_command}' nakam hui thi.\nWajah (Failure Reason): [{err_type}] {err_msg}."
            return f"Previous command '{failed_rec.raw_command}' failed.\nFailure Reason: [{err_type}] {err_msg}."

        elif q_type_val in ("tool_usage_count", "tool_count"):
            tool_name = (param or "").lower().strip()
            count = 0
            for r in self.execution_trace_ledger:
                for t in r.tools_called:
                    if tool_name in t.lower():
                        count += 1
            if is_ur:
                return f"Tool '{tool_name}' kul {count} dafa istemal hua hai."
            return f"Tool '{tool_name}' was executed {count} time(s)."

        elif q_type_val in ("comparative_metric", "compare"):
            target_metric = param or "free_gb"
            comp = self.compare_historical_metric(target_metric)
            if comp["past_value"] is None:
                if is_ur:
                    return f"'{target_metric}' ke liye mawazna (comparison) karne ke waste pichla record mojood nahi."
                return f"Insufficient historical telemetry to compare '{target_metric}'."
            p_val = comp["past_value"]
            c_val = comp["current_value"]
            trend = comp["trend"]
            delta = comp["delta"]
            if is_ur:
                trend_ur = "zyada (increased)" if trend == "increased" else ("kam (decreased)" if trend == "decreased" else "barabar (unchanged)")
                delta_str = f" (Farq: {delta})" if delta is not None else ""
                return f"Mawazna ({target_metric}): Pehle {p_val} tha, ab {c_val} hai. Trend: {trend_ur}{delta_str}."
            return f"Comparative Telemetry ({target_metric}): Prior value was {p_val}, current is {c_val}. Trend: {trend} (Delta: {delta})."

        else:
            summary = self.get_trace_summary()
            if is_ur:
                return f"Execution Trace Jaiza: Kul Turns: {summary.total_turns} | Kamyab: {summary.successful_turns} | Nakam: {summary.failed_turns}."
            return f"Execution Trace Summary: Total Turns: {summary.total_turns} | Succeeded: {summary.successful_turns} | Failed: {summary.failed_turns}."

    def record_adversarial_attack(self, record: Any) -> None:
        """
        Records an intercepted adversarial attack, prompt injection, or jailbreak attempt (Bullet #30).
        Enforces 4 GB RAM Guard: strictly bounded circular buffer (max 25 entries).
        """
        if record is None:
            return
        self.adversarial_attack_history.append(record)
        if len(self.adversarial_attack_history) > 25:
            self.adversarial_attack_history = self.adversarial_attack_history[-25:]

