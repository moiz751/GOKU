from __future__ import annotations
import os
from pathlib import Path
import re
import sys
import time
from typing import Any, Optional, Union, List, Dict, Tuple
from dataclasses import dataclass, field

from brain.planner import (
    Plan,
    PlanStep,
    StructuredIntent,
    create_plan_from_decision,
    decompose_compound_command,
    parse_compound_request,
    resolve_step_variables,
    resolve_step_variables_with_guard,
    inject_plan_prerequisites,
    prune_plan_steps,
    build_hypothesis_investigation_plan,
    build_root_cause_investigation_plan,
    parse_conditional_goal,
    synthesize_adaptive_replan,
    decompose_into_milestones,
    restore_plan_from_checkpoint,
    build_cross_domain_plan,
    apply_cross_domain_transformation,
    build_long_horizon_exploration_plan,
    decompose_long_horizon_goal,
    compute_state_hash,
    detect_state_cycle,
    heuristic_node_score,
    expand_exploration_frontier,
    select_next_frontier_node,
    apply_reflective_history_pruning,
)
from command_layer.cognitive_reasoner import CognitiveReasoner
from command_layer.context import (
    EntityType,
    TypedEntity,
    ORDINAL_REFERENCES,
    SessionContext,
    resolve_references,
    session_context,
    update_context_from_result,
)
from command_layer.semantic_model import (
    SemanticDomain,
    SemanticAction,
    CommandIntent,
    AmbiguityType,
    ClarificationRequest,
    SymptomCategory,
    SituationType,
    ConfidenceTier,
    RiskTier,
    ConfidenceScore,
    ConfirmationRequest,
    FailureType,
    AdaptiveStrategy,
    PlanAdaptation,
    TaskLifecycleState,
    TaskMilestone,
    TaskCheckpoint,
    DomainBridgeType,
    DomainBridgeLink,
    CrossDomainWorkflow,
    HorizonDepth,
    ExplorationNode,
    SearchFrontier,
    LongHorizonReport,
    HistoryQueryType,
    ExecutionTraceRecord,
    TraceSummary,
)
from command_layer.semantic_parser import (
    parse_semantic_intent,
    create_plan_from_intent,
    resolve_in_turn_correction,
    strip_conversational_noise,
    split_compound_clauses,
    detect_symptom_category,
)
from command_layer.firewall import validate_tool_against_firewall, pre_execution_semantic_check, validate_long_horizon_action
from command_layer.state_machine import agent_state
from command_layer.validator import validate_and_sanitize_tool_arguments
from command_layer.lexer import UniversalLexer
from brain.runtime_bus import RuntimePipingBus
from security.state import confirmation_manager
from tools.utils.app_resolver import (
    APP_ALIASES,
    get_canonical_app_name,
    resolve_app,
)
from tools.utils.target_resolver import TargetType, resolve_universal_target, disambiguate_multi_candidates
from command_layer.router_base import (
    Step,
    run_tool_call,
    resolve_system_canonical_path,
    verify_post_recovery,
    verify_semantic_outcome,
    capture_environment_snapshot,
    capture_step_observation,
    detect_environment_drift,
    _entity_val,
    get_all_schemas,
    KNOWN_SITE_KEYS,
    KNOWN_APP_NAMES,
    _has_file_extension,
    _normalize_resolved_path,
    _is_conversational_folder_path,
)
from security.safety_firewall import is_safe_readonly_operation
from security.confirm import RISKY_TOOLS
from command_layer.decomposer import count_action_verbs
from brain.workflow_orchestrator import orchestrate_compound_workflow
from tools.browser import sanitize_search_query
from tools.search import parse_search_grammar
import executor.verifier
import executor.executor

from command_layer.router_sanitizer import (
    _isolate_browser_context,
    prune_negated_steps,
    sanitize_action_query,
    sanitize_url,
    _canonicalize_plan_tools,
    sanitize_ui_target,
    extract_clean_search_query,
)
from command_layer.router_cli_parser import (
    translate_cli_command,
    sanitize_cli_command,
    extract_pure_text_payload,
    parse_sequential_keyboard_actions,
    is_standalone_navigation_request,
    resolve_temporal_order,
    strip_idiomatic_conditions,
)
from command_layer.router_confidence import (
    determine_risk_tier,
    format_uncertainty_response,
    compute_command_confidence,
    synthesize_cross_domain_report,
    synthesize_long_horizon_report,
    get_conversational_response,
)
from command_layer.router_classifier_core import _classify_and_parse_command

from command_layer.router_classifier_core import _classify_and_parse_command

def dispatch_and_resolve_plan(user_text: str, session_context: Any = None, plan: Plan | None = None, raw_input: str = '', is_correction: bool = False) -> Any:
    destructive_plan = None
    from command_layer.router_executor import handle_command
    situational_triggers = [
        "determine whether ram exhaustion", "work out if my current connectivity issue",
        "if system telemetry doesn't have enough history", "state that cause is unknown",
        "multiple possible reasons why", "evaluate whether cpu, ram, or storage",
        "conclusive evidence or if the cause cannot be established"
    ]
    norm_lower = raw_input.lower()
    is_situational = any(t in norm_lower for t in situational_triggers) or (
        any(w in norm_lower for w in ["figure out", "work out", "investigate", "find out", "determine", "observe", "re-check", "dekhna", "check karna", "pata karo", "check karo", "dekh"])
        and any(w in norm_lower for w in ["problem", "wrong", "causing", "unusual", "bottleneck", "issue", "dead", "strange", "messed up", "acting", "stuck", "consuming", "anomalies", "not responding", "unresponsive", "disconnected", "spike", "cleared", "interrupted", "degraded", "relying", "running", "slow", "memory"])
    ) or any(p in norm_lower for p in [
        "browser stuck", "stuck ho gaya", "ajeeb behave", "ajeeb chal", "kya scene", "masla", "heavy chal", "delay ho raha",
        "pages thore slow", "pop-up", "low storage", "computer slow", "pc slow",
        "kitni ram", "kitna ram", "kitna cpu", "kitni cpu", "kitna memory", "kitni memory",
        "how much ram", "how much memory", "how much cpu", "eating all ram", "saari ram",
        "saari memory", "ram le raha", "cpu le raha", "memory le raha", "le raha hai", "le rahi hai"
    ])
    normalized_input = raw_input
    clean_lower = raw_input.lower()
    # --- Phase 0.5: Continuity Re-execution ("again" / "dobara") ---
    if clean_lower in ("again", "run again", "do again", "do it again", "dobara karo", "phir se karo", "dobara", "phir se"):
        last_succ = agent_state.last_success
        if last_succ and last_succ.get("raw_command"):
            return handle_command(last_succ["raw_command"])
        elif agent_state.last_action and agent_state.last_success:
            tool = agent_state.last_success.get("selected_tool")
            args = agent_state.last_success.get("arguments", {})
            if tool and tool != "none":
                return run_tool_call(tool, args).get("message", "Command re-executed.")
        return "No previous successful command in context to repeat."

    # --- Phase 0.55: Evidence-Based Reasoning Inquiry ("why", "kyun", "kese pata chala") (Bullet #16) ---
    reasoning_query_triggers = [
        "why", "kyun", "kyu", "kese pata chala", "kaise pata chala", "reason batao",
        "wajah batao", "explain this", "explain why", "how do you know",
        "show reasoning", "show deduction", "show evidence", "why did you say that"
    ]
    if clean_lower in reasoning_query_triggers or any(clean_lower.startswith(t) for t in ["why did you say", "how do you know", "kese pata chala"]):
        if session_context.last_inference:
            from tools.diagnostic_synthesizer import format_inference_result
            return format_inference_result(session_context.last_inference)

    # --- Phase 0.56: Multi-Turn Hypothesis Ledger Inquiry (Bullet #17) ---
    # 1. Broad ledger queries ("kya kya check kiya", "what was tested", "show hypotheses", etc.)
    ledger_query_triggers = [
        "kya kya check kiya", "kya check kiya tha", "kya check kiya", "what did you check",
        "what was checked", "show hypotheses", "show hypothesis", "hypothesis ledger",
        "hypothesis ledger dikhao", "konsi hypotheses eliminate huin", "what was eliminated",
        "hypothesis report", "hypotheses list", "check hypotheses", "list hypotheses"
    ]
    if clean_lower in ledger_query_triggers or any(clean_lower.startswith(q) for q in ["show hypotheses", "kya kya check kiya", "what was checked", "what did you check", "hypothesis ledger"]):
        if session_context.last_hypothesis_ledger:
            from tools.diagnostic_synthesizer import format_hypothesis_ledger
            return format_hypothesis_ledger(session_context.last_hypothesis_ledger)

    # 2. Specific hypothesis queries ("DNS check kiya tha?", "Was Wi-Fi tested?", "RAM check kiya?", etc.)
    specific_hyp_m = re.search(r'\b(dns|wifi|wi-fi|network|internet|cpu|ram|memory|storage|drive|disk|process|processes)\b.*?(?:check\s+kiya|check\s+hua|check\s+hue|check\s+huye|tested|test\s+hua|test\s+hue|check\s+kiya\s+tha|kiya\s+tha|hua\s+tha|hue\s+the|hue\s+thay)', clean_lower)
    if not specific_hyp_m:
        specific_hyp_m = re.search(r'(?:did\s+you\s+check|was\s+there|have\s+you\s+checked|was)\s+.*?\b(dns|wifi|wi-fi|network|internet|cpu|ram|memory|storage|drive|disk|process|processes)\b', clean_lower)
    if not specific_hyp_m:
        specific_hyp_m = re.search(r'\bkya\s+.*?\b(dns|wifi|wi-fi|network|internet|cpu|ram|memory|storage|drive|disk|process|processes)\b.*?(?:check|test|hue|hua|kiya)', clean_lower)

    if specific_hyp_m and session_context.last_hypothesis_ledger:
        kw = specific_hyp_m.group(1).lower()
        ledger = session_context.last_hypothesis_ledger
        found_hyp = None
        for h in ledger.hypotheses:
            h_text = (h.name + " " + h.test_tool + " " + h.description).lower()
            if kw in h_text:
                found_hyp = h
                break
        if found_hyp:
            from command_layer.semantic_model import HypothesisStatus
            if found_hyp.status == HypothesisStatus.ELIMINATED:
                return f"Haan, '{found_hyp.name}' hypothesis test kiya gaya tha aur eliminate ho gaya. Wajah: {found_hyp.elimination_reason}"
            elif found_hyp.status == HypothesisStatus.CONFIRMED:
                return f"Haan, '{found_hyp.name}' hypothesis test kiya gaya tha aur confirm ho gaya. Wajah: {found_hyp.confirmation_reason}"
            elif found_hyp.status in (HypothesisStatus.SUPPORTED, HypothesisStatus.TESTING):
                return f"Haan, '{found_hyp.name}' test kiya gaya tha aur telemetry evidence isko support karti hai."
            else:
                return f"'{found_hyp.name}' hypothesis formulate kiya gaya tha magar conclusive early-exit ki wajah se test karne ki zaroorat nahi padi."
        else:
            return f"Nahi, pichli investigation ('{ledger.symptom}') mein '{kw}' se mutalliq koi specific hypothesis shamil nahi tha."

    # --- Phase 0.56: Multi-Turn Observation & Drift Recall (Bullet #24) ---
    obs_query_triggers = [
        "observation", "screen ki halat", "file ki halat", "system ki halat",
        "kya halat thi", "kya haalat thi", "what was observed", "drift detect hua",
        "drift hua kya", "environment drift", "pichli observation", "last observation",
        "observation report", "physical state", "state after step", "pehli observation",
        "screen kaisa tha", "file kaisa tha", "drift kya tha", "drift details"
    ]
    is_obs_query = any(t in clean_lower for t in obs_query_triggers)
    if is_obs_query and not any(w in clean_lower for w in ["hypo", "root cause", "5 whys"]):
        step_target = None
        m_step = re.search(r'\bstep\s*(\d+)\b', clean_lower)
        if m_step:
            step_target = int(m_step.group(1))
        elif any(w in clean_lower for w in ["pehle step", "pehla step", "first step"]):
            step_target = 1
        elif any(w in clean_lower for w in ["doosre step", "doosra step", "second step"]):
            step_target = 2
        elif any(w in clean_lower for w in ["teesre step", "teesra step", "third step"]):
            step_target = 3

        is_urdu = any(w in clean_lower for w in ["kya", "halat", "haalat", "thi", "tha", "hua", "pehle", "batao", "dikhao", "kaisa", "pichli"])
        lang = "ur" if is_urdu else "en"

        if "drift" in clean_lower:
            last_obs = session_context.get_last_observation()
            if not last_obs and not session_context.observation_history:
                return "Abhi tak koi environment observation ya drift record nahi hui." if is_urdu else "No environment observations or drifts recorded yet."
            drift_obs = [o for o in session_context.observation_history if getattr(o, "drift_detected", False)]
            if drift_obs:
                d = drift_obs[-1]
                if is_urdu:
                    return f"Haan, Step {d.step_num} ke baad environment drift detect hua tha! Wajah: {d.drift_reason}. Details: {d.drift_details}"
                else:
                    return f"Yes, environment drift was detected after Step {d.step_num}! Reason: {d.drift_reason}. Details: {d.drift_details}"
            else:
                return "Nahi, execution ke dauran koi unexpected environment drift detect nahi hua. System stable tha." if is_urdu else "No unexpected environment drift was detected during execution. The system remained stable."

        explanation = session_context.get_observation_explanation(step_num=step_target, lang=lang)
        if explanation and not explanation.startswith("No observation"):
            return explanation
        elif not session_context.observation_history:
            return "Pichli execution mein koi physical observation capture nahi hui thi." if is_urdu else "No physical observations were recorded from the previous execution."

    # --- Phase 0.56b: Multi-Turn Outcome Verification Recall (Bullet #25) ---
    outcome_query_triggers = [
        "did it actually work", "did it work", "did it really work",
        "did the task succeed", "was the goal achieved", "is the goal fulfilled",
        "was it verified", "verify outcome", "check outcome", "outcome report",
        "kya kaam waqayi complete ho gaya", "kya kaam mukammal ho gaya",
        "kya waqayi ho gaya", "kya sach mein ho gaya", "kya kaam ho gaya",
        "kya physical result mila", "kya file ban gayi sach mein", "kya goal achieve hua",
        "kya physical reality verify hui", "outcome kaisa tha", "outcome kya hai",
        "show outcome report", "show outcome verification", "outcome proof",
        "did it succeed", "was it successful physically", "physical proof",
        "kya proof hai", "physical evidence", "kya physical suboot hai"
    ]
    is_outcome_query = (
        clean_lower in outcome_query_triggers or
        any(t in clean_lower for t in [
            "did it actually work", "did it work", "did it really work", "kya kaam waqayi",
            "kya waqayi ho gaya", "kya waqayi mukammal hua", "kya waqayi",
            "kya sach mein ho gaya", "kya physical reality", "kya kaam ho gaya",
            "outcome report", "outcome verification", "was the goal achieved",
            "physical suboot", "physical proof", "did it succeed", "was it successful"
        ])
    )
    if is_outcome_query and not any(w in clean_lower for w in ["observation", "drift", "hypo", "root cause"]):
        is_urdu = any(w in clean_lower for w in ["kya", "waqayi", "mukammal", "sach", "batao", "dikhao", "kaisa", "pichli", "hai", "tha", "hui", "suboot"])
        lang = "ur" if is_urdu else "en"
        return session_context.get_outcome_explanation(lang=lang)

    # --- Phase 0.57: Multi-Turn Root-Cause & Remediation Inquiry (Bullet #18) ---
    # 1. Root cause inquiries ("root cause kya hai", "what is the root cause", "asal wajah kya hai", "show root cause", "5 whys")
    rca_query_triggers = [
        "root cause kya hai", "root cause kya thi", "root cause", "what is the root cause",
        "what caused this", "asal wajah kya hai", "asal wajah batao", "show root cause",
        "root cause report", "5 whys", "five whys", "causal chain", "show causal chain",
        "why did it happen", "originator entity", "asal reason kya tha"
    ]
    if clean_lower in rca_query_triggers or any(clean_lower.startswith(q) for q in ["root cause", "what is the root cause", "asal wajah", "show 5 whys", "5 whys"]):
        if session_context.last_root_cause_report:
            from tools.diagnostic_synthesizer import format_root_cause_report
            return format_root_cause_report(session_context.last_root_cause_report)

    # 2. Remediation inquiries ("how to fix", "remediation kya hai", "isko fix kaise karein", "solution batao")
    remediation_query_triggers = [
        "how to fix", "how do i fix", "how can i fix", "what is the fix", "remediation",
        "remediations", "remediation kya hai", "remediation batao", "isko fix kaise karein",
        "solution kya hai", "solution batao", "recommendations", "fix batao", "how to resolve"
    ]
    if clean_lower in remediation_query_triggers or any(clean_lower.startswith(q) for q in ["how to fix", "remediation", "solution", "isko fix kaise"]):
        if session_context.last_root_cause_report:
            rc_rep = session_context.last_root_cause_report
            if rc_rep.remediations:
                lines = [
                    f"=== TARGETED MINIMAL REMEDIATION FOR [{rc_rep.root_entity}] ===",
                    f"Root Cause: {rc_rep.root_cause}",
                    ""
                ]
                for idx, r in enumerate(rc_rep.remediations, 1):
                    lines.append(f"{idx}. ({r.action_type}) Target: {r.target} [Risk: {r.risk_level.upper()}]")
                    lines.append(f"   Action: {r.description}")
                    if r.command:
                        lines.append(f"   Command: `{r.command}`")
                return "\n".join(lines)
            else:
                return f"Root cause is '{rc_rep.root_cause}'. No disruptive actions required; system is operating normally."

    # --- Phase 0.58: Hypothesis-Driven Diagnostic Investigation Dispatch (Bullet #17) ---
    hyp_dispatch_triggers = ["hypothesis", "hypotheses", "hypo", "eliminate competing", "competing causes", "test alternatives"]
    is_hyp_dispatch = any(w in clean_lower for w in hyp_dispatch_triggers) and not any(w in clean_lower for w in ["show", "list", "dikhao", "report", "kya kya"])

    if plan is None:
        plan = destructive_plan
    if is_hyp_dispatch and plan is None:
        from tools.diagnostic_synthesizer import generate_hypotheses_for_symptom
        from brain.planner import build_hypothesis_investigation_plan
        core_symptom = clean_lower
        for tw in hyp_dispatch_triggers:
            core_symptom = core_symptom.replace(tw, "")
        core_symptom = re.sub(r'\b(?:test|check|investigate|karo|do|kar do|diagnose|find)\b', '', core_symptom).strip(" ,.-:?")
        if not core_symptom:
            core_symptom = "system performance"
        ledger = generate_hypotheses_for_symptom(core_symptom)
        plan = build_hypothesis_investigation_plan(ledger, raw_input)
        session_context.record_hypothesis_ledger(ledger)

    # --- Phase 0.59: Root-Cause Analysis Investigation Dispatch (Bullet #18) ---
    rca_dispatch_triggers = [
        "find root cause", "diagnose root cause", "root cause diagnose karo",
        "asal wajah pata karo", "asal wajah dhoondo", "root cause analysis",
        "trace root cause", "deep root cause", "identify root cause", "underlying cause"
    ]
    is_rca_dispatch = any(w in clean_lower for w in rca_dispatch_triggers) or (
        ("root cause" in clean_lower or "asal wajah" in clean_lower)
        and not any(w in clean_lower for w in ["kya hai", "kya thi", "batao", "show", "report"])
    )
    if is_rca_dispatch and plan is None:
        from brain.planner import build_root_cause_investigation_plan
        core_sym = clean_lower
        for tw in rca_dispatch_triggers + ["root cause", "asal wajah"]:
            core_sym = core_sym.replace(tw, "")
        core_sym = re.sub(r'\b(?:find|diagnose|karo|do|pata|dhoondo|investigate|check|test)\b', '', core_sym).strip(" ,.-:?")
        if not core_sym:
            core_sym = "system performance degradation"
        plan = build_root_cause_investigation_plan(core_sym, raw_input)
    active_domain = SemanticDomain.UNKNOWN
    active_action = SemanticAction.OPEN
    semantic_intent = None
    active_target = ""

    # --- Phase 0.52: Long-Horizon Problem Solving Dispatch (Bullet #28) ---
    if plan is None:
        plan = build_long_horizon_exploration_plan(normalized_input, session_context)

    # --- Phase 0.525: Check Explicit Decomposed Plan (Supports Bullet #14 Mocks & Conditionals) ---
    if plan is None:
        decomp_override = decompose_compound_command(normalized_input)
        if isinstance(decomp_override, Plan):
            plan = decomp_override

    # --- Phase 0.53: Cross-Domain Problem Solving Dispatch (Bullet #27) ---
    is_compound_syntax = bool(re.search(
        r'[,;]|\b(?:aur|and|phir|then|after that|uske baad|iske baad)\b|\n',
        normalized_input.lower()
    ))
    skip_cross_domain = False
    if plan is None and is_compound_syntax:
        from command_layer.decomposer import decompose_compound_command as decomp_intents
        sub_intents = decomp_intents(normalized_input)
        if len(sub_intents) >= 2:
            is_canonical_cross = bool(
                (any(w in normalized_input.lower() for w in ["archive", "zip"]) and any(w in normalized_input.lower() for w in ["space", "storage"])) or
                (any(w in normalized_input.lower() for w in ["search", "find", "dhoondo", "dhundo"]) and any(w in normalized_input.lower() for w in [".pdf", ".html", ".docx", ".txt", "quarterly"]) and any(w in normalized_input.lower() for w in ["chrome", "browser"]) and any(w in normalized_input.lower() for w in ["screenshot", "snapshot", "tasweer"])) or
                (any(w in normalized_input.lower() for w in ["internet", "wifi"]) and any(w in normalized_input.lower() for w in ["settings", "ms-settings"])) or
                (any(w in normalized_input.lower() for w in ["diagnose", "diagnostics"]) and any(w in normalized_input.lower() for w in ["heavy process", "top process", "find process", "process dhundo"])) or
                (any(w in normalized_input.lower() for w in ["diagnose", "system health"]) and any(w in normalized_input.lower() for w in ["health.html", "system_health_report"]) and any(w in normalized_input.lower() for w in ["chrome", "browser"]))
            )
            if not is_canonical_cross:
                skip_cross_domain = True
                from brain.workflow_orchestrator import orchestrate_compound_workflow
                orch_plan = orchestrate_compound_workflow(normalized_input, session_context)
                if orch_plan is not None and orch_plan.steps and not getattr(orch_plan, "is_direct_message", False):
                    plan = orch_plan
                    active_domain = SemanticDomain.UNKNOWN
                    active_action = SemanticAction.OPEN
                    active_target = "compound_workflow"

    if plan is None and not skip_cross_domain:
        plan = build_cross_domain_plan(normalized_input, session_context)

    # --- Phase 0.55: Bullet #19 Conditional Decision Making ---
    if plan is None and re.search(r'\b(?:if|agar|in case|jab|agar kabhi|check if)\b', normalized_input.lower()):
        plan = parse_conditional_goal(normalized_input)

    # --- Phase 0.6: Bullet #11 Symptom & Situation Recognition ---
    symptom_cat, situation_type, symptom_entities = detect_symptom_category(normalized_input)
    is_compound_syntax = bool(re.search(r'[,;]|\b(?:aur|and|phir|then|after that|uske baad|agar|if)\b|\n', normalized_input.lower()))
    if plan is None and symptom_cat != SymptomCategory.NONE and not is_compound_syntax:
        plan = _classify_and_parse_command(normalized_input, session_context)
        if plan:
            active_domain = SemanticDomain.DIAGNOSTICS
            active_action = SemanticAction.DIAGNOSE
            active_target = plan.explanation

    # --- Phase 0.8: Multi-Intent Orchestrator & Compound Workflows ---
    if plan is None:
        decomp_result = decompose_compound_command(normalized_input)
        if isinstance(decomp_result, Plan):
            plan = decomp_result
        elif isinstance(decomp_result, (list, tuple)) and len(decomp_result) > 1:
            from brain.workflow_orchestrator import orchestrate_compound_workflow
            orch_plan = orchestrate_compound_workflow(normalized_input, session_context)
            if orch_plan is not None and orch_plan.steps:
                plan = orch_plan
                active_domain = SemanticDomain.UNKNOWN
                active_action = SemanticAction.OPEN
                active_target = "compound_workflow"

    # Check deterministic parser first for known web site destinations (e.g. 'Chrome mein YouTube kholo')
    has_site_destination = any(re.search(rf'\b{site_key}\b', normalized_input.lower()) for site_key in KNOWN_SITE_KEYS)
    if plan is None and has_site_destination:
        site_plan = _classify_and_parse_command(normalized_input, session_context)
        if site_plan and site_plan.steps and any(s.tool in ("open_url", "search_web") for s in site_plan.steps):
            plan = site_plan

    # --- Phase 1: Semantic Intent Parsing (Structured Intent & Domain Model) ---
    is_explicit_kill = bool(re.search(r'\b(?:kill|terminate|force\s+close|process\s+kill|kill\s+process)\b', normalized_input.lower()))
    if plan is None and not is_explicit_kill:
        semantic_intent = parse_semantic_intent(normalized_input)
    if semantic_intent and plan is None:
        if semantic_intent.domain == SemanticDomain.CONVERSATION:
            # Check if deterministic classifier has an actionable tool plan (e.g. 'clipboard mein kya hai?')
            det_plan = _classify_and_parse_command(normalized_input, session_context)
            if det_plan and det_plan.steps and not det_plan.is_direct_message:
                plan = det_plan

        if plan is None:
            active_domain = semantic_intent.domain
            active_action = semantic_intent.action
            active_target = semantic_intent.target
            agent_state.current_domain = active_domain
            # Bullet #6 Failure Isolation: do NOT pre-emptively bind current_target before execution
            if semantic_intent.entities.get("query"):
                agent_state.current_search = {"query": semantic_intent.entities["query"], "domain": active_domain}
            plan = create_plan_from_intent(semantic_intent)

    # --- Phase 2: Situational Investigation ---
    if plan is None and is_situational:
        from brain.planner import create_investigation_plan
        plan = create_investigation_plan(normalized_input)
        active_domain = SemanticDomain.DIAGNOSTICS
        active_action = SemanticAction.INSPECT
        active_target = plan.explanation

    # --- Phase 3: Compound Request Decomposition ---
    if plan is None:
        plan = decompose_compound_command(normalized_input)

    # --- Phase 4: Context and Reference Resolution + Deterministic Classification ---
    if plan is None:
        resolved_text, is_ambiguous, ambiguity_msg = resolve_references(normalized_input, session_context)
        if is_ambiguous and ambiguity_msg:
            return f"Clarification needed: {ambiguity_msg}"

        plan = _classify_and_parse_command(resolved_text, session_context)

    # --- Phase 4.45: Conversational Intent Bypass (Non-OS Queries) ---
    if plan is None:
        from command_layer.semantic_parser import detect_conversational_intent
        is_conv, conv_cat, conv_lang = detect_conversational_intent(normalized_input)
        if is_conv:
            msg = get_conversational_response(normalized_input, conv_cat, conv_lang, session_context)
            trace_id = agent_state.start_trace(raw_input, normalized_input)
            agent_state.record_execution(
                trace_id=trace_id,
                user_cmd=raw_input,
                norm_cmd=normalized_input,
                domain=SemanticDomain.CONVERSATION,
                action=SemanticAction.ANSWER if conv_cat == "general_qa" else SemanticAction.CONVERSE,
                tools=["CONVERSATIONAL_RESPONSE"],
                args=[{"category": conv_cat, "text": normalized_input}],
                success=True,
                verified=True,
                status="completed"
            )
            return msg

    # --- Phase 4.5: Vague/Underspecified Command Confidence Gating (Bullet #20) ---
    if plan is None:
        # Conversational / text query check — prevent tool hallucinations and false confidence gating for non-action queries
        import brain.llm
        if brain.llm._is_conversational_prompt(normalized_input):
            decision = brain.llm.ask_llm(normalized_input, [])
            text_reply = decision.get("text", "")
            if text_reply:
                trace_id = agent_state.start_trace(raw_input, normalized_input)
                agent_state.record_execution(
                    trace_id=trace_id,
                    user_cmd=raw_input,
                    norm_cmd=normalized_input,
                    domain=SemanticDomain.CONVERSATION,
                    action=SemanticAction.ANSWER,
                    tools=["CONVERSATIONAL_RESPONSE"],
                    args=[{"category": "general_qa", "text": normalized_input}],
                    success=True,
                    verified=True,
                    status="completed"
                )
                return text_reply

        # Only gate truly vague commands — commands with recognizable action verbs should
        # fall through to LLM for a chance at proper classification
        _action_verbs = {
            "open", "close", "launch", "kill", "delete", "check", "find", "search",
            "kholo", "band", "hatao", "dikhao", "show", "batao", "start", "stop",
            "create", "move", "copy", "rename", "download", "install", "run",
            "type", "click", "press", "write", "read", "play", "pause",
            "minimize", "maximize", "restore", "switch", "focus", "terminate",
        }
        has_action_verb = any(v in normalized_input.lower().split() for v in _action_verbs)

        if not has_action_verb:
            vague_conf = compute_command_confidence(
                user_cmd=normalized_input,
                domain=active_domain,
                action=active_action,
                target=active_target,
                tool_name="none",
                args={},
                context=session_context
            )
            session_context.record_confidence_score(vague_conf)
            if vague_conf.tier == ConfidenceTier.LOW:
                trace_id = agent_state.start_trace(raw_input, normalized_input)
                agent_state.record_execution(
                    trace_id=trace_id,
                    user_cmd=raw_input,
                    norm_cmd=normalized_input,
                    domain=active_domain,
                    action=active_action,
                    tools=["none"],
                    args=[{}],
                    success=False,
                    verified=False,
                    status="gated_low_confidence",
                    failure_reason=f"Low confidence ({vague_conf.overall_score:.2f}): {vague_conf.reasoning}"
                )
                return "I could not clearly understand your command. Please specify: 1) What application or window, 2) What exact action to take."

    # --- Phase 4.9: COMPOUND PIPELINE HARD INTERCEPT (Anti-LLM-Hallucination Guard) ---
    # CRITICAL: If the command is compound (has conjunctions + lifecycle verbs OR is_compound_syntax),
    # NEVER let the LLM (Ollama/qwen2.5) handle it. The small model generates wrong plans like
    # [type_text, ctrl+s] for multi-step pipelines. Force orchestrate_compound_workflow instead.
    if plan is None:
        _COMPOUND_CONJS_P5 = re.findall(r'\b(?:phir|aur|and|then|after\s+that|pehle|uske\s+baad|iske\s+baad)\b', normalized_input.lower())
        _LIFECYCLE_VERBS_P5 = {"launch", "open", "close", "read", "save", "scan", "kholo", "band", "padhao", "type", "likho"}
        _has_any_conj_p5 = len(_COMPOUND_CONJS_P5) >= 1
        _has_lifecycle_p5 = any(v in normalized_input.lower().split() for v in _LIFECYCLE_VERBS_P5) or bool(re.search(r'\b(?:launch|open|close|read|save|scan|type|likho)\b', normalized_input.lower()))
        _force_orchestrate = (
            is_compound_syntax  # already-detected compound syntax (commas, semicolons, conjunctions)
            or (_has_any_conj_p5 and _has_lifecycle_p5)  # 1+ conjunction + lifecycle verb
            or len(_COMPOUND_CONJS_P5) >= 2  # 2+ conjunctions alone
        )
        if _force_orchestrate:
            from brain.workflow_orchestrator import orchestrate_compound_workflow
            _orch_p5 = orchestrate_compound_workflow(normalized_input, session_context)
            if _orch_p5 is not None and _orch_p5.steps and not getattr(_orch_p5, "is_direct_message", False):
                plan = _orch_p5
                active_domain = SemanticDomain.UNKNOWN
                active_action = SemanticAction.OPEN
                active_target = "compound_workflow"

    # --- Phase 5: LLM Fallback (Only if command cannot be deterministically classified) ---
    if plan is None:
        import brain.llm
        # Conversational / text query check — prevent tool hallucinations for non-action queries
        if brain.llm._is_conversational_prompt(normalized_input):
            decision = brain.llm.ask_llm(normalized_input, [])
            return decision.get("text", "")

        tool_schemas = get_all_schemas()
        decision = brain.llm.ask_llm(normalized_input, tool_schemas)
        if decision.get("success") is False:
            return None
        plan = create_plan_from_decision(decision)


    # Hardened browser context isolation
    plan = _isolate_browser_context(plan, raw_input)

    trace_id = agent_state.start_trace(raw_input, normalized_input)
    if active_domain != SemanticDomain.UNKNOWN:
        session_context.decay_stale_domain(active_domain.value if hasattr(active_domain, "value") else str(active_domain))

    if plan.is_direct_message:
        agent_state.record_execution(
            trace_id=trace_id,
            user_cmd=raw_input,
            norm_cmd=normalized_input,
            domain=active_domain,
            action=active_action,
            tools=["DIRECT_MESSAGE"],
            args=[{"message": plan.message_text}],
            success=True,
            verified=True,
            status="completed"
        )

    if plan.is_empty():
        agent_state.record_execution(
            trace_id=trace_id,
            user_cmd=raw_input,
            norm_cmd=normalized_input,
            domain=active_domain,
            action=active_action,
            tools=[],
            args=[],
            success=False,
            verified=False,
            status="no_executable_actions",
            failure_reason="No executable actions found for this command."
        )
        return "I could not clearly understand your command. Please specify: 1) What application or window, 2) What exact action to take."

    # Gate 1: Strict Inquiry vs Physical Action Isolation Guard
    PHYSICAL_INTERACTION_TOOLS = {
        "type_text", "send_keyboard_input", "mouse_click", "click_mouse",
        "click_element_by_text", "move_mouse", "mouse_move"
    }
    is_user_inquiry = (
        any(normalized_input.lower().startswith(kw) for kw in ["tell", "how many", "what is", "what are", "list", "show", "give me", "which", "compare", "comparison", "kya", "batao", "kitne", "kitni"])
        or any(re.search(rf'\b{re.escape(kw)}\b', normalized_input.lower()) for kw in ["tell me", "how many", "what is", "what are", "give me", "kya hai", "batao", "kitne", "kitni", "compare", "comparison"])
    )
    if is_user_inquiry and plan and plan.steps:
        has_physical = any(s.tool in PHYSICAL_INTERACTION_TOOLS for s in plan.steps)
        if has_physical:
            if any(w in normalized_input.lower() for w in ["game", "games", "app", "apps"]):
                plan = Plan(
                    steps=[PlanStep(step=1, tool="get_installed_apps", args={"query": "categorized_games"})],
                    explanation="Inspecting installed games."
                )
            elif any(w in normalized_input.lower() for w in ["cpu", "ram", "memory", "health", "system", "performance"]):
                plan = Plan(
                    steps=[PlanStep(step=1, tool="get_system_health_snapshot", args={})],
                    explanation="Inspecting system health."
                )
            else:
                plan = Plan(
                    is_direct_message=True,
                    message_text="Information inquiry processed. Physical UI interaction was prevented."
                )

    plan = inject_plan_prerequisites(plan, session_context)
    plan = prune_plan_steps(plan, session_context)
    # Bullet #29: Reflective Failure Avoidance & Negative Knowledge Pruning
    plan = apply_reflective_history_pruning(plan, session_context)

    # Universal Task Execution & Visual Audit Proof Engine:
    # When any command requests an action plus proof, automatically append record_task_evidence_and_report
    proof_triggers = [
        "report aur screenshot", "screenshot aur report", "generate report with proof",
        "report with proof", "proof and report", "proof aur report", "audit report and proof",
        "last par report", "last pe report", "last mein report", "screenshot and report",
        "report and screenshot", "with proof", "task evidence"
    ]
    norm_low = normalized_input.lower()
    if any(t in norm_low for t in proof_triggers) and plan and plan.steps:
        if not any(s.tool == "record_task_evidence_and_report" for s in plan.steps):
            clean_task = re.sub(
                r'\b(?:(?:last\s+(?:par|pe|mein)\s+)?(?:report\s+(?:aur|and)\s+screenshot|screenshot\s+(?:aur|and)\s+report|generate\s+report\s+with\s+proof|report\s+with\s+proof|proof\s+(?:aur|and)\s+report|audit\s+report\s+and\s+proof|banao|generate|create|karo|aur|and|with\s+proof))\b.*$',
                '',
                normalized_input,
                flags=re.IGNORECASE
            ).strip(' ,.-')
            task_title = clean_task or "task_execution"
            evidence_step = PlanStep(
                step=len(plan.steps) + 1,
                tool="record_task_evidence_and_report",
                args={
                    "task_title": task_title,
                    "report_filepath": r"C:\reports\audit_summary.txt",
                    "take_screenshot": True
                }
            )
            plan.steps.append(evidence_step)

    # Bullet #26 Multi-Step Task Management: Milestone Initialization & Task Tracking
    import time as _time
    if len(plan.steps) > 1 and not getattr(plan, "milestones", None):
        plan.milestones = decompose_into_milestones(plan)
        session_context.record_active_milestones(plan.milestones)
        task_id = f"task_{int(_time.time())}"
        agent_state.transition_task_state(TaskLifecycleState.IN_PROGRESS, task_id=task_id)
        init_cp = TaskCheckpoint(
            task_id=task_id,
            task_goal=raw_input,
            lifecycle_state=TaskLifecycleState.IN_PROGRESS,
            current_milestone_idx=0,
            completed_step_ids=[],
            pending_plan=plan,
            saved_context_slots=dict(session_context.step_output_cache),
            progress_percent=0.0,
        )
        session_context.save_task_checkpoint(init_cp)
    elif getattr(plan, "milestones", None) and not session_context.active_milestones:
        session_context.record_active_milestones(plan.milestones)

    return plan, None
