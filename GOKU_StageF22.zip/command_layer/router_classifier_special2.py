from __future__ import annotations
import os
from pathlib import Path
import re
import sys
import time
from typing import Any, Optional, Union, List, Dict, Tuple
from dataclasses import dataclass, field

from brain.planner import (
    Plan,
    PlanStep,
    StructuredIntent,
    create_plan_from_decision,
    decompose_compound_command,
    parse_compound_request,
    resolve_step_variables,
    resolve_step_variables_with_guard,
    inject_plan_prerequisites,
    prune_plan_steps,
    build_hypothesis_investigation_plan,
    build_root_cause_investigation_plan,
    parse_conditional_goal,
    synthesize_adaptive_replan,
    decompose_into_milestones,
    restore_plan_from_checkpoint,
    build_cross_domain_plan,
    apply_cross_domain_transformation,
    build_long_horizon_exploration_plan,
    decompose_long_horizon_goal,
    compute_state_hash,
    detect_state_cycle,
    heuristic_node_score,
    expand_exploration_frontier,
    select_next_frontier_node,
    apply_reflective_history_pruning,
)
from command_layer.cognitive_reasoner import CognitiveReasoner
from command_layer.context import (
    EntityType,
    TypedEntity,
    ORDINAL_REFERENCES,
    SessionContext,
    resolve_references,
    session_context,
    update_context_from_result,
)
from command_layer.semantic_model import (
    SemanticDomain,
    SemanticAction,
    CommandIntent,
    AmbiguityType,
    ClarificationRequest,
    SymptomCategory,
    SituationType,
    ConfidenceTier,
    RiskTier,
    ConfidenceScore,
    ConfirmationRequest,
    FailureType,
    AdaptiveStrategy,
    PlanAdaptation,
    TaskLifecycleState,
    TaskMilestone,
    TaskCheckpoint,
    DomainBridgeType,
    DomainBridgeLink,
    CrossDomainWorkflow,
    HorizonDepth,
    ExplorationNode,
    SearchFrontier,
    LongHorizonReport,
    HistoryQueryType,
    ExecutionTraceRecord,
    TraceSummary,
)
from command_layer.semantic_parser import (
    parse_semantic_intent,
    create_plan_from_intent,
    resolve_in_turn_correction,
    strip_conversational_noise,
    split_compound_clauses,
    detect_symptom_category,
)
from command_layer.firewall import validate_tool_against_firewall, pre_execution_semantic_check, validate_long_horizon_action
from command_layer.state_machine import agent_state
from command_layer.validator import validate_and_sanitize_tool_arguments
from command_layer.lexer import UniversalLexer
from brain.runtime_bus import RuntimePipingBus
from security.state import confirmation_manager
from tools.utils.app_resolver import (
    APP_ALIASES,
    get_canonical_app_name,
    resolve_app,
)
from tools.utils.target_resolver import TargetType, resolve_universal_target, disambiguate_multi_candidates
from command_layer.router_base import (
    Step,
    run_tool_call,
    resolve_system_canonical_path,
    verify_post_recovery,
    verify_semantic_outcome,
    capture_environment_snapshot,
    capture_step_observation,
    detect_environment_drift,
    _entity_val,
    get_all_schemas,
    KNOWN_SITE_KEYS,
    KNOWN_APP_NAMES,
    _has_file_extension,
    _normalize_resolved_path,
    _is_conversational_folder_path,
)
from security.safety_firewall import is_safe_readonly_operation
from security.confirm import RISKY_TOOLS
from command_layer.decomposer import count_action_verbs
from brain.workflow_orchestrator import orchestrate_compound_workflow
from tools.browser import sanitize_search_query
from tools.search import parse_search_grammar
import executor.verifier
import executor.executor

from command_layer.router_sanitizer import (
    _isolate_browser_context,
    prune_negated_steps,
    sanitize_action_query,
    sanitize_url,
    _canonicalize_plan_tools,
    sanitize_ui_target,
    extract_clean_search_query,
)
from command_layer.router_cli_parser import (
    translate_cli_command,
    sanitize_cli_command,
    extract_pure_text_payload,
    parse_sequential_keyboard_actions,
    is_standalone_navigation_request,
    resolve_temporal_order,
    strip_idiomatic_conditions,
)
from command_layer.router_confidence import (
    determine_risk_tier,
    format_uncertainty_response,
    compute_command_confidence,
    synthesize_cross_domain_report,
    synthesize_long_horizon_report,
    get_conversational_response,
)

def _classify_and_parse_command(text: str, context: SessionContext | None = None, is_compound_root: bool = True) -> Plan | None:
    from command_layer.router_classifier_core import _classify_and_parse_command as _real_fn
    return _real_fn(text, context, is_compound_root)

def classify_special_intents_2(text: str, context: SessionContext | None = None, is_compound_root: bool = True) -> Plan | None:
    from command_layer.decomposer import count_action_verbs
    from brain.workflow_orchestrator import orchestrate_compound_workflow
    from tools.browser import sanitize_search_query
    from tools.search import parse_search_grammar
    from security.safety_firewall import is_safe_readonly_operation
    from security.confirm import RISKY_TOOLS
    cleaned = re.sub(r'[\x00-\x1f\x7f]+$', '', text).strip()
    cleaned = re.sub(r'[\x13\x03\x1b]', '', cleaned).strip()
    raw_lower = cleaned.lower()
    lower = text.lower()
    folder_ref_m = re.search(r"folder\s+'([^']+)'", text)
    file_ref_m = re.search(r"file\s+'([^']+)'", text)
    text_unwrapped = re.sub(r'[\'"]([^\'"]+)[\'"]', r'\1', text)
    try:
        symptom_cat, situation_type, symptom_entities = detect_symptom_category(raw_lower)
    except Exception:
        symptom_cat, situation_type, symptom_entities = SymptomCategory.NONE, SituationType.NORMAL, []
    _p2_is_compound_guard = False
    # 0.0235 Basic Conditional Sequence Flattening:
    # E.g. "agar notepad nahi chal raha to calc kholo, 500 type karo" (optional warna <alt>)
    _cond_check_m = re.search(
        r'\b(?:agar|if)\s+(.+?)\s+(?:to|phir|then)\s+(.+)',
        cleaned,
        re.IGNORECASE
    )
    if _cond_check_m:
        _c_pred = _cond_check_m.group(1).strip().lower()
        _c_rest = _cond_check_m.group(2).strip()
        if re.search(r'\b(?:nahi\s+chal|nahi\s+khula|band\s+hai|closed|not\s+running|not\s+open)\b', _c_pred):
            _warna_split = re.split(r'\b(?:warna|else|otherwise|agar\s+nahi\s+to)\b', _c_rest, flags=re.IGNORECASE)
            _active_branch = _warna_split[0].strip(" ,;.-")
            if len(_warna_split) > 1:
                _after_warna = _warna_split[1].strip()
                _trailing_m = re.search(r',\s*(?:phir\s+)?(.+)$', _after_warna)
                if _trailing_m and any(w in _trailing_m.group(1).lower() for w in ["type", "likho", "click", "press", "save"]):
                    _active_branch = f"{_active_branch}, {_trailing_m.group(1).strip()}"

            from brain.workflow_orchestrator import orchestrate_compound_workflow
            _cond_plan = orchestrate_compound_workflow(_active_branch, context)
            if _cond_plan is not None and _cond_plan.steps:
                return _isolate_browser_context(_canonicalize_plan_tools(_cond_plan), text)

    # 0.024 Pre-noise-strip click-element guard:
    # UI element names like 'OK', 'Cancel', 'Apply', 'Yes', 'No' may be wrongly stripped
    # as conversational noise. Intercept click-element patterns before noise stripping.
    _pre_strip_click = re.match(
        r'^(?:please\s+)?(?:mouse\s+)?click\s+(?:(?:on|the)\s+)?element\s+[\'"]?(?P<target>[a-zA-Z0-9_\-][a-zA-Z0-9_\-\s]{0,60}?)[\'"]?$',
        cleaned, re.IGNORECASE
    )
    if _pre_strip_click:
        _pre_target = _pre_strip_click.group("target").strip()
        if _pre_target:
            return Plan(
                steps=[PlanStep(step=1, tool="click_element_by_text", args={"target_text": _pre_target})],
                explanation=f"Clicking on-screen element '{_pre_target}' via UIA/OCR grounding."
            )

    # 0.025 Conversational Noise & Monologue Stripping (Bullet #10)
    denoised_text, stripped_noise = strip_conversational_noise(cleaned)
    if stripped_noise and denoised_text:
        cleaned = denoised_text
        raw_lower = cleaned.lower()

    # 0.026 Conversational, Greeting & Feedback Bypass
    from command_layer.semantic_parser import detect_conversational_intent
    is_conv, conv_cat, conv_lang = detect_conversational_intent(cleaned)
    if is_conv and conv_cat in ("greeting", "capability", "feedback"):
        msg = get_conversational_response(cleaned, conv_cat, conv_lang, context)
        return Plan(is_direct_message=True, message_text=msg)

    # 0.03 Multi-Turn Pending Clarification Resolution (Bullet #9)
    if context.pending_clarification and context.disambiguation_candidates:
        resolved_cand = context.resolve_clarification_answer(cleaned)
        if resolved_cand:
            selected, req = resolved_cand
            orig_tool = req.original_tool or "open_file"
            orig_args = dict(req.original_args)
            if "path" in orig_args:
                orig_args["path"] = selected
            elif "name" in orig_args:
                orig_args["name"] = selected
            elif orig_tool == "read_file_text":
                orig_tool = "read_file"
                orig_args["path"] = selected
            elif orig_tool in ("open_file", "delete_file", "read_file", "open_folder", "list_folder"):
                orig_args["path"] = selected
            elif orig_tool in ("launch_app", "close_app", "kill_process", "find_application"):
                orig_args["name"] = selected
            else:
                orig_args["path"] = selected

            context.clear_pending_clarification()
            return Plan(
                steps=[PlanStep(step=1, tool=orig_tool, args=orig_args)],
                explanation=f"Resolved clarification to '{selected}' and executed {orig_tool}."
            )

    # 0.05 Symptom & Situation Recognition (Bullet #11)
    symptom_cat, situation_type, symptom_entities = detect_symptom_category(cleaned)

    # 0.046 Conversational Web Search / Type & Search Pattern
    # Matches: "Google search mein type karo \"<query>\" aur search kardo", "search mein type karo <query> aur search kardo"
    if ("search" in raw_lower or "google" in raw_lower or "edge" in raw_lower or "browser" in raw_lower or "bing" in raw_lower) and any(w in raw_lower for w in ["mein type karo", "type karo", "likho", "search mein", "search bar mein"]) and any(w in raw_lower for w in ["search kardo", "search karo", "kardo", "kar do", "search", "enter"]):
        b_target = "edge" if any(b in raw_lower for b in ["edge", "msedge"]) else "chrome"
        q_m = re.search(r'[\'"]([^\'"]+)[\'"]', text)
        if q_m:
            clean_q = q_m.group(1).strip()
        else:
            clean_q = sanitize_action_query(text)
        clean_q = sanitize_action_query(clean_q)
        if clean_q:
            return Plan(
                steps=[PlanStep(step=1, tool="search_web", args={"query": clean_q, "browser": b_target})],
                explanation=f"Searching for '{clean_q}' using {b_target.title()}."
            )

    # 0.047 Multi-Step Browser Tab Navigation Pipeline
    # Matches: "browser mein <site1> kholo, ek naya tab bana kar wahan <site2> kholo", "chrome mein <site1> kholo, naya tab bana kar wahan <site2> kholo"
    if ("tab" in raw_lower or "naya tab" in raw_lower or "new tab" in raw_lower) and any(w in raw_lower for w in ["kholo", "open", "launch", "chalao"]) and any(sep in raw_lower for sep in [",", "aur", "and", "phir"]):
        m_tab_pipeline = re.search(
            r'(?:browser|chrome|edge|firefox|brave)?\s*(?:mein\s+)?([a-zA-Z0-9_\-\.]+)\s+(?:kholo|open|launch|chalao)\s*(?:,|aur|and|phir|\sthen\s)\s*(?:ek\s+)?(?:naya\s+tab\s+bana\s+kar|new\s+tab\s+bana\s+kar|naya\s+tab\s+khol\s+kar|new\s+tab\s+mein|naya\s+tab\s+mein|naya\s+tab|new\s+tab)\s*(?:banao\s*[,;]?\s*)?(?:wahan\s+)?([a-zA-Z0-9_\-\.]+)\s+(?:kholo|open|launch|chalao)',
            raw_lower
        )
        if m_tab_pipeline:
            b_target = "edge" if any(b in raw_lower for b in ["edge", "msedge"]) else "chrome"
            site1 = m_tab_pipeline.group(1).strip()
            site2 = m_tab_pipeline.group(2).strip()
            return Plan(
                steps=[
                    PlanStep(step=1, tool="open_url", args={"url": site1, "browser": b_target}),
                    PlanStep(step=2, tool="new_tab", args={"browser": b_target}),
                    PlanStep(step=3, tool="open_url", args={"url": site2, "browser": b_target}),
                ],
                explanation=f"Opened '{site1}' in {b_target.title()}, opened a new tab, and opened '{site2}'."
            )

    # 0.0475 Browser Launch + Site Open Flow
    # Matches: "browser mein fast.com kholo", "chrome mein fast.com kholo", "open fast.com in browser"
    if not (is_compound_root and any(sep in raw_lower for sep in [",", " aur ", " and ", " phir ", " then ", " karke ", " ke baad "])) and (
        ("browser" in raw_lower or "chrome" in raw_lower or "edge" in raw_lower or "firefox" in raw_lower or "brave" in raw_lower)
        and any(w in raw_lower for w in ["kholo", "open", "launch", "chalao"])
        and not any(w in raw_lower for w in ["tab", "search", "dhundo", "type", "likh", "folder", "directory"])
    ):
        b_target = "edge" if any(b in raw_lower for b in ["edge", "msedge"]) else "chrome"
        m_b_url = re.search(
            r'(?:browser|chrome|edge|firefox|brave)?\s*(?:mein|me|in)?\s*([a-zA-Z0-9_\-\./:]+\.[a-zA-Z]{2,10}(?:/[^\s]*)?)\s*(?:mein|me|in)?\s*(?:kholo|open\s*kar[a-z]*|chalao|launch|start|khol\s*do|khol\s*de)?',
            raw_lower
        )
        site_cand = None
        if m_b_url:
            site_cand = m_b_url.group(1).strip()
        else:
            _scan = re.sub(r'\bgoogle\s+chrome\b', 'chrome', raw_lower)     # "Google Chrome" is the app's name, not a request for google.com
            for sk in KNOWN_SITE_KEYS:
                if re.search(rf'\b{sk}\b', _scan):
                    site_cand = sk
                    break
        if site_cand:
            clean_u = sanitize_url(site_cand)
            if clean_u:
                if context:
                    context.last_target_app = b_target
                return Plan(
                    steps=[
                        PlanStep(step=1, tool="launch_app", args={"name": b_target}),
                        PlanStep(step=2, tool="open_url", args={"url": clean_u, "browser": b_target}),
                    ],
                    explanation=f"Launched {b_target.title()} and opened '{clean_u}'."
                )

    # 0.048 YouTube Search & Play Flow
    # Matches: "<browser> kholo, youtube.com par jao, search bar mein <text> likho aur pehli video par click karo"
    if "youtube" in raw_lower and any(w in raw_lower for w in ["search", "likho", "type"]) and any(w in raw_lower for w in ["pehli video", "first video", "video", "play", "chalao"]):
        browser = "chrome"
        for b_cand in ["chrome", "edge", "firefox", "brave"]:
            if b_cand in raw_lower:
                browser = b_cand
                break

        txt_m = re.search(r'\b(?:search\s+bar\s+mein|search\s+box\s+mein|mein|me)\s+([a-zA-Z0-9_\-\s]+?)(?:\s+likho|\s+type|\s+search|\s+enter|$)', text, re.IGNORECASE)
        txt = txt_m.group(1).strip() if txt_m else None
        if not txt:
            txt_m2 = re.search(r'[\'"]([^\'"]+)[\'"]', text)
            txt = txt_m2.group(1).strip() if txt_m2 else "Coke Studio"
        txt = re.sub(r'\b(likho|type|search|karo|kar\s+do|please|aur|pehli|video)\b', '', txt, flags=re.IGNORECASE).strip() or "Coke Studio"

        return Plan(
            steps=[
                PlanStep(step=1, tool="open_url", args={"url": "https://www.youtube.com", "browser": browser}),
                PlanStep(step=2, tool="wait_for_ui_settle", args={"timeout_ms": 1500}),
                PlanStep(step=3, tool="find_and_interact", args={"target_query": "Search", "query": "Search", "action": "type", "input_text": txt, "post_key": "enter"}),
                PlanStep(step=4, tool="wait_for_ui_settle", args={"timeout_ms": 2000}),
                PlanStep(step=5, tool="find_and_interact", args={"target_query": "video_result_1", "query": "video_result_1", "action": "click", "rank": 1}),
            ],
            explanation=f"Opened YouTube, searched for '{txt}', and clicked the first video."
        )

    # 0.049 File Explorer Folder Navigation
    # Matches: "file explorer kholo, <folder> mein jao", "file explorer kholo aur <folder> mein jao", "explorer kholo, <folder> mein jao"
    if ("file explorer" in raw_lower or "explorer" in raw_lower) and any(w in raw_lower for w in ["mein jao", "me jao", "folder", "open karo", "kholo", "jao"]):
        folder_m = re.search(r'\b(?:explorer\s+(?:kholo|open\s+karo|chalao)?\s*(?:,|aur|and|phir)?\s*)?([a-zA-Z0-9_\-\s\\/:]+?)\s+(?:mein\s+jao|me\s+jao|folder\s+kholo|folder)\b', text, re.IGNORECASE)
        folder_target = folder_m.group(1).strip() if folder_m else None
        if not folder_target:
            folder_m2 = re.search(r'\b(?:mein\s+jao|me\s+jao|jao)\b', raw_lower)
            if folder_m2:
                folder_target = re.sub(r'\b(file\s+explorer|explorer|kholo|open|aur|and|phir|mein\s+jao|me\s+jao|jao|,)\b', '', text, flags=re.IGNORECASE).strip()
        folder_clean = folder_target.strip(" '\",") if folder_target else "Downloads"
        known_dirs = {"downloads": "Downloads", "desktop": "Desktop", "documents": "Documents", "pictures": "Pictures", "music": "Music", "videos": "Videos"}
        norm_path = known_dirs.get(folder_clean.lower(), folder_clean)
        steps = [PlanStep(step=1, tool="open_folder", args={"path": norm_path})]

        if any(w in raw_lower for w in ["naya folder", "new folder", "folder banao", "folder create", "make folder", "mkdir"]):
            nf_m = re.search(r'[\'"]([^\'"]+)[\'"]', text)
            nf_name = nf_m.group(1) if nf_m else None
            if not nf_name:
                nf_m2 = re.search(r'(?:naya\s+folder\s+banao|folder\s+banao|create\s+folder|new\s+folder)\s+([a-zA-Z0-9_\-]+)', text, re.IGNORECASE)
                nf_name = nf_m2.group(1) if nf_m2 else "New Folder"
            target_new_path = os.path.join(norm_path, nf_name)
            steps.append(PlanStep(step=2, tool="create_folder", args={"path": target_new_path}))
            return Plan(steps=steps, explanation=f"Opened '{norm_path}' in File Explorer and created '{nf_name}'.")

        return Plan(
            steps=steps,
            explanation=f"Navigated to '{norm_path}' in File Explorer."
        )

    # 0.052 Compound App/URL Launch + UI Action Workflow
    # Matches:
    #   "<app/site> (open|kholo|launch) (karo|ker) aur <target> (par|pe)? (click karo|select karo)"
    #   "taskmgr launch karo aur processes tab par click karo"
    #   "tiktok open karo aur continue with google par click karo"
    #   "calc launch karo, 7 par click karo, multiply par click karo"
    m_compound_app_click = re.match(
        r'^(?:please\s+)?(?P<app>[a-zA-Z0-9_\.\-]+)\s+(?P<verb>open|kholo|launch|start|chalao)\s*(?:karo|kar|ker|do)?\s*(?:,|aur|and|phir|\sthen\s)\s+(?P<rest>.+)$',
        cleaned,
        re.IGNORECASE
    )
    if m_compound_app_click:
        raw_app = m_compound_app_click.group("app").strip()
        rest_clause = m_compound_app_click.group("rest").strip()
        if any(w in rest_clause.lower() for w in ["click", "select", "dabao", "press", "type", "likho"]):
            is_site = (
                raw_app.lower() in KNOWN_SITE_KEYS
                or any(raw_app.lower().startswith(p) for p in ["http://", "https://", "www."])
                or any(raw_app.lower().endswith(s) for s in [".com", ".org", ".net", ".io", ".pk", ".co"])
            )
            c_steps = []
            if is_site:
                c_steps.append(PlanStep(step=1, tool="open_url", args={"url": raw_app, "browser": "chrome"}))
                c_steps.append(PlanStep(step=2, tool="wait_for_ui_settle", args={"timeout_ms": 1000}))
            else:
                app_cand = get_canonical_app_name(raw_app) or raw_app
                c_steps.append(PlanStep(step=1, tool="launch_app", args={"name": app_cand}))

            sub_actions = [a.strip() for a in re.split(r'\s*(?:,|aur|and|phir|\sthen\s)\s*', rest_clause) if a.strip()]
            for act in sub_actions:
                act_lower = act.lower()
                if any(w in act_lower for w in ["click", "select", "dabao", "press"]):
                    t = re.sub(r'^(?:aur|and|phir|then|pehle|please)\s+', '', act, flags=re.IGNORECASE)
                    t = re.sub(r'\s*(?:par|pe)?\s*(?:click\s+karo|click\s+kar\s+do|click|select\s+karo|select|dabao|press)\.?$', '', t, flags=re.IGNORECASE).strip()
                    t = re.sub(r'\s+(?:par|pe)$', '', t, flags=re.IGNORECASE).strip()
                    # Strip suffixes like tab, button, btn, option, menu
                    t = re.sub(r'\s*\b(tab|button|btn|option|menu)\b\s*$', '', t, flags=re.IGNORECASE).strip()
                    t = t.strip("'\"")
                    if t:
                        c_steps.append(PlanStep(
                            step=len(c_steps) + 1,
                            tool="find_and_interact",
                            args={"target_query": t.capitalize() if len(t) > 2 else t, "query": t.capitalize() if len(t) > 2 else t, "action": "click"}
                        ))
                elif any(w in act_lower for w in ["type", "likho", "write", "enter"]):
                    txt_m = re.search(r"['\"]([^'\"]+)['\"]", act)
                    input_txt = txt_m.group(1) if txt_m else "text"
                    t_field = re.sub(r'\b(mein|me|likho|type|enter|karo|please)\b', '', act, flags=re.IGNORECASE).strip().strip("'\"") or "input"
                    c_steps.append(PlanStep(
                        step=len(c_steps) + 1,
                        tool="find_and_interact",
                        args={"target_query": t_field, "query": t_field, "action": "type", "input_text": input_txt}
                    ))

            if len(c_steps) >= 2:
                return Plan(
                    steps=c_steps,
                    explanation=f"Compound workflow: launched {raw_app} and interacted with target UI elements."
                )

    # Phase 0.53: Cross-Domain Compound Intent Interception (Bullet #27)
    if is_compound_root:
        is_compound_syntax = bool(re.search(
            r'[,;]|\b(?:aur|and|phir|then|after that|uske baad|iske baad)\b|\n',
            raw_lower
        ))
        skip_cross_domain = False
        if is_compound_syntax:
            from command_layer.decomposer import decompose_compound_command as decomp_intents
            sub_intents = decomp_intents(cleaned)
            if len(sub_intents) >= 2:
                is_canonical_cross = bool(
                    (any(w in raw_lower for w in ["archive", "zip"]) and any(w in raw_lower for w in ["space", "storage"])) or
                    (any(w in raw_lower for w in ["search", "find", "dhoondo", "dhundo"]) and any(w in raw_lower for w in [".pdf", ".html", ".docx", ".txt", "quarterly"]) and any(w in raw_lower for w in ["chrome", "browser"]) and any(w in raw_lower for w in ["screenshot", "snapshot", "tasweer"])) or
                    (any(w in raw_lower for w in ["internet", "wifi"]) and any(w in raw_lower for w in ["settings", "ms-settings"])) or
                    (any(w in raw_lower for w in ["diagnose", "diagnostics"]) and any(w in raw_lower for w in ["heavy process", "top process", "find process", "process dhundo"])) or
                    (any(w in raw_lower for w in ["diagnose", "system health"]) and any(w in raw_lower for w in ["health.html", "system_health_report"]) and any(w in raw_lower for w in ["chrome", "browser"]))
                )
                if not is_canonical_cross:
                    skip_cross_domain = True
                    from brain.workflow_orchestrator import orchestrate_compound_workflow
                    orch_plan = orchestrate_compound_workflow(cleaned, context)
                    if orch_plan is not None and orch_plan.steps and not getattr(orch_plan, "is_direct_message", False):
                        return orch_plan

        if not skip_cross_domain:
            cross_plan = build_cross_domain_plan(cleaned, context)
            if cross_plan:
                return cross_plan

    # Phase 0.55: Bullet #19 Conditional Decision Making
    if re.search(r'\b(?:if|agar|in case|jab|agar kabhi|check if)\b', raw_lower):
        cond_plan = parse_conditional_goal(cleaned)
        if cond_plan:
            return cond_plan

    # Phase 4: Conversational Objection / Negation Interception
    # Prevents conversational corrections like "no thats games..." from leaking into wildcard file searches
    m_negation = re.match(r'^(?:no|nahi|not\s+that|thats\s+not\s+what\s+i\s+meant|that\'s\s+not\s+what\s+i\s+meant)\b[,.\s]*(.*)', cleaned, re.IGNORECASE)
    if m_negation:
        remainder = m_negation.group(1).strip()
        rem_lower = remainder.lower()
        if rem_lower:
            # Check if remainder specifies store games or installed apps
            if ("game" in rem_lower or "games" in rem_lower) and any(w in rem_lower for w in ["store", "downloaded", "installed", "count", "list"]):
                store_q = "uwp_games" if any(w in rem_lower for w in ["store", "microsoft store"]) else "games"
                return Plan(
                    steps=[PlanStep(step=1, tool="get_installed_apps", args={"query": store_q})],
                    explanation=f"Corrected intent: inspecting installed {store_q} without file system search."
                )
            if any(w in rem_lower for w in ["app", "apps", "application"]) and any(w in rem_lower for w in ["installed", "downloaded", "count", "list"]):
                return Plan(
                    steps=[PlanStep(step=1, tool="get_installed_apps", args={"query": ""})],
                    explanation="Corrected intent: inspecting installed applications."
                )
            sub_plan = _classify_and_parse_command(remainder, context, is_compound_root=False)
            if sub_plan:
                return sub_plan

        return Plan(
            is_direct_message=True,
            message_text="Understood, I apologize for the misunderstanding. What specific game, application, or task would you like me to inspect or perform?"
        )

    # --- Phase 4.1: Universal Task Execution & Visual Proof Engine Hooks ---
    m_prep = re.match(r'^(?:prepare\s+(?:target\s+)?environment\s+(?:for\s+)?|prepare\s+app\s+|prepare\s+)([a-zA-Z0-9_\-]+(?:\s+[a-zA-Z0-9_\-]+)?)$', cleaned, re.IGNORECASE)
    if m_prep and not any(w in raw_lower for w in ["report", "screenshot", "proof"]):
        target_app = m_prep.group(1).strip()
        return Plan(
            steps=[PlanStep(step=1, tool="prepare_target_environment", args={"app_name": target_app})],
            explanation=f"Prepare target environment for {target_app}."
        )

    m_clean = re.match(r'^(?:smart\s+cleanup(?:\s+app)?|cleanup\s+app|smart\s+close)\s+([a-zA-Z0-9_\-]+(?:\s+[a-zA-Z0-9_\-]+)?)$', cleaned, re.IGNORECASE)
    if m_clean:
        target_app = m_clean.group(1).strip()
        return Plan(
            steps=[PlanStep(step=1, tool="smart_cleanup_app", args={"app_name": target_app, "force_close": False})],
            explanation=f"Smart cleanup for {target_app} (preserves pre-existing windows)."
        )

    if any(re.search(pat, raw_lower) for pat in [
        r'\b(?:(?:last\s+(?:par|pe|mein)\s+)?(?:report\s+(?:aur|and)\s+screenshot|screenshot\s+(?:aur|and)\s+report|generate\s+report\s+with\s+proof|report\s+with\s+proof|proof\s+(?:aur|and)\s+report|audit\s+report\s+and\s+proof|record\s+task\s+evidence))\b',
        r'\b(?:report\s+aur\s+screenshot\s+banao|screenshot\s+aur\s+report\s+banao|generate\s+audit\s+report)\b',
        r'\b(?:(?:last\s+(?:par|pe|mein)\s+)?(?:audit\s+report|evidence\s+report|proof\s+report)(?:\s+banao|\s+generate|\s+create|\s+karo)?)\b(?!\s*(?:file|files|folder|path|doc|pdf|txt))',
    ]) and not any(w in raw_lower for w in ["read", "open", "view", "cat", "search", "dhoondo", "dhundo", "dhoond", "dhund", "find", "talash", "khojo", "locate", "wifi", "network", "status", "type", "likho", "open_file", "files", "folder", "save", "save as", "save_file", "save_file_dialog"]):

        clean_task = re.sub(
            r'\b(?:(?:last\s+(?:par|pe|mein)\s+)?(?:report\s+(?:aur|and)\s+screenshot|screenshot\s+(?:aur|and)\s+report|generate\s+report\s+with\s+proof|report\s+with\s+proof|proof\s+(?:aur|and)\s+report|audit\s+report\s+and\s+proof|banao|generate|create|karo|aur|and|with\s+proof|report))\b',
            '',
            cleaned,
            flags=re.IGNORECASE
        ).strip(' ,.-')
        title = clean_task or "audit_summary"
        return Plan(
            steps=[
                PlanStep(
                    step=1,
                    tool="record_task_evidence_and_report",
                    args={
                        "task_title": title,
                        "report_filepath": r"C:\reports\audit_summary.txt",
                        "take_screenshot": True
                    }
                )
            ],
            explanation=f"Record task evidence and generate audit proof report for '{title}'."
        )


    return None
