# GOKU: Grounded OS Knowledge Unit

GOKU is an autonomous desktop operator agent designed for Windows, combining deterministic OS execution, physical truth verification, lightweight vision inspection, and small-model (0.5B) language steering.

---

## 1. Quick Start & Installation

### Prerequisites
- Windows 10/11 (64-bit)
- Python 3.10+ (tested on Python 3.12)
- Ollama (optional, required only for Stage C natural language reasoning: `ollama run qwen2.5:0.5b`)

### Install Dependencies
```bash
pip install -r requirements.txt
```

### Run the Agent
```bash
python main.py
```

### Run the Reality & Truth Test Matrix
```bash
python scripts/verify_all.py
```

---

## 2. Core Architecture

1. **Truth Layer (`executor/truth_oracle.py`)**:
   - Independent verification oracle reading physical OS state (`check_file`, `check_process`, `check_window`, `check_foreground`, `check_dialog`, `check_screen_changed`).
   - Replaces synthetic `verified=True` flags with ground-truth evidence.

2. **ONE Eye Vision Engine (`tools/vision/screen_engine.py`)**:
   - Per-monitor DPI V2 aware screen observer with 3-tier fallback (UIA -> Win32 -> on-demand OCR).
   - Window-scoped caching (500ms TTL) and leak-free GDI BitBlt screen capture.

3. **Content Understanding (`tools/documents.py`)**:
   - Streaming, memory-safe parser for DOCX, XLSX, PPTX, PDF, and text formats.
   - Enforces a 20 MB file size cap, TF-IDF extractive summarization under 1,000 tokens, and quote-verification against physical text chunks to prevent hallucination.

4. **Reliable Routing (`brain/llm.py`)**:
   - Word-boundary token matching with bilingual English & Roman Urdu verb lexicons.
   - Confidence scoring: high confidence commands route deterministically, ambiguous commands trigger single-question clarification, and low-confidence inputs defer to chat.

5. **Pacing Engine (`brain/time_sliced_orchestrator.py`)**:
   - Multi-stage execution pipeline:
     - **Stage A (Deterministic)**: 0 LLM inference cost, instant OS action dispatch.
     - **Stage B (Contingency Fallback)**: Triggered only when Stage A encounters obstacles.
     - **Stage C (0.5B Micro-Prompt)**: Bounded to 200 input tokens with structured JSON schema output.

6. **Experience Flywheel (`brain/experience_memory.py`)**:
   - Records telemetry only for physical-oracle-verified executions.
   - Promotes playbooks to Golden Playbook status only after two consecutive successes in separate runs.
   - Maintains failure signatures to automatically avoid repeated failure patterns.

7. **Web UI/UX Analyzer (`tools/web_uiux_analyzer.py`)**:
   - WCAG 2.2 contrast checking (linearized sRGB relative luminance), 24x24 px touch target compliance, layout shift detection, and semantic HTML structure validation via headless Chromium.

8. **0.5B Training Kit (`training/`)**:
   - Includes Ollama Modelfile (`training/Modelfile.goku`), synthetic command dataset generator (`training/make_dataset.py`), evaluation benchmark (`training/eval_router.py`), and Google Colab QLoRA notebook (`training/colab_lora.ipynb`).

---

## 3. Verification & Test Matrix

The test runner `run_truth_tests.py` executes 9 comprehensive suites validating physical OS reality:

```bash
python scripts/verify_all.py
```

| Suite | Focus | Tests Passed | Pass Rate |
| :--- | :--- | :--- | :--- |
| **AST Banned Patterns** | Zero try/except, assert True, missing asserts | 7 / 7 | 100% |
| **Firewall Adversarial Bypass** | 11 attack vectors: unicode, 8.3, traversal, format | 62 / 62 | 100% |
| **Truth Layer** | Real OS state checks, dialogs, processes | 35 / 35 | 100% |
| **Content Understanding** | Multi-format doc parsing, quote verification | 7 / 7 | 100% |
| **Routing & Reliability** | Verb lexicons, word boundaries, confidence | 5 / 5 | 100% |
| **Popup Policy & Safeguards** | Dialog policy, unique path, save protection | 13 / 13 | 100% |
| **Physical Execution Verifier** | Truth verifier, PID checks, process liveness | 9 / 9 | 100% |
| **Windows Live Perception** | Live Notepad UIA, Win32, edit state inspection | 1 / 1 | 100% |
| **Task Acceptance Matrix** | 22 Matrix rows verified with physical evidence | 22 / 22 | 100% |
| **Total** | Full Verified Matrix | **161 / 161** | **100%** |
---

## 4. Hardware Footprint & Resource Telemetry

- **Target Hardware**: Windows 10/11 laptop with 4 GB physical RAM (stay alive in 600 MB free RAM).
- **RAM Budget (`config/budget.py`)**:
  - Agent Tree USS (including child processes): `<= 80 MB` (currently ~22 MB, >55 MB headroom).
  - Perception Working Buffer: `<= 8 MB`.
  - LLM Resident when idle: `0 MB` (`keep_alive = 0`).
  - Model Calls: Single-threaded concurrency lock; refused when available RAM < 500 MB.
- **Process Memory Profile & Reconciliation**:
  - **Base Idle Python (`AUDIT_REPORT.md`)**: ~15.5 - 17.7 MB Working Set (RSS), ~8.3 MB Private (USS).
  - **Full Agent Runtime (`README.md`)**: ~31.0 - 45.5 MB Working Set (RSS) including shared OS DLLs.
  - **Authoritative Private USS**: ~19.9 - 22.4 MB (well within the <= 80 MB budget).
  - During `observe()`: ~24.5 MB USS.
  - During Document Query: ~26.2 MB USS.
  - During Model Inference: ~27.0 MB USS (runner kept at 0 MB idle via `keep_alive=0`).
  - Peak Total Agent USS: < 35.0 MB.

