"""
tests/test_ocr_real_apps_kit.py
Unit tests for Real Applications OCR benchmark kit (tests/ocr_real_apps_test.py).
Fully headless, non-GUI: zero application windows opened, 100% synthetic data.
"""
from __future__ import annotations

import copy
from pathlib import Path
from typing import Any
import pytest
from PIL import Image

from tests.ocr_real_apps_test import (
    compute_capture_blank,
    evaluate_honesty_blank,
    is_point_in_region,
    filter_elements_by_region,
    calculate_word_match,
    calculate_precision_in_region,
    evaluate_real_apps_rules,
    ensure_real_page_assets,
    compute_real_kit_sha256,
)


# ==============================================================================
# 1. DETERMINISTIC ASSET GENERATION
# ==============================================================================

def test_page_html_and_fixture_deterministic(tmp_path: Path):
    """Assets page.html and fixture.png must generate deterministically with matching hashes."""
    dir1 = tmp_path / "run1"
    dir2 = tmp_path / "run2"

    html1, fix1, sha1, words1 = ensure_real_page_assets(dir1)
    html2, fix2, sha2, words2 = ensure_real_page_assets(dir2)

    assert sha1 == sha2
    assert html1.read_bytes() == html2.read_bytes()
    assert fix1.read_bytes() == fix2.read_bytes()
    assert words1 == words2

    content = html1.read_text(encoding="utf-8")
    assert "<title>OCR REAL PAGE</title>" in content
    assert '<canvas id="canvas-section"' in content
    assert '<img id="image-section"' in content
    assert "DOM Heading Standard Browser Text" in content


# ==============================================================================
# 2. CAPTURE BLANK DETECTION ON SYNTHETIC IMAGES
# ==============================================================================

def test_capture_blank_none():
    """None image returns True (capture blank)."""
    assert compute_capture_blank(None) is True


def test_capture_blank_solid_black():
    """Solid black bitmap returns True."""
    img = Image.new("RGB", (200, 150), (0, 0, 0))
    assert compute_capture_blank(img) is True


def test_capture_blank_solid_white():
    """Solid white bitmap returns True."""
    img = Image.new("RGB", (200, 150), (255, 255, 255))
    assert compute_capture_blank(img) is True


def test_capture_blank_uniform_gray():
    """Solid uniform gray bitmap returns True."""
    img = Image.new("RGB", (200, 150), (128, 128, 128))
    assert compute_capture_blank(img) is True


def test_capture_blank_low_stddev_noise():
    """Bitmap with grayscale std-dev < 2.0 returns True."""
    # Create image with pixels alternating between 128 and 129 (stddev ~ 0.5)
    img = Image.new("L", (100, 100), 128)
    for x in range(0, 100, 2):
        for y in range(0, 100, 2):
            img.putpixel((x, y), 129)
    assert compute_capture_blank(img) is True


def test_capture_blank_over_99_5_percent_identical():
    """Bitmap where > 99.5% of pixels are identical returns True."""
    # 10,000 pixels total, 9,970 white, 30 black (99.7% identical)
    img = Image.new("RGB", (100, 100), (255, 255, 255))
    for i in range(30):
        img.putpixel((i, 0), (0, 0, 0))
    assert compute_capture_blank(img) is True


def test_capture_blank_normal_rendered_ui():
    """Rendered UI bitmap with text and buttons returns False."""
    img = Image.new("RGB", (200, 150), (255, 255, 255))
    # Draw significant dark regions and diverse values
    for x in range(20, 180, 2):
        for y in range(30, 80, 2):
            img.putpixel((x, y), (10, 20, 30))
    for x in range(30, 160):
        for y in range(100, 130):
            img.putpixel((x, y), (200, 100, 50))
    assert compute_capture_blank(img) is False


# ==============================================================================
# 3. REGION FILTERING & GEOMETRY
# ==============================================================================

def test_is_point_in_region():
    region = {"left": 50, "top": 100, "right": 250, "bottom": 300}
    # Inside
    assert is_point_in_region({"x": 100, "y": 150}, region) is True
    # Exactly on borders
    assert is_point_in_region({"x": 50, "y": 100}, region) is True
    assert is_point_in_region({"x": 250, "y": 300}, region) is True
    # Outside
    assert is_point_in_region({"x": 49, "y": 150}, region) is False
    assert is_point_in_region({"x": 251, "y": 150}, region) is False
    assert is_point_in_region({"x": 100, "y": 99}, region) is False
    assert is_point_in_region({"x": 100, "y": 301}, region) is False
    # None region allows all points
    assert is_point_in_region({"x": 999, "y": 999}, None) is True


def test_filter_elements_by_region():
    region = {"left": 50, "top": 50, "right": 200, "bottom": 200}
    elements = [
        {"name": "Inside1", "center": {"x": 100, "y": 100}},
        {"name": "Inside2", "bounds": {"left": 80, "top": 80, "right": 120, "bottom": 120}},
        {"name": "OutsideTop", "center": {"x": 100, "y": 20}},
        {"name": "OutsideRight", "center": {"x": 250, "y": 100}},
    ]
    filtered = filter_elements_by_region(elements, region)
    assert len(filtered) == 2
    assert [e["name"] for e in filtered] == ["Inside1", "Inside2"]


# ==============================================================================
# 4. RECALL, PRECISION, AND HONESTY EVALUATION
# ==============================================================================

def test_calculate_word_match_perfect():
    truth = ["Quick", "Brown", "Fox"]
    tokens = ["quick", "brown", "fox", "extra"]
    res = calculate_word_match(truth, tokens)
    assert res["matched_count"] == 3
    assert res["truth_count"] == 3
    assert res["recall"] == 1.0
    assert res["unmatched_truth"] == []


def test_calculate_word_match_half():
    truth = ["Quick", "Brown", "Fox", "Jumps"]
    tokens = ["quick", "fox"]
    res = calculate_word_match(truth, tokens)
    assert res["matched_count"] == 2
    assert res["truth_count"] == 4
    assert res["recall"] == 0.5
    assert res["unmatched_truth"] == ["brown", "jumps"]


def test_calculate_word_match_empty():
    truth = ["Alpha", "Beta"]
    tokens = []
    res = calculate_word_match(truth, tokens)
    assert res["matched_count"] == 0
    assert res["recall"] == 0.0
    assert res["unmatched_truth"] == ["alpha", "beta"]


def test_calculate_precision_in_region():
    valid_truth = ["Canvas", "Matrix", "Vector"]
    tokens = ["canvas", "matrix", "vector", "hallucination1", "hallucination2"]
    res = calculate_precision_in_region(valid_truth, tokens)
    assert res["ocr_count"] == 5
    assert res["matched_count"] == 3
    assert res["precision"] == 0.6


def test_evaluate_honesty_blank():
    # Non-blank capture is always honest
    assert evaluate_honesty_blank(capture_blank=False, ocr_status="available", ocr_count=0) is True

    # Blank capture with 'available' and 0 elements is a SILENT FALSE NEGATIVE (dishonest)
    assert evaluate_honesty_blank(capture_blank=True, ocr_status="available", ocr_count=0) is False

    # Blank capture reported as unavailable with a reason is honest
    assert evaluate_honesty_blank(capture_blank=True, ocr_status="unavailable", ocr_count=0) is True
    assert evaluate_honesty_blank(capture_blank=True, ocr_status="OCR unavailable", ocr_count=0) is True


# ==============================================================================
# 5. RULE EVALUATION ENGINE TESTS (G1 to G6)
# ==============================================================================

def make_base_real_results() -> dict[str, Any]:
    return {
        "NP": {
            "app": "Notepad",
            "status": "available",
            "capture_blank": False,
            "honesty_blank": True,
            "recall": 0.94,
            "precision": 0.95,
            "ocr_added_latency_ms": 120.0,
            "ram_delta_mb": 5.0,
            "uia_unchanged": True,
        },
        "CH": {
            "app": "Chrome",
            "status": "available",
            "capture_blank": False,
            "honesty_blank": True,
            "precision": 0.92,
            "subcases": {
                "canvas": {"recall": 0.90, "matched_count": 9, "truth_count": 10},
                "image": {"recall": 0.89, "matched_count": 25, "truth_count": 28},
                "dom": {"recall": 0.90, "matched_count": 9, "truth_count": 10},
            },
            "ocr_added_latency_ms": 250.0,
            "ram_delta_mb": 8.0,
            "uia_unchanged": True,
        },
        "ED": {
            "app": "Edge",
            "status": "available",
            "capture_blank": False,
            "honesty_blank": True,
            "precision": 0.91,
            "subcases": {
                "canvas": {"recall": 0.90, "matched_count": 9, "truth_count": 10},
                "image": {"recall": 0.86, "matched_count": 24, "truth_count": 28},
                "dom": {"recall": 0.90, "matched_count": 9, "truth_count": 10},
            },
            "ocr_added_latency_ms": 260.0,
            "ram_delta_mb": 10.0,
            "uia_unchanged": True,
        },
        "OCC": {
            "app": "Notepad Occlusion",
            "occluder_leaks": 0,
            "ocr_added_latency_ms": 110.0,
            "ram_delta_mb": 1.0,
            "uia_unchanged": True,
        },
        "CA": {
            "app": "Calculator",
            "informational": True,
            "recall": 0.50,
            "status": "available",
        },
        "ST": {
            "app": "Settings",
            "informational": True,
            "recall": 0.40,
            "status": "available",
        },
    }


def test_rules_all_pass_accept():
    """All rules G1-G6 pass -> VERDICT: ACCEPT."""
    res = make_base_real_results()
    verdict, rules = evaluate_real_apps_rules(res)
    assert verdict == "ACCEPT"
    assert all(r["passed"] for r in rules)


def test_rule_g1_failure_capture_blank():
    """G1 fails if any gating app has capture_blank == True."""
    res = make_base_real_results()
    res["CH"]["capture_blank"] = True
    res["CH"]["honesty_blank"] = True  # Honest capture failure
    verdict, rules = evaluate_real_apps_rules(res)
    assert verdict == "REJECT"
    g1 = next(r for r in rules if r["rule"] == "G1")
    assert g1["passed"] is False
    assert "CAPTURE FAILURE" in g1["details"]

    # Silent false negative
    res2 = make_base_real_results()
    res2["CH"]["capture_blank"] = True
    res2["CH"]["honesty_blank"] = False
    verdict2, rules2 = evaluate_real_apps_rules(res2)
    assert verdict2 == "REJECT"
    g1_2 = next(r for r in rules2 if r["rule"] == "G1")
    assert g1_2["passed"] is False
    assert "SILENT FALSE NEGATIVE" in g1_2["details"]


def test_rule_g2_failure_recall_below_85():
    """G2 fails if recall for NP, CH-canvas, CH-image, ED-canvas, or ED-image < 85%."""
    # Case A: NP recall fails
    res_np = make_base_real_results()
    res_np["NP"]["recall"] = 0.80
    v, r = evaluate_real_apps_rules(res_np)
    assert v == "REJECT"
    assert next(rule for rule in r if rule["rule"] == "G2")["passed"] is False

    # Case B: CH-image recall fails
    res_img = make_base_real_results()
    res_img["CH"]["subcases"]["image"]["recall"] = 0.75
    v2, r2 = evaluate_real_apps_rules(res_img)
    assert v2 == "REJECT"
    assert next(rule for rule in r2 if rule["rule"] == "G2")["passed"] is False


def test_rule_g3_failure_precision_below_90():
    """G3 fails if precision inside Region for NP, CH, or ED < 90%."""
    res = make_base_real_results()
    res["ED"]["precision"] = 0.85
    verdict, rules = evaluate_real_apps_rules(res)
    assert verdict == "REJECT"
    g3 = next(r for r in rules if r["rule"] == "G3")
    assert g3["passed"] is False


def test_rule_g4_failure_occluder_leaks():
    """G4 fails if occluder_leaks > 0."""
    res = make_base_real_results()
    res["OCC"]["occluder_leaks"] = 2
    verdict, rules = evaluate_real_apps_rules(res)
    assert verdict == "REJECT"
    g4 = next(r for r in rules if r["rule"] == "G4")
    assert g4["passed"] is False


def test_rule_g5_failure_high_latency_or_ram():
    """G5 fails if added latency > 1500 ms or RAM delta > 150 MB."""
    res = make_base_real_results()
    res["CH"]["ocr_added_latency_ms"] = 1600.0
    verdict, rules = evaluate_real_apps_rules(res)
    assert verdict == "REJECT"
    g5 = next(r for r in rules if r["rule"] == "G5")
    assert g5["passed"] is False

    res2 = make_base_real_results()
    res2["NP"]["ram_delta_mb"] = 180.0
    verdict2, rules2 = evaluate_real_apps_rules(res2)
    assert verdict2 == "REJECT"
    g5_2 = next(r for r in rules2 if r["rule"] == "G5")
    assert g5_2["passed"] is False


def test_rule_g6_failure_uia_changed():
    """G6 fails if uia_unchanged is False."""
    res = make_base_real_results()
    res["NP"]["uia_unchanged"] = False
    verdict, rules = evaluate_real_apps_rules(res)
    assert verdict == "REJECT"
    g6 = next(r for r in rules if r["rule"] == "G6")
    assert g6["passed"] is False


def test_informational_ca_st_do_not_block_verdict():
    """Low recall on informational Calculator (CA) and Settings (ST) does not fail verdict."""
    res = make_base_real_results()
    res["CA"]["recall"] = 0.10
    res["ST"]["recall"] = 0.05
    verdict, rules = evaluate_real_apps_rules(res)
    assert verdict == "ACCEPT"
    assert all(r["passed"] for r in rules)
