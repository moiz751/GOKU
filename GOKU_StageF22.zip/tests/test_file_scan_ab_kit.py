"""
tests/test_file_scan_ab_kit.py - Unit Tests for File Scanning A/B Benchmark Kit.

Verifies:
  1. Kit hash freeze integrity against reports/file_scan/KIT_HASH.json.
  2. Fixture generation and ground truth calculation in isolated temp directories.
  3. Win32 exclusive locking and clean release.
  4. Truncation honesty evaluator logic across all 40-match scenarios.
  5. Rule evaluation (F1 through F9) on synthetic passing and failing datasets.
  6. Comparator evaluation and relative performance rules (ACCEPT vs REJECT).
  7. Hard timeout enforcement runner.

Non-GUI only: strictly self-contained temp fixtures and mock data (Rule 16).
"""
from __future__ import annotations

import json
from pathlib import Path
import sys
import time
import pytest

PROJECT_ROOT = Path(__file__).resolve().parent.parent

from tests.file_scan_ab_test import (
    FileScanFixtureBundle,
    check_kit_hash,
    compute_file_sha256,
    compute_kit_sha256,
    evaluate_rules,
    evaluate_truncation_honesty,
    run_with_timeout,
)
from scripts.file_scan_compare import compare_file_scan_results


def test_kit_hash_freeze_integrity():
    """Verifies that the current kit code matches the frozen KIT_HASH.json."""
    assert check_kit_hash(PROJECT_ROOT) is True


def test_fixture_generation_in_temp_dir_and_cleanup(tmp_path):
    """Verifies that FileScanFixtureBundle creates required fixtures with computed ground truths and cleans up cleanly."""
    bundle = FileScanFixtureBundle(base_dir=tmp_path)
    try:
        fixtures = bundle.generate_all()
        assert len(fixtures) >= 9, "Bundle must generate all required fixture entries"

        # Check required fixture keys
        required_keys = [
            "alpha_doc", "sub1_zip", "sub1_png", "dup_alpha",
            "near_dup_alpha", "large_dummy", "hidden_file",
            "bulk_reports", "disguised_png", "disguised_pdf",
            "unknown_binary", "locked_file"
        ]
        for rk in required_keys:
            assert rk in fixtures, f"Missing required fixture: {rk}"
            f = fixtures[rk]
            assert f["sha256"] != "" or Path(f["path"]).is_dir() or f.get("skipped"), f"SHA-256 missing for {rk}"

        # Verify ground truth values
        assert fixtures["alpha_doc"]["ground_truth"]["size_bytes"] == 1024
        assert fixtures["large_dummy"]["ground_truth"]["size_bytes"] == 2 * 1024 * 1024
        assert fixtures["bulk_reports"]["ground_truth"]["count"] == 40

        temp_dir = bundle.temp_dir
        assert temp_dir.exists()
    finally:
        bundle.cleanup()
        assert not temp_dir.exists(), "Cleanup must remove temporary directory completely"


def test_win32_exclusive_locking_and_release(tmp_path):
    """Verifies that acquire_file_lock creates an exclusive Win32 lock that blocks reads and releases cleanly."""
    bundle = FileScanFixtureBundle(base_dir=tmp_path)
    test_file = tmp_path / "test_lock.txt"
    test_file.write_text("lock test content\n", encoding="utf-8")

    try:
        if sys.platform == "win32":
            locked = bundle.acquire_file_lock(test_file)
            assert locked is True, "acquire_file_lock should succeed on Windows"

            # Attempting to open the file should raise PermissionError
            with pytest.raises(PermissionError):
                with open(test_file, "r") as f:
                    f.read()

            bundle.release_file_lock()

            # Now reading should succeed
            with open(test_file, "r") as f:
                content = f.read()
            assert "lock test" in content
    finally:
        bundle.cleanup()


def test_truncation_honesty_evaluator():
    """Verifies evaluate_truncation_honesty logic across complete, flagged partial, and false success cases."""
    # 1. All 40 items returned -> HONEST
    items_40 = [f"item_{i}" for i in range(40)]
    h, _ = evaluate_truncation_honesty(40, items_40, {"matches": items_40, "count": 40})
    assert h is True

    # 2. 15 items returned with is_truncated=True -> HONEST
    items_15 = [f"item_{i}" for i in range(15)]
    h, _ = evaluate_truncation_honesty(40, items_15, {"matches": items_15, "count": 40, "is_truncated": True})
    assert h is True

    # 3. 15 items returned without is_truncated flag (silent truncation) -> FALSE SUCCESS
    h, r = evaluate_truncation_honesty(40, items_15, {"matches": items_15, "count": 15, "is_truncated": False})
    assert h is False
    assert "FALSE SUCCESS" in r

    # 4. Reported count 40 but matches list length 10 without is_truncated flag -> FALSE SUCCESS
    items_10 = [f"item_{i}" for i in range(10)]
    h, r = evaluate_truncation_honesty(40, items_10, {"matches": items_10, "count": 40, "is_truncated": False})
    assert h is False
    assert "FALSE SUCCESS" in r


def test_evaluate_rules_synthetic_pass_and_fail():
    """Verifies evaluate_rules on synthetic passing and failing datasets."""
    # 1. Fully passing trial dataset
    passing_trials = [
        {"trial_id": "F1_exact_name_recall", "pass": True, "recall_ratio": 1.0, "targets_found": 4, "targets_tested": 4, "elapsed_seconds": 0.05, "median_rss_delta_bytes": 100000},
        {"trial_id": "F2a_truncation_find_file", "is_honest": True, "elapsed_seconds": 0.05},
        {"trial_id": "F2b_truncation_search_files", "is_honest": True, "elapsed_seconds": 0.05},
        {"trial_id": "F2c_truncation_search_files_intelligent", "is_honest": True, "elapsed_seconds": 0.05},
        {"trial_id": "F3_duplicate_detection", "pass": True, "elapsed_seconds": 0.05},
        {"trial_id": "F4_locked_file_handling", "pass": True, "elapsed_seconds": 0.05},
        {"trial_id": "F5_metadata_accuracy", "pass": True, "elapsed_seconds": 0.05},
        {"trial_id": "F6_classification_magic_bytes", "pass": True, "elapsed_seconds": 0.05},
        {"trial_id": "F7_timeout_partial_handling", "pass": True, "elapsed_seconds": 0.05},
        {"trial_id": "F8_list_folder_structure", "pass": True, "elapsed_seconds": 0.05},
        {"trial_id": "F10_storage_drives_info", "drives_count": 2, "elapsed_seconds": 0.05},
    ]

    rules = evaluate_rules(passing_trials)
    assert rules["F1"]["pass"] is True
    assert rules["F2"]["pass"] is True
    assert rules["F3"]["pass"] is True
    assert rules["F4"]["pass"] is True
    assert rules["F5"]["pass"] is True
    assert rules["F6"]["pass"] is True
    assert rules["F7"]["pass"] is True
    assert rules["F8"]["pass"] is True
    assert rules["F9"]["pass"] is True
    assert rules["F10"]["pass"] is True

    # 2. Failing F1
    fail_f1 = [dict(t) for t in passing_trials]
    fail_f1[0]["pass"] = False
    fail_f1[0]["recall_ratio"] = 0.75
    assert evaluate_rules(fail_f1)["F1"]["pass"] is False

    # 3. Failing F2
    fail_f2 = [dict(t) for t in passing_trials]
    fail_f2[1]["is_honest"] = False
    assert evaluate_rules(fail_f2)["F2"]["pass"] is False

    # 4. Failing F3
    fail_f3 = [dict(t) for t in passing_trials]
    fail_f3[4]["pass"] = False
    assert evaluate_rules(fail_f3)["F3"]["pass"] is False

    # 5. Failing F4
    fail_f4 = [dict(t) for t in passing_trials]
    fail_f4[5]["pass"] = False
    assert evaluate_rules(fail_f4)["F4"]["pass"] is False

    # 6. Failing F5
    fail_f5 = [dict(t) for t in passing_trials]
    fail_f5[6]["pass"] = False
    assert evaluate_rules(fail_f5)["F5"]["pass"] is False

    # 7. Failing F6
    fail_f6 = [dict(t) for t in passing_trials]
    fail_f6[7]["pass"] = False
    assert evaluate_rules(fail_f6)["F6"]["pass"] is False

    # 8. Failing F7
    fail_f7 = [dict(t) for t in passing_trials]
    fail_f7[8]["pass"] = False
    assert evaluate_rules(fail_f7)["F7"]["pass"] is False

    # 9. Failing F8
    fail_f8 = [dict(t) for t in passing_trials]
    fail_f8[9]["pass"] = False
    assert evaluate_rules(fail_f8)["F8"]["pass"] is False

    # 10. Failing F9: crash or timeout recorded
    fail_f9 = [dict(t) for t in passing_trials]
    fail_f9[0]["crashed"] = True
    assert evaluate_rules(fail_f9)["F9"]["pass"] is False


def test_compare_file_scan_results_accept_and_reject():
    """Verifies comparator logic on mock datasets."""
    kit_sha = compute_kit_sha256()

    def make_dataset(tag: str, all_pass: bool = True, lat_ms: float = 40.0, rss_mb: float = 2.0):
        trials = [
            {"trial_id": "F1_exact_name_recall", "pass": all_pass, "recall_ratio": 1.0 if all_pass else 0.5, "elapsed_seconds": lat_ms / 1000.0, "median_rss_delta_bytes": int(rss_mb * 1024 * 1024)},
            {"trial_id": "F2a_truncation_find_file", "is_honest": all_pass, "elapsed_seconds": 0.05},
            {"trial_id": "F3_duplicate_detection", "pass": all_pass, "elapsed_seconds": 0.05},
            {"trial_id": "F4_locked_file_handling", "pass": all_pass, "elapsed_seconds": 0.05},
            {"trial_id": "F5_metadata_accuracy", "pass": all_pass, "elapsed_seconds": 0.05},
            {"trial_id": "F6_classification_magic_bytes", "pass": all_pass, "elapsed_seconds": 0.05},
            {"trial_id": "F7_timeout_partial_handling", "pass": all_pass, "elapsed_seconds": 0.05},
            {"trial_id": "F8_list_folder_structure", "pass": all_pass, "elapsed_seconds": 0.05},
        ]
        rules = evaluate_rules(trials)
        rules["F10"]["median_latency_ms"] = lat_ms
        rules["F10"]["median_rss_delta_mb"] = rss_mb
        return {
            "tag": tag,
            "kit_sha256": kit_sha,
            "files_py_sha256": "dummy_files_sha",
            "search_py_sha256": "dummy_search_sha",
            "file_intelligence_py_sha256": "dummy_intel_sha",
            "folders_py_sha256": "dummy_folders_sha",
            "rules": rules,
            "trials": trials,
        }

    # Case 1: Before fails rules, After passes everything within perf envelope -> ACCEPT
    b_data = make_dataset("before", all_pass=False, lat_ms=50.0, rss_mb=2.0)
    a_data = make_dataset("after", all_pass=True, lat_ms=60.0, rss_mb=3.0)
    res = compare_file_scan_results(b_data, a_data)
    assert res["verdict"] == "ACCEPT"

    # Case 2: After fails a rule -> REJECT
    a_fail = make_dataset("after", all_pass=False, lat_ms=60.0, rss_mb=3.0)
    assert compare_file_scan_results(b_data, a_fail)["verdict"] == "REJECT"

    # Case 3: After latency regresses beyond 1.25x + 50ms (before=50ms -> max=112.5ms)
    a_slow = make_dataset("after", all_pass=True, lat_ms=120.0, rss_mb=3.0)
    assert compare_file_scan_results(b_data, a_slow)["verdict"] == "REJECT"

    # Case 4: After RAM regresses beyond before + 10MB (before=2.0MB -> max=12.0MB)
    a_fat = make_dataset("after", all_pass=True, lat_ms=60.0, rss_mb=15.0)
    assert compare_file_scan_results(b_data, a_fat)["verdict"] == "REJECT"

    # Case 5: Kit hash mismatch -> raises ValueError
    b_bad = dict(b_data)
    b_bad["kit_sha256"] = "mismatched_kit_hash"
    with pytest.raises(ValueError, match="Kit hash mismatch"):
        compare_file_scan_results(b_bad, a_data)


def test_run_with_timeout_runner():
    """Verifies timeout runner terminates slow callables."""
    def fast_fn():
        return 42

    r_fast = run_with_timeout(fast_fn, timeout=1.0)
    assert r_fast["result"] == 42
    assert r_fast["timed_out"] is False

    def slow_fn():
        time.sleep(1.0)
        return 99

    r_slow = run_with_timeout(slow_fn, timeout=0.1)
    assert r_slow["timed_out"] is True
    assert r_slow["result"] is None
