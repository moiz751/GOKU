"""Stage F21: D14 paste guard + deep read-only device scan (+ routing of the phrases that failed on the real Windows laptop).
Linux/tmp-dir tests only: they prove logic, NOT live Windows behaviour (msvcrt paste detection, real drive permissions)."""
import os
import hashlib

import pytest

from brain import paste_guard as pg
from brain import f15_tasks
from tools import device_scan_deep as ds

# lines that really ran tools on the user's laptop (tool in brackets)
D14_LINES = [
    "4. Do not switch to unrestricted run mode merely to obtain passing results.",   # get_bluetooth_status
    "6. Never fabricate test results, logs, screenshots, or completion claims.",     # take_screenshot
    "- Exit code or exception.",                                                     # close_app VS Code
    "4. Failed, skipped, blocked, and untested cases.",                              # launch_app Blocked
    "# GOKU — Post-Repair Execution Validation & Evidence Audit",
    "## Strict rules",
    "> Do not modify, delete, overwrite, or install anything.",
]
REAL_COMMANDS = ["notepad kholo", "advise mere laptop ka health scan karo", "monthly report", "device inventory", "adaptive status",
                 "mere laptop par 1.1 GB RAM available hone ki surat mein task execute karo", "chrome open karo", "capabilities", "deep device scan 10 min"]


@pytest.mark.parametrize("line", D14_LINES)
def test_d14_prose_lines_are_not_commands(line):
    out = pg.guard(line, pending=lambda: False)
    assert out and "PASTE GUARD" in out and "kuch execute nahi kiya" in out


@pytest.mark.parametrize("line", REAL_COMMANDS)
def test_real_commands_still_run(line):
    assert pg.guard(line, pending=lambda: False) is None


def test_long_prose_blocked_and_run_prefix_forces():
    long = " ".join(["word"] * 60)
    assert "PASTE GUARD" in pg.guard(long, pending=lambda: False)
    assert pg.guard("run: - Exit code", pending=lambda: False) is None
    assert pg.force_text("run: notepad kholo") == "notepad kholo"


def test_multiline_paste_burst_is_dropped_as_one_block():
    buf = ["second line", "third line", "fourth line"]
    out = pg.guard("first line", readline=lambda: buf.pop(0) + "\n", pending=lambda: bool(buf))
    assert out and "4 lines" in out and buf == []


def test_single_typed_line_has_no_burst():
    assert pg.drain_paste_burst("x", readline=lambda: "", pending=lambda: False) == []


# ---------------- deep scan
def _tree(tmp_path):
    (tmp_path / "pics").mkdir()
    (tmp_path / "docs" / "sub").mkdir(parents=True)
    (tmp_path / "pics" / "a.jpg").write_bytes(b"x" * 100)
    (tmp_path / "pics" / "b.PNG").write_bytes(b"x" * 50)
    (tmp_path / "docs" / "r.pdf").write_bytes(b"y" * 300)
    (tmp_path / "docs" / "sub" / "n.txt").write_bytes(b"z" * 10)
    (tmp_path / "setup.exe").write_bytes(b"e" * 20)
    return tmp_path


def _snapshot(root):
    out = {}
    for dp, _, fs in os.walk(root):
        for f in fs:
            p = os.path.join(dp, f)
            out[p] = (os.path.getsize(p), hashlib.sha256(open(p, "rb").read()).hexdigest(), os.stat(p).st_mtime_ns)
    return out


def test_deep_scan_counts_and_is_read_only(tmp_path):
    _tree(tmp_path)
    before = _snapshot(tmp_path)
    res = ds.deep_scan([str(tmp_path)], total_time_s=30)
    assert _snapshot(tmp_path) == before                     # nothing created, changed, moved or deleted
    d = res["per_drive"][0]
    assert d["completed"] and res["coverage"].startswith("COMPLETE")
    assert d["files"] == 5 and d["bytes"] == 480
    assert d["categories"]["images"]["files"] == 2 and d["categories"]["documents"]["files"] == 2 and d["categories"]["programs"]["files"] == 1
    assert d["contents_read"] is False and res["files_modified"] == 0
    assert any("pics" in k for k, _ in d["image_video_folders"])
    assert d["biggest_files"][0][0] == 300


def test_cut_short_scan_is_never_called_complete(tmp_path):
    _tree(tmp_path)
    for i in range(600):
        (tmp_path / f"f{i}.bin").write_bytes(b"1")
    res = ds.deep_scan([str(tmp_path)], total_time_s=30, max_entries_per_root=300)
    d = res["per_drive"][0]
    assert not d["completed"] and d["stopped_because"] == "entry limit reached"
    assert res["coverage"].startswith("PARTIAL") and res["drives_cut_short"] == [str(tmp_path)]
    assert "CUT SHORT" in ds.render_deep_scan(res)


def test_time_budget_cuts_scan_short(tmp_path):
    for i in range(1000):
        (tmp_path / f"f{i}.bin").write_bytes(b"1")
    t = iter(range(0, 10**6, 100))                          # fake clock jumps 100 s every call
    d = ds.scan_root(str(tmp_path), time_budget_s=5, max_entries=10**9, now=lambda: float(next(t)))
    assert not d["completed"] and d["stopped_because"] == "time budget reached"


def test_missing_drive_is_reported_not_hidden(tmp_path):
    res = ds.deep_scan([str(tmp_path / "Z_missing")], total_time_s=10)
    assert res["per_drive"][0]["stopped_because"] == "path not accessible" and res["drives_completed"] == []
    assert res["coverage"].startswith("PARTIAL")


def test_symlink_loop_is_not_followed(tmp_path):
    (tmp_path / "d").mkdir()
    (tmp_path / "d" / "f.txt").write_text("hi")
    try:
        os.symlink(str(tmp_path), str(tmp_path / "d" / "loop"), target_is_directory=True)
    except (OSError, NotImplementedError):
        pytest.skip("symlinks unavailable")
    res = ds.deep_scan([str(tmp_path)], total_time_s=20)
    assert res["per_drive"][0]["completed"] and res["per_drive"][0]["files"] == 1


# ---------------- routing of the phrases that failed on Windows
@pytest.mark.parametrize("text", ["full scan al files folder each and every thing about this device", "deep device scan", "Deep device scan 15 min", "poora computer scan",
                                  "scan all files"])
def test_full_scan_phrases_route_to_deep_scan(text):
    assert f15_tasks.match(text) == "device_deep_scan"


def test_bounded_inventory_still_routes_and_says_it_is_bounded():
    assert f15_tasks.match("full device scan") == "device_inventory"
    assert f15_tasks.match("device inventory") == "device_inventory"


def test_deep_scan_handler_end_to_end(tmp_path, monkeypatch):
    _tree(tmp_path)
    monkeypatch.setattr(ds, "fixed_drive_roots", lambda: [str(tmp_path)])
    out = f15_tasks.handle("deep device scan 1 min")
    assert out and "Deep Read-Only Device Scan" in out and "COMPLETE" in out and "NOT read" in out


def test_users_real_single_line_scan_request_is_not_blocked():
    """The long but genuine one-line command typed on Windows must still run (advisor + router)."""
    line = ("mere computer ki tamam drives, files aur folders ka read-only scan karo. Storage, RAM, installed software, file types, folder sizes aur system information "
            "ki inventory banao. Koi file modify, delete ya move mat karna.")
    assert pg.guard(line, pending=lambda: False) is None
    from brain import request_advisor as ra
    a = ra.advise(line, log=False)
    assert a["status"] == "CAN" and a["intent"] in ("full_device_audit", "deep_device_scan")


def test_advisor_never_says_can_to_pasted_text():
    from brain import request_advisor as ra
    for line in D14_LINES:
        a = ra.advise(line, log=False)
        assert a["status"] == "CLARIFY" and a["intent"] == "pasted_text"
    a = ra.advise("full scan al files folder each and every thing about this device", log=False)
    assert (a["status"], a["intent"]) == ("CAN", "deep_device_scan")


def test_capabilities_explains_health_clarify():
    from brain import request_advisor as ra
    out = ra.handle_command("capabilities")
    assert "health: CLARIFY" in out and "PC/laptop health = CAN" in out
