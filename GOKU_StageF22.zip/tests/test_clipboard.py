from unittest.mock import patch

from command_layer.router import handle_command
from tools.clipboard import clear_clipboard, get_clipboard_text, set_clipboard_text


def test_set_and_get_clipboard_text():
    set_res = set_clipboard_text("Phase 4 Clipboard Test")
    assert set_res["success"] is True

    get_res = get_clipboard_text()
    assert get_res["success"] is True
    if get_res["status"] == "completed":
        assert "Phase 4 Clipboard Test" in get_res["text"]


def test_clear_clipboard():
    res = clear_clipboard()
    assert res["success"] is True
    assert "cleared successfully" in res["message"]


def test_clipboard_non_text_format_handling():
    with patch("tools.clipboard._win32_get_clipboard_text", return_value=(True, "Clipboard contains an image, not plain text.", "non_text_image")):
        res = get_clipboard_text()
        assert res["success"] is True
        assert res["status"] == "non_text_image"
        assert "contains an image" in res["message"]


def test_router_clipboard_commands():
    with patch("tools.clipboard.get_clipboard_text", return_value={"success": True, "status": "completed", "message": "Clipboard content: Hello", "text": "Hello"}):
        reply = handle_command("clipboard mein kya hai?")
        assert "Clipboard content: Hello" in reply

    with patch("tools.clipboard.clear_clipboard", return_value={"success": True, "status": "completed", "message": "Clipboard cleared successfully."}):
        reply = handle_command("clipboard clear karo")
        assert "cleared successfully" in reply
