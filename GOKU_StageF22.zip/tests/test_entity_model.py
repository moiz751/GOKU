"""
Unit tests for EntityType and TypedEntity tracking in SessionContext.
"""
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).parent.parent))

from command_layer.context import EntityType, SessionContext, TypedEntity, update_context_from_result


def test_typed_entity_creation():
    e = TypedEntity(value="chrome", entity_type=EntityType.APPLICATION, metadata={"pid": 1234})
    assert e.value == "chrome"
    assert e.entity_type == EntityType.APPLICATION
    assert e.metadata["pid"] == 1234


def test_session_context_typed_tracking():
    ctx = SessionContext()

    update_context_from_result(
        ctx,
        "launch_app",
        {"name": "chrome"},
        {"success": True, "app_name": "chrome", "pid": 5678},
    )
    assert ctx.last_application is not None
    assert ctx.last_application.entity_type == EntityType.APPLICATION
    assert ctx.last_application.value == "chrome"

    update_context_from_result(
        ctx,
        "create_folder",
        {"path": "C:/Users/User/Desktop/TestFolder"},
        {"success": True, "path": "C:/Users/User/Desktop/TestFolder"},
    )
    assert ctx.last_folder is not None
    assert ctx.last_folder.entity_type == EntityType.FOLDER
    assert "TestFolder" in ctx.last_folder.value
