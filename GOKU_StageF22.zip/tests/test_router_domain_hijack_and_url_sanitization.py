from command_layer.router import (
    sanitize_url,
    is_standalone_navigation_request,
    decompose_deterministic_plan,
    route_command,
)
from command_layer.context import session_context


def test_markdown_url_sanitization():
    """Verify URLs are cleaned from markdown syntax and formatted correctly."""
    assert sanitize_url("https://site](https://site)") == "https://site"
    assert sanitize_url("[https://flappybird.io/](https://flappybird.io/)") == "https://flappybird.io/"
    assert sanitize_url("flappybird.io](https://flappybird.io/)") == "https://flappybird.io/"
    assert sanitize_url("https://google.com") == "https://google.com"
    assert sanitize_url("google.com") == "https://google.com"
    assert sanitize_url("chrome mein https://github.com/ kholo") == "https://github.com/"


def test_standalone_navigation_detection():
    """Verify standalone navigation requests are distinguished from compound instructions."""
    assert is_standalone_navigation_request("chrome mein google.com kholo") is True
    assert is_standalone_navigation_request("google.com open karo") is True
    assert is_standalone_navigation_request("open https://site.org") is True

    # Compound requests with 'aur', 'phir', 'cmd', 'notepad' must return False
    assert is_standalone_navigation_request("cmd mein dir chalao aur chrome mein google.com kholo") is False
    assert is_standalone_navigation_request("google.com kholo phir notepad mein likho") is False
    assert is_standalone_navigation_request("notepad kholo aur google.com kholo") is False
    assert is_standalone_navigation_request("powershell chalao ipconfig phir google.com open karo") is False


def test_compound_cli_browser_notepad_chronological_order():
    """Verify compound CLI + Browser + Notepad retains all phases in chronological order."""
    text = "cmd mein dir chalao aur chrome mein google.com kholo aur notepad mein 'Line 1' enter daba kar 'Line 2' likho"
    plan = decompose_deterministic_plan(text)
    assert plan is not None
    assert len(plan.steps) == 8

    # Phase 1: CLI
    assert plan.steps[0].tool == "execute_system_command"
    assert plan.steps[0].args["command"] == "dir"
    assert plan.steps[0].args["shell"] == "cmd"

    # Phase 2: Browser
    assert plan.steps[1].tool == "launch_app"
    assert plan.steps[1].args["name"] == "chrome"
    assert plan.steps[2].tool == "open_url"
    assert plan.steps[2].args["url"] == "https://google.com"

    # Phase 3: Notepad
    assert plan.steps[3].tool == "launch_app"
    assert plan.steps[3].args["name"] == "Notepad"
    assert plan.steps[4].tool == "focus_app_window"
    assert plan.steps[4].args["app_name"] == "Notepad"
    assert plan.steps[5].tool == "type_text"
    assert plan.steps[5].args["text"] == "Line 1"
    assert plan.steps[6].tool == "press_hotkey"
    assert plan.steps[6].args["keys"] == "enter"
    assert plan.steps[7].tool == "type_text"
    assert plan.steps[7].args["text"] == "Line 2"


def test_compound_browser_first_retains_chronological_order():
    """Verify compound with Browser first preserves chronological order."""
    text = "google.com kholo phir cmd mein ipconfig chalao aur notepad kholo"
    plan = decompose_deterministic_plan(text)
    assert plan is not None
    assert len(plan.steps) == 4

    # Phase 1: Browser
    assert plan.steps[0].tool == "launch_app"
    assert plan.steps[0].args["name"] == "chrome"
    assert plan.steps[1].tool == "open_url"
    assert plan.steps[1].args["url"] == "https://google.com"

    # Phase 2: CLI
    assert plan.steps[2].tool == "execute_system_command"
    assert plan.steps[2].args["command"] == "ipconfig"
    assert plan.steps[2].args["shell"] == "cmd"

    # Phase 3: Notepad
    assert plan.steps[3].tool == "launch_app"
    assert plan.steps[3].args["name"] == "Notepad"


def test_compound_powershell_and_markdown_url():
    """Verify compound CLI with Markdown link syntax extracts clean URL."""
    text = "powershell chalao Get-Process aur https://flappybird.io/](https://flappybird.io/) kholo"
    plan = decompose_deterministic_plan(text)
    assert plan is not None
    assert len(plan.steps) == 3

    assert plan.steps[0].tool == "execute_system_command"
    assert plan.steps[0].args["command"] == "Get-Process"
    assert plan.steps[0].args["shell"] == "powershell"

    assert plan.steps[1].tool == "launch_app"
    assert plan.steps[1].args["name"] == "chrome"
    assert plan.steps[2].tool == "open_url"
    assert plan.steps[2].args["url"] == "https://flappybird.io/"


def test_standalone_navigation_request_generates_isolated_plan():
    """Verify standalone navigation generates standard isolated navigation plan."""
    text = "chrome mein google.com kholo"
    plan = route_command(text, session_context)
    assert plan is not None
    assert len(plan.steps) == 2
    assert plan.steps[0].tool == "launch_app"
    assert plan.steps[1].tool == "open_url"
    assert plan.steps[1].args["url"] == "https://google.com"
