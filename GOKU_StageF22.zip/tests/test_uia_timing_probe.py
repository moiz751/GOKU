"""
tests/test_uia_timing_probe.py
Non-GUI unit tests for scratch/uia_timing_probe.py.

Strictly non-GUI: no applications are launched, no Tkinter roots are opened.
Tests:
- Path resolution for output JSON
- Summary statistics computation (median, min, max, element counts)
- Table formatting
- Result schema validation
"""
from __future__ import annotations

import json
from pathlib import Path
import pytest
import sys

PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from scratch.uia_timing_probe import (
    compute_timing_summary,
    format_probe_ascii_table,
    resolve_probe_output_path,
)


def test_resolve_probe_output_path():
    """Verifies output path follows reports/screen_change/probe/uia_timing_<tag>.json."""
    p1 = resolve_probe_output_path("uia1")
    assert p1.name == "uia_timing_uia1.json"
    assert "reports" in p1.parts
    assert "screen_change" in p1.parts
    assert "probe" in p1.parts

    custom_dir = PROJECT_ROOT / "temp_probe"
    p2 = resolve_probe_output_path("custom_tag", base_dir=custom_dir)
    assert p2 == custom_dir / "uia_timing_custom_tag.json"


def test_compute_timing_summary_empty():
    """Empty call list returns zeroes safely."""
    summ = compute_timing_summary([])
    assert summ["median_ms"] == 0.0
    assert summ["min_ms"] == 0.0
    assert summ["max_ms"] == 0.0
    assert summ["median_elements"] == 0


def test_compute_timing_summary_metrics():
    """Verifies median, min, max calculation across 5 mock calls."""
    calls = [
        {"latency_ms": 100.0, "element_count": 20},
        {"latency_ms": 120.0, "element_count": 20},
        {"latency_ms": 3500.0, "element_count": 1},
        {"latency_ms": 80.0, "element_count": 22},
        {"latency_ms": 95.0, "element_count": 20},
    ]
    summ = compute_timing_summary(calls)
    assert summ["min_ms"] == 80.0
    assert summ["max_ms"] == 3500.0
    assert summ["median_ms"] == 100.0
    assert summ["median_elements"] == 20


def test_format_probe_ascii_table():
    """Verifies formatted ASCII table contains window names and metrics."""
    mock_results = {
        "tag": "test_tag",
        "windows": {
            "Tkinter": {
                "calls": [
                    {"latency_ms": 3512.4, "element_count": 0},
                    {"latency_ms": 3508.1, "element_count": 0},
                ],
                "summary": {"median_ms": 3510.2, "median_elements": 0},
            },
            "Notepad": {
                "calls": [
                    {"latency_ms": 42.5, "element_count": 24},
                    {"latency_ms": 45.1, "element_count": 24},
                ],
                "summary": {"median_ms": 43.8, "median_elements": 24},
            },
        },
    }
    table = format_probe_ascii_table(mock_results)
    assert "Target Window" in table
    assert "Tkinter" in table
    assert "3512ms (0)" in table
    assert "Notepad" in table
    assert "44ms (24)" in table or "43ms (24)" in table or "44" in table


def test_probe_schema_and_stage_note(tmp_path: Path):
    """Verifies JSON schema serializability and inclusion of stage timing rationale."""
    mock_payload = {
        "tag": "mock_uia1",
        "timestamp": "2026-10-20T12:00:00",
        "stage_timing_note": "Internal UIA worker stages run on uninstrumented worker thread.",
        "windows": {
            "Notepad": {
                "class_name": "Notepad",
                "hwnd": 12345,
                "calls": [
                    {
                        "call_index": 1,
                        "latency_ms": 45.2,
                        "element_count": 24,
                        "source_breakdown": {"uia": 24},
                        "click_verified_count": 5,
                        "status": "completed",
                        "timed_out_35s": False,
                    }
                ],
                "summary": {"median_ms": 45.2, "min_ms": 45.2, "max_ms": 45.2, "median_elements": 24},
            }
        },
    }
    out_file = tmp_path / "uia_timing_mock.json"
    out_file.write_text(json.dumps(mock_payload, indent=2), encoding="utf-8")

    loaded = json.loads(out_file.read_text(encoding="utf-8"))
    assert loaded["tag"] == "mock_uia1"
    assert "stage_timing_note" in loaded
    assert "Notepad" in loaded["windows"]
    assert loaded["windows"]["Notepad"]["calls"][0]["element_count"] == 24
