import json
import pytest
from brain import seo_workflow as W

ARTICLE = """# Home Workout Basics

If you are a beginner, a home workout is the easiest way to start exercising without a gym. This guide explains how a home workout can fit into a busy day and what you need to begin.

## Why a home workout works

A home workout saves travel time and costs nothing. Beginners can repeat short sessions several times a week and track progress in a notebook. The key is a regular routine that you can keep for months, not a perfect plan that you drop after a week.

## Simple home workout exercises

- Squats
- Push-ups
- Planks

Start with three sets of ten squats, then rest for one minute. A home workout should feel challenging but never painful. Studies show that regular activity improves mood, and 30% of adults do not exercise enough.

## Staying consistent

Pick fixed days and set a reminder. Beginners who plan ahead find it easier to continue. A home workout needs only a small space and a mat.
""" + ("\nMore text about routines and simple habits for beginners who want to build a home workout. " * 12)


class FakeWP:
    def __init__(self, allow=True):
        self.posts, self.allow, self.calls = {}, allow, []

    def __call__(self, method, url, headers, payload):
        self.calls.append((method, url))
        if "users/me" in url:
            return {"status": 200 if self.allow else 401, "json": {"name": "admin", "capabilities": {"publish_posts": True}}}
        if method == "POST" and url.endswith("/posts"):
            pid = len(self.posts) + 1
            self.posts[pid] = {"id": pid, "status": payload["status"], "title": {"raw": payload["title"]}, "slug": payload["slug"], "link": f"https://x.test/{payload['slug']}/", "html": payload["title"]}
            return {"status": 201, "json": self.posts[pid]}
        if method == "POST":
            pid = int(url.rsplit("/", 1)[1])
            self.posts[pid]["status"] = payload["status"]
            return {"status": 200, "json": self.posts[pid]}
        if "/posts/" in url:
            return {"status": 200, "json": self.posts[int(url.split("/posts/")[1].split("?")[0])]}
        if url.startswith("https://x.test/"):
            p = next(v for v in self.posts.values() if v["link"] == url)
            return {"status": 200 if p["status"] == "publish" else 404, "text": f"<h1>{p['html']}</h1>"}
        return {"status": 404}


ENV = {"GOKU_WP_URL": "https://x.test", "GOKU_WP_USER": "admin", "GOKU_WP_APP_PASSWORD": "abcd efgh"}


def test_one_instruction_runs_all_stages_and_saves_outputs(tmp_path):
    job = W.SeoJob(ARTICLE, workdir=tmp_path / "j", env={})
    job.run()
    st = {s: job.status_of(s) for s in W.STAGES}
    assert [s for s in W.STAGES[:4]] and all(st[s] == "done" for s in ("understand", "topic", "intent", "keywords", "gaps", "optimize", "onpage", "additions", "quality"))
    assert st["competitors"] == "blocked" and "invented" in job.state["stages"]["competitors"]["reason"]
    assert st["wp_prepare"] == "blocked" and "no authorized" in job.state["stages"]["wp_prepare"]["reason"]
    assert st["publish"] == "pending"
    assert (tmp_path / "j" / "stage04_keywords.json").exists() and (tmp_path / "j" / "report.md").exists()
    assert job.out("keywords")["primary"] == "home workout"
    on = job.out("onpage")
    assert len(on["title_tag"]) <= 60 and len(on["meta_description"]) <= 155 and on["slug"] == "home-workout"
    assert job.out("intent")["intent"] == "informational" and job.out("topic")["audience"] == "beginners"
    assert job.out("additions")["claims_needing_a_source"] and job.out("additions")["faq"]
    assert "not invent" in job.out("additions")["external_references"]
    opt = (tmp_path / "j" / "optimized.md").read_text()
    assert "Squats" in opt and "Why a home workout works" in opt                      # meaning and wording preserved
    rep = (tmp_path / "j" / "report.md").read_text()
    assert "nothing has been verified" in rep


def test_resume_does_not_redo_finished_stages(tmp_path):
    j1 = W.SeoJob(ARTICLE, workdir=tmp_path / "j", env={}); j1.run(until="keywords")
    t = j1.state["stages"]["keywords"]["t"]
    j2 = W.SeoJob(ARTICLE, workdir=tmp_path / "j", env={}); j2.run()
    assert j2.state["stages"]["keywords"]["t"] == t and j2.status_of("quality") == "done"
    j3 = W.SeoJob(ARTICLE + "\nExtra.", workdir=tmp_path / "j", env={})
    assert j3.status_of("keywords") == "pending"                                       # changed article -> redo


def test_competitors_only_from_real_search(tmp_path):
    j = W.SeoJob(ARTICLE, workdir=tmp_path / "j", env={}, web_fn=lambda q: [{"title": "T", "url": "https://a.test/1", "snippet": "s"}])
    j.run(until="competitors")
    assert j.out("competitors")["pages"][0]["url"] == "https://a.test/1"
    j2 = W.SeoJob(ARTICLE, workdir=tmp_path / "k", env={}, web_fn=lambda q: (_ for _ in ()).throw(RuntimeError("offline")))
    j2.run(until="competitors")
    assert j2.status_of("competitors") == "blocked"


def test_keyword_stuffing_detected(tmp_path):
    j = W.SeoJob("# Cheap pens\n\n" + "Buy cheap pens. Cheap pens are cheap pens. " * 40, workdir=tmp_path / "j", env={})
    j.run(until="quality")
    q = j.out("quality")
    assert q["keyword_stuffing"] and q["duplicate_sentences"]


def test_wordpress_draft_then_approval_then_verified_publish(tmp_path):
    wp = FakeWP()
    j = W.SeoJob(ARTICLE, workdir=tmp_path / "j", env=ENV, http_fn=wp)
    j.run()
    assert j.status_of("wp_prepare") == "done" and wp.posts[1]["status"] == "draft"          # prepared as DRAFT only
    assert j.state["awaiting_approval"] and "seo approve" in (tmp_path / "j" / "final_review.md").read_text()
    assert j.status_of("publish") == "pending" and wp.posts[1]["status"] == "draft"          # not public without approval
    j.approve()
    assert wp.posts[1]["status"] == "publish" and j.status_of("publish") == "done"
    chk = j.out("publish")["checks"]
    assert all(chk.values()) and any(c[0] == "GET" and c[1] == "https://x.test/home-workout/" for c in wp.calls)
    assert "not verified" in j.out("publish")["seo_plugin_fields"]
    assert "abcd" not in json.dumps(j.state) and "abcd" not in (tmp_path / "j" / "report.md").read_text()      # password never stored


def test_bad_credentials_never_pretend(tmp_path):
    wp = FakeWP(allow=False)
    j = W.SeoJob(ARTICLE, workdir=tmp_path / "j", env=ENV, http_fn=wp); j.run()
    assert j.status_of("wp_prepare") == "blocked" and "401" in j.state["stages"]["wp_prepare"]["reason"] and not wp.posts
    j.approve()
    assert j.status_of("publish") == "blocked" and "no prepared" in j.state["stages"]["publish"]["reason"]


def test_publish_verification_failure_is_reported(tmp_path):
    wp = FakeWP()
    orig = wp.__call__
    def bad(method, url, headers, payload):
        if url.startswith("https://x.test/") and "wp-json" not in url:
            return {"status": 404, "text": ""}
        return orig(method, url, headers, payload)
    j = W.SeoJob(ARTICLE, workdir=tmp_path / "j", env=ENV, http_fn=bad); j.run(); j.approve()
    assert j.status_of("publish") == "blocked" and "public_url_opens" in j.state["stages"]["publish"]["reason"]


def test_command(tmp_path, monkeypatch):
    monkeypatch.setattr(W, "JOBS_DIR", tmp_path / "jobs")
    f = tmp_path / "blog.md"; f.write_text(ARTICLE, encoding="utf-8")
    out = W.handle_command(f"seo run {f}")
    assert "keywords" in out and "Limits" in out
    assert "keywords" in W.handle_command("seo status")
    assert "abhi tayyar nahi" in W.handle_command("seo show")
    assert W.handle_command("hello") is None
