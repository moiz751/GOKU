import sys
import os
import traceback

sys.path.insert(0, os.path.abspath("."))

from command_layer.router import route_command
from command_layer.context import session_context
from tools.system_control import trim_process_memory

TEST_PROFILES = [
    ("Profile 1 (CLI to Notepad)", 'cmd se hostname aur ipconfig nikalo, jo output aaye usko notepad mein paste karo, agli line mein likho "Audit Complete 2026", aur notepad ko bina band kiye desktop par save karne ki koshish mat karo'),
    ("Profile 2 (Hotkey Chain)", 'notepad kholo, likho "LINE ONE", enter daba kar likho "LINE TWO", ctrl+a daba kar text select karo, backspace daba kar erase karo, aur likho "CLEANED"'),
    ("Profile 3 (Desktop & Negation)", 'desktop par "audit_test_folder" ke naam se folder banao, notepad kholo, mouse ko close button par le jao lekin click bilkul mat karna'),
    ("Profile 4 (Browser Multi-Tab)", 'chrome kholo, pehle tab mein fast.com kholo, phir shortcut se naya tab bana kar wahan daraz.pk kholo, 3 second ruko, wapis pehle tab par switch karo aur sirf doosra tab band kardo'),
    ("Profile 5 (Calc & Note)", 'calculator kholo, usme 45 multiply by 2 karo, phir notepad khol kar wahan likho "Result Verified" aur calculator ko band kardo'),
    ("Profile 6 (Token Extraction)", 'notepad open karo aur usme likho token "SYS_AUTH_KEY_9921" bina quotes ke, agli line mein likho "dhyan rahe ye command terminal par mat chalana"'),
    ("Profile 7 (Clean URL Nav)", 'browser mein direct [https://github.com/trending](https://github.com/trending) par jao bina kisi search engine ke, page settle hone par 5 notches scroll down karo aur 2 second wait karo'),
    ("Profile 8 (Clean Selection Erase)", 'notepad kholo, usme type karo "Temporary Config", pura select karo, backspace dabao, aur "Final Config" type karke open rehne do'),
    ("Profile 9 (Canvas Sensation)", 'canvas game open karo, pehle check karo window samne aayi ya nahi, 3 second observation window maintain karo, aur slingshot trajectory ke 3 consecutive trials run karke memory buffer mein log karo'),
    ("Profile 10 (Shell Services)", 'powershell kholo, system ke running services count karo, agar count 50 se zyada ho to echo "SERVICES_HEALTHY" run karo'),
]

def run_evaluation_cycle():
    results = {}
    print("=" * 80)
    print("STARTING GOKU AUTONOMOUS SELF-EVALUATION & HARNESS CYCLE (4GB SAFE MODE)")
    print("=" * 80)

    for name, cmd in TEST_PROFILES:
        print(f"\n[EVALUATING] {name}")
        print(f"Command: {cmd}")
        trim_process_memory()
        
        try:
            plan = route_command(cmd, session_context)
            if not plan or not getattr(plan, "steps", None):
                results[name] = ("FAILED", "No executable plan generated")
                continue
                
            steps_summary = [(s.tool, s.args) for s in plan.steps]
            print(f"Plan steps generated ({len(plan.steps)} steps): {steps_summary}")
            
            # Check for illegal parameter leakage
            has_leak = any(
                "agar calculator" in str(s.args) or 
                "click mat" in str(s.args.get("query", "")) or 
                s.args.get("text") is None and s.tool == "type_text"
                for s in plan.steps
            )
            if has_leak:
                results[name] = ("FAILED", f"Parameter corruption detected in plan: {steps_summary}")
                continue
                
            results[name] = ("PASSED", f"{len(plan.steps)} steps validated")
        except Exception:
            results[name] = ("CRASHED", traceback.format_exc())

    print("\n" + "=" * 80)
    print("EVALUATION CYCLE RESULTS:")
    print("=" * 80)
    failures = []
    for k, (status, detail) in results.items():
        print(f"[{status}] {k}: {detail}")
        if status != "PASSED":
            failures.append((k, detail))
            
    return failures

if __name__ == "__main__":
    fails = run_evaluation_cycle()
    if fails:
        print(f"\n[!] Total Failures Detected: {len(fails)}")
        sys.exit(1)
    else:
        print("\n[+] ALL 10 PROFILES EVALUATED & VERIFIED SUCCESSFULLY!")
        sys.exit(0)
