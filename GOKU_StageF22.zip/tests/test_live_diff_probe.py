"""
tests/test_live_diff_probe.py - Non-GUI unit tests for scratch/live_diff_probe.py.

GOKU Stage 1 - Prompt T1.7d.
Tests diff-statistics helper on synthetic PIL images, caret blink analyzer,
and summary table / JSON generation without launching any external application.
"""
from __future__ import annotations

import json
from pathlib import Path
import pytest
from PIL import Image, ImageDraw

from scratch.live_diff_probe import (
    analyze_caret_frames,
    compute_pixel_diff,
    format_probe_summary_table,
)


def test_compute_pixel_diff_identical_images():
    """Identical images must yield exactly 0 diff pixels and 0x0 bbox."""
    img1 = Image.new("RGB", (200, 100), (255, 255, 255))
    img2 = Image.new("RGB", (200, 100), (255, 255, 255))

    diff = compute_pixel_diff(img1, img2, threshold=12)
    assert diff["count"] == 0
    assert diff["total_pixels"] == 20000
    assert diff["percent"] == 0.0
    assert diff["bbox"] == [0, 0, 0, 0]
    assert diff["bbox_w"] == 0
    assert diff["bbox_h"] == 0
    assert diff["bbox_str"] == "0x0"


def test_compute_pixel_diff_caret_simulation():
    """Simulates a 1x14 caret toggled at (20, 30)."""
    img1 = Image.new("RGB", (200, 100), (255, 255, 255))
    img2 = Image.new("RGB", (200, 100), (255, 255, 255))

    # Draw 1x14 vertical black line at x=20, y=30..43
    draw = ImageDraw.Draw(img2)
    draw.rectangle([20, 30, 20, 43], fill=(0, 0, 0))

    diff = compute_pixel_diff(img1, img2, threshold=12)
    assert diff["count"] == 14
    assert diff["total_pixels"] == 20000
    assert diff["percent"] == pytest.approx(14 / 20000 * 100.0, 1e-4)
    assert diff["bbox"] == [20, 30, 21, 44]
    assert diff["bbox_w"] == 1
    assert diff["bbox_h"] == 14
    assert diff["bbox_str"] == "1x14"


def test_compute_pixel_diff_thresholding():
    """Pixel differences with |delta| <= threshold must be ignored."""
    # Base: gray (100, 100, 100)
    img1 = Image.new("RGB", (50, 50), (100, 100, 100))

    # Delta = 10 (<= 12 threshold): must NOT count
    img_subtle = Image.new("RGB", (50, 50), (110, 110, 110))
    d_subtle = compute_pixel_diff(img1, img_subtle, threshold=12)
    assert d_subtle["count"] == 0

    # Delta = 20 (> 12 threshold): must count all 2500 pixels
    img_over = Image.new("RGB", (50, 50), (120, 120, 120))
    d_over = compute_pixel_diff(img1, img_over, threshold=12)
    assert d_over["count"] == 2500
    assert d_over["bbox"] == [0, 0, 50, 50]
    assert d_over["bbox_w"] == 50
    assert d_over["bbox_h"] == 50


def test_compute_pixel_diff_size_mismatch():
    """Mismatched image sizes must raise ValueError."""
    img1 = Image.new("RGB", (100, 100), (255, 255, 255))
    img2 = Image.new("RGB", (100, 120), (255, 255, 255))

    with pytest.raises(ValueError, match="Image sizes do not match"):
        compute_pixel_diff(img1, img2)


def test_analyze_caret_frames_alternation():
    """Verifies caret analysis detects alternation and period from frame sequence."""
    # 40 frames: 5 off (count=0), 5 on (count=14), 5 off, 5 on, etc.
    # 100 ms per frame -> 500 ms half-cycle -> 1000 ms period
    diffs = []
    for cycle in range(4):
        for _ in range(5):
            diffs.append({"count": 0, "bbox": [0, 0, 0, 0], "bbox_w": 0, "bbox_h": 0, "bbox_str": "0x0"})
        for _ in range(5):
            diffs.append({"count": 14, "bbox": [10, 20, 11, 34], "bbox_w": 1, "bbox_h": 14, "bbox_str": "1x14"})

    res = analyze_caret_frames(diffs, interval_ms=100.0)
    assert res["max_count"] == 14
    assert res["largest_bbox"] == [10, 20, 11, 34]
    assert res["largest_bbox_str"] == "1x14"
    assert res["alternates"] is True
    assert res["transitions"] >= 6
    assert res["estimated_period_ms"] == pytest.approx(1000.0, abs=50.0)


def test_analyze_caret_frames_static_no_alternation():
    """If caret never blinks, alternates must be False."""
    diffs = [{"count": 0, "bbox": [0, 0, 0, 0], "bbox_w": 0, "bbox_h": 0, "bbox_str": "0x0"} for _ in range(40)]
    res = analyze_caret_frames(diffs, interval_ms=100.0)
    assert res["max_count"] == 0
    assert res["alternates"] is False
    assert res["estimated_period_ms"] is None


def test_format_probe_summary_table():
    """Verifies summary table structure and string formatting."""
    scenarios = {
        "P1_caret": {
            "count_min": 0, "count_med": 0.0, "count_max": 14,
            "bbox_min_str": "0x0", "bbox_max_str": "1x14",
            "focused": True,
        },
        "P2_single_X": {
            "count_min": 35, "count_med": 42.0, "count_max": 50,
            "bbox_min_str": "7x10", "bbox_max_str": "8x12",
            "focused": True,
        },
        "P5_occluder_without": {
            "count_min": 0, "count_med": 0.0, "count_max": 0,
            "bbox_min_str": "0x0", "bbox_max_str": "0x0",
            "focused": False,
        },
    }

    table_text = format_probe_summary_table(scenarios, global_focused=True)
    assert "GOKU LIVE DIFF PROBE SUMMARY TABLE" in table_text
    assert "P1_caret" in table_text
    assert "0 / 0.0 / 14" in table_text
    assert "1x14" in table_text
    assert "P2_single_X" in table_text
    assert "35 / 42.0 / 50" in table_text
    assert "P5_occluder_without" in table_text
    assert "no" in table_text  # focused=False for P5_occluder_without


def test_json_serialization(tmp_path: Path):
    """Verifies probe result dictionary can be serialized to JSON and read back."""
    data = {
        "tag": "probe_test",
        "focused": True,
        "scenarios": {
            "P1_caret": {"count_min": 0, "count_max": 14},
        },
    }
    json_path = tmp_path / "probe_test.json"
    json_path.write_text(json.dumps(data, indent=2), encoding="utf-8")

    loaded = json.loads(json_path.read_text(encoding="utf-8"))
    assert loaded["tag"] == "probe_test"
    assert loaded["focused"] is True
    assert loaded["scenarios"]["P1_caret"]["count_max"] == 14
