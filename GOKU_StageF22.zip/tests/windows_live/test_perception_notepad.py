"""
tests/windows_live/test_perception_notepad.py - Live Windows Perception Suite on Real Notepad.
Launches real notepad.exe, transitions through 4 distinct states:
1. Notepad empty
2. Text typed into Notepad
3. Save As dialog open
4. Confirm Save As dialog open
Measures USS memory delta against the 8 MB budget.
"""
from __future__ import annotations

import ctypes
import json
import os
from pathlib import Path
import subprocess
import sys
import time

import psutil
import pytest

from perception.controls import inspect_controls
from perception.dialogs import find_dialog_window
from perception.snapshot import snapshot
from perception.windows import list_top_windows

# Win32 Constants
WM_COMMAND = 0x0111
WM_SETTEXT = 0x000C
BM_CLICK = 0x00F5
ID_FILE_SAVEAS = 3


def test_real_notepad_perception_four_snapshots():
    """
    Executes live Notepad scenario, verifies 4 real snapshots,
    and enforces USS memory delta < 8 MB budget.
    """
    if sys.platform != "win32":
        pytest.skip("Windows-specific live UI perception test")

    current_proc = psutil.Process(os.getpid())
    uss_start = current_proc.memory_full_info().uss

    # Collision file to force 'Confirm Save As'
    scratch_dir = Path("scratch")
    scratch_dir.mkdir(parents=True, exist_ok=True)
    collision_file = (scratch_dir / "test_perception_confirm.txt").resolve()
    collision_file.write_text("pre-existing content for overwrite confirmation", encoding="utf-8")

    proc = subprocess.Popen(["notepad.exe"])
    notepad_hwnd = 0

    try:
        # Wait up to 5 seconds for visible Notepad window
        target_pid = proc.pid
        t_deadline = time.time() + 5.0
        while time.time() < t_deadline:
            wins = [
                w for w in list_top_windows()
                if w["visible"] and (w["class_name"] == "Notepad" or "notepad" in w["title"].lower())
            ]
            if wins:
                # Pick the notepad window
                target_win = next((w for w in wins if w["pid"] == proc.pid), wins[0])
                notepad_hwnd = target_win["hwnd"]
                target_pid = target_win["pid"]
                break
            time.sleep(0.2)

        assert notepad_hwnd != 0, f"Could not find visible Notepad window (target PID {proc.pid})"

        # Bring Notepad to foreground
        ctypes.windll.user32.SetForegroundWindow(notepad_hwnd)
        time.sleep(0.3)

        # ======================================================================
        # SNAPSHOT 1: Notepad empty
        # ======================================================================
        snap1 = snapshot(task_ctx={"target_pid": target_pid})
        assert "Notepad" in snap1["fg"]["class"] or "Notepad" in snap1["fg"]["title"]
        assert snap1["dialog"] is None
        json1 = json.dumps(snap1, indent=2)
        assert len(json1.encode("utf-8")) <= 2048

        # ======================================================================
        # SNAPSHOT 2: Text typed
        # ======================================================================
        typed_text = "Task P3 Notepad Perception Live Text Active"
        # Set text via UIA ValuePattern or SendMessage
        import comtypes.client
        uia_mod = comtypes.client.GetModule("UIAutomationCore.dll")
        uia = comtypes.client.CreateObject(uia_mod.CUIAutomation, interface=uia_mod.IUIAutomation)
        root = uia.ElementFromHandle(notepad_hwnd)
        edit_elem = root.FindFirst(uia_mod.TreeScope_Descendants, uia.CreatePropertyCondition(30003, 50004))
        if edit_elem:
            val_pat = edit_elem.GetCurrentPattern(10002)
            if val_pat:
                p_val = val_pat.QueryInterface(uia_mod.IUIAutomationValuePattern)
                p_val.SetValue(typed_text)
        time.sleep(0.3)

        snap2 = snapshot(task_ctx={"target_pid": target_pid})
        assert snap2["editor"] is not None
        assert snap2["editor"]["len"] > 0
        assert "Task P3" in snap2["editor"]["head"]
        json2 = json.dumps(snap2, indent=2)
        assert len(json2.encode("utf-8")) <= 2048

        # ======================================================================
        # SNAPSHOT 3: Save As dialog open
        # ======================================================================
        # Trigger Save As via non-blocking PostMessage
        ctypes.windll.user32.PostMessageW(notepad_hwnd, WM_COMMAND, ID_FILE_SAVEAS, 0)

        save_dlg_hwnd = 0
        t_deadline = time.time() + 3.0
        while time.time() < t_deadline:
            dlg = find_dialog_window(target_pid=target_pid, known_titles=["save as"])
            if dlg:
                save_dlg_hwnd = dlg["hwnd"]
                break
            time.sleep(0.1)

        assert save_dlg_hwnd != 0, "Save As dialog failed to appear"

        snap3 = snapshot(task_ctx={"target_pid": target_pid})
        assert snap3["dialog"] is not None
        assert "save as" in snap3["dialog"]["title"].lower()
        assert len(snap3["dialog"]["buttons"]) > 0
        json3 = json.dumps(snap3, indent=2)
        assert len(json3.encode("utf-8")) <= 2048

        # ======================================================================
        # SNAPSHOT 4: Confirm Save As dialog open
        # ======================================================================
        # Enter collision filename into Save As dialog edit box
        ctrls = inspect_controls(save_dlg_hwnd)
        edit_ctrl = next((c for c in ctrls if c["class_name"].lower() in ("edit", "combobox")), None)
        assert edit_ctrl is not None, "Could not find filename input control in Save As dialog"
        ctypes.windll.user32.SendMessageW(edit_ctrl["hwnd"], WM_SETTEXT, 0, str(collision_file))
        time.sleep(0.3)

        save_btn = next((c for c in ctrls if c["control_id"] == 1 and c["class_name"].lower() == "button"), None)
        assert save_btn is not None, "Could not find Save button in Save As dialog"
        ctypes.windll.user32.PostMessageW(save_btn["hwnd"], BM_CLICK, 0, 0)

        confirm_dlg_hwnd = 0
        t_deadline = time.time() + 3.0
        while time.time() < t_deadline:
            cdlg = find_dialog_window(target_pid=target_pid, known_titles=["confirm save as", "confirm"])
            if cdlg:
                confirm_dlg_hwnd = cdlg["hwnd"]
                break
            time.sleep(0.2)

        assert confirm_dlg_hwnd != 0, "Confirm Save As dialog failed to appear"
        time.sleep(0.2)

        snap4 = snapshot(task_ctx={"target_pid": target_pid})
        assert snap4["dialog"] is not None
        assert "confirm" in snap4["dialog"]["title"].lower()
        assert "already exists" in snap4["dialog"]["body"].lower()
        json4 = json.dumps(snap4, indent=2)
        assert len(json4.encode("utf-8")) <= 2048

        # Save the four real snapshots for artifact recording
        snapshots_payload = {
            "snapshot_1_empty": snap1,
            "snapshot_2_typed": snap2,
            "snapshot_3_save_as": snap3,
            "snapshot_4_confirm_save_as": snap4,
        }
        (scratch_dir / "perception_four_snapshots.json").write_text(
            json.dumps(snapshots_payload, indent=2), encoding="utf-8"
        )

    finally:
        # Guaranteed cleanup of Notepad and all child windows
        try:
            if target_pid:
                subprocess.run(["taskkill", "/F", "/PID", str(target_pid)], capture_output=True)
            proc.terminate()
            proc.wait(timeout=1.0)
        except Exception:
            try:
                proc.kill()
            except Exception:
                pass

        # Cleanup test collision file
        if collision_file.exists():
            try:
                collision_file.unlink()
            except Exception:
                pass

    # ======================================================================
    # USS Memory Delta Verification (< 8 MB budget)
    # ======================================================================
    uss_end = current_proc.memory_full_info().uss
    delta_mb = (uss_end - uss_start) / (1024 * 1024)

    print(f"\n[PERCEPTION_BUDGET] Start USS: {uss_start / (1024*1024):.2f} MB")
    print(f"[PERCEPTION_BUDGET] End USS:   {uss_end / (1024*1024):.2f} MB")
    print(f"[PERCEPTION_BUDGET] Delta USS: {delta_mb:.2f} MB (Budget < 8.0 MB)")

    assert delta_mb < 8.0, f"Perception USS delta exceeded 8 MB budget: {delta_mb:.2f} MB"
