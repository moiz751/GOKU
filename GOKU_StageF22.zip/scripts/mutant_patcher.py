"""
scripts/mutant_patcher.py - Active In-Memory Mutation Patching Utility
Invoked by tests/conftest.py when GOKU_MUTATION_ACTIVE == '1'.
Inverts the core logic of the targeted function to prove tests fail.
"""
from __future__ import annotations

import functools
import importlib
import os
from pathlib import Path
from typing import Any


def apply_active_mutation():
    """Applies the in-memory mutation requested via GOKU_MUTANT_TARGET."""
    if os.environ.get("GOKU_MUTATION_ACTIVE") != "1":
        return

    target = os.environ.get("GOKU_MUTANT_TARGET", "")
    m_type = os.environ.get("GOKU_MUTATION_TYPE", "")
    if not target:
        return

    # Handling for class methods like ConditionalPredicate.evaluate
    parts = target.split(".")
    if len(parts) >= 3 and parts[-2][0].isupper():
        cls_name = parts[-2]
        func_name = parts[-1]
        mod_name = ".".join(parts[:-2])
        try:
            mod = importlib.import_module(mod_name)
            cls_obj = getattr(mod, cls_name)
            orig_fn = getattr(cls_obj, func_name)

            @functools.wraps(orig_fn)
            def mutated_method(self, *args, **kwargs):
                return not orig_fn(self, *args, **kwargs)

            setattr(cls_obj, func_name, mutated_method)
        except Exception as e:
            print(f"[MUTANT_PATCHER_ERROR] {e}")
        return

    # Standard module function
    mod_name = ".".join(parts[:-1])
    func_name = parts[-1]
    try:
        mod = importlib.import_module(mod_name)
    except Exception:
        return

    orig_fn = getattr(mod, func_name, None)
    if orig_fn is None:
        return

    if m_type == "invert_boolean":
        @functools.wraps(orig_fn)
        def mutated_bool(*args, **kwargs):
            return not bool(orig_fn(*args, **kwargs))
        setattr(mod, func_name, mutated_bool)

    elif m_type == "invert_process_liveness":
        @functools.wraps(orig_fn)
        def mutated_liveness(*args, **kwargs):
            alive, err = orig_fn(*args, **kwargs)
            return (not alive, "MUTATION_INVERTED" if alive else None)
        setattr(mod, func_name, mutated_liveness)

    elif m_type == "invert_dict_verified":
        @functools.wraps(orig_fn)
        def mutated_dict(*args, **kwargs):
            res = orig_fn(*args, **kwargs)
            if isinstance(res, dict):
                res["verified"] = not res.get("verified", False)
            return res
        setattr(mod, func_name, mutated_dict)

    elif m_type == "invert_observation":
        from executor.truth_oracle import Observation
        @functools.wraps(orig_fn)
        def mutated_obs(*args, **kwargs):
            obs = orig_fn(*args, **kwargs)
            status = "FAILED" if getattr(obs, "is_verified", False) else "VERIFIED"
            return Observation(status=status, evidence=getattr(obs, "evidence", {}), reason="MUTATED_FAIL")
        setattr(mod, func_name, mutated_obs)

    elif m_type == "invert_firewall_tuple":
        @functools.wraps(orig_fn)
        def mutated_tuple(*args, **kwargs):
            allowed, reason = orig_fn(*args, **kwargs)
            return (not allowed, "MUTATION_INVERTED" if allowed else None)
        setattr(mod, func_name, mutated_tuple)

    elif m_type == "invert_dialog_policy":
        @functools.wraps(orig_fn)
        def mutated_diag(*args, **kwargs):
            res = orig_fn(*args, **kwargs)
            if isinstance(res, dict):
                res["status"] = "STOPPED" if res.get("status") == "PROCEED" else "PROCEED"
            return res
        setattr(mod, func_name, mutated_diag)

    elif m_type == "invert_numbered_filename":
        @functools.wraps(orig_fn)
        def mutated_num(file_path, *args, **kwargs):
            return Path(file_path)
        setattr(mod, func_name, mutated_num)

    elif m_type == "invert_unique_path":
        @functools.wraps(orig_fn)
        def mutated_uniq(target_path, *args, **kwargs):
            return Path(target_path)
        setattr(mod, func_name, mutated_uniq)
