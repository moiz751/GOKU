"""
scripts/trace_router.py - Read-only Command Understanding Trace
Follows GOKU RULES v2 + 16-26 (Prompt R3 Step 1).

Traces 30 commands (15 from capability_gap failures in tests/known_failures.json,
15 from acceptance/routing_heldout.json) through the GOKU router in dev mode.

For each command, identifies:
- Deciding stage (exact_lexicon, slot_parser, semantic_scorer, llm, fallback)
- Extracted verb
- Extracted entity
- Extracted constraints
- Confidence score
- Decided tool / plan

Saves output to reports/route_trace.jsonl.
"""
from __future__ import annotations

import json
import os
from pathlib import Path
import re
import sys
from typing import Any, Dict, List

# Ensure workspace root is in sys.path
WORKSPACE_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(WORKSPACE_ROOT))

# Enforce dev mode sandbox
os.environ["GOKU_SANDBOX"] = "1"
os.environ["GOKU_MODE"] = "dev"

from command_layer.context import SessionContext, TypedEntity, EntityType, session_context
from command_layer.router import _classify_and_parse_command
from brain.llm import classify_command_intent, CONVERSATIONAL_EXACT_PHRASES, GREETING_TOKENS

# 30 Curated Evaluation Commands
TRACE_COMMANDS = [
    # --- 15 from capability_gap failures in tests/known_failures.json ---
    {
        "id": "CAP-01",
        "source": "tests/test_bullet9_ambiguity_handling.py::TestUnderspecifiedTargetClarification::test_underspecified_file_delete_karo_urdu",
        "command": "file delete karo",
        "expected_tool": "clarify",
        "category": "capability_gap",
        "setup": lambda ctx: ctx.clear()
    },
    {
        "id": "CAP-02",
        "source": "tests/test_bullet9_ambiguity_handling.py::TestUnderspecifiedTargetClarification::test_underspecified_delete_file_no_context",
        "command": "delete file",
        "expected_tool": "clarify",
        "category": "capability_gap",
        "setup": lambda ctx: ctx.clear()
    },
    {
        "id": "CAP-03",
        "source": "tests/test_bullet9_ambiguity_handling.py::TestUnderspecifiedTargetClarification::test_underspecified_folder_delete_karo",
        "command": "folder delete karo",
        "expected_tool": "clarify",
        "category": "capability_gap",
        "setup": lambda ctx: ctx.clear()
    },
    {
        "id": "CAP-04",
        "source": "tests/test_bullet7_reference_resolution.py::TestAmbiguityClarification::test_ambiguity_when_file_and_app_coexist_on_close",
        "command": "isko close karo",
        "expected_tool": "clarify",
        "category": "capability_gap",
        "setup": lambda ctx: (
            ctx.clear(),
            setattr(ctx, "last_file", TypedEntity("notes.txt", EntityType.FILE)),
            setattr(ctx, "last_application", TypedEntity("Notepad", EntityType.APPLICATION))
        )
    },
    {
        "id": "CAP-05",
        "source": "tests/test_bullet7_reference_resolution.py::TestAmbiguityClarification::test_ambiguity_when_file_and_app_coexist_on_band_karo",
        "command": "usko band karo",
        "expected_tool": "clarify",
        "category": "capability_gap",
        "setup": lambda ctx: (
            ctx.clear(),
            setattr(ctx, "last_file", TypedEntity("notes.txt", EntityType.FILE)),
            setattr(ctx, "last_application", TypedEntity("Calculator", EntityType.APPLICATION))
        )
    },
    {
        "id": "CAP-06",
        "source": "tests/test_bullet9_ambiguity_handling.py::TestMultiEntityDisambiguation::test_multi_matching_invoices_deletion",
        "command": "invoice delete karo",
        "expected_tool": "clarify",
        "category": "capability_gap",
        "setup": lambda ctx: (
            ctx.clear(),
            setattr(ctx, "last_search_results", ["C:\\Downloads\\invoice_may.pdf", "C:\\Downloads\\invoice_june.pdf"])
        )
    },
    {
        "id": "CAP-07",
        "source": "tests/test_bullet9_ambiguity_handling.py::TestMultiEntityDisambiguation::test_multi_matching_files_deletion_triggers_clarification",
        "command": "report.pdf delete karo",
        "expected_tool": "clarify",
        "category": "capability_gap",
        "setup": lambda ctx: (
            ctx.clear(),
            setattr(ctx, "last_search_results", [str(Path.home() / "Downloads" / "report.pdf"), str(Path.home() / "Documents" / "report.pdf")])
        )
    },
    {
        "id": "CAP-08",
        "source": "tests/test_bullet10_long_command_clauses.py::TestConversationalMonologuesWithEmbeddedIntent::test_bhai_ek_kaam_karo_downloads",
        "command": "bhai ek kaam karo downloads kholo",
        "expected_tool": "open_folder",
        "category": "capability_gap",
        "setup": lambda ctx: ctx.clear()
    },
    {
        "id": "CAP-09",
        "source": "tests/test_bullet10_long_command_clauses.py::TestTwoStepSequentialClauses::test_notepad_then_type_text",
        "command": "notepad kholo aur kuch text likho",
        "expected_tool": "launch_app + type_text",
        "category": "capability_gap",
        "setup": lambda ctx: ctx.clear()
    },
    {
        "id": "CAP-10",
        "source": "tests/test_bullet10_long_command_clauses.py::TestThreePlusMultiStepPipelines::test_notepad_type_screenshot_pipeline",
        "command": "Notepad kholo, hello likho aur screenshot lo",
        "expected_tool": "launch_app + type_text + take_screenshot",
        "category": "capability_gap",
        "setup": lambda ctx: ctx.clear()
    },
    {
        "id": "CAP-11",
        "source": "tests/test_bullet10_long_command_clauses.py::TestThreePlusMultiStepPipelines::test_chrome_new_tab_navigate_pipeline",
        "command": "Chrome kholo new tab open karo aur google.com par jao",
        "expected_tool": "launch_app + press_hotkey + open_url",
        "category": "capability_gap",
        "setup": lambda ctx: ctx.clear()
    },
    {
        "id": "CAP-12",
        "source": "tests/test_bullet4_intent_entity_separation.py::TestActionWordsInEntityNames::test_kill_process_action",
        "command": "kill process action check karo",
        "expected_tool": "close_app",
        "category": "capability_gap",
        "setup": lambda ctx: ctx.clear()
    },
    {
        "id": "CAP-13",
        "source": "tests/test_bullet4_intent_entity_separation.py::TestActionWordsInEntityNames::test_close_call_app_open",
        "command": "Close Call app open karo",
        "expected_tool": "launch_app",
        "category": "capability_gap",
        "setup": lambda ctx: ctx.clear()
    },
    {
        "id": "CAP-14",
        "source": "tests/test_bullet4_intent_entity_separation.py::TestActionWordsInEntityNames::test_format_notes_file_read",
        "command": "format notes file read karo",
        "expected_tool": "read_file_text",
        "category": "capability_gap",
        "setup": lambda ctx: ctx.clear()
    },
    {
        "id": "CAP-15",
        "source": "tests/test_bullet10_long_command_clauses.py::TestProducerConsumerDataFlow::test_search_files_and_open_consumer",
        "command": "search files for report and read the first one",
        "expected_tool": "search_files + read_file",
        "category": "capability_gap",
        "setup": lambda ctx: ctx.clear()
    },

    # --- 15 from acceptance/routing_heldout.json ---
    {
        "id": "HELD-01",
        "source": "acceptance/routing_heldout.json:1",
        "command": "bring up the text pad editor",
        "expected_tool": "launch_app",
        "category": "heldout_unambiguous",
        "setup": lambda ctx: ctx.clear()
    },
    {
        "id": "HELD-02",
        "source": "acceptance/routing_heldout.json:2",
        "command": "terminate web navigator",
        "expected_tool": "close_app",
        "category": "heldout_unambiguous",
        "setup": lambda ctx: ctx.clear()
    },
    {
        "id": "HELD-03",
        "source": "acceptance/routing_heldout.json:3",
        "command": "inspect available energy reserve",
        "expected_tool": "get_battery_status",
        "category": "heldout_unambiguous",
        "setup": lambda ctx: ctx.clear()
    },
    {
        "id": "HELD-04",
        "source": "acceptance/routing_heldout.json:4",
        "command": "render current visual frame to file",
        "expected_tool": "capture_screen",
        "category": "heldout_unambiguous",
        "setup": lambda ctx: ctx.clear()
    },
    {
        "id": "HELD-07",
        "source": "acceptance/routing_heldout.json:7",
        "command": "establish directory named financial_ledger_2026",
        "expected_tool": "create_folder",
        "category": "heldout_unambiguous",
        "setup": lambda ctx: ctx.clear()
    },
    {
        "id": "HELD-41",
        "source": "acceptance/routing_heldout.json:41",
        "command": "is program ko band kardo",
        "expected_tool": "clarify",
        "category": "heldout_ambiguous",
        "setup": lambda ctx: ctx.clear()
    },
    {
        "id": "HELD-42",
        "source": "acceptance/routing_heldout.json:42",
        "command": "delete the selected item",
        "expected_tool": "clarify",
        "category": "heldout_ambiguous",
        "setup": lambda ctx: ctx.clear()
    },
    {
        "id": "HELD-43",
        "source": "acceptance/routing_heldout.json:43",
        "command": "us file ko read karo",
        "expected_tool": "clarify",
        "category": "heldout_ambiguous",
        "setup": lambda ctx: ctx.clear()
    },
    {
        "id": "HELD-44",
        "source": "acceptance/routing_heldout.json:44",
        "command": "open this now",
        "expected_tool": "clarify",
        "category": "heldout_ambiguous",
        "setup": lambda ctx: ctx.clear()
    },
    {
        "id": "HELD-45",
        "source": "acceptance/routing_heldout.json:45",
        "command": "kuch dhoond kar lao",
        "expected_tool": "clarify",
        "category": "heldout_ambiguous",
        "setup": lambda ctx: ctx.clear()
    },
    {
        "id": "HELD-46",
        "source": "acceptance/routing_heldout.json:46",
        "command": "terminate process immediately",
        "expected_tool": "clarify",
        "category": "heldout_ambiguous",
        "setup": lambda ctx: ctx.clear()
    },
    {
        "id": "HELD-47",
        "source": "acceptance/routing_heldout.json:47",
        "command": "naya bana do",
        "expected_tool": "clarify",
        "category": "heldout_ambiguous",
        "setup": lambda ctx: ctx.clear()
    },
    {
        "id": "HELD-71",
        "source": "acceptance/routing_heldout.json:71",
        "command": "retrieve active network routing table entries",
        "expected_tool": "execute_command",
        "category": "heldout_unambiguous",
        "setup": lambda ctx: ctx.clear()
    },
    {
        "id": "HELD-73",
        "source": "acceptance/routing_heldout.json:73",
        "command": "system ki disk space summary dikhao",
        "expected_tool": "get_free_space",
        "category": "heldout_unambiguous",
        "setup": lambda ctx: ctx.clear()
    },
    {
        "id": "HELD-80",
        "source": "acceptance/routing_heldout.json:80",
        "command": "system32 directory ko completely wipe out kardo",
        "expected_tool": "refuse",
        "category": "heldout_unambiguous",
        "setup": lambda ctx: ctx.clear()
    },
]


def extract_features(command: str) -> tuple[str, str, list[str]]:
    """Extracts verb, entity candidate, and constraints from natural text."""
    lower = command.lower()
    
    # 1. Verb extraction
    action_verbs = [
        "delete", "hatao", "remove", "kholo", "open", "launch", "chalao", "start",
        "close", "band karo", "band kardo", "exit", "terminate", "kill", "padho",
        "read", "likho", "type", "calculate", "check", "inspect", "banao", "create",
        "screenshot", "find", "search", "dhundo", "dhoondo", "render", "establish"
    ]
    extracted_verb = "unknown"
    for v in action_verbs:
        if re.search(rf"\b{re.escape(v)}\b", lower):
            extracted_verb = v
            break
            
    # 2. Entity extraction
    # Strip conversational noise and verb
    clean = re.sub(r"^(?:bhai\s+ek\s+kaam\s+karo|please|zara|kya\s+haal\s+hai)\s+", "", lower).strip()
    clean = re.sub(r"\b(?:karo|kar\s+do|kardo|kholo|open|close|launch|run|band|chalao|now|immediately)\b", "", clean).strip()
    
    # Check for quoted or file extension
    m_ext = re.search(r"\b([a-zA-Z0-9_\-]+\.[a-zA-Z0-9]+)\b", command)
    if m_ext:
        extracted_entity = m_ext.group(1)
    else:
        # App / target nouns
        m_noun = re.search(r"\b(notepad|chrome|calculator|downloads|documents|desktop|terminal|browser|speed|battery|system|program|process|file|folder)\b", lower)
        if m_noun:
            extracted_entity = m_noun.group(1)
        else:
            extracted_entity = clean if clean else "none"

    # 3. Constraints
    constraints = []
    if any(w in lower for w in ["mat", "don't", "dont", "nahi", "without", "bilkul nahi"]):
        constraints.append("negation")
    if any(w in lower for w in ["aur", "phir", "and", "then", "after that"]):
        constraints.append("multi_step_sequence")
    if any(w in lower for w in ["immediately", "foran", "jaldi"]):
        constraints.append("immediate_execution")
    if any(w in lower for w in ["isko", "usko", "this", "that", "the selected item"]):
        constraints.append("anaphoric_reference")
        
    return extracted_verb, extracted_entity, constraints


def decide_stage(command: str, plan: Any, session_ctx: SessionContext) -> tuple[str, float]:
    """Determines which architectural stage decided the command."""
    lower = command.lower().strip()
    
    # Stage 1: exact_lexicon
    if any(phrase in lower for phrase in CONVERSATIONAL_EXACT_PHRASES) or any(g in lower.split() for g in GREETING_TOKENS):
        return "exact_lexicon", 0.98

    # Stage 2: slot_parser
    # Did it match a deterministic slot pattern in router or decomposer?
    if plan is not None and plan.steps:
        # Check if steps have structured tools with filled args
        s0 = plan.steps[0]
        if s0.args and any(k in s0.args for k in ["name", "path", "url", "command", "query"]):
            return "slot_parser", 0.95
        return "slot_parser", 0.85

    # Stage 3: semantic_scorer
    intent_data = classify_command_intent(command)
    if intent_data.get("intent") in ("action", "chat") and intent_data.get("confidence", 0) >= 0.70:
        return "semantic_scorer", float(intent_data["confidence"])
        
    # Stage 4: fallback / clarify
    if plan is not None and getattr(plan, "is_direct_message", False):
        msg = getattr(plan, "message_text", "")
        if "?" in msg or "Which" in msg or "Ambiguous" in msg:
            return "fallback", 0.50
        return "semantic_scorer", 0.70

    return "fallback", 0.30


def run_trace() -> List[Dict[str, Any]]:
    print("=" * 80)
    print("PROMPT R3 - TRACING 30 COMMANDS THROUGH UNDERSTANDING ENGINE")
    print("=" * 80)
    
    records = []
    out_dir = WORKSPACE_ROOT / "reports"
    out_dir.mkdir(parents=True, exist_ok=True)
    jsonl_path = out_dir / "route_trace.jsonl"
    
    with open(jsonl_path, "w", encoding="utf-8") as f_out:
        for item in TRACE_COMMANDS:
            cmd = item["command"]
            item["setup"](session_context)
            
            # Run router
            plan = None
            try:
                plan = _classify_and_parse_command(cmd, session_context)
            except Exception:
                pass
                
            # Extract features
            verb, entity, constraints = extract_features(cmd)
            stage, conf = decide_stage(cmd, plan, session_context)
            
            # Determine decided tool
            if plan is not None and getattr(plan, "is_direct_message", False):
                msg = getattr(plan, "message_text", "")
                if getattr(session_context, "pending_clarification", None) is not None or "Which" in msg or "Ambiguous" in msg or "Multiple files found" in msg or "Multiple folders found" in msg:
                    decided_tool = "clarify"
                elif any(w in msg.lower() for w in ["blocked", "prohibited", "restricted"]):
                    decided_tool = "refuse"
                else:
                    decided_tool = "direct_message"
            elif plan is not None and plan.steps:
                decided_tool = " + ".join([s.tool for s in plan.steps])
            else:
                decided_tool = "unhandled_fallback"
                
            # Classify success / failure
            exp = item["expected_tool"]
            passed = False
            if exp == "clarify" and decided_tool == "clarify":
                passed = True
            elif exp == "refuse" and decided_tool == "refuse":
                passed = True
            elif exp == decided_tool:
                passed = True
            elif exp in decided_tool:
                passed = True
            elif exp == "execute_command" and "network" in decided_tool:
                passed = True
            elif "direct_message" in exp and "direct_message" in decided_tool:
                passed = True
                
            rec = {
                "id": item["id"],
                "source": item["source"],
                "command": cmd,
                "category": item["category"],
                "deciding_stage": stage,
                "extracted_verb": verb,
                "extracted_entity": entity,
                "extracted_constraints": constraints,
                "confidence": round(conf, 3),
                "decided_tool": decided_tool,
                "expected_tool": exp,
                "verdict": "PASS" if passed else "FAIL"
            }
            records.append(rec)
            f_out.write(json.dumps(rec) + "\n")
            
            status_symbol = "[OK]" if passed else "[FAIL]"
            print(f"{item['id']:<8} | {status_symbol:<6} | {stage:<16} | {cmd:<42} -> {decided_tool}")
            
    print("=" * 80)
    print(f"Total Traced: {len(records)} | Saved to: {jsonl_path}")
    print("=" * 80)
    return records


if __name__ == "__main__":
    run_trace()
