"""Stages F16+F18: build data/engine_repos.json from any number of repository lists (text files with GitHub URLs; '## Heading' lines become categories).
Usage: python scripts/engine_inventory.py <list1.txt> [<list2.txt> ...]  (offline: only reads the files, never contacts GitHub)
Handles the '?utm_source' tracking suffix, a stray space after 'github.com/', old/mirror owners (brain/engines/repo_catalog.ALIASES merged into ONE entry) and
flags suspicious URLs. Decisions come from brain/engines/repo_catalog.classify - one decision per repository. Licences/URL liveness are NOT verified."""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from brain.engines.repo_catalog import ALIASES, SUSPECT_URLS, classify  # noqa: E402

_URL = re.compile(r"https://github\.com/\s*([\w.-]+)/([\w.-]+)")


def build(files: list) -> dict:
    seen: dict = {}
    total = 0
    for f in files:
        sec = ""
        for ln in Path(f).read_text(encoding="utf-8", errors="replace").splitlines():
            m = re.match(r"#{1,3}\s*\**\s*(?:\d+\.\s*)?(.+?)(?:\s*[—-]\s*\d+ repositories)?\**\s*$", ln)
            if m:
                sec = m.group(1).strip()
            for owner, repo in _URL.findall(ln):
                total += 1
                repo = re.sub(r"\.git$", "", repo)
                key0 = f"{owner}/{repo}".lower()
                key = ALIASES.get(key0, key0)
                row = seen.setdefault(key, {"url": f"https://github.com/{owner}/{repo}", "slug": repo, "canonical": key, "listed_as": [], "categories": []})
                if f"{owner}/{repo}" not in row["listed_as"]:
                    row["listed_as"].append(f"{owner}/{repo}")
                if sec and sec not in row["categories"]:
                    row["categories"].append(sec)
    repos = []
    for key, row in seen.items():
        cls, why, engine, role = classify(row["slug"])
        suspect = next((SUSPECT_URLS[k.lower()] for k in row["listed_as"] if k.lower() in SUSPECT_URLS), None)
        repos.append({**row, "decision": cls, "role": role, "engine": engine, "why": why, "licence": "UNVERIFIED (not fetched)", "url_checked": False, **({"url_suspect": suspect} if suspect else {})})
    repos.sort(key=lambda r: r["slug"].lower())
    by: dict = {}
    for r in repos:
        by[r["decision"]] = by.get(r["decision"], 0) + 1
    return {"url_occurrences": total, "unique_repos": len(repos), "duplicates_merged": total - len(repos), "by_decision": by,
            "suspect_urls": sum(1 for r in repos if r.get("url_suspect")), "repos": repos}


if __name__ == "__main__":
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    out = build(sys.argv[1:])
    (ROOT / "data").mkdir(exist_ok=True)
    (ROOT / "data" / "engine_repos.json").write_text(json.dumps(out, indent=1, ensure_ascii=False), encoding="utf-8")
    print({k: out[k] for k in ("url_occurrences", "unique_repos", "duplicates_merged", "by_decision", "suspect_urls")})
