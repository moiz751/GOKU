import os
import ast
import sys

found = []
for root, dirs, files in os.walk("tools"):
    for f in sorted(files):
        if f.endswith(".py"):
            path = os.path.join(root, f)
            with open(path, "r", encoding="utf-8", errors="ignore") as fp:
                tree = ast.parse(fp.read(), filename=path)
            for node in ast.walk(tree):
                # Check dict key 'verified' with value True
                if isinstance(node, ast.Dict):
                    for k, v in zip(node.keys, node.values):
                        if isinstance(k, ast.Constant) and k.value == "verified":
                            if isinstance(v, ast.Constant) and v.value is True:
                                found.append((path, node.lineno, "Dict 'verified': True"))
                # Check keyword argument verified=True
                elif isinstance(node, ast.keyword) and node.arg == "verified":
                    if isinstance(node.value, ast.Constant) and node.value is True:
                        found.append((path, node.lineno, "Keyword verified=True"))

if found:
    print(f"FAILED: Found {len(found)} verified=True literals in tools/:")
    for p, line, desc in found:
        print(f"  {p}:{line} - {desc}")
    sys.exit(1)
else:
    print("PASSED: Zero verified=True literals in tools/.")
    sys.exit(0)
