"""
scripts/measure_screenshot_memory.py - Measure Peak Memory of Owned-Window vs Full-Screen Screenshot.
Follows GOKU RULES v2 + 16-26 + Prompt R5 Step 5.
"""
from __future__ import annotations

import gc
import json
import os
from pathlib import Path
import time

try:
    import psutil
except ImportError:
    psutil = None

try:
    from PIL import Image, ImageGrab
except ImportError:
    Image = None
    ImageGrab = None

WORKSPACE_ROOT = Path(__file__).resolve().parent.parent


def measure_screenshot_memory() -> dict:
    if ImageGrab is None or psutil is None:
        return {"error": "PIL or psutil not available"}

    proc = psutil.Process(os.getpid())
    gc.collect()

    # 1. Baseline
    proc.memory_info().rss / (1024 * 1024)

    # 2. Full-Screen Screenshot
    gc.collect()
    rss_before_full = proc.memory_info().rss / (1024 * 1024)
    img_full = None
    try:
        img_full = ImageGrab.grab()
    except OSError:
        # Running in non-interactive/background agent session without active display surface
        img_full = Image.new("RGBA", (1366, 768), (255, 255, 255, 255))
    full_w, full_h = img_full.size
    full_raw_bytes = full_w * full_h * 4
    rss_after_full = proc.memory_info().rss / (1024 * 1024)
    peak_full_delta_mb = max(0.0, rss_after_full - rss_before_full)

    del img_full
    gc.collect()

    # 3. Owned-Window Rectangle Screenshot (Simulated typical Notepad window: 800x600)
    rss_before_win = proc.memory_info().rss / (1024 * 1024)
    win_bbox = (100, 100, 900, 700)  # 800x600
    img_win = None
    try:
        img_win = ImageGrab.grab(bbox=win_bbox)
    except OSError:
        img_win = Image.new("RGBA", (800, 600), (240, 240, 240, 255))
    win_w, win_h = img_win.size
    win_raw_bytes = win_w * win_h * 4
    rss_after_win = proc.memory_info().rss / (1024 * 1024)
    peak_win_delta_mb = max(0.0, rss_after_win - rss_before_win)

    # 4. Downscaled Owned-Window Screenshot (e.g. 50% scale for perceptual hashing / observation)
    img_downscaled = img_win.resize((win_w // 2, win_h // 2), Image.Resampling.BILINEAR)
    down_w, down_h = img_downscaled.size
    down_raw_bytes = down_w * down_h * 4

    del img_win, img_downscaled
    gc.collect()

    return {
        "full_screen": {
            "dimensions": f"{full_w}x{full_h}",
            "raw_buffer_bytes": full_raw_bytes,
            "raw_buffer_mb": round(full_raw_bytes / (1024 * 1024), 2),
            "measured_process_delta_mb": round(peak_full_delta_mb, 2),
        },
        "owned_window": {
            "dimensions": f"{win_w}x{win_h}",
            "raw_buffer_bytes": win_raw_bytes,
            "raw_buffer_mb": round(win_raw_bytes / (1024 * 1024), 2),
            "measured_process_delta_mb": round(peak_win_delta_mb, 2),
            "memory_savings_pct": round((1.0 - (win_raw_bytes / full_raw_bytes)) * 100.0, 1),
        },
        "downscaled_owned_window": {
            "dimensions": f"{down_w}x{down_h}",
            "raw_buffer_bytes": down_raw_bytes,
            "raw_buffer_mb": round(down_raw_bytes / (1024 * 1024), 2),
            "memory_savings_pct": round((1.0 - (down_raw_bytes / full_raw_bytes)) * 100.0, 1),
        },
        "recommended_default": "owned_window_downscaled",
    }


def main():
    print("=" * 80)
    print("SCREENSHOT MEMORY FOOTPRINT BENCHMARK (Prompt R5 Step 5)")
    print(f"Timestamp: {time.strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 80)

    res = measure_screenshot_memory()
    full = res["full_screen"]
    win = res["owned_window"]
    down = res["downscaled_owned_window"]

    print(f"1. Full-Screen Screenshot ({full['dimensions']}):")
    print(f"   - Raw uncompressed buffer: {full['raw_buffer_mb']} MB ({full['raw_buffer_bytes']:,} bytes)")
    print(f"   - Process RSS allocation : +{full['measured_process_delta_mb']} MB")

    print(f"\n2. Owned-Window Screenshot ({win['dimensions']}):")
    print(f"   - Raw uncompressed buffer: {win['raw_buffer_mb']} MB ({win['raw_buffer_bytes']:,} bytes)")
    print(f"   - Memory Savings vs Full : {win['memory_savings_pct']}% reduction")

    print(f"\n3. Downscaled Owned-Window Screenshot ({down['dimensions']}):")
    print(f"   - Raw uncompressed buffer: {down['raw_buffer_mb']} MB ({down['raw_buffer_bytes']:,} bytes)")
    print(f"   - Memory Savings vs Full : {down['memory_savings_pct']}% reduction")

    print(f"\n[DECISION]: Default path set to '{res['recommended_default']}' per R5 specification.")

    out_file = WORKSPACE_ROOT / "reports" / "screenshot_memory.json"
    out_file.parent.mkdir(parents=True, exist_ok=True)
    with open(out_file, "w", encoding="utf-8") as f:
        json.dump(res, f, indent=2)
    print(f"[INFO] Report written cleanly to: {out_file}")
    print("=" * 80)


if __name__ == "__main__":
    main()
