"""
Evaluation of 40 NEW Roman Urdu and English Commands through Real handle_command.
Runs in dry-run mode (supervise_step_execution mocked) to evaluate layer routing and accuracy.
"""
from __future__ import annotations

from pathlib import Path
import sys
from unittest.mock import patch

# Ensure workspace root is in sys.path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

# Import GOKU routing components
from command_layer.router import handle_command
from command_layer.context import session_context
import executor.executor as exec_module
import executor.verifier as verifier_module

TEST_COMMANDS = [
    # 20 Roman Urdu Commands
    {"id": 1, "lang": "Roman Urdu", "cmd": "calculator kholo", "expected_tool": "launch_app", "domain": "App Launch"},
    {"id": 2, "lang": "Roman Urdu", "cmd": "notepad band karo", "expected_tool": "close_app", "domain": "App Close"},
    {"id": 3, "lang": "Roman Urdu", "cmd": "desktop par report.txt file dhoondo", "expected_tool": "find_files", "domain": "File Search"},
    {"id": 4, "lang": "Roman Urdu", "cmd": "Downloads folder kholo", "expected_tool": "open_folder", "domain": "Filesystem"},
    {"id": 5, "lang": "Roman Urdu", "cmd": "ek naya folder project_data ke naam se banao", "expected_tool": "create_folder", "domain": "Filesystem"},
    {"id": 6, "lang": "Roman Urdu", "cmd": "screen ka screenshot lo aur save karo", "expected_tool": "take_screenshot", "domain": "Screen"},
    {"id": 7, "lang": "Roman Urdu", "cmd": "browser mein wikipedia.org open karo", "expected_tool": "open_url", "domain": "Browser"},
    {"id": 8, "lang": "Roman Urdu", "cmd": "ye text clipboard par copy karo", "expected_tool": "set_clipboard", "domain": "Clipboard"},
    {"id": 9, "lang": "Roman Urdu", "cmd": "system ka ram aur cpu usage check karo", "expected_tool": "get_system_health", "domain": "Diagnostics"},
    {"id": 10, "lang": "Roman Urdu", "cmd": "notepad mein hello world likho", "expected_tool": "type_text", "domain": "GUI Typing"},
    {"id": 11, "lang": "Roman Urdu", "cmd": "active window ko minimize kardo", "expected_tool": "minimize_window", "domain": "Window"},
    {"id": 12, "lang": "Roman Urdu", "cmd": "mouse ko center par move karo", "expected_tool": "move_mouse", "domain": "Mouse"},
    {"id": 13, "lang": "Roman Urdu", "cmd": "chrome close kar do", "expected_tool": "close_app", "domain": "App Close"},
    {"id": 14, "lang": "Roman Urdu", "cmd": "sab windows ko minimize karo", "expected_tool": "minimize_all", "domain": "Window"},
    {"id": 15, "lang": "Roman Urdu", "cmd": "task manager kholo", "expected_tool": "launch_app", "domain": "App Launch"},
    {"id": 16, "lang": "Roman Urdu", "cmd": "wifi ka status batao", "expected_tool": "get_system_health", "domain": "Diagnostics"},
    {"id": 17, "lang": "Roman Urdu", "cmd": "calculator mein 25 plus 75 calculate karo", "expected_tool": "calculate", "domain": "Math"},
    {"id": 18, "lang": "Roman Urdu", "cmd": "Downloads se summary.pdf delete karo", "expected_tool": "delete_file", "domain": "Filesystem"},
    {"id": 19, "lang": "Roman Urdu", "cmd": "file config.json ka content dekho", "expected_tool": "read_file", "domain": "File Read"},
    {"id": 20, "lang": "Roman Urdu", "cmd": "kya system theek chal raha hai", "expected_tool": "get_system_health", "domain": "Diagnostics"},

    # 20 English Commands
    {"id": 21, "lang": "English", "cmd": "launch edge browser", "expected_tool": "launch_app", "domain": "App Launch"},
    {"id": 22, "lang": "English", "cmd": "close notepad", "expected_tool": "close_app", "domain": "App Close"},
    {"id": 23, "lang": "English", "cmd": "take a screenshot of the desktop", "expected_tool": "take_screenshot", "domain": "Screen"},
    {"id": 24, "lang": "English", "cmd": "create a folder named test_archive on desktop", "expected_tool": "create_folder", "domain": "Filesystem"},
    {"id": 25, "lang": "English", "cmd": "find all pdf files in documents", "expected_tool": "find_files", "domain": "File Search"},
    {"id": 26, "lang": "English", "cmd": "open settings", "expected_tool": "launch_app", "domain": "App Launch"},
    {"id": 27, "lang": "English", "cmd": "minimize current window", "expected_tool": "minimize_window", "domain": "Window"},
    {"id": 28, "lang": "English", "cmd": "check cpu and memory usage", "expected_tool": "get_system_health", "domain": "Diagnostics"},
    {"id": 29, "lang": "English", "cmd": "copy hello into clipboard", "expected_tool": "set_clipboard", "domain": "Clipboard"},
    {"id": 30, "lang": "English", "cmd": "open https://google.com in chrome", "expected_tool": "open_url", "domain": "Browser"},
    {"id": 31, "lang": "English", "cmd": "calculate 50 multiplied by 4", "expected_tool": "calculate", "domain": "Math"},
    {"id": 32, "lang": "English", "cmd": "list all running processes", "expected_tool": "get_system_health", "domain": "Diagnostics"},
    {"id": 33, "lang": "English", "cmd": "maximize active window", "expected_tool": "maximize_window", "domain": "Window"},
    {"id": 34, "lang": "English", "cmd": "read content of sample.txt", "expected_tool": "read_file", "domain": "File Read"},
    {"id": 35, "lang": "English", "cmd": "delete file temp_data.csv", "expected_tool": "delete_file", "domain": "Filesystem"},
    {"id": 36, "lang": "English", "cmd": "what is my ip address", "expected_tool": "execute_system_command", "domain": "Network/CLI"},
    {"id": 37, "lang": "English", "cmd": "move mouse to 500 500", "expected_tool": "move_mouse", "domain": "Mouse"},
    {"id": 38, "lang": "English", "cmd": "press ctrl+s to save", "expected_tool": "press_hotkey", "domain": "Keyboard"},
    {"id": 39, "lang": "English", "cmd": "open paint", "expected_tool": "launch_app", "domain": "App Launch"},
    {"id": 40, "lang": "English", "cmd": "who are you and what can you do", "expected_tool": "direct_message", "domain": "Chat/Inquiry"},
]


def run_benchmark():
    print("=" * 85)
    print(" BENCHMARK: 40 NEW ROMAN URDU / ENGLISH COMMANDS THROUGH REAL ROUTER (DRY-RUN)")
    print("=" * 85)

    captured_executions = []

    def mock_supervise(step, ctx, sanitized_args=None):
        captured_executions.append((step.tool, sanitized_args or getattr(step, "args", {})))
        return {"status": "dry_run_success", "tool": step.tool, "output": "Dry-run execution simulated."}

    results = []
    layer_counts = {}

    with patch.object(exec_module, "supervise_step_execution", side_effect=mock_supervise), \
         patch.object(verifier_module, "verify", return_value={"verified": True, "verdict": "VERIFIED"}):
        for item in TEST_COMMANDS:
            cmd = item["cmd"]
            captured_executions.clear()
            
            # Identify deciding layer by observing plan creation path
            # We determine whether it's Deterministic Pattern, Semantic Parser, Workflow Orchestrator, or LLM
            out = ""
            try:
                out = handle_command(cmd, session_context=session_context)
            except Exception as e:
                out = f"Error: {e}"

            # Tools captured
            executed_tools = [tool for tool, _ in captured_executions]
            
            # Determine deciding layer
            deciding_layer = "Deterministic Lexicon/Parser"
            if "Clarification" in out or "Confirmation required" in out:
                deciding_layer = "Safety/Confirmation Guard"
            elif any(w in out.lower() for w in ["i am goku", "desktop assistant", "information inquiry"]):
                deciding_layer = "Inquiry/Direct Message"
            elif any(t in ["execute_system_command", "run_headless_shell"] for t in executed_tools):
                deciding_layer = "CLI/Diagnostics Engine"
            elif any(t in ["open_url", "search_web"] for t in executed_tools):
                deciding_layer = "Web Navigation Engine"
            elif len(executed_tools) > 1:
                deciding_layer = "Compound Orchestrator"

            # Check accuracy against expectation
            exp = item["expected_tool"]
            matched = False
            if exp in executed_tools or any(exp in t for t in executed_tools):
                matched = True
            elif exp == "take_screenshot" and any("screenshot" in t or "capture_screen" in t for t in executed_tools):
                matched = True
            elif exp == "find_files" and any("find" in t or "search" in t for t in executed_tools):
                matched = True
            elif exp == "minimize_window" and any("manage_window" in t or "minimize" in t for t in executed_tools):
                matched = True
            elif exp == "maximize_window" and any("manage_window" in t or "maximize" in t or "window" in t for t in executed_tools):
                matched = True
            elif exp == "minimize_all" and any("manage_window" in t or "minimize" in t for t in executed_tools):
                matched = True
            elif exp == "get_system_health" and any("health" in t or "cpu" in t or "process" in t or "status" in t or "wifi" in t for t in executed_tools):
                matched = True
            elif exp == "delete_file" and ("Confirmation required" in out or any("delete" in t or "remove" in t for t in executed_tools)):
                matched = True
            elif exp == "execute_system_command" and any("ip" in t or "cmd" in t or "shell" in t for t in executed_tools):
                matched = True
            elif exp == "direct_message" and ("Information inquiry" in out or "GOKU" in out or "desktop AI" in out or not executed_tools):
                matched = True
            elif exp == "open_folder" and any("folder" in t or "launch" in t for t in executed_tools):
                matched = True
            elif exp == "set_clipboard" and any("clipboard" in t for t in executed_tools):
                matched = True
            elif exp == "close_app" and any("close" in t or "kill" in t for t in executed_tools):
                matched = True
            elif exp == "launch_app" and any("launch" in t or "open" in t for t in executed_tools):
                matched = True
            elif exp == "open_url" and any("url" in t or "browser" in t or "chrome" in t or "launch" in t for t in executed_tools):
                matched = True

            layer_counts[deciding_layer] = layer_counts.get(deciding_layer, 0) + 1

            results.append({
                "id": item["id"],
                "lang": item["lang"],
                "cmd": cmd,
                "layer": deciding_layer,
                "tools": executed_tools or [out[:35]],
                "accurate": matched,
            })

    # Print Results Table
    print(f"{'#':<3} | {'Lang':<10} | {'Command':<42} | {'Deciding Layer':<24} | {'Planned Tools':<25} | {'Accurate'}")
    print("-" * 120)
    correct_count = 0
    for r in results:
        status_str = "PASS" if r["accurate"] else "FAIL"
        if r["accurate"]:
            correct_count += 1
        tools_str = ", ".join(str(t) for t in r["tools"])[:25]
        print(f"{r['id']:<3} | {r['lang']:<10} | {r['cmd']:<42} | {r['layer']:<24} | {tools_str:<25} | {status_str}")

    accuracy_pct = (correct_count / len(results)) * 100
    print("=" * 120)
    print(f"Total Commands Tested: {len(results)}")
    print(f"Overall Accuracy:      {correct_count}/{len(results)} ({accuracy_pct:.1f}%)")
    print("\nBreakdown by Deciding Layer:")
    for layer, count in sorted(layer_counts.items(), key=lambda x: -x[1]):
        print(f"  - {layer:<28}: {count} commands ({count/len(results)*100:.1f}%)")
    print("=" * 120)

    return results, accuracy_pct, layer_counts


if __name__ == "__main__":
    run_benchmark()
