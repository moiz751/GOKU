"""Stage F22: held-out self-check for the request advisor (no pytest needed, works on the real Windows laptop).
Usage: python scripts/heldout_eval.py     -> prints GREEN/RED per case and exits 1 if any case is RED.
It only calls brain.request_advisor.advise (read-only, log=False); it never executes a command."""
from __future__ import annotations

import json
import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
os.environ.setdefault("GOKU_ADAPTIVE_DIR", tempfile.mkdtemp(prefix="goku_eval_"))


def run(path: Path = ROOT / "data" / "heldout_eval.json") -> list:
    from brain.request_advisor import advise
    results = []
    for c in json.loads(path.read_text(encoding="utf-8"))["cases"]:
        a = advise(c["text"], log=False)
        why = []
        if "status" in c and a["status"] != c["status"]:
            why.append(f"status {a['status']} != {c['status']}")
        if "status_in" in c and a["status"] not in c["status_in"]:
            why.append(f"status {a['status']} not in {c['status_in']}")
        if "status_not" in c and a["status"] == c["status_not"]:
            why.append(f"status must not be {c['status_not']}")
        if "intent" in c and a["intent"] != c["intent"]:
            why.append(f"intent {a['intent']} != {c['intent']}")
        if "intent_not" in c and a["intent"] == c["intent_not"]:
            why.append(f"intent must not be {c['intent_not']}")
        results.append({"text": c["text"], "got": f"{a['status']}/{a['intent']}", "ok": not why, "why": "; ".join(why)})
    return results


if __name__ == "__main__":
    res = run()
    for r in res:
        print(("GREEN " if r["ok"] else "RED   ") + f"{r['got']:<42} | {r['text'][:70]}" + (f"  <- {r['why']}" if r["why"] else ""))
    bad = sum(1 for r in res if not r["ok"])
    print(f"\n{len(res) - bad}/{len(res)} GREEN" + ("" if not bad else f", {bad} RED"))
    sys.exit(1 if bad else 0)
