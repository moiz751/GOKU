"""Stage F12: builds docs/F12_SOLUTIONS.md + knowledge/f12_solutions.json: for every capability that was yellow/red - what failed, what F12 fixed, the solution options for what is
still open, and 5 further improvement points that the audit text did not mention. Status comes from docs/CAPABILITY_MATRIX.json (never hand-edited)."""
import json, os
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
S = {
"hw_profile": dict(fix="`my tier` command (hardware_tier) feeds the real profile to an independent `verify_tier`; unknown RAM -> strict mode.", open="Real laptop numbers need scripts/laptop_validate.py.",
  opt=["A (done): thresholds + independent verification", "B: auto-calibrate tier boundaries from laptop_validate measured peaks", "C: remote-measured profile file shipped per laptop model"],
  more=["Report confidence per field (measured / inferred / unknown)", "Detect RAM pressure from background apps and downgrade the tier temporarily", "Detect battery-saver/thermal throttling and lower the tier", "Store the last 5 validated profiles and warn when RAM drops >20%", "Expose `tier why` explaining which signal decided the tier"]),
"resource_monitor": dict(fix="tools/process_tree.py: GOKU own / tree (children, browser, Ollama) / outside-tree / system free are separate numbers; budget_state OK/NEAR/OVER/UNKNOWN; leak watcher; `ram budget` command.", open="Windows working-set vs private bytes needs a laptop comparison.",
  opt=["A (done): psutil RSS tree", "B: add Windows private-working-set via GetProcessMemoryInfo for exactness", "C: Job Object limit so Windows itself caps GOKU's children"],
  more=["Sample adaptively (fast when near budget, slow when idle)", "Track per-kind history to predict the next peak", "Log every OVER event with the top 3 consumers", "Show a one-line 'why was my task queued' using these numbers", "Add a self-test that compares the tree number with Task Manager screenshots on the laptop"]),
"safe_state": dict(fix="`emergency stop` / `clear stop` commands, stop blocks task steps, risky tools need confirmation, `verify_stop_log` checks that nothing runs after stop; checkpoint recovery tested.", open="A hung native call still cannot be force-killed from inside.",
  opt=["A (done): cooperative stop + checkpoints", "B: external watchdog process that kills only GOKU-owned children after a deadline", "C: run risky tools in a child process with a timeout"],
  more=["Hotkey test on the laptop (Ctrl+Alt+Esc style) with latency measurement", "Stop reason shown in every later task report", "Auto-pause when the lid closes or the session locks", "Dead-man switch: no heartbeat for N s -> pause the queue", "Audit entry for each stop/clear with who and when"]),
"calc": dict(fix="Independent exact-Fraction evaluator (`verify_arithmetic`) re-checks every result; `verify:` command; zero-division and non-math refused.", open="Units/algebra beyond the supported grammar are refused, not guessed.",
  opt=["A (done): refuse what is not understood", "B: add unit conversion tables with exact factors", "C: symbolic algebra via sympy when installed (offline pip)"],
  more=["Currency/locale number parsing (1,00,000 / 1.000,50)", "Show the working steps as a checkable list", "Percentage-change vs percentage-point disambiguation", "Date arithmetic (days between, add weeks)", "Significant-figure and rounding policy flag"]),
"reasoning_agent": dict(fix="`verify_assignment` re-evaluates every constraint solution; contradiction/missing-info detectors tested.", open="Real model reasoning quality is unmeasured.",
  opt=["A (done): rule + constraint solver verified independently", "B: route open-ended reasoning to Ollama and verify with rules", "C: labelled held-out reasoning set scored by a human"],
  more=["Label every statement evidence/inference/assumption/unknown", "Ask at most one clarifying question when information is missing", "Keep a reasoning trace that can be replayed", "Detect circular reasoning", "Time-box deep thinking by tier"]),
"security_policy": dict(fix="Policy decisions pass `verify_approval`; a risky 'allow' without an approval record is rejected; injection text never becomes an action.", open="Novel attacks are not covered by static rules.",
  opt=["A (done): static rules + independent approval check", "B: add a regression corpus of new injection samples each month", "C: sandbox untrusted text in a read-only context"],
  more=["Quarantine downloaded text before it reaches the planner", "Log every blocked/confirmed decision with the rule that fired", "Rate-limit repeated risky requests", "Show the user exactly which rule blocked and how to proceed safely", "Red-team test pack runnable with one command"]),
"files_stream": dict(fix="`verify_search_hits` re-reads the source and proves every snippet exists; missing/binary files return clear notes; large files stream by unit.", open="Scanned PDFs need OCR; audio/video are metadata only.",
  opt=["A (done): text formats verified", "B: optional tesseract OCR plugin with a clear 'OCR unavailable' message", "C: Whisper-tiny transcript for audio when RAM allows"],
  more=["Incremental re-index by file hash", "Duplicate-document detection", "Per-folder allow list for indexing", "Retention policy and 'forget this folder'", "Query-time highlight with surrounding context"]),
"screen_vision": dict(fix="tools/live_observer.py merges UIA+OCR into cross-checked elements, reports BLOCKED_ENVIRONMENT precisely; `screen observer` command; scripts/live_evidence.py collects real Windows evidence.", open="Real capture/UIA/OCR on Windows: LIVE evidence missing.",
  opt=["A (done): adapter + honest status", "B: run live_evidence.py on the laptop (screen_vision)", "C: add pywinauto fallback if uiautomation is missing"],
  more=["DPI-scale self-test (100/125/150%)", "Multi-monitor coordinate mapping", "Element stability score across 2 frames", "OCR confidence threshold per language", "Privacy mask for password fields in saved screenshots"]),
"ram_partition": dict(fix="plan_parts + `verify_chunks` prove pieces sum to the whole and fit the budget; unknown RAM -> sequential.", open="Windows behaviour was proved on Linux only.",
  opt=["A (done)", "B: run PartitionedRunner on the laptop under a Job Object limit", "C: adaptive batch size from measured peaks"],
  more=["Checkpoint every N items with atomic writes", "Resume after crash with no double processing", "Merge pieces hierarchically", "Report per-piece peak RSS", "Abort a piece (not the task) when it exceeds its estimate x1.5"]),
"memory_store": dict(fix="`verify_memory_row` confirms secrets are redacted in stored text; forget removes rows; data survives reopen.", open="No device sync; trust scores are heuristic.",
  opt=["A (done)", "B: export/import encrypted memory file for another PC", "C: trust score learned from verified outcomes only"],
  more=["Expiry reminders for time-limited facts", "Conflict detection for contradicting memories", "Memory of corrections ranked above plain facts", "Separate user facts from tool results", "Weekly compaction with a diff report"]),
"route_planning": dict(fix="`verify_route_choice` demands a destructive gate; all-routes-fail ends at ask_user.", open="Plans are not real app execution.",
  opt=["A (done)", "B: wire each route to a verified executor one by one", "C: dry-run mode printing the exact steps"],
  more=["Route cooldown after repeated failure", "Prefer API over UI when both exist", "Record seconds and MB per route", "Explain why a route was dropped", "Ask the user only when all routes are risky"]),
"game_framework": dict(fix="`verify_reward`: reward needs verified evidence; pixel activity never counts; unparseable score is None.", open="No real game session: LIVE evidence missing.",
  opt=["A (done)", "B: user picks a safe offline game and runs a 60 s supervised session", "C: record-and-replay of screenshots for judge regression"],
  more=["Per-game action ban list", "Stuck detection (no state change 20 s)", "Win/lose text language packs", "Pause on window change", "Save best action policy per game"]),
"task_manager": dict(fix="History verifier + plan verifier + restart recovery tested.", open="No cloud sync.",
  opt=["A (done)", "B: export task state file", "C: optional encrypted sync folder"],
  more=["Task priority aging", "Per-step timeouts", "Pause on low RAM instead of failing", "Human-readable audit per task", "Duplicate task detection"]),
"qa_answer_engine": dict(fix="Integration tests via the real `ask:` route; false premise (incl. 'why is the capital of Australia Sydney') now challenged — a real bug found and fixed in qa_mind; unknown stays unknown.", open="Core facts pack is small.",
  opt=["A (done)", "B: grow the pack with sourced facts per domain", "C: optional online lookup with source labels"],
  more=["Source + date on every fact", "Confidence label on every answer", "Ask a clarifying question for ambiguous names", "Roman Urdu answers for every pack fact", "Weekly self-test over the whole pack"]),
"resource_strategy": dict(fix="`decide()` plan integration-tested and budget-verified.", open="Savings are estimates until model_bench runs on the laptop.",
  opt=["A (done)", "B: run model_bench on laptop and store measured rows", "C: choose smaller quantisation automatically when RAM is low"],
  more=["Show estimate vs measured side by side", "Unload model after idle timeout", "Warm-start only when the user is present", "Context length shrink under pressure", "Per-task model choice table"]),
"capability_planner": dict(fix="`verify_chunks` proves chunk plans cover the work within budget.", open="Estimates need laptop calibration.",
  opt=["A (done)", "B: calibration.json from laptop_validate", "C: learn estimate error per work kind"],
  more=["Show ETA ranges not points", "Warn when estimate error >30%", "Explain pending reason in plain words", "Resume order by priority then age", "Auto-split by free RAM"]),
"scheduler": dict(fix="Dependency-ordered run tested; each job ran exactly once.", open="One job at a time by design.",
  opt=["A (done)", "B: use ram_scheduler for light parallel tasks", "C: user-chosen concurrency cap"],
  more=["Skip dependants when a parent fails", "Per-job result files", "Stop request honoured between jobs", "Presence rules (don't run heavy while user is active)", "Daily run summary"]),
"control_layer": dict(fix="Feature switch OFF blocks work with a stated reason, even when the user typed 'run'.", open="Windows idle detection is untested live.",
  opt=["A (done)", "B: live idle-time test on the laptop", "C: manual 'I'm away' toggle"],
  more=["Switch audit log", "Per-feature RAM shown beside the switch", "Compare mode (what changes if I turn X off)", "Safe defaults after update", "Switch presets (battery / performance)"]),
"answer_pipeline": dict(fix="Compound questions answered part by part with labels (integration-tested).", open="Conservative rule engines.",
  opt=["A (done)", "B: model draft + rule verification", "C: more decomposition patterns"],
  more=["Mark which part was verified", "Carry context across follow-ups", "Detect contradictory sub-questions", "Offer to continue after a partial answer", "Skip parts it must not guess"]),
"download": dict(fix="Hash/size mismatch detection verified independently; live collector `--url --sha256`.", open="No real internet download tested: LIVE evidence missing.",
  opt=["A (done)", "B: run live_evidence.py --only download with a small trusted file", "C: resume partial downloads with Range requests"],
  more=["Official-source allow list", "Free-disk check before download", "Quarantine folder until verified", "Progress with cancel", "Retry with backoff only for idempotent GETs"]),
"translate_text": dict(fix="Numbers and restrictions verifiers (`verify_numbers_preserved`, `verify_restrictions_kept`); needing a model is stated, not faked.", open="Offline translation is partial.",
  opt=["A (done)", "B: small offline phrase table", "C: Ollama translation with these verifiers on the output"],
  more=["Preserve names/URLs untouched", "Flag idioms for review", "Roman Urdu spelling normalisation", "Round-trip check", "Show alternatives when ambiguous"]),
"benchmark_f8": dict(fix="`verify_recurring` proves no duplicate runs; recurring add/run tested with a fake clock.", open="No real account/browser/notification.",
  opt=["A (done)", "B: Windows toast test on laptop", "C: real browser monitor behind approval"],
  more=["Catch-up policy per task", "Missed-run report", "Quiet hours", "Pause all with one command", "Change detection with before/after proof"]),
"qa_mind": dict(fix="Integration tests through the real route (misconception + premise + unknown).", open="60 concepts; self-authored benchmark.",
  opt=["A (done)", "B: grow concepts with sources", "C: independent human-labelled set"],
  more=["Premise check for 'why' questions (fixed now)", "Correct units/dates traps", "Roman Urdu premise phrases", "Confidence calibration table", "Self-correction log"]),
"shopify_seo_oem": dict(fix="Offline workflow verified (F10/F11); read-only live collector (`SHOPIFY_*` env vars).", open="Real Shopify session: LIVE evidence missing.",
  opt=["A (done)", "B: read-only API check with a scoped token", "C: staging store dry run"],
  more=["Never store tokens in files", "Compare published vs prepared text by hash", "Spelling dictionary offline", "Link reachability when online", "Per-product OEM confidence"]),
"orchestrator": dict(fix="Real command executed as a step with an independent verify; COMPLETED trace checked by `verify_trace`.", open="Not every route has a real executor yet.",
  opt=["A (done)", "B: add executors route by route", "C: generic tool-runner with verification hooks"],
  more=["Resume from the last verified step", "Evidence file per step", "Parallel read-only steps", "Timeout per step", "Summary showing open requirements"]),
"ram_scheduler": dict(fix="Wired into app (`schedule:`); light starts, heavy queues; schedule log verified; unmeasurable RAM starts nothing.", open="Real 1.1 GB laptop run not done.",
  opt=["A (done)", "B: feed measured peaks from process_tree", "C: laptop stress test"],
  more=["Pause only at checkpoints", "Idempotency keys", "Approval never granted by free RAM", "Priority aging", "Queue delay report"]),
"recovery_engine": dict(fix="Uncertain-action refusal until read-back, duplicate refusal, classification all tested through real objects.", open="External state read-back is the caller's job.",
  opt=["A (done)", "B: per-integration read-back functions", "C: user confirmation fallback"],
  more=["Failure category counters", "Next safe action in each diagnosis", "Never retry non-idempotent actions", "Link to the checkpoint", "Plain-language failure report"]),
"screen_loop": dict(fix="`verify_screen_log`: no click after stale/blocked/disagreeing observation; risky click without approval never happens.", open="Real Windows observer run: LIVE evidence missing.",
  opt=["A (done)", "B: live_evidence.py screen_loop", "C: dry-run mode that only highlights targets"],
  more=["Max one retry after re-observation", "Window-change guard", "DPI conversion test", "Dialog detector", "Action replay log"]),
"video_audit": dict(fix="Media report verifier ensures evidence on every issue and no full-coverage claim; corrupt files blocked.", open="Face/hand/lip-sync/subtitle OCR not performed on this tier.",
  opt=["A (done)", "B: optional heavier model on bigger RAM tier", "C: human review queue for suspected issues"],
  more=["Per-issue timecode thumbnails", "Audio loudness (LUFS) report", "Scene-cut list export", "Compare before/after correction", "Never overwrite original"]),
"image_audit": dict(fix="Findings carry evidence; corrupt images blocked.", open="No object/scene recognition.",
  opt=["A (done)", "B: OCR with tesseract when installed", "C: tiny classifier on bigger tier"],
  more=["Colour palette with names", "Blur/exposure measures", "Crop-region suggestions", "EXIF read-only summary", "Uncertainty labels"]),
"social_prep": dict(fix="Package/preview/approval gate verified offline.", open="Real account: LIVE evidence missing.",
  opt=["A (done)", "B: draft-only check on a test account", "C: platform spec refresh from official pages"],
  more=["Char/hashtag limits per platform", "Link and media validation", "Content hash approved vs posted", "Read-back after post", "Schedule suggestion only"]),
"install_policy": dict(fix="Wired as `install plan:` command; download approval does not cover install; hash mismatch, bypass flags and bundled extras refused.", open="Real installer/Authenticode run: LIVE evidence missing.",
  opt=["A (done)", "B: live_evidence.py --installer (signature check, never executes)", "C: sandboxed VM install test"],
  more=["Official-domain allow list", "Disk/RAM compatibility check", "Rollback plan note", "Post-install verification", "Uninstall instructions"]),
}
def main():
    m = json.load(open(os.path.join(ROOT, "docs", "CAPABILITY_MATRIX.json"), encoding="utf-8"))
    rows = {r["id"]: r for r in m["rows"]}
    L = ["# GOKU F12 - failures, fixes, solution options and 5 further points per capability", "", "Generated from docs/CAPABILITY_MATRIX.json. Green = all applicable criteria met by tests; PASS_OFFLINE_LIVE_PENDING = every offline criterion met, only the real Windows/account proof is missing (cannot be green without evidence/live/<id>.json).", ""]
    out = {}
    for cid, d in S.items():
        r = rows.get(cid)
        if not r:
            continue
        ic = {"green": "\U0001F7E2", "yellow": "\U0001F7E1", "red": "\U0001F534"}[r["color"]]
        L += [f"## {ic} {r['name']} (`{cid}`) - {r['status']} {r['score']}", f"**Fixed in F12:** {d['fix']}", f"**Still open:** {d['open']}" + (f" Matrix gaps: {', '.join(k.split(' ',1)[1] for k in r['missing'])}" if r["missing"] else ""),
              "**Solution options:**"] + [f"- {o}" for o in d["opt"]] + ["**5 further points (not in the audit):**"] + [f"{i}. {p}" for i, p in enumerate(d["more"], 1)] + [""]
        out[cid] = {**d, "status": r["status"], "color": r["color"]}
    L += ["## Retired", "- action_machine_draft: SUPERSEDED by orchestrator + recovery (retired/action_machine.py.txt)."]
    open(os.path.join(ROOT, "docs", "F12_SOLUTIONS.md"), "w", encoding="utf-8").write("\n".join(L))
    json.dump(out, open(os.path.join(ROOT, "knowledge", "f12_solutions.json"), "w", encoding="utf-8"), indent=1, ensure_ascii=False)
    print(len(out), "capabilities documented;", sum(1 for v in out.values() if len(v["more"]) == 5), "with 5 further points")
if __name__ == "__main__":
    main()
