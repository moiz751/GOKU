"""Measures GOKU on THIS machine and calibrates the planner (run it on the laptop, with nothing else heavy open):
    python scripts/laptop_validate.py [--big-mb 150] [--with-ollama]
Writes logs/laptop_validation.json (full report) and logs/calibration.json (measured numbers that brain/capability_planner.py then prefers over estimates).
Everything runs in a temporary folder that this script creates and removes itself; no other file and no other program is touched."""
from __future__ import annotations

import argparse
import gc
import json
import os
import shutil
import sys
import tempfile
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))


def rss_mb() -> float:
    import psutil
    return psutil.Process().memory_info().rss / 1048576.0


def check(name: str, ok: bool, detail: str, report: dict) -> None:
    report["checks"].append({"name": name, "ok": bool(ok), "detail": detail})
    print(f"[{'PASS' if ok else 'WARN'}] {name}: {detail}")


def alloc_and_hold(mb: int) -> int:                    # runs in the child process for the isolation test
    data = bytearray(mb * 1048576)
    for i in range(0, len(data), 4096):
        data[i] = 1
    return len(data) // 1048576


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--big-mb", type=float, default=150.0)
    ap.add_argument("--with-ollama", action="store_true")
    a = ap.parse_args()
    from brain import capability_planner as cp
    from brain.piece_runner import file_profile_piece, merge_profile, run_pieces
    report: dict = {"started": time.strftime("%Y-%m-%d %H:%M:%S"), "checks": [], "measured": {}}
    cal: dict = {"kinds": {}, "measured_at": report["started"]}

    snap = cp.scan_system()
    report["scan"] = {k: snap.get(k) for k in ("total_mb", "free_mb", "tier", "battery_pct", "on_ac", "cpu_count", "goku_mb", "disk_free_mb")}
    print("machine:", report["scan"])
    check("scan", snap["total_mb"] > 0 and snap["free_mb"] > 0, f"RAM {snap['free_mb']:.0f} free of {snap['total_mb']:.0f} MB, tier {snap['tier']}", report)

    # 1) big file in pieces: peak memory and speed
    tmp = Path(tempfile.mkdtemp(prefix="goku_validate_"))
    try:
        need = a.big_mb * 1.2
        free_disk = (snap.get("disk_free_mb") or 0)
        if free_disk and free_disk < need + 300:
            check("big file in pieces", False, f"skipped: only {free_disk:.0f} MB disk free", report)
        else:
            big = tmp / "big.txt"
            line = "alpha beta gamma delta epsilon zeta eta theta iota kappa lambda mu nu xi omicron\n"
            with open(big, "w", encoding="utf-8") as f:
                n = 0
                while n < a.big_mb * 1048576:
                    blk = "".join(f"{i} {line}" for i in range(500)) + "\n"
                    f.write(blk)
                    n += len(blk)
            size = big.stat().st_size
            gc.collect()
            base = rss_mb()
            peak = [0.0]

            def fn(piece):
                peak[0] = max(peak[0], rss_mb() - base)
                return file_profile_piece(piece)
            piece_mb = cp.plan_chunks(size / 1048576, snap["free_mb"], snap["headroom_mb"], tier=snap["tier"])["chunk_mb"]
            t0 = time.time()
            r = run_pieces(big, fn, piece_mb=piece_mb, results_path=tmp / "r.jsonl")
            dt = max(time.time() - t0, 1e-6)
            tot = merge_profile(r["results_path"]) if r["coverage_ok"] else {}
            mbps = size / 1048576 / dt
            est = cp.WORK["big_text"]["chunk_ram_mb"]
            check("big file in pieces: all bytes covered", r["status"] == "done" and r["coverage_ok"] and tot.get("bytes") == size, f"{size / 1048576:.0f} MB in {tot.get('pieces')} pieces of ~{piece_mb} MB", report)
            check("big file in pieces: memory stayed flat", peak[0] < max(120.0, 3 * piece_mb + 60), f"peak growth {peak[0]:.0f} MB (planner estimate {est} MB)", report)
            cal["kinds"]["big_text"] = {"chunk_ram_mb": round(max(peak[0], 5.0) * 1.25, 1), "mb_per_s": round(mbps, 2)}
            report["measured"]["big_text"] = {"peak_growth_mb": round(peak[0], 1), "mb_per_s": round(mbps, 2), "piece_mb": piece_mb}

        # 2) process isolation really returns memory to the OS
        from tools.isolated import run_isolated
        before = rss_mb()
        r = run_isolated("scripts.laptop_validate:alloc_and_hold", [200], timeout=120, cwd=str(ROOT))
        after = rss_mb()
        check("isolated heavy task", r.get("ok") and r.get("result") == 200 and after - before < 60, f"child peak {r.get('peak_mb')} MB, parent grew {after - before:.0f} MB", report)
        report["measured"]["isolated"] = {"child_peak_mb": r.get("peak_mb"), "parent_growth_mb": round(after - before, 1)}

        # 3) reclaim after a big in-process allocation
        hold = bytearray(150 * 1048576)
        for i in range(0, len(hold), 4096):
            hold[i] = 1
        high = rss_mb()
        del hold
        res = cp.reclaim(trim=__import__("tools.system_control", fromlist=["x"]).trim_process_memory)
        low = rss_mb()
        check("reclaim after work", res["ok"] and low < high - 20, f"{high:.0f} MB -> {low:.0f} MB ({', '.join(res['done'])})", report)
        report["measured"]["reclaim"] = {"before_mb": round(high, 1), "after_mb": round(low, 1)}

        # 4) solver speed (no model)
        from brain import answer_engine
        qs = ["what is 15% of 240", "2 hours 30 minutes in minutes", "5 gb in mb", "kitne din bache 2026-12-25 tak", "capital of japan"] * 4
        t0 = time.time()
        ok = sum(1 for q in qs if answer_engine.answer(q).get("status") in ("answered", "needs_web", "unknown", "clarify"))
        per = (time.time() - t0) / len(qs) * 1000
        check("answer engine speed", ok == len(qs) and per < 200, f"{per:.1f} ms per question", report)
        report["measured"]["solver_ms"] = round(per, 1)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)

    # 5) tree memory vs GOKU's ceiling
    snap2 = cp.scan_system()
    ceiling = cp._goku_ceiling_mb(snap2["tier"])
    check("GOKU memory inside its ceiling", (snap2.get("goku_mb") or 0) < ceiling, f"{snap2.get('goku_mb') or 0:.0f} MB of {ceiling:.0f} MB", report)

    if a.with_ollama:
        try:
            import subprocess
            subprocess.run([sys.executable, str(ROOT / "scripts" / "model_bench.py"), "--quick"], check=False, timeout=900, cwd=str(ROOT))
            rows = json.loads((ROOT / "logs" / "model_bench.json").read_text(encoding="utf-8")).get("rows", [])
            good = [r for r in rows if r.get("ok") and r.get("ctx") == 1024 and r.get("batch") == 64]
            if good:
                cal["kinds"]["chat"] = {"ram_mb": round(good[0]["rss_mb"] * 1.1, 1)}
            check("model benchmark", bool(good), f"{len(rows)} variants measured", report)
        except Exception as exc:
            check("model benchmark", False, f"{type(exc).__name__}: {exc}", report)

    out = ROOT / "logs"
    out.mkdir(exist_ok=True)
    (out / "laptop_validation.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    if cal["kinds"]:
        (out / "calibration.json").write_text(json.dumps(cal, indent=2), encoding="utf-8")
        print("calibration written: the planner now uses the measured numbers for", ", ".join(cal["kinds"]))
    bad = [c for c in report["checks"] if not c["ok"]]
    print(f"\n{len(report['checks']) - len(bad)} passed, {len(bad)} warnings. Send logs/laptop_validation.json back.")
    return 0 if not bad else 1


if __name__ == "__main__":
    sys.exit(main())
