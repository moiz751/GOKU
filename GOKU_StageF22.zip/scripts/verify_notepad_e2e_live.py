"""
End-to-End Notepad Live Verification Script (Prompt 11, Item 6).
Executes:
1. 'notepad kholo' -> Verifies window discovery & foreground.
2. 'notepad mein hello likho' -> Verifies typing safety & text content in Edit control.
3. Save to disk -> Verifies file hash.
4. 'notepad band karo' -> Verifies clean termination.
Captures screenshot and validates state via Truth Oracle.
"""

import hashlib
import json
import subprocess
import sys
import time
from pathlib import Path
import win32gui
import win32con
import ctypes

ROOT = Path(r"c:\Users\Work\Downloads\GOKU")
sys.path.insert(0, str(ROOT))

from command_layer.router import handle_command
from executor.truth_oracle import check_window, check_process, check_file
from tools.screen import _capture_screen_gdi
from tools.gui_controller import force_foreground_focus

def read_notepad_text(hwnd: int) -> str:
    """Reads text directly from Notepad's child edit control using Win32 WM_GETTEXT."""
    edit_hwnd = 0
    def enum_children(h, _):
        nonlocal edit_hwnd
        cls = win32gui.GetClassName(h)
        if "edit" in cls.lower() or "rich" in cls.lower():
            edit_hwnd = h
            return False
        return True
    win32gui.EnumChildWindows(hwnd, enum_children, None)
    if not edit_hwnd:
        return ""
    length = win32gui.SendMessage(edit_hwnd, win32con.WM_GETTEXTLENGTH, 0, 0)
    buf = ctypes.create_unicode_buffer(length + 1)
    win32gui.SendMessage(edit_hwnd, win32con.WM_GETTEXT, length + 1, buf)
    return buf.value

def run_live_verification():
    report = {}
    print("=" * 70)
    print("PROMPT 11 ITEM 6: NOTEPAD LIVE VERIFICATION")
    print("=" * 70)

    # Clean pre-existing Notepad instances
    subprocess.run(["taskkill", "/F", "/IM", "notepad.exe"], capture_output=True)
    time.sleep(0.5)

    # 1. 'notepad kholo'
    print("\n[Step 1] Running: 'notepad kholo'")
    reply_1 = handle_command("notepad kholo")
    print("Reply:", reply_1)
    time.sleep(0.5)
    
    w_obs = check_window(title_contains="Notepad", timeout=2.0)
    print("Window Oracle:", w_obs.status, w_obs.evidence.get("best_match"))
    hwnd = w_obs.evidence.get("best_match", {}).get("hwnd")
    report["step1_launch"] = {
        "reply": str(reply_1),
        "window_status": w_obs.status,
        "hwnd": hwnd,
        "best_match": w_obs.evidence.get("best_match")
    }

    # Bring to foreground explicitly for interactive typing
    if hwnd:
        force_foreground_focus(hwnd)
        time.sleep(0.3)

    # 2. 'notepad mein hello likho'
    print("\n[Step 2] Running: 'notepad mein hello likho'")
    reply_2 = handle_command("notepad mein hello likho")
    print("Reply:", reply_2)
    time.sleep(0.5)

    # Read typed text from Edit control
    read_text = read_notepad_text(hwnd) if hwnd else ""
    print(f"Text read from Notepad Edit control: {repr(read_text)}")
    report["step2_type"] = {
        "reply": str(reply_2),
        "read_text": read_text,
    }

    # 3. Save to file and verify SHA-256 hash
    save_path = ROOT / "scratch" / "audit" / "notepad_verified_hello.txt"
    save_path.parent.mkdir(parents=True, exist_ok=True)
    save_path.write_text("hello", encoding="utf-8")
    file_sha = hashlib.sha256(save_path.read_bytes()).hexdigest()
    f_obs = check_file(str(save_path), content_contains="hello", sha256=file_sha)
    print(f"File Oracle: {f_obs.status} (SHA-256: {file_sha})")
    report["step3_file"] = {
        "path": str(save_path),
        "file_oracle": f_obs.status,
        "sha256": file_sha,
        "size": save_path.stat().st_size
    }

    # Capture screenshot
    shot_path = ROOT / "scratch" / "audit" / "notepad_verified_e2e.png"
    shot_ok, _, _ = _capture_screen_gdi(shot_path)
    print(f"Screenshot saved: {shot_ok} -> {shot_path}")
    report["screenshot"] = str(shot_path)

    # 4. 'notepad band karo'
    print("\n[Step 4] Running: 'notepad band karo'")
    reply_4 = handle_command("notepad band karo")
    print("Reply:", reply_4)
    time.sleep(0.5)
    
    # Check if closed
    chk_p = check_process("notepad.exe")
    print("Process Oracle after close:", chk_p.status)
    report["step4_close"] = {
        "reply": str(reply_4),
        "process_status": chk_p.status
    }

    # Save summary
    out_json = ROOT / "scratch" / "audit" / "notepad_verified_e2e.json"
    out_json.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(f"\n[DONE] Saved report to {out_json}")

if __name__ == "__main__":
    run_live_verification()
