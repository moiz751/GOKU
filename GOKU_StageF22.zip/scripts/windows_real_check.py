"""Stage F19: ONE command for the real-Windows check. Runs the test suite on YOUR machine with the failure ledger switched off (so nothing is hidden), records the machine
(OS, RAM, free RAM, CPU, GPU via nvidia-smi when present), samples GOKU's own status commands, and writes reports/windows_real_check_<time>.json + .md with
GREEN / YELLOW / RED per test file. Send those two files back and the sandbox-only reds can be separated from real defects.
Usage (from the project folder):  python scripts/windows_real_check.py            -> everything except the very slow groups
                                  python scripts/windows_real_check.py --full     -> every test
                                  python scripts/windows_real_check.py tests/test_window_lifecycle.py  -> only those files
Nothing is installed or downloaded; no password/token is read; the run is offline."""
from __future__ import annotations

import collections
import json
import os
import platform
import shutil
import subprocess
import sys
import time
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
os.chdir(ROOT)
sys.path.insert(0, str(ROOT))


def machine() -> dict:
    info = {"os": platform.platform(), "python": sys.version.split()[0], "cpu_count": os.cpu_count()}
    try:
        import psutil
        vm = psutil.virtual_memory()
        info.update(ram_total_mb=round(vm.total / 1048576), ram_free_mb=round(vm.available / 1048576), cpu_pct=psutil.cpu_percent(interval=0.5), source="measured (psutil)")
    except Exception:
        info["source"] = "unknown (psutil missing)"
    if shutil.which("nvidia-smi"):
        try:
            info["gpu"] = subprocess.run(["nvidia-smi", "--query-gpu=name,memory.total,memory.used", "--format=csv,noheader"], capture_output=True, text=True, timeout=10).stdout.strip()
        except Exception as exc:
            info["gpu"] = f"nvidia-smi failed: {exc}"
    else:
        info["gpu"] = "no nvidia-smi found"
    return info


def goku_status() -> dict:
    out = {}
    try:
        from brain import adaptive_runtime
        out["adaptive"] = adaptive_runtime.status_text()
    except Exception as exc:
        out["adaptive"] = f"error: {exc}"
    try:
        from brain.engines import handle_command
        out["engines"] = handle_command("engine stats")
    except Exception as exc:
        out["engines"] = f"error: {exc}"
    try:
        from brain.request_advisor import advise
        out["advisor_samples"] = {t: advise(t, log=False)["status"] for t in ("Avengers Endgame download kar", "doctor doom", "meri health scan ker", "notepad kholo")}
    except Exception as exc:
        out["advisor_samples"] = f"error: {exc}"
    return out


def main(argv: list) -> int:
    full = "--full" in argv
    targets = [a for a in argv if not a.startswith("--")] or ["tests"]
    stamp = time.strftime("%Y%m%d_%H%M%S")
    rep = ROOT / "reports"
    rep.mkdir(exist_ok=True)
    xml = rep / f"windows_real_check_{stamp}.xml"
    env = dict(os.environ, GOKU_IGNORE_LEDGER="1", PYTHONPATH=str(ROOT))
    cmd = [sys.executable, "-m", "pytest", *targets, "-p", "no:cacheprovider", "-q", "--continue-on-collection-errors", f"--junitxml={xml}"]
    if not full and targets == ["tests"]:
        cmd += ["-m", "not slow"]
    print("running:", " ".join(cmd), flush=True)
    t0 = time.time()
    proc = subprocess.run(cmd, env=env)
    files = collections.defaultdict(lambda: {"pass": 0, "fail": 0, "xfail": 0, "skip": 0})
    try:
        for tc in ET.parse(xml).iter("testcase"):
            f = tc.get("classname", "").replace("tests.", "").split(".")[0]
            if tc.find("failure") is not None or tc.find("error") is not None:
                files[f]["fail"] += 1
            elif tc.find("skipped") is not None:
                s = tc.find("skipped")
                files[f]["xfail" if (s.get("type") == "pytest.xfail" or "xfail" in (s.get("message") or "")) else "skip"] += 1
            else:
                files[f]["pass"] += 1
    except (OSError, ET.ParseError) as exc:
        print("could not read junit:", exc)
    rows = []
    for f, v in sorted(files.items()):
        rows.append({"file": f, "light": "RED" if v["fail"] else ("YELLOW" if v["xfail"] or v["skip"] else "GREEN"), **v})
    result = {"time": stamp, "seconds": round(time.time() - t0), "pytest_exit": proc.returncode, "machine": machine(), "goku": goku_status(),
              "summary": dict(collections.Counter(r["light"] for r in rows)), "files": rows}
    (rep / f"windows_real_check_{stamp}.json").write_text(json.dumps(result, indent=1, ensure_ascii=False), encoding="utf-8")
    md = [f"# GOKU real-Windows check {stamp}", "", f"Machine: {result['machine']}", "", f"Summary: {result['summary']}", "", "| light | file | pass | fail | xfail | skip |", "|---|---|---|---|---|---|"]
    md += [f"| {r['light']} | {r['file']} | {r['pass']} | {r['fail']} | {r['xfail']} | {r['skip']} |" for r in sorted(rows, key=lambda r: (r["light"] != "RED", r["light"] != "YELLOW", r["file"]))]
    (rep / f"windows_real_check_{stamp}.md").write_text("\n".join(md), encoding="utf-8")
    print("\nSUMMARY", result["summary"], "\nReports:", rep / f"windows_real_check_{stamp}.json", rep / f"windows_real_check_{stamp}.md")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
