"""Unpack .skill packs (zip files holding SKILL.md + references) into knowledge/skills/<group>/<name>/ as TEXT ONLY
and write knowledge/skills/index.json. Binary assets (fonts, images) and files > 400 KB are skipped (recorded in the index).
Nothing in a pack is ever executed by this script. usage: python scripts/build_skill_library.py <dir-with-group-folders> [--out knowledge/skills]"""
import argparse, hashlib, json, os, re, shutil, sys, zipfile
from pathlib import Path

TEXT = {".md", ".txt", ".json", ".csv", ".yaml", ".yml", ".py", ".mjs", ".js", ".html", ".css", ".svg", ".toml", ".cjs", ""}
MAXF = 400_000


def front(text):
    m = re.match(r"(?s)^---\s*\n(.*?)\n---\s*\n", text)
    fm = {}
    if m:
        cur = None
        for ln in m.group(1).split("\n"):
            k = re.match(r"^([A-Za-z_-]+):\s*(.*)$", ln)
            if k:
                cur = k.group(1); fm[cur] = k.group(2).strip().strip('"\'>|')
            elif cur and ln.strip():
                fm[cur] = (fm[cur] + " " + ln.strip()).strip()
    return fm


def main(src, out):
    out = Path(out); lib = {}
    if out.exists():
        shutil.rmtree(out)
    out.mkdir(parents=True)
    for pack in sorted(Path(src).glob("*/*.skill")):
        group = pack.parent.name
        z = zipfile.ZipFile(pack)
        names = [i for i in z.infolist() if not i.is_dir()]
        root = pack.stem
        kept, skipped = [], []
        for i in names:
            rel = i.filename.split("/", 1)[1] if "/" in i.filename else i.filename
            if ".." in rel.split("/") or rel.startswith("/"):
                skipped.append(i.filename); continue
            ext = os.path.splitext(rel)[1].lower()
            if ext not in TEXT or i.file_size > MAXF:
                skipped.append(rel); continue
            dest = out / group / root / rel
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(z.read(i))
            kept.append(rel)
        sk = out / group / root / "SKILL.md"
        text = sk.read_text(encoding="utf-8", errors="ignore") if sk.is_file() else ""
        fm = front(text)
        lib[root] = {"name": fm.get("name", root), "group": group, "description": (fm.get("description") or re.sub(r"\s+", " ", text[:200])).strip()[:600],
                     "files": sorted(kept), "skipped_binary_or_large": len(skipped), "sha256": hashlib.sha256(pack.read_bytes()).hexdigest()}
    (out / "index.json").write_text(json.dumps(lib, indent=1, ensure_ascii=False), encoding="utf-8")
    print(f"{len(lib)} skills -> {out}")


if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("src"); ap.add_argument("--out", default="knowledge/skills")
    a = ap.parse_args(); main(a.src, a.out)
