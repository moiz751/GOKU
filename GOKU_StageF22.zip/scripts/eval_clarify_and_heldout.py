"""
scripts/eval_clarify_and_heldout.py - Clarify Metrics & Held-Out Evaluation
Follows GOKU RULES v2 + 16-26 (Prompt R3 Step 4 & 6).

Evaluates the held-out dataset plus explicit expected-clarify cases:
- Missing target: ("delete file", "file delete karo", "close app", "folder delete karo")
- Two candidate apps: ("isko close karo" with file+app, "usko band karo" with file+app)
- Destructive verb without target: ("delete karo", "wipe that immediately", "terminate process immediately")

Computes and reports:
1. Overall Accuracy: (True Execute + True Clarify) / Total
2. False-Clarify Rate: False Clarify / Total Unambiguous
3. False-Execute Rate: False Execute / Total Ambiguous
"""
from __future__ import annotations

import json
import os
from pathlib import Path
import sys
from typing import Any, Dict

WORKSPACE_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(WORKSPACE_ROOT))

os.environ["GOKU_SANDBOX"] = "1"
os.environ["GOKU_MODE"] = "dev"

from command_layer.context import TypedEntity, EntityType, session_context
from command_layer.router import _classify_and_parse_command


def run_evaluation() -> Dict[str, Any]:
    print("=" * 80)
    print("PROMPT R3 STEP 4: CLARIFY METRIC & HELD-OUT EVALUATION")
    print("=" * 80)
    
    heldout_path = WORKSPACE_ROOT / "acceptance" / "routing_heldout.json"
    with open(heldout_path, "r", encoding="utf-8") as f:
        heldout_cases = json.load(f)
        
    # Additional required expected-clarify cases (missing target, two candidate apps, destructive verb without target)
    expected_clarify_additions = [
        # Missing Target
        {
            "id": 1001,
            "command": "file delete karo",
            "tool": "clarify",
            "is_ambiguous": True,
            "clarify_type": "missing_target",
            "setup": lambda ctx: ctx.clear()
        },
        {
            "id": 1002,
            "command": "delete file",
            "tool": "clarify",
            "is_ambiguous": True,
            "clarify_type": "missing_target",
            "setup": lambda ctx: ctx.clear()
        },
        {
            "id": 1003,
            "command": "folder delete karo",
            "tool": "clarify",
            "is_ambiguous": True,
            "clarify_type": "missing_target",
            "setup": lambda ctx: ctx.clear()
        },
        {
            "id": 1004,
            "command": "close app",
            "tool": "clarify",
            "is_ambiguous": True,
            "clarify_type": "missing_target",
            "setup": lambda ctx: ctx.clear()
        },
        # Two Candidate Apps / Entities
        {
            "id": 1005,
            "command": "isko close karo",
            "tool": "clarify",
            "is_ambiguous": True,
            "clarify_type": "two_candidate_entities",
            "setup": lambda ctx: (
                ctx.clear(),
                setattr(ctx, "last_file", TypedEntity("notes.txt", EntityType.FILE)),
                setattr(ctx, "last_application", TypedEntity("Notepad", EntityType.APPLICATION))
            )
        },
        {
            "id": 1006,
            "command": "usko band karo",
            "tool": "clarify",
            "is_ambiguous": True,
            "clarify_type": "two_candidate_entities",
            "setup": lambda ctx: (
                ctx.clear(),
                setattr(ctx, "last_file", TypedEntity("budget.xlsx", EntityType.FILE)),
                setattr(ctx, "last_application", TypedEntity("Calculator", EntityType.APPLICATION))
            )
        },
        # Destructive Verb Without Target
        {
            "id": 1007,
            "command": "delete karo",
            "tool": "clarify",
            "is_ambiguous": True,
            "clarify_type": "destructive_no_target",
            "setup": lambda ctx: ctx.clear()
        },
        {
            "id": 1008,
            "command": "terminate immediately",
            "tool": "clarify",
            "is_ambiguous": True,
            "clarify_type": "destructive_no_target",
            "setup": lambda ctx: ctx.clear()
        },
    ]

    all_test_cases = list(heldout_cases) + expected_clarify_additions

    tc = 0  # True Clarify
    fe = 0  # False Execute (failed to clarify when ambiguous)
    te = 0  # True Execute (executed correct tool when unambiguous)
    fc = 0  # False Clarify (clarified when unambiguous)
    wt = 0  # Wrong Tool (executed wrong tool when unambiguous)

    detailed_results = []
    
    for case in all_test_cases:
        cmd = case["command"]
        exp_tool = case["tool"]
        is_ambig = case.get("is_ambiguous", False)
        
        # Setup context
        if "setup" in case and callable(case["setup"]):
            case["setup"](session_context)
        else:
            session_context.clear()
            
        plan = None
        try:
            plan = _classify_and_parse_command(cmd, session_context)
        except Exception:
            pass
            
        is_clarify = False
        decided_tool = "unhandled"
        if plan is not None and getattr(plan, "is_direct_message", False):
            msg = getattr(plan, "message_text", "")
            if getattr(session_context, "pending_clarification", None) is not None or "Which" in msg or "Ambiguous" in msg or "Multiple" in msg or "what would you like" in msg.lower():
                is_clarify = True
                decided_tool = "clarify"
            elif any(w in msg.lower() for w in ["blocked", "prohibited", "restricted"]):
                decided_tool = "refuse"
            else:
                decided_tool = "chat"
        elif plan is not None and plan.steps:
            decided_tool = plan.steps[0].tool
            
        # Metric counting
        if is_ambig:
            if is_clarify or decided_tool == "clarify":
                tc += 1
                verdict = "PASS_CLARIFY"
            else:
                fe += 1
                verdict = "FALSE_EXECUTE"
        else:
            if is_clarify:
                fc += 1
                verdict = "FALSE_CLARIFY"
            elif exp_tool == decided_tool or (exp_tool == "execute_command" and "network" in decided_tool):
                te += 1
                verdict = "PASS_EXECUTE"
            else:
                wt += 1
                verdict = "WRONG_TOOL"
                
        detailed_results.append({
            "id": case["id"],
            "command": cmd,
            "is_ambiguous": is_ambig,
            "expected_tool": exp_tool,
            "decided_tool": decided_tool,
            "verdict": verdict
        })

    total_cases = len(all_test_cases)
    total_ambig = tc + fe
    total_unambig = te + fc + wt
    accuracy = ((tc + te) / total_cases * 100) if total_cases > 0 else 0.0
    false_clarify_rate = (fc / total_unambig * 100) if total_unambig > 0 else 0.0
    false_execute_rate = (fe / total_ambig * 100) if total_ambig > 0 else 0.0

    print(f"Total Evaluated Commands : {total_cases}")
    print(f" - Unambiguous Commands  : {total_unambig}")
    print(f" - Ambiguous (Clarify)   : {total_ambig}")
    print("-" * 80)
    print(f"True Execute (TE)        : {te:>3} / {total_unambig}")
    print(f"True Clarify (TC)        : {tc:>3} / {total_ambig}")
    print(f"False Clarify (FC)       : {fc:>3} / {total_unambig} (Over-clarification)")
    print(f"False Execute (FE)       : {fe:>3} / {total_ambig} (Under-clarification / Silent Guessing)")
    print(f"Wrong Tool (WT)          : {wt:>3} / {total_unambig}")
    print("=" * 80)
    print(f"OVERALL ACCURACY         : {accuracy:>5.1f}% [MEASURED]")
    print(f"FALSE-CLARIFY RATE       : {false_clarify_rate:>5.1f}% [MEASURED]")
    print(f"FALSE-EXECUTE RATE       : {false_execute_rate:>5.1f}% [MEASURED]")
    print("=" * 80)
    
    summary = {
        "total_cases": total_cases,
        "total_unambiguous": total_unambig,
        "total_ambiguous": total_ambig,
        "true_execute": te,
        "true_clarify": tc,
        "false_clarify": fc,
        "false_execute": fe,
        "wrong_tool": wt,
        "accuracy_pct": round(accuracy, 2),
        "false_clarify_rate_pct": round(false_clarify_rate, 2),
        "false_execute_rate_pct": round(false_execute_rate, 2)
    }
    
    # Save metric report
    out_path = WORKSPACE_ROOT / "reports" / "clarify_metrics.json"
    with open(out_path, "w", encoding="utf-8") as f_out:
        json.dump(summary, f_out, indent=2)
    print(f"Metrics saved to: {out_path}")
    return summary


if __name__ == "__main__":
    run_evaluation()
