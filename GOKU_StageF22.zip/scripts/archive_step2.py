import os
import shutil
import zipfile

repo_root = os.path.abspath(".")
archive_dir = os.path.abspath("../GOKU_ARCHIVE")
os.makedirs(archive_dir, exist_ok=True)

targets = ["backups", "user-data", "scratch"]
zip_path = os.path.join(archive_dir, "goku_baseline_archive.zip")

print(f"Creating zip at {zip_path}...")
with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
    for target in targets:
        target_path = os.path.join(repo_root, target)
        if os.path.exists(target_path):
            print(f"Adding {target} to zip...")
            for root, dirs, files in os.walk(target_path):
                for f in files:
                    full_p = os.path.join(root, f)
                    rel_p = os.path.relpath(full_p, repo_root)
                    zf.write(full_p, rel_p)

    # Also collect any __pycache__ outside those folders
    print("Collecting and archiving __pycache__ dirs...")
    pycache_count = 0
    for root, dirs, files in os.walk(repo_root):
        if "__pycache__" in dirs:
            py_dir = os.path.join(root, "__pycache__")
            for f in os.listdir(py_dir):
                full_p = os.path.join(py_dir, f)
                if os.path.isfile(full_p):
                    rel_p = os.path.relpath(full_p, repo_root)
                    zf.write(full_p, rel_p)
            pycache_count += 1
    print(f"Archived {pycache_count} __pycache__ locations to zip.")

# Now move the target folders out of repo into archive_dir
for target in targets:
    src = os.path.join(repo_root, target)
    dst = os.path.join(archive_dir, target)
    if os.path.exists(src):
        if os.path.exists(dst):
            shutil.rmtree(dst)
        print(f"Moving {src} -> {dst}")
        shutil.move(src, dst)

# Now remove the pycaches from repo (they are zipped in archive)
for root, dirs, files in os.walk(repo_root, topdown=False):
    for d in dirs:
        if d == "__pycache__":
            py_dir = os.path.join(root, d)
            # Remove directory
            shutil.rmtree(py_dir, ignore_errors=True)

print("Step 2 archive and move completed successfully.")
