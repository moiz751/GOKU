"""
One-shot laptop check for the P0/P1/P2 work. Run once from the project folder:

    python scripts/p0_laptop_check.py

It changes nothing permanent, starts no background threads and writes reports/p0/laptop_report.json.
Send that JSON file back. Every item is PASS / FAIL / SKIP with the measured value (no guessing).
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
OUT = ROOT / "reports" / "p0"
results = []


def rec(name, status, detail=None):
    results.append({"check": name, "status": status, "detail": detail})
    print(f"[{status:4}] {name}: {detail if detail is not None else ''}")


def guard(name):
    def deco(fn):
        try:
            fn()
        except Exception as exc:
            rec(name, "FAIL", f"{type(exc).__name__}: {exc}")
        return fn
    return deco


@guard("hardware profile")
def _():
    from tools.hw_profile import get_hw_profile, apply_tier_defaults
    p = get_hw_profile(refresh=True, include_gpu=True)
    applied = apply_tier_defaults({})
    rec("hardware profile", "PASS", {"tier": p.get("tier"), "ram_total_mb": p.get("ram_total_mb"), "ram_free_mb": p.get("ram_available_mb_at_probe"),
                                       "cpu": p.get("cpu"), "gpu": p.get("gpu"), "env_it_would_set": applied})


@guard("resource monitor")
def _():
    from tools import resource_monitor as rm
    s = rm.sample(include_tree=True)
    rec("resource monitor", "PASS", {"sample": s, "pressure": rm.pressure_level(s.get("free_mb")) if isinstance(s, dict) else None})


@guard("budget (process tree)")
def _():
    from tools.budget_governor import tree_private_mb
    v = tree_private_mb()
    rec("budget (process tree)", "PASS" if v is not None else "SKIP", {"tree_private_mb": v, "ceiling_mb": 1100})


@guard("calculation engine")
def _():
    from brain import calc_engine as c
    cases = {"2+3*4": "14", "15% of 80": "12", "x^2-5x+6=0": "x = 2; x = 3", "12 km to m": "12000 m"}
    bad = {k: (c.calculate_from_text(k) or {}).get("display") for k, v in cases.items() if (c.calculate_from_text(k) or {}).get("display") != v}
    rec("calculation engine", "FAIL" if bad else "PASS", bad or "all sample calculations verified")


@guard("emergency stop hotkey")
def _():
    if sys.platform != "win32":
        return rec("emergency stop hotkey", "SKIP", "not Windows")
    import ctypes
    from tools import emergency_stop as es
    es.clear_stop()
    with es.hotkey_watch() as info:
        if not info.get("registered"):
            return rec("emergency stop hotkey", "FAIL", info)
        u = ctypes.windll.user32
        for vk, up in ((0x11, 0), (0x12, 0), (0x7B, 0), (0x7B, 2), (0x12, 2), (0x11, 2)):
            u.keybd_event(vk, 0, up, 0)
        t0 = time.time()
        while time.time() - t0 < 3 and not es.is_stop_requested():
            time.sleep(0.05)
        hit = es.is_stop_requested()
    es.clear_stop()
    rec("emergency stop hotkey", "PASS" if hit else "FAIL", {"stop_seen": hit, "latency_s": round(time.time() - t0, 2)})


@guard("crash recovery")
def _():
    import tempfile
    from tools import safe_state as ss
    d = Path(tempfile.mkdtemp())
    ss.save_checkpoint("t", {"step": 2}, state_dir=d)
    (d / "session.json").write_text(json.dumps({"pid": 99999999, "create_time": 1.0, "started": 1.0}))
    rep = ss.begin_session(state_dir=d, release_inputs=False)
    ok = rep["recovered"] and [t["task_id"] for t in rep["incomplete_tasks"]] == ["t"]
    rec("crash recovery", "PASS" if ok else "FAIL", {"recovered": rep["recovered"]})


@guard("idle cpu of main.py")
def _():
    try:
        import psutil
    except ImportError:
        return rec("idle cpu of main.py", "SKIP", "psutil missing")
    p = subprocess.Popen([sys.executable, str(ROOT / "main.py")], cwd=str(ROOT), stdin=subprocess.PIPE, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    try:
        time.sleep(15)  # let it start and block on input()
        if p.poll() is not None:
            return rec("idle cpu of main.py", "FAIL", f"main.py exited early with code {p.returncode} (it must wait at the prompt)")
        ps = psutil.Process(p.pid)
        ps.cpu_percent(None)
        time.sleep(10)
        cpu = ps.cpu_percent(None)
        tree = ps.memory_info().rss + sum(c.memory_info().rss for c in ps.children(recursive=True))
        rec("idle cpu of main.py", "PASS" if cpu < 3 else "FAIL", {"cpu_percent_10s": cpu, "tree_rss_mb": round(tree / 2**20, 1)})
    finally:
        p.kill()


@guard("new unit tests")
def _():
    r = subprocess.run([sys.executable, "-m", "pytest", "tests/test_p0_hw_profile.py", "tests/test_p0_resource_monitor.py", "tests/test_p0_workload_modes.py",
                        "tests/test_p0_emergency_stop.py", "tests/test_p0_safe_state.py", "tests/test_p0_integration.py", "tests/test_p2_calc_engine.py",
                        "tests/test_p2_reasoning_agent.py", "-q", "-p", "no:cacheprovider"], cwd=str(ROOT), capture_output=True, text=True, timeout=300)
    tail = (r.stdout.strip().splitlines() or [""])[-1]
    rec("new unit tests", "PASS" if r.returncode == 0 else "FAIL", tail)


OUT.mkdir(parents=True, exist_ok=True)
(OUT / "laptop_report.json").write_text(json.dumps({"time": time.strftime("%Y-%m-%d %H:%M:%S"), "platform": sys.platform, "python": sys.version, "results": results}, indent=1, default=str), encoding="utf-8")
print(f"\nReport written: {OUT / 'laptop_report.json'}  (send this file)")
