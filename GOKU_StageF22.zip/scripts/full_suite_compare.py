#!/usr/bin/env python3
"""scripts/full_suite_compare.py

Compares two GOKU full-suite execution summaries (summary_<timestamp>.json).
Identifies:
  - New failures (passed/skipped in before, failed in after)
  - Fixed tests (failed in before, passed in after)
  - Still failing (failed in both before and after)
  - Unrecorded failures (failures in after not present in config/known_failures.json)

Conforms to TASK S1-01 and docs/ANTIGRAVITY_RULES.md.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys
from typing import Any, Dict, List, Set


VALID_CATEGORIES = {
    "PRODUCTION BUG",
    "CAPABILITY GAP",
    "ENVIRONMENT",
    "OBSOLETE TEST",
}

FAILURE_STATUSES = {"FAIL", "ERROR", "TIMEOUT", "RAM_WAIT_TIMEOUT"}


def load_summary(path: str | Path) -> Dict[str, Any]:
    p = Path(path)
    if not p.is_file():
        raise FileNotFoundError(f"Summary file not found: {p}")
    with p.open("r", encoding="utf-8") as f:
        return json.load(f)


def load_known_failures(path: str | Path | None) -> List[Dict[str, Any]]:
    if path is None:
        path = Path("config") / "known_failures.json"
    p = Path(path)
    if not p.is_file():
        return []
    with p.open("r", encoding="utf-8") as f:
        data = json.load(f)
    if isinstance(data, list):
        return data
    if isinstance(data, dict):
        return data.get("failures", data.get("known_failures", []))
    return []


def extract_failures(summary: Dict[str, Any]) -> Dict[str, Dict[str, Any]]:
    """Extracts failure map from a summary dictionary.

    Returns a dict mapping failure_id -> detail_dict.
    failure_id is preferably 'file::test_name', falling back to 'file' if no
    granular test IDs are listed.
    """
    failures: Dict[str, Dict[str, Any]] = {}
    results = summary.get("results", [])

    for r in results:
        file_path = r.get("file", "")
        status = r.get("status", "")
        failed_ids = r.get("failed_test_ids", [])

        if status in FAILURE_STATUSES:
            if failed_ids:
                for fid in failed_ids:
                    failures[fid] = {
                        "file": file_path,
                        "test_id": fid,
                        "status": status,
                        "first_3_failure_lines": r.get("first_3_failure_lines", []),
                    }
            else:
                failures[file_path] = {
                    "file": file_path,
                    "test_id": file_path,
                    "status": status,
                    "first_3_failure_lines": r.get("first_3_failure_lines", []),
                }

    return failures


def compare_summaries(
    before_path: str | Path,
    after_path: str | Path,
    known_path: str | Path | None = None,
) -> Dict[str, Any]:
    """Compares before and after summaries, cross-referencing known failures."""
    before_data = load_summary(before_path)
    after_data = load_summary(after_path)
    known_data = load_known_failures(known_path)

    known_ids: Set[str] = set()
    for item in known_data:
        if isinstance(item, dict) and "id" in item:
            known_ids.add(item["id"])

    before_failures = extract_failures(before_data)
    after_failures = extract_failures(after_data)

    before_ids = set(before_failures.keys())
    after_ids = set(after_failures.keys())

    new_failure_ids = sorted(list(after_ids - before_ids))
    fixed_ids = sorted(list(before_ids - after_ids))
    still_failing_ids = sorted(list(before_ids & after_ids))

    unrecorded_ids = sorted([
        fid for fid in after_ids
        if fid not in known_ids and after_failures[fid]["file"] not in known_ids
    ])

    return {
        "before_path": str(before_path),
        "after_path": str(after_path),
        "known_path": str(known_path) if known_path else "config/known_failures.json",
        "counts": {
            "before_failures": len(before_ids),
            "after_failures": len(after_ids),
            "new_failures": len(new_failure_ids),
            "fixed": len(fixed_ids),
            "still_failing": len(still_failing_ids),
            "unrecorded_failures": len(unrecorded_ids),
        },
        "new_failures": [after_failures[fid] for fid in new_failure_ids],
        "fixed": [before_failures[fid] for fid in fixed_ids],
        "still_failing": [after_failures[fid] for fid in still_failing_ids],
        "unrecorded_failures": [after_failures[fid] for fid in unrecorded_ids],
    }


def format_report_markdown(comparison: Dict[str, Any]) -> str:
    lines = [
        "# Full Suite Comparison Report",
        "",
        f"- **Before**: `{comparison['before_path']}`",
        f"- **After**: `{comparison['after_path']}`",
        f"- **Known Failures File**: `{comparison['known_path']}`",
        "",
        "## Summary Counts",
        "",
        "| Metric | Count |",
        "|---|---|",
        f"| Before Total Failures | {comparison['counts']['before_failures']} |",
        f"| After Total Failures | {comparison['counts']['after_failures']} |",
        f"| **New Failures** | **{comparison['counts']['new_failures']}** |",
        f"| Fixed Tests | {comparison['counts']['fixed']} |",
        f"| Still Failing | {comparison['counts']['still_failing']} |",
        f"| **Unrecorded Failures** | **{comparison['counts']['unrecorded_failures']}** |",
        "",
    ]

    # New failures section
    lines.append("## New Failures")
    if comparison["new_failures"]:
        lines.append("| Test / File ID | Status | Failure Snippet |")
        lines.append("|---|---|---|")
        for nf in comparison["new_failures"]:
            snip = "<br>".join(nf.get("first_3_failure_lines", [])[:3]).replace("|", "\\|")
            lines.append(f"| `{nf['test_id']}` | `{nf['status']}` | {snip} |")
    else:
        lines.append("Zero new failures detected.")
    lines.append("")

    # Fixed section
    lines.append("## Fixed Tests")
    if comparison["fixed"]:
        lines.append("| Test / File ID | Previous Status |")
        lines.append("|---|---|")
        for fx in comparison["fixed"]:
            lines.append(f"| `{fx['test_id']}` | `{fx['status']}` |")
    else:
        lines.append("Zero fixed tests.")
    lines.append("")

    # Unrecorded failures section
    lines.append("## Unrecorded Failures")
    if comparison["unrecorded_failures"]:
        lines.append("These failures in `after` are NOT documented in `config/known_failures.json`:")
        lines.append("")
        lines.append("| ID | File | Status |")
        lines.append("|---|---|---|")
        for uf in comparison["unrecorded_failures"]:
            lines.append(f"| `{uf['test_id']}` | `{uf['file']}` | `{uf['status']}` |")
    else:
        lines.append("All current failures are documented in known failures.")
    lines.append("")

    return "\n".join(lines)


def main() -> int:
    parser = argparse.ArgumentParser(description="Compare two GOKU full-suite run summaries.")
    parser.add_argument("--before", required=True, help="Path to before summary JSON")
    parser.add_argument("--after", required=True, help="Path to after summary JSON")
    parser.add_argument("--known", default=None, help="Path to known_failures.json (default: config/known_failures.json)")
    parser.add_argument("--markdown", action="store_true", help="Print output in Markdown format")

    args = parser.parse_args()

    try:
        comp = compare_summaries(args.before, args.after, args.known)
    except Exception as exc:
        print(f"[ERROR] Failed to compare summaries: {exc}", file=sys.stderr)
        return 2

    if args.markdown:
        print(format_report_markdown(comp))
    else:
        print("================================================================================")
        print("                          FULL SUITE RUN COMPARISON                             ")
        print("================================================================================")
        print(f"Before Summary: {comp['before_path']}")
        print(f"After Summary : {comp['after_path']}")
        print("--------------------------------------------------------------------------------")
        print(f"Before Failures      : {comp['counts']['before_failures']}")
        print(f"After Failures       : {comp['counts']['after_failures']}")
        print(f"New Failures         : {comp['counts']['new_failures']}")
        print(f"Fixed Tests          : {comp['counts']['fixed']}")
        print(f"Still Failing        : {comp['counts']['still_failing']}")
        print(f"Unrecorded Failures  : {comp['counts']['unrecorded_failures']}")
        print("================================================================================")

        if comp["new_failures"]:
            print("\n>>> NEW FAILURES:")
            for nf in comp["new_failures"]:
                print(f"  - [{nf['status']}] {nf['test_id']}")
                for line in nf.get("first_3_failure_lines", [])[:3]:
                    print(f"      {line}")

        if comp["fixed"]:
            print("\n>>> FIXED TESTS:")
            for fx in comp["fixed"]:
                print(f"  - [WAS {fx['status']}] {fx['test_id']}")

        if comp["unrecorded_failures"]:
            print("\n>>> UNRECORDED FAILURES (Not in config/known_failures.json):")
            for uf in comp["unrecorded_failures"]:
                print(f"  - [{uf['status']}] {uf['test_id']}")

    return 1 if comp["counts"]["new_failures"] > 0 else 0


if __name__ == "__main__":
    sys.exit(main())

