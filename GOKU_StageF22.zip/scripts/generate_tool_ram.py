import json
import sys
from pathlib import Path

# Ensure root in sys.path
root = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(root))

from tools.registry import discover_tools, TOOLS

def generate_tool_ram():
    discover_tools()
    
    # Load TOOL_RAM_MAP.json
    map_path = root / "reports" / "budget" / "TOOL_RAM_MAP.json"
    with open(map_path, "r", encoding="utf-8") as f:
        ram_map = json.load(f)

    # Base classifications
    heavy_tools = {
        "run_autonomous_agent": 250,
        "answer_document_question": 200,
        "read_document": 75,
        "get_document_map": 60,
        "find_text_on_screen": 60,
        "click_element_by_text": 60,
        "engage_continuous_game_loop": 60,
        "remediate_wifi_stack": 40,
        "deep_scan_wifi_spectrum": 40,
    }

    medium_tools = {
        "capture_screen": 15,
        "capture_screen_context": 25,
        "take_screenshot": 15,
        "detect_game_object": 25,
        "detect_game_scene": 15,
        "wait_for_visual_stability": 20,
        "inspect_screen": 20,
        "click_ui_element": 25,
        "find_and_interact": 25,
        "observe_and_scroll_until": 25,
        "scroll_and_inspect": 25,
        "scroll_active_window": 15,
        "get_bluetooth_device_status": 20,
        "get_bluetooth_devices": 20,
        "get_bluetooth_status": 20,
        "get_connected_bluetooth_devices": 20,
        "get_connected_device_summary": 20,
        "get_connected_devices": 20,
        "get_paired_bluetooth_devices": 20,
        "get_pnp_devices": 20,
        "get_usb_devices": 20,
        "audit_wifi_hardware_and_services": 20,
        "find_duplicate_files": 35,
        "get_largest_files": 20,
        "search_files_intelligent": 25,
        "read_file": 20,
        "extract_archive": 25,
        "copy_folder": 15,
        "diagnose_system": 15,
        "diagnose_network_health": 15,
        "scan_computer": 20,
        "audit_and_reclaim_ram": 15,
        "record_task_evidence_and_report": 15,
    }

    output = {}
    for tool_name in sorted(TOOLS.keys()):
        if tool_name in heavy_tools:
            output[tool_name] = {
                "ram_mb": heavy_tools[tool_name],
                "cpu_class": "heavy",
                "source": "estimate"
            }
        elif tool_name in medium_tools:
            output[tool_name] = {
                "ram_mb": medium_tools[tool_name],
                "cpu_class": "medium",
                "source": "estimate"
            }
        else:
            output[tool_name] = {
                "ram_mb": 5,
                "cpu_class": "light",
                "source": "estimate"
            }

    dest = root / "config" / "tool_ram.json"
    with open(dest, "w", encoding="utf-8") as f:
        json.dump(output, f, indent=2)

    print(f"Regenerated {dest} with {len(output)} tools.")

if __name__ == "__main__":
    generate_tool_ram()
