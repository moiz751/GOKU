"""Repo-wide static audit (stdlib only, read-only). Output: data/repo_audit.json + a short text summary.
Checks: syntax of every .py, module inventory per package, who imports whom (static imports + string references such as
importlib/__import__/'brain.x'), unreferenced (dead/unwired) modules, duplicate module basenames across packages,
duplicate function bodies (normalised AST hash), stray files in the project root, stale 'retired'/'scratch' dirs.
It never claims a module 'works' - only whether it is wired, compiles and has a test referencing it."""
from __future__ import annotations
import warnings; warnings.filterwarnings('ignore')
import ast, hashlib, json, os, re, sys
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
PKGS = ["brain", "executor", "command_layer", "tools", "perception", "security", "memory", "config", "scripts"]
SKIP = {"knowledge", "retired", "backups", "_to_delete", "scratch", "__pycache__", "data", "evidence", "logs", "state", "venv", ".git"}


def pyfiles(base: Path):
    for p in base.rglob("*.py"):
        if not (set(p.relative_to(ROOT).parts) & SKIP):
            yield p


def modname(p: Path) -> str:
    return ".".join(p.relative_to(ROOT).with_suffix("").parts).replace(".__init__", "")


def main() -> int:
    mods, syntax, funcs = {}, [], defaultdict(list)
    for pk in PKGS + ["tests"]:
        b = ROOT / pk
        if not b.is_dir():
            continue
        for p in pyfiles(b):
            src = p.read_text(encoding="utf-8", errors="replace")
            try:
                tree = ast.parse(src)
            except SyntaxError as e:
                syntax.append({"file": str(p.relative_to(ROOT)), "err": str(e)})
                continue
            m = modname(p)
            mods[m] = {"path": str(p.relative_to(ROOT)), "lines": src.count("\n") + 1, "src": src}
            for n in ast.walk(tree):
                if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and len(n.body) >= 4 and not pk == "tests":
                    h = hashlib.md5(ast.dump(ast.Module(body=n.body, type_ignores=[])).encode()).hexdigest()
                    funcs[h].append(f"{m}:{n.name}")
    main_src = (ROOT / "main.py").read_text(encoding="utf-8", errors="replace") if (ROOT / "main.py").exists() else ""
    allsrc = {m: v["src"] for m, v in mods.items()}
    allsrc["main"] = main_src
    refs = defaultdict(set)
    known = set(mods)
    strrx = re.compile(r"[\"']((?:brain|executor|command_layer|tools|perception|security|memory|config)(?:\.\w+)+)[\"']")
    for m, s in allsrc.items():
        used = set()
        try:
            tree = ast.parse(s)
        except Exception:
            continue
        for n in ast.walk(tree):
            if isinstance(n, ast.Import):
                for a_ in n.names:
                    used.add(a_.name)
            elif isinstance(n, ast.ImportFrom):
                base_ = n.module or ""
                if n.level:
                    parts = m.split(".")[:-n.level] if "." in m else []
                    base_ = ".".join(parts + ([base_] if base_ else []))
                used.add(base_)
                for a_ in n.names:
                    used.add(base_ + "." + a_.name if base_ else a_.name)
        used |= set(strrx.findall(s))
        for u in used:
            while u:
                if u in known and u != m:
                    refs[u].add(m)
                u = u.rsplit(".", 1)[0] if "." in u else ""
    prod = {m for m in mods if not m.startswith("tests.")}
    unref, test_only = [], []
    for m in sorted(prod):
        if m.split(".")[-1] in ("__init__", "settings") or m.startswith("scripts."):
            continue
        users = refs.get(m, set())
        if not users:
            unref.append(m)
        elif all(u.startswith("tests.") for u in users):
            test_only.append(m)
    base = defaultdict(list)
    for m in prod:
        base[m.split(".")[-1]].append(m)
    dup_names = {k: v for k, v in base.items() if len(v) > 1 and k != "__init__"}
    dup_funcs = [v for v in funcs.values() if len({x.split(":")[0] for x in v}) > 1]
    stray = sorted(x.name for x in ROOT.iterdir() if x.is_file() and not x.name.endswith((".py", ".md", ".txt", ".ini", ".json", ".html")) or
                   (x.is_file() and re.search(r"^(?:[A-Z]:|test|created|scratch|trace|test_relative)", x.name)))
    out = {"modules": len(prod), "tests": len([m for m in mods if m.startswith("tests.")]), "syntax_errors": syntax, "unreferenced": unref,
           "referenced_only_by_tests": test_only, "duplicate_basenames": dup_names, "duplicate_function_bodies": dup_funcs[:80], "stray_root_files": stray}
    (ROOT / "data").mkdir(exist_ok=True)
    (ROOT / "data" / "repo_audit.json").write_text(json.dumps(out, indent=1), encoding="utf-8")
    print(f"modules {out['modules']} | tests {out['tests']} | syntax errors {len(syntax)} | unreferenced {len(unref)} | test-only {len(test_only)} | dup basenames {len(dup_names)} | dup function groups {len(dup_funcs)} | stray root {len(stray)}")
    return 1 if syntax else 0


if __name__ == "__main__":
    sys.exit(main())
