"""
scripts/live_notepad_e2e.py - Live End-to-End Notepad Closed Loop Test Suite.
Runs 10 scenarios exercising:
1. Normal new file save via GUI
2. Target exists and empty -> policy branch: overwrite_empty_file
3. Target exists and created by this task -> policy branch: overwrite_task_created_file
4. Target exists and non-empty with user approval -> policy branch: overwrite_user_approved
5. Target exists and non-empty without approval -> policy branch: save_as_numbered_copy
6. Python fast path (gui_required=False, temp file + os.replace)
7. Multiline text with CRLF line ending normalization
8. Slow start under CPU load (testing dynamic backoff wait_for)
9. Target file locked by another app (exclusive lock, error detection & retry)
10. Typing verification & clipboard paste fallback

Prints a real per-run observation table.
GATE requirement: 10/10 with raw log; for overwrite cases, log explicitly
names which policy branch fired and why.
"""
from __future__ import annotations

from pathlib import Path
import shutil
import sys
import threading
import time
from typing import Any

REPO_ROOT = Path(__file__).resolve().parent.parent
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from executor.closed_loop import execute_closed_loop

TEST_DIR = Path("scratch/e2e_notepad")


def setup_clean_env() -> None:
    """Prepares clean scratch test directory."""
    if TEST_DIR.exists():
        shutil.rmtree(TEST_DIR, ignore_errors=True)
    TEST_DIR.mkdir(parents=True, exist_ok=True)


def simulate_cpu_load(duration_sec: float) -> threading.Thread:
    """Spins worker threads to simulate CPU load without blocking."""
    stop_event = threading.Event()

    def _worker():
        while not stop_event.is_set():
            _ = [i * i for i in range(1000)]
            time.sleep(0.001)

    t = threading.Thread(target=_worker, daemon=True)
    t.start()
    return t


def run_scenario(
    index: int,
    name: str,
    action_cfg: dict[str, Any],
    setup_fn: Any = None,
    teardown_fn: Any = None,
) -> dict[str, Any]:
    print(f"\n[{index}/10] Starting: {name} ...")
    setup_data = setup_fn() if setup_fn else None

    start_time = time.time()
    res = execute_closed_loop(action_cfg)
    elapsed = time.time() - start_time

    if teardown_fn:
        teardown_fn(setup_data)

    verdict = res.get("verdict", "FAILED")
    branch = res.get("policy_branch") or "N/A (no popup)"
    rationale = res.get("policy_rationale") or "Standard flow without policy intervention."
    final_file = res.get("final_file", action_cfg.get("target_file"))

    print(f"       Verdict: {verdict} ({elapsed:.2f}s)")
    if res.get("policy_branch"):
        print(f"       Policy Branch Fired: {branch}")
        print(f"       Branch Rationale:    {rationale}")
    if res.get("error"):
        print(f"       Error:               {res['error']}")
    print(f"       Final File on Disk:  {final_file}")

    return {
        "index": index,
        "name": name,
        "method": action_cfg.get("gui_required", True) and "GUI" or "PYTHON",
        "target": Path(action_cfg["target_file"]).name,
        "final": Path(final_file).name,
        "branch": branch,
        "rationale": rationale,
        "verdict": verdict,
        "elapsed": round(elapsed, 2),
    }


def main() -> int:
    setup_clean_env()
    results: list[dict[str, Any]] = []

    print("=" * 80)
    print("TASK P4: Live Notepad Closed-Loop E2E Suite (10 Scenarios)")
    print("Enforcing: observe -> decide -> act -> observe -> postcondition")
    print("=" * 80)

    # --------------------------------------------------------------------------
    # Scenario 1: Clean GUI Save As (New File)
    # --------------------------------------------------------------------------
    target_1 = TEST_DIR / "run_01_new.txt"
    res1 = run_scenario(
        1,
        "Clean GUI Save As (New File)",
        {
            "target_file": str(target_1),
            "text_to_type": "Run 1: Clean GUI creation.",
            "gui_required": True,
        },
    )
    results.append(res1)

    # --------------------------------------------------------------------------
    # Scenario 2: Target exists and is empty (0 bytes) -> overwrite_empty_file
    # --------------------------------------------------------------------------
    target_2 = TEST_DIR / "run_02_empty.txt"
    target_2.touch()
    assert target_2.stat().st_size == 0
    res2 = run_scenario(
        2,
        "Target Exists and Empty (0 bytes)",
        {
            "target_file": str(target_2),
            "text_to_type": "Run 2: Overwrote empty file successfully.",
            "gui_required": True,
            "user_allow_overwrite": False,
        },
    )
    results.append(res2)

    # --------------------------------------------------------------------------
    # Scenario 3: Target created by this task in session -> overwrite_task_created_file
    # --------------------------------------------------------------------------
    target_3 = TEST_DIR / "run_03_task_file.txt"
    target_3.write_text("Created earlier in this task", encoding="utf-8")
    res3 = run_scenario(
        3,
        "Target Created by this Task",
        {
            "target_file": str(target_3),
            "text_to_type": "Run 3: Overwrote task-created file.",
            "gui_required": True,
            "task_created_files": [str(target_3)],
            "user_allow_overwrite": False,
        },
    )
    results.append(res3)

    # --------------------------------------------------------------------------
    # Scenario 4: Target exists, non-empty, user approved -> overwrite_user_approved
    # --------------------------------------------------------------------------
    target_4 = TEST_DIR / "run_04_user_approved.txt"
    target_4.write_text("Existing valuable user data", encoding="utf-8")
    res4 = run_scenario(
        4,
        "Target Non-Empty with User Approval",
        {
            "target_file": str(target_4),
            "text_to_type": "Run 4: Overwrote with explicit user approval.",
            "gui_required": True,
            "user_allow_overwrite": True,
        },
    )
    results.append(res4)

    # --------------------------------------------------------------------------
    # Scenario 5: Target exists, non-empty, NO approval -> save_as_numbered_copy
    # --------------------------------------------------------------------------
    target_5 = TEST_DIR / "run_05_protected.txt"
    target_5.write_text("Protected non-empty user content - DO NOT OVERWRITE", encoding="utf-8")
    res5 = run_scenario(
        5,
        "Target Non-Empty WITHOUT Approval (Numbered Copy)",
        {
            "target_file": str(target_5),
            "text_to_type": "Run 5: Saved safely into numbered copy.",
            "gui_required": True,
            "user_allow_overwrite": False,
            "task_created_files": [],
        },
    )
    results.append(res5)

    # --------------------------------------------------------------------------
    # Scenario 6: Python fast path (gui_required=False, temp + os.replace)
    # --------------------------------------------------------------------------
    target_6 = TEST_DIR / "run_06_fast_path.txt"
    res6 = run_scenario(
        6,
        "Python Fast Path (Atomic temp + os.replace)",
        {
            "target_file": str(target_6),
            "text_to_type": "Run 6: Atomic Python fast-path write.",
            "gui_required": False,
        },
    )
    results.append(res6)

    # --------------------------------------------------------------------------
    # Scenario 7: Multiline text with CRLF line ending normalization
    # --------------------------------------------------------------------------
    target_7 = TEST_DIR / "run_07_multiline.txt"
    multiline_text = "Line 1: Alpha\r\nLine 2: Beta\nLine 3: Gamma\r\nLine 4: Delta"
    res7 = run_scenario(
        7,
        "Multiline Text with CRLF Normalization",
        {
            "target_file": str(target_7),
            "text_to_type": multiline_text,
            "gui_required": True,
        },
    )
    results.append(res7)

    # --------------------------------------------------------------------------
    # Scenario 8: Slow start under simulated CPU load (wait_for backoff)
    # --------------------------------------------------------------------------
    target_8 = TEST_DIR / "run_08_cpu_load.txt"
    load_thread = simulate_cpu_load(3.0)
    try:
        res8 = run_scenario(
            8,
            "Slow Start Under CPU Load (Dynamic Backoff)",
            {
                "target_file": str(target_8),
                "text_to_type": "Run 8: Launched successfully under CPU load.",
                "gui_required": True,
            },
        )
        results.append(res8)
    finally:
        del load_thread

    # --------------------------------------------------------------------------
    # Scenario 9: Target file locked by another app (exclusive lock -> retry)
    # --------------------------------------------------------------------------
    target_9 = TEST_DIR / "run_09_locked.txt"
    target_9.write_text("Original locked data", encoding="utf-8")

    def _lock_setup():
        import msvcrt
        f = open(target_9, "r+")
        msvcrt.locking(f.fileno(), msvcrt.LK_NBLCK, 50)
        return f

    def _lock_teardown(f):
        if f:
            try:
                f.close()
            except Exception:
                pass

    res9 = run_scenario(
        9,
        "Target File Locked by Another App (Policy Protection)",
        {
            "target_file": str(target_9),
            "text_to_type": "Run 9: Attempted overwrite blocked by lock.",
            "gui_required": True,
            "user_allow_overwrite": True,  # User approved, but OS lock prevented it
            "allow_locked_file": True,
        },
        setup_fn=_lock_setup,
        teardown_fn=_lock_teardown,
    )
    results.append(res9)

    # --------------------------------------------------------------------------
    # Scenario 10: Typing Verification & Strategy Fallback
    # --------------------------------------------------------------------------
    target_10 = TEST_DIR / "run_10_typing.txt"
    res10 = run_scenario(
        10,
        "Typing Verification & Focus Guard",
        {
            "target_file": str(target_10),
            "text_to_type": "Run 10: Closed loop typing verified by perception.",
            "gui_required": True,
        },
    )
    results.append(res10)

    # ==========================================================================
    # Final Table Output from Real Observations
    # ==========================================================================
    print("\n" + "=" * 115)
    print(f"{'Run':<4} | {'Scenario Name':<38} | {'Method':<7} | {'Final File':<20} | {'Policy Branch Fired':<30} | {'Status'}")
    print("-" * 115)
    passed_count = 0
    for r in results:
        status = r["verdict"]
        if status == "PASSED":
            passed_count += 1
        print(
            f"{r['index']:<4} | {r['name'][:38]:<38} | {r['method']:<7} | {r['final']:<20} | {r['branch'][:30]:<30} | {status}"
        )
    print("=" * 115)

    print(f"\nGATE SUMMARY: {passed_count}/10 runs passed.")
    if passed_count == 10:
        print("GATE STATUS: PASSED")
        return 0
    else:
        print("GATE STATUS: FAILED")
        return 1


if __name__ == "__main__":
    sys.exit(main())
