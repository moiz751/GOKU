"""
scripts/mutation_sanity.py - Mutation Sanity Engine for Critical GOKU Components
Follows Prompt Task P9 Item 3:
"Mutation sanity: for 15 critical functions (verifier, oracle checks, firewall, popup policy,
unique_path, router thresholds) flip the logic and show at least one test fails. Save the raw output."
"""
from __future__ import annotations

import json
import os
from pathlib import Path
import subprocess
import sys
import time
from typing import Any, Dict, List

ROOT_DIR = Path(__file__).resolve().parent.parent
REPORTS_DIR = ROOT_DIR / "reports"
OUTPUT_JSON = REPORTS_DIR / "mutation_sanity.json"

# List of 15 critical functions across 6 key subsystems
MUTATIONS = [
    # Area 1: Verifier (3 functions)
    {
        "id": "mutant_01_verifier_verify",
        "area": "verifier",
        "module": "executor.verifier",
        "function": "verify",
        "test_target": "tests/test_verifier.py::test_verifier_create_folder_created",
        "mutation_type": "invert_boolean",
    },
    {
        "id": "mutant_02_verifier_post_recovery",
        "area": "verifier",
        "module": "executor.verifier",
        "function": "verify_post_recovery",
        "test_target": "tests/test_bullet23_failure_recovery.py::test_dim4_02_verify_post_recovery_filesystem_exists",
        "mutation_type": "invert_dict_verified",
    },
    {
        "id": "mutant_03_verifier_process_liveness",
        "area": "verifier",
        "module": "executor.verifier",
        "function": "verify_process_liveness",
        "test_target": "tests/test_cross_app_workflows.py::test_verifier_suppresses_crash_for_voluntarily_closed_app",
        "mutation_type": "invert_process_liveness",
    },

    # Area 2: Oracle checks (5 functions)
    {
        "id": "mutant_04_oracle_check_file",
        "area": "oracle checks",
        "module": "executor.truth_oracle",
        "function": "check_file",
        "test_target": "tests/test_truth_layer.py::test_check_file_existing_file",
        "mutation_type": "invert_observation",
    },
    {
        "id": "mutant_05_oracle_check_process",
        "area": "oracle checks",
        "module": "executor.truth_oracle",
        "function": "check_process",
        "test_target": "tests/test_truth_layer.py::test_check_process_running_self",
        "mutation_type": "invert_observation",
    },
    {
        "id": "mutant_06_oracle_check_window",
        "area": "oracle checks",
        "module": "executor.truth_oracle",
        "function": "check_window",
        "test_target": "tests/test_truth_layer.py::test_check_window_existing_app",
        "mutation_type": "invert_observation",
    },
    {
        "id": "mutant_07_oracle_check_saved_file",
        "area": "oracle checks",
        "module": "executor.truth_oracle",
        "function": "check_saved_file",
        "test_target": "tests/test_task_contracts.py::TestStepContractContractsAndRegistry::test_save_file_contract_disk_verification",
        "mutation_type": "invert_observation",
    },
    {
        "id": "mutant_08_oracle_check_dialog",
        "area": "oracle checks",
        "module": "executor.truth_oracle",
        "function": "check_dialog",
        "test_target": "tests/test_truth_layer.py::test_check_dialog_no_dialog_on_desktop",
        "mutation_type": "invert_observation",
    },

    # Area 3: Firewall (3 functions)
    {
        "id": "mutant_09_firewall_validate_tool",
        "area": "firewall",
        "module": "command_layer.firewall",
        "function": "validate_tool_against_firewall",
        "test_target": "tests/test_rollback_and_path_fixes.py::test_compound_firewall_allows_hotkey_with_diagnostics",
        "mutation_type": "invert_firewall_tuple",
    },
    {
        "id": "mutant_10_firewall_pre_execution",
        "area": "firewall",
        "module": "command_layer.firewall",
        "function": "pre_execution_semantic_check",
        "test_target": "tests/test_router_hardening_and_safety.py::test_firewall_pre_execution_system32_drivers",
        "mutation_type": "invert_firewall_tuple",
    },
    {
        "id": "mutant_11_firewall_bypass_guard",
        "area": "firewall",
        "module": "command_layer.firewall_bypass_guard",
        "function": "inspect_firewall_bypass",
        "test_target": "tests/test_firewall_bypass_adversarial.py::test_bypass_format_blocked",
        "mutation_type": "invert_firewall_tuple",
    },

    # Area 4: Popup policy (2 functions)
    {
        "id": "mutant_12_popup_evaluate_policy",
        "area": "popup policy",
        "module": "perception.popup_handler",
        "function": "evaluate_dialog_policy",
        "test_target": "tests/test_popup_policy.py::test_save_changes_prompt_intent_save",
        "mutation_type": "invert_dialog_policy",
    },
    {
        "id": "mutant_13_popup_get_numbered_filename",
        "area": "popup policy",
        "module": "perception.popup_handler",
        "function": "get_numbered_filename",
        "test_target": "tests/test_popup_policy.py::test_get_numbered_filename",
        "mutation_type": "invert_numbered_filename",
    },

    # Area 5: Unique path (1 function)
    {
        "id": "mutant_14_unique_path",
        "area": "unique_path",
        "module": "tools.utils.path_safety",
        "function": "unique_path",
        "test_target": "tests/test_p5_knowledge.py::test_p5_item4_unique_path_handling",
        "mutation_type": "invert_unique_path",
    },

    # Area 6: Router thresholds (1 function)
    {
        "id": "mutant_15_router_threshold_predicate",
        "area": "router thresholds",
        "module": "command_layer.semantic_model",
        "function": "ConditionalPredicate.evaluate",
        "test_target": "tests/test_bullet19_conditional_decision_making.py::test_dim1_01_numeric_cpu_greater_than_true",
        "mutation_type": "invert_predicate_eval",
    },
]


def run_targeted_test(test_target: str, env_vars: dict | None = None) -> tuple[int, str]:
    """Runs a single targeted test using pytest and returns (exit_code, output)."""
    cmd = [sys.executable, "-m", "pytest", test_target, "-v", "--tb=short"]
    env = os.environ.copy()
    env["PYTHONPATH"] = str(ROOT_DIR)
    if env_vars:
        env.update(env_vars)
    res = subprocess.run(cmd, cwd=str(ROOT_DIR), env=env, capture_output=True, text=True, timeout=60)
    output = (res.stdout or "") + "\n" + (res.stderr or "")
    return res.returncode, output


def main():
    print("=" * 70)
    print("MUTATION SANITY VERIFICATION ENGINE (Task P9 Item 3)")
    print(f"Testing 15 critical functions across 6 key architectural subsystems")
    print("=" * 70)

    REPORTS_DIR.mkdir(parents=True, exist_ok=True)
    results = []
    total_mutants = len(MUTATIONS)
    mutants_killed = 0

    for idx, spec in enumerate(MUTATIONS, 1):
        m_id = spec["id"]
        area = spec["area"]
        mod_name = spec["module"]
        func_name = spec["function"]
        target = spec["test_target"]
        m_type = spec["mutation_type"]

        print(f"\n[{idx:02d}/{total_mutants:02d}] Subsystem: {area.upper()} | Function: {mod_name}.{func_name}")
        print(f"   Target test: {target}")

        # Step A: Baseline check (must PASS unmutated)
        base_code, base_out = run_targeted_test(target, env_vars={})
        if base_code != 0:
            print(f"   [BASELINE FAILED] Target test did not pass in unmutated state! Output:\n{base_out[-400:]}")
            results.append({
                "id": m_id,
                "area": area,
                "function": f"{mod_name}.{func_name}",
                "target_test": target,
                "baseline_passed": False,
                "mutant_killed": False,
                "exit_code_mutated": -1,
                "verdict": "FAILED",
                "reason": "Baseline test failed before mutation",
            })
            continue

        # Step B: Run with inverted logic mutant enabled via GOKU_MUTATION_SANITY
        mutant_env = {
            "GOKU_MUTATION_ACTIVE": "1",
            "GOKU_MUTANT_TARGET": f"{mod_name}.{func_name}",
            "GOKU_MUTATION_TYPE": m_type,
        }
        mut_code, mut_out = run_targeted_test(target, env_vars=mutant_env)

        # A mutant is KILLED if pytest exits with code != 0 (test failed as expected)
        killed = (mut_code != 0)
        status = "PASSED" if killed else "FAILED"
        if killed:
            mutants_killed += 1
            print(f"   [MUTANT KILLED] Test failed on mutated logic as expected! (exit code: {mut_code})")
        else:
            print(f"   [MUTANT SURVIVED] Test unexpectedly passed with inverted logic!")

        # Extract last 10 lines of failure trace
        trace_lines = [l for l in mut_out.splitlines() if l.strip()]
        snippet = "\n".join(trace_lines[-12:]) if trace_lines else ""

        results.append({
            "id": m_id,
            "area": area,
            "function": f"{mod_name}.{func_name}",
            "target_test": target,
            "baseline_passed": True,
            "mutant_killed": killed,
            "exit_code_mutated": mut_code,
            "verdict": status,
            "raw_failure_snippet": snippet,
        })

    # Summary
    summary = {
        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
        "total_critical_functions": total_mutants,
        "mutants_killed": mutants_killed,
        "mutants_survived": total_mutants - mutants_killed,
        "pass_rate_pct": round((mutants_killed / total_mutants) * 100.0, 1),
        "results": results,
    }

    OUTPUT_JSON.write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print("\n" + "=" * 70)
    print(f"MUTATION SANITY RESULTS: {mutants_killed}/{total_mutants} KILLED ({summary['pass_rate_pct']}%)")
    print(f"Full report saved to: {OUTPUT_JSON}")
    print("=" * 70)

    if mutants_killed == total_mutants:
        sys.exit(0)
    else:
        sys.exit(1)


if __name__ == "__main__":
    main()
