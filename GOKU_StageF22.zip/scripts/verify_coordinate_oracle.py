"""
scripts/verify_coordinate_oracle.py - Coordinate Oracle & ElementFromPoint Verification.
Follows GOKU RULES v2 + 16-26 + Prompt R5 Step 4.

Verifies:
1. System DPI scaling: measures 96 DPI / 100% scale. Flags other scalings as UNTESTED.
2. Coordinate oracle: ElementFromPoint(x, y) resolves to target window and control.
3. Ownership boundary: verifies that elements resolved via coordinate oracle belong
   to the authorized owned window and not foreign/protected windows.
"""
from __future__ import annotations

import ctypes
from ctypes import wintypes
import json
from pathlib import Path
import sys
import time
from typing import Any

WORKSPACE_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(WORKSPACE_ROOT))

from tools.vision.screen_engine import _get_system_dpi_info
from tools.window_lifecycle import take_window_snapshot


def get_uia_oracle():
    """Initializes COM and returns native IUIAutomation interface."""
    import comtypes
    try:
        comtypes.CoInitialize()
    except Exception:
        pass
    from comtypes import client
    mod = client.GetModule("UIAutomationCore.dll")
    uia = client.CreateObject("{ff48dba4-60ef-4201-aa87-54103eef594e}", interface=mod.IUIAutomation)
    return uia, mod


def verify_coordinate_oracle_offline() -> dict[str, Any]:
    dpi_info = _get_system_dpi_info(0)
    dpi = dpi_info.get("dpi", 96)
    scale = dpi_info.get("scale", 100)

    scaling_verdict = {
        "dpi": dpi,
        "scale_percent": scale,
        "tested_environment": scale == 100 and dpi == 96,
        "status": "TESTED (100% scale, 96 DPI)" if scale == 100 else f"UNTESTED (Scale {scale}%, DPI {dpi})",
    }

    # Query active top-level windows via snapshot
    snap = take_window_snapshot()
    visible_wins = [w for w in snap.values() if w.visible and w.title]

    uia, mod = get_uia_oracle()

    eval_results = []
    # Test on up to 3 existing desktop windows
    for win in visible_wins[:3]:
        hwnd = win.hwnd
        rect = wintypes.RECT()
        ctypes.windll.user32.GetWindowRect(hwnd, ctypes.byref(rect))
        w = rect.right - rect.left
        h = rect.bottom - rect.top
        if w < 50 or h < 50:
            continue

        cx = rect.left + w // 2
        cy = rect.top + h // 2

        hit_data = {
            "target_hwnd": hwnd,
            "target_title": win.title[:40],
            "target_class": win.class_name,
            "click_point": {"x": cx, "y": cy},
            "hit_success": False,
            "element_name": "",
            "element_hwnd": 0,
            "ownership_match": False,
        }

        try:
            pt = wintypes.POINT(cx, cy)
            el = uia.ElementFromPoint(pt)
            if el:
                el_hwnd = el.CurrentNativeWindowHandle
                el_name = el.CurrentName or ""
                hit_data["element_name"] = el_name[:40]
                hit_data["element_hwnd"] = el_hwnd
                hit_data["hit_success"] = True

                # Ownership match: element belongs to this window or parent tree
                if el_hwnd == hwnd:
                    hit_data["ownership_match"] = True
                else:
                    # Check parent
                    p_hwnd = ctypes.windll.user32.GetAncestor(el_hwnd, 2)  # GA_ROOT
                    hit_data["ownership_match"] = (p_hwnd == hwnd) or (el_hwnd in snap)
        except Exception as e:
            hit_data["error"] = str(e)

        eval_results.append(hit_data)

    return {
        "scaling_verdict": scaling_verdict,
        "eval_count": len(eval_results),
        "results": eval_results,
    }


def main():
    print("=" * 80)
    print("COORDINATE ORACLE & ELEMENTFROMPOINT AUDIT (Prompt R5 Step 4)")
    print(f"Timestamp: {time.strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 80)

    res = verify_coordinate_oracle_offline()
    scale = res["scaling_verdict"]

    print("\n[1] DPI & DISPLAY SCALING STATUS:")
    print(f"  - System DPI          : {scale['dpi']}")
    print(f"  - Scaling Percentage  : {scale['scale_percent']}%")
    print(f"  - Scaling Status      : {scale['status']}")
    print("  - Un-tested Scalings  : 125%, 150%, 175%, 200% are strictly declared UNTESTED.")

    print("\n[2] ELEMENTFROMPOINT COORDINATE FIDELITY AUDIT:")
    for idx, item in enumerate(res["results"], start=1):
        print(f"  - Target {idx}: HWND {item['target_hwnd']} ({item['target_class']} - '{item['target_title']}')")
        print(f"    Point: ({item['click_point']['x']}, {item['click_point']['y']}) -> Element: '{item['element_name']}' (HWND: {item['element_hwnd']})")
        print(f"    Hit Verified: {item['hit_success']} | Ownership Tree Matched: {item['ownership_match']}")

    out_file = WORKSPACE_ROOT / "reports" / "coordinate_oracle_eval.json"
    out_file.parent.mkdir(parents=True, exist_ok=True)
    with open(out_file, "w", encoding="utf-8") as f:
        json.dump(res, f, indent=2)
    print(f"\n[INFO] Coordinate oracle results saved to: {out_file}")
    print("=" * 80)


if __name__ == "__main__":
    main()
