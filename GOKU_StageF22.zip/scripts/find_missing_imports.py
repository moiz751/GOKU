import os
import ast
import sys

# Known mapping of top-level import name to PyPI package name
IMPORT_TO_PKG = {
    "PIL": "pillow",
    "docx": "python-docx",
    "win32api": "pywin32",
    "win32gui": "pywin32",
    "win32con": "pywin32",
    "win32process": "pywin32",
    "win32clipboard": "pywin32",
    "win32event": "pywin32",
    "win32pipe": "pywin32",
    "win32file": "pywin32",
    "pythoncom": "pywin32",
    "playwright": "playwright",
    "pypdf": "pypdf",
    "openpyxl": "openpyxl",
    "psutil": "psutil",
    "numpy": "numpy",
    "pyautogui": "pyautogui",
    "requests": "requests",
    "pytest": "pytest"
}

project_dirs = ["brain", "command_layer", "config", "executor", "security", "tools", "voice"]
local_modules = set(project_dirs) | {"main", "package_artifact", "view_ledger_summary"}

stdlib_modules = set(sys.stdlib_module_names)

all_imports = set()

for d in project_dirs:
    for root, dirs, files in os.walk(d):
        for f in files:
            if f.endswith(".py"):
                path = os.path.join(root, f)
                try:
                    with open(path, "r", encoding="utf-8", errors="ignore") as fp:
                        tree = ast.parse(fp.read(), filename=path)
                    for node in ast.walk(tree):
                        if isinstance(node, ast.Import):
                            for alias in node.names:
                                top = alias.name.split(".")[0]
                                all_imports.add(top)
                        elif isinstance(node, ast.ImportFrom):
                            if node.module:
                                top = node.module.split(".")[0]
                                all_imports.add(top)
                except Exception:
                    pass

if os.path.exists("main.py"):
    with open("main.py", "r", encoding="utf-8", errors="ignore") as fp:
        tree = ast.parse(fp.read(), filename="main.py")
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                all_imports.add(alias.name.split(".")[0])
        elif isinstance(node, ast.ImportFrom):
            if node.module:
                all_imports.add(node.module.split(".")[0])

# Read requirements.txt
req_packages = set()
with open("requirements.txt", "r", encoding="utf-8") as f:
    for line in f:
        line = line.strip()
        if line and not line.startswith("#"):
            pkg = line.split("==")[0].split(">=")[0].split("<=")[0].strip().lower()
            req_packages.add(pkg)

external_imports = all_imports - stdlib_modules - local_modules

missing_from_requirements = {}
for imp in sorted(external_imports):
    pkg = IMPORT_TO_PKG.get(imp, imp).lower()
    if pkg not in req_packages:
        missing_from_requirements[imp] = pkg

print("=== EXTERNAL IMPORTS AUDIT ===")
print(f"Total external imports found: {len(external_imports)}")
print("\nImports mapped in requirements.txt:")
for imp in sorted(external_imports):
    pkg = IMPORT_TO_PKG.get(imp, imp).lower()
    if pkg in req_packages:
        print(f"  [OK] {imp} -> {pkg}")

print("\nIMPORTS MISSING FROM requirements.txt:")
for imp, pkg in sorted(missing_from_requirements.items()):
    print(f"  [MISSING] import {imp} (Package: {pkg})")
