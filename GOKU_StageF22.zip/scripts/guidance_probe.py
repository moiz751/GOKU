"""Stage F11: 'did GOKU need guidance?' probe. Each capability is asked with its TRAINED phrasing and with UNSEEN paraphrases
(Roman Urdu / short / long). A capability needs NO guidance only if every variant is handled correctly on the first try.
Run the same file against an older stage tree (e.g. F8) to see what changed. Self-authored: a regression/honesty probe, not independent proof.
usage: python scripts/guidance_probe.py <root> <out.json>"""
import json, os, sys, types, ctypes, tempfile
from unittest.mock import MagicMock

root = os.path.abspath(sys.argv[1]); out = sys.argv[2]
os.chdir(root); sys.path.insert(0, root)
os.environ.setdefault("GOKU_QA_NO_MODEL", "1")
for m in ("win32gui", "win32con", "win32api", "win32process", "win32ui", "pythoncom", "pyautogui"):
    sys.modules[m] = MagicMock()
ctypes.windll = types.SimpleNamespace(user32=MagicMock(), gdi32=MagicMock(), kernel32=MagicMock())

tmp = tempfile.mkdtemp()
IMG = os.path.join(tmp, "i.png")
try:
    from PIL import Image
    import numpy as np
    Image.fromarray(np.random.default_rng(1).integers(0, 255, (80, 80, 3)).astype("uint8")).save(IMG)
except Exception:
    IMG = "/nonexistent.png"
BLOG = os.path.join(tmp, "b.html"); open(BLOG, "w").write("<h1>A</h1><h3>B</h3><img src='x.jpg'>")
LONG = "First open Chrome and search YouTube for a video. Then pick a video of at least 45 seconds. Do not subscribe without asking me. After that subscribe to the channel. Show me the screenshot before you save it."

# (capability id, [phrasings...], [any-of expected substrings, lowercase])
P = [
 ("qa_definition", ["What is a stack in programming?", "stack kya hota hai programming mein?", "explain stack data structure simply"], ["last", "lifo", "push"]),
 ("qa_math", ["What is 15% of 240?", "240 ka 15 percent kitna hota hai?", "calculate fifteen percent of 240"], ["36"]),
 ("qa_false_premise", ["Why do we only use 10% of our brains?", "kya hum sirf 10 percent dimagh use karte hain?", "is it true humans use just 10% of the brain"], ["myth", "not true", "misconception", "premise", "false", "not"]),
 ("qa_followup_capital", ["What is the capital of France?|And what about Italy?", "capital of France?|aur Italy?", "France capital?|how about Italy?"], ["rome"]),
 ("qa_unknown_honest", ["What is Zorblaxium-7 used for?", "Zorblaxium-7 kis kaam aata hai?", "tell me about the Zorblaxium-7 compound"], ["don't have", "do not have", "unknown", "not sure", "verified answer", "cannot", "no verified"]),
 ("long_ledger", ["ledger: " + LONG, "long command: " + LONG, "ledger : " + LONG.lower()], ["requirements"]),
 ("capability_preflight", ["preflight: subscribe to a youtube channel", "preflight: youtube par channel subscribe karna", "can goku do: set a wallpaper"], ["status", "blocked", "not_tested", "unsupported", "partial", "pending"]),
 ("ram_plan", ["plan video 800", "plan video analysis 800 MB", "advise video 800"], ["pending", "now", "pieces", "impossible", "run", "option"]),
 ("system_scan", ["system scan", "scan system", "system scan please"], ["ram", "mb", "memory"]),
 ("video_audit_missing", ["video audit: /no/such.mp4", "audit video: /no/such.mp4", "video audit : /no/such.mp4"], ["blocked", "not found", "unsupported"]),
 ("image_audit", ["image audit: " + IMG, "inspect image: " + IMG, "image audit : " + IMG], ["not determined", "blocked"]),
 ("blog_audit", ["blog audit: " + BLOG, "blog audit : " + BLOG, "Blog Audit: " + BLOG], ["h1 -> h3", "alt text"]),
 ("feedback_classify", ["feedback: you selected the wrong video, always verify", "feedback: galat video select kiya, hamesha verify karo", "feedback: you picked the wrong video and from now on always verify"], ["no source file"]),
 ("social_check", ["social check: tiktok | My desk tour. Clean cables.", "social check: instagram_reel | My desk tour. Clean cables.", "social check : tiktok | My desk tour"], ["nothing published"]),
 ("translate", ["translate to urdu: good morning", "good morning ka urdu translation", "translate good morning into roman urdu"], ["subah", "صبح", "suba", "cannot translate", "translation model"]),
 ("remember_recall", ["remember my favourite color is blue|what is my favourite color?", "yaad rakho meri pasandida colour blue hai|meri pasandida colour kya hai?", "remember favourite color: blue|favourite color?"], ["blue"]),
 ("features_switches", ["features", "show features", "feature list"], ["feature", "on", "off"]),
 ("pending_list", ["pending list", "pending", "show pending"], ["pending", "no pending", "nothing"]),
]

import importlib
ta = importlib.import_module("brain.task_agent")
res = []
for cid, phr, exp in P:
    row = {"id": cid, "variants": []}
    for ph in phr:
        try:
            turns = ph.split("|") if cid in ("qa_followup_capital", "remember_recall") and "|" in ph else [ph]
            outp = ""
            for t in turns:
                outp = ta.try_handle(t) or ""
                if not isinstance(outp, str):
                    outp = str(outp)
            ok = any(e in outp.lower() for e in exp)
            row["variants"].append({"q": ph[:70], "ok": bool(ok), "out": outp[:120].replace("\n", " ")})
        except Exception as e:
            row["variants"].append({"q": ph[:70], "ok": False, "out": "EXC " + repr(e)[:100]})
    row["trained_ok"] = row["variants"][0]["ok"]
    row["unseen_ok"] = all(v["ok"] for v in row["variants"][1:])
    row["needs_guidance"] = not all(v["ok"] for v in row["variants"])
    res.append(row)
json.dump({"root": root, "rows": res}, open(out, "w"), indent=1, ensure_ascii=False)
print(sum(1 for r in res if not r["needs_guidance"]), "/", len(res), "capabilities handled without guidance")
for r in res:
    print(("OK  " if not r["needs_guidance"] else "NEED"), r["id"], [int(v["ok"]) for v in r["variants"]])
