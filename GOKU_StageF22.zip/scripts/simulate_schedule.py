"""Shows what the planner and scheduler would do on ANY hardware, without that hardware:
    python scripts/simulate_schedule.py --total 4096 --free 1500      (your laptop)
    python scripts/simulate_schedule.py --total 32768 --free 24000    (a strong PC)
Same code, different machine; nothing is executed, only decided."""
import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from brain import capability_planner as cp  # noqa: E402
from brain.capability_catalog import WORK  # noqa: E402


def tier_for(total):
    try:
        from tools import hw_profile
        return hw_profile.classify_tier(total)
    except Exception:
        return "tiny" if total < 6000 else "small" if total < 12000 else "medium" if total < 24000 else "large"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--total", type=float, default=4096)
    ap.add_argument("--free", type=float, default=1500)
    ap.add_argument("--big-mb", type=float, default=1024)
    a = ap.parse_args()
    s = dict(time=0, total_mb=a.total, free_mb=a.free, tier=tier_for(a.total), headroom_mb=150, processes=[], battery_pct=None, on_ac=None, temp_c=None, notes=[])
    print(f"machine: {a.total:.0f} MB total, {a.free:.0f} MB free, tier {s['tier']}\n")
    for k in sorted(WORK):
        print(cp.explain(cp.evaluate(k, a.big_mb if k in ("big_text", "pdf", "video_edit", "code_review") else 0, s)), "\n")


if __name__ == "__main__":
    main()
