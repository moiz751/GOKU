"""
scripts/generate_matrix_report.py - Generates reports/MATRIX.md from pytest JUnit XML execution results.
Follows MASTER RULES:
- Rule 1: Evidence or it did not happen.
- Rule 2: Three states only: PASSED, FAILED, UNVERIFIED.
- Rule 3: No hand-typed numbers. Numbers come from a script that reads JUnit XML and prints them.
"""
from __future__ import annotations

import os
from pathlib import Path
import subprocess
import sys
import xml.etree.ElementTree as ET

PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

ROW_METADATA = {
    "test_row_01_nested_folder_navigation": {
        "row": 1,
        "category": "Folder Navigation",
        "intent": "Nested folder navigation (Compound 'us ka bad' / 'us ke baad')",
        "command": "Local drive F: ma CSS Paper folder open ker us ka bad CSS Paper 2017 wala folder open ker",
        "type": "Implemented Behaviour",
        "limit_ref": "N/A (Code Implementation)",
    },
    "test_row_02_drive_folder_open": {
        "row": 2,
        "category": "Folder Navigation",
        "intent": "Drive root folder opening",
        "command": "F drive mein CSS Paper folder kholo",
        "type": "Implemented Behaviour",
        "limit_ref": "N/A (Code Implementation)",
    },
    "test_row_03_nested_child_folder_open": {
        "row": 3,
        "category": "Folder Navigation",
        "intent": "Nested child folder opening ('ke andar')",
        "command": "CSS Paper ke andar CSS Paper 2017 kholo",
        "type": "Implemented Behaviour",
        "limit_ref": "N/A (Code Implementation)",
    },
    "test_row_04_direct_raw_path_open": {
        "row": 4,
        "category": "Folder Navigation",
        "intent": "Direct raw path opening",
        "command": r"F:\CSS Paper\CSS Paper 2017 kholo",
        "type": "Implemented Behaviour",
        "limit_ref": "N/A (Code Implementation)",
    },
    "test_row_05_named_folder_open": {
        "row": 5,
        "category": "Folder Navigation",
        "intent": "Named folder open across drives",
        "command": "CSS Paper 2017 folder open karo",
        "type": "Implemented Behaviour",
        "limit_ref": "N/A (Code Implementation)",
    },
    "test_row_06_physical_mouse_movements": {
        "row": 6,
        "category": "Mouse Engine",
        "intent": "Directional physical mouse movement",
        "command": "mouse ko left se right move karo",
        "type": "Implemented Behaviour",
        "limit_ref": "N/A (Code Implementation)",
    },
    "test_row_07_mouse_circular_and_continuous_motion": {
        "row": 7,
        "category": "Mouse Engine",
        "intent": "Mouse circular & continuous motion patterns",
        "command": "mouse ko circle mein move karo",
        "type": "Implemented Behaviour",
        "limit_ref": "N/A (Code Implementation)",
    },
    "test_row_08_window_button_target_move_limit": {
        "row": 8,
        "category": "Window Management",
        "intent": "Window caption minimize button target move (Antigravity)",
        "command": "Antigravity ke minimize button par mouse le jao",
        "type": "Documented Limit",
        "limit_ref": "KNOWN_LIMITS.md #1",
    },
    "test_row_09_window_button_mouse_click_limit": {
        "row": 9,
        "category": "Window Management",
        "intent": "Window caption minimize button mouse click",
        "command": "minimize button par click karo",
        "type": "Documented Limit",
        "limit_ref": "KNOWN_LIMITS.md #2",
    },
    "test_row_10_local_downloaded_app_search": {
        "row": 10,
        "category": "Application Search",
        "intent": "Local downloaded application discovery without web redirect",
        "command": "computer mein downloaded Angry Bird game open karo",
        "type": "Implemented Behaviour",
        "limit_ref": "N/A (Code Implementation)",
    },
    "test_row_11_file_search_by_extension_in_folder": {
        "row": 11,
        "category": "Filesystem Search",
        "intent": "Folder file search filtered by extension",
        "command": "Downloads mein jo PDF files hain unko find karo",
        "type": "Implemented Behaviour",
        "limit_ref": "N/A (Code Implementation)",
    },
    "test_row_12_drive_file_search": {
        "row": 12,
        "category": "Filesystem Search",
        "intent": "Drive file search matching keyword query",
        "command": "F drive mein CSS wali files find karo",
        "type": "Implemented Behaviour",
        "limit_ref": "N/A (Code Implementation)",
    },
    "test_row_13_microsoft_store_workflow": {
        "row": 13,
        "category": "Compound Automation",
        "intent": "Microsoft Store multi-step sequential automation workflow",
        "command": "Microsoft Store open karo, search bar par mouse le jao, click karo, new games type karo, search karo, phir slowly scroll karo",
        "type": "Implemented Behaviour",
        "limit_ref": "N/A (Code Implementation)",
    },
    "test_row_14_scrolling_controls": {
        "row": 14,
        "category": "Scroll Engine",
        "intent": "Scrolling controls (standard, speed, count, duration)",
        "command": "scroll down / slowly scroll down / scroll down 5 times",
        "type": "Implemented Behaviour",
        "limit_ref": "N/A (Code Implementation)",
    },
    "test_row_15_app_batch_close": {
        "row": 15,
        "category": "Process Management",
        "intent": "Natural language application batch closure",
        "command": "jo jo notepad open hain unko close kar do",
        "type": "Implemented Behaviour",
        "limit_ref": "N/A (Code Implementation)",
    },
    "test_row_16_notepad_compound_workflow": {
        "row": 16,
        "category": "Compound Automation",
        "intent": "Notepad multi-action workflow (launch, write, screenshot)",
        "command": "Notepad kholo, usmein GOKU TEST likho, phir screenshot lo",
        "type": "Implemented Behaviour",
        "limit_ref": "N/A (Code Implementation)",
    },
    "test_row_17_chrome_chatgpt_compound_workflow": {
        "row": 17,
        "category": "Compound Automation",
        "intent": "Browser & web app compound workflow (Chrome -> ChatGPT -> type -> screenshot)",
        "command": 'Chrome kholo, ChatGPT kholo, chat box mein "how to download NFS" likho, phir screenshot lo',
        "type": "Implemented Behaviour",
        "limit_ref": "N/A (Code Implementation)",
    },
    "test_row_18_context_resolution_followup_folder": {
        "row": 18,
        "category": "Context Resolution",
        "intent": "Pronoun and contextual follow-up folder resolution ('usmein...')",
        "command": "usmein CSS Paper 2017 kholo",
        "type": "Implemented Behaviour",
        "limit_ref": "N/A (Code Implementation)",
    },
    "test_row_19_conversational_prompts": {
        "row": 19,
        "category": "Conversational Safety",
        "intent": "Conversational queries answered without launching applications",
        "command": "hello / how are you / what is AI / what is 2+2 / GOKU TEST",
        "type": "Implemented Behaviour",
        "limit_ref": "N/A (Code Implementation)",
    },
    "test_row_20_ollama_lifecycle_and_model_check": {
        "row": 20,
        "category": "LLM Lifecycle",
        "intent": "Ollama service status & local model availability check",
        "command": "is_ollama_running() & is_model_available('qwen2.5:0.5b')",
        "type": "Implemented Behaviour",
        "limit_ref": "N/A (Code Implementation)",
    },
    "test_row_21_drag_and_drop_text_selection": {
        "row": 21,
        "category": "GUI Automation",
        "intent": "Hardware mouse drag and text selection range dispatch",
        "command": "drag_mouse(...) & select_text_range(...)",
        "type": "Implemented Behaviour",
        "limit_ref": "N/A (Code Implementation)",
    },
    "test_row_22_window_resize_and_move": {
        "row": 22,
        "category": "Window Management",
        "intent": "Window repositioning and dimension resizing API",
        "command": "resize_window(...) & move_window(...)",
        "type": "Implemented Behaviour",
        "limit_ref": "N/A (Code Implementation)",
    },
}


def main():
    reports_dir = PROJECT_ROOT / "reports"
    reports_dir.mkdir(parents=True, exist_ok=True)
    junit_xml_path = reports_dir / "junit_matrix.xml"
    matrix_md_path = reports_dir / "MATRIX.md"

    # Step 1: Run pytest to generate JUnit XML
    cmd = [
        sys.executable,
        "-m",
        "pytest",
        "tests/test_p8_matrix.py",
        f"--junitxml={junit_xml_path}",
        "-v",
    ]
    print(f"Running: {' '.join(cmd)}")
    proc = subprocess.run(cmd, cwd=str(PROJECT_ROOT), capture_output=True, text=True)
    print(proc.stdout)
    if proc.stderr:
        print(proc.stderr, file=sys.stderr)

    if not junit_xml_path.exists():
        print(f"Error: JUnit XML was not generated at {junit_xml_path}")
        sys.exit(1)

    # Step 2: Parse JUnit XML
    tree = ET.parse(junit_xml_path)
    root = tree.getroot()

    testcase_results: dict[str, dict] = {}
    for tc in root.iter("testcase"):
        tc_name = tc.attrib.get("name", "")
        tc_time = float(tc.attrib.get("time", 0.0))
        status = "PASSED"
        fail_msg = ""
        for child in tc:
            if child.tag == "failure":
                status = "FAILED"
                fail_msg = child.attrib.get("message", "Failure")
            elif child.tag == "error":
                status = "FAILED"
                fail_msg = child.attrib.get("message", "Error")
            elif child.tag == "skipped":
                status = "UNVERIFIED"
                fail_msg = child.attrib.get("message", "Skipped")

        testcase_results[tc_name] = {
            "status": status,
            "time": tc_time,
            "fail_msg": fail_msg,
        }

    # Step 3: Map to 22 matrix rows
    rows_data = []
    total_passed = 0
    total_failed = 0
    total_unverified = 0

    for tc_name, meta in sorted(ROW_METADATA.items(), key=lambda x: x[1]["row"]):
        tc_res = testcase_results.get(tc_name, {"status": "UNVERIFIED", "time": 0.0, "fail_msg": "Not executed"})
        status = tc_res["status"]
        if status == "PASSED":
            total_passed += 1
        elif status == "FAILED":
            total_failed += 1
        else:
            total_unverified += 1

        row_item = {
            "row": meta["row"],
            "category": meta["category"],
            "intent": meta["intent"],
            "command": meta["command"],
            "type": meta["type"],
            "limit_ref": meta["limit_ref"],
            "test_id": f"tests/test_p8_matrix.py::{tc_name}",
            "status": status,
            "time_s": tc_res["time"],
        }
        rows_data.append(row_item)

    # Step 4: Write reports/MATRIX.md
    md_lines = [
        "# GOKU 22-Row Capability Verification Matrix",
        "",
        "This matrix records physical verification across all 22 required capability items from Section 15.",
        "Generated deterministically from real pytest test execution outputs (`reports/junit_matrix.xml`).",
        "",
        "## 1. Summary Statistics",
        f"- **Total Rows in Matrix**: {len(rows_data)}",
        f"- **PASSED**: {total_passed} / {len(rows_data)} ({total_passed / len(rows_data) * 100:.1f}%)",
        f"- **FAILED**: {total_failed} / {len(rows_data)}",
        f"- **UNVERIFIED**: {total_unverified} / {len(rows_data)}",
        f"- **Documented Limitations (Rows 8 & 9)**: 2 (documented in `KNOWN_LIMITS.md` and verified by test)",
        f"- **Implemented Code Behaviors**: {len(rows_data) - 2}",
        "",
        "## 2. 22-Row Verification Matrix Table",
        "",
        "| Row # | Domain Category | Capability / Intent | Representative Command | Resolution Type | Test ID / Documented Limit | Status | Execution Time |",
        "|:---:|:---|:---|:---|:---|:---|:---:|:---:|",
    ]

    for r in rows_data:
        test_or_limit = f"`{r['test_id']}`"
        if r["type"] == "Documented Limit":
            test_or_limit = f"[{r['limit_ref']}](file:///c:/Users/Work/Downloads/GOKU/KNOWN_LIMITS.md) & `{r['test_id']}`"
        md_lines.append(
            f"| **{r['row']}** | {r['category']} | {r['intent']} | `{r['command']}` | {r['type']} | {test_or_limit} | **{r['status']}** | {r['time_s']:.3f}s |"
        )

    md_lines.extend([
        "",
        "---",
        "",
        "## 3. Documented Limitations Resolution (Rows 8 and 9)",
        "",
        "### Row 8: Window Button Target Move (`Antigravity Minimize`)",
        "- **Command**: `Antigravity ke minimize button par mouse le jao`",
        "- **Resolution**: Handled via safe intercept with documented guidance.",
        "- **Exact User-Visible Message**:",
        '  > `"Cannot target window caption or minimize button of IDE/system frame directly. Please use standard Windows shortcuts like Win+Down or Alt+Space then N to manage the window."`',
        "- **Verified By**: `tests/test_p8_matrix.py::test_row_08_window_button_target_move_limit`",
        "- **Reference**: [KNOWN_LIMITS.md #1](file:///c:/Users/Work/Downloads/GOKU/KNOWN_LIMITS.md#1-matrix-row-8-window-caption-button-target-move-antigravity-minimize)",
        "",
        "### Row 9: Window Button Mouse Click (`Minimize Button`)",
        "- **Commands**: `minimize button par click karo`, `mouse minimize button par le jao`",
        "- **Resolution**: Handled via safe intercept with documented guidance.",
        "- **Exact User-Visible Message**:",
        '  > `"Cannot click or manipulate window caption buttons directly. Please use standard Windows shortcuts like Win+Down or Alt+Space then N to minimize the window."`',
        "- **Verified By**: `tests/test_p8_matrix.py::test_row_09_window_button_mouse_click_limit`",
        "- **Reference**: [KNOWN_LIMITS.md #2](file:///c:/Users/Work/Downloads/GOKU/KNOWN_LIMITS.md#2-matrix-row-9-window-caption-button-direct-mouse-click-minimize-button)",
        "",
    ])

    matrix_md_path.write_text("\n".join(md_lines), encoding="utf-8")
    print(f"\nSuccessfully wrote {matrix_md_path} ({len(rows_data)} rows).")

    # Output table for console evidence
    print("\n" + "=" * 110)
    print("GATE ARTIFACT: reports/MATRIX.md")
    print("\n".join(md_lines[14:40]))
    print("=" * 110)

    if total_failed > 0 or total_unverified > 0 or len(rows_data) != 22:
        print("GATE FAILURE: Matrix did not achieve 22/22 PASSED.")
        sys.exit(1)
    else:
        print("GATE SUCCESS: 22/22 Matrix rows verified with concrete test IDs.")


if __name__ == "__main__":
    main()
