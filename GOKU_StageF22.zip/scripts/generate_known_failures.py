"""
scripts/generate_known_failures.py - Honest Failure Ledger Generator
Follows GOKU RULES v2 + Prompt R2 Step 4.

Parses reports/full_suite.xml (or reports/full_suite_v3.xml) for all 342 failures,
extracts:
- test_id (nodeid)
- module
- exception_type
- first_message_line (normalized)
- category in {obsolete_expectation, environment, production_bug, capability_gap}

Decided by explicit printed rules:
Rule 1 (capability_gap): All test_bullet* modules (all 205 bullet failures, including the 145 bullet failures)
       plus complex autonomous replanning / multi-step workflow failures.
Rule 2 (environment): Tests requiring live hardware, live UI interaction, or active desktop foreground.
Rule 3 (obsolete_expectation): Tests asserting superseded string representations or obsolete return structures.
Rule 4 (production_bug): Unhandled runtime errors (KeyError, IndexError), leaked processes, or router tool routing bugs.

Outputs tests/known_failures.json.
"""
from __future__ import annotations

import argparse
from collections import Counter
import json
import os
import re
import sys
import xml.etree.ElementTree as ET


def normalize_line(line: str) -> str:
    cleaned = re.sub(r"\s+", " ", line.strip())
    cleaned = re.sub(r"0x[0-9a-fA-F]+", "0x...", cleaned)
    cleaned = re.sub(r"[A-Za-z]:\\[^\s'\"]+", "<PATH>", cleaned)
    return cleaned


def resolve_nodeid(classname: str, name: str) -> tuple[str, str]:
    parts = classname.split(".")
    path1 = os.path.join(*parts) + ".py"
    path2 = os.path.join(*parts[:-1]) + ".py" if len(parts) > 1 else None

    if os.path.exists(path1):
        rel = path1.replace("\\", "/")
        return rel, f"{rel}::{name}"
    elif path2 and os.path.exists(path2):
        rel = path2.replace("\\", "/")
        cls = parts[-1]
        return rel, f"{rel}::{cls}::{name}"
    else:
        rel = "/".join(parts) + ".py"
        return rel, f"{rel}::{name}"


def categorize_failure(nodeid: str, module: str, exc: str, first_line: str) -> tuple[str, str]:
    """
    Categorizes failure based on explicit published rules.
    Returns (category, rule_reason).
    """
    norm = normalize_line(first_line).lower()

    # Rule 1: Bullet tests are ALWAYS capability_gap
    if "bullet" in module.lower():
        return "capability_gap", "Rule 1: Bullet test suite evaluates advanced autonomous capability gap"

    # Rule 2: Environment
    if any(m in nodeid for m in ["test_live_operator", "test_wifi_advanced_scanner"]):
        return "environment", "Rule 2: Requires live user operator interaction or physical network adapter"
    if "test_truth_eye" in nodeid and any(t in nodeid for t in ["notepad_file_menu", "desktop_icon", "unsaved_changes"]):
        return "environment", "Rule 2: Requires active desktop GUI session and visible Notepad window"

    # Rule 3: Obsolete expectation
    if any(k in norm for k in [
        "assert 'success' == 'completed'",
        "assert 'left_to_right' == 'left_right_then_top_bottom'",
        "assert 'notepad' == 'notepad'",
        "conversation",
        "assert windowspath"
    ]):
        return "obsolete_expectation", "Rule 3: Test asserts superseded return value format or legacy enum"

    # Rule 4: Production bug
    if "leaked processes" in norm:
        return "production_bug", "Rule 4: Leaked background processes detected during test teardown"
    if exc in ["KeyError", "IndexError", "TypeError", "AttributeError"]:
        return "production_bug", f"Rule 4: Unhandled runtime {exc} in core implementation"
    if "direct_msg" in norm or "expected call not found" in norm:
        return "production_bug", "Rule 4: Router collision or unhandled routing dispatch"

    # Capability gap for complex multi-turn / compound stress
    if any(m in nodeid for m in [
        "test_search_ambiguity",
        "test_workflow_e2e",
        "test_phase4_autonomous_loop",
        "test_reliability_hardening",
        "test_compound_stress_fixes",
        "test_target_understanding",
    ]):
        return "capability_gap", "Rule 1: Multi-step compound autonomous workflow or ambiguity resolution gap"

    return "production_bug", "Rule 4: Unexpected assertion failure in production component"


def generate_known_failures(xml_path: str, output_json: str):
    if not os.path.exists(xml_path):
        print(f"Error: XML path {xml_path} does not exist.")
        sys.exit(1)

    print("=" * 80)
    print("STEP 4: GENERATE HONEST FAILURE LEDGER FROM XML")
    print("=" * 80)

    tree = ET.parse(xml_path)
    testcases = tree.findall(".//testcase")

    failures = []
    category_counts = Counter()
    rules_applied = Counter()

    for tc in testcases:
        fail = tc.find("failure")
        err = tc.find("error")
        elem = fail if fail is not None else err

        if elem is not None:
            classname = tc.attrib["classname"]
            name = tc.attrib["name"]
            duration = float(tc.attrib.get("time", 0.0) or 0.0)

            file_path, nodeid = resolve_nodeid(classname, name)

            raw = (elem.text or "").strip()
            msg = elem.attrib.get("message", "")
            first_line = msg.split("\n")[0] if msg else (raw.split("\n")[0] if raw else "")

            # Extract exception type
            m = re.search(r"(\w+Error|\w+Exception|AssertionError):", raw)
            exc = m.group(1) if m else elem.attrib.get("type", "AssertionError")
            if not exc:
                exc = "AssertionError"

            cat, rule_reason = categorize_failure(nodeid, classname, exc, first_line)

            category_counts[cat] += 1
            rules_applied[rule_reason.split(":")[0]] += 1

            failures.append({
                "test_id": nodeid,
                "module": classname,
                "file": file_path,
                "exception_type": exc,
                "first_message_line": normalize_line(first_line),
                "category": cat,
                "rule_reason": rule_reason,
                "duration": duration,
            })

    output_data = {
        "version": "1.0",
        "source_xml": xml_path,
        "total_known_failures": len(failures),
        "category_counts": dict(category_counts),
        "rules_applied": dict(rules_applied),
        "failures": failures,
        "failure_map": {f["test_id"]: f for f in failures},
    }

    os.makedirs(os.path.dirname(output_json), exist_ok=True)
    with open(output_json, "w", encoding="utf-8") as f:
        json.dump(output_data, f, indent=2)

    print(f"Total failures extracted: {len(failures)}")
    print("-" * 80)
    print("FAILURE CATEGORY BREAKDOWN:")
    for cat, cnt in category_counts.most_common():
        print(f"  {cat:22s} : {cnt:4d} ({cnt/len(failures)*100:5.2f}%)")
    print("-" * 80)
    print("RULES APPLIED:")
    for rule, cnt in rules_applied.most_common():
        print(f"  {rule:22s} : {cnt:4d}")
    print("=" * 80)
    print(f"Ledger written to: {output_json}")
    print("=" * 80)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Generate known_failures.json from XML")
    parser.add_argument("--xml", default="reports/full_suite.xml", help="Path to XML file")
    parser.add_argument("--output", default="tests/known_failures.json", help="Path to output known_failures.json")
    args = parser.parse_args()

    generate_known_failures(args.xml, args.output)
