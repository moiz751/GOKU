# scripts/run_full_suite.ps1
# GOKU Safe Resumable Full Suite Test Runner
# Windows PowerShell 5 compatible

param(
    [switch]$IncludeLive,
    [switch]$Resume,
    [switch]$SelfTest
)

Set-StrictMode -Off
$ErrorActionPreference = "Continue"

# ------------------------------------------------------------------------------
# 1. ERROR MODE SUPPRESSION (kernel32 SetErrorMode)
# ------------------------------------------------------------------------------
# SEM_FAILCRITICALERRORS (0x0001) | SEM_NOGPFAULTERRORBOX (0x0002) | SEM_NOOPENFILEERRORBOX (0x8000) = 0x8003
if (-not ([System.Management.Automation.PSTypeName]'FullSuiteKernel32ErrorMode').Type) {
    Add-Type -TypeDefinition @"
    using System;
    using System.Runtime.InteropServices;
    public class FullSuiteKernel32ErrorMode {
        [DllImport("kernel32.dll", SetLastError = true)]
        public static extern uint SetErrorMode(uint uMode);
    }
"@
}
[FullSuiteKernel32ErrorMode]::SetErrorMode(0x8003) | Out-Null

# ------------------------------------------------------------------------------
# 2. PATHS & DIRECTORIES SETUP
# ------------------------------------------------------------------------------
$repoRoot = (Resolve-Path "$PSScriptRoot\..").Path
$reportsDir = Join-Path $repoRoot "reports\full_suite"
if (-not (Test-Path $reportsDir)) {
    New-Item -ItemType Directory -Path $reportsDir -Force | Out-Null
}

$desktopDir = [Environment]::GetFolderPath("Desktop")

$suiteStartTime = Get-Date
$timestampStr = $suiteStartTime.ToString("yyyyMMdd_HHmmss")
$logFile = Join-Path $reportsDir "full_suite_$timestampStr.log"
$summaryJsonPath = Join-Path $reportsDir "summary_$timestampStr.json"
$summaryMdPath = Join-Path $reportsDir "summary_$timestampStr.md"

$stdoutFile = Join-Path $env:TEMP "full_suite_stdout.tmp"
$stderrFile = Join-Path $env:TEMP "full_suite_stderr.tmp"

function Write-SuiteLog {
    param([string]$Message = "")
    Write-Host $Message
    if ($logFile) {
        Add-Content -Path $logFile -Value $Message -Encoding UTF8
    }
}

# ------------------------------------------------------------------------------
# 3. HELPER FUNCTIONS: MEMORY & SIDE EFFECT WATCH
# ------------------------------------------------------------------------------
function Get-FreePhysicalMemoryMB {
    try {
        $os = Get-CimInstance Win32_OperatingSystem -ErrorAction Stop
        return [Math]::Round($os.FreePhysicalMemory / 1024, 2)
    } catch {
        return 9999.0
    }
}

function Wait-ForFreeMemory {
    param([int]$RequiredMB = 300, [int]$TimeoutSeconds = 60)
    $sw = [System.Diagnostics.Stopwatch]::StartNew()
    $hasRam = $false
    $lastMb = 0.0
    while ($sw.Elapsed.TotalSeconds -lt $TimeoutSeconds) {
        $lastMb = Get-FreePhysicalMemoryMB
        if ($lastMb -ge $RequiredMB) {
            $hasRam = $true
            break
        }
        Start-Sleep -Seconds 2
    }
    $sw.Stop()
    return [PSCustomObject]@{
        Success = $hasRam
        FreeMB = $lastMb
        WaitSeconds = [Math]::Round($sw.Elapsed.TotalSeconds, 2)
    }
}

function Get-SideEffectSnapshot {
    $desktopFiles = @()
    if (Test-Path $desktopDir) {
        $desktopFiles = @(Get-ChildItem -Path $desktopDir -File -ErrorAction SilentlyContinue | Select-Object -ExpandProperty FullName)
    }
    $repoRootFiles = @(Get-ChildItem -Path $repoRoot -File -ErrorAction SilentlyContinue | Select-Object -ExpandProperty FullName)
    $gitStatus = @(git status --short 2>&1)

    return [PSCustomObject]@{
        DesktopFiles = $desktopFiles
        RepoRootFiles = $repoRootFiles
        GitStatus = $gitStatus
    }
}

function Compare-SideEffectSnapshot {
    param($Before, $After)
    $newDesktop = @()
    if ($After.DesktopFiles -and $Before.DesktopFiles) {
        $newDesktop = @($After.DesktopFiles | Where-Object { $Before.DesktopFiles -notcontains $_ })
    }
    $newRepoRoot = @()
    if ($After.RepoRootFiles -and $Before.RepoRootFiles) {
        $newRepoRoot = @($After.RepoRootFiles | Where-Object { $Before.RepoRootFiles -notcontains $_ })
    }
    $newGitStatus = @()
    if ($After.GitStatus -and $Before.GitStatus) {
        $newGitStatus = @($After.GitStatus | Where-Object { $Before.GitStatus -notcontains $_ })
    }

    return [PSCustomObject]@{
        NewDesktop = $newDesktop
        NewRepoRoot = $newRepoRoot
        NewGitStatus = $newGitStatus
    }
}

# ------------------------------------------------------------------------------
# 4. SUBPROCESS STEP RUNNER
# ------------------------------------------------------------------------------
function Invoke-PytestSubprocess {
    param(
        [string]$TestFileRel,
        [string]$CommandLine,
        [int]$TimeoutSeconds = 300,
        [string]$JunitXmlPath = ""
    )

    [System.IO.File]::WriteAllText($stdoutFile, "", [System.Text.Encoding]::UTF8)
    [System.IO.File]::WriteAllText($stderrFile, "", [System.Text.Encoding]::UTF8)

    $firstSpace = $CommandLine.IndexOf(" ")
    if ($firstSpace -gt 0) {
        $exe = $CommandLine.Substring(0, $firstSpace).Trim()
        $args = $CommandLine.Substring($firstSpace + 1).Trim()
    } else {
        $exe = $CommandLine.Trim()
        $args = ""
    }

    $sw = [System.Diagnostics.Stopwatch]::StartNew()
    $proc = Start-Process -FilePath $exe -ArgumentList $args -WorkingDirectory $repoRoot -NoNewWindow -PassThru -RedirectStandardOutput $stdoutFile -RedirectStandardError $stderrFile
    
    # Touch process handle immediately
    $null = $proc.Handle

    $timeoutMs = $TimeoutSeconds * 1000
    $exited = $proc.WaitForExit($timeoutMs)
    $sw.Stop()
    $durationSec = [Math]::Round($sw.Elapsed.TotalSeconds, 2)

    $isTimeout = $false
    if (-not $exited) {
        $isTimeout = $true
        Write-SuiteLog "[TIMEOUT] Exceeded timeout of $TimeoutSeconds s. Terminating process tree..."
        & taskkill.exe /PID $proc.Id /T /F 2>&1 | Out-Null
        try {
            if (-not $proc.HasExited) {
                Stop-Process -Id $proc.Id -Force -ErrorAction SilentlyContinue
            }
        } catch {}
    } else {
        $proc.WaitForExit()
    }

    $outText = if (Test-Path $stdoutFile) { [System.IO.File]::ReadAllText($stdoutFile, [System.Text.Encoding]::UTF8) } else { "" }
    $errText = if (Test-Path $stderrFile) { [System.IO.File]::ReadAllText($stderrFile, [System.Text.Encoding]::UTF8) } else { "" }

    $rawExitCode = $proc.ExitCode
    $exitCodeDec = $null
    if ($isTimeout) {
        $exitCodeDec = -1
        $statusStr = "TIMEOUT"
    } elseif ($null -eq $rawExitCode) {
        $exitCodeDec = $null
        $statusStr = "UNKNOWN"
    } else {
        $exitCodeDec = [int]$rawExitCode
        if ($exitCodeDec -eq 0) {
            $statusStr = "PASS"
        } else {
            if ($outText -match "ERROR collecting" -or $errText -match "SyntaxError|ImportError|ModuleNotFoundError") {
                $statusStr = "ERROR"
            } else {
                $statusStr = "FAIL"
            }
        }
    }

    # Parse JUnit XML if available
    $passedCount = 0
    $failedCount = 0
    $xfailedCount = 0
    $skippedCount = 0
    $failedTestIds = @()

    if ($JunitXmlPath -and (Test-Path $JunitXmlPath)) {
        try {
            [xml]$xml = Get-Content -Path $JunitXmlPath -Raw -Encoding UTF8
            $tsNode = $xml.SelectSingleNode("//testsuite")
            if ($tsNode) {
                $tTotal = [int]$tsNode.Attributes["tests"].Value
                $tFail = if ($tsNode.Attributes["failures"]) { [int]$tsNode.Attributes["failures"].Value } else { 0 }
                $tErr = if ($tsNode.Attributes["errors"]) { [int]$tsNode.Attributes["errors"].Value } else { 0 }
                $tSkip = if ($tsNode.Attributes["skipped"]) { [int]$tsNode.Attributes["skipped"].Value } else { 0 }

                $tcNodes = $xml.SelectNodes("//testcase")
                if ($tcNodes) {
                    foreach ($tc in $tcNodes) {
                        $tcName = $tc.Attributes["name"].Value
                        $hasFail = ($tc.SelectSingleNode("failure") -ne $null)
                        $hasErr = ($tc.SelectSingleNode("error") -ne $null)
                        $skipNode = $tc.SelectSingleNode("skipped")

                        if ($hasFail -or $hasErr) {
                            $failedTestIds += "$TestFileRel`::$tcName"
                        }
                        if ($skipNode -ne $null) {
                            if ($skipNode.Attributes["type"] -and $skipNode.Attributes["type"].Value -eq "pytest.xfail") {
                                $xfailedCount++
                            }
                        }
                    }
                }

                $failedCount = $tFail + $tErr
                $skippedCount = [Math]::Max(0, ($tSkip - $xfailedCount))
                $passedCount = [Math]::Max(0, ($tTotal - $failedCount - $tSkip))
            }
        } catch {}
    }

    # Extract first 3 failure lines
    $first3FailureLines = @()
    if ($statusStr -ne "PASS") {
        $lines = ($outText + "`n" + $errText) -split "`r?`n"
        foreach ($l in $lines) {
            $trimL = $l.Trim()
            if ($trimL -match "^(FAILED|ERROR|E\s{3}|AssertionError|Traceback)" -or $trimL -match "(assert|SyntaxError|NameError|AttributeError)") {
                $first3FailureLines += $trimL
                if ($first3FailureLines.Count -ge 3) { break }
            }
        }
        if ($first3FailureLines.Count -eq 0) {
            foreach ($l in $lines) {
                if ($l.Trim()) {
                    $first3FailureLines += $l.Trim()
                    if ($first3FailureLines.Count -ge 3) { break }
                }
            }
        }
    }

    return [PSCustomObject]@{
        Status = $statusStr
        ExitCode = $exitCodeDec
        Duration = $durationSec
        Passed = $passedCount
        Failed = $failedCount
        XFailed = $xfailedCount
        Skipped = $skippedCount
        FailedTestIds = $failedTestIds
        First3FailureLines = $first3FailureLines
        Output = ($outText + "`n" + $errText)
    }
}

# ------------------------------------------------------------------------------
# 5. SELF-TEST SWITCH (-SelfTest)
# ------------------------------------------------------------------------------
if ($SelfTest) {
    Write-Host "================================================================================"
    Write-Host "               RUNNING FULL SUITE RUNNER SELF-TEST                              "
    Write-Host "================================================================================"

    $tempDir = Join-Path $env:TEMP ("full_suite_selftest_" + [Guid]::NewGuid().ToString("N"))
    [System.IO.Directory]::CreateDirectory($tempDir) | Out-Null

    try {
        # Create 5 test cases
        $fPass = Join-Path $tempDir "test_01_pass.py"
        [System.IO.File]::WriteAllText($fPass, "def test_ok():`n    assert True`n", [System.Text.Encoding]::UTF8)

        $fFail = Join-Path $tempDir "test_02_fail.py"
        [System.IO.File]::WriteAllText($fFail, "def test_fail():`n    assert False, 'selftest expected failure'`n", [System.Text.Encoding]::UTF8)

        $fHang = Join-Path $tempDir "test_03_hang.py"
        [System.IO.File]::WriteAllText($fHang, "import time`ndef test_hang():`n    time.sleep(10)`n", [System.Text.Encoding]::UTF8)

        $fError = Join-Path $tempDir "test_04_error.py"
        [System.IO.File]::WriteAllText($fError, "def test_syntax_err(:::):`n    pass`n", [System.Text.Encoding]::UTF8)

        $fSkip = Join-Path $tempDir "test_05_skip.py"
        [System.IO.File]::WriteAllText($fSkip, "import pytest`ndef test_sk():`n    pytest.skip('selftest skip')`n", [System.Text.Encoding]::UTF8)

        $xml1 = Join-Path $tempDir "01.xml"
        $xml2 = Join-Path $tempDir "02.xml"
        $xml3 = Join-Path $tempDir "03.xml"
        $xml4 = Join-Path $tempDir "04.xml"
        $xml5 = Join-Path $tempDir "05.xml"

        # Check 1: Pass
        $r1 = Invoke-PytestSubprocess -TestFileRel "test_01_pass.py" -CommandLine "python -m pytest `"$fPass`" -q -p no:cacheprovider --junitxml=`"$xml1`"" -TimeoutSeconds 30 -JunitXmlPath $xml1
        # Check 2: Fail
        $r2 = Invoke-PytestSubprocess -TestFileRel "test_02_fail.py" -CommandLine "python -m pytest `"$fFail`" -q -p no:cacheprovider --junitxml=`"$xml2`"" -TimeoutSeconds 30 -JunitXmlPath $xml2
        # Check 3: Hang (short timeout 2s)
        $r3 = Invoke-PytestSubprocess -TestFileRel "test_03_hang.py" -CommandLine "python -m pytest `"$fHang`" -q -p no:cacheprovider --junitxml=`"$xml3`"" -TimeoutSeconds 2 -JunitXmlPath $xml3
        # Check 4: Collect Error
        $r4 = Invoke-PytestSubprocess -TestFileRel "test_04_error.py" -CommandLine "python -m pytest `"$fError`" -q -p no:cacheprovider --junitxml=`"$xml4`"" -TimeoutSeconds 30 -JunitXmlPath $xml4
        # Check 5: Skip
        $r5 = Invoke-PytestSubprocess -TestFileRel "test_05_skip.py" -CommandLine "python -m pytest `"$fSkip`" -q -p no:cacheprovider --junitxml=`"$xml5`"" -TimeoutSeconds 30 -JunitXmlPath $xml5

        $c1Ok = ($r1.Status -eq "PASS" -and $r1.ExitCode -eq 0)
        $c2Ok = ($r2.Status -eq "FAIL" -and $r2.ExitCode -eq 1)
        $c3Ok = ($r3.Status -eq "TIMEOUT" -and $r3.ExitCode -eq -1)
        $c4Ok = ($r4.Status -eq "ERROR" -or ($r4.ExitCode -ne 0 -and $r4.Status -in @("FAIL", "ERROR")))
        $c5Ok = ($r5.Status -eq "PASS" -and $r5.Skipped -ge 1)

        $c1Str = if ($c1Ok) { "PASS" } else { "FAIL" }
        $c2Str = if ($c2Ok) { "PASS" } else { "FAIL" }
        $c3Str = if ($c3Ok) { "PASS" } else { "FAIL" }
        $c4Str = if ($c4Ok) { "PASS" } else { "FAIL" }
        $c5Str = if ($c5Ok) { "PASS" } else { "FAIL" }

        Write-Host ""
        Write-Host "================================================================================"
        Write-Host "                         SELF-TEST RESULTS                                      "
        Write-Host "================================================================================"
        Write-Host ("Check 1 [pass file          -> PASS]:    {0} (ExitCode: {1}, Status: {2})" -f $c1Str, $r1.ExitCode, $r1.Status)
        Write-Host ("Check 2 [fail file          -> FAIL]:    {0} (ExitCode: {1}, Status: {2})" -f $c2Str, $r2.ExitCode, $r2.Status)
        Write-Host ("Check 3 [hang file (timeout)-> TIMEOUT]: {0} (ExitCode: {1}, Status: {2})" -f $c3Str, $r3.ExitCode, $r3.Status)
        Write-Host ("Check 4 [syntax error file  -> ERROR]:   {0} (ExitCode: {1}, Status: {2})" -f $c4Str, $r4.ExitCode, $r4.Status)
        Write-Host ("Check 5 [skip file          -> PASS]:    {0} (ExitCode: {1}, Skipped: {2})" -f $c5Str, $r5.ExitCode, $r5.Skipped)
        Write-Host "================================================================================"

        if ($c1Ok -and $c2Ok -and $c3Ok -and $c4Ok -and $c5Ok) {
            Write-Host "ALL 5 SELF-TEST CHECKS PASSED. Exiting 0."
            exit 0
        } else {
            Write-Host "ONE OR MORE SELF-TEST CHECKS FAILED. Exiting 1."
            exit 1
        }
    } finally {
        try {
            [System.IO.Directory]::Delete($tempDir, $true)
        } catch {}
    }
    exit 0
}

# ------------------------------------------------------------------------------
# 6. SUITE INITIALIZATION
# ------------------------------------------------------------------------------
Write-SuiteLog "================================================================================"
Write-SuiteLog "                GOKU FULL SUITE TEST RUNNER                                     "
Write-SuiteLog "================================================================================"
Write-SuiteLog "Start Time    : $($suiteStartTime.ToString('yyyy-MM-dd HH:mm:ss'))"
Write-SuiteLog "Repository    : $repoRoot"
Write-SuiteLog "Reports Dir   : $reportsDir"
Write-SuiteLog "Include Live  : $IncludeLive"
Write-SuiteLog "Resume Mode   : $Resume"
Write-SuiteLog "================================================================================"

# Load Live Tests Config
$liveConfigPath = Join-Path $repoRoot "config\live_tests.json"
$liveTestsMap = @{}
if (Test-Path $liveConfigPath) {
    try {
        $rawLive = Get-Content -Path $liveConfigPath -Raw -Encoding UTF8 | ConvertFrom-Json
        if ($rawLive.PSObject.Properties) {
            foreach ($prop in $rawLive.PSObject.Properties) {
                $val = $prop.Value
                $reasonStr = if ($val.reason) { $val.reason } else { "$val" }
                $liveTestsMap[$prop.Name] = $reasonStr
                $baseN = [System.IO.Path]::GetFileName($prop.Name)
                $liveTestsMap[$baseN] = $reasonStr
            }
        }
    } catch {
        Write-SuiteLog "Warning: Could not load config\live_tests.json: $_"
    }
}

# Load per-file test timeouts from config\test_timeouts.json (defaults to 300s)
$testTimeoutsFile = Join-Path $repoRoot "config\test_timeouts.json"
$testTimeoutsMap = @{}
if (Test-Path $testTimeoutsFile) {
    try {
        $rawTimeouts = Get-Content -Path $testTimeoutsFile -Raw -Encoding UTF8 | ConvertFrom-Json
        if ($rawTimeouts.PSObject.Properties) {
            foreach ($prop in $rawTimeouts.PSObject.Properties) {
                $timeoutSec = [int]$prop.Value
                $testTimeoutsMap[$prop.Name] = $timeoutSec
                $normSlash = $prop.Name.Replace("/", "\")
                $testTimeoutsMap[$normSlash] = $timeoutSec
                $baseName = [System.IO.Path]::GetFileName($prop.Name)
                $testTimeoutsMap[$baseName] = $timeoutSec
            }
        }
    } catch {
        Write-SuiteLog "Warning: Could not load config\test_timeouts.json: $_"
    }
}

# Handle Resume Mode
$resumedResults = @{}
if ($Resume) {
    $existingSummaries = @(Get-ChildItem -Path $reportsDir -Filter "summary_*.json" -File | Sort-Object Name -Descending)
    if ($existingSummaries.Count -gt 0) {
        $latestSummaryPath = $existingSummaries[0].FullName
        Write-SuiteLog "Resume switch active. Loading latest summary: $latestSummaryPath"
        try {
            $prevJson = Get-Content -Path $latestSummaryPath -Raw -Encoding UTF8 | ConvertFrom-Json
            if ($prevJson.results) {
                foreach ($r in $prevJson.results) {
                    if ($r.status -in @("PASS", "FAIL", "ERROR", "TIMEOUT", "SKIPPED_LIVE", "RAM_WAIT_TIMEOUT")) {
                        $resumedResults[$r.file] = $r
                    }
                }
            }
            Write-SuiteLog "Loaded $($resumedResults.Count) previously completed files from summary."
        } catch {
            Write-SuiteLog "Warning: Could not parse resume summary: $_"
        }
    }
}

# Enumerate test files in tests/
$testsDir = Join-Path $repoRoot "tests"
$testFiles = @(Get-ChildItem -Path $testsDir -Filter "test_*.py" -File | Sort-Object Name)
Write-SuiteLog "Total test files discovered: $($testFiles.Count)"
Write-SuiteLog "================================================================================"

$allResults = @()
$totalPassedFiles = 0
$totalFailedFiles = 0
$totalErrorFiles = 0
$totalTimeoutFiles = 0
$totalSkippedLiveFiles = 0
$totalRamWaitFiles = 0

$totalTestsPassed = 0
$totalTestsFailed = 0
$totalTestsXFailed = 0
$totalTestsSkipped = 0

$fileIndex = 0
foreach ($tf in $testFiles) {
    $fileIndex++
    $relPath = "tests/" + $tf.Name
    $fileName = $tf.Name
    $fileBase = [System.IO.Path]::GetFileNameWithoutExtension($tf.Name)
    $xmlPath = Join-Path $reportsDir "$fileBase.xml"

    Write-SuiteLog ""
    Write-SuiteLog ("[{0}/{1}] File: {2}" -f $fileIndex, $testFiles.Count, $relPath)

    # Check if already completed in resume mode
    if ($Resume -and $resumedResults.ContainsKey($relPath)) {
        $prev = $resumedResults[$relPath]
        Write-SuiteLog ("  [RESUMED] Status: {0} ({1}s) - Skipping execution." -f $prev.status, $prev.seconds)
        $allResults += $prev
        continue
    }

    # Check if Live Test
    $isLive = ($liveTestsMap.ContainsKey($relPath) -or $liveTestsMap.ContainsKey($fileName))
    if ($isLive -and -not $IncludeLive) {
        $reason = if ($liveTestsMap.ContainsKey($relPath)) { $liveTestsMap[$relPath] } else { $liveTestsMap[$fileName] }
        Write-SuiteLog "  [SKIPPED_LIVE] Reason: $reason (Use -IncludeLive to run)"
        $resObj = [PSCustomObject]@{
            file = $relPath
            status = "SKIPPED_LIVE"
            exit_code = 0
            seconds = 0.0
            passed = 0
            failed = 0
            xfailed = 0
            skipped = 1
            failed_test_ids = @()
            first_3_failure_lines = @("SKIPPED_LIVE: $reason")
            side_effects = [PSCustomObject]@{
                desktop = @()
                repo_root = @()
                git_status = @()
            }
        }
        $allResults += $resObj
        continue
    }

    # Check Free Physical Memory (>= 300 MB, wait up to 60 s)
    $memWait = Wait-ForFreeMemory -RequiredMB 300 -TimeoutSeconds 60
    if (-not $memWait.Success) {
        Write-SuiteLog ("  [RAM_WAIT_TIMEOUT] Free RAM ({0} MB) below 300 MB after {1} s wait. Skipping." -f $memWait.FreeMB, $memWait.WaitSeconds)
        $resObj = [PSCustomObject]@{
            file = $relPath
            status = "RAM_WAIT_TIMEOUT"
            exit_code = -2
            seconds = $memWait.WaitSeconds
            passed = 0
            failed = 0
            xfailed = 0
            skipped = 0
            failed_test_ids = @()
            first_3_failure_lines = @("RAM_WAIT_TIMEOUT: Free physical memory was $($memWait.FreeMB) MB (required >= 300 MB)")
            side_effects = [PSCustomObject]@{
                desktop = @()
                repo_root = @()
                git_status = @()
            }
        }
        $allResults += $resObj
        continue
    }

    # Snapshot state before test
    $snapBefore = Get-SideEffectSnapshot

    # Execute test file in isolated subprocess
    $fileTimeout = 300
    if ($testTimeoutsMap.ContainsKey($relPath)) {
        $fileTimeout = [int]$testTimeoutsMap[$relPath]
    } elseif ($testTimeoutsMap.ContainsKey($tf.Name)) {
        $fileTimeout = [int]$testTimeoutsMap[$tf.Name]
    }
    $cmd = "python -m pytest `"$($tf.FullName)`" -q -p no:cacheprovider --junitxml=`"$xmlPath`""
    $stepRes = Invoke-PytestSubprocess -TestFileRel $relPath -CommandLine $cmd -TimeoutSeconds $fileTimeout -JunitXmlPath $xmlPath

    # Snapshot state after test
    $snapAfter = Get-SideEffectSnapshot
    $sideEffects = Compare-SideEffectSnapshot -Before $snapBefore -After $snapAfter

    if ($sideEffects.NewDesktop.Count -gt 0 -or $sideEffects.NewRepoRoot.Count -gt 0) {
        Write-SuiteLog "  [SIDE EFFECT DETECTED]:"
        if ($sideEffects.NewDesktop.Count -gt 0) {
            Write-SuiteLog "    New Desktop files: $($sideEffects.NewDesktop -join ', ')"
        }
        if ($sideEffects.NewRepoRoot.Count -gt 0) {
            Write-SuiteLog "    New Repo Root files: $($sideEffects.NewRepoRoot -join ', ')"
        }
    }

    Write-SuiteLog ("  Result: {0} | ExitCode: {1} | Duration: {2}s | P:{3} F:{4} X:{5} S:{6}" -f `
        $stepRes.Status, $stepRes.ExitCode, $stepRes.Duration, $stepRes.Passed, $stepRes.Failed, $stepRes.XFailed, $stepRes.Skipped)

    $resObj = [PSCustomObject]@{
        file = $relPath
        status = $stepRes.Status
        exit_code = $stepRes.ExitCode
        seconds = $stepRes.Duration
        passed = $stepRes.Passed
        failed = $stepRes.Failed
        xfailed = $stepRes.XFailed
        skipped = $stepRes.Skipped
        failed_test_ids = $stepRes.FailedTestIds
        first_3_failure_lines = $stepRes.First3FailureLines
        side_effects = [PSCustomObject]@{
            desktop = $sideEffects.NewDesktop
            repo_root = $sideEffects.NewRepoRoot
            git_status = $sideEffects.NewGitStatus
        }
    }
    $allResults += $resObj
}

# ------------------------------------------------------------------------------
# 7. TOTALS & AGGREGATION
# ------------------------------------------------------------------------------
foreach ($r in $allResults) {
    switch ($r.status) {
        "PASS" { $totalPassedFiles++ }
        "FAIL" { $totalFailedFiles++ }
        "ERROR" { $totalErrorFiles++ }
        "TIMEOUT" { $totalTimeoutFiles++ }
        "SKIPPED_LIVE" { $totalSkippedLiveFiles++ }
        "RAM_WAIT_TIMEOUT" { $totalRamWaitFiles++ }
    }
    $totalTestsPassed += [int]$r.passed
    $totalTestsFailed += [int]$r.failed
    $totalTestsXFailed += [int]$r.xfailed
    $totalTestsSkipped += [int]$r.skipped
}

$suiteEndTime = Get-Date
$totalSuiteSec = [Math]::Round(($suiteEndTime - $suiteStartTime).TotalSeconds, 2)

$summaryData = [PSCustomObject]@{
    timestamp = $timestampStr
    start_time = $suiteStartTime.ToString("yyyy-MM-dd HH:mm:ss")
    end_time = $suiteEndTime.ToString("yyyy-MM-dd HH:mm:ss")
    duration_seconds = $totalSuiteSec
    include_live = [bool]$IncludeLive
    total_files = $allResults.Count
    summary = [PSCustomObject]@{
        passed_files = $totalPassedFiles
        failed_files = $totalFailedFiles
        error_files = $totalErrorFiles
        timeout_files = $totalTimeoutFiles
        skipped_live_files = $totalSkippedLiveFiles
        ram_wait_timeout_files = $totalRamWaitFiles
        total_tests_passed = $totalTestsPassed
        total_tests_failed = $totalTestsFailed
        total_tests_xfailed = $totalTestsXFailed
        total_tests_skipped = $totalTestsSkipped
    }
    results = $allResults
}

# Write summary JSON
$jsonText = $summaryData | ConvertTo-Json -Depth 6
[System.IO.File]::WriteAllText($summaryJsonPath, $jsonText, [System.Text.Encoding]::UTF8)

# Write summary Markdown
$mdLines = @()
$mdLines += "# Full Suite Execution Summary ($timestampStr)"
$mdLines += ""
$mdLines += "- **Start Time**: $($summaryData.start_time)"
$mdLines += "- **End Time**: $($summaryData.end_time)"
$mdLines += "- **Duration**: $totalSuiteSec seconds"
$mdLines += "- **Total Files**: $($allResults.Count)"
$mdLines += ""
$mdLines += "## Summary Totals"
$mdLines += ""
$mdLines += "| Metric | Count |"
$mdLines += "|---|---:|"
$mdLines += "| Passed Files | $totalPassedFiles |"
$mdLines += "| Failed Files | $totalFailedFiles |"
$mdLines += "| Error Files (Collection) | $totalErrorFiles |"
$mdLines += "| Timeout Files | $totalTimeoutFiles |"
$mdLines += "| Skipped Live Files | $totalSkippedLiveFiles |"
$mdLines += "| RAM Wait Timeout Files | $totalRamWaitFiles |"
$mdLines += "| **Tests Passed** | **$totalTestsPassed** |"
$mdLines += "| **Tests Failed** | **$totalTestsFailed** |"
$mdLines += "| **Tests Skipped** | **$totalTestsSkipped** |"
$mdLines += ""
$mdLines += "## Per-File Results"
$mdLines += ""
$mdLines += "| File | Status | Duration (s) | P/F/S | Failure Snippet |"
$mdLines += "|---|---|---:|---|---|"
foreach ($r in $allResults) {
    $snip = if ($r.first_3_failure_lines.Count -gt 0) { ($r.first_3_failure_lines -join "<br>").Replace("|", "\|") } else { "-" }
    $pfs = "$($r.passed)/$($r.failed)/$($r.skipped)"
    $mdLines += "| `$($r.file)` | **$($r.status)** | $($r.seconds) | $pfs | $snip |"
}
$mdText = $mdLines -join "`r`n"
[System.IO.File]::WriteAllText($summaryMdPath, $mdText, [System.Text.Encoding]::UTF8)

Write-SuiteLog ""
Write-SuiteLog "================================================================================"
Write-SuiteLog "                           FULL SUITE SUMMARY                                   "
Write-SuiteLog "================================================================================"
Write-SuiteLog "Passed Files        : $totalPassedFiles"
Write-SuiteLog "Failed Files        : $totalFailedFiles"
Write-SuiteLog "Error Files         : $totalErrorFiles"
Write-SuiteLog "Timeout Files       : $totalTimeoutFiles"
Write-SuiteLog "Skipped Live Files  : $totalSkippedLiveFiles"
Write-SuiteLog "RAM Wait Files      : $totalRamWaitFiles"
Write-SuiteLog "--------------------------------------------------------------------------------"
Write-SuiteLog "Tests Passed        : $totalTestsPassed"
Write-SuiteLog "Tests Failed        : $totalTestsFailed"
Write-SuiteLog "Tests Skipped       : $totalTestsSkipped"
Write-SuiteLog "Total Suite Duration: $totalSuiteSec s"
Write-SuiteLog "Summary JSON        : $summaryJsonPath"
Write-SuiteLog "Summary Markdown    : $summaryMdPath"
Write-SuiteLog "================================================================================"

if ($totalFailedFiles -gt 0 -or $totalErrorFiles -gt 0 -or $totalTimeoutFiles -gt 0) {
    exit 1
} else {
    exit 0
}
