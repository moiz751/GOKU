"""
Tests UI coordinate detection and window bounds at current DPI scale for Calculator and Edge.
"""
from __future__ import annotations

import ctypes
import subprocess
import sys
import time
from pathlib import Path
import psutil

# Ensure workspace root in sys.path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

# DPI detection
user32 = ctypes.windll.user32
gdi32 = ctypes.windll.gdi32

def get_system_dpi_scale():
    try:
        user32.SetProcessDPIAware()
        hdc = user32.GetDC(0)
        dpi_x = gdi32.GetDeviceCaps(hdc, 88) # LOGPIXELSX
        user32.ReleaseDC(0, hdc)
        scale_pct = int(round(dpi_x / 96.0 * 100))
        return dpi_x, scale_pct
    except Exception:
        return 96, 100

def test_app_bounds(app_cmd: str, proc_name: str, window_keyword: str):
    print(f"\n--- Testing {proc_name} ---")
    subprocess.Popen(app_cmd, shell=True)
    time.sleep(2.0)
    
    from executor.truth_oracle import check_window
    obs = check_window(title_contains=window_keyword, timeout=3.0)
    print(f"check_window result: {obs}")
    
    hwnd = obs.evidence.get("hwnd") if obs.evidence else None
    rect_data = {}
    if hwnd:
        import ctypes.wintypes
        rect = ctypes.wintypes.RECT()
        user32.GetWindowRect(hwnd, ctypes.byref(rect))
        rect_data = {
            "left": rect.left, "top": rect.top,
            "right": rect.right, "bottom": rect.bottom,
            "width": rect.right - rect.left, "height": rect.bottom - rect.top
        }
        print(f"Window RECT: {rect_data}")
    
    # Terminate tested app
    try:
        for p in psutil.process_iter(['pid', 'name']):
            if proc_name.lower() in (p.info['name'] or '').lower():
                p.kill()
    except Exception:
        pass
    
    return obs.status == "VERIFIED", rect_data

def main():
    dpi, scale = get_system_dpi_scale()
    print(f"Current System DPI: {dpi} ({scale}% Scaling)")
    
    calc_ok, calc_rect = test_app_bounds("calc.exe", "CalculatorApp.exe", "Calculator")
    if not calc_ok:
        # Retry with standard calc
        calc_ok, calc_rect = test_app_bounds("calc.exe", "calc.exe", "Calculator")
        
    edge_ok, edge_rect = test_app_bounds("start msedge", "msedge.exe", "Edge")
    
    print("\nSummary Results:")
    print(f"DPI: {scale}%")
    print(f"Calculator Found: {calc_ok}, Rect: {calc_rect}")
    print(f"Edge Found: {edge_ok}, Rect: {edge_rect}")

if __name__ == "__main__":
    main()
