"""
scripts/user_gui_smoke_test.py - User-Run Standalone Smoke Test for 10 GUI Commands

RUN INSTRUCTIONS (Per GOKU RULE 16):
Execute this script from a standalone PowerShell window with your IDE closed or minimized:
    powershell.exe
    cd <path_to_GOKU>
    python scripts/user_gui_smoke_test.py
"""
import sys
import time
from pathlib import Path

# Add project root to sys.path
root = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(root))

from command_layer.router import route_command, handle_command
from tools.input_guard import AUDIT_LOG_PATH

COMMANDS = [
    ("1. Launch Notepad", "Notepad kholo"),
    ("2. Type Text into Notepad", "Notepad mein hello world likho"),
    ("3. Save Document", "test.txt file save karo"),
    ("4. Create Test Folder", "Desktop par test_project_folder banao"),
    ("5. Open Documents", "Documents kholo"),
    ("6. Launch Calculator", "Calculator kholo"),
    ("7. Switch Focus to Calculator", "Calculator window samne lao"),
    ("8. Switch Focus to Notepad", "Notepad window samne lao"),
    ("9. Close Calculator", "Calculator band karo"),
    ("10. Close Notepad", "Notepad band karo"),
]

def main():
    print("=" * 60)
    print("GOKU 10 REAL GUI COMMANDS SMOKE TEST (STANDALONE INTERACTIVE)")
    print("=" * 60)
    
    results = []
    for label, cmd in COMMANDS:
        print(f"\n[RUNNING] {label} -> '{cmd}'")
        plan = route_command(cmd)
        print(f"  Plan: {[s.tool for s in plan.steps] if plan else 'None'}")
        
        try:
            res = handle_command(cmd)
            status = "PASSED" if res and "error" not in str(res).lower() else "FAILED"
            print(f"  Result: {status} | Output: {str(res)[:80]}")
            results.append((label, cmd, status))
        except Exception as e:
            print(f"  Exception: {e}")
            results.append((label, cmd, f"ERROR: {e}"))
        time.sleep(1.0)

    print("\n" + "=" * 60)
    print("SUMMARY OF EXECUTION:")
    print("=" * 60)
    for label, cmd, st in results:
        print(f" - {label:30} : {st}")
    print(f"\nAudit log appended at: {AUDIT_LOG_PATH}")

if __name__ == "__main__":
    main()
