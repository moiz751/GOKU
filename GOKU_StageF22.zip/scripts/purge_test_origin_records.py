"""
scripts/purge_test_origin_records.py - Authorized Test-Origin Data Purge
Follows GOKU RULES v2 + v3 Prompt A3 Step 4:
- Requires user explicit approval ('--confirm-purge') to execute.
- Purges test-origin records from:
  1. memory/experience_store.json
  2. memory/user_lexicon.json
  3. execution_traces.jsonl
- Logs every removed record ID to logs/data_purge.log.
"""
from __future__ import annotations

import json
from pathlib import Path
import re
import sys
import time

LOG_PATH = Path("logs/data_purge.log")
LOG_PATH.parent.mkdir(parents=True, exist_ok=True)

TEST_NAME_REGEX = re.compile(r"_\d{10,}$|test_|mock_|dummy|synthetic", re.IGNORECASE)


def log_removal(file_source: str, record_id: str, reason: str):
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    with open(LOG_PATH, "a", encoding="utf-8") as f:
        f.write(f"[{ts}] [{file_source}] REMOVED: {record_id} | Reason: {reason}\n")


def execute_purge(dry_run: bool = True):
    print("=" * 70)
    print("GOKU PROMPT A3: TEST-ORIGIN RECORD PURGE ENGINE")
    print(f"Mode: {'DRY RUN (NO CHANGES)' if dry_run else 'ACTIVE PURGE'}")
    print("=" * 70)

    # 1. experience_store.json
    exp_path = Path("memory/experience_store.json")
    if exp_path.exists():
        with open(exp_path, "r", encoding="utf-8") as f:
            exp_data = json.load(f)

        records = exp_data.get("records", [])
        clean_records = []
        purged_records = []

        for r in records:
            task_id = str(r.get("task_id", ""))
            tool = str(r.get("tool", ""))
            remedy = str(r.get("remedy", ""))
            is_test = bool(TEST_NAME_REGEX.search(tool) or TEST_NAME_REGEX.search(task_id) or "test" in remedy.lower())
            if is_test:
                purged_records.append(r)
                if not dry_run:
                    log_removal("experience_store.records", task_id or tool, f"tool={tool}")
            else:
                clean_records.append(r)

        # Promoted remedies
        promoted = exp_data.get("promoted_remedies", {})
        clean_promoted = {}
        for sig, rem in promoted.items():
            if TEST_NAME_REGEX.search(sig) or "test" in str(rem).lower():
                if not dry_run:
                    log_removal("experience_store.promoted", sig, str(rem))
            else:
                clean_promoted[sig] = rem

        print(f"1. memory/experience_store.json: {len(purged_records)} records flagged for purge ({len(clean_records)} retained).")

        if not dry_run:
            exp_data["records"] = clean_records
            exp_data["promoted_remedies"] = clean_promoted
            with open(exp_path, "w", encoding="utf-8") as f:
                json.dump(exp_data, f, indent=2)
            print("   -> memory/experience_store.json written cleanly.")

    # 2. user_lexicon.json
    lex_path = Path("memory/user_lexicon.json")
    if lex_path.exists():
        with open(lex_path, "r", encoding="utf-8") as f:
            lex_data = json.load(f)

        corrections = lex_data.get("corrections", [])
        clean_corrections = []
        purged_lex = []

        for c in corrections:
            orig = str(c.get("original", ""))
            corr = str(c.get("corrected", ""))
            is_test = bool(
                re.search(r"calc_\d+|test_app_\d+|dummy|mock", orig, re.IGNORECASE) or
                re.search(r"calc_\d+|test_app_\d+|dummy|mock", corr, re.IGNORECASE)
            )
            if is_test:
                purged_lex.append(c)
                if not dry_run:
                    log_removal("user_lexicon.corrections", f"{orig} -> {corr}", "synthetic test correction")
            else:
                clean_corrections.append(c)

        print(f"2. memory/user_lexicon.json: {len(purged_lex)} corrections flagged for purge ({len(clean_corrections)} retained).")

        if not dry_run:
            lex_data["corrections"] = clean_corrections
            with open(lex_path, "w", encoding="utf-8") as f:
                json.dump(lex_data, f, indent=2)
            print("   -> memory/user_lexicon.json written cleanly.")

    # 3. execution_traces.jsonl
    traces_path = Path("execution_traces.jsonl")
    if traces_path.exists():
        with open(traces_path, "r", encoding="utf-8") as f:
            trace_lines = f.readlines()

        clean_traces = []
        purged_traces = 0

        for line in trace_lines:
            try:
                row = json.loads(line)
                tools_called = [str(t) for t in row.get("tools_called", [])]
                raw_cmd = str(row.get("raw_command", ""))
                is_test = any(TEST_NAME_REGEX.search(t) for t in tools_called) or bool(re.search(r"dummy|mock|test_\d+", raw_cmd, re.IGNORECASE))
                if is_test:
                    purged_traces += 1
                    if not dry_run:
                        turn_id = row.get("turn_id", "unknown")
                        log_removal("execution_traces.jsonl", str(turn_id), f"tools={tools_called}")
                else:
                    clean_traces.append(line)
            except Exception:
                clean_traces.append(line)

        print(f"3. execution_traces.jsonl: {purged_traces} traces flagged for purge ({len(clean_traces)} retained).")

        if not dry_run:
            with open(traces_path, "w", encoding="utf-8") as f:
                f.writelines(clean_traces)
            print("   -> execution_traces.jsonl written cleanly.")

    print("=" * 70)


if __name__ == "__main__":
    is_active = "--confirm-purge" in sys.argv
    if not is_active:
        print("[GATE NOTICE] Running in DRY-RUN mode. To execute actual purge after approval, pass --confirm-purge")
    execute_purge(dry_run=not is_active)
