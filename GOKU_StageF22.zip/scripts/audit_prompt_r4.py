"""
scripts/audit_prompt_r4.py - Verification & Audit Script for Prompt R4.
Follows GOKU RULES v2 + 16-26 (Rule 20: No hand-typed statistics).

Audits:
1. Application Profiles in apps_profiles.json (Notepad, Calculator, Settings, Chrome).
2. Offline Reproduction & Fix of 'target_not_found' (MISTAKES.MD #1) across all recorded fixtures.
3. Ownership Registry lifecycle safety, WM_CLOSE, and refusal of unowned windows.
4. Process & window leak detector metrics.
"""
from __future__ import annotations

import json
from pathlib import Path
import sys
import time
from typing import Any, Dict

WORKSPACE_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(WORKSPACE_ROOT))

from tools.window_lifecycle import (
    load_app_profiles,
    find_matching_new_window,
    OwnershipRegistry,
    WindowSnapshotEntry,
)
from scripts.leak_check import capture_full_leak_state, compare_leak_states


def _dict_to_snapshot(data: Dict[str, Any]) -> Dict[int, WindowSnapshotEntry]:
    res = {}
    for h_str, d in data.items():
        h = int(h_str)
        res[h] = WindowSnapshotEntry(
            hwnd=h,
            pid=d["pid"],
            class_name=d["class_name"],
            title=d["title"],
            visible=d["visible"],
            owner=d["owner"],
            image_name=d.get("image_name", ""),
        )
    return res


def main():
    print("=" * 80)
    print("GOKU PROMPT R4: APP LIFECYCLE & WINDOW FINDING AUDIT")
    print(f"Timestamp: {time.strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 80)

    # 1. Profile Audit
    profiles = load_app_profiles()
    print("\n[1] APPS PROFILES AUDIT (apps_profiles.json)")
    print(f"Total Profiles Configured: {len(profiles)}")
    for k, p in profiles.items():
        print(f"  - Profile: {k:<12} | Type: {p.get('type'):<20} | Close: {p.get('close', {}).get('method')}")
        if p.get("type") == "uwp":
            print(f"    * Top Class: {p.get('top_level_class')} -> Host: {p.get('host_process')}")
            print(f"    * Child Class: {p.get('child_class')} -> Real: {p.get('real_process')}")
        elif p.get("type") == "win32_multi_instance":
            print(f"    * Class: {p.get('class')} -> Executable: {p.get('executable')}")
            print(f"    * Flags: {p.get('launch_flags')} | Test Flags: {p.get('test_flags')}")
        else:
            print(f"    * Class: {p.get('class')} -> Process: {p.get('process')}")

    # 2. Offline Snapshot Reproduction & Fix Audit
    fixtures_dir = WORKSPACE_ROOT / "tests" / "fixtures" / "snapshots"
    fixture_files = list(fixtures_dir.glob("*.json"))
    print("\n[2] RECORDED SNAPSHOT REPRODUCTION & FIX AUDIT")
    print(f"Fixtures Found in tests/fixtures/snapshots: {len(fixture_files)}")

    reproduction_results = []
    for fpath in fixture_files:
        with open(fpath, "r", encoding="utf-8") as f:
            data = json.load(f)

        before_snap = _dict_to_snapshot(data["before_snapshot"])
        after_snap = _dict_to_snapshot(data["after_snapshot"])
        launcher_pid = data.get("launcher_pid", 0)
        app_name = data.get("app_name", fpath.stem.split("_")[0])
        child_wins = data.get("child_windows", {})

        # Old PID-only logic test
        old_matched_hwnd = None
        for h, win in after_snap.items():
            if win.pid == launcher_pid:
                old_matched_hwnd = h
                break

        old_status = "FOUND" if old_matched_hwnd is not None else "NOT_FOUND"

        # New profile + snapshot diff logic test
        def mock_resolver(p_hwnd: int, cw=child_wins):
            c_list = cw.get(str(p_hwnd), [])
            for c in c_list:
                if c.get("class_name") == "Windows.UI.Core.CoreWindow":
                    return c.get("pid", 0), c.get("image_name", "")
            return 0, ""

        found = find_matching_new_window(
            before_snap,
            after_snap,
            app_name=app_name,
            profiles=profiles,
            offline_child_resolver=mock_resolver,
        )

        new_status = "FOUND" if found is not None else "NOT_FOUND"
        details = found[1] if found else {}

        reproduction_results.append({
            "fixture": fpath.name,
            "app": app_name,
            "old_status": old_status,
            "new_status": new_status,
            "resolved_pid": details.get("resolved_pid"),
            "resolved_image": details.get("resolved_image"),
            "type": details.get("type"),
        })

        print(f"  - Fixture: {fpath.name}")
        print(f"    Target: {app_name} | Old PID Match: {old_status} | New Diff Match: {new_status}")
        if found:
            entry = found[0]
            print(f"    Discovered: HWND {entry.hwnd} (Class: {entry.class_name}) | Resolved: PID {details.get('resolved_pid')} ({details.get('resolved_image')})")

    # 3. Ownership Registry Safety Audit
    print("\n[3] OWNERSHIP REGISTRY SAFETY AUDIT")
    reg = OwnershipRegistry()
    reg.clear()

    # Unowned window close attempt
    unowned_res = reg.close_owned(0x999999)
    print(f"  - Unowned Close Refusal: Status = {unowned_res.get('status')} | Success = {unowned_res.get('success')}")

    # Registered window safe close attempt
    reg.register(hwnd=0x123456, pid=54321, app_name="test_app", how_proven="diff_test")
    is_owned_before = reg.is_owned(0x123456)
    owned_res = reg.close_owned(0x123456)
    is_owned_after = reg.is_owned(0x123456)
    print(f"  - Proven Window Close  : Status = {owned_res.get('status')} | Registered Before = {is_owned_before} | Owned After = {is_owned_after}")

    # 4. Live Desktop Leak Check State
    print("\n[4] LIVE DESKTOP LEAK CHECK STATE")
    s1 = capture_full_leak_state()
    time.sleep(0.1)
    s2 = capture_full_leak_state()
    leak_res = compare_leak_states(s1, s2)
    print(f"  - Processes Active: {len(s1['processes'])}")
    print(f"  - Windows Active  : {len(s1['windows'])}")
    print(f"  - Survivor Processes: {leak_res['survivor_process_count']}")
    print(f"  - Survivor Windows  : {leak_res['survivor_window_count']}")
    print(f"  - Leak Verdict      : {'LEAK' if leak_res['has_leaks'] else 'CLEAN (NO LEAKS)'}")

    # Write summary artifact
    out_file = WORKSPACE_ROOT / "reports" / "r4_audit_summary.json"
    out_file.parent.mkdir(parents=True, exist_ok=True)
    summary_data = {
        "timestamp": time.strftime('%Y-%m-%d %H:%M:%S'),
        "profiles_count": len(profiles),
        "fixtures_count": len(fixture_files),
        "reproduction_results": reproduction_results,
        "unowned_refused": unowned_res.get("status") == "REFUSED_UNOWNED",
        "owned_closed": owned_res.get("success") is True,
        "leak_clean": not leak_res["has_leaks"],
        "processes_active": len(s1["processes"]),
        "windows_active": len(s1["windows"]),
    }
    with open(out_file, "w", encoding="utf-8") as f:
        json.dump(summary_data, f, indent=2)
    print(f"\n[INFO] Audit summary saved cleanly to: {out_file}")
    print("=" * 80)


if __name__ == "__main__":
    main()
