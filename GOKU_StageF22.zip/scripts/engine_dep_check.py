"""Stage F16: re-run the optional-library dependency check on YOUR machine (offline machines: skip). Uses `pip install --dry-run` only - nothing is installed.
Usage: python scripts/engine_dep_check.py [lib ...]. The committed result of the sandbox run (python 3.11 / win_amd64, wheel-only) is data/engine_dep_report.json."""
import json
import subprocess
import sys

LIBS = sys.argv[1:] or ["sympy", "pandas", "scipy", "networkx", "shapely", "spacy", "chromadb", "qdrant-client"]
for lib in LIBS:
    p = subprocess.run([sys.executable, "-m", "pip", "install", "--dry-run", "--quiet", "--no-input", "-r", "requirements.txt", lib], capture_output=True, text=True, timeout=300)
    print(json.dumps({"lib": lib, "resolves_with_requirements": p.returncode == 0, "tail": (p.stdout + p.stderr).strip().splitlines()[-2:]}))
