"""Run the static security audit: python scripts/security_audit.py [--json out.json]. Read-only."""
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from security.static_audit import audit_tree, render  # noqa: E402

if __name__ == "__main__":
    rep = audit_tree(str(ROOT))
    print(render(rep))
    if "--json" in sys.argv:
        Path(sys.argv[sys.argv.index("--json") + 1]).write_text(json.dumps(rep, indent=1), encoding="utf-8")
