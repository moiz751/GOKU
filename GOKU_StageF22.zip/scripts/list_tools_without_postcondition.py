"""
scripts/list_tools_without_postcondition.py - Audit Tools Lacking Truth Contracts
Follows GOKU RULES v2 + v3 Prompt A3 Step 5.
Identifies every tool registered in GOKU that lacks an independent postcondition contract
in executor/truth_oracle.py, sorted by execution frequency in execution_traces.jsonl.
"""
from __future__ import annotations

from collections import Counter
import json
from pathlib import Path
import sys

# Add project root to sys.path
_ROOT = Path(__file__).resolve().parent.parent
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

from executor.truth_oracle import TOOL_CONTRACTS
from tools.registry import discover_tools, TOOLS, DESTRUCTIVE_TOOLS, MUTATIVE_TOOLS, ACTIVE_INSPECTION_TOOLS, STATE_CHANGING_TOOLS


def analyze_uncontracted_tools():
    print("=" * 80)
    print("GOKU PROMPT A3 - STEP 5: TOOLS WITHOUT INDEPENDENT POSTCONDITIONS")
    print("=" * 80)

    try:
        discover_tools()
    except Exception:
        pass

    all_known_tools = set(TOOLS.keys()) | DESTRUCTIVE_TOOLS | MUTATIVE_TOOLS | ACTIVE_INSPECTION_TOOLS | STATE_CHANGING_TOOLS
    contract_tools = set(TOOL_CONTRACTS.keys())

    # Count executions from execution_traces.jsonl
    traces_path = Path("execution_traces.jsonl")
    tool_counts = Counter()

    if traces_path.exists():
        with open(traces_path, "r", encoding="utf-8", errors="ignore") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    data = json.loads(line)
                    tools = data.get("tools_executed") or []
                    if isinstance(tools, list):
                        for t in tools:
                            tool_counts[str(t)] += 1
                    elif isinstance(tools, str):
                        tool_counts[tools] += 1
                except Exception:
                    pass

    missing_contracts = []
    for t_name in sorted(all_known_tools):
        if t_name not in contract_tools:
            freq = tool_counts.get(t_name, 0)
            missing_contracts.append((t_name, freq))

    # Sort descending by frequency, then alphabetically
    missing_contracts.sort(key=lambda x: (x[1], x[0]), reverse=True)

    print(f"Total Known Registered Tools: {len(all_known_tools)}")
    print(f"Tools WITH Contracts        : {len(contract_tools)}")
    print(f"Tools WITHOUT Contract      : {len(missing_contracts)}")
    print("-" * 80)
    print(f"{'#':<4} {'Tool Name':<40} {'Trace Executions':<18} {'Rule 22 Postcondition Status'}")
    print("-" * 80)
    for idx, (t_name, freq) in enumerate(missing_contracts, 1):
        print(f"{idx:<4} {t_name:<40} {freq:<18} UNVERIFIED ('no postcondition')")
    print("=" * 80)

    return missing_contracts


if __name__ == "__main__":
    analyze_uncontracted_tools()
