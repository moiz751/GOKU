"""
scripts/measure_lanes.py - Measure and Report Test Lane Durations
Follows GOKU RULES v2 + Prompt R2 Step 6.

Reports:
1. Baseline XML durations per lane.
2. Dev mode execution measurements for smoke and core lanes.
3. User run instructions for gui, llm, and full lanes.
"""
from __future__ import annotations

import argparse
import json
import os
import sys


def measure_lanes(lanes_path: str = "tests/lanes.json"):
    if not os.path.exists(lanes_path):
        print(f"Error: {lanes_path} not found.")
        sys.exit(1)

    with open(lanes_path, "r", encoding="utf-8") as f:
        data = json.load(f)

    lane_counts = data.get("lane_counts", {})
    tests = data.get("tests", {})

    # Compute XML sum per lane
    xml_sums = {k: 0.0 for k in lane_counts}
    for tid, info in tests.items():
        dur = info.get("duration", 0.0)
        for l in info.get("lanes", []):
            if l in xml_sums:
                xml_sums[l] += dur

    print("=" * 80)
    print("PROMPT R2 - TEST LANE MEASUREMENTS & DURATION SUMMARY")
    print("=" * 80)
    print("1. MEASURED DURATIONS FROM FULL_SUITE.XML BASELINE:")
    print("-" * 80)
    print(f"{'Lane':<12} | {'Tests':<8} | {'XML Duration (s)':<18} | {'Duration (min)':<14} | {'Runner'}")
    print("-" * 80)
    runners = {
        "smoke": "Agent Shell (Dev Mode)",
        "core": "Agent Shell (Dev Mode)",
        "gui": "User Run (Run Mode)",
        "llm": "User Run (Run Mode)",
        "fs_real": "User Run (Run Mode)",
        "full": "User Run (Full Suite)",
    }
    for lane in ["smoke", "core", "gui", "llm", "fs_real", "full"]:
        cnt = lane_counts.get(lane, 0)
        t_sec = xml_sums.get(lane, 0.0)
        t_min = t_sec / 60.0
        r = runners.get(lane, "Unknown")
        print(f"{lane:<12} | {cnt:<8d} | {t_sec:10.2f} s       | {t_min:8.2f} min    | {r}")
    print("=" * 80)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Measure lane durations")
    parser.add_argument("--lanes", default="tests/lanes.json", help="Path to lanes.json")
    args = parser.parse_args()
    measure_lanes(args.lanes)
