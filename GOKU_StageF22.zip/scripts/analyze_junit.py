"""
scripts/analyze_junit.py - Comprehensive JUnit XML Analyzer
Follows GOKU RULES v2 + v3 Prompt A3 Step 1.
Reads any JUnit XML, tallies pass/fail/error/skip directly from testcases,
groups failures by exception type, module, and normalized first message line,
identifies the 20 slowest tests, counts tests per module,
and writes full analysis JSON next to the XML.
"""
from __future__ import annotations

import argparse
from collections import Counter
import json
import os
from pathlib import Path
import re
import sys
import xml.etree.ElementTree as ET


def normalize_line(line: str) -> str:
    cleaned = re.sub(r"\s+", " ", line.strip())
    # Strip memory addresses and hex handles
    cleaned = re.sub(r"0x[0-9a-fA-F]+", "0x...", cleaned)
    # Strip paths
    cleaned = re.sub(r"[A-Za-z]:\\[^\s'\"]+", "<PATH>", cleaned)
    return cleaned


def analyze_junit(xml_path: Path):
    if not xml_path.exists():
        print(f"Error: XML file not found at {xml_path}")
        sys.exit(1)

    xml_path.stat()
    mtime_str = os.path.getmtime(xml_path)
    import datetime
    mtime_dt = datetime.datetime.fromtimestamp(mtime_str)

    tree = ET.parse(xml_path)
    root = tree.getroot()

    ts_elem = root.find(".//testsuite")
    xml_timestamp = root.attrib.get("timestamp") or (ts_elem.attrib.get("timestamp") if ts_elem is not None else "N/A")
    root_tests = root.attrib.get("tests") or (ts_elem.attrib.get("tests") if ts_elem is not None else None)
    root_failures = root.attrib.get("failures") or (ts_elem.attrib.get("failures") if ts_elem is not None else None)
    root_errors = root.attrib.get("errors") or (ts_elem.attrib.get("errors") if ts_elem is not None else None)
    root_skipped = root.attrib.get("skipped") or (ts_elem.attrib.get("skipped") if ts_elem is not None else None)
    root_time = root.attrib.get("time") or (ts_elem.attrib.get("time") if ts_elem is not None else None)

    testcases = root.findall(".//testcase")
    total_testcases = len(testcases)

    passed_count = 0
    failed_count = 0
    error_count = 0
    skipped_count = 0

    failures_by_exc = Counter()
    failures_by_module = Counter()
    failures_by_msg_first_line = Counter()
    tests_per_module = Counter()

    all_tests_timed = []
    failure_details = []

    for tc in testcases:
        classname = tc.attrib.get("classname", "unknown")
        name = tc.attrib.get("name", "unknown")
        duration = float(tc.attrib.get("time", 0.0) or 0.0)
        parts = classname.split(".")
        if parts[0] == "tests" and len(parts) > 1:
            module = parts[1]
        else:
            module = parts[0]

        tests_per_module[module] += 1
        all_tests_timed.append({"name": f"{classname}::{name}", "time": duration, "module": module})

        fail_elem = tc.find("failure")
        err_elem = tc.find("error")
        skip_elem = tc.find("skipped")

        if fail_elem is not None:
            failed_count += 1
            exc_type = fail_elem.attrib.get("type", "")
            msg = fail_elem.attrib.get("message", "")
            raw_text = (fail_elem.text or "").strip()

            if not exc_type:
                # Try finding exception from text
                m = re.search(r"(\w+Error|\w+Exception|AssertionError):", raw_text)
                if m:
                    exc_type = m.group(1)
                else:
                    exc_type = "UnknownError"

            first_line = msg.split("\n")[0] if msg else (raw_text.split("\n")[0] if raw_text else "")
            norm_first_line = normalize_line(first_line)

            failures_by_exc[exc_type] += 1
            failures_by_module[module] += 1
            failures_by_msg_first_line[norm_first_line] += 1

            failure_details.append({
                "test": f"{classname}::{name}",
                "module": module,
                "exc_type": exc_type,
                "first_line": norm_first_line,
                "duration": duration,
            })
        elif err_elem is not None:
            error_count += 1
            exc_type = err_elem.attrib.get("type", "Error")
            failures_by_exc[exc_type] += 1
            failures_by_module[module] += 1
        elif skip_elem is not None:
            skipped_count += 1
        else:
            passed_count += 1

    # 20 slowest tests
    slowest_20 = sorted(all_tests_timed, key=lambda x: x["time"], reverse=True)[:20]

    output_data = {
        "xml_path": str(xml_path),
        "file_mtime": mtime_dt.isoformat(),
        "xml_header_timestamp": xml_timestamp,
        "header_attribs": {
            "tests": root_tests,
            "failures": root_failures,
            "errors": root_errors,
            "skipped": root_skipped,
            "time_seconds": root_time,
        },
        "counted_totals": {
            "total_testcases": total_testcases,
            "passed": passed_count,
            "failed": failed_count,
            "errors": error_count,
            "skipped": skipped_count,
        },
        "failures_by_exception_type": dict(failures_by_exc.most_common()),
        "failures_by_module": dict(failures_by_module.most_common()),
        "top_failure_messages": dict(failures_by_msg_first_line.most_common(20)),
        "tests_per_module": dict(tests_per_module.most_common()),
        "slowest_20_tests": slowest_20,
    }

    # Write JSON next to XML
    json_path = xml_path.with_name(f"{xml_path.stem}_analysis.json")
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(output_data, f, indent=2)

    # Print Report
    print("=" * 80)
    print(f"JUNIT XML ANALYSIS REPORT: {xml_path}")
    print("=" * 80)
    print(f"File Modification Time (mtime): {mtime_dt.isoformat()} ({mtime_str})")
    print(f"XML Header Timestamp          : {xml_timestamp}")
    print(f"XML Header Declared Totals    : tests={root_tests}, failures={root_failures}, errors={root_errors}, skipped={root_skipped}, time={root_time}s")
    print("-" * 80)
    print("COUNTED FROM TESTCASES:")
    print(f"  Total Test Cases : {total_testcases}")
    print(f"  Passed           : {passed_count}")
    print(f"  Failed           : {failed_count}")
    print(f"  Errors           : {error_count}")
    print(f"  Skipped          : {skipped_count}")
    print("-" * 80)
    print("FAILURES BY EXCEPTION TYPE:")
    for exc, cnt in failures_by_exc.most_common():
        print(f"  {cnt:>4} : {exc}")
    print("-" * 80)
    print("FAILURES BY MODULE:")
    for mod, cnt in failures_by_module.most_common():
        print(f"  {cnt:>4} : {mod}")
    print("-" * 80)
    print("TOP 15 NORMALIZED FAILURE FIRST-LINES:")
    for msg, cnt in failures_by_msg_first_line.most_common(15):
        print(f"  {cnt:>4} : {msg[:90]}")
    print("-" * 80)
    print("TOP 20 SLOWEST TESTS:")
    for idx, t in enumerate(slowest_20, 1):
        print(f"  {idx:>2}. {t['time']:>6.2f}s : {t['name']}")
    print("-" * 80)
    print(f"Analysis written to JSON: {json_path}")
    print("=" * 80)

    return output_data


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Analyze JUnit XML test suite results")
    parser.add_argument("xml_path", nargs="?", default="reports/full_suite.xml", help="Path to JUnit XML file")
    args = parser.parse_args()
    analyze_junit(Path(args.xml_path))
