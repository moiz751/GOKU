"""
Measures real, separate RAM (Working Set / RSS) for:
1. Python
2. Ollama supervisor (ollama.exe)
3. Ollama llama model runner (ollama_llama_server.exe)
4. Headless Chrome (launched and measured)
"""
from __future__ import annotations

import os
import subprocess
import time
import psutil

def get_process_group_ram(proc_name_substr: str):
    total_rss = 0
    pids = []
    for p in psutil.process_iter(['pid', 'name', 'memory_info']):
        try:
            name = (p.info['name'] or '').lower()
            if proc_name_substr.lower() in name:
                rss = p.info['memory_info'].rss
                total_rss += rss
                pids.append((p.info['pid'], p.info['name'], round(rss / (1024 * 1024), 2)))
        except Exception:
            pass
    return round(total_rss / (1024 * 1024), 2), pids

def main():
    print("=" * 70)
    print(" EMPIRICAL RAM PROFILING BREAKDOWN (PROMPT 11 AUDIT)")
    print("=" * 70)

    # 1. Python
    py_ram, py_procs = get_process_group_ram("python")
    print(f"\n1. Python Process(es): {py_ram} MB total")
    for pid, name, mb in py_procs:
        print(f"   - PID {pid} ({name}): {mb} MB")

    # 2. Ollama supervisor vs runner
    ollama_sup_ram, sup_procs = get_process_group_ram("ollama.exe")
    ollama_run_ram, run_procs = get_process_group_ram("ollama_llama_server")
    print(f"\n2. Ollama Supervisor (ollama.exe): {ollama_sup_ram} MB total")
    for pid, name, mb in sup_procs:
        print(f"   - PID {pid} ({name}): {mb} MB")

    print(f"\n3. Ollama Llama Runner (ollama_llama_server.exe): {ollama_run_ram} MB total")
    for pid, name, mb in run_procs:
        print(f"   - PID {pid} ({name}): {mb} MB")

    total_ollama = ollama_sup_ram + ollama_run_ram
    print(f"   => Combined Ollama Engine: {round(total_ollama, 2)} MB")

    # 4. Headless Chrome measurement
    print("\n4. Measuring Headless Chrome...")
    chrome_path = r"C:\Program Files\Google\Chrome\Application\chrome.exe"
    if not os.path.exists(chrome_path):
        chrome_path = r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe"

    chrome_proc = None
    chrome_ram = 0.0
    chrome_subprocs = []
    if os.path.exists(chrome_path):
        chrome_proc = subprocess.Popen([
            chrome_path,
            "--headless=new",
            "--disable-gpu",
            "--no-first-run",
            "--remote-debugging-port=9222",
            "about:blank"
        ])
        time.sleep(2.0)
        chrome_ram, chrome_subprocs = get_process_group_ram("chrome")
        print(f"   Headless Chrome Total RAM: {chrome_ram} MB")
        for pid, name, mb in chrome_subprocs:
            print(f"   - PID {pid} ({name}): {mb} MB")
        chrome_proc.terminate()
        try:
            chrome_proc.wait(timeout=2.0)
        except Exception:
            chrome_proc.kill()
    else:
        print("   Chrome binary not found at default location.")

    print("\n" + "=" * 70)
    print(" SUMMARY RAM TABLE:")
    print("=" * 70)
    print(f" Python Process (GOKU runtime)       : {py_ram:.2f} MB")
    print(f" Ollama CLI Supervisor (ollama.exe)  : {ollama_sup_ram:.2f} MB")
    print(f" Ollama Model Runner (llama server)  : {ollama_run_ram:.2f} MB")
    print(f" Total Ollama Combined               : {total_ollama:.2f} MB")
    print(f" Headless Chrome (on demand)         : {chrome_ram:.2f} MB")
    print("=" * 70)

if __name__ == "__main__":
    main()
