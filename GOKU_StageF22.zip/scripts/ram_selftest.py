"""
RAM self-test for the laptop. It is safe: it allocates at most ~40% of the RAM that is free right now, in parts, and frees it again.

    python scripts/ram_selftest.py

It shows how GOKU splits work for YOUR free RAM, whether the work finishes, how the parts shrink when you fill RAM
(open a few programs while it runs and run it again), and writes reports/ram/ram_selftest.json. Send that file back.
"""
from __future__ import annotations

import json
import mmap
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from tools import ram_planner as rp
from tools import resource_monitor as rm

free0 = rm.free_ram_mb()
print(f"free RAM now: {free0} MB, pressure: {rm.pressure_level(free0)}")
if free0 is None:
    sys.exit("free RAM could not be measured on this machine")
work_mb = max(200.0, min(free0 * 0.4 * 6, 3000.0))     # total work is several times bigger than the RAM it may use at once
item_mb = 25.0
n = int(work_mb // item_mb)
plan = rp.plan_parts(n, item_mb, free0)
print("plan:", plan["reason"])
peak = [0.0]


def proc(batch):
    maps = []
    for _ in batch:
        m = mmap.mmap(-1, int(item_mb * 1048576))
        for i in range(0, len(m), 4096):
            m[i] = 1
        maps.append(m)
    peak[0] = max(peak[0], (rm._own_rss_mb() or 0))
    out = [len(m) // 1048576 for m in maps]
    for m in maps:
        m.close()
    return out


t = time.time()
runner = rp.PartitionedRunner(list(range(n)), proc, cost=item_mb, max_wait_s=20, poll_s=1)
out = runner.run()
res = {"free_before_mb": free0, "work_mb": n * item_mb, "plan": plan, "result": {k: out[k] for k in ("status", "note", "processed", "total", "parts", "batch_sizes", "shrinks", "grows", "waits", "peak_estimated_mb", "min_free_mb")},
       "own_peak_rss_mb": round(peak[0]), "seconds": round(time.time() - t, 1), "free_after_mb": rm.free_ram_mb()}
print(json.dumps(res, indent=1, default=str))
d = ROOT / "reports" / "ram"
d.mkdir(parents=True, exist_ok=True)
(d / "ram_selftest.json").write_text(json.dumps(res, indent=1, default=str), encoding="utf-8")
print("\nReport:", d / "ram_selftest.json")
