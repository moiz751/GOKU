"""
scripts/analyze_routing_failures.py - Failure Cause Classification Script
Follows GOKU RULES v2 + 16-26 (Prompt R3 Step 2).

Rule Table:
1. no_clarification_when_ambiguous:
   - Expected clarification, but an action tool was returned instead.
   - Or multiple candidates existed, but the router guessed one.
2. wrong_tool:
   - Router executed an action tool that conflicts with the user's intent.
3. wrong_entity:
   - Extracted entity is an action word, conversational noise, or entire phrase.
4. dropped_condition_or_step:
   - Multi-step pipeline or conditional command where 1+ steps or constraints were omitted.
5. stale_context:
   - Pronoun/reference bound to an outdated or unverified entity.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict

WORKSPACE_ROOT = Path(__file__).resolve().parent.parent
TRACE_PATH = WORKSPACE_ROOT / "reports" / "route_trace.jsonl"


def classify_failure(rec: Dict[str, Any]) -> str:
    if rec["verdict"] == "PASS":
        return "none"
        
    cmd = rec["command"].lower()
    exp = rec["expected_tool"]
    dec = rec["decided_tool"]
    
    # 1. no_clarification_when_ambiguous
    if exp == "clarify" and dec != "clarify":
        return "no_clarification_when_ambiguous"
        
    # 2. dropped_condition_or_step
    if "+" in exp:
        # Expected multi-step pipeline
        exp_steps = [s.strip() for s in exp.split("+")]
        dec_steps = [s.strip() for s in dec.split("+")]
        if len(dec_steps) < len(exp_steps):
            return "dropped_condition_or_step"
            
    # 3. wrong_entity
    # Entity was misparsed (e.g., action verb inside entity name)
    if any(k in cmd for k in ["file delete", "close call", "format notes", "kill process"]):
        return "wrong_entity"
        
    # 4. stale_context
    if any(k in cmd for k in ["pichli", "previous", "earlier", "same one"]):
        return "stale_context"
        
    # 5. wrong_tool
    if dec not in ("unhandled_fallback", "clarify") and dec != exp:
        return "wrong_tool"
        
    # 6. Default fallback for unhandled
    if dec == "unhandled_fallback":
        # Missing domain mapping / slot template
        if exp == "clarify":
            return "no_clarification_when_ambiguous"
        return "wrong_tool"
        
    return "wrong_tool"


def analyze():
    print("=" * 80)
    print("PROMPT R3 STEP 2 - ROUTING FAILURE CAUSE AUDIT")
    print("=" * 80)
    print("PRINTED RULE TABLE:")
    print(" - no_clarification_when_ambiguous : Expected clarify, but executed tool; or guessed candidate.")
    print(" - wrong_tool                     : Mapped to wrong tool or failed to match required tool.")
    print(" - wrong_entity                   : Extracted action word, phrase or noise as entity.")
    print(" - dropped_condition_or_step      : Omitted step in multi-step pipeline or condition.")
    print(" - stale_context                  : Bound reference to stale/outdated context.")
    print("=" * 80)
    
    if not TRACE_PATH.exists():
        print(f"Error: {TRACE_PATH} not found. Run trace_router.py first.")
        return
        
    records = []
    with open(TRACE_PATH, "r", encoding="utf-8") as f:
        for line in f:
            if line.strip():
                records.append(json.loads(line.strip()))
                
    causes_count = {
        "no_clarification_when_ambiguous": 0,
        "wrong_tool": 0,
        "wrong_entity": 0,
        "dropped_condition_or_step": 0,
        "stale_context": 0,
    }
    
    table_rows = []
    for r in records:
        cause = classify_failure(r)
        r["failure_cause"] = cause
        if cause != "none":
            causes_count[cause] += 1
        table_rows.append((r["id"], r["command"][:32], r["expected_tool"][:18], r["decided_tool"][:18], r["verdict"], cause))
        
    print(f"{'ID':<8} | {'Command':<32} | {'Expected':<18} | {'Decided':<18} | {'Verdict':<7} | {'Cause'}")
    print("-" * 115)
    for row in table_rows:
        print(f"{row[0]:<8} | {row[1]:<32} | {row[2]:<18} | {row[3]:<18} | {row[4]:<7} | {row[5]}")
        
    print("=" * 80)
    print("AGGREGATE FAILURE COUNTS BY CAUSE:")
    print("=" * 80)
    total_fails = sum(causes_count.values())
    for cause, cnt in sorted(causes_count.items(), key=lambda x: x[1], reverse=True):
        pct = (cnt / total_fails * 100) if total_fails > 0 else 0
        print(f" - {cause:<32}: {cnt:>2} ({pct:>5.1f}%)")
    print("-" * 80)
    print(f"Total Failures: {total_fails} / {len(records)} total traced")
    print(f"Pass Count    : {len(records) - total_fails} / {len(records)} ({((len(records) - total_fails)/len(records)*100):.1f}%)")
    print("=" * 80)
    
    # Save enriched trace
    with open(TRACE_PATH, "w", encoding="utf-8") as f:
        for r in records:
            f.write(json.dumps(r) + "\n")


if __name__ == "__main__":
    analyze()
