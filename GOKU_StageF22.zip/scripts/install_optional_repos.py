"""Stage F22: install the OPTIONAL Python libraries that GOKU can use (voice, vector memory, self-improvement helpers) - on YOUR PC, only when you say so.
GOKU itself never installs anything and never needs the internet; this script is run by you once (pip needs internet once, or point --wheels at a folder of downloaded .whl files).
Default = DRY RUN (prints what it would do). Add --yes to really install. Tiers are chosen by free RAM so a 4 GB laptop is not overloaded:
  light  : vosk pyttsx3 sounddevice                       (small; offline voice)
  medium : faster-whisper sqlite-vec lancedb piper-tts openwakeword
  heavy  : mem0ai cognee graphiti-core letta textgrad gepa dspy   (need >= 16 GB RAM; several pull torch/onnx; most also expect an LLM API - GOKU does not call one)
Usage: python scripts/install_optional_repos.py [--tier light|medium|heavy|all] [--yes] [--wheels DIR] [--force]
chromadb is NOT in any tier: the Windows dry-run found a version conflict with numpy 2.x (use sqlite-vec/lancedb, or chromadb in its own venv).
Models (vosk / whisper / piper voices) are NOT downloaded here: copy them into models/ yourself (see tools/voice_io.py)."""
from __future__ import annotations

import argparse
import subprocess
import sys

TIERS = {
    "light": ["vosk", "pyttsx3", "sounddevice"],
    "medium": ["faster-whisper", "sqlite-vec", "lancedb", "piper-tts", "openwakeword"],
    "heavy": ["mem0ai", "cognee", "graphiti-core", "letta", "textgrad", "gepa", "dspy"],
}
MIN_FREE_GB = {"light": 1.0, "medium": 2.0, "heavy": 12.0}


def free_ram_gb() -> float:
    try:
        import psutil
        return psutil.virtual_memory().available / 1073741824.0
    except Exception:
        return 0.0


def plan(tier: str, ram_gb: float, force: bool = False) -> dict:
    names = ["light", "medium", "heavy"] if tier == "all" else [tier]
    out = {"install": [], "skipped": []}
    for n in names:
        if ram_gb >= MIN_FREE_GB[n] or force:
            out["install"] += TIERS[n]
        else:
            out["skipped"].append({"tier": n, "packages": TIERS[n], "reason": f"free RAM {ram_gb:.1f} GB < {MIN_FREE_GB[n]} GB (use --force to override)"})
    return out


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--tier", default="light", choices=["light", "medium", "heavy", "all"])
    ap.add_argument("--yes", action="store_true", help="really install (default: dry run)")
    ap.add_argument("--wheels", help="folder with pre-downloaded wheels (offline install)")
    ap.add_argument("--force", action="store_true")
    a = ap.parse_args(argv)
    ram = free_ram_gb()
    p = plan(a.tier, ram, a.force)
    print(f"Free RAM now: {ram:.1f} GB | tier: {a.tier} | mode: {'INSTALL' if a.yes else 'DRY RUN'}")
    for s in p["skipped"]:
        print(f"SKIPPED {s['tier']}: {', '.join(s['packages'])} - {s['reason']}")
    if not p["install"]:
        print("Nothing to install.")
        return 0
    rc = 0
    for pkg in p["install"]:
        cmd = [sys.executable, "-m", "pip", "install", "--only-binary=:all:", pkg] if not a.wheels else [sys.executable, "-m", "pip", "install", "--no-index", "--find-links", a.wheels, pkg]
        print(("RUN  " if a.yes else "WOULD RUN  ") + " ".join(cmd))
        if a.yes:
            r = subprocess.run(cmd)
            print(f"  -> {'OK' if r.returncode == 0 else 'FAILED (exit %d)' % r.returncode}")
            rc = rc or r.returncode
    print("Done. Check with: python main.py -> voice status / engine status")
    return rc


if __name__ == "__main__":
    sys.exit(main())
