"""
scripts/claim_check.py - Comprehensive Claim & Forbidden Words Scanner
Follows GOKU RULES v2 + v3 (Prompts L & A3 Step 7).
Scans all root *.md, reports/*.md, and *LEDGER*.json files case-insensitively for:
- 'zero defects'
- '100 percent'
- '100.0%'
- 'production ready'
- 'fully verified'
- 'FROZEN'
- 'CLOSED'
"""
from __future__ import annotations

import glob
from pathlib import Path
import re
import sys

FORBIDDEN_PATTERNS = [
    (re.compile(r"zero defects", re.IGNORECASE), "zero defects"),
    (re.compile(r"100 percent", re.IGNORECASE), "100 percent"),
    (re.compile(r"100\.0%", re.IGNORECASE), "100.0%"),
    (re.compile(r"production ready", re.IGNORECASE), "production ready"),
    (re.compile(r"fully verified", re.IGNORECASE), "fully verified"),
    (re.compile(r"\bFROZEN\b"), "FROZEN"),
    (re.compile(r"\b(?:STATUS:\s*)?CLOSED\b"), "CLOSED"),
]


def get_target_files() -> list[Path]:
    root_md = [Path(p) for p in glob.glob("*.md")]
    reports_md = [Path(p) for p in glob.glob("reports/*.md")]
    ledger_json = [Path(p) for p in glob.glob("*LEDGER*.json") + glob.glob("reports/*LEDGER*.json")]
    all_files = sorted(list(set(root_md + reports_md + ledger_json)))
    return all_files


def check_claims():
    print("=" * 70)
    print("GOKU PROMPT A3 / L - STEP 7: CLAIM CHECK & FORBIDDEN PHRASE SCANNER")
    print("=" * 70)

    target_files = get_target_files()
    print(f"Total target files discovered: {len(target_files)}")

    violations = []

    for path in target_files:
        if not path.exists():
            continue

        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            lines = f.readlines()

        print(f"Scanning {path} ({len(lines)} lines)...")
        for line_num, line in enumerate(lines, 1):
            for pattern, name in FORBIDDEN_PATTERNS:
                match = pattern.search(line)
                if match:
                    # Allow historical quotes if explicitly marked as retracted/forbidden/rule/prerequisite
                    lower_line = line.lower()
                    if any(w in lower_line for w in [
                        "forbidden", "retracted", "do not use", "rule", "prerequisite", 
                        "instruction", "claim (", "claims (", "step 4", "checkers:"
                    ]):
                        continue
                    # Skip benign operational descriptions
                    if any(b in lower_line for b in ["closed chrome", "ide closed", "closed-loop"]):
                        continue
                    violations.append({
                        "file": str(path),
                        "line": line_num,
                        "type": "FORBIDDEN_PHRASE",
                        "matched": match.group(0),
                        "content": line.strip()[:100],
                    })

    print(f"\nScan complete across {len(target_files)} files.")
    print(f"Total forbidden phrase violations found: {len(violations)}")
    for v in violations:
        print(f" - [{v['type']}] {v['file']}:{v['line']} -> '{v['matched']}' in: \"{v['content']}\"")

    if violations:
        print("\nFAIL: Forbidden phrases detected! Clean up before proceeding.")
        sys.exit(1)
    else:
        print("\nPASS: ZERO forbidden phrases detected across all scanned reports and ledgers.")
        print("=" * 70)


if __name__ == "__main__":
    check_claims()
