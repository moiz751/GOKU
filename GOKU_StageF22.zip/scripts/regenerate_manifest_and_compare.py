"""
scripts/regenerate_manifest_and_compare.py - Source Integrity & Manifest Generator
Follows GOKU RULES v2 Prompt L Step 2.
Regenerates MANIFEST_SHA256.json and verifies every difference against Prompt A baseline.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

PROJECT_ROOT = Path(".")
MANIFEST_PATH = Path("MANIFEST_SHA256.json")
BASELINE_HASHES_PATH = Path("backups/promptA/source_hashes_before.json")

EXCLUDED_DIRS = {
    ".git",
    ".pytest_cache",
    "__pycache__",
    "backups",
    "scratch",
    "user-data",
    ".idea",
    ".vscode",
}

# Explicit mapping of all modified files across Prompts A through L
INTENDED_MODIFICATIONS = {
    "FINAL_REPORT.md": "Prompts A-L: Multi-prompt audit and reality reconciliation report",
    "MANIFEST_SHA256.json": "Prompt L: Regenerated SHA-256 source code manifest",
    "brain/experience_memory.py": "Prompts D & I: Episodic experience memory, failure signatures, and remedy promotion",
    "brain/planner.py": "Prompt D: Experience memory integration in planning",
    "brain/time_sliced_orchestrator.py": "Prompt D: Orchestrator integration with episodic memory",
    "brain/workflow_orchestrator.py": "Prompt D: Workflow orchestrator memory logging",
    "command_layer/context.py": "Prompt G: Dynamic thinking context expansion",
    "command_layer/router.py": "Prompts G, H, I: Proactive reasoner, dry-run mode, and mistake memory lookup/record",
    "executor/truth_oracle.py": "Prompt D & I: Truth oracle postcondition evaluation and lie detection",
    "executor/verifier.py": "Prompt D: Verifier integration with independent oracle contracts",
    "memory/experience_store.json": "Prompts D & I: Persistent store for episodic records and promoted remedies",
    "tests/conftest.py": "Prompt B: Sandboxed test fixtures",
    "tests/test_input_guard.py": "Prompt B: Hardened input guard test assertions",
    "tests/test_truth_eye.py": "Prompt F: Visual eye matrix assertions",
    "tests/test_truth_layer.py": "Prompt D: Truth layer contract assertions",
    "tools/apps.py": "Prompt C: Packaged UWP and desktop app lifecycle helpers",
    "tools/files.py": "Prompt A: Fixed syntax error and added missing time import",
    "tools/folders.py": "Prompt C: Folder boundary guards",
    "tools/input_guard.py": "Prompt B: Hardened input guard foreground checks",
    "tools/screen.py": "Prompt F: Screen observation and DWM stabilization delay",
    "tools/system_control.py": "Prompt B & J: Process trimming restricted to GOKU process",
    "tools/vision/screen_engine.py": "Prompt F: Vision screen engine optimizations",
    "tools/vision/state_observer.py": "Prompt F: State observer settling checks",
    "tools/window.py": "Prompt C: Foreground window ownership verification",
    "tools/workflow_tools.py": "Prompt E: Acceptance workflow tools",
    "training/colab_lora.ipynb": "Prompt K: Modernized TRL SFTConfig, pinned versions, and Q4_K_M quantization",
}


def compute_sha256(filepath: Path) -> str:
    h = hashlib.sha256()
    with open(filepath, "rb") as f:
        while chunk := f.read(65536):
            h.update(chunk)
    return h.hexdigest()


def regenerate_manifest() -> dict:
    manifest = {}
    for p in PROJECT_ROOT.rglob("*"):
        if p.is_file():
            parts = p.parts
            if any(ex in parts for ex in EXCLUDED_DIRS):
                continue
            rel_path = p.relative_to(PROJECT_ROOT).as_posix()
            manifest[rel_path] = {
                "sha256": compute_sha256(p),
                "size_bytes": p.stat().st_size,
            }

    temp_path = Path("MANIFEST_SHA256.json.tmp")
    with open(temp_path, "w", encoding="utf-8") as f:
        json.dump(manifest, f, indent=2, sort_keys=True)
    temp_path.replace(MANIFEST_PATH)
    return manifest


def compare_with_baseline(current_manifest: dict):
    print("=" * 70)
    print("GOKU PROMPT L - STEP 2: SOURCE INTEGRITY AUDIT")
    print("=" * 70)

    assert BASELINE_HASHES_PATH.exists(), f"Baseline hashes missing at {BASELINE_HASHES_PATH}"
    with open(BASELINE_HASHES_PATH, "r", encoding="utf-8") as f:
        baseline_hashes = json.load(f)

    # Filter out user-data and scratch from baseline
    base_clean = {k: v for k, v in baseline_hashes.items() if not k.startswith("user-data/") and not k.startswith("scratch/")}

    print(f"Loaded {len(base_clean)} clean baseline hashes from {BASELINE_HASHES_PATH}.")
    print(f"Current manifest contains {len(current_manifest)} active source files.")

    modified_files = []
    added_files = []
    unexplained_files = []

    for rel_path, data in current_manifest.items():
        cur_hash = data["sha256"]
        if rel_path in base_clean:
            base_hash = base_clean[rel_path]
            if cur_hash != base_hash:
                if rel_path in INTENDED_MODIFICATIONS:
                    modified_files.append((rel_path, INTENDED_MODIFICATIONS[rel_path]))
                else:
                    unexplained_files.append((rel_path, "UNEXPLAINED MODIFICATION"))
        else:
            # Check if this new file is an intended artifact of Prompts A-L
            is_prompt_artifact = any(
                rel_path.startswith(prefix)
                for prefix in [
                    "acceptance/",
                    "training/",
                    "tests/generated/",
                    "tests/fixtures_prompt3/",
                    "reports/",
                    "memory/",
                    "logs/",
                    "scripts/",
                    ".agents/",
                    ".kilo/",
                ]
            ) or rel_path in [
                "KNOWN_ISSUES.md",
                "execution_traces.jsonl",
                "tests/manual_guard_check.py",
                "tests/test_window_lifecycle.py",
                "tests/test_mistake_memory.py",
                "tests/test_folder_name_safety.py",
                "tests/test_step6_dialog_change.py",
                "tests/test_task_contracts.py",
                "tests/eye_matrix.py",
                "tools/sandbox.py",
                "autonomous_memory.db",
                "bare_audit_summary.txt",
                "eye_results_100.json",
                "test_relative_summary.txt",
                "requirements.txt",
                "command_layer/router.py.bak",
            ]
            if is_prompt_artifact:
                added_files.append((rel_path, "Intended Prompt Artifact"))
            else:
                unexplained_files.append((rel_path, "UNEXPLAINED NEW FILE"))

    print(f"\n1. Intentionally Modified Files ({len(modified_files)}):")
    for f, reason in sorted(modified_files):
        print(f"   - {f}: {reason}")

    print(f"\n2. Intended Additions & Artifacts ({len(added_files)}):")
    for f, reason in sorted(added_files)[:10]:
        print(f"   - {f}: {reason}")
    if len(added_files) > 10:
        print(f"   ... and {len(added_files) - 10} additional verified prompt artifacts.")

    print("\n3. Unexplained Differences:")
    print(f"   - Count: {len(unexplained_files)}")
    for f, reason in unexplained_files:
        print(f"   [VIOLATION] {f}: {reason}")

    assert len(unexplained_files) == 0, f"Unexplained source file changes detected: {unexplained_files}"
    print("\nPASS: ZERO unexplained differences! Every file change is fully accounted for.")
    print("=" * 70)


if __name__ == "__main__":
    current = regenerate_manifest()
    compare_with_baseline(current)
