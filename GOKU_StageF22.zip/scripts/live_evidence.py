"""Stage F12: LIVE evidence collector. Run ON YOUR WINDOWS PC:  python scripts\\live_evidence.py [--only id,id] [--url URL --sha256 HASH] [--installer PATH]
Writes evidence/live/<id>.json (only when really run on Windows; on any other OS it refuses and writes nothing). Each record is checked by brain.verifier.verify_live_evidence.
It never asks for or stores passwords/tokens: Shopify/social checks read a token from an environment variable you set yourself and only perform READ-ONLY calls.
Nothing is posted, installed, subscribed or purchased by this script."""
import argparse, hashlib, json, os, platform, subprocess, sys, tempfile, time
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, ROOT)
from brain import verifier as V

def rec(cap, ok, result, log, **extra):
    return {"capability": cap, "live": True, "os": f"{platform.system()} {platform.release()} {platform.version()}", "python": sys.version.split()[0], "when": time.strftime("%Y-%m-%d %H:%M:%S"),
            "result": "PASS" if ok else "FAIL", "detail": result, "log": log, **extra}

def screen(cap):
    from tools import live_observer as LO
    st = LO.status()
    if st["state"] == "BLOCKED_ENVIRONMENT":
        return rec(cap, False, "BLOCKED_ENVIRONMENT", f"missing {st['missing']}")
    p = LO.windows_providers()
    if not p.get("ok"):
        return rec(cap, False, p["why"], "providers unavailable")
    o = p["observe"]()
    ok = bool(o["window"].get("title")) and len(o["elements"]) > 0
    return rec(cap, ok, f"window={o['window'].get('title')!r} elements={len(o['elements'])}", json.dumps(o, default=str)[:4000], mode=st["state"])

def download(cap, url, sha):
    if not url:
        return rec(cap, False, "NOT_TESTED: pass --url (a small file you trust) and --sha256 from the vendor page", "no url")
    import urllib.request
    from brain import install_plan as IP
    d = tempfile.mkdtemp(); f = os.path.join(d, "dl.bin")
    urllib.request.urlretrieve(url, f)
    v = IP.verify_download(f, None, sha or None)
    return rec(cap, bool(v.get("ok")), f"sha256={v.get('sha256')} size={os.path.getsize(f)}", json.dumps(v, default=str))

def install(cap, path):
    if not path:
        return rec(cap, False, "NOT_TESTED: pass --installer PATH (signature check only; it is NOT executed)", "no installer")
    out = subprocess.run(["powershell", "-NoProfile", "-Command", f"(Get-AuthenticodeSignature -LiteralPath '{path}').Status"], capture_output=True, text=True, timeout=60)
    return rec(cap, out.returncode == 0 and out.stdout.strip() != "", f"Authenticode status: {out.stdout.strip()}", out.stderr[:500] or "ok", executed=False)

def shopify(cap):
    tok, shop = os.environ.get("SHOPIFY_TOKEN"), os.environ.get("SHOPIFY_SHOP")
    if not (tok and shop):
        return rec(cap, False, "NOT_TESTED: set SHOPIFY_SHOP and SHOPIFY_TOKEN (read-only scope) in your own environment", "no credentials")
    import urllib.request
    rq = urllib.request.Request(f"https://{shop}/admin/api/2024-10/shop.json", headers={"X-Shopify-Access-Token": tok})
    with urllib.request.urlopen(rq, timeout=20) as r:
        body = json.loads(r.read().decode())
    return rec(cap, "shop" in body, f"read-only shop.json ok: {body.get('shop', {}).get('name', '?')}", "GET only")

JOBS = {"screen_vision": lambda a: screen("screen_vision"), "screen_loop": lambda a: screen("screen_loop"), "download": lambda a: download("download", a.url, a.sha256),
        "install_policy": lambda a: install("install_policy", a.installer), "shopify_seo_oem": lambda a: shopify("shopify_seo_oem")}

def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--only", default=""); ap.add_argument("--url", default=""); ap.add_argument("--sha256", default=""); ap.add_argument("--installer", default="")
    a = ap.parse_args()
    if platform.system() != "Windows":
        print("REFUSED: live evidence must be collected on Windows (this is", platform.system() + "). Nothing written."); return 2
    os.makedirs(os.path.join(ROOT, "evidence", "live"), exist_ok=True)
    ids = [x for x in a.only.split(",") if x] or list(JOBS)
    bad = 0
    for i in ids:
        try:
            r = JOBS[i](a)
        except Exception as e:
            r = rec(i, False, f"{type(e).__name__}: {e}", "exception")
        chk = V.verify_live_evidence(r)
        if r["result"] == "PASS" and chk["ok"]:
            json.dump(r, open(os.path.join(ROOT, "evidence", "live", i + ".json"), "w"), indent=1)
        else:
            bad += 1
        print(i, r["result"], r["detail"][:120], "" if chk["ok"] else "(record invalid: " + chk["why"] + ")")
    return 1 if bad else 0

if __name__ == "__main__":
    sys.exit(main())
