"""
Department capability tests A-L (Stage F7).

Usage:  python scripts/department_tests.py [--only A,K] [--out logs/department_report.md]

* Tests that can run anywhere (planner decisions, local file work, local HTTP download, translation, watcher
  logic on synthetic frames, honest refusals) are executed and judged by their own verification evidence.
* Tests that need the real Windows desktop, a real browser, a live LLM or the real internet are marked
  NEEDS_LAPTOP - they are never reported as passed here.
Every executed test produces an Individual Test Report (15-field execution trace). Nothing is overwritten
without confirmation: all file work happens in a temporary folder.
"""
from __future__ import annotations

import argparse
import http.server
import json
import os
import sys
import tempfile
import threading
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from brain import task_route_planner as RP  # noqa: E402
from brain import translate as TR  # noqa: E402
from brain.execution_trace import Trace  # noqa: E402

LAPTOP = "NEEDS_LAPTOP"


def _env(**kw):
    e = RP.probe_env(need_net=False)
    e.update(kw)
    return e


def _good_env(**kw):
    base = dict(internet=True, browser="chrome", disk_free_mb=50000, ram_free_mb=1200, windows=True, tools={"download_file", "move_file", "copy_file", "rename_file"})
    base.update(kw)
    return _env(**base)


class Home:
    """Temporary home folder so the tests never touch real user files."""

    def __enter__(self):
        self.tmp = tempfile.TemporaryDirectory()
        h = Path(self.tmp.name) / "home"
        for d in ("Downloads", "Desktop", "Documents"):
            (h / d).mkdir(parents=True)
        self.old = (Path.home, os.environ.get("HOME"), os.environ.get("USERPROFILE"), os.environ.get("GOKU_SANDBOX"), Path.cwd())
        Path.home = classmethod(lambda cls: h)  # type: ignore
        os.environ["HOME"] = os.environ["USERPROFILE"] = str(h)
        os.environ.pop("GOKU_SANDBOX", None)
        (Path(self.tmp.name) / "cwd").mkdir()
        os.chdir(Path(self.tmp.name) / "cwd")
        self.h = h
        return h

    def __exit__(self, *a):
        Path.home = self.old[0]  # type: ignore
        for k, v in (("HOME", self.old[1]), ("USERPROFILE", self.old[2]), ("GOKU_SANDBOX", self.old[3])):
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = v
        os.chdir(self.old[4])
        self.tmp.cleanup()


def _serve(root: Path):
    class H(http.server.SimpleHTTPRequestHandler):
        def __init__(self, *a, **k):
            super().__init__(*a, directory=str(root), **k)

        def log_message(self, *a):
            pass
    srv = http.server.ThreadingHTTPServer(("127.0.0.1", 0), H)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv


# each test returns (Trace, passed: bool, note)
def t_a1():
    with Home() as h:
        (h / "Downloads" / "test.txt").write_text("x")
        r = RP.run("test.txt ko Desktop par move karo", _good_env(), save=False)
        return r["trace"], r["trace"].d["final_outcome"] == "PASS" and (h / "Desktop" / "test.txt").exists() and not (h / "Downloads" / "test.txt").exists(), "move verified on disk"


def t_a2():
    with Home() as h:
        (h / "Downloads" / "a.txt").write_text("new")
        (h / "Desktop" / "a.txt").write_text("OLD")
        r = RP.run("a.txt ko Desktop par move karo", _good_env(), save=False)
        return r["trace"], r["status"] == "needs_confirmation" and (h / "Desktop" / "a.txt").read_text() == "OLD", "no overwrite without confirmation"


def t_a3():
    with Home() as h:
        www = Path(tempfile.mkdtemp())
        (www / "doc.pdf").write_bytes(b"%PDF" + os.urandom(100000))
        srv = _serve(www)
        os.environ["GOKU_ALLOW_LOCAL_DOWNLOAD"] = "1"
        try:
            url = f"http://127.0.0.1:{srv.server_address[1]}/doc.pdf"
            r = RP.run(f"Internet se {url} download karo aur usay Desktop ke GOKU_Test folder mein move kar do", _good_env(), save=False)
            ok = r["trace"].d["final_outcome"] == "PASS" and (h / "Desktop" / "GOKU_Test" / "doc.pdf").exists()
            return r["trace"], ok, "download then move, size and location verified"
        finally:
            os.environ.pop("GOKU_ALLOW_LOCAL_DOWNLOAD", None)
            srv.shutdown()


def t_a4():
    with Home():
        r = RP.run("nofile.txt ko Desktop par move karo", _good_env(), save=False)
        return r["trace"], r["status"] == "missing" and r["trace"].d["final_outcome"] == "BLOCKED", "missing file reported, not invented"


def t_b1():
    p = RP.plan("Chrome kholo aur Google par search karo latest Python version", _good_env())
    return p["trace"], p["route"] == "browser_search", "route chosen with reason; live search itself needs the laptop"


def t_b2():
    p = RP.plan("Chrome kholo aur Google par search karo latest Python version", _good_env(internet=False))
    return p["trace"], p["status"] == "blocked" and p["resume_when"] == {"internet": True}, "internet down -> blocked, resumes when online"


def t_e1():
    r = TR.translate("mujhe pani chahiye", "english")
    t = Trace("translate mujhe pani chahiye")
    t.set(intent="translate", selected_route="phrasebook", route_reason="exact phrase known offline")
    t.verify("original preserved", r["original"] == "mujhe pani chahiye", r["original"])
    t.verify("translation is the known phrase", r["translation"] == "I need water", r["translation"])
    t.finish("PASS")
    return t, t.d["final_outcome"] == "PASS", "phrasebook translation"


def t_e2():
    r = TR.translate("Ahmed ko 5000 rupees chahiye aur woh kal aayega", "english")
    t = Trace("translate unknown sentence without LLM")
    t.set(intent="translate", selected_route="none", route_reason="no phrasebook entry and no LLM")
    t.verify("refuses instead of guessing", r["status"] == "unsupported", r["status"])
    t.finish("PASS")
    return t, r["status"] == "unsupported", "honest refusal"


def t_i1():
    p = RP.plan("Chrome kholo aur Google par search karo latest Python version", _good_env(ram_free_mb=200))
    return p["trace"], p["status"] == "pending" and p["resume_when"].get("ram_free_mb", 0) >= 500, "RAM gate: pending until capable"


def t_i2():
    with tempfile.TemporaryDirectory() as d:
        q = RP.PendingTasks(Path(d) / "p.json")
        p = RP.plan_or_queue("Chrome kholo aur Google par search karo latest Python version", _good_env(ram_free_mb=200), q)
        now = len(q.capable_now(_good_env(ram_free_mb=200)))
        later = len(q.capable_now(_good_env(ram_free_mb=1500)))
        t = p["trace"]
        t.verify("not runnable at 200 MB", now == 0, str(now))
        t.verify("runnable at 1500 MB", later == 1, str(later))
        return t, now == 0 and later == 1, "pending list resumes only when capable"


def t_k1():
    out = []
    for text in ("Mere laptop par 3D game render karo", "Mere behalf par payment kar do", "Meri screen ko 24 ghante continuously watch karo"):
        p = RP.plan(text, _good_env())
        out.append(p["status"] == "unsupported" and all(f"{n}. " in p["message"] for n in range(1, 8)))
    return p["trace"], all(out), "unsupported tasks get the 7-point explanation"


def t_l1():
    t = Trace("self-learning must not edit source")
    import subprocess
    r = subprocess.run([sys.executable, "-c", "import brain.lesson_store as m, inspect; s=inspect.getsource(m); print(any(x in s for x in ('write_text(','open(')) and 'py' in s)"], capture_output=True, text=True, cwd=ROOT)
    t.set(intent="check", selected_route="static", route_reason="lesson store only writes its own json")
    src = (ROOT / "brain" / "lesson_store.py").read_text(encoding="utf-8")
    ok = ".py" not in src.replace("lesson_store.py", "")
    t.verify("lesson_store never targets .py files", ok, "static scan")
    t.finish("PASS" if ok else "FAIL")
    return t, ok, "static check"


def _trace_from(name, intent, route, reason, checks):
    t = Trace(name)
    t.set(intent=intent, selected_route=route, route_reason=reason)
    for n, ok, ev in checks:
        t.verify(n, bool(ok), str(ev)[:200])
    t.finish("PASS" if all(c[1] for c in checks) else "FAIL")
    return t, all(c[1] for c in checks)


def t_s1():
    from brain import capability_status as C
    qs = [("Kya tum 10 GB ki file download kar sakte ho jab sirf 500 MB free space ho?", "LOW_DISK"), ("Kya tum kisi phone number par actual call kar sakte ho?", "MISSING_TOOL"),
          ("Kya tum background mein laptop band hone ke baad bhi kaam kar sakte ho?", "MACHINE_MUST_BE_ON")]
    checks = [(q[:40], (C.assess(q) or {}).get("reason") == r, (C.assess(q) or {}).get("status")) for q, r in qs]
    t, ok = _trace_from("capability decisions", "capability", "rules", "status + reason code per question", checks)
    return t, ok, "status/reason codes"


def t_s2():
    from brain import msg_split as M
    text = " ".join(f"Sentence {i} is here with emoji \U0001F600 and words." for i in range(400))
    r = M.split_text(text, 1000)
    t, ok = _trace_from("split 20k text", "split", "msg_split", "sentence boundaries", [("reconstruction", r["reconstruction_ok"], r["count"]), ("no missing sentences", not r["missing_sentences"], 0),
                                                                                    ("all parts <= 1000", not r["over_limit_parts"], max(r["part_chars"])), ("platform limit not guessed", r["platform_limit"] == "NOT VERIFIED", r["platform_limit"])])
    return t, ok, "split + proof"


def t_s3():
    from brain import watch_verify as W
    L = W.PlaybackLog()
    for x in range(0, 61):
        L.add(x, x, "playing")
    P = {"video_id": "a", "title": "T", "channel": "C"}
    v = W.verify_playback(L, P, dict(P), subscribe_before=False, subscribe_after=True, bell_before="off", bell_after="off", screenshot_ts=61)
    t, ok = _trace_from("playback verify", "watch", "watch_verify", "position-based", [("verdict PASS on synthetic log", v["verdict"] == "PASS", v["calculations"])])
    return t, ok, "synthetic playback log (the real YouTube run needs the laptop)"


def t_s4():
    from brain import translate as T
    r = T.translate_instruction("file delete mat karna, sirf copy karna, original folder preserve karna")
    t, ok = _trace_from("translate restrictions", "translate", "rules", "clause rules", [("negation kept", r["restrictions"]["checks"]["negations_kept"], r["translation"]), ("no verb swap", r["restrictions"]["checks"]["no_verb_swap"], "")])
    return t, ok, "restrictions preserved"


TESTS = [
    ("A", "A1 move file", t_a1), ("A", "A2 no overwrite", t_a2), ("A", "A3 download then move", t_a3), ("A", "A4 missing file", t_a4),
    ("B", "B1 search route", t_b1), ("B", "B2 internet down", t_b2),
    ("E", "E1 translate known", t_e1), ("E", "E2 translate unknown refuses", t_e2),
    ("I", "I1 RAM gate", t_i1), ("I", "I2 pending resumes", t_i2),
    ("K", "K1 unsupported 7 points", t_k1),
    ("L", "L1 lessons never edit source", t_l1),
    ("S", "S1 capability status codes", t_s1), ("S", "S2 20k text split proof", t_s2), ("S", "S3 playback verification logic", t_s3), ("S", "S4 translate keeps restrictions", t_s4),
]

LIVE = [
    ("B", "B3 real Chrome search and reading the result page"), ("C", "C1 screen watch: popup appears within 10 s on a real screen"),
    ("C", "C2 scroll-search a real web page for a heading"), ("D", "D1 draft a message in a real chat window, wait for approval, send"),
    ("F", "F1 answer 20 ChatGPT-set questions with the real LLM"), ("G", "G1 1,200-word blog -> SEO -> WordPress draft (needs WP URL + app password)"),
    ("H", "H1 memory across restart"), ("J", "J1 open/close Notepad and verify the window"), ("J", "J2 popup handling with UIA"),
    ("S", "S5 WhatsApp real send with approval"), ("S", "S6 X follow/DM/post on a real account"), ("S", "S7 daily streak on a real site"), ("S", "S8 schedule survives laptop restart/sleep"),
]


def main(argv=None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--only", default="")
    ap.add_argument("--out", default=str(ROOT / "logs" / "department_report.md"))
    a = ap.parse_args(argv)
    only = {x.strip().upper() for x in a.only.split(",") if x.strip()}
    rows, reports = [], []
    for dept, name, fn in TESTS:
        if only and dept not in only:
            continue
        try:
            tr, ok, note = fn()
            res = "PASS" if ok else "FAIL"
            reports.append(tr.render(name.split()[0]))
        except Exception as e:
            res, note = "ERROR", repr(e)
        rows.append((dept, name, res, note))
    for dept, name in LIVE:
        if only and dept not in only:
            continue
        rows.append((dept, name, LAPTOP, "needs the real Windows desktop / browser / LLM / internet - run on the laptop"))
    ran = [r for r in rows if r[2] in ("PASS", "FAIL", "ERROR")]
    head = ["# GOKU department test report", "", "| Dept | Test | Result | Note |", "|---|---|---|---|"] + [f"| {d} | {n} | {r} | {x} |" for d, n, r, x in rows]
    summary = ["", f"Executed here: {len(ran)}; passed: {sum(r[2] == 'PASS' for r in ran)}; needs laptop: {sum(r[2] == LAPTOP for r in rows)}.", "NEEDS_LAPTOP tests are NOT counted as passed."]
    lines = head + summary + ["", "## Individual Test Reports", ""] + sum([["```", rep, "```", ""] for rep in reports], [])
    out = Path(a.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text("\n".join(lines), encoding="utf-8")
    print("\n".join(head + summary))
    print(f"\nFull report: {out}")
    return 0 if all(r[2] == "PASS" for r in ran) else 1


if __name__ == "__main__":
    raise SystemExit(main())
