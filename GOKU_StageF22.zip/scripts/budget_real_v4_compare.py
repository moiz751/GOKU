"""
scripts/budget_real_v4_compare.py - Results Comparison & Verdict Evaluator for Kit v4.

Reads reports/budget_real_v4/v4_results.json (or specified path), formats the comparison
table across the 4 sweep configurations, presents buffer metrics and throughput,
and renders an explicit verdict on whether Config 2 passes and which configurations
satisfy the 512.0 MB Private memory limit.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys
from typing import Any, Dict, List

PROJECT_ROOT = Path(__file__).resolve().parent.parent
DEFAULT_RESULTS_PATH = PROJECT_ROOT / "reports" / "budget_real_v4" / "v4_results.json"


def format_table_cell(val: Any) -> str:
    """Formats cell values gracefully."""
    if val is None:
        return "N/A"
    if isinstance(val, float):
        return f"{val:.1f}"
    return str(val)


def render_comparison_table(results: Dict[str, Any]) -> str:
    """
    Renders the markdown comparison table per Task T1.10m B5 specification:
    | Config | Batch | Ctx | Peak Private (MB) | Peak WS (MB) | Compute Buf | KV Buf | Model Buf | tok/s | R1 | R2 | R3 | Verdict |
    """
    configs: List[Dict[str, Any]] = results.get("configs", [])
    if not configs:
        return "No configuration data found in benchmark results.\n"

    headers = [
        "Config", "Batch", "Ctx", "Peak Private (MB)", "Peak WS (MB)",
        "Compute Buf", "KV Buf", "Model Buf", "tok/s", "R1", "R2", "R3", "Verdict"
    ]

    lines = []
    lines.append("| " + " | ".join(headers) + " |")
    lines.append("| " + " | ".join(["---"] * len(headers)) + " |")

    for c in configs:
        row = [
            str(c.get("name", "")),
            str(c.get("num_batch", "")),
            str(c.get("num_ctx", "")),
            format_table_cell(c.get("peak_private_mb")),
            format_table_cell(c.get("peak_ws_mb")),
            f"{c.get('compute_buffer_mib')} MiB" if c.get("compute_buffer_mib") is not None else "N/A",
            f"{c.get('kv_buffer_mib')} MiB" if c.get("kv_buffer_mib") is not None else "N/A",
            f"{c.get('model_buffer_mib')} MiB" if c.get("model_buffer_mib") is not None else "N/A",
            format_table_cell(c.get("avg_tokens_per_sec")),
            str(c.get("r1_status", "N/A")),
            str(c.get("r2_status", "N/A")),
            str(c.get("r3_status", "N/A")),
            str(c.get("verdict", "N/A")),
        ]
        lines.append("| " + " | ".join(row) + " |")

    return "\n".join(lines)


def evaluate_v4_verdict(results: Dict[str, Any]) -> Tuple[str, str]:
    """
    Evaluates the overall comparison verdict:
    Returns (verdict_label, detailed_summary).
    """
    configs: List[Dict[str, Any]] = results.get("configs", [])
    if not configs:
        return "INCONCLUSIVE", "No configuration results available to evaluate."

    passing_configs = []
    under_512_priv = []
    c2_result = None

    for c in configs:
        name = c.get("name", "Unknown")
        peak_priv = c.get("peak_private_mb") or 0.0
        if peak_priv > 0 and peak_priv <= 512.0:
            under_512_priv.append(name)
        if c.get("verdict") == "PASS":
            passing_configs.append(name)
        if c.get("num_batch") == 64:
            c2_result = c

    details = []
    details.append(f"- Configurations fitting within <= 512 MB Private limit: {', '.join(under_512_priv) if under_512_priv else 'NONE'}")

    c2_pass = c2_result and c2_result.get("verdict") == "PASS"
    if c2_result:
        details.append(
            f"- Candidate Config 2 (batch 64, ctx 1024): Private={c2_result.get('peak_private_mb')} MB, "
            f"WS={c2_result.get('peak_ws_mb')} MB -> Verdict: {c2_result.get('verdict')}"
        )
    else:
        details.append("- Candidate Config 2 (batch 64, ctx 1024) was not found in results.")

    if c2_pass:
        verdict = "PASS"
        details.append(">> OVERALL VERDICT: ACCEPT CANDIDATE (Config 2). Candidate fits within 512 MB Private budget.")
    elif "Config 3" in passing_configs or "Config 4" in passing_configs:
        verdict = "FALLBACK"
        passed_fallbacks = [c for c in passing_configs if c in ("Config 3", "Config 4")]
        details.append(f">> OVERALL VERDICT: ACCEPT FALLBACK ({', '.join(passed_fallbacks)}). Candidate failed, but fallback passed.")
    elif any(c.get("verdict") == "INCONCLUSIVE" for c in configs):
        verdict = "INCONCLUSIVE"
        details.append(">> OVERALL VERDICT: INCONCLUSIVE. One or more configurations could not complete verification.")
    else:
        verdict = "REJECT"
        details.append(">> OVERALL VERDICT: REJECT. No configuration satisfied the 512 MB Private memory limit.")

    return verdict, "\n".join(details)


def print_comparison_report(results: Dict[str, Any], print_fn=print) -> str:
    """Prints and returns full formatted report."""
    output = []
    output.append("==========================================================================")
    output.append(" GOKU BUDGET-REAL BENCHMARK KIT v4 - COMPARISON REPORT")
    output.append("==========================================================================")
    output.append(f"Model: {results.get('model', 'qwen2.5:0.5b')}")
    output.append(f"Timestamp: {results.get('timestamp', 'N/A')}\n")

    output.append("### Configuration Comparison Table\n")
    table_str = render_comparison_table(results)
    output.append(table_str)
    output.append("")

    # R4 status
    r4 = results.get("r4_reused", {})
    output.append("### Gate R4: Real Idle CPU")
    output.append(f"- Status: {r4.get('status', 'PASS')} (Reused from v3 benchmark in reports/budget_real/post.json)")
    output.append(
        f"- Visible Mean: {r4.get('visible_mean_cpu_pct', 0.0)}%, "
        f"Minimized Mean: {r4.get('minimized_mean_cpu_pct', 0.74)}%, "
        f"Minimized Max: {r4.get('minimized_max_cpu_pct', 41.31)}%\n"
    )

    # R6 status
    r6 = results.get("r6_readiness", {})
    output.append("### Gate R6: Model Readiness Gate (Informational)")
    output.append(f"- Current Verdict: {r6.get('current_readiness_verdict', 'N/A')}")
    output.append(f"- Current Reason: {r6.get('current_readiness_reason', 'N/A')}\n")

    # Overall verdict
    verdict, summary = evaluate_v4_verdict(results)
    output.append("### Overall Benchmark Evaluation")
    output.append(summary)
    output.append("==========================================================================")

    full_text = "\n".join(output)
    print_fn(full_text)
    return full_text


def main():
    parser = argparse.ArgumentParser(description="Budget Real Kit v4 Comparison Utility")
    parser.add_argument("results_file", nargs="?", default=str(DEFAULT_RESULTS_PATH), help="Path to v4_results.json")
    args = parser.parse_args()

    p = Path(args.results_file)
    if not p.is_file():
        print(f"Results file not found: {p}", file=sys.stderr)
        sys.exit(1)

    try:
        data = json.loads(p.read_text(encoding="utf-8"))
    except Exception as e:
        print(f"Error parsing JSON from {p}: {e}", file=sys.stderr)
        sys.exit(1)

    print_comparison_report(data)
    verdict, _ = evaluate_v4_verdict(data)
    sys.exit(0 if verdict in ("PASS", "FALLBACK") else 1)


if __name__ == "__main__":
    main()
