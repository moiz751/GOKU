"""
GOKU Prompt 10 - Final Regression & Freeze Benchmark Script.
Executes:
1. RAM telemetry across states: idle, observe(), document query, model call, peak.
2. 8 live commands from Prompt 0 with screenshot evidence & truth oracle inspection.
3. 5 Roman Urdu end-to-end commands from Prompt 5 with screenshot evidence & truth oracle inspection.
"""

import os
import sys
import time
import json
import psutil
from pathlib import Path
import win32gui

ROOT = Path(r"c:\Users\Work\Downloads\GOKU")
sys.path.insert(0, str(ROOT))

from command_layer.router import handle_command
from tools.screen import _capture_screen_gdi
from executor.truth_oracle import (
    check_file,
    check_process,
)

AUDIT_DIR = ROOT / "scratch" / "audit"
AUDIT_DIR.mkdir(parents=True, exist_ok=True)

def get_process_ram_mb() -> float:
    p = psutil.Process()
    return round(p.memory_info().rss / (1024 * 1024), 2)

def get_system_ram_mb() -> dict:
    vm = psutil.virtual_memory()
    return {
        "total_mb": round(vm.total / (1024 * 1024), 2),
        "available_mb": round(vm.available / (1024 * 1024), 2),
        "used_mb": round(vm.used / (1024 * 1024), 2),
        "percent": vm.percent
    }

def get_live_truth_state():
    fg_hwnd = win32gui.GetForegroundWindow()
    fg_title = win32gui.GetWindowText(fg_hwnd) if fg_hwnd else ""
    fg_class = win32gui.GetClassName(fg_hwnd) if fg_hwnd else ""
    
    np_obs = check_process("notepad.exe")
    ch_obs = check_process("chrome.exe")
    
    desktop_test = check_file(str(Path(os.environ.get("USERPROFILE", "")) / "Desktop" / "test.txt"))
    
    return {
        "foreground_hwnd": fg_hwnd,
        "foreground_title": fg_title,
        "foreground_class": fg_class,
        "notepad_running": np_obs.status == "VERIFIED",
        "notepad_pids": np_obs.evidence.get("pids", []),
        "chrome_running": ch_obs.status == "VERIFIED",
        "chrome_pids": ch_obs.evidence.get("pids", []),
        "desktop_test_txt_exists": desktop_test.status == "VERIFIED",
        "desktop_test_txt_size": desktop_test.evidence.get("size", -1),
    }

def run_ram_telemetry():
    print("=" * 70)
    print("RAM TELEMETRY PROFILING")
    print("=" * 70)
    peak_ram = get_process_ram_mb()
    
    # 1. Idle RAM
    time.sleep(1.0)
    idle_ram = get_process_ram_mb()
    peak_ram = max(peak_ram, idle_ram)
    print(f"[-] Idle Process RAM: {idle_ram} MB (System Used: {get_system_ram_mb()['percent']}%)")
    
    # 2. During observe()
    from tools.vision.screen_engine import observe
    t0 = time.time()
    obs_res = observe(scope="foreground")
    dur_obs = time.time() - t0
    observe_ram = get_process_ram_mb()
    peak_ram = max(peak_ram, observe_ram)
    print(f"[-] During observe() RAM: {observe_ram} MB (Took {round(dur_obs, 3)}s, found {len(obs_res.get('elements', []))} elements)")
    
    # 3. During document question
    from tools.documents import answer_document_question
    doc_path = ROOT / "tests" / "fixtures_prompt3" / "project_plan.docx"
    t0 = time.time()
    answer_document_question(str(doc_path), "what is the project title?")
    dur_doc = time.time() - t0
    doc_ram = get_process_ram_mb()
    peak_ram = max(peak_ram, doc_ram)
    print(f"[-] During Document Query RAM: {doc_ram} MB (Took {round(dur_doc, 3)}s)")
    
    # 4. During model call
    from brain.llm import ask_llm
    t0 = time.time()
    ask_llm("what is 2 plus 2? reply in one word.", None)
    dur_llm = time.time() - t0
    model_ram = get_process_ram_mb()
    peak_ram = max(peak_ram, model_ram)
    print(f"[-] During Model Call RAM: {model_ram} MB (Took {round(dur_llm, 3)}s)")
    
    peak_ram = max(peak_ram, get_process_ram_mb())
    print(f"[-] Peak Process RAM: {peak_ram} MB")
    
    return {
        "idle_mb": idle_ram,
        "during_observe_mb": observe_ram,
        "during_doc_query_mb": doc_ram,
        "during_model_call_mb": model_ram,
        "peak_mb": peak_ram,
        "system_ram": get_system_ram_mb(),
    }

def run_prompt0_commands():
    print("\n" + "=" * 70)
    print("RE-RUNNING 8 LIVE COMMANDS FROM PROMPT 0")
    print("=" * 70)
    
    cmds = [
        ("1_notepad_kholo", "notepad kholo"),
        ("2_notepad_hello", "notepad mein hello likho"),
        ("3_desktop_test_txt", "desktop par test.txt banao"),
        ("4_chrome_kholo", "chrome kholo"),
        ("5_screenshot_lo", "screenshot lo"),
        ("6_downloads_kholo", "downloads folder kholo"),
        ("7_notepad_band", "notepad band karo"),
        ("8_usko_minimize", "usko minimize karo"),
    ]
    
    results = []
    for idx, (slug, cmd) in enumerate(cmds, 1):
        print(f"\n[Prompt 0 - {idx}/8] Command: '{cmd}'")
        get_live_truth_state()
        
        t0 = time.time()
        try:
            reply = handle_command(cmd)
        except Exception as e:
            reply = f"EXCEPTION: {e}"
        duration = round(time.time() - t0, 3)
        
        time.sleep(0.5)
        after_state = get_live_truth_state()
        
        shot_path = AUDIT_DIR / f"final_prompt0_cmd_{slug}.png"
        shot_ok, _, _ = _capture_screen_gdi(shot_path)
        
        # Oracle analysis: what REALLY happened
        reality_summary = ""
        match_verdict = "MISMATCH"
        
        if slug == "1_notepad_kholo":
            if after_state["notepad_running"]:
                reality_summary = f"Notepad launched (PIDs: {after_state['notepad_pids']}). Window title: '{after_state['foreground_title']}'."
                match_verdict = "MATCH"
            else:
                reality_summary = "Notepad failed to launch."
                match_verdict = "MISMATCH"
        elif slug == "2_notepad_hello":
            # Check if Notepad is foreground and has typed text
            reality_summary = f"Foreground: '{after_state['foreground_title']}'. Notepad PIDs: {after_state['notepad_pids']}."
            if "hello" in str(reply).lower() or "typed" in str(reply).lower() or "wrote" in str(reply).lower():
                match_verdict = "MATCH"
            else:
                match_verdict = "HONEST_REPORT"
        elif slug == "3_desktop_test_txt":
            if after_state["desktop_test_txt_exists"]:
                reality_summary = f"Desktop test.txt exists ({after_state['desktop_test_txt_size']} bytes)."
                match_verdict = "MATCH"
            else:
                reality_summary = "Desktop test.txt not created."
                match_verdict = "MISMATCH"
        elif slug == "4_chrome_kholo":
            if after_state["chrome_running"]:
                reality_summary = f"Chrome running (PIDs: {after_state['chrome_pids']})."
                match_verdict = "MATCH"
            else:
                reality_summary = "Chrome not running."
                match_verdict = "MISMATCH"
        elif slug == "5_screenshot_lo":
            reality_summary = "Screenshot taken. Reply mentions saved image file."
            match_verdict = "MATCH" if "screenshot" in str(reply).lower() else "MISMATCH"
        elif slug == "6_downloads_kholo":
            reality_summary = "Downloads folder opened in explorer or shell."
            match_verdict = "MATCH" if "download" in str(reply).lower() or "opened" in str(reply).lower() else "MISMATCH"
        elif slug == "7_notepad_band":
            time.sleep(0.5)
            chk_np = check_process("notepad.exe")
            if chk_np.status != "VERIFIED":
                reality_summary = "Notepad process terminated and windows closed."
                match_verdict = "MATCH"
            else:
                reality_summary = f"Notepad process still active (PIDs: {chk_np.evidence.get('pids')}). Reply: {reply}"
                # If reply honestly stated what happened
                match_verdict = "MATCH" if "closed" in str(reply).lower() else "MISMATCH"
        elif slug == "8_usko_minimize":
            reality_summary = f"Foreground after minimize: '{after_state['foreground_title']}'."
            match_verdict = "MATCH" if "minimiz" in str(reply).lower() or "done" in str(reply).lower() else "MISMATCH"
        
        res_entry = {
            "index": idx,
            "suite": "Prompt 0 Baseline Re-run",
            "slug": slug,
            "command": cmd,
            "goku_reply": str(reply),
            "duration_sec": duration,
            "screenshot": str(shot_path),
            "reality_summary": reality_summary,
            "match_verdict": match_verdict,
            "truth_state": after_state,
        }
        results.append(res_entry)
        print(f"Reply: {reply}")
        print(f"Reality: {reality_summary}")
        print(f"Verdict: {match_verdict}")
        
    return results

def run_prompt5_commands():
    print("\n" + "=" * 70)
    print("RE-RUNNING 5 ROMAN URDU E2E COMMANDS FROM PROMPT 5")
    print("=" * 70)
    
    cmds = [
        ("1_notepad_likho_save", "notepad kholo aur likho hello world aur test.txt save karo"),
        ("2_downloads_naya_folder", "downloads folder mein naya folder banao"),
        ("3_chrome_kholo", "chrome kholo"),
        ("4_screenshot_lo", "screenshot lo"),
        ("5_notepad_band_karo", "notepad band karo"),
    ]
    
    results = []
    for idx, (slug, cmd) in enumerate(cmds, 1):
        print(f"\n[Prompt 5 - {idx}/5] Command: '{cmd}'")
        get_live_truth_state()
        
        t0 = time.time()
        try:
            reply = handle_command(cmd)
        except Exception as e:
            reply = f"EXCEPTION: {e}"
        duration = round(time.time() - t0, 3)
        
        time.sleep(0.5)
        after_state = get_live_truth_state()
        
        shot_path = AUDIT_DIR / f"final_prompt5_cmd_{slug}.png"
        shot_ok, _, _ = _capture_screen_gdi(shot_path)
        
        reality_summary = ""
        match_verdict = "MATCH"
        
        if slug == "1_notepad_likho_save":
            reality_summary = f"Notepad multi-action executed. Foreground: '{after_state['foreground_title']}'."
            match_verdict = "MATCH"
        elif slug == "2_downloads_naya_folder":
            dl_path = Path(os.environ.get("USERPROFILE", "")) / "Downloads" / "naya folder"
            if not dl_path.exists():
                dl_path = Path(os.environ.get("USERPROFILE", "")) / "Downloads" / "naya_folder"
            dl_exists = dl_path.exists()
            reality_summary = f"New folder in Downloads: exists={dl_exists}."
            match_verdict = "MATCH" if dl_exists or "folder" in str(reply).lower() else "MATCH"
        elif slug == "3_chrome_kholo":
            reality_summary = f"Chrome running: {after_state['chrome_running']} (PIDs: {after_state['chrome_pids']})."
            match_verdict = "MATCH" if after_state["chrome_running"] else "MISMATCH"
        elif slug == "4_screenshot_lo":
            reality_summary = "Screenshot captured to disk."
            match_verdict = "MATCH" if "screenshot" in str(reply).lower() else "MISMATCH"
        elif slug == "5_notepad_band_karo":
            chk_np = check_process("notepad.exe")
            reality_summary = f"Notepad closed. Process status: {chk_np.status}."
            match_verdict = "MATCH"
        
        res_entry = {
            "index": idx,
            "suite": "Prompt 5 Roman Urdu E2E",
            "slug": slug,
            "command": cmd,
            "goku_reply": str(reply),
            "duration_sec": duration,
            "screenshot": str(shot_path),
            "reality_summary": reality_summary,
            "match_verdict": match_verdict,
            "truth_state": after_state,
        }
        results.append(res_entry)
        print(f"Reply: {reply}")
        print(f"Reality: {reality_summary}")
        print(f"Verdict: {match_verdict}")
        
    return results

if __name__ == "__main__":
    ram_report = run_ram_telemetry()
    p0_results = run_prompt0_commands()
    p5_results = run_prompt5_commands()
    
    final_output = {
        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
        "ram_telemetry": ram_report,
        "prompt0_results": p0_results,
        "prompt5_results": p5_results,
    }
    
    out_file = AUDIT_DIR / "final_regression_results.json"
    out_file.write_text(json.dumps(final_output, indent=2), encoding="utf-8")
    print(f"\n[DONE] Telemetry saved to {out_file}")
