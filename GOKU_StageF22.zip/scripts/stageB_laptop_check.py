"""
Stage B laptop check (READ-ONLY: it does not click, type or move anything). Run once from the project folder:

    python scripts/stageB_laptop_check.py

Writes reports/stageB/laptop_report.json. Send that file back.
Keep a Notepad window in front while it runs; at the countdown, move the mouse a little (the check looks for it).
"""
from __future__ import annotations

import json
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
results = []


def rec(name, status, detail=None):
    results.append({"check": name, "status": status, "detail": detail})
    print(f"[{status:4}] {name}: {str(detail)[:230] if detail is not None else ''}")


def timed(fn, *a):
    t = time.time()
    try:
        return fn(*a), round((time.time() - t) * 1000), None
    except Exception as exc:
        return None, round((time.time() - t) * 1000), f"{type(exc).__name__}: {exc}"


if sys.platform != "win32":
    rec("platform", "SKIP", "this check only means something on Windows")
else:
    import psutil
    from tools.vision import screen_providers as sp
    from tools.vision.screen_fusion import ScreenUnderstanding

    proc = psutil.Process()
    rss0 = proc.memory_info().rss / 2**20
    for name, fn in (("window_meta", sp.window_meta), ("monitors", sp.monitors), ("cursor", sp.cursor), ("uia", sp.uia), ("capture", sp.capture), ("ocr", sp.ocr)):
        val, ms, err = timed(fn)
        ok = err is None and bool(val)
        extra = len(val) if hasattr(val, "__len__") and not isinstance(val, dict) else (val.size if hasattr(val, "size") else val)
        rec(f"provider {name}", "PASS" if ok else ("FAIL" if err else "WARN"), {"ms": ms, "result": str(extra)[:120], "error": err})
    mons = sp.monitors()
    rec("multi-monitor", "PASS" if mons else "WARN", {"count": len(mons), "monitors": mons})
    su = ScreenUnderstanding(sp.default_providers())
    s1, ms, err = timed(su.observe, "overview")
    rec("observe overview", "PASS" if s1 and s1["verdict"] == "OK" else "WARN", {"ms": ms, "verdict": s1 and s1["verdict"], "confidence": s1 and s1["confidence"],
                                                                         "title": s1 and (s1["window"] or {}).get("title"), "elements": s1 and len(s1["elements"]), "conflicts": s1 and s1["conflicts"], "error": err})
    print("Move the mouse a little during the next 3 seconds ...")
    su.user.expect(cursor=sp.cursor(), hwnd=(s1 or {}).get("window", {}).get("hwnd"))
    time.sleep(3)
    s2, ms, err = timed(su.observe, "detect_change")
    s3, ms3, err3 = timed(su.observe, "detect_change")
    rec("temporal change (no change expected between two immediate frames)", "PASS" if s3 and s3.get("change") and s3["change"]["level"] in ("none", "minor") else "WARN",
        {"level": s3 and s3.get("change") and s3["change"]["level"], "ms": ms3})
    rec("manual user action detected", "PASS" if s2 and s2["user_activity"]["user_activity"] else "INFO", {"detected": s2 and s2["user_activity"], "note": "INFO = you did not move the mouse"})
    rss1 = proc.memory_info().rss / 2**20
    rec("memory", "PASS" if rss1 - rss0 < 150 else "WARN", {"rss_before_mb": round(rss0), "rss_after_mb": round(rss1)})
out = ROOT / "reports" / "stageB"
out.mkdir(parents=True, exist_ok=True)
(out / "laptop_report.json").write_text(json.dumps({"time": time.strftime("%Y-%m-%d %H:%M:%S"), "platform": sys.platform, "results": results}, indent=1, default=str), encoding="utf-8")
print(f"\nReport: {out / 'laptop_report.json'}")
