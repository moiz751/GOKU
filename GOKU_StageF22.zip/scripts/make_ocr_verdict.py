"""
scripts/make_ocr_verdict.py
Stage 1 Task 1.2 Closeout: Script-Generated OCR Verdict Document.

Reads benchmark result JSONs, kit hash manifests, and checks engine SHA-256
recorded in result JSONs to generate reports/ocr/STAGE1_T1_2_VERDICT.md.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import sys
from typing import Any

PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from tests.ocr_ab_test import compute_engine_sha256

EXPECTED_ENGINE_SHA_PREFIX = "27872cf52e89"


def get_waivers(ocr_added_delta_str: str, abs_latency_ms: float = 3786.0) -> list[str]:
    """Builds the waiver list with dynamic OCR-added latency delta inserted into W1."""
    return [
        f"W1 Level B fails kit v1 rule R5 (absolute latency {round(abs_latency_ms)} ms) because observe() waits the UIA timeout on a Tk window with no UIA; judged on OCR-added latency ({ocr_added_delta_str}) under kit v2 rules (user-approved, post-hoc).",
        "W2 OCR kit v2 truth includes window title and native label words (user-approved, post-hoc).",
        "W3 real1 REJECT was caused by kit defects (1x1 Chrome region, OCC latency measurement); fixed in real kit v2 without any engine change; real2b ACCEPT; real1 stays on record.",
        "W4 Calculator and Settings (UWP) OCR accuracy not measured (truth too small); only non-blank capture shown.",
        "W5 Known limits: 9 px text recall 65.2%, C7 confusions (0/O, $/S), always-2x without a pixel-budget cap, only a local page tested in Chrome/Edge, RAM delta reads 0.0 MB (coarse).",
    ]


# Legacy constant for backwards-compatibility
WAIVERS = get_waivers("+278.0 ms", 3786.0)


def compute_file_sha256(path: Path) -> str:
    """Computes SHA-256 hex digest of a file."""
    if not path.is_file():
        raise FileNotFoundError(f"File not found for hashing: {path}")
    return hashlib.sha256(path.read_bytes()).hexdigest()


def generate_ocr_verdict_markdown(
    reports_ocr_dir: Path | None = None,
    engine_sha: str | None = None,
    current_engine_sha: str | None = None,
) -> tuple[str, bool]:
    """
    Reads the benchmark JSONs and generates STAGE1_T1_2_VERDICT.md content.
    The engine check compares the engine_sha256 RECORDED inside the result JSONs
    (after_c_A, after2_B, real2b) against EXPECTED_ENGINE_SHA_PREFIX.
    The CURRENT engine SHA is printed as a separate informational line.
    Returns (markdown_text, is_result_engine_sha_valid).
    """
    base_dir = reports_ocr_dir or (PROJECT_ROOT / "reports" / "ocr")

    required_files = {
        "before2_A": base_dir / "before2_A.json",
        "after_c_A": base_dir / "after_c_A.json",
        "before2_B": base_dir / "before2_B.json",
        "after2_B": base_dir / "after2_B.json",
        "real1": base_dir / "real" / "real1.json",
        "real2b": base_dir / "real" / "real2b.json",
        "KIT_HASH": base_dir / "KIT_HASH.json",
        "KIT_HASH_v1": base_dir / "KIT_HASH_v1.json",
        "REAL_KIT_HASH": base_dir / "REAL_KIT_HASH.json",
        "REAL_KIT_HASH_v2": base_dir / "REAL_KIT_HASH_v2.json",
    }

    # Verify all files exist
    for key, path in required_files.items():
        if not path.is_file():
            raise FileNotFoundError(f"Required report file missing: {path}")

    # Load JSON contents
    data_b_a = json.loads(required_files["before2_A"].read_text(encoding="utf-8"))
    data_a_a = json.loads(required_files["after_c_A"].read_text(encoding="utf-8"))
    data_b_b = json.loads(required_files["before2_B"].read_text(encoding="utf-8"))
    data_a_b = json.loads(required_files["after2_B"].read_text(encoding="utf-8"))
    data_real1 = json.loads(required_files["real1"].read_text(encoding="utf-8"))
    data_real2b = json.loads(required_files["real2b"].read_text(encoding="utf-8"))

    # Compute file hashes
    file_hashes = {k: compute_file_sha256(p) for k, p in required_files.items()}

    # Check Engine SHA recorded inside result JSONs
    result_shas = {
        "after_c_A": data_a_a.get("engine_sha256", ""),
        "after2_B": data_a_b.get("engine_sha256", ""),
        "real2b": data_real2b.get("engine_sha256", ""),
    }
    mismatched_result_shas = {
        k: sha for k, sha in result_shas.items()
        if not (sha and sha.lower().startswith(EXPECTED_ENGINE_SHA_PREFIX.lower()))
    }
    result_engine_sha_valid = (len(mismatched_result_shas) == 0)

    if not result_engine_sha_valid:
        print(
            f"LOUD WARNING: Engine SHA mismatch in result JSONs! Expected prefix {EXPECTED_ENGINE_SHA_PREFIX}, got: {mismatched_result_shas}",
            file=sys.stderr,
        )

    # Current Engine SHA (informational line only, does not invalidate verdict)
    active_current_sha = current_engine_sha or engine_sha
    if active_current_sha is None:
        try:
            active_current_sha = compute_engine_sha256()
        except Exception:
            active_current_sha = "unknown"

    current_sha_matches = active_current_sha.lower().startswith(EXPECTED_ENGINE_SHA_PREFIX.lower())
    if current_sha_matches:
        current_sha_display = f"`{active_current_sha}`"
    else:
        current_sha_display = f"`{active_current_sha}` (engine changed after these measurements; later stage results apply)"

    # Compute Level B numbers & W1 latency string
    sb_b = data_b_b.get("summary", {})
    sb_a = data_a_b.get("summary", {})
    b_lat_a = sb_a.get("latency_ms", 3786.0)
    b_add_b = sb_b.get("ocr_added_latency_ms", 0.0)
    b_add_a = sb_a.get("ocr_added_latency_ms", 0.0)
    ocr_added_delta = b_add_a - b_add_b
    ocr_added_delta_str = f"{ocr_added_delta:+.1f} ms"

    active_waivers = get_waivers(ocr_added_delta_str=ocr_added_delta_str, abs_latency_ms=b_lat_a)

    # Build Markdown document
    lines: list[str] = []
    lines.append("# STAGE 1 TASK 1.2: OCR VERDICT & TELEMETRY REPORT")
    lines.append("")
    lines.append("## Executive Verdict")
    lines.append("")
    lines.append("**VERDICT: ACCEPT WITH WAIVERS**")
    lines.append("")

    if not result_engine_sha_valid:
        lines.append("> [!WARNING]")
        lines.append(f"> **LOUD WARNING: Engine SHA prefix mismatch in benchmark result JSONs!**")
        lines.append(f"> Expected prefix: `{EXPECTED_ENGINE_SHA_PREFIX}`")
        lines.append(f"> Mismatched JSONs: `{mismatched_result_shas}`")
        lines.append("")

    lines.append("## Waivers")
    lines.append("")
    for w in active_waivers:
        lines.append(f"- {w}")
    lines.append("")

    # Section 1: Level A
    lines.append("## 1. Level A (Synthetic Static Fixtures)")
    lines.append("")
    lines.append("Measured on synthetic PIL fixtures (C1-C8 text scales, contrast, noise, hallucinations).")
    lines.append("")
    lines.append("| Metric | Before (`before2_A.json`) | After (`after_c_A.json`) | Delta / Evaluation |")
    lines.append("|---|---|---|---|")

    sa_b = data_b_a.get("summary", {})
    sa_a = data_a_a.get("summary", {})

    rec_b = sa_b.get("gating_mean_recall", 0.0) * 100.0
    rec_a = sa_a.get("gating_mean_recall", 0.0) * 100.0
    lines.append(f"| Gating Mean Recall | {rec_b:.1f}% | {rec_a:.1f}% | {rec_a - rec_b:+.1f}% (gate >= 85%) |")

    prec_b = sa_b.get("mean_precision", 0.0) * 100.0
    prec_a = sa_a.get("mean_precision", 0.0) * 100.0
    lines.append(f"| Mean Precision | {prec_b:.1f}% | {prec_a:.1f}% | {prec_a - prec_b:+.1f}% (gate >= 90%) |")

    c8_b = sa_b.get("c8_hallucinations", 0)
    c8_a = sa_a.get("c8_hallucinations", 0)
    lines.append(f"| C8 Hallucinations | {c8_b} | {c8_a} | {c8_a - c8_b:+d} (required 0) |")

    bbox_b = sa_b.get("gating_bbox_hit_rate", 0.0) * 100.0
    bbox_a = sa_a.get("gating_bbox_hit_rate", 0.0) * 100.0
    lines.append(f"| Bounding Box Hit Rate | {bbox_b:.1f}% | {bbox_a:.1f}% | {bbox_a - bbox_b:+.1f}% (gate >= 90%) |")

    lat_b = sa_b.get("median_latency_ms", 0.0)
    lat_a = sa_a.get("median_latency_ms", 0.0)
    lines.append(f"| Median Latency | {lat_b:.1f} ms | {lat_a:.1f} ms | {lat_a - lat_b:+.1f} ms |")

    ram_b = sa_b.get("max_ram_delta_mb", 0.0)
    ram_a = sa_a.get("max_ram_delta_mb", 0.0)
    lines.append(f"| Max RAM Delta | {ram_b:.2f} MB | {ram_a:.2f} MB | {ram_a - ram_b:+.2f} MB |")

    cap_b = sa_b.get("capture_method", "-")
    cap_a = sa_a.get("capture_method", "-")
    lines.append(f"| Capture Method | {cap_b} | {cap_a} | - |")

    ups_b = sa_b.get("ocr_upscale", "-")
    ups_a = sa_a.get("ocr_upscale", "-")
    lines.append(f"| Upscale Mode | {ups_b} | {ups_a} | - |")
    lines.append("")

    # Section 2: Level B
    lines.append("## 2. Level B (Live Window Own-Surface Capture)")
    lines.append("")
    lines.append("Measured on live Tk window with window-own PrintWindow capture and occluder testing.")
    lines.append("")
    lines.append("| Metric | Before (`before2_B.json`) | After (`after2_B.json`) | Delta / Evaluation |")
    lines.append("|---|---|---|---|")

    b_rec_b = sb_b.get("word_recall", 0.0) * 100.0
    b_rec_a = sb_a.get("word_recall", 0.0) * 100.0
    lines.append(f"| Word Recall | {b_rec_b:.1f}% | {b_rec_a:.1f}% | {b_rec_a - b_rec_b:+.1f}% (gate >= 85%) |")

    b_prec_b = sb_b.get("word_precision", 0.0) * 100.0
    b_prec_a = sb_a.get("word_precision", 0.0) * 100.0
    lines.append(f"| Word Precision | {b_prec_b:.1f}% | {b_prec_a:.1f}% | {b_prec_a - b_prec_b:+.1f}% (gate >= 90%) |")

    b_bbox_b = sb_b.get("bbox_hit_rate", 0.0) * 100.0
    b_bbox_a = sb_a.get("bbox_hit_rate", 0.0) * 100.0
    lines.append(f"| Bounding Box Hit Rate | {b_bbox_b:.1f}% | {b_bbox_a:.1f}% | {b_bbox_a - b_bbox_b:+.1f}% (gate >= 90%) |")

    b_lat_b = sb_b.get("latency_ms", 0.0)
    lines.append(f"| Absolute Latency | {b_lat_b:.1f} ms | {b_lat_a:.1f} ms | {b_lat_a - b_lat_b:+.1f} ms (UIA timeout in Tk) |")

    lines.append(f"| OCR Added Latency | {b_add_b:.1f} ms | {b_add_a:.1f} ms | {ocr_added_delta_str} (gate <= 1500 ms) |")

    b_leak_b = sb_b.get("occluder_leaks", 0)
    b_leak_a = sb_a.get("occluder_leaks", 0)
    lines.append(f"| Occluder Leaks | {b_leak_b} | {b_leak_a} | {b_leak_a - b_leak_b:+d} (required 0) |")

    b_uia_b = str(sb_b.get("uia_unchanged", "-"))
    b_uia_a = str(sb_a.get("uia_unchanged", "-"))
    lines.append(f"| UIA Unchanged | {b_uia_b} | {b_uia_a} | - |")

    b_cap_b = sb_b.get("capture_method", "-")
    b_cap_a = sb_a.get("capture_method", "-")
    lines.append(f"| Capture Method | {b_cap_b} | {b_cap_a} | - |")
    lines.append("")

    # Section 3: Real Apps (real1 vs real2b)
    lines.append("## 3. Real Applications Benchmark (`real1` vs `real2b`)")
    lines.append("")
    lines.append("| Case | App | Gating? | real1 (`real1.json`) | real2b (`real2b.json`) | Real Apps Evolution |")
    lines.append("|---|---|---|---|---|---|")

    c1 = data_real1.get("cases", {})
    c2 = data_real2b.get("cases", {})

    all_keys = ["NP", "OCC", "CH", "ED", "CA", "ST"]
    for k in all_keys:
        row1 = c1.get(k, {})
        row2 = c2.get(k, {})
        app = row2.get("app") or row1.get("app", k)
        is_info = row2.get("informational", row1.get("informational", False))
        gating_str = "No (Info)" if is_info else "YES"

        def format_case_summary(c: dict[str, Any]) -> str:
            if not c:
                return "MISSING"
            st = c.get("status", "-")
            lat = c.get("ocr_added_latency_ms", c.get("latency_ms", 0.0))
            if "subcases" in c:
                sub = c["subcases"]
                c_r = sub.get("canvas", {}).get("recall", 0.0) * 100.0
                i_r = sub.get("image", {}).get("recall", 0.0) * 100.0
                p_r = c.get("precision", 0.0) * 100.0
                return f"C:{c_r:.0f}% I:{i_r:.0f}% Prec:{p_r:.0f}% Lat:{lat:.0f}ms ({st})"
            if "occluder_leaks" in c:
                return f"Leaks:{c['occluder_leaks']} Lat:{lat:.0f}ms ({st})"
            if is_info:
                truth = c.get("truth_count", "-")
                rec = c.get("recall", 0.0) * 100.0
                return f"Truth:{truth} Rec:{rec:.0f}% Lat:{lat:.0f}ms ({st})"
            rec = c.get("recall", 0.0) * 100.0
            prec = c.get("precision", 0.0) * 100.0
            return f"Rec:{rec:.0f}% Prec:{prec:.0f}% Lat:{lat:.0f}ms ({st})"

        s1 = format_case_summary(row1)
        s2 = format_case_summary(row2)

        note = "-"
        if k == "CH":
            note = "Fixed K1 region candidate selection (from 1x1 to largest area)"
        elif k == "OCC":
            note = "Fixed K3 added latency formula (isolated OCR overhead)"
        elif k in ("CA", "ST"):
            note = "Filtered on-screen UIA bounds; flagged truth < 5 words"

        lines.append(f"| {k} | {app} | {gating_str} | {s1} | {s2} | {note} |")

    v1_verdict = data_real1.get("verdict", "N/A")
    v2_verdict = data_real2b.get("verdict", "N/A")
    lines.append(f"| **OVERALL** | **Suite Verdict** | - | **{v1_verdict}** | **{v2_verdict}** | **Kit v2 repair verified** |")
    lines.append("")

    # Section 4: Cryptographic Integrity & File Hashes
    lines.append("## 4. Cryptographic Hashes & System Integrity")
    lines.append("")
    lines.append(f"- **Benchmark Result JSONs Engine SHA Status**: `{'VALID' if result_engine_sha_valid else 'MISMATCH WARNING'}`")
    lines.append(f"- **Expected Engine SHA Prefix**: `{EXPECTED_ENGINE_SHA_PREFIX}`")
    lines.append(f"- **Current Engine SHA-256**: {current_sha_display}")
    lines.append("")
    lines.append("| Component / Artifact | Path | SHA-256 Digest |")
    lines.append("|---|---|---|")
    for key, path in required_files.items():
        try:
            rel_path = path.relative_to(PROJECT_ROOT).as_posix()
        except ValueError:
            rel_path = f"reports/ocr/{path.parent.name}/{path.name}" if path.parent.name == "real" else f"reports/ocr/{path.name}"
        lines.append(f"| `{key}` | `{rel_path}` | `{file_hashes[key]}` |")
    lines.append("")

    return "\n".join(lines) + "\n", result_engine_sha_valid


def main():
    parser = argparse.ArgumentParser(description="Generate Stage 1 Task 1.2 OCR Verdict Document")
    parser.add_argument("--reports-dir", help="Path to reports/ocr directory", default=None)
    parser.add_argument("--output", help="Output file path", default=None)
    args = parser.parse_args()

    reports_dir = Path(args.reports_dir) if args.reports_dir else (PROJECT_ROOT / "reports" / "ocr")
    out_file = Path(args.output) if args.output else (reports_dir / "STAGE1_T1_2_VERDICT.md")

    md_content, is_valid = generate_ocr_verdict_markdown(reports_ocr_dir=reports_dir)
    out_file.write_text(md_content, encoding="utf-8")
    print(f"[+] Successfully wrote OCR verdict to {out_file}")

    if not is_valid:
        print("[!] Warning: Result JSON Engine SHA mismatch detected during verdict generation.", file=sys.stderr)


if __name__ == "__main__":
    main()
