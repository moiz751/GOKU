<#
.SYNOPSIS
    hygiene_apply.ps1 - Safe repository hygiene application script for Task S1-08.
.DESCRIPTION
    Moves group (b) clutter/scratch files into _to_delete/ and appends group (a) runtime patterns to .gitignore.
    Strictly adheres to docs/ANTIGRAVITY_RULES.md:
    - Default mode is -WhatIf (simulation only; no changes made unless -Apply is explicitly specified).
    - NEVER touches, moves, or edits any Group (c) engine files (command_layer/*, brain/*, executor/*, tools/*, perception/*, training/*).
    - NEVER deletes files (uses Move-Item to _to_delete/, never Remove-Item).
.PARAMETER Apply
    Switch parameter required to perform actual file relocations and gitignore updates.
    Without -Apply, the script executes in preview / -WhatIf mode.
#>
[CmdletBinding(SupportsShouldProcess = $true)]
param(
    [switch]$Apply
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$RepoRoot = (Get-Item $PSScriptRoot).Parent.FullName
Set-Location $RepoRoot

$IsDryRun = -not $Apply

Write-Host "============================================================" -ForegroundColor Cyan
Write-Host " GOKU REPOSITORY HYGIENE RUNNER (Task S1-08)" -ForegroundColor Cyan
Write-Host " Mode: $(if ($IsDryRun) { '[WHAT-IF PREVIEW - NO CHANGES WILL BE MADE]' } else { '[LIVE APPLY]' })" -ForegroundColor $(if ($IsDryRun) { 'Yellow' } else { 'Green' })
Write-Host " Working Directory: $RepoRoot" -ForegroundColor Gray
Write-Host "============================================================" -ForegroundColor Cyan

# -----------------------------------------------------------------------------
# SAFETY INVARIANT: Engine directories are protected and forbidden from touch
# -----------------------------------------------------------------------------
$ProtectedEnginePrefixes = @(
    "command_layer",
    "brain",
    "executor",
    "tools",
    "perception",
    "training"
)

function Assert-NotEngineFile([string]$RelPath) {
    $norm = $RelPath.Replace('\', '/').TrimStart('/')
    foreach ($prefix in $ProtectedEnginePrefixes) {
        if ($norm.StartsWith($prefix + "/") -or $norm -eq $prefix) {
            throw "CRITICAL SAFETY VIOLATION: Attempted to touch protected engine path: $RelPath"
        }
    }
}

# -----------------------------------------------------------------------------
# 1. GROUP (A): Update .gitignore with runtime artifact patterns
# -----------------------------------------------------------------------------
Write-Host "`n--- Step 1: Group (a) Runtime Artifacts (.gitignore) ---" -ForegroundColor Cyan

$GitIgnorePath = Join-Path $RepoRoot ".gitignore"
$ProposedPatterns = @(
    "# Runtime execution artifacts & traces (Task S1-08)",
    "*.log",
    "*.gz",
    "user-data/",
    "_to_delete/",
    "backups/",
    "acceptance/shots/",
    "acceptance/results.json",
    "reports/full_suite/",
    "reports/evaluation/",
    "reports/run_logs/",
    "reports/llm_calls.jsonl",
    "reports/clarify_metrics.json",
    "reports/mutation_sanity.json",
    "reports/ram_S1_goku_loaded.json"
)

$ExistingGitIgnore = if (Test-Path $GitIgnorePath) { Get-Content $GitIgnorePath } else { @() }
$LinesToAdd = @()

foreach ($pattern in $ProposedPatterns) {
    if (-not ($ExistingGitIgnore -contains $pattern)) {
        $LinesToAdd += $pattern
    }
}

if ($LinesToAdd.Count -eq 0) {
    Write-Host "  .gitignore is already up to date. No new patterns needed." -ForegroundColor Green
} else {
    Write-Host "  Proposed additions to .gitignore ($($LinesToAdd.Count) lines):" -ForegroundColor Yellow
    foreach ($line in $LinesToAdd) {
        Write-Host "    + $line" -ForegroundColor Gray
    }
    if ($IsDryRun) {
        Write-Host "  [WHAT-IF] Would append $($LinesToAdd.Count) lines to $GitIgnorePath" -ForegroundColor Yellow
    } else {
        Add-Content -Path $GitIgnorePath -Value $LinesToAdd -Encoding UTF8
        Write-Host "  [APPLIED] Appended $($LinesToAdd.Count) lines to .gitignore" -ForegroundColor Green
    }
}

# -----------------------------------------------------------------------------
# 2. GROUP (B): Move scratch & clutter items into _to_delete/
# -----------------------------------------------------------------------------
Write-Host "`n--- Step 2: Group (b) Clutter & Scratch Relocation ---" -ForegroundColor Cyan

$ToDeleteDir = Join-Path $RepoRoot "_to_delete"

$Relocations = @(
    # Root Clutter Files
    @{ Source = "agent_state_test.txt"; TargetDir = "_to_delete/root_clutter" },
    @{ Source = "cleanup_test.txt";     TargetDir = "_to_delete/root_clutter" },
    @{ Source = "hello";                TargetDir = "_to_delete/root_clutter" },
    @{ Source = "package_artifact.py";  TargetDir = "_to_delete/root_clutter" },
    @{ Source = "sample_partial.txt";   TargetDir = "_to_delete/root_clutter" },
    @{ Source = "test.txt";             TargetDir = "_to_delete/root_clutter" },
    @{ Source = "test_gate.txt";        TargetDir = "_to_delete/root_clutter" },

    # Untracked generated test suite clutter
    @{ Source = "tests/test_master_evaluation_suite.py"; TargetDir = "_to_delete/tests" },
    @{ Source = "tests/fixtures_eye_batch1.json";        TargetDir = "_to_delete/tests" },

    # Untracked ad-hoc test scripts
    @{ Source = "scripts/thousand_command_benchmark.py"; TargetDir = "_to_delete/scripts" },
    @{ Source = "scripts/measure_main_ram.py";           TargetDir = "_to_delete/scripts" },
    @{ Source = "scripts/master_test_runner.py";         TargetDir = "_to_delete/scripts" },
    @{ Source = "scripts/generate_master_test_dataset.py"; TargetDir = "_to_delete/scripts" },
    @{ Source = "scripts/run_unseen_validation.py";      TargetDir = "_to_delete/scripts" }
)

$MovedCount = 0

foreach ($item in $Relocations) {
    $srcPath = Join-Path $RepoRoot $item.Source
    Assert-NotEngineFile $item.Source
    if (Test-Path $srcPath) {
        $destDir = Join-Path $RepoRoot $item.TargetDir
        $destFile = Join-Path $destDir (Split-Path $srcPath -Leaf)
        if ($IsDryRun) {
            Write-Host "  [WHAT-IF] Move-Item $($item.Source) -> $($item.TargetDir)/" -ForegroundColor Yellow
        } else {
            if (-not (Test-Path $destDir)) {
                New-Item -ItemType Directory -Path $destDir -Force | Out-Null
            }
            Move-Item -Path $srcPath -Destination $destFile -Force
            Write-Host "  [MOVED] $($item.Source) -> $destFile" -ForegroundColor Green
        }
        $MovedCount++
    }
}

# Generated test directory
$GenTestsDir = Join-Path $RepoRoot "tests/generated"
if (Test-Path $GenTestsDir) {
    $targetGenDir = Join-Path $ToDeleteDir "untracked_generated_tests"
    if ($IsDryRun) {
        Write-Host "  [WHAT-IF] Move-Item tests/generated -> _to_delete/untracked_generated_tests/" -ForegroundColor Yellow
    } else {
        if (-not (Test-Path (Split-Path $targetGenDir -Parent))) {
            New-Item -ItemType Directory -Path (Split-Path $targetGenDir -Parent) -Force | Out-Null
        }
        Move-Item -Path $GenTestsDir -Destination $targetGenDir -Force
        Write-Host "  [MOVED] tests/generated -> $targetGenDir" -ForegroundColor Green
    }
    $MovedCount++
}

Write-Host "`n============================================================" -ForegroundColor Cyan
Write-Host " SUMMARY" -ForegroundColor Cyan
Write-Host " Total Group (b) actions identified: $MovedCount" -ForegroundColor Gray
Write-Host " Status: $(if ($IsDryRun) { 'Preview completed. Re-run with -Apply to execute.' } else { 'Hygiene actions successfully applied.' })" -ForegroundColor $(if ($IsDryRun) { 'Yellow' } else { 'Green' })
Write-Host " Engine files touched: 0 (Strictly protected)" -ForegroundColor Green
Write-Host "============================================================" -ForegroundColor Cyan
