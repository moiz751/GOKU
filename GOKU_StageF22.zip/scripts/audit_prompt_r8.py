"""
scripts/audit_prompt_r8.py - Complete Audit and Verification for Prompt R8
Follows GOKU RULES v2 + 16-26.
Runs and aggregates:
1. Startup import profile & top-20 cumulative import times (importtime)
2. Heavy libraries elimination check
3. RAM probe before/after measurements (S1 state)
4. Idle CPU 60s profile and thread justification
5. Log sizes report & rotation policy execution
6. Single-instance lock and leak_check verification
7. Footprint before/after matrix & Rule 25 satisfaction
"""
from __future__ import annotations

import json
import os
from pathlib import Path
import subprocess
import sys
import time

PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))


def run_cmd(cmd: list[str]) -> tuple[int, str]:
    res = subprocess.run(cmd, cwd=str(PROJECT_ROOT), capture_output=True, text=True)
    return res.returncode, res.stdout + ("\n" + res.stderr if res.stderr else "")


def main():
    print("=" * 95)
    print("GOKU PROMPT R8 AUDIT & VERIFICATION REPORT GENERATOR")
    print("=" * 95)
    print(f"Timestamp: {time.strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"GOKU_SANDBOX: {os.environ.get('GOKU_SANDBOX', '0')}")
    print(f"GOKU_MODE   : {os.environ.get('GOKU_MODE', 'dev')}\n")

    # 1. Import Profile
    print("--- 1. Startup Import Profile & Heavy Libraries ---")
    code1, out1 = run_cmd([sys.executable, "scripts/analyze_import_time.py"])
    print(out1.strip())
    print("-" * 95)

    # 2. Footprint Before/After Comparison Table
    print("\n--- 2. Footprint Before/After Comparison Matrix ---")
    code2, out2 = run_cmd([sys.executable, "scripts/compare_footprint_before_after.py"])
    print(out2.strip())
    print("-" * 95)

    # 3. Idle CPU Profile Inspection
    print("\n--- 3. 60-Second Idle CPU Profile & Thread Audit ---")
    cpu_path = Path("reports/idle_cpu_profile.json")
    if cpu_path.exists():
        mtime_cpu = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(cpu_path.stat().st_mtime))
        print(f"Artifact: {cpu_path} (mtime: {mtime_cpu})")
        with open(cpu_path, "r", encoding="utf-8") as f:
            c_data = json.load(f)
        print(f"Duration: {c_data.get('duration_seconds')}s | Mean CPU: {c_data.get('mean_idle_cpu_pct')}% | Max CPU: {c_data.get('max_idle_cpu_pct')}%")
        print(f"Active Threads: {c_data.get('mean_thread_count')} threads")
        for t in c_data.get("active_threads", []):
            print(f"  - {t['thread_id']}: {t['purpose']} ({t['mechanism']}) -> Justification: {t['justification']}")
    print("-" * 95)

    # 4. Log Sizes and Rotation Audit
    print("\n--- 4. Log Sizes and Rotation Audit ---")
    code4, out4 = run_cmd([sys.executable, "scripts/report_and_rotate_logs.py"])
    print(out4.strip())
    print("-" * 95)

    # 5. Full Pytest Suite Execution
    print("\n--- 5. Full Test Suite Execution (tests/test_r8_startup_and_idle.py) ---")
    code5, out5 = run_cmd([sys.executable, "-m", "pytest", "tests/test_r8_startup_and_idle.py", "-v"])
    print(out5.strip())
    print("=" * 95)


if __name__ == "__main__":
    main()
