"""
Evaluation script for Prompt P6 Item 2: Held-out Paraphrases Benchmark.
Measures routing accuracy across 30 new held-out paraphrases per intent:
- 10 English
- 10 Roman Urdu
- 10 Mixed (Code-switched)
Across 7 core intents:
  1. OPEN_APP
  2. CLOSE_APP
  3. CREATE_FOLDER
  4. SEARCH_FILES
  5. SYSTEM_DIAGNOSTICS
  6. WEB_NAVIGATION
  7. SCREENSHOT
Total: 210 held-out paraphrases.
"""
from __future__ import annotations

from pathlib import Path
import sys

# Ensure project root is in sys.path
PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from command_layer.router import route_command

DATASET = {
    "OPEN_APP": {
        "valid_tools": {"launch_app", "focus_app", "execute_system_command"},
        "paraphrases": [
            # English (10)
            {"text": "open the notepad application", "lang": "English"},
            {"text": "launch calculator please", "lang": "English"},
            {"text": "start google chrome right now", "lang": "English"},
            {"text": "bring up task manager", "lang": "English"},
            {"text": "can you open paint", "lang": "English"},
            {"text": "fire up the terminal window", "lang": "English"},
            {"text": "run the vlc player", "lang": "English"},
            {"text": "open edge browser", "lang": "English"},
            {"text": "launch the settings window", "lang": "English"},
            {"text": "start wordpad application", "lang": "English"},
            # Roman Urdu (10)
            {"text": "notepad kholo", "lang": "Roman Urdu"},
            {"text": "calculator chala do", "lang": "Roman Urdu"},
            {"text": "chrome shuru karo", "lang": "Roman Urdu"},
            {"text": "task manager open kar do", "lang": "Roman Urdu"},
            {"text": "paint chalao", "lang": "Roman Urdu"},
            {"text": "terminal khol do bhai", "lang": "Roman Urdu"},
            {"text": "vlc player start karo", "lang": "Roman Urdu"},
            {"text": "edge browser open kar", "lang": "Roman Urdu"},
            {"text": "settings kholo jaldi", "lang": "Roman Urdu"},
            {"text": "wordpad application chalao", "lang": "Roman Urdu"},
            # Mixed (10)
            {"text": "notepad app open karo", "lang": "Mixed"},
            {"text": "calculator launch kar do please", "lang": "Mixed"},
            {"text": "chrome browser start karo abhi", "lang": "Mixed"},
            {"text": "task manager ko open karna", "lang": "Mixed"},
            {"text": "paint application start kar do", "lang": "Mixed"},
            {"text": "terminal window kholo", "lang": "Mixed"},
            {"text": "vlc player ko launch karo", "lang": "Mixed"},
            {"text": "edge browser start kar do", "lang": "Mixed"},
            {"text": "settings app khol do", "lang": "Mixed"},
            {"text": "wordpad program open karo", "lang": "Mixed"},
        ],
    },
    "CLOSE_APP": {
        "valid_tools": {"close_app", "kill_process", "execute_system_command"},
        "paraphrases": [
            # English (10)
            {"text": "close notepad", "lang": "English"},
            {"text": "shut down calculator", "lang": "English"},
            {"text": "exit the chrome browser", "lang": "English"},
            {"text": "terminate paint application", "lang": "English"},
            {"text": "quit vlc player", "lang": "English"},
            {"text": "close task manager window", "lang": "English"},
            {"text": "kill edge browser process", "lang": "English"},
            {"text": "shut the terminal app", "lang": "English"},
            {"text": "exit wordpad right now", "lang": "English"},
            {"text": "close the settings application", "lang": "English"},
            # Roman Urdu (10)
            {"text": "notepad band karo", "lang": "Roman Urdu"},
            {"text": "calculator band kar do", "lang": "Roman Urdu"},
            {"text": "chrome ko khatam karo", "lang": "Roman Urdu"},
            {"text": "paint application band kar", "lang": "Roman Urdu"},
            {"text": "vlc player band kardo", "lang": "Roman Urdu"},
            {"text": "task manager ko band karo", "lang": "Roman Urdu"},
            {"text": "edge browser band karo", "lang": "Roman Urdu"},
            {"text": "terminal app khatam kar do", "lang": "Roman Urdu"},
            {"text": "wordpad band kardo abhi", "lang": "Roman Urdu"},
            {"text": "settings window ko band kar", "lang": "Roman Urdu"},
            # Mixed (10)
            {"text": "notepad app close karo", "lang": "Mixed"},
            {"text": "calculator window close kar do", "lang": "Mixed"},
            {"text": "chrome browser terminate karo", "lang": "Mixed"},
            {"text": "paint program exit kar do", "lang": "Mixed"},
            {"text": "vlc player ko quit karo", "lang": "Mixed"},
            {"text": "task manager window band karo", "lang": "Mixed"},
            {"text": "edge browser kill kar do", "lang": "Mixed"},
            {"text": "terminal process shut down karo", "lang": "Mixed"},
            {"text": "wordpad application close kar do", "lang": "Mixed"},
            {"text": "settings window close kardo", "lang": "Mixed"},
        ],
    },
    "CREATE_FOLDER": {
        "valid_tools": {"create_folder", "create_directory"},
        "paraphrases": [
            # English (10)
            {"text": "create a new folder called budget", "lang": "English"},
            {"text": "make a directory named receipts", "lang": "English"},
            {"text": "create folder projects", "lang": "English"},
            {"text": "make a new directory archives", "lang": "English"},
            {"text": "create folder invoices", "lang": "English"},
            {"text": "generate a folder named clients", "lang": "English"},
            {"text": "build a new directory backup", "lang": "English"},
            {"text": "create folder records", "lang": "English"},
            {"text": "make directory called datasets", "lang": "English"},
            {"text": "create a new folder reports", "lang": "English"},
            # Roman Urdu (10)
            {"text": "budget naam ka naya folder banao", "lang": "Roman Urdu"},
            {"text": "receipts ka folder bana do", "lang": "Roman Urdu"},
            {"text": "projects folder banao", "lang": "Roman Urdu"},
            {"text": "archives naam ki directory banao", "lang": "Roman Urdu"},
            {"text": "invoices ka naya folder bana do", "lang": "Roman Urdu"},
            {"text": "clients naam ka folder create karo", "lang": "Roman Urdu"},
            {"text": "backup directory bana do", "lang": "Roman Urdu"},
            {"text": "records naam ka folder banao", "lang": "Roman Urdu"},
            {"text": "datasets ka folder create kar do", "lang": "Roman Urdu"},
            {"text": "reports ka naya folder banao", "lang": "Roman Urdu"},
            # Mixed (10)
            {"text": "budget ka folder create karo", "lang": "Mixed"},
            {"text": "receipts directory make karo", "lang": "Mixed"},
            {"text": "projects naam ka new folder banao", "lang": "Mixed"},
            {"text": "archives folder create kar do", "lang": "Mixed"},
            {"text": "invoices directory create karo abhi", "lang": "Mixed"},
            {"text": "clients ka new folder bana do", "lang": "Mixed"},
            {"text": "backup folder make karo", "lang": "Mixed"},
            {"text": "records directory bana do jaldi", "lang": "Mixed"},
            {"text": "datasets ka new folder create karo", "lang": "Mixed"},
            {"text": "reports folder create kar do please", "lang": "Mixed"},
        ],
    },
    "SEARCH_FILES": {
        "valid_tools": {"search_files", "find_file"},
        "paraphrases": [
            # English (10)
            {"text": "find file summary.docx in documents", "lang": "English"},
            {"text": "search for notes.txt in downloads", "lang": "English"},
            {"text": "look for budget.xlsx in documents", "lang": "English"},
            {"text": "locate presentation.pptx in desktop", "lang": "English"},
            {"text": "find config.json in downloads", "lang": "English"},
            {"text": "search files matching readme.md in desktop", "lang": "English"},
            {"text": "search for report.pdf in documents", "lang": "English"},
            {"text": "locate file database.csv in downloads", "lang": "English"},
            {"text": "find script.py in desktop", "lang": "English"},
            {"text": "search for invoice.pdf in documents", "lang": "English"},
            # Roman Urdu (10)
            {"text": "documents mein summary.docx dhoondo", "lang": "Roman Urdu"},
            {"text": "downloads mein notes.txt talash karo", "lang": "Roman Urdu"},
            {"text": "documents mein budget.xlsx khojo", "lang": "Roman Urdu"},
            {"text": "desktop pe presentation.pptx dhoond do", "lang": "Roman Urdu"},
            {"text": "downloads mein config.json talash kar", "lang": "Roman Urdu"},
            {"text": "desktop par readme.md file dhoondo", "lang": "Roman Urdu"},
            {"text": "documents mein report.pdf talash karo", "lang": "Roman Urdu"},
            {"text": "downloads mein database.csv dhoond do", "lang": "Roman Urdu"},
            {"text": "desktop pe script.py talash karo", "lang": "Roman Urdu"},
            {"text": "documents mein invoice.pdf dhoondo", "lang": "Roman Urdu"},
            # Mixed (10)
            {"text": "documents folder mein summary.docx search karo", "lang": "Mixed"},
            {"text": "downloads mein notes.txt file find karo", "lang": "Mixed"},
            {"text": "documents mein budget.xlsx locate karo", "lang": "Mixed"},
            {"text": "desktop pe presentation.pptx search kar do", "lang": "Mixed"},
            {"text": "downloads folder mein config.json file find karo", "lang": "Mixed"},
            {"text": "desktop mein readme.md search karo please", "lang": "Mixed"},
            {"text": "documents mein report.pdf file locate kar do", "lang": "Mixed"},
            {"text": "downloads pe database.csv search karo", "lang": "Mixed"},
            {"text": "desktop folder mein script.py find kar do", "lang": "Mixed"},
            {"text": "documents mein invoice.pdf search karo", "lang": "Mixed"},
        ],
    },
    "SYSTEM_DIAGNOSTICS": {
        "valid_tools": {
            "get_wifi_status",
            "diagnose_cpu",
            "diagnose_memory",
            "diagnose_storage",
            "diagnose_system",
            "diagnose_system_performance",
            "get_battery_status",
            "get_system_diagnostic_snapshot",
            "get_free_space",
            "inspect_process",
            "get_memory_status",
            "get_cpu_status",
            "get_network_state",
            "get_system_health_snapshot",
            "get_power_status",
        },
        "paraphrases": [
            # English (10)
            {"text": "check wifi status", "lang": "English"},
            {"text": "diagnose cpu usage", "lang": "English"},
            {"text": "check memory health", "lang": "English"},
            {"text": "what is the battery percentage", "lang": "English"},
            {"text": "check storage space", "lang": "English"},
            {"text": "diagnose system performance", "lang": "English"},
            {"text": "is wifi connected right now", "lang": "English"},
            {"text": "how much ram is being used", "lang": "English"},
            {"text": "check battery level", "lang": "English"},
            {"text": "inspect cpu usage and load", "lang": "English"},
            # Roman Urdu (10)
            {"text": "wifi status check karo", "lang": "Roman Urdu"},
            {"text": "cpu usage check kar do", "lang": "Roman Urdu"},
            {"text": "ram kitni use ho rahi hai", "lang": "Roman Urdu"},
            {"text": "battery kitni bachi hai", "lang": "Roman Urdu"},
            {"text": "storage space check karo", "lang": "Roman Urdu"},
            {"text": "system ki performance check karo", "lang": "Roman Urdu"},
            {"text": "wifi chal raha hai ya nahi", "lang": "Roman Urdu"},
            {"text": "memory status batao", "lang": "Roman Urdu"},
            {"text": "battery status kya hai", "lang": "Roman Urdu"},
            {"text": "cpu ka load check karo", "lang": "Roman Urdu"},
            # Mixed (10)
            {"text": "wifi connection status diagnose karo", "lang": "Mixed"},
            {"text": "cpu load check kar do please", "lang": "Mixed"},
            {"text": "ram consumption check karo", "lang": "Mixed"},
            {"text": "battery percentage check kar do", "lang": "Mixed"},
            {"text": "disk storage space check karo", "lang": "Mixed"},
            {"text": "overall system health diagnose karo", "lang": "Mixed"},
            {"text": "wifi status report batao", "lang": "Mixed"},
            {"text": "memory usage diagnose karo", "lang": "Mixed"},
            {"text": "battery health check kar do", "lang": "Mixed"},
            {"text": "cpu performance check karo", "lang": "Mixed"},
        ],
    },
    "WEB_NAVIGATION": {
        "valid_tools": {"open_url", "search_web", "launch_app"},
        "paraphrases": [
            # English (10)
            {"text": "open https://www.google.com", "lang": "English"},
            {"text": "search web for latest python release", "lang": "English"},
            {"text": "navigate to https://github.com", "lang": "English"},
            {"text": "search google for weather in lahore", "lang": "English"},
            {"text": "open url https://news.ycombinator.com", "lang": "English"},
            {"text": "browse to https://wikipedia.org", "lang": "English"},
            {"text": "search the web for fast typing tips", "lang": "English"},
            {"text": "open website https://reddit.com", "lang": "English"},
            {"text": "search online for world news", "lang": "English"},
            {"text": "go to https://youtube.com", "lang": "English"},
            # Roman Urdu (10)
            {"text": "https://www.google.com open karo", "lang": "Roman Urdu"},
            {"text": "python release ke liye web search karo", "lang": "Roman Urdu"},
            {"text": "https://github.com kholo", "lang": "Roman Urdu"},
            {"text": "google pe weather search karo", "lang": "Roman Urdu"},
            {"text": "https://news.ycombinator.com khol do", "lang": "Roman Urdu"},
            {"text": "https://wikipedia.org open kar do", "lang": "Roman Urdu"},
            {"text": "internet pe fast typing tips search karo", "lang": "Roman Urdu"},
            {"text": "https://reddit.com website kholo", "lang": "Roman Urdu"},
            {"text": "web par world news search karo", "lang": "Roman Urdu"},
            {"text": "https://youtube.com kholo", "lang": "Roman Urdu"},
            # Mixed (10)
            {"text": "browser mein https://www.google.com open karo", "lang": "Mixed"},
            {"text": "web pe python release search kar do", "lang": "Mixed"},
            {"text": "https://github.com website open karo", "lang": "Mixed"},
            {"text": "google search karo weather update", "lang": "Mixed"},
            {"text": "url https://news.ycombinator.com kholo", "lang": "Mixed"},
            {"text": "browser pe https://wikipedia.org open karo", "lang": "Mixed"},
            {"text": "online web search karo typing tips", "lang": "Mixed"},
            {"text": "https://reddit.com website browse karo", "lang": "Mixed"},
            {"text": "web search karo international news", "lang": "Mixed"},
            {"text": "chrome mein https://youtube.com open karo", "lang": "Mixed"},
        ],
    },
    "SCREENSHOT": {
        "valid_tools": {"capture_screen", "take_screenshot"},
        "paraphrases": [
            # English (10)
            {"text": "take a screenshot", "lang": "English"},
            {"text": "capture the entire screen", "lang": "English"},
            {"text": "take screen capture", "lang": "English"},
            {"text": "grab a screenshot of my display", "lang": "English"},
            {"text": "capture current screen right now", "lang": "English"},
            {"text": "snap a screenshot of the desktop", "lang": "English"},
            {"text": "take a picture of the screen", "lang": "English"},
            {"text": "capture screen display", "lang": "English"},
            {"text": "take a screen snapshot", "lang": "English"},
            {"text": "grab screen capture", "lang": "English"},
            # Roman Urdu (10)
            {"text": "screen capture karo", "lang": "Roman Urdu"},
            {"text": "screenshot le lo", "lang": "Roman Urdu"},
            {"text": "puri screen ki photo lo", "lang": "Roman Urdu"},
            {"text": "display ka screenshot lo", "lang": "Roman Urdu"},
            {"text": "screen snapshot banao", "lang": "Roman Urdu"},
            {"text": "desktop ki picture lo", "lang": "Roman Urdu"},
            {"text": "abhi screenshot le lo", "lang": "Roman Urdu"},
            {"text": "screen ki tasveer lo", "lang": "Roman Urdu"},
            {"text": "screen capture kar do", "lang": "Roman Urdu"},
            {"text": "screenshot bana do", "lang": "Roman Urdu"},
            # Mixed (10)
            {"text": "screen ka snapshot capture karo", "lang": "Mixed"},
            {"text": "display ka screenshot le lo please", "lang": "Mixed"},
            {"text": "screen capture kar do abhi", "lang": "Mixed"},
            {"text": "full screen screenshot le lo", "lang": "Mixed"},
            {"text": "current display snapshot lo", "lang": "Mixed"},
            {"text": "desktop ka screenshot capture karo", "lang": "Mixed"},
            {"text": "screen image capture kar do", "lang": "Mixed"},
            {"text": "display snapshot save kar lo", "lang": "Mixed"},
            {"text": "screen snapshot le lo", "lang": "Mixed"},
            {"text": "system display ka screenshot lo", "lang": "Mixed"},
        ],
    },
}


def evaluate():
    total_tests = 0
    total_passed = 0

    results_by_intent = {}
    results_by_lang = {"English": [0, 0], "Roman Urdu": [0, 0], "Mixed": [0, 0]}
    failures = []

    for intent, data in DATASET.items():
        valid_tools = data["valid_tools"]
        intent_passed = 0
        intent_total = len(data["paraphrases"])

        for item in data["paraphrases"]:
            text = item["text"]
            lang = item["lang"]
            total_tests += 1
            results_by_lang[lang][1] += 1

            plan = route_command(text)
            matched = False
            routed_tool = None
            if plan and plan.steps:
                routed_tools = [s.tool for s in plan.steps]
                # Check if any routed tool matches
                for t in routed_tools:
                    if t in valid_tools:
                        matched = True
                        routed_tool = t
                        break
                if not matched:
                    routed_tool = routed_tools[0]
            elif plan and plan.is_direct_message:
                routed_tool = f"direct_message: {plan.message_text[:30]}"
            else:
                routed_tool = "None"

            if matched:
                intent_passed += 1
                total_passed += 1
                results_by_lang[lang][0] += 1
            else:
                failures.append({
                    "intent": intent,
                    "text": text,
                    "lang": lang,
                    "expected": list(valid_tools),
                    "got": routed_tool,
                })

        acc = (intent_passed / intent_total) * 100.0 if intent_total else 0.0
        results_by_intent[intent] = (intent_passed, intent_total, acc)

    overall_acc = (total_passed / total_tests) * 100.0 if total_tests else 0.0

    print("=" * 80)
    print(" HELD-OUT PARAPHRASE ROUTING ACCURACY BENCHMARK (TASK P6)")
    print("=" * 80)
    print(f"{'Intent':<22} | {'Tested':<8} | {'Passed':<8} | {'Accuracy':<10}")
    print("-" * 80)
    for intent, (passed, tot, acc) in results_by_intent.items():
        print(f"{intent:<22} | {tot:<8} | {passed:<8} | {acc:>8.2f}%")
    print("-" * 80)
    print(f"{'OVERALL':<22} | {total_tests:<8} | {total_passed:<8} | {overall_acc:>8.2f}%")
    print("=" * 80)
    print("\nACCURACY BY LANGUAGE:")
    for lang, (p, t) in results_by_lang.items():
        l_acc = (p / t) * 100.0 if t else 0.0
        print(f"  {lang:<14}: {p}/{t} ({l_acc:.2f}%)")
    print("=" * 80)

    if failures:
        print(f"\nFAILURES ({len(failures)} total):")
        for f in failures[:15]:
            print(f"  [{f['intent']} | {f['lang']}] '{f['text']}' -> Got '{f['got']}', Expected {f['expected']}")

    return overall_acc, failures


if __name__ == "__main__":
    acc, fails = evaluate()
    if acc < 90.0:
        sys.exit(1)
