#!/usr/bin/env python3
"""
scripts/report_from_junit.py
Parses a JUnit XML file and outputs totals, failures per module, and failures per exception type
STRICTLY from the XML data only.
"""

import os
import argparse
import xml.etree.ElementTree as ET
from collections import defaultdict

def parse_junit_xml(xml_path):
    if not os.path.exists(xml_path):
        raise FileNotFoundError(f"XML file not found: {xml_path}")
    
    tree = ET.parse(xml_path)
    root = tree.getroot()

    # Handle both <testsuites> and single <testsuite> root
    if root.tag == "testsuites":
        testsuites = list(root.findall("testsuite"))
    elif root.tag == "testsuite":
        testsuites = [root]
    else:
        testsuites = root.findall(".//testsuite")

    total_tests = 0
    total_failures = 0
    total_errors = 0
    total_skipped = 0
    total_time = 0.0

    failures_by_module = defaultdict(int)
    errors_by_module = defaultdict(int)
    failures_by_exception = defaultdict(int)

    all_failure_details = []

    for suite in testsuites:
        for case in suite.findall("testcase"):
            total_tests += 1
            classname = case.get("classname", "").strip()
            name = case.get("name", "unknown")
            time_val = float(case.get("time", "0.0") or 0.0)
            total_time += time_val

            if classname:
                module = classname.split(".")[1] if "." in classname else classname
            else:
                parts = name.split(".")
                module = parts[1] if len(parts) > 1 else parts[0]


            failure = case.find("failure")
            error = case.find("error")
            skipped = case.find("skipped")

            if skipped is not None:
                total_skipped += 1

            if failure is not None:
                total_failures += 1
                failures_by_module[module] += 1
                exc_type = failure.get("type", "AssertionError") or "AssertionError"
                # Strip long module path from exception if present
                short_exc = exc_type.split(".")[-1]
                failures_by_exception[short_exc] += 1
                all_failure_details.append({
                    "kind": "FAILURE",
                    "module": module,
                    "name": name,
                    "exception": short_exc,
                    "message": failure.get("message", "").strip()[:120]
                })

            if error is not None:
                total_errors += 1
                errors_by_module[module] += 1
                exc_type = error.get("type", "Error") or "Error"
                short_exc = exc_type.split(".")[-1]
                failures_by_exception[short_exc] += 1
                all_failure_details.append({
                    "kind": "ERROR",
                    "module": module,
                    "name": name,
                    "exception": short_exc,
                    "message": error.get("message", "").strip()[:120]
                })

    passed = total_tests - (total_failures + total_errors + total_skipped)

    return {
        "xml_path": os.path.basename(xml_path),
        "total_tests": total_tests,
        "passed": passed,
        "failures": total_failures,
        "errors": total_errors,
        "skipped": total_skipped,
        "total_time": round(total_time, 2),
        "failures_by_module": sorted(failures_by_module.items(), key=lambda x: x[1], reverse=True),
        "errors_by_module": sorted(errors_by_module.items(), key=lambda x: x[1], reverse=True),
        "failures_by_exception": sorted(failures_by_exception.items(), key=lambda x: x[1], reverse=True),
        "all_failure_details": all_failure_details
    }

def generate_markdown(data):
    md = []
    md.append(f"# Test Baseline Report: `{data['xml_path']}`")
    md.append("")
    md.append("## Summary Totals (Extracted from XML)")
    md.append("")
    md.append("| Metric | Count |")
    md.append("|---|---|")
    md.append(f"| Total Tests | {data['total_tests']} |")
    md.append(f"| Passed | {data['passed']} |")
    md.append(f"| Failures | {data['failures']} |")
    md.append(f"| Errors | {data['errors']} |")
    md.append(f"| Skipped | {data['skipped']} |")
    md.append(f"| Execution Time (s) | {data['total_time']} |")
    md.append("")
    
    md.append("## Failures & Errors by Exception Type")
    md.append("")
    md.append("| Exception Type | Count |")
    md.append("|---|---|")
    for exc, count in data["failures_by_exception"]:
        md.append(f"| `{exc}` | {count} |")
    md.append("")

    md.append("## Failures by Module")
    md.append("")
    md.append("| Module | Failures |")
    md.append("|---|---|")
    for mod, count in data["failures_by_module"]:
        md.append(f"| `{mod}` | {count} |")
    md.append("")

    if data["errors_by_module"]:
        md.append("## Errors by Module")
        md.append("")
        md.append("| Module | Errors |")
        md.append("|---|---|")
        for mod, count in data["errors_by_module"]:
            md.append(f"| `{mod}` | {count} |")
        md.append("")

    return "\n".join(md)

def main():
    parser = argparse.ArgumentParser(description="Generate JUnit XML Baseline Report")
    parser.add_argument("xml_file", help="Path to JUnit XML file")
    parser.add_argument("--output", "-o", help="Path to save markdown output")
    args = parser.parse_args()

    data = parse_junit_xml(args.xml_file)
    md_content = generate_markdown(data)

    print("=== JUNIT XML BASELINE AUDIT SUMMARY ===")
    print(f"File: {data['xml_path']}")
    print(f"Total Tests: {data['total_tests']}")
    print(f"Passed: {data['passed']}")
    print(f"Failures: {data['failures']}")
    print(f"Errors: {data['errors']}")
    print(f"Skipped: {data['skipped']}")
    print(f"Total Time: {data['total_time']}s")
    print("\nTop 10 Failures by Exception Type:")
    for exc, count in data["failures_by_exception"][:10]:
        print(f"  {exc}: {count}")
    print("\nTop 10 Failures by Module:")
    for mod, count in data["failures_by_module"][:10]:
        print(f"  {mod}: {count}")

    if args.output:
        os.makedirs(os.path.dirname(os.path.abspath(args.output)), exist_ok=True)
        with open(args.output, "w", encoding="utf-8") as f:
            f.write(md_content)
        print(f"\nReport saved to: {args.output}")

if __name__ == "__main__":
    main()
