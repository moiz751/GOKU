"""
scripts/test_file_content_extractor.py - File Content Extractor & Summarizer Test.
Follows GOKU RULES v2 + 16-26 + Prompt R5 Step 3.

Evaluates 10 files of different types:
.txt, .md, .csv, .json, .py, .log, .html, .docx (if available), .pdf (if available), .xml.
Extracts: headings, first lines, counts, key terms.
Enforces bounded excerpt matching the 0.5B model token budget.
"""
from __future__ import annotations

import csv
import json
from pathlib import Path
import sys
import time

WORKSPACE_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(WORKSPACE_ROOT))

from tools.documents import extract_document, summarize_document

TOKEN_BUDGET_EXCERPT_CHARS = 1000  # ~250 tokens for 0.5B model input excerpt


def prepare_sample_test_files(test_dir: Path) -> list[Path]:
    test_dir.mkdir(parents=True, exist_ok=True)
    files = []

    # 1. Plain Text (.txt)
    f_txt = test_dir / "sample_service.txt"
    f_txt.write_text("Windows Service Audit\nSystem: Windows 10 Pro build 19045\nStatus: Operational\nKey service wuauserv running.\n", encoding="utf-8")
    files.append(f_txt)

    # 2. Markdown (.md)
    f_md = test_dir / "architecture.md"
    f_md.write_text("# GOKU Architecture\n## Vision Layer\nLight Eye operates under strict 4GB RAM budget.\nNo torch or cv2 imports allowed.\n", encoding="utf-8")
    files.append(f_md)

    # 3. CSV (.csv)
    f_csv = test_dir / "process_table.csv"
    with open(f_csv, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["pid", "name", "rss_mb", "status"])
        writer.writerow([101, "explorer.exe", 85.4, "running"])
        writer.writerow([102, "notepad.exe", 12.1, "running"])
        writer.writerow([103, "calc.exe", 24.5, "running"])
    files.append(f_csv)

    # 4. JSON (.json)
    f_json = test_dir / "config_sample.json"
    f_json.write_text(json.dumps({
        "agent": "GOKU",
        "mode": "dev",
        "ram_budget_mb": 4096,
        "token_limit": 1024,
        "modules": ["router", "window_lifecycle", "light_eye"]
    }, indent=2), encoding="utf-8")
    files.append(f_json)

    # 5. Python (.py)
    f_py = test_dir / "probe_math.py"
    f_py.write_text("def calculate_budget(total_mb: float, used_mb: float) -> float:\n    '''Calculates remaining memory headroom.'''\n    return max(0.0, total_mb - used_mb)\n\nif __name__ == '__main__':\n    print(calculate_budget(4096, 2500))\n", encoding="utf-8")
    files.append(f_py)

    # 6. Log File (.log)
    f_log = test_dir / "system_events.log"
    f_log.write_text("2026-10-15 12:00:01 INFO GOKU initialization started\n2026-10-15 12:00:02 INFO S1_goku_loaded RSS 46.8 MB\n2026-10-15 12:00:03 INFO Router resolved exact lexicon\n", encoding="utf-8")
    files.append(f_log)

    # 7. HTML (.html)
    f_html = test_dir / "report_preview.html"
    f_html.write_text("<html><head><title>Audit</title></head><body><h1>Verification Report</h1><p>Zero defect ledger validated cleanly.</p></body></html>", encoding="utf-8")
    files.append(f_html)

    # 8. XML (.xml)
    f_xml = test_dir / "manifest.xml"
    f_xml.write_text("<manifest><app name='Notepad' class='Notepad'/><app name='Calculator' class='ApplicationFrameWindow'/></manifest>", encoding="utf-8")
    files.append(f_xml)

    # 9. DOCX (.docx) if python-docx exists
    try:
        import docx
        f_docx = test_dir / "specification.docx"
        doc = docx.Document()
        doc.add_heading("GOKU Light Eye Specification", 0)
        doc.add_paragraph("Order of evidence: window facts -> UIA tree -> window screenshot -> OCR.")
        doc.save(str(f_docx))
        files.append(f_docx)
    except Exception:
        # Fallback to existing doc or another structured format
        f_fallback = test_dir / "spec_fallback.ini"
        f_fallback.write_text("[Screen]\norder=window_facts,uia,screenshot,ocr\nocr=unsupported\n", encoding="utf-8")
        files.append(f_fallback)

    # 10. PDF (.pdf) if pypdf / reportlab exists or create a simple text-based pdf
    try:
        test_dir / "guidelines.pdf"
        # Create minimal PDF if writer available or find an existing PDF in workspace
        found_pdf = list(WORKSPACE_ROOT.glob("**/*.pdf"))
        if found_pdf:
            files.append(found_pdf[0])
        else:
            f_sql = test_dir / "schema.sql"
            f_sql.write_text("CREATE TABLE telemetry (id INTEGER PRIMARY KEY, rss_mb REAL, status TEXT);\n", encoding="utf-8")
            files.append(f_sql)
    except Exception:
        f_sql = test_dir / "schema.sql"
        f_sql.write_text("CREATE TABLE telemetry (id INTEGER PRIMARY KEY, rss_mb REAL, status TEXT);\n", encoding="utf-8")
        files.append(f_sql)

    return files[:10]


def main():
    print("=" * 80)
    print("FILE CONTENT EXTRACTOR & EXTRACTIVE SUMMARIZER TEST (10 File Formats)")
    print(f"Timestamp: {time.strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 80)

    scratch_dir = WORKSPACE_ROOT / "scratch" / "test_extract_10_files"
    test_files = prepare_sample_test_files(scratch_dir)

    results = []

    for idx, fpath in enumerate(test_files, start=1):
        ext_res = extract_document(fpath)
        sum_res = summarize_document(fpath)

        text_content = ext_res.get("text", "")
        bounded_excerpt = text_content[:TOKEN_BUDGET_EXCERPT_CHARS]
        if len(text_content) > TOKEN_BUDGET_EXCERPT_CHARS:
            bounded_excerpt += "\n...[Bounded to 0.5B token budget]..."

        lines = [l.strip() for l in text_content.splitlines() if l.strip()]
        first_line = lines[0] if lines else "(empty)"
        word_count = len(text_content.split())
        line_count = len(lines)
        headings = ext_res.get("headings", [])
        key_sentences = sum_res.get("sentences", [])

        file_stat = {
            "index": idx,
            "filename": fpath.name,
            "extension": fpath.suffix,
            "size_bytes": fpath.stat().st_size,
            "first_line": first_line[:80],
            "line_count": line_count,
            "word_count": word_count,
            "headings_found": headings[:3],
            "key_extractive_excerpts": key_sentences[:2],
            "bounded_excerpt_char_len": len(bounded_excerpt),
            "status": "PASS" if ext_res.get("success") else "FAIL",
        }
        results.append(file_stat)

        print(f"\n[File {idx}/10]: {fpath.name} ({fpath.suffix})")
        print(f"  - Size: {fpath.stat().st_size} bytes | Lines: {line_count} | Words: {word_count}")
        print(f"  - First Line   : {first_line[:80]}")
        print(f"  - Headings     : {headings[:3] if headings else 'None'}")
        print(f"  - Key Terms/Excerpt : {key_sentences[:1] if key_sentences else 'Extracted plain'}")
        print(f"  - Bounded Excerpt Len : {len(bounded_excerpt)} chars (Capped for 0.5B model)")

    out_file = WORKSPACE_ROOT / "reports" / "file_extractor_eval.json"
    out_file.parent.mkdir(parents=True, exist_ok=True)
    with open(out_file, "w", encoding="utf-8") as f:
        json.dump(results, f, indent=2)
    print(f"\n[INFO] 10-file extraction results saved to: {out_file}")
    print("=" * 80)


if __name__ == "__main__":
    main()
