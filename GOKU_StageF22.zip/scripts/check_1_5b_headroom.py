"""
scripts/check_1_5b_headroom.py - Rule and Verdict Evaluator for 1.5B Model Feasibility
Prompt R7 Requirement 1:
"No move to a 1.5B model on this laptop unless docs/RESOURCE_BUDGET.json shows
enough measured headroom in state S4. Write the rule and compute the verdict by script."
"""
from __future__ import annotations

import json
from pathlib import Path

BUDGET_FILE = Path("docs/RESOURCE_BUDGET.json")

# Rule thresholds
# 1.5B model (e.g. Qwen2.5-1.5B-Instruct Q4_K_M) requires ~1,150 MB RSS vs ~380 MB for 0.5B.
# Incremental model delta = 770 MB.
# Minimum safety cushion for Windows 10 OS + desktop buffer = 430 MB.
# Total S4 available headroom required = 1,200 MB.
MIN_S4_HEADROOM_MB = 1200.0
MODEL_DELTA_MB = 770.0
OS_SAFETY_BUFFER_MB = 430.0


def evaluate_1_5b_headroom(budget_path: Path = BUDGET_FILE) -> dict:
    if not budget_path.exists():
        return {
            "verdict": "BLOCKED",
            "reason": f"Budget file {budget_path} not found.",
            "rule": "Headroom check failed: missing budget file",
            "eligible": False,
        }

    with open(budget_path, "r", encoding="utf-8") as f:
        budget = json.load(f)

    avail_map = budget.get("available_mb_per_state", {})
    s4_avail = avail_map.get("S4_with_chrome")
    s1_avail = avail_map.get("S1_goku_loaded")
    budget.get("all_states_present", False)

    rule_description = (
        f"1.5B Model Eligibility Rule: State S4 (GOKU + Model + Chrome) must be measured "
        f"and available RAM in S4 must be >= {MIN_S4_HEADROOM_MB:.1f} MB "
        f"(Incremental 1.5B Delta: {MODEL_DELTA_MB:.1f} MB + OS Safety Cushion: {OS_SAFETY_BUFFER_MB:.1f} MB)."
    )

    if s4_avail is None:
        return {
            "verdict": "BLOCKED",
            "reason": (
                f"State S4 (S4_with_chrome) is unmeasured (null) in {budget_path}. "
                f"S1_goku_loaded available RAM is {s1_avail} MB, which is already well below the {MIN_S4_HEADROOM_MB} MB requirement."
            ),
            "rule": rule_description,
            "s4_available_mb": None,
            "s1_available_mb": s1_avail,
            "threshold_mb": MIN_S4_HEADROOM_MB,
            "eligible": False,
        }

    if s4_avail < MIN_S4_HEADROOM_MB:
        return {
            "verdict": "BLOCKED",
            "reason": (
                f"Measured Available RAM in S4 is {s4_avail:.2f} MB, which is below the "
                f"required {MIN_S4_HEADROOM_MB:.2f} MB threshold (deficit: {MIN_S4_HEADROOM_MB - s4_avail:.2f} MB)."
            ),
            "rule": rule_description,
            "s4_available_mb": s4_avail,
            "threshold_mb": MIN_S4_HEADROOM_MB,
            "eligible": False,
        }

    return {
        "verdict": "ALLOWED",
        "reason": f"Measured S4 available RAM ({s4_avail:.2f} MB) satisfies headroom threshold ({MIN_S4_HEADROOM_MB:.2f} MB).",
        "rule": rule_description,
        "s4_available_mb": s4_avail,
        "threshold_mb": MIN_S4_HEADROOM_MB,
        "eligible": True,
    }


def main():
    print("=" * 80)
    print("PROMPT R7: 1.5B MODEL RESOURCE HEADROOM RULE & VERDICT EVALUATOR")
    print("=" * 80)
    res = evaluate_1_5b_headroom()
    print(f"RULE STATEMENT:\n  {res['rule']}\n")
    print("MEASURED STATE VALUES:")
    print(f"  S1_goku_loaded Available RAM : {res.get('s1_available_mb')} MB")
    print(f"  S4_with_chrome Available RAM : {res.get('s4_available_mb')} MB")
    print(f"  Required Headroom Threshold  : {res.get('threshold_mb')} MB\n")
    print(f"VERDICT: {res['verdict']}")
    print(f"DECISION REASON:\n  {res['reason']}")
    print("=" * 80)
    if not res["eligible"]:
        print("FINAL ACTION: Model STAYS at 0.5B. Migration to 1.5B is strictly prohibited.")
    else:
        print("FINAL ACTION: 1.5B migration permitted by budget.")


if __name__ == "__main__":
    main()
