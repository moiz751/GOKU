"""Real-task suite + failure diagnostic. Run on the Windows laptop:   set GOKU_MODE=run   then   python scripts\\real_task_suite.py [--no-gui] [--only blog,app] [--cleanup]
Every command goes through GOKU's REAL path (brain.task_agent.try_handle, then main.handle_command - exactly what the prompt does) and the result is judged by
INDEPENDENT checks (process started, window title, new file + its words/hash, screenshot file ...), never by what GOKU says about itself.
Verdicts: PASS (independent check satisfied) | FALSE_SUCCESS (GOKU sounded done, check failed) | FAIL_HONEST (GOKU said it failed) | NO_ROUTE (nothing handled it)
          | INCONCLUSIVE (the check could not be measured here) | UNVERIFIED (task has no independent check: never counted as PASS) | SKIPPED.
Writes evidence/real_tasks/run_<time>.json and docs/REAL_TASK_REPORT.md (with the top failure reasons). It never deletes anything and asks before opening apps."""
import argparse, contextlib, glob, hashlib, io, json, os, re, shutil, socket, sys, tempfile, threading, time, types, ctypes
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
os.chdir(ROOT); sys.path.insert(0, str(ROOT))
IS_WIN = os.name == "nt"
if not IS_WIN:                                                   # Linux dry run: win32 modules do not exist
    from unittest.mock import MagicMock
    for m in ("win32gui", "win32con", "win32api", "win32process", "win32ui", "pythoncom", "pyautogui"):
        sys.modules.setdefault(m, MagicMock())
    if not hasattr(ctypes, "windll"):
        ctypes.windll = types.SimpleNamespace(user32=MagicMock(), gdi32=MagicMock(), kernel32=MagicMock())

HOME = Path.home()
SEARCH_DIRS = [ROOT, ROOT / "logs", HOME / "Desktop", HOME / "Documents", HOME / "Downloads", HOME / "Pictures"]


# ------------------------------------------------------------------ independent checks (each returns (ok|None, why); None = cannot measure here)
def windows_titles():
    if not IS_WIN:
        return None
    titles = []
    EnumProc = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_void_p, ctypes.c_void_p)
    u = ctypes.windll.user32
    def cb(h, _):
        if u.IsWindowVisible(h):
            n = u.GetWindowTextLengthW(h)
            if n:
                b = ctypes.create_unicode_buffer(n + 1); u.GetWindowTextW(h, b, n + 1); titles.append(b.value)
        return True
    u.EnumWindows(EnumProc(cb), 0)
    return titles


def procs():
    import psutil
    return {p.pid: (p.info["name"] or "", p.info["create_time"] or 0) for p in psutil.process_iter(["name", "create_time"])}


def chk_process(names, ctx):
    now = procs()
    low = [n.lower() for n in names]
    hit_new = [pid for pid, (nm, ct) in now.items() if nm.lower() in low and pid not in ctx["procs0"]]
    if hit_new:
        return True, f"new process {names} pid {hit_new[:3]}"
    already = any(nm.lower() in low for nm, _ in ctx["procs0"].values())
    return (None, f"{names} was already running before; a new window cannot be told apart without a window-title check") if already else (False, f"no {names} process was started")


def chk_title(words, ctx):
    t = windows_titles()
    if t is None:
        return None, "window titles can only be read on Windows"
    hit = [x for x in t if all(w.lower() in x.lower() for w in words)]
    return (True, f"window '{hit[0][:60]}'") if hit else (False, f"no visible window with {words} in its title (titles: {[x[:30] for x in t[:6]]})")


def newest_files(globs, ctx, dirs=None):
    out = []
    for d in (dirs or SEARCH_DIRS):
        for g in globs:
            for f in glob.glob(str(Path(d) / "**" / g), recursive=True):
                try:
                    if os.path.getmtime(f) >= ctx["t0"] - 1 and os.path.isfile(f) and "real_tasks" not in f and "real_task_work" not in f:
                        out.append(f)
                except OSError:
                    pass
    return sorted(set(out), key=os.path.getmtime, reverse=True)


def chk_screenshot(ctx):
    f = newest_files(["*.png", "*.jpg"], ctx)
    return (True, f"new image {f[0]}") if f and os.path.getsize(f[0]) > 2000 else (False, "no new screenshot file appeared")


def chk_blog(topic, min_words, ctx):
    files = newest_files(["*.md", "*.txt", "*.html", "*.docx"], ctx)
    best = None
    for f in files:
        try:
            txt = Path(f).read_text(encoding="utf-8", errors="ignore") if not f.endswith(".docx") else ""
        except Exception:
            continue
        words = len(re.findall(r"\w+", txt))
        if words >= min_words and txt.lower().count(topic.lower()) >= 3 and not re.search(r"lorem ipsum|\bTODO\b|\[insert", txt, re.I):
            return True, f"{f}: {words} words, '{topic}' x{txt.lower().count(topic.lower())}"
        if best is None or words > best[1]:
            best = (f, words)
    return False, ("best new file " + (f"{best[0]} has only {best[1]} words or does not discuss '{topic}'" if best else "none") + f"; need >= {min_words} words about '{topic}'") if best else f"no new text/blog file was created (need >= {min_words} words about '{topic}')"


def chk_file_hash(path, sha, ctx):
    p = Path(path)
    if not p.is_file():
        return False, f"{path} does not exist"
    return (hashlib.sha256(p.read_bytes()).hexdigest() == sha, "content matches" if hashlib.sha256(p.read_bytes()).hexdigest() == sha else "file exists but content differs")


def chk_file_contains(path, words, ctx):
    p = Path(path)
    if not p.is_file():
        return False, f"{path} does not exist"
    t = p.read_text(encoding="utf-8", errors="ignore").lower()
    miss = [w for w in words if w.lower() not in t]
    return (not miss, "contains " + ",".join(words) if not miss else f"missing {miss}")


def chk_exists(path, ctx):
    return Path(path).exists(), f"{path} {'exists' if Path(path).exists() else 'does not exist'}"


def chk_reply(words, ctx, absent=()):
    r = (ctx["reply"] or "").lower()
    miss = [w for w in words if w.lower() not in r]
    bad = [w for w in absent if w.lower() in r]
    return (not miss and not bad, "reply ok" if not miss and not bad else f"reply missing {miss} / contains forbidden {bad}")


def chk_seo_job(ctx):
    f = newest_files(["optimized.md", "report.md"], ctx, [ROOT / "logs"])
    return (True, f"seo output {f[0]}") if f else (False, "no new seo job output (optimized.md/report.md)")


def chk_internet():
    try:
        socket.create_connection(("1.1.1.1", 53), 3).close(); return True
    except OSError:
        return False


# ------------------------------------------------------------------ tasks
def build_tasks(W: Path, port: int):
    (W / "a.txt").write_text("vinylfrog alpha beta gamma delta\nsecond line about PPF films\n", encoding="utf-8")
    (W / "story.txt").write_text("The knifeless tape protects the paint. Installers use it to cut film without a blade. " * 6, encoding="utf-8")
    (W / "blog_in.md").write_text("# PPF Trimming\n\nPPF trimming tools help installers cut paint protection film. " * 30, encoding="utf-8")
    a_sha = hashlib.sha256((W / "a.txt").read_bytes()).hexdigest()
    (W / "dl").mkdir(exist_ok=True); (W / "copy").mkdir(exist_ok=True)
    T = []
    def t(id, family, cmd, checks, gui=False, net=False, note=""):
        T.append(dict(id=id, family=family, cmd=cmd, checks=checks, gui=gui, net=net, note=note))
    # apps / gui
    t("app01", "app", "chrome kholo", [lambda c: chk_process(["chrome.exe", "chrome"], c)], gui=True)
    t("app02", "app", "notepad kholo", [lambda c: chk_process(["notepad.exe", "notepad"], c), lambda c: chk_title(["notepad"], c)], gui=True)
    t("app03", "app", "calculator kholo", [lambda c: chk_process(["calculatorapp.exe", "calc.exe", "calculator.exe", "win32calc.exe"], c)], gui=True)
    t("app04", "app", "open paint", [lambda c: chk_process(["mspaint.exe", "paintstudio.view.exe"], c)], gui=True)
    t("app05", "app", "notepad kholo aur usme hello goku likho", [lambda c: chk_title(["notepad"], c), lambda c: chk_reply(["hello goku"], c)], gui=True, note="typed text itself is not readable without UIA; title only")
    t("scr01", "screen", "screenshot lo", [chk_screenshot], gui=True)
    t("scr02", "screen", "screen par kya hai batao", [lambda c: (len(c["reply"] or "") > 60 and not re.search(r"no verified answer|FAILED", c["reply"] or ""), "reply describes the screen" if len(c["reply"] or "") > 60 else "reply too short/none")], gui=True)
    t("web01", "web", "chrome kholo aur youtube.com kholo", [lambda c: chk_title(["youtube"], c)], gui=True, net=True)
    t("web02", "web", "google par ppf trimming tool search karo", [lambda c: chk_title(["ppf"], c)], gui=True, net=True)
    t("web03", "web", "open wikipedia and read about Karachi", [lambda c: chk_title(["karachi"], c), lambda c: chk_reply(["karachi"], c)], gui=True, net=True)
    t("game01", "game", "chrome kholo aur 2048 game khelo", [lambda c: chk_title(["2048"], c)], gui=True, net=True, note="no public game page is assumed: title check only")
    t("game02", "game", "chrome kholo aur chess khelo", [lambda c: chk_title(["chess"], c)], gui=True, net=True)
    # files (fully verifiable: real files in a work folder)
    t("file01", "file", f'copy "{W / "a.txt"}" to "{W / "copy"}"', [lambda c: chk_file_hash(W / "copy" / "a.txt", a_sha, c)])
    t("file02", "file", f'rename "{W / "story.txt"}" to "story_new.txt"', [lambda c: chk_exists(W / "story_new.txt", c)])
    t("file03", "file", f'naya folder banao "{W / "made_folder"}"', [lambda c: chk_exists(W / "made_folder", c)])
    t("file04", "file", f'"{W / "note.txt"}" file banao jisme "hello goku" likha ho', [lambda c: chk_file_contains(W / "note.txt", ["hello goku"], c)])
    t("file05", "file", f'"{W / "a.txt"}" ko summarise karo', [lambda c: chk_reply(["vinylfrog"], c)])
    t("file06", "file", f'a.txt dhoondo folder "{W}" mein', [lambda c: chk_reply(["a.txt"], c)])
    t("file07", "file", f'move "{W / "a.txt"}" to "{W / "copy" / "moved"}"', [lambda c: chk_exists(W / "copy" / "moved" / "a.txt", c)])
    # download (local server so it is repeatable)
    t("dl01", "download", f"download http://127.0.0.1:{port}/sample.pdf to \"{W / 'dl'}\"", [lambda c: chk_exists(W / "dl" / "sample.pdf", c)])
    t("dl02", "download", "mujhe Dune movie download karke do", [lambda c: (not newest_files(["*.mp4", "*.mkv"], c), "no video file was fetched from an unlicensed source"), lambda c: chk_reply(["legal"], c)])
    # writing
    t("blog01", "blog", "write a 800 word blog about vinylfrog", [lambda c: chk_blog("vinylfrog", 600, c)])
    t("blog02", "blog", "vinylfrog ke upar blog likho", [lambda c: chk_blog("vinylfrog", 600, c)])
    t("blog03", "blog", "write a 1200 word blog about PPF trimming tools using live web research", [lambda c: chk_blog("ppf", 900, c)], net=True)
    t("blog04", "blog", f'seo run "{W / "blog_in.md"}"', [chk_seo_job])
    t("blog05", "blog", "vinylfrog.com website dekho aur uska review likho", [lambda c: chk_blog("vinylfrog", 300, c)], net=True)
    # qa / maths / memory
    t("qa01", "qa", "2 plus 2 kya hota hai", [lambda c: chk_reply(["4"], c)])
    t("qa02", "qa", "pakistan ki capital kya hai", [lambda c: chk_reply(["islamabad"], c)])
    t("qa03", "qa", "25% of 4800", [lambda c: chk_reply(["1200"], c)])
    t("qa04", "qa", "translate hello to urdu", [lambda c: chk_reply(["salam"], c)])
    t("qa05", "qa", "fix this python bug in main.py", [lambda c: chk_reply([], c, absent=["high-level, general-purpose"])], note="must not answer with a definition of Python")
    t("mem01", "memory", "remember my name is Leaflo", [lambda c: chk_reply(["leaflo"], c)])
    t("mem02", "memory", "mera naam kya hai", [lambda c: chk_reply(["leaflo"], c)])
    # skills (F15): the library + executable skills
    t("sk01", "skill", "skill find blog sounds like AI", [lambda c: chk_reply(["humanizer"], c)])
    t("sk02", "skill", "design brief jewelry ecommerce store", [lambda c: chk_reply(["#"], c), lambda c: chk_reply(["Palette"], c)])
    t("sk03", "skill", "diagram: flow Start -> Fetch page -> Verify file", [lambda c: chk_reply(["Diagram ban gaya", "labels missing=[]"], c)])
    (W / "ai.txt").write_text("Great question! Additionally, this is a testament to meticulous work. I hope this helps!")
    t("sk04", "skill", f'humanize fix "{W / "ai.txt"}"', [lambda c: chk_exists(W / "ai.humanized.txt", c), lambda c: chk_file_contains(W / "ai.txt", ["Great question"], c)])
    t("sk05", "skill", "tower defense game banao", [lambda c: chk_reply(["tower-defense"], c)])
    t("rem01", "reminder", "2 minute baad reminder lagao chai pani", [], note="no independent check exists for reminders yet -> UNVERIFIED")
    return T


class _PDF(BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def do_GET(self):
        b = b"%PDF-1.4\n" + b"x" * 5000
        self.send_response(200); self.send_header("Content-Type", "application/pdf"); self.send_header("Content-Length", str(len(b))); self.end_headers(); self.wfile.write(b)


def preflight():
    rows = []
    def add(name, ok, detail, fix=""):
        rows.append(dict(name=name, ok=ok, detail=detail, fix=fix))
    mode = os.environ.get("GOKU_MODE", "dev").lower()
    add("GOKU_MODE", mode == "run", mode, "set GOKU_MODE=run   (in dev mode the model, GUI and screenshots are BLOCKED by design)")
    try:
        from config.settings import is_model_call_allowed
        ok, why = is_model_call_allowed(); add("model allowed", ok, why[:160], "run mode + enough free RAM (readiness READY/DEGRADED)")
    except Exception as e:
        add("model allowed", False, repr(e)[:120])
    try:
        import urllib.request
        urllib.request.urlopen(os.environ.get("OLLAMA_BASE_URL", "http://127.0.0.1:11434") + "/api/tags", timeout=3).read(); add("ollama server", True, "reachable")
    except Exception as e:
        add("ollama server", False, repr(e)[:80], "start Ollama (ollama serve) and pull the model")
    try:
        import psutil
        add("free RAM", psutil.virtual_memory().available > 900 * 1048576, f"{psutil.virtual_memory().available // 1048576} MB", "close other programs; the model needs headroom")
    except Exception:
        pass
    add("internet", chk_internet(), "tcp 1.1.1.1:53", "connect internet for web/blog-research tasks")
    add("chrome", bool(shutil.which("chrome") or shutil.which("chrome.exe") or any(Path(p).exists() for p in (r"C:\Program Files\Google\Chrome\Application\chrome.exe", r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe"))), "chrome executable", "install Chrome or tell GOKU which browser to use")
    add("tesseract", bool(shutil.which("tesseract")), "OCR engine", "winget install UB-Mannheim.TesseractOCR")
    add("windows", IS_WIN, os.name, "GUI/screen tasks need Windows")
    return rows


def classify(reply, checks_res, has_checks):
    r = reply or ""
    claims_ok = bool(r) and not re.search(r"(?i)\b(FAILED|not installed|blocked|no verified answer|nahi (?:ho|kar)|cannot|can't|error|NOT_IMPLEMENTED|Precondition failed|nahi\s+(?:likh|mil|mila|mili|ban|bana|ho|kar)|koi\s+\w+\s+nahi|not found|roka\s+gaya)\b", r)
    if not has_checks:
        return "UNVERIFIED", "no independent check exists for this task"
    if any(ok is False for ok, _ in checks_res):
        return ("FALSE_SUCCESS" if claims_ok else "FAIL_HONEST"), "; ".join(w for ok, w in checks_res if ok is False)
    if any(ok is None for ok, _ in checks_res):
        return "INCONCLUSIVE", "; ".join(w for ok, w in checks_res if ok is None)
    return "PASS", "; ".join(w for _, w in checks_res)


def run_one(task, W, args):
    import psutil  # noqa: F401
    ctx = dict(t0=time.time(), procs0=procs(), reply=None)
    buf = io.StringIO()
    handled, route = "none", "?"
    reply = None
    try:
        from brain.task_agent import try_handle, route as rt
        route = rt(task["cmd"])["route"]
        with contextlib.redirect_stdout(buf), contextlib.redirect_stderr(buf):
            reply = try_handle(task["cmd"])
            handled = "new-stack(try_handle)"
            if reply is None:
                import main as goku_main
                reply = goku_main.handle_command(task["cmd"]); handled = "legacy(handle_command)"
    except Exception as e:
        reply = f"EXCEPTION {type(e).__name__}: {e}"; handled = handled + "+exception"
    ctx["reply"] = str(reply) if reply is not None else ""
    deadline = time.time() + (10 if task["gui"] or task["net"] else 2)
    res = []
    while True:                                                    # apps/files appear a little later: poll the independent checks
        res = []
        for ch in task["checks"]:
            try:
                res.append(ch(ctx))
            except Exception as e:
                res.append((None, f"check crashed: {e!r}"))
        if all(ok for ok, _ in res) or time.time() > deadline or not task["checks"]:
            break
        time.sleep(0.7)
    verdict, why = classify(ctx["reply"], res, bool(task["checks"]))
    trace = [ln for ln in buf.getvalue().splitlines() if ln.strip()][-4:]
    return dict(id=task["id"], family=task["family"], cmd=task["cmd"], route=route, handled_by=handled, verdict=verdict, why=why[:400], reply=ctx["reply"][:300], trace=trace, note=task.get("note", ""), seconds=round(time.time() - ctx["t0"], 1))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--no-gui", action="store_true"); ap.add_argument("--no-net", action="store_true"); ap.add_argument("--only", default=""); ap.add_argument("--yes", action="store_true"); ap.add_argument("--list", action="store_true")
    args = ap.parse_args()
    pre = preflight()
    print("PREFLIGHT (these decide whether commands can work at all):")
    for r in pre:
        print(f"  [{'ok' if r['ok'] else 'BAD'}] {r['name']}: {r['detail']}" + (f"   -> FIX: {r['fix']}" if not r['ok'] and r['fix'] else ""))
    W = Path(tempfile.mkdtemp(prefix="real_task_work_", dir=str(ROOT)))
    srv = HTTPServer(("127.0.0.1", 0), _PDF); threading.Thread(target=srv.serve_forever, daemon=True).start()
    os.environ["GOKU_ALLOW_LOCAL_DOWNLOAD"] = "1"
    tasks = build_tasks(W, srv.server_port)
    only = [x for x in args.only.split(",") if x]
    tasks = [t for t in tasks if (not only or t["family"] in only or t["id"] in only) and not (args.no_gui and t["gui"]) and not (args.no_net and t["net"])]
    if args.list:
        for t in tasks: print(t["id"], t["family"], t["cmd"])
        return 0
    if any(t["gui"] for t in tasks) and not args.yes:
        if input("This opens apps / takes screenshots on THIS PC (nothing is deleted). Continue? [y/N] ").strip().lower() != "y":
            print("stopped."); return 1
    out = []
    for t in tasks:
        r = run_one(t, W, args); out.append(r)
        print(f"{r['id']:<7} {r['verdict']:<14} {r['handled_by']:<24} {t['cmd'][:60]}\n        {r['why'][:150]}")
    ev = ROOT / "evidence" / "real_tasks"; ev.mkdir(parents=True, exist_ok=True)
    stamp = time.strftime("%Y%m%d_%H%M%S")
    (ev / f"run_{stamp}.json").write_text(json.dumps({"preflight": pre, "results": out, "goku_mode": os.environ.get("GOKU_MODE", "dev"), "os": os.name}, indent=1), encoding="utf-8")
    counts = {}
    for r in out:
        counts[r["verdict"]] = counts.get(r["verdict"], 0) + 1
    reasons = {}
    for r in out:
        if r["verdict"] in ("FAIL_HONEST", "FALSE_SUCCESS", "NO_ROUTE"):
            key = re.sub(r"[\\/]\S+", "<path>", (r["why"] or r["reply"])[:90]); reasons[key] = reasons.get(key, 0) + 1
    md = ["# Real task report (independent checks)", "", f"GOKU_MODE={os.environ.get('GOKU_MODE', 'dev')}  OS={os.name}", "", "## Preflight", ""] + [f"- {'OK ' if r['ok'] else 'BAD'} {r['name']}: {r['detail']}" + (f" -> {r['fix']}" if not r['ok'] and r['fix'] else "") for r in pre]
    md += ["", "## Verdicts", ""] + [f"- {k}: {v}" for k, v in sorted(counts.items())] + ["", "## Top failure reasons", ""] + [f"- x{v}  {k}" for k, v in sorted(reasons.items(), key=lambda x: -x[1])[:12]] + ["", "## Tasks", "", "| id | cmd | handled by | verdict | why |", "|---|---|---|---|---|"]
    md += [f"| {r['id']} | {r['cmd'][:50]} | {r['handled_by']} | {r['verdict']} | {r['why'][:120].replace('|', '/')} |" for r in out]
    (ROOT / "docs").mkdir(exist_ok=True)
    (ROOT / "docs" / "REAL_TASK_REPORT.md").write_text("\n".join(md), encoding="utf-8")
    print("\nSUMMARY:", counts, "\nreport: docs/REAL_TASK_REPORT.md   raw: evidence/real_tasks/run_" + stamp + ".json")
    srv.shutdown()
    shutil.rmtree(W, ignore_errors=True)                 # the temp work folder is not left behind in the project
    return 0


if __name__ == "__main__":
    sys.exit(main())
