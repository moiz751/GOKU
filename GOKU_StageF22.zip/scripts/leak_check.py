"""
scripts/leak_check.py - Process and Window Leak Detection Tool & Pytest Fixture.
Follows GOKU RULES v2 + 16-26 (Prompt R4 Step 4).

Captures:
- Running processes (PID, executable name, command line, creation time)
- Visible & top-level windows (HWND, PID, class name, title, visibility)

Detects and reports new survivors between two points in time.
Provides:
1. CLI interface (--start, --check, --save-report)
2. Context manager and pytest fixture for automated test integration.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import sys
import time
from typing import Any, Dict, List

try:
    import psutil
except ImportError:
    psutil = None

WORKSPACE_ROOT = Path(__file__).resolve().parent.parent
DEFAULT_STATE_FILE = WORKSPACE_ROOT / ".leak_before.json"

# Process names that represent background OS tasks or the test runner itself
BENIGN_IGNORED_PROCESSES = {
    "conhost.exe",
    "dllhost.exe",
    "backgroundtaskhost.exe",
    "wmiapsrv.exe",
    "runtimebroker.exe",
    "svchost.exe",
    "searchapp.exe",
    "searchindexer.exe",
    "startmenuexperiencehost.exe",
    "textinputhost.exe",
    "ctfmon.exe",
    "tiworker.exe",
    "trustedinstaller.exe",
    "taskhostw.exe",
    "searchfilterhost.exe",
    "searchprotocolhost.exe",
    "smartscreen.exe",
    "mousocoreworker.exe",
    "wmiprvse.exe",
    "powershell.exe",
    "cmd.exe",
}



def take_process_snapshot() -> Dict[int, Dict[str, Any]]:
    """Captures currently running processes on the system."""
    procs: Dict[int, Dict[str, Any]] = {}
    if psutil is None:
        return procs

    current_pid = os.getpid()
    parent_pid = os.getppid() if hasattr(os, "getppid") else 0

    for p in psutil.process_iter(["pid", "name", "create_time", "cmdline"]):
        try:
            p_info = p.info
            pid = p_info["pid"]
            # Exclude current test process and its direct parent runner
            if pid in (current_pid, parent_pid):
                continue
            name = (p_info["name"] or "").lower()
            procs[pid] = {
                "pid": pid,
                "name": name,
                "cmdline": p_info.get("cmdline") or [],
                "create_time": p_info.get("create_time", 0.0),
            }
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            pass
    return procs


def take_window_snapshot_light() -> Dict[int, Dict[str, Any]]:
    """Captures existing visible top-level windows."""
    windows: Dict[int, Dict[str, Any]] = {}
    if sys.platform != "win32":
        return windows

    import ctypes
    from ctypes import wintypes
    user32 = ctypes.windll.user32

    def enum_cb(h: int, lparam: Any) -> bool:
        try:
            hwnd = int(h)
            if not user32.IsWindow(hwnd):
                return True
            visible = bool(user32.IsWindowVisible(hwnd))

            cbuff = ctypes.create_unicode_buffer(256)
            user32.GetClassNameW(hwnd, cbuff, 256)
            cls_name = cbuff.value or ""

            tlen = user32.GetWindowTextLengthW(hwnd) + 1
            tbuff = ctypes.create_unicode_buffer(tlen)
            user32.GetWindowTextW(hwnd, tbuff, tlen)
            title = tbuff.value or ""

            win_pid = wintypes.DWORD()
            user32.GetWindowThreadProcessId(hwnd, ctypes.byref(win_pid))
            pid = int(win_pid.value) if win_pid.value else 0

            windows[hwnd] = {
                "hwnd": hwnd,
                "pid": pid,
                "class": cls_name,
                "title": title,
                "visible": visible,
            }
        except Exception:
            pass
        return True

    WNDENUMPROC = ctypes.WINFUNCTYPE(ctypes.c_bool, wintypes.HWND, wintypes.LPARAM)
    user32.EnumWindows(WNDENUMPROC(enum_cb), 0)

    try:
        h_def = user32.OpenDesktopW("default", 0, False, 0x01FF)
        if h_def:
            user32.EnumDesktopWindows(h_def, WNDENUMPROC(enum_cb), 0)
    except Exception:
        pass
    return windows


def capture_full_leak_state() -> Dict[str, Any]:
    """Captures combined process and window state."""
    return {
        "timestamp": time.time(),
        "iso_timestamp": datetime.now(timezone.utc).isoformat(),
        "processes": take_process_snapshot(),
        "windows": take_window_snapshot_light(),
    }


def compare_leak_states(
    before_state: Dict[str, Any],
    after_state: Dict[str, Any],
    strict_benign_filter: bool = True,
) -> Dict[str, Any]:
    """
    Compares two leak states and identifies survivor processes and windows.
    """
    before_pids = {int(p) for p in before_state.get("processes", {}).keys()}
    after_procs = after_state.get("processes", {})

    survivor_processes: List[Dict[str, Any]] = []
    for pid_str, p_info in after_procs.items():
        pid = int(pid_str)
        if pid not in before_pids:
            p_name = p_info.get("name", "").lower()
            if strict_benign_filter and p_name in BENIGN_IGNORED_PROCESSES:
                continue
            survivor_processes.append(p_info)

    before_hwnds = {int(h) for h in before_state.get("windows", {}).keys()}
    after_windows = after_state.get("windows", {})

    survivor_windows: List[Dict[str, Any]] = []
    for h_str, w_info in after_windows.items():
        hwnd = int(h_str)
        if hwnd not in before_hwnds:
            # Check if visible or has meaningful class
            if w_info.get("visible", False):
                survivor_windows.append(w_info)

    return {
        "timestamp_before": before_state.get("timestamp"),
        "timestamp_after": after_state.get("timestamp"),
        "survivor_process_count": len(survivor_processes),
        "survivor_window_count": len(survivor_windows),
        "has_leaks": bool(survivor_processes or survivor_windows),
        "survivor_processes": survivor_processes,
        "survivor_windows": survivor_windows,
    }


class LeakChecker:
    """
    Context manager for automated leak checking in tests.
    Usage:
        with LeakChecker(assert_zero_leaks=True):
            run_gui_action()
    """

    def __init__(self, assert_zero_leaks: bool = False, label: str = ""):
        self.assert_zero_leaks = assert_zero_leaks
        self.label = label
        self.before_state: Dict[str, Any] = {}
        self.result: Dict[str, Any] = {}

    def __enter__(self) -> "LeakChecker":
        self.before_state = capture_full_leak_state()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        after_state = capture_full_leak_state()
        self.result = compare_leak_states(self.before_state, after_state)
        if self.assert_zero_leaks and self.result["has_leaks"]:
            procs = [p.get("name") for p in self.result["survivor_processes"]]
            wins = [w.get("title") or w.get("class") for w in self.result["survivor_windows"]]
            raise AssertionError(
                f"LeakCheck Assertion Failed [{self.label}]: "
                f"Surviving processes: {procs}, Surviving windows: {wins}"
            )


def format_leak_report(result: Dict[str, Any]) -> str:
    """Formats comparison results into a readable summary."""
    lines = [
        "=" * 80,
        "GOKU PROCESS & WINDOW LEAK CHECK REPORT",
        "=" * 80,
        f"Survivor Processes : {result['survivor_process_count']}",
        f"Survivor Windows   : {result['survivor_window_count']}",
        f"Verdict            : {'LEAK DETECTED' if result['has_leaks'] else 'CLEAN (NO LEAKS)'}",
        "-" * 80,
    ]
    if result["survivor_processes"]:
        lines.append("SURVIVING PROCESSES:")
        for p in result["survivor_processes"]:
            lines.append(f" - PID {p.get('pid')}: {p.get('name')} (cmdline: {' '.join(p.get('cmdline', []))})")
    if result["survivor_windows"]:
        lines.append("SURVIVING WINDOWS:")
        for w in result["survivor_windows"]:
            lines.append(f" - HWND {w.get('hwnd')}: class='{w.get('class')}' title='{w.get('title')}' (PID {w.get('pid')})")
    lines.append("=" * 80)
    return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser(description="GOKU Process & Window Leak Checker")
    parser.add_argument("--start", action="store_true", help="Capture baseline state before run")
    parser.add_argument("--check", action="store_true", help="Compare current state against baseline")
    parser.add_argument("--state-file", type=str, default=str(DEFAULT_STATE_FILE), help="State file path")
    parser.add_argument("--save-report", type=str, help="Save report JSON to file")
    args = parser.parse_args()

    state_file = Path(args.state_file)

    if args.start:
        state = capture_full_leak_state()
        with open(state_file, "w", encoding="utf-8") as f:
            json.dump(state, f, indent=2)
        print(f"[OK] Baseline snapshot saved to: {state_file}")
        print(f"     Processes indexed: {len(state['processes'])}")
        print(f"     Windows indexed  : {len(state['windows'])}")
        return 0

    if args.check:
        if not state_file.exists():
            print(f"[ERROR] Baseline state file not found: {state_file}. Run with --start first.")
            return 1

        with open(state_file, "r", encoding="utf-8") as f:
            before_state = json.load(f)

        after_state = capture_full_leak_state()
        result = compare_leak_states(before_state, after_state)
        report_text = format_leak_report(result)
        print(report_text)

        if args.save_report:
            out_p = Path(args.save_report)
            out_p.parent.mkdir(parents=True, exist_ok=True)
            with open(out_p, "w", encoding="utf-8") as f:
                json.dump(result, f, indent=2)
            print(f"[INFO] Report saved to: {out_p}")

        return 1 if result["has_leaks"] else 0

    parser.print_help()
    return 0


if __name__ == "__main__":
    sys.exit(main())
