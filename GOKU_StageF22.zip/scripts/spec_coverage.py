"""Validate docs/spec_coverage.json against the repository and render docs/SPEC_COVERAGE.md.
A row whose status is 'done' must name at least one existing file and at least one existing test; every cited file/test must exist.
Usage: python scripts/spec_coverage.py [--check]"""
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def validate(data):
    problems = []
    for row in data["items"] + data["extra"]:
        name = row["item"]
        for f in row.get("files", []):
            if not (ROOT / f).exists():
                problems.append(f"{name}: missing file {f}")
        for t in row.get("tests", []):
            path, _, fn = t.partition("::")
            p = ROOT / path
            if not p.exists():
                problems.append(f"{name}: missing test file {path}")
            elif fn and not re.search(r"def %s\w*\(" % re.escape(fn), p.read_text(encoding="utf-8", errors="replace")):
                problems.append(f"{name}: test {fn} not found in {path}")
        if row["status"] == "done" and (not row.get("files") or not row.get("tests")):
            problems.append(f"{name}: 'done' needs files and tests as evidence")
    return problems


def render(data):
    rows = data["items"]
    counts = {}
    for r in rows:
        counts[r["status"]] = counts.get(r["status"], 0) + 1
    out = ["# GOKU spec coverage (section 15 checklist)", "",
           f"{len(rows)} items: " + ", ".join(f"{k} {v}" for k, v in sorted(counts.items())), "",
           "done = implemented and covered by an automated test; partial = works but narrower than the spec; windows_unverified = built, needs a run on the real laptop; missing = not built.", "",
           "| Group | Item | Status | Evidence / note |", "|---|---|---|---|"]
    for r in rows + [dict(x, group=x["section"]) for x in data["extra"]]:
        ev = ", ".join(r.get("files", [])[:2]) or "-"
        out.append(f"| {r['group']} | {r['item']} | {r['status']} | {ev}{' - ' + r['note'] if r.get('note') else ''} |")
    return "\n".join(out) + "\n"


if __name__ == "__main__":
    data = json.loads((ROOT / "docs" / "spec_coverage.json").read_text(encoding="utf-8"))
    probs = validate(data)
    for p in probs:
        print("PROBLEM:", p)
    if "--check" not in sys.argv:
        (ROOT / "docs" / "SPEC_COVERAGE.md").write_text(render(data), encoding="utf-8")
    print("coverage problems:", len(probs))
    sys.exit(1 if probs else 0)
