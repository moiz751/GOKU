"""
scripts/list_test_origin_records.py - Read-Only Scanner for Test-Origin Records
Follows GOKU RULES v2 + v3 Prompt A3 Step 4.
Scans:
- memory/experience_store.json (remedies, failure_records, lie_records, step_contract_records)
- memory/user_lexicon.json (corrections, aliases)
- execution_traces.jsonl
For test artifacts matching:
- tool name matching r"_\\d{10,}$"
- commands/arguments created during test runs (e.g. fake_ui_click, testpad, calculator foran chalao, etc.)
- records marked sandbox or test
READ-ONLY: Does NOT delete anything. Prints counts and 10 examples per file.
"""
from __future__ import annotations

import json
from pathlib import Path
import re
from typing import Any

TEST_TOOL_PATTERN = re.compile(r"_\d{10,}$")
TEST_KW_PATTERN = re.compile(r"(?:testpad|fake_ui_click|calculator foran chalao \d+|wipe all records \d+|test_|sandbox|pytest)", re.IGNORECASE)


def is_test_origin(tool: str, cmd: str = "", args: Any = None) -> bool:
    if TEST_TOOL_PATTERN.search(tool or ""):
        return True
    if TEST_KW_PATTERN.search(tool or "") or TEST_KW_PATTERN.search(cmd or ""):
        return True
    args_str = str(args or "")
    if TEST_TOOL_PATTERN.search(args_str) or TEST_KW_PATTERN.search(args_str):
        return True
    return False


def scan_experience_store(store_path: Path):
    if not store_path.exists():
        print(f"File not found: {store_path}")
        return

    with open(store_path, "r", encoding="utf-8") as f:
        data = json.load(f)

    test_remedies = []
    for k, v in data.get("remedies", {}).items():
        tool = v.get("tool", "")
        if is_test_origin(tool, k, v.get("remedy_args")):
            test_remedies.append((k, v))

    test_failures = []
    for f_rec in data.get("failure_records", []):
        tool = f_rec.get("tool", "")
        cmd = f_rec.get("error", "")
        if is_test_origin(tool, cmd, f_rec.get("app")):
            test_failures.append(f_rec)

    test_lies = []
    for l_rec in data.get("lie_records", []):
        tool = l_rec.get("tool", "")
        cmd = l_rec.get("command", "")
        if is_test_origin(tool, cmd, l_rec.get("args")):
            test_lies.append(l_rec)

    test_contracts = []
    for s_rec in data.get("step_contract_records", []):
        tool = s_rec.get("tool", "")
        params = str(s_rec.get("parameters", ""))
        if is_test_origin(tool, params, s_rec.get("evidence_summary")):
            test_contracts.append(s_rec)

    total_test_in_store = len(test_remedies) + len(test_failures) + len(test_lies) + len(test_contracts)
    print("=" * 80)
    print(f"EXPERIENCE STORE AUDIT: {store_path}")
    print(f"Total Identified Test-Origin Records: {total_test_in_store}")
    print(f"  - Test Remedies          : {len(test_remedies)} / {len(data.get('remedies', {}))}")
    print(f"  - Test Failure Records   : {len(test_failures)} / {len(data.get('failure_records', []))}")
    print(f"  - Test Lie Records       : {len(test_lies)} / {len(data.get('lie_records', []))}")
    print(f"  - Test Contract Records  : {len(test_contracts)} / {len(data.get('step_contract_records', []))}")
    print("-" * 80)
    print("10 EXAMPLES FROM EXPERIENCE STORE:")
    examples = (
        [(f"Remedy: {k}", v) for k, v in test_remedies[:3]] +
        [(f"Failure: {f.get('tool')}", f) for f in test_failures[:3]] +
        [(f"Lie: {l.get('tool')}", l) for l in test_lies[:2]] +
        [(f"Contract: {c.get('tool')}", c) for c in test_contracts[:2]]
    )
    for idx, (lbl, obj) in enumerate(examples[:10], 1):
        print(f"  {idx:>2}. [{lbl}] -> {str(obj)[:120]}")


def scan_user_lexicon(lex_path: Path):
    if not lex_path.exists():
        print(f"File not found: {lex_path}")
        return

    with open(lex_path, "r", encoding="utf-8") as f:
        data = json.load(f)

    test_corrections = []
    for c in data.get("corrections", []):
        cmd = c.get("command", "")
        tool = c.get("corrected_tool", "") or c.get("original_action", "")
        if is_test_origin(tool, cmd, c.get("corrected_args")):
            test_corrections.append(c)

    test_aliases = []
    for cmd, info in data.get("aliases", {}).items():
        tool = info.get("tool", "")
        if is_test_origin(tool, cmd, info.get("args")):
            test_aliases.append((cmd, info))

    print("=" * 80)
    print(f"USER LEXICON AUDIT: {lex_path}")
    print(f"Total Test-Origin Entries: {len(test_corrections) + len(test_aliases)}")
    print(f"  - Test Corrections : {len(test_corrections)} / {len(data.get('corrections', []))}")
    print(f"  - Test Aliases     : {len(test_aliases)} / {len(data.get('aliases', {}))}")
    print("-" * 80)
    print("10 EXAMPLES FROM USER LEXICON:")
    all_lex_examples = (
        [(f"Correction: '{c.get('command')}'", c) for c in test_corrections[:5]] +
        [(f"Alias: '{cmd}'", info) for cmd, info in test_aliases[:5]]
    )
    for idx, (lbl, obj) in enumerate(all_lex_examples[:10], 1):
        print(f"  {idx:>2}. [{lbl}] -> {str(obj)[:120]}")


def scan_execution_traces(traces_path: Path):
    if not traces_path.exists():
        print(f"File not found: {traces_path}")
        return

    test_traces = []
    total_traces = 0
    with open(traces_path, "r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            total_traces += 1
            try:
                row = json.loads(line)
                cmd = row.get("user_command", "") or row.get("raw_input", "") or row.get("command", "")
                tools = str(row.get("tools_executed", "") or row.get("tool", ""))
                if is_test_origin(tools, cmd, row):
                    test_traces.append(row)
            except Exception:
                pass

    print("=" * 80)
    print(f"EXECUTION TRACES AUDIT: {traces_path}")
    print(f"Total Test-Origin Traces: {len(test_traces)} / {total_traces}")
    print("-" * 80)
    print("10 EXAMPLES FROM EXECUTION TRACES:")
    for idx, t in enumerate(test_traces[:10], 1):
        cmd = t.get("user_command") or t.get("raw_input") or t.get("command") or "trace"
        tools = t.get("tools_executed") or t.get("tool")
        print(f"  {idx:>2}. Cmd: '{str(cmd)[:60]}' | Tools: {tools}")
    print("=" * 80)


if __name__ == "__main__":
    scan_experience_store(Path("memory/experience_store.json"))
    scan_user_lexicon(Path("memory/user_lexicon.json"))
    scan_execution_traces(Path("execution_traces.jsonl"))
