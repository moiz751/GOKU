"""
scripts/show_changed_files.py - Repository Diff & Change Auditor
Follows GOKU RULES v2 + 16-26 (Rule 20: No Hand-Typed Numbers/Lists).

Compares current workspace files against MANIFEST_SHA256.json:
- Reports newly created files
- Reports modified files (with SHA256 hash change)
- Prints exact file list and line change metrics
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import sys


def compute_sha256(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while chunk := f.read(65536):
            h.update(chunk)
    return h.hexdigest()


def audit_repository_diff():
    workspace = Path(".")
    manifest_path = workspace / "MANIFEST_SHA256.json"

    if not manifest_path.exists():
        print(f"Error: Manifest {manifest_path} not found.")
        sys.exit(1)

    with open(manifest_path, "r", encoding="utf-8") as f:
        manifest = json.load(f)

    modified_files = []

    # Check manifest files for modifications
    for rel_path, entry in manifest.items():
        p = workspace / rel_path
        if not p.exists():
            continue
        # Skip dynamic logs, cache, or auto-generated scratch
        if any(rel_path.startswith(prefix) for prefix in [".git", "__pycache__", ".pytest_cache", "logs/"]):
            continue

        current_hash = compute_sha256(p)
        manifest_hash = entry.get("sha256", "")
        if current_hash != manifest_hash:
            modified_files.append({
                "path": rel_path.replace("\\", "/"),
                "manifest_sha256": manifest_hash[:10],
                "current_sha256": current_hash[:10],
                "size_bytes": p.stat().st_size,
            })

    print("=" * 80)
    print("GOKU REPOSITORY DIFF AUDIT (AUTOMATED)")
    print("=" * 80)
    print(f"Total files registered in manifest: {len(manifest)}")
    print(f"Modified tracked files: {len(modified_files)}")
    print("-" * 80)
    print(f"| {'Modified File Path':<45} | {'Manifest':<10} | {'Current':<10} | {'Size':<8} |")
    print(f"| {'-'*45} | {'-'*10} | {'-'*10} | {'-'*8} |")
    for mf in sorted(modified_files, key=lambda x: x["path"]):
        print(f"| {mf['path']:<45} | {mf['manifest_sha256']:<10} | {mf['current_sha256']:<10} | {mf['size_bytes']:<8} |")
    print("=" * 80)


if __name__ == "__main__":
    audit_repository_diff()
