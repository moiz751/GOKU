"""Stage F22: ADD repositories to data/engine_repos.json without rebuilding it (nothing existing is dropped or overwritten).
Usage: python scripts/engine_inventory_merge.py <list.txt> [--live <file with 'owner/repo <sha12>' lines>]...
  * new repos are classified by brain/engines/repo_catalog.classify; repos already present (same canonical name, aliases applied) are kept untouched except for their liveness fields;
  * --live files come from `git ls-remote https://github.com/<owner>/<repo> HEAD` (a 12-hex sha = reachable). Reachable -> url_checked true; otherwise url_checked false + url_unreachable true.
  Licences are still NOT verified."""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from scripts.engine_inventory import build  # noqa: E402

DATA = ROOT / "data" / "engine_repos.json"


def read_live(paths) -> dict:
    live = {}
    for p in paths:
        for ln in Path(p).read_text(encoding="utf-8", errors="replace").splitlines():
            parts = ln.split()
            if len(parts) >= 2:
                live[parts[0].lower()] = parts[1] if re.fullmatch(r"[0-9a-f]{12}", parts[1]) else ""
    return live


def merge(existing: dict, new_list: str, live: dict) -> dict:
    new = build([new_list])
    have = {r["canonical"]: r for r in existing["repos"]}
    added = []
    for r in new["repos"]:
        if r["canonical"] in have:
            for la in r["listed_as"]:
                if la not in have[r["canonical"]]["listed_as"]:
                    have[r["canonical"]]["listed_as"].append(la)
            for c in r["categories"]:
                if c not in have[r["canonical"]]["categories"]:
                    have[r["canonical"]]["categories"].append(c)
            continue
        existing["repos"].append(r)
        have[r["canonical"]] = r
        added.append(r["canonical"])
    for r in existing["repos"]:
        keys = [r["canonical"]] + [x.lower() for x in r.get("listed_as", [])]
        k = next((x for x in keys if x in live), None)
        if k is not None:
            sha = live[k]
            r["url_checked"] = bool(sha)
            r["head_sha_prefix"] = sha or None
            if not sha:
                r["url_unreachable"] = True
            else:
                r.pop("url_unreachable", None)
    existing["repos"].sort(key=lambda r: r["slug"].lower())
    by: dict = {}
    for r in existing["repos"]:
        by[r["decision"]] = by.get(r["decision"], 0) + 1
    existing["by_decision"] = by
    existing["unique_repos"] = len(existing["repos"])
    existing["url_occurrences"] = existing.get("url_occurrences", 0) + new["url_occurrences"]
    existing["duplicates_merged"] = existing["url_occurrences"] - existing["unique_repos"]
    existing["liveness_note"] = "url_checked = git ls-remote returned a HEAD (repo reachable anonymously); false = not reachable that way (renamed, private or wrong name). Licences NOT verified."
    existing["_added_in_F22"] = added
    return existing


if __name__ == "__main__":
    args = sys.argv[1:]
    if not args:
        sys.exit(__doc__)
    live_files = [args[i + 1] for i, a in enumerate(args) if a == "--live"]
    lst = args[0]
    out = merge(json.loads(DATA.read_text(encoding="utf-8")), lst, read_live(live_files))
    DATA.write_text(json.dumps(out, indent=1, ensure_ascii=False), encoding="utf-8")
    print({"unique_repos": out["unique_repos"], "added": len(out["_added_in_F22"]), "by_decision": out["by_decision"]})
