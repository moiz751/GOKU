"""Measures real Ollama memory/speed for ctx x batch x flash x kv-cache variants (RAM techniques #2, #6, #7, #8, #11). Run on the laptop:
    python scripts/model_bench.py [--model qwen2.5:0.5b] [--quick]
It starts its OWN `ollama serve` on port 11500 (your normal Ollama is untouched), tries each variant, reads the runner's RSS, and writes logs/model_bench.json.
tools/resource_strategy.py then prefers these measured rows over estimates. Needs the model already pulled; never downloads anything."""
from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
PORT = 11500
VARIANTS = [  # (ctx, batch, flash, kv, mmap)
    (1024, 64, False, "f16", True), (1024, 512, False, "f16", True), (1536, 64, False, "f16", True), (2048, 64, False, "f16", True),
    (1024, 64, True, "f16", True), (1024, 64, True, "q8_0", True), (1024, 64, True, "q4_0", True), (1024, 64, False, "f16", False),
]


def _rss_mb(pid_root: int) -> float:
    try:
        import psutil
        p = psutil.Process(pid_root)
        return sum(c.memory_info().rss for c in [p] + p.children(recursive=True)) / 1048576.0
    except Exception:
        return 0.0


def _post(path: str, body: dict, timeout: float = 120.0) -> dict:
    req = urllib.request.Request(f"http://127.0.0.1:{PORT}{path}", data=json.dumps(body).encode(), headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode())


def _exe() -> str:
    from brain.ollama_manager import find_ollama_executable
    return find_ollama_executable() or ""


def run_variant(model: str, exe: str, v: tuple) -> dict:
    ctx, batch, flash, kv, mm = v
    env = dict(os.environ, OLLAMA_HOST=f"127.0.0.1:{PORT}", OLLAMA_NUM_PARALLEL="1", OLLAMA_MAX_LOADED_MODELS="1", OLLAMA_FLASH_ATTENTION="1" if flash else "0", OLLAMA_KV_CACHE_TYPE=kv)
    row = {"model": model, "ctx": ctx, "batch": batch, "flash": flash, "kv": kv, "mmap": mm, "ok": False}
    proc = subprocess.Popen([exe, "serve"], env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    try:
        for _ in range(40):
            try:
                urllib.request.urlopen(f"http://127.0.0.1:{PORT}/api/version", timeout=1)
                break
            except Exception:
                time.sleep(0.5)
        t0 = time.time()
        r = _post("/api/generate", {"model": model, "prompt": "Write one sentence about the sea.", "stream": False, "keep_alive": "5m",
                                    "options": {"num_ctx": ctx, "num_batch": batch, "num_predict": 48, "use_mmap": mm, "use_mlock": False}})
        dt = time.time() - t0
        row.update(ok=bool(r.get("response", "").strip()), seconds=round(dt, 2), tokens_per_s=round(r.get("eval_count", 0) / max(r.get("eval_duration", 1) / 1e9, 1e-6), 1), rss_mb=round(_rss_mb(proc.pid), 1))
    except Exception as exc:
        row["error"] = f"{type(exc).__name__}: {exc}"[:200]
    finally:
        proc.terminate()
        try:
            proc.wait(10)
        except Exception:
            proc.kill()
    return row


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", default="qwen2.5:0.5b")
    ap.add_argument("--quick", action="store_true")
    a = ap.parse_args()
    exe = _exe()
    if not exe:
        print("Ollama executable not found; nothing measured.")
        return 2
    rows = [run_variant(a.model, exe, v) for v in (VARIANTS[:2] if a.quick else VARIANTS)]
    out = ROOT / "logs" / "model_bench.json"
    out.parent.mkdir(exist_ok=True)
    out.write_text(json.dumps({"measured_at": time.strftime("%Y-%m-%d %H:%M:%S"), "rows": rows}, indent=2), encoding="utf-8")
    for r in rows:
        print(r)
    print("saved", out)
    return 0


if __name__ == "__main__":
    sys.exit(main())
