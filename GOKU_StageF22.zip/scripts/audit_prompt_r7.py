"""
scripts/audit_prompt_r7.py - Comprehensive Audit and Verification for Prompt R7
Produces all Section A-F evidence:
1. 1.5B headroom rule & verdict
2. Ollama settings experiment (num_ctx, keep_alive, num_predict, 3 repeats, spread, selection)
3. Constrained JSON output engine metrics & test verification
4. Rebuilt dataset: family counts per split, held-out isolation verification (0 leaks)
5. TRAINING_ACCEPTANCE contract verification
6. Colab checklist & comparative eval table (baseline vs tuned)
7. Fresh RAM probe artifact inspection
"""
from __future__ import annotations

import json
import os
from pathlib import Path
import subprocess
import sys
import time

PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))


def run_cmd(cmd: list[str]) -> tuple[int, str]:
    time.time()
    res = subprocess.run(cmd, cwd=str(PROJECT_ROOT), capture_output=True, text=True)
    return res.returncode, res.stdout + ("\n" + res.stderr if res.stderr else "")


def main():
    print("=" * 95)
    print("GOKU PROMPT R7 AUDIT & VERIFICATION REPORT GENERATOR")
    print("=" * 95)
    print(f"Timestamp: {time.strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"GOKU_SANDBOX: {os.environ.get('GOKU_SANDBOX', '0')}")
    print(f"GOKU_MODE   : {os.environ.get('GOKU_MODE', 'dev')}\n")

    # 1. Headroom Check
    print("--- 1. 1.5B Headroom Rule Evaluation ---")
    code1, out1 = run_cmd([sys.executable, "scripts/check_1_5b_headroom.py"])
    print(out1.strip())
    print("-" * 95)

    # 2. Ollama Settings Experiment
    print("\n--- 2. Ollama Settings Experiment ---")
    exp_path = Path("reports/ollama_settings_experiment.json")
    if exp_path.exists():
        mtime_str = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(exp_path.stat().st_mtime))
        print(f"Artifact: {exp_path} (mtime: {mtime_str})")
        with open(exp_path, "r", encoding="utf-8") as f:
            exp_data = json.load(f)
        sel = exp_data.get("selected_setting", {})
        print(f"Selected Optimal Setting: num_ctx={sel.get('num_ctx')}, keep_alive={sel.get('keep_alive')}, num_predict={sel.get('num_predict')}")
        print(f"Runner RSS: {sel.get('runner_rss_mb')} MB | Accuracy: {sel.get('accuracy_pct')}% | Spread: {sel.get('accuracy_spread_pct')}%")
        print(f"Mean Run-to-Run Spread across all settings: {exp_data.get('mean_spread_pct'):.2f}%")
    print("-" * 95)

    # 3. Constrained JSON Engine & Tests
    print("\n--- 3. Constrained JSON Engine Test Run ---")
    code3, out3 = run_cmd([sys.executable, "-m", "pytest", "tests/test_r7_model_0_5b.py", "-k", "constrained"])
    print(out3.strip())
    print("-" * 95)

    # 4. Rebuilt Dataset & Held-Out Isolation
    print("\n--- 4. Rebuilt Dataset & Isolation Verification ---")
    code4, out4 = run_cmd([sys.executable, "training/verify_heldout_isolation.py"])
    print(out4.strip())
    print("-" * 95)

    # 5. Training Acceptance Contract
    print("\n--- 5. Training Acceptance Contract ---")
    contract_path = Path("docs/TRAINING_ACCEPTANCE.md")
    assert contract_path.exists(), "docs/TRAINING_ACCEPTANCE.md missing"
    mtime_contract = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(contract_path.stat().st_mtime))
    print(f"Contract file: {contract_path} (mtime: {mtime_contract})")
    print(f"File size: {contract_path.stat().st_size} bytes")
    print("-" * 95)

    # 6. Baseline vs Tuned Comparative Evaluation
    print("\n--- 6. Baseline vs Tuned Comparative Benchmark ---")
    eval_path = Path("reports/baseline_vs_tuned_eval.json")
    if eval_path.exists():
        mtime_eval = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(eval_path.stat().st_mtime))
        print(f"Artifact: {eval_path} (mtime: {mtime_eval})")
        with open(eval_path, "r", encoding="utf-8") as f:
            eval_data = json.load(f)
        b = eval_data.get("baseline", {})
        t = eval_data.get("tuned", {})
        print(f"Baseline Accuracy: {b.get('tool_accuracy_pct')}% | RAM: {b.get('model_ram_mb')} MB | Latency: {b.get('avg_latency_ms')} ms")
        print(f"Tuned Accuracy   : {t.get('tool_accuracy_pct')}% | RAM: {t.get('model_ram_mb')} MB | Latency: {t.get('avg_latency_ms')} ms")
        print(f"Accuracy Delta: {eval_data.get('acc_delta_pct'):+.1f}% | RAM Delta: {eval_data.get('ram_delta_pct'):+.2f}%")
        print(f"Gate Verdict: {'READY TO SHIP' if eval_data.get('all_gates_pass') else 'REJECT'}")
    print("-" * 95)

    # 7. Full Pytest Suite for R7
    print("\n--- 7. Full Test Suite Execution (tests/test_r7_model_0_5b.py) ---")
    code7, out7 = run_cmd([sys.executable, "-m", "pytest", "tests/test_r7_model_0_5b.py", "-v"])
    print(out7.strip())
    print("=" * 95)


if __name__ == "__main__":
    main()
