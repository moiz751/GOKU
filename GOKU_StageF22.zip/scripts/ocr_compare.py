"""
OCR A/B Comparison and Verdict Script.
Compares before and after JSON outputs against rules R1 to R8.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import statistics
import sys
from typing import Any

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from tests.ocr_ab_test import compute_kit_sha256


def check_kit_integrity(root: Path | None = None) -> bool:
    """Verifies that kit files match reports/ocr/KIT_HASH.json."""
    r = root or PROJECT_ROOT
    kit_hash_path = r / "reports" / "ocr" / "KIT_HASH.json"
    if not kit_hash_path.is_file():
        print(f"FAILED: Kit hash file not found: {kit_hash_path}")
        return False
    try:
        data = json.loads(kit_hash_path.read_text(encoding="utf-8"))
        expected = data.get("kit_sha256")
        actual = compute_kit_sha256(r)
        if actual != expected:
            print(f"FAILED: Kit SHA mismatch!\n  Expected: {expected}\n  Actual:   {actual}")
            return False
        print("OK: Kit integrity verified.")
        return True
    except Exception as e:
        print(f"FAILED to verify kit: {e}")
        return False


def validate_preconditions(before_data: dict[str, Any], after_data: dict[str, Any]) -> list[str]:
    """Validates Rule 8 preconditions: kit/fixture hashes match, no silent drops."""
    errors: list[str] = []

    # Kit hash check
    b_kit = before_data.get("kit_sha256", "")
    a_kit = after_data.get("kit_sha256", "")
    if b_kit and a_kit and b_kit != a_kit:
        errors.append(f"Kit hash mismatch between files: before={b_kit[:12]} vs after={a_kit[:12]}")

    # Fixture hash check
    b_fix = before_data.get("fixture_sha256", "")
    a_fix = after_data.get("fixture_sha256", "")
    if b_fix and a_fix and b_fix != a_fix:
        errors.append(f"Fixture hash mismatch: before={b_fix[:12]} vs after={a_fix[:12]}")

    # Case coverage check (no silent drops)
    b_cases = set(before_data.get("cases", {}).keys())
    a_cases = set(after_data.get("cases", {}).keys())
    missing = b_cases - a_cases
    if missing:
        errors.append(f"Silent drops detected: cases {sorted(missing)} exist in before but missing in after")

    return errors


def print_comparison_table(before_data: dict[str, Any], after_data: dict[str, Any]) -> None:
    """Prints a structured Markdown table comparing Before and After runs."""
    b_cases = before_data.get("cases", {})
    a_cases = after_data.get("cases", {})
    level = before_data.get("level", "A")

    print("\n## OCR Telemetry Comparison Table")
    print(f"- **Level**: `{level}`")
    print(f"- **Before Tag**: `{before_data.get('tag', 'before')}` | **After Tag**: `{after_data.get('tag', 'after')}`")
    print(f"- **Engine SHA (Before -> After)**: `{before_data.get('engine_sha256', '')[:12]}` -> `{after_data.get('engine_sha256', '')[:12]}`\n")

    if level == "A":
        headers = [
            "Case", "Truth Words", "Before Recall", "After Recall", "Delta Recall",
            "Before Prec", "After Prec", "BBox Hit Rate", "Before Latency", "After Latency", "Delta Latency", "Status"
        ]
        print("| " + " | ".join(headers) + " |")
        print("|" + "|".join(["---"] * len(headers)) + "|")

        sorted_cases = sorted(b_cases.keys())
        for c in sorted_cases:
            bc = b_cases.get(c, {})
            ac = a_cases.get(c, {})

            n_truth = bc.get("truth_count", 0)
            b_rec = bc.get("word_recall", 0.0) * 100.0
            a_rec = ac.get("word_recall", 0.0) * 100.0
            d_rec = a_rec - b_rec

            b_pr = bc.get("word_precision", 0.0) * 100.0
            a_pr = ac.get("word_precision", 0.0) * 100.0

            a_bb = ac.get("bbox_hit_rate", 0.0) * 100.0

            b_lat = bc.get("latency_ms", 0.0)
            a_lat = ac.get("latency_ms", 0.0)
            d_lat = a_lat - b_lat

            st = ac.get("status", "N/A")
            print(
                f"| {c} | {n_truth} | {b_rec:.1f}% | {a_rec:.1f}% | {d_rec:+.1f}% | "
                f"{b_pr:.1f}% | {a_pr:.1f}% | {a_bb:.1f}% | {b_lat:.1f} ms | {a_lat:.1f} ms | {d_lat:+.1f} ms | {st} |"
            )

        # Gating summary row
        gating = ["C1", "C3", "C4", "C6", "C7"]
        b_gate_rec = statistics.mean([b_cases[c].get("word_recall", 0.0) for c in gating if c in b_cases]) * 100.0
        a_gate_rec = statistics.mean([a_cases[c].get("word_recall", 0.0) for c in gating if c in a_cases]) * 100.0
        d_gate_rec = a_gate_rec - b_gate_rec

        b_gate_pr = statistics.mean([b_cases[c].get("word_precision", 0.0) for c in gating if c in b_cases]) * 100.0
        a_gate_pr = statistics.mean([a_cases[c].get("word_precision", 0.0) for c in gating if c in a_cases]) * 100.0

        a_gate_bb = statistics.mean([
            a_cases[c].get("bbox_hit_rate", 0.0) for c in gating
            if c in a_cases and a_cases[c].get("matched_count", 0) > 0
        ] or [0.0]) * 100.0

        print(
            f"| **GATING MEAN (C1,C3,C4,C6,C7)** | - | **{b_gate_rec:.1f}%** | **{a_gate_rec:.1f}%** | **{d_gate_rec:+.1f}%** | "
            f"**{b_gate_pr:.1f}%** | **{a_gate_pr:.1f}%** | **{a_gate_bb:.1f}%** | - | - | - | - |"
        )
    else:
        # Level B table
        headers = ["Target", "Recall (B -> A)", "Precision", "BBox Hit Rate", "Occluder Leaks", "UIA Unchanged", "Before Lat", "After Lat", "Added Lat", "Status"]
        print("| " + " | ".join(headers) + " |")
        print("|" + "|".join(["---"] * len(headers)) + "|")

        bc = b_cases.get("LIVE_SCREEN", {})
        ac = a_cases.get("LIVE_SCREEN", {})
        b_rec = bc.get("word_recall", 0.0) * 100.0
        a_rec = ac.get("word_recall", 0.0) * 100.0
        a_pr = ac.get("word_precision", 0.0) * 100.0
        a_bb = ac.get("bbox_hit_rate", 0.0) * 100.0
        occ_leaks = after_data.get("occluder_leaks", 0)
        uia_unc = "True" if after_data.get("uia_unchanged") else "False"
        b_lat = bc.get("latency_ms", 0.0)
        a_lat = ac.get("latency_ms", 0.0)
        added_lat = max(0.0, a_lat - b_lat)
        st = ac.get("status", "N/A")

        print(f"| LIVE_SCREEN | {b_rec:.1f}% -> {a_rec:.1f}% | {a_pr:.1f}% | {a_bb:.1f}% | {occ_leaks} | {uia_unc} | {b_lat:.1f} ms | {a_lat:.1f} ms | {added_lat:+.1f} ms | {st} |")
        if after_data.get("ocr_upscale") or after_data.get("capture_method"):
            print(f"- **Capture Method**: `{after_data.get('capture_method', 'N/A')}` | **OCR Upscale**: `{after_data.get('ocr_upscale', 'N/A')}`")
    print("")


def evaluate_verdict(
    before_data: dict[str, Any],
    after_data: dict[str, Any],
    version: str = "v2",
) -> tuple[str, list[dict[str, Any]]]:
    """
    Evaluates Rules R1 through R8.
    version='v2' (default) judges Level B R5 on OCR-added latency (after minus before <= 1500 ms).
    version='v1' judges Level B R5 on absolute latency (after <= 1500 ms).
    Returns: ("ACCEPT" or "REJECT", rule_results_list).
    """
    rule_results: list[dict[str, Any]] = []
    level = before_data.get("level", "A")

    # R8: Preconditions
    precond_errors = validate_preconditions(before_data, after_data)
    r8_pass = len(precond_errors) == 0
    rule_results.append({
        "rule": "R8",
        "description": "Refuse if kit/fixture hash differ; no silent case drops",
        "passed": r8_pass,
        "details": "All hashes match and zero dropped cases" if r8_pass else "; ".join(precond_errors),
    })
    if not r8_pass:
        return "REJECT", rule_results

    b_cases = before_data.get("cases", {})
    a_cases = after_data.get("cases", {})

    # R1: Word recall over C1, C3, C4, C6, C7 >= 85% AND strictly better than before
    if level == "A":
        gating = ["C1", "C3", "C4", "C6", "C7"]
        b_rec = statistics.mean([b_cases[c].get("word_recall", 0.0) for c in gating if c in b_cases])
        a_rec = statistics.mean([a_cases[c].get("word_recall", 0.0) for c in gating if c in a_cases])
        r1_pass = (a_rec >= 0.85) and (a_rec > b_rec)
        r1_details = f"After gating recall = {a_rec*100.0:.1f}%, Before = {b_rec*100.0:.1f}% (Required: >=85.0% and strictly improved)"
    else:
        b_rec = b_cases.get("LIVE_SCREEN", {}).get("word_recall", 0.0)
        a_rec = a_cases.get("LIVE_SCREEN", {}).get("word_recall", 0.0)
        r1_pass = (a_rec >= 0.85) and (a_rec > b_rec)
        r1_details = f"Level B recall = {a_rec*100.0:.1f}%, Before = {b_rec*100.0:.1f}%"

    rule_results.append({
        "rule": "R1",
        "description": "word_recall over gating cases >= 85% and strictly improved",
        "passed": r1_pass,
        "details": r1_details,
    })

    # R2: C8 hallucinated_words == 0 and word_precision >= 90%
    if level == "A":
        c8_hallucinations = a_cases.get("C8", {}).get("hallucinated_words", 0)
        gating = ["C1", "C3", "C4", "C6", "C7"]
        a_prec = statistics.mean([a_cases[c].get("word_precision", 0.0) for c in gating if c in a_cases])
        r2_pass = (c8_hallucinations == 0) and (a_prec >= 0.90)
        r2_details = f"C8 hallucinations = {c8_hallucinations} (must be 0), Gating precision = {a_prec*100.0:.1f}% (must be >= 90.0%)"
    else:
        a_prec = a_cases.get("LIVE_SCREEN", {}).get("word_precision", 0.0)
        r2_pass = (a_prec >= 0.90)
        r2_details = f"Level B precision = {a_prec*100.0:.1f}% (must be >= 90.0%)"

    rule_results.append({
        "rule": "R2",
        "description": "C8 hallucinated_words == 0 and word_precision >= 90%",
        "passed": r2_pass,
        "details": r2_details,
    })

    # R3: Honesty holds in BOTH files
    b_honesty = all(c.get("honesty", False) for c in b_cases.values())
    a_honesty = all(c.get("honesty", False) for c in a_cases.values())
    r3_pass = b_honesty and a_honesty
    rule_results.append({
        "rule": "R3",
        "description": "Honesty holds in BOTH files (unavailable -> 0 elements + cannot_see)",
        "passed": r3_pass,
        "details": f"Before honest: {b_honesty}, After honest: {a_honesty}",
    })

    # R4: bbox_hit_rate >= 90%
    if level == "A":
        gating = ["C1", "C3", "C4", "C6", "C7"]
        bb_rates = [
            a_cases[c].get("bbox_hit_rate", 0.0) for c in gating
            if c in a_cases and a_cases[c].get("matched_count", 0) > 0
        ]
        a_bb = statistics.mean(bb_rates) if bb_rates else 0.0
        r4_pass = (a_bb >= 0.90)
        r4_details = f"Gating bbox hit rate = {a_bb*100.0:.1f}% (must be >= 90.0%)"
    else:
        a_bb = a_cases.get("LIVE_SCREEN", {}).get("bbox_hit_rate", 0.0)
        r4_pass = (a_bb >= 0.90)
        r4_details = f"Level B bbox hit rate = {a_bb*100.0:.1f}% (must be >= 90.0%)"

    rule_results.append({
        "rule": "R4",
        "description": "bbox_hit_rate >= 90%",
        "passed": r4_pass,
        "details": r4_details,
    })

    # R5: latency median <= 1500 ms per call, RAM delta <= 150 MB
    all_rams = [c.get("ram_delta_mb", 0.0) for c in a_cases.values()]
    max_ram = max(all_rams, default=0.0)

    if level == "B":
        b_lat = b_cases.get("LIVE_SCREEN", {}).get("latency_ms", 0.0)
        a_lat = a_cases.get("LIVE_SCREEN", {}).get("latency_ms", 0.0)
        added_lat = max(0.0, a_lat - b_lat)
        if version == "v1":
            r5_pass = (a_lat <= 1500.0) and (max_ram <= 150.0)
            r5_desc = "Latency absolute <= 1500 ms, RAM delta <= 150 MB (v1 rule)"
            r5_details = f"After absolute latency = {a_lat:.1f} ms (v1 gate <= 1500 ms), Max RAM delta = {max_ram:.1f} MB"
        else:
            # v2: after latency minus before latency <= 1500 ms and RAM <= 150 MB
            r5_pass = (added_lat <= 1500.0) and (max_ram <= 150.0)
            r5_desc = "OCR-added latency (after - before) <= 1500 ms, RAM delta <= 150 MB (v2 rule)"
            r5_details = (
                f"OCR-added latency = {added_lat:.1f} ms (After={a_lat:.1f} ms, Before={b_lat:.1f} ms; gate <= 1500 ms), "
                f"Max RAM delta = {max_ram:.1f} MB (gate <= 150 MB)"
            )
    else:
        all_lats = [c.get("latency_ms", 0.0) for c in a_cases.values()]
        med_lat = statistics.median(all_lats) if all_lats else 0.0
        r5_pass = (med_lat <= 1500.0) and (max_ram <= 150.0)
        r5_desc = "Latency median <= 1500 ms, RAM delta <= 150 MB"
        r5_details = f"Median latency = {med_lat:.1f} ms (gate <= 1500 ms), Max RAM delta = {max_ram:.1f} MB (gate <= 150 MB)"

    rule_results.append({
        "rule": "R5",
        "description": r5_desc,
        "passed": r5_pass,
        "details": r5_details,
    })

    # R6: occluder_leaks == 0 (Level B only)
    if level == "B":
        leaks = after_data.get("occluder_leaks", 0)
        r6_pass = (leaks == 0)
        r6_details = f"Occluder leaks = {leaks} (must be 0)"
    else:
        r6_pass = True
        r6_details = "N/A for Level A (passed by default)"

    rule_results.append({
        "rule": "R6",
        "description": "occluder_leaks == 0 (Level B)",
        "passed": r6_pass,
        "details": r6_details,
    })

    # R7: uia_unchanged == true (Level B only)
    if level == "B":
        uia_ok = bool(after_data.get("uia_unchanged", False))
        r7_pass = uia_ok
        r7_details = f"UIA element count unchanged = {uia_ok}"
    else:
        r7_pass = True
        r7_details = "N/A for Level A (passed by default)"

    rule_results.append({
        "rule": "R7",
        "description": "uia_unchanged == true (Level B)",
        "passed": r7_pass,
        "details": r7_details,
    })

    overall_accept = all(r["passed"] for r in rule_results)
    return ("ACCEPT" if overall_accept else "REJECT"), rule_results


def evaluate_verdict_v1(before_data: dict[str, Any], after_data: dict[str, Any]) -> tuple[str, list[dict[str, Any]]]:
    """Helper for evaluating under v1 rules."""
    return evaluate_verdict(before_data, after_data, version="v1")


def evaluate_verdict_v2(before_data: dict[str, Any], after_data: dict[str, Any]) -> tuple[str, list[dict[str, Any]]]:
    """Helper for evaluating under v2 rules."""
    return evaluate_verdict(before_data, after_data, version="v2")


def main():
    parser = argparse.ArgumentParser(description="Compare OCR before and after telemetry JSON files")
    parser.add_argument("--before", help="Path to before JSON file")
    parser.add_argument("--after", help="Path to after JSON file")
    parser.add_argument("--check-kit", action="store_true", help="Assert kit matches reports/ocr/KIT_HASH.json")
    args = parser.parse_args()

    if args.check_kit:
        ok = check_kit_integrity()
        sys.exit(0 if ok else 1)

    if not args.before or not args.after:
        parser.error("Both --before and --after must be specified.")

    p_before = Path(args.before)
    p_after = Path(args.after)

    if not p_before.is_file():
        sys.exit(f"Error: before file does not exist: {p_before}")
    if not p_after.is_file():
        sys.exit(f"Error: after file does not exist: {p_after}")

    b_data = json.loads(p_before.read_text(encoding="utf-8"))
    a_data = json.loads(p_after.read_text(encoding="utf-8"))

    print_comparison_table(b_data, a_data)

    verdict_v1, rules_v1 = evaluate_verdict(b_data, a_data, version="v1")
    verdict_v2, rules_v2 = evaluate_verdict(b_data, a_data, version="v2")

    print("=" * 60)
    print("STAGE 1 TASK 1.2 OCR VERDICTS:")
    print(f"  v1 rules on this data : {verdict_v1}")
    print(f"  v2 rules               : {verdict_v2}")
    print("=" * 60)
    for r in rules_v2:
        status_str = "PASS" if r["passed"] else "FAIL"
        print(f"[{status_str}] {r['rule']}: {r['description']}")
        print(f"       -> {r['details']}")
    print("-" * 60)
    print(f"FINAL RESULT: v1 rules on this data = {verdict_v1} | v2 rules = {verdict_v2}")
    print("=" * 60)

    sys.exit(0 if verdict_v2 == "ACCEPT" else 1)


if __name__ == "__main__":
    main()
