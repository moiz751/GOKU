"""QA benchmark by the ten capabilities (Stage F9). Runs real questions through answer_pipeline.respond and checks the ANSWER TEXT.

  python scripts/qa_score.py [--json out.json] [--set dev|heldout|all]

Two sets: `dev` (used while building) and `heldout` (written after the implementation, not tuned to). A fake model is injected for the model-related items so
the result does not depend on Ollama; real-model quality is NOT measured here. The author of both sets is the same person who built the code, so this is a
regression and honesty benchmark, not an independent evaluation.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
os.environ["GOKU_QA_NO_MODEL"] = "1"

DIMS = ["1 Independent thinking", "2 Deep understanding", "3 Logical reasoning", "4 General knowledge", "5 Multi-step questions", "6 Follow-up understanding",
        "7 Critical thinking", "8 Problem solving", "9 Uncertainty awareness", "10 Self-correction"]


def bullets(t):
    return sum(1 for l in t.split("\n") if l.startswith("- "))


JUNK = lambda p: "According to a 2021 study at https://example.org/x the exact figure is 48213 and everything is certain."          # noqa: E731
OK_LLM = lambda p: "Zorblax is a word with no established meaning that I know of, so any definition would be a guess."            # noqa: E731
ARITH = lambda p: "The product is 12 x 12 = 124 as you can see."                                                                  # noqa: E731


def A(*needles):                       # all needles present (case-insensitive)
    return lambda t, r: all(n.lower() in t.lower() for n in needles)


def ANY(*needles):
    return lambda t, r: any(n.lower() in t.lower() for n in needles)


def NOT(*needles):
    return lambda t, r: not any(n.lower() in t.lower() for n in needles)


def AND(*fs):
    return lambda t, r: all(f(t, r) for f in fs)


# (dimension index, set, turns, check, llm)
ITEMS = [
    # 1 independent thinking: composed / reasoned answers
    (0, "dev", ["Compare Python and Java in 5 points"], AND(A("Python", "Java", "Typing"), lambda t, r: bullets(t) == 5), None),
    (0, "dev", ["SQL vs NoSQL in 4 points"], lambda t, r: bullets(t) == 4 and "SQL" in t, None),
    (0, "dev", ["All birds are animals. A sparrow is a bird. Is a sparrow an animal?"], A("Yes"), None),
    (0, "dev", ["What is the difference between a stack and a queue?"], A("LIFO", "FIFO"), None),
    (0, "heldout", ["All roses are flowers. A tulip is a flower. Is a tulip a rose?"], A("cannot be concluded"), None),
    (0, "heldout", ["Difference between SSD and HDD"], A("flash", "spinning"), None),
    (0, "heldout", ["array vs linked list"], A("O(1)", "O(n)"), None),
    # 2 deep understanding: language / format / level
    (1, "dev", ["Explain gravity in 2 points"], lambda t, r: bullets(t) == 2, None),
    (1, "dev", ["Explain DNA briefly"], lambda t, r: "\n" not in t.strip() and "double" not in t.lower(), None),
    (1, "dev", ["Explain cell in Roman Urdu"], A("zinda"), None),
    (1, "dev", ["Photosynthesis kya hai?"], ANY("paudhe", "paudhay"), None),
    (1, "heldout", ["Describe the atom in 3 points"], lambda t, r: bullets(t) == 3, None),
    (1, "heldout", ["recursion ko asaan alfaaz mein samjhao"], ANY("base case", "khud ko"), None),
    (1, "heldout", ["What is an API? Answer briefly"], lambda t, r: "\n" not in t.strip(), None),
    # 3 logical reasoning: checkable computation with steps
    (2, "dev", ["Is 17 x 3 = 51?"], A("Yes"), None),
    (2, "dev", ["2+2=5, right?"], A("No", "4"), None),
    (2, "dev", ["A bat and a ball cost $1.10 in total. The bat costs $1.00 more than the ball. How much does the ball cost?"], A("0.05"), None),
    (2, "heldout", ["Is 12 x 12 = 154?"], A("No", "144"), None),
    (2, "heldout", ["Is 100 / 4 = 25?"], A("Yes"), None),
    (2, "heldout", ["A bat and a ball cost $2.20 in total. The bat costs $2.00 more than the ball. How much does the ball cost?"], A("0.10"), None),
    # 4 general knowledge
    (3, "dev", ["Explain photosynthesis simply"], A("light", "glucose"), None),
    (3, "dev", ["Why is the sky blue?"], A("Rayleigh"), None),
    (3, "dev", ["Explain quantum computing in Roman Urdu"], A("qubit"), None),
    (3, "dev", ["What is inflation?"], A("prices"), None),
    (3, "dev", ["How do I learn programming?"], A("1.", "2."), None),
    (3, "heldout", ["Why do we have seasons?"], A("tilt"), None),
    (3, "heldout", ["What is a black hole?"], A("gravity", "light"), None),
    (3, "heldout", ["What is Git?"], A("version control"), None),
    (3, "heldout", ["Why is my computer slow?"], A("RAM"), None),
    (3, "heldout", ["How do I save money?"], ANY("budget", "expenses", "savings"), None),
    # 5 multi-step
    (4, "dev", ["What is the capital of Japan? Also explain gravity"], A("Tokyo", "gravity"), None),
    (4, "dev", ["Explain RAM and what is 15% of 200"], A("RAM", "30"), None),
    (4, "heldout", ["What is the capital of Italy? Also why is the sea salty?"], A("Rome", "salt"), None),
    (4, "heldout", ["Compare TCP and UDP and what is 12 * 12"], A("TCP", "UDP", "144"), None),
    (4, "heldout", ["Explain DNA; why is the sky blue?"], A("double", "Rayleigh"), None),
    # 6 follow-up
    (5, "dev", ["What is the capital of France?", "And what about Italy?"], A("Rome"), None),
    (5, "dev", ["What is the capital of France?", "What about Japan?"], A("Tokyo"), None),
    (5, "dev", ["Explain Python", "What about Java?"], A("Java"), None),
    (5, "dev", ["Explain Python", "What about Java?", "Compare them in 3 points"], AND(A("Typing"), lambda t, r: bullets(t) == 3), None),
    (5, "heldout", ["What is the capital of Germany?", "How about Spain?"], A("Madrid"), None),
    (5, "heldout", ["Explain TCP", "aur UDP?"], A("UDP"), None),
    (5, "heldout", ["Explain gravity", "simpler"], lambda t, r: "\n" not in t.strip() and "gravity" in t.lower(), None),
    (5, "heldout", ["Explain Python", "its speed"], A("Speed"), None),
    (5, "heldout", ["Explain DNA", "in Roman Urdu"], A("double-helix"), None),
    # 7 critical thinking
    (6, "dev", ["Why does the sun orbit the earth?"], A("Wrong premise"), None),
    (6, "dev", ["Karachi is the capital of Pakistan, right?"], A("Islamabad"), None),
    (6, "dev", ["Python is statically typed, right?"], A("not quite"), None),
    (6, "dev", ["The Great Wall of China is visible from space, right?"], ANY("not visible", "myth"), None),
    (6, "heldout", ["Why do we only use 10% of our brains?"], ANY("myth", "wrong premise"), None),
    (6, "heldout", ["UDP is reliable, right?"], A("not quite"), None),
    (6, "heldout", ["Sydney is the capital of Australia, correct?"], A("Canberra"), None),
    (6, "heldout", ["Why is the earth flat?"], A("wrong premise"), None),
    (6, "heldout", ["HTTP is encrypted, correct?"], A("not quite"), None),
    # 8 problem solving
    (7, "dev", ["If it takes 5 machines 5 minutes to make 5 widgets, how long would it take 100 machines to make 100 widgets?"], A("5 minutes"), None),
    (7, "dev", ["A lily pad doubles in size every day. It covers the whole lake in 48 days. On which day was it half the lake?"], A("47"), None),
    (7, "heldout", ["If it takes 3 machines 3 minutes to make 3 widgets, how long would it take 50 machines to make 50 widgets?"], A("3 minutes"), None),
    (7, "heldout", ["A lily pad doubles in size every day. It covers the whole lake in 30 days. On which day was it half the lake?"], A("29"), None),
    (7, "heldout", ["How many animals of each kind did Moses take on the ark?"], A("Noah"), None),
    # 9 uncertainty
    (8, "dev", ["What is the meaning of life?"], AND(ANY("do not have a verified", "verified answer"), NOT("42")), None),
    (8, "dev", ["What is Zorblax?"], ANY("do not have a verified", "verified answer"), None),
    (8, "dev", ["What is Zorblax?"], AND(NOT("48213", "example.org"), ANY("do not have a verified", "did not pass")), JUNK),
    (8, "heldout", ["What is the population of the planet Zorblax?"], ANY("do not have a verified"), None),
    (8, "heldout", ["How many grains of sand are on Earth exactly?"], AND(NOT("48213"), ANY("do not have a verified", "did not pass", "needs", "internet")), JUNK),
    (8, "heldout", ["Explain flurbology"], lambda t, r: r.get("label") in ("unknown", "likely") and "unverified" in (t + str(r.get("display", ""))).lower() or r.get("label") == "unknown", OK_LLM),
    # 10 self-correction
    (9, "dev", ["Explain Python in 9 points"], lambda t, r: "only" in r.get("display", "").lower() and "not pad" in r.get("display", "").lower(), None),
    (9, "dev", ["What is the product of the numbers in the Zorblax riddle?"], A("= 144"), ARITH),
    (9, "heldout", ["Explain gravity in 12 points"], lambda t, r: "do not pad" in r.get("display", "").lower(), None),
    (9, "heldout", ["Tell me the sum of the Frobnitz values"], A("= 15"), lambda p: "Result: 7 + 8 = 16."),
]


def run(which: str = "all") -> dict:
    from brain import answer_pipeline
    from brain.dialog_state import DialogState
    rows = []
    for dim, sset, turns, check, llm in ITEMS:
        if which != "all" and sset != which:
            continue
        st = DialogState(tempfile.mktemp(suffix=".json"))
        res, err = None, None
        try:
            for q in turns:
                res = answer_pipeline.respond(q, state=st, record=True, llm=llm)
            text = res["text"]
            ok = bool(check(text, res))
        except Exception as e:                                          # an exception is a failure, never a pass
            ok, text, err = False, "", repr(e)
        rows.append({"dim": DIMS[dim], "set": sset, "turns": turns, "ok": ok, "text": (text or "")[:300], "label": (res or {}).get("label"), "error": err})
    out = {"items": rows}
    for key in ("dev", "heldout", "all"):
        per = {}
        for d in DIMS:
            sel = [r for r in rows if r["dim"] == d and (key == "all" or r["set"] == key)]
            per[d] = {"passed": sum(r["ok"] for r in sel), "total": len(sel), "pct": round(100 * sum(r["ok"] for r in sel) / len(sel), 1) if sel else None}
        sel = [r for r in rows if key == "all" or r["set"] == key]
        out[key] = {"per_dimension": per, "passed": sum(r["ok"] for r in sel), "total": len(sel), "pct": round(100 * sum(r["ok"] for r in sel) / max(1, len(sel)), 1)}
    return out


def main(argv=None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--json", default="")
    ap.add_argument("--set", default="all")
    a = ap.parse_args(argv)
    out = run(a.set)
    for key in ("dev", "heldout"):
        print(f"{key}: {out[key]['passed']}/{out[key]['total']} = {out[key]['pct']}%")
        for d, v in out[key]["per_dimension"].items():
            print(f"   {d:30s} {v['passed']}/{v['total']}")
    for r in out["items"]:
        if not r["ok"]:
            print("FAIL", r["set"], r["dim"], r["turns"][-1][:60], "->", (r["text"] or r["error"] or "")[:100].replace("\n", " / "))
    if a.json:
        Path(a.json).write_text(json.dumps(out, ensure_ascii=False, indent=1), encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
