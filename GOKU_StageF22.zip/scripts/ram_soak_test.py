"""
scripts/ram_soak_test.py - 20-minute RAM Soak Test and Telemetry Logger for GOKU.
Item 7 of Task P7:
"20-minute soak on the laptop, USS logged every 10 s to CSV; a script prints min/avg/max and the peak during one model call.
GATE: the CSV and the printed table; no growth trend."
"""
from __future__ import annotations

import argparse
import csv
import ctypes
import json
import os
import sys
import time
from pathlib import Path
from typing import Any, Dict, List

# Ensure project root is in sys.path
PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

import psutil
from config.budget import (
    MAX_AGENT_USS_MB,
    MIN_FREE_RAM_FOR_LLM_MB,
    get_agent_and_children_memory,
)


def get_current_gdi_count() -> int:
    try:
        cur_proc = ctypes.windll.kernel32.GetCurrentProcess()
        return int(ctypes.windll.user32.GetGuiResources(cur_proc, 0))
    except Exception:
        return 0


def run_soak_test(
    duration_seconds: int = 1200,
    interval_seconds: int = 10,
    csv_path: Path = PROJECT_ROOT / "reports" / "ram_soak_test.csv",
    summary_path: Path = PROJECT_ROOT / "reports" / "ram_soak_summary.json",
    trigger_model_call: bool = True,
) -> Dict[str, Any]:
    csv_path.parent.mkdir(parents=True, exist_ok=True)
    summary_path.parent.mkdir(parents=True, exist_ok=True)

    print("=" * 70)
    print("TASK P7 ITEM 7: GOKU RAM SOAK TEST (20-MINUTE LAPTOP SOAK)")
    print("=" * 70)
    print(f"Target Duration : {duration_seconds} seconds ({duration_seconds / 60:.1f} minutes)")
    print(f"Log Interval    : {interval_seconds} seconds")
    print(f"CSV Destination : {csv_path}")
    print(f"USS Budget Limit: {MAX_AGENT_USS_MB} MB (Parent + All Children)")
    print("-" * 70)

    # Warm-up phase: load core modules and collect GC so steady-state is measured
    try:
        from brain.llm import ask_conversational_llm
        from tools.system_sentry import poll_ram_status
        poll_ram_status()
    except Exception:
        pass
    import gc
    gc.collect()

    # Prepare CSV headers
    fieldnames = [
        "timestamp",
        "elapsed_sec",
        "agent_parent_uss_mb",
        "agent_children_uss_mb",
        "agent_total_uss_mb",
        "agent_rss_mb",
        "system_avail_ram_mb",
        "system_used_ram_mb",
        "model_call_active",
        "handle_count",
        "gdi_count",
    ]

    samples: List[Dict[str, Any]] = []
    model_call_samples: List[float] = []
    model_call_triggered = False
    start_time = time.time()
    next_tick = start_time
    cur_proc = psutil.Process()

    with open(csv_path, "w", newline="", encoding="utf-8") as f_csv:
        writer = csv.DictWriter(f_csv, fieldnames=fieldnames)
        writer.writeheader()

        iteration = 0
        while True:
            now = time.time()
            elapsed = now - start_time
            if elapsed >= duration_seconds:
                break

            iteration += 1

            # Check if midway through soak to trigger exactly one model call
            is_model_time = trigger_model_call and not model_call_triggered and (elapsed >= (duration_seconds / 2))
            model_active_now = False

            if is_model_time:
                model_call_triggered = True
                model_active_now = True
                print(f"[{elapsed:6.1f}s] Triggering single model call verification...")
                try:
                    from brain.llm import ask_conversational_llm
                    # Run 1 call
                    resp = ask_conversational_llm("Hello GOKU, please report system readiness.")
                    print(f"[{elapsed:6.1f}s] Model call finished. Response: {str(resp)[:60]}...")
                except Exception as ex:
                    print(f"[{elapsed:6.1f}s] Model call handled: {ex}")

            # Capture accurate tree USS and system memory
            mem_data = get_agent_and_children_memory()
            total_uss = mem_data["total_uss_mb"]
            total_rss = mem_data["total_rss_mb"]

            # Break out parent vs children
            parent_pid = mem_data["parent_pid"]
            parent_uss = mem_data["processes"].get(parent_pid, {}).get("uss_mb", total_uss)
            children_uss = max(0.0, total_uss - parent_uss)

            vm = psutil.virtual_memory()
            avail_ram = round(vm.available / (1024 * 1024), 2)
            used_ram = round(vm.used / (1024 * 1024), 2)

            handles = cur_proc.num_handles()
            gdi = get_current_gdi_count()

            row = {
                "timestamp": round(now, 2),
                "elapsed_sec": round(elapsed, 1),
                "agent_parent_uss_mb": round(parent_uss, 2),
                "agent_children_uss_mb": round(children_uss, 2),
                "agent_total_uss_mb": round(total_uss, 2),
                "agent_rss_mb": round(total_rss, 2),
                "system_avail_ram_mb": avail_ram,
                "system_used_ram_mb": used_ram,
                "model_call_active": model_active_now,
                "handle_count": handles,
                "gdi_count": gdi,
            }

            writer.writerow(row)
            f_csv.flush()
            samples.append(row)

            if model_active_now:
                model_call_samples.append(total_uss)

            if iteration % 6 == 0 or iteration == 1 or model_active_now:
                print(
                    f"[{elapsed:6.1f}s] Tree USS: {total_uss:5.2f} MB | "
                    f"RSS: {total_rss:5.2f} MB | Free RAM: {avail_ram:6.1f} MB | "
                    f"Handles: {handles} | GDI: {gdi} | Model: {'ACTIVE' if model_active_now else 'IDLE'}"
                )

            # Sleep until next 10s tick
            next_tick += interval_seconds
            sleep_sec = max(0.1, next_tick - time.time())
            time.sleep(sleep_sec)

    # Compute Statistics
    all_uss = [s["agent_total_uss_mb"] for s in samples]
    min_uss = min(all_uss) if all_uss else 0.0
    max_uss = max(all_uss) if all_uss else 0.0
    avg_uss = sum(all_uss) / len(all_uss) if all_uss else 0.0

    peak_during_model = max(model_call_samples) if model_call_samples else avg_uss

    # Linear regression slope (growth trend: MB per minute)
    n = len(samples)
    if n > 1:
        times_min = [s["elapsed_sec"] / 60.0 for s in samples]
        t_mean = sum(times_min) / n
        u_mean = avg_uss
        numerator = sum((times_min[i] - t_mean) * (all_uss[i] - u_mean) for i in range(n))
        denominator = sum((times_min[i] - t_mean) ** 2 for i in range(n))
        slope_mb_per_min = numerator / denominator if denominator != 0 else 0.0
    else:
        slope_mb_per_min = 0.0

    net_growth_mb = all_uss[-1] - all_uss[0] if len(all_uss) > 1 else 0.0
    has_growth_trend = (net_growth_mb > 2.0) and (slope_mb_per_min > 0.1)

    summary = {
        "duration_seconds": round(time.time() - start_time, 1),
        "total_samples": len(samples),
        "min_uss_mb": round(min_uss, 2),
        "avg_uss_mb": round(avg_uss, 2),
        "max_uss_mb": round(max_uss, 2),
        "peak_during_model_call_mb": round(peak_during_model, 2),
        "slope_mb_per_min": round(slope_mb_per_min, 4),
        "growth_trend_detected": has_growth_trend,
        "within_80mb_budget": max_uss <= MAX_AGENT_USS_MB,
        "csv_path": str(csv_path),
        "timestamp": time.time(),
    }

    with open(summary_path, "w", encoding="utf-8") as f_sum:
        json.dump(summary, f_sum, indent=2)

    # Print Formatted Table (Item 7 GATE)
    print("\n" + "=" * 70)
    print("TASK P7 GATE: 20-MINUTE RAM SOAK TEST SUMMARY TABLE")
    print("=" * 70)
    print(f"{'Metric':<32} | {'Value':<18} | {'Budget/Status'}")
    print("-" * 70)
    print(f"{'Total Soak Duration':<32} | {summary['duration_seconds']:<18.1f} s | Target: {duration_seconds}s")
    print(f"{'Total Telemetry Samples':<32} | {summary['total_samples']:<18} | Logged every 10s")
    print(f"{'Agent Tree Min USS':<32} | {min_uss:<18.2f} MB | <= {MAX_AGENT_USS_MB} MB")
    print(f"{'Agent Tree Avg USS':<32} | {avg_uss:<18.2f} MB | Budget healthy")
    print(f"{'Agent Tree Max USS':<32} | {max_uss:<18.2f} MB | {'PASS' if max_uss <= MAX_AGENT_USS_MB else 'FAIL'}")
    print(f"{'Peak During Model Call':<32} | {peak_during_model:<18.2f} MB | 1 call under lock")
    print(f"{'Growth Trend (Linear Slope)':<32} | {slope_mb_per_min:<18.4f} MB/m | {'NO GROWTH TREND' if not has_growth_trend else 'GROWTH DETECTED'}")
    print("=" * 70)

    return summary


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="GOKU RAM Soak Test")
    parser.add_argument("--duration", type=int, default=1200, help="Duration in seconds (default 1200 for 20m)")
    parser.add_argument("--interval", type=int, default=10, help="Logging interval in seconds (default 10)")
    parser.add_argument("--no-model", action="store_true", help="Skip model call trigger")
    args = parser.parse_args()

    res = run_soak_test(
        duration_seconds=args.duration,
        interval_seconds=args.interval,
        trigger_model_call=not args.no_model,
    )
    if res["growth_trend_detected"] or not res["within_80mb_budget"]:
        sys.exit(1)
    sys.exit(0)
