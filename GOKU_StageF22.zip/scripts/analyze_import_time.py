"""
scripts/analyze_import_time.py - Profile and Analyze Python Startup Import Times
Prompt R8 Requirement 1:
"Run python -X importtime on the GOKU entry point and list the top 20 imports by
cumulative time. List heavy libraries imported at startup (torch, transformers,
cv2, numpy, pandas, tkinter and similar). Move imports used only in rare paths
inside the functions that need them, keeping behaviour identical; add tests for import side effects."
"""
from __future__ import annotations

import json
from pathlib import Path
import re
import subprocess
import sys
import time

HEAVY_TARGETS = [
    "torch", "transformers", "cv2", "numpy", "pandas",
    "tkinter", "_tkinter", "matplotlib", "scipy", "pyautogui",
    "pyscreeze", "PIL", "mouseinfo"
]


def run_importtime(entry_cmd: str = "import main") -> list[dict]:
    cmd = [sys.executable, "-X", "importtime", "-c", entry_cmd]
    proc = subprocess.run(cmd, capture_output=True, text=True, errors="replace")
    lines = proc.stderr.splitlines()

    records = []
    # Line format: import time: self_us | cum_us | module_name
    pattern = re.compile(r"import time:\s*(\d+)\s*\|\s*(\d+)\s*\|\s*(.+)$")
    for line in lines:
        m = pattern.match(line.strip())
        if m:
            self_us = int(m.group(1))
            cum_us = int(m.group(2))
            mod_name = m.group(3).strip()
            records.append({
                "module": mod_name,
                "self_us": self_us,
                "self_ms": round(self_us / 1000.0, 2),
                "cum_us": cum_us,
                "cum_ms": round(cum_us / 1000.0, 2),
            })
    return records


def analyze_imports():
    print("=" * 85)
    print("PROMPT R8: GOKU ENTRY POINT STARTUP IMPORT PROFILER (python -X importtime)")
    print("=" * 85)

    records = run_importtime("import main")
    if not records:
        print("Error: No importtime output captured.")
        return

    # Sort by cumulative time descending
    by_cum = sorted(records, key=lambda x: x["cum_us"], reverse=True)

    print(f"Total modules imported at startup: {len(records)}")
    total_startup_ms = by_cum[0]["cum_ms"] if by_cum else 0.0
    print(f"Total startup import duration     : {total_startup_ms:.2f} ms ({total_startup_ms/1000.0:.2f} s)\n")

    print("-" * 85)
    print(f"{'Rank':<5} | {'Module Name':<42} | {'Cumulative (ms)':<16} | {'Self (ms)':<10}")
    print("-" * 85)
    top_20 = by_cum[:20]
    for idx, r in enumerate(top_20, 1):
        print(f"{idx:<5} | {r['module']:<42} | {r['cum_ms']:<16.2f} | {r['self_ms']:<10.2f}")
    print("-" * 85)

    # Check heavy libraries
    print("\n[HEAVY LIBRARIES AUDIT AT STARTUP]")
    heavy_detected = []
    for r in records:
        mod_root = r["module"].split(".")[0]
        if mod_root in HEAVY_TARGETS or r["module"] in HEAVY_TARGETS:
            heavy_detected.append(r)

    # Dedup and sort heavy
    seen = set()
    unique_heavy = []
    for h in sorted(heavy_detected, key=lambda x: x["cum_us"], reverse=True):
        root = h["module"].split(".")[0]
        if root not in seen:
            seen.add(root)
            unique_heavy.append(h)

    for h in unique_heavy:
        print(f"  [HEAVY IMPORT DETECTED] {h['module']:<20} -> {h['cum_ms']:.2f} ms cumulative")

    if not unique_heavy:
        print("  None detected! All heavy libraries successfully deferred.")

    out_file = Path("reports/import_profile.json")
    out_file.parent.mkdir(parents=True, exist_ok=True)
    with open(out_file, "w", encoding="utf-8") as f:
        json.dump({
            "generated_at": time.strftime("%Y-%m-%d %H:%M:%S"),
            "total_modules": len(records),
            "total_import_ms": total_startup_ms,
            "top_20_cumulative": top_20,
            "heavy_imports_detected": unique_heavy,
        }, f, indent=2)
    print(f"\nReport written cleanly to: {out_file}")
    print("=" * 85)


if __name__ == "__main__":
    analyze_imports()
