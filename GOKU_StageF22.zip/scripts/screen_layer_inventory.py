"""
scripts/screen_layer_inventory.py - Screen Layer Inventory & Import Cost Profiler.
Follows GOKU RULES v2 + 16-26 + Prompt R5 Step 1.

Measures:
1. Exact import time and cost (via python -X importtime) for screen/vision modules.
2. Dependencies audit: verifies no torch, cv2, or heavy vision models are imported.
3. Process memory (RSS and USS) before and after first use of screen inspection.
"""
from __future__ import annotations

from typing import Any

import gc
import json
import os
from pathlib import Path
import subprocess
import sys
import time

try:
    import psutil
except ImportError:
    psutil = None

WORKSPACE_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(WORKSPACE_ROOT))


def run_import_time(module_name: str) -> dict[str, Any]:
    """Runs python -X importtime on a module and parses cumulative import time."""
    cmd = [sys.executable, "-X", "importtime", "-c", f"import {module_name}"]
    res = subprocess.run(cmd, capture_output=True, text=True)
    lines = res.stderr.splitlines()

    total_self_us = 0
    total_cum_us = 0
    submodules = []

    for line in lines:
        if "import time:" in line:
            parts = line.strip().split("|")
            if len(parts) >= 3:
                try:
                    self_us = int(parts[0].replace("import time:", "").strip())
                    cum_us = int(parts[1].strip())
                    name = parts[2].strip()
                    total_self_us += self_us
                    total_cum_us = max(total_cum_us, cum_us)
                    if module_name in name or any(k in name for k in ["comtypes", "PIL", "ctypes", "win32"]):
                        submodules.append({"name": name, "self_us": self_us, "cum_us": cum_us})
                except ValueError:
                    pass

    return {
        "module": module_name,
        "total_cum_ms": round(total_cum_us / 1000.0, 2),
        "total_self_ms": round(total_self_us / 1000.0, 2),
        "sample_submodules": submodules[-8:],
    }


def audit_heavy_dependencies() -> dict[str, Any]:
    """Audits screen layer for heavy dependencies (torch, cv2, pytesseract, transformers)."""
    heavy_pkgs = ["torch", "cv2", "tensorflow", "transformers", "ultralytics", "pytesseract"]
    audit = {}
    for pkg in heavy_pkgs:
        try:
            __import__(pkg)
            audit[pkg] = "INSTALLED (Present in environment)"
        except ImportError:
            audit[pkg] = "NOT_INSTALLED (Zero footprint)"
    return audit


def measure_memory_before_after_screen_use() -> dict[str, Any]:
    """Measures RSS and USS before and after first use of screen capture / UIA inspect."""
    if psutil is None:
        return {"error": "psutil not available"}

    proc = psutil.Process(os.getpid())
    gc.collect()

    m0 = proc.memory_full_info() if hasattr(proc, "memory_full_info") else proc.memory_info()
    rss_before_mb = m0.rss / (1024 * 1024)
    uss_before_mb = getattr(m0, "uss", m0.rss) / (1024 * 1024)

    # First use: window capture and resolution probe
    from tools.screen import get_screen_size
    screen_info = get_screen_size()

    from tools.window_lifecycle import take_window_snapshot
    snap = take_window_snapshot()

    gc.collect()
    m1 = proc.memory_full_info() if hasattr(proc, "memory_full_info") else proc.memory_info()
    rss_after_mb = m1.rss / (1024 * 1024)
    uss_after_mb = getattr(m1, "uss", m1.rss) / (1024 * 1024)

    return {
        "rss_before_mb": round(rss_before_mb, 2),
        "rss_after_mb": round(rss_after_mb, 2),
        "rss_delta_mb": round(rss_after_mb - rss_before_mb, 2),
        "uss_before_mb": round(uss_before_mb, 2),
        "uss_after_mb": round(uss_after_mb, 2),
        "uss_delta_mb": round(uss_after_mb - uss_before_mb, 2),
        "screen_resolution": f"{screen_info.get('width')}x{screen_info.get('height')}",
        "windows_enumerated": len(snap),
    }


def main():
    print("=" * 80)
    print("SCREEN LAYER INVENTORY & IMPORT COST AUDIT")
    print(f"Timestamp: {time.strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 80)

    # 1. Heavy Dependencies Check
    print("\n[1] HEAVY VISION DEPENDENCY AUDIT:")
    dep_audit = audit_heavy_dependencies()
    for pkg, status in dep_audit.items():
        print(f"  - {pkg:<15}: {status}")

    # 2. Import Cost Measurements
    print("\n[2] IMPORT TIME & COST PROFILING (python -X importtime):")
    target_modules = [
        "tools.screen",
        "tools.window_lifecycle",
        "tools.documents",
        "tools.vision.screen_engine",
    ]
    import_results = {}
    for mod in target_modules:
        res = run_import_time(mod)
        import_results[mod] = res
        print(f"  - Module: {mod:<30} | Cumulative Time: {res['total_cum_ms']:>8.2f} ms | Self Time: {res['total_self_ms']:>8.2f} ms")

    # 3. Memory Before & After First Use
    print("\n[3] MEMORY IMPACT BEFORE / AFTER FIRST SCREEN USE:")
    mem_res = measure_memory_before_after_screen_use()
    print(f"  - RSS Before First Use : {mem_res.get('rss_before_mb')} MB")
    print(f"  - RSS After First Use  : {mem_res.get('rss_after_mb')} MB (Delta: +{mem_res.get('rss_delta_mb')} MB)")
    print(f"  - USS Before First Use : {mem_res.get('uss_before_mb')} MB")
    print(f"  - USS After First Use  : {mem_res.get('uss_after_mb')} MB (Delta: +{mem_res.get('uss_delta_mb')} MB)")
    print(f"  - Screen Resolution    : {mem_res.get('screen_resolution')}")
    print(f"  - Windows Enumerated   : {mem_res.get('windows_enumerated')}")

    out_file = WORKSPACE_ROOT / "reports" / "screen_layer_inventory.json"
    out_file.parent.mkdir(parents=True, exist_ok=True)
    data = {
        "timestamp": time.strftime('%Y-%m-%d %H:%M:%S'),
        "heavy_dependencies": dep_audit,
        "import_costs": import_results,
        "memory_telemetry": mem_res,
    }
    with open(out_file, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
    print(f"\n[INFO] Inventory report saved to: {out_file}")
    print("=" * 80)


if __name__ == "__main__":
    main()
