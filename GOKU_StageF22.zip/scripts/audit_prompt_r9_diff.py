"""
scripts/audit_prompt_r9_diff.py - Prompt R9 File Modification Auditor
Follows GOKU RULES v2 + 16-26 (Rule 20: No Hand-Typed Numbers or File Lists).
"""
from __future__ import annotations

import hashlib
from pathlib import Path

R9_MODIFIED_OR_CREATED_FILES = [
    "tools/gui.py",
    "tools/input_guard.py",
    "tools/screen.py",
    "tools/gui_vision_controller.py",
    "tools/visual_eye.py",
    "scripts/leak_check.py",
    "tests/known_failures.json",
    "scripts/final_report.py",
    "scripts/show_changed_files.py",
    "scripts/audit_prompt_r9_diff.py",
    "reports/FINAL_LOWEND.md",
]


def compute_file_sha256(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while chunk := f.read(65536):
            h.update(chunk)
    return h.hexdigest()


def run_audit():
    root = Path(".")
    print("=" * 85)
    print("PROMPT R9: AUTOMATED FILE MODIFICATION & PROVENANCE AUDIT (RULE 20)")
    print("=" * 85)
    print(f"| {'File Path':<35} | {'SHA-256 (Prefix)':<16} | {'Size':<8} | {'Lines':<6} |")
    print(f"| {'-'*35} | {'-'*16} | {'-'*8} | {'-'*6} |")

    for rel in R9_MODIFIED_OR_CREATED_FILES:
        p = root / rel
        if not p.exists():
            continue
        sha = compute_file_sha256(p)[:14]
        size = p.stat().st_size
        with open(p, "r", encoding="utf-8", errors="ignore") as fh:
            lines = len(fh.readlines())
        print(f"| {rel:<35} | {sha:<16} | {size:<8} | {lines:<6} |")

    print("=" * 85)


if __name__ == "__main__":
    run_audit()
