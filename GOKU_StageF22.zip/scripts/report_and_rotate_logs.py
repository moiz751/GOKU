"""
scripts/report_and_rotate_logs.py - Log Size Auditor and Rotation Runner
Prompt R8 Requirement 4:
"Logs: report sizes of logs/*.jsonl, execution_traces.jsonl and reports/.
Add size caps and rotation from config for GOKU-owned logs only;
rotation renames or compresses, and never deletes a user file without approval."
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys
import time

PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from tools.log_rotator import get_log_sizes_summary, rotate_all_goku_logs_if_needed, MAX_LOG_FILE_BYTES


def main():
    parser = argparse.ArgumentParser(description="GOKU Log Size Auditor and Rotation")
    parser.add_argument("--rotate", action="store_true", help="Perform rotation on logs exceeding cap")
    args = parser.parse_args()

    print("=" * 85)
    print("PROMPT R8: GOKU LOG SIZE AUDITOR & ROTATION REPORT")
    print("=" * 85)
    print(f"Max Log File Cap (Config): {MAX_LOG_FILE_BYTES} bytes ({MAX_LOG_FILE_BYTES / (1024*1024):.1f} MB)")
    print("Rotation Mode            : Renames & Gzip Compression (No user file deletion)\n")

    summary = get_log_sizes_summary(PROJECT_ROOT)

    print("-" * 85)
    print(f"{'Log Category / File':<42} | {'Size (Bytes)':<16} | {'Size (MB)':<12} | {'Status':<10}")
    print("-" * 85)

    # 1. execution_traces.jsonl
    tr = summary["execution_traces_jsonl"]
    if tr:
        status = "EXCEEDS CAP" if tr["size_bytes"] >= MAX_LOG_FILE_BYTES else "OK"
        print(f"{'execution_traces.jsonl':<42} | {tr['size_bytes']:<16} | {tr['size_mb']:<12.3f} | {status:<10}")
    else:
        print(f"{'execution_traces.jsonl':<42} | {'MISSING':<16} | {'0.000':<12} | {'OK':<10}")

    # 2. logs/*.jsonl
    for name, item in summary["logs_jsonl"].items():
        status = "EXCEEDS CAP" if item["size_bytes"] >= MAX_LOG_FILE_BYTES else "OK"
        print(f"{f'logs/{name}':<42} | {item['size_bytes']:<16} | {item['size_mb']:<12.3f} | {status:<10}")

    # 3. reports/*.jsonl
    for name, item in summary["reports_jsonl"].items():
        status = "EXCEEDS CAP" if item["size_bytes"] >= MAX_LOG_FILE_BYTES else "OK"
        print(f"{f'reports/{name}':<42} | {item['size_bytes']:<16} | {item['size_mb']:<12.3f} | {status:<10}")

    print("-" * 85)
    print(f"Total reports/ directory size (all files): {summary['reports_dir_total_bytes']} bytes ({summary['reports_dir_total_mb']} MB)")
    print("-" * 85)

    # Run rotation if requested or if any file exceeds cap
    rotations = []
    if args.rotate:
        print("\n[PERFORMING LOG ROTATION]")
        rotations = rotate_all_goku_logs_if_needed(PROJECT_ROOT)
        if rotations:
            for r in rotations:
                print(f"  Rotated {r['original_path']} ({r['uncompressed_bytes']} bytes) -> {r['rotated_target']} ({r['rotated_bytes']} bytes, ratio: {r['ratio_pct']}%)")
        else:
            print("  All GOKU-owned logs are under size cap. Zero rotations required.")

    # Save artifact
    out_file = PROJECT_ROOT / "reports" / "log_audit.json"
    out_file.parent.mkdir(parents=True, exist_ok=True)
    with open(out_file, "w", encoding="utf-8") as f_out:
        json.dump({
            "generated_at": time.strftime("%Y-%m-%d %H:%M:%S"),
            "max_log_bytes_cap": MAX_LOG_FILE_BYTES,
            "summary": summary,
            "rotations": rotations,
        }, f_out, indent=2)

    print(f"\nAudit artifact saved cleanly to: {out_file}")
    print("=" * 85)


if __name__ == "__main__":
    main()
