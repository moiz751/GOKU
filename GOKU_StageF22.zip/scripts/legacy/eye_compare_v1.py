"""
GOKU Autonomous Desktop Agent — Eye A/B Comparison Tool.
Compares before/after test reports and computes honest verdicts against frozen criteria.
FROZEN FILE: Do not edit after creation.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import sys
from typing import Any

PROJECT_ROOT = Path(__file__).resolve().parent.parent


def compute_file_sha256(path: Path) -> str:
    if not path.is_file():
        return ""
    return hashlib.sha256(path.read_bytes()).hexdigest()


def check_kit_hashes(project_root: Path | None = None) -> bool:
    root = project_root or PROJECT_ROOT
    hash_file = root / "reports" / "eye" / "KIT_HASH.json"
    if not hash_file.is_file():
        print(f"MODIFIED: Kit hash file not found: {hash_file}")
        return False

    try:
        data = json.loads(hash_file.read_text(encoding="utf-8"))
    except Exception as e:
        print(f"MODIFIED: Failed to parse {hash_file}: {e}")
        return False

    expected_hashes = data.get("files", {})
    all_ok = True
    for rel_path, expected_hash in expected_hashes.items():
        actual_path = root / rel_path
        actual_hash = compute_file_sha256(actual_path)
        if actual_hash != expected_hash:
            print(f"MODIFIED: {rel_path} hash mismatch!\n  Expected: {expected_hash}\n  Actual:   {actual_hash}")
            all_ok = False

    if all_ok:
        print("OK: Kit integrity verified. All test files match frozen hashes.")
        return True
    return False


def validate_comparison_preconditions(before_data: dict[str, Any], after_data: dict[str, Any]) -> list[str]:
    """
    Checks refusal conditions:
    - schema_version mismatch
    - test_sha256 differs
    - scale_flag or resolution differ
    - engine_sha256 is identical
    Returns list of refusal reasons (empty if valid).
    """
    refusals = []

    b_schema = before_data.get("schema_version")
    a_schema = after_data.get("schema_version")
    if b_schema != 1 or a_schema != 1 or b_schema != a_schema:
        refusals.append(f"schema_version mismatch: before has {b_schema}, after has {a_schema} (expected 1)")

    b_test_sha = before_data.get("test_sha256", "")
    a_test_sha = after_data.get("test_sha256", "")
    if b_test_sha != a_test_sha or not b_test_sha:
        refusals.append(f"test_sha256 differs between files (before={b_test_sha[:10]}..., after={a_test_sha[:10]}...)")

    b_scale = before_data.get("scale_flag")
    a_scale = after_data.get("scale_flag")
    if b_scale != a_scale:
        refusals.append(f"scale_flag differs (before={b_scale}%, after={a_scale}%)")

    b_res = before_data.get("resolution", {})
    a_res = after_data.get("resolution", {})
    if b_res != a_res:
        refusals.append(f"resolution differs (before={b_res}, after={a_res})")

    b_engine = before_data.get("engine_sha256", "")
    a_engine = after_data.get("engine_sha256", "")
    if b_engine == a_engine and b_engine != "":
        refusals.append("engine_sha256 is identical between before and after files (nothing changed in tools/vision/)")

    return refusals


def evaluate_verdict(before_data: dict[str, Any], after_data: dict[str, Any]) -> tuple[bool, list[str], dict[str, Any]]:
    """
    Evaluates before vs after results according to the frozen rules.
    Apps skipped in either file are excluded from totals and listed.
    Returns (verdict_passed, failed_rules, comparison_stats).
    """
    b_apps = before_data.get("per_app", {})
    a_apps = after_data.get("per_app", {})

    all_app_names = sorted(set(list(b_apps.keys()) + list(a_apps.keys())))
    completed_apps: list[str] = []
    skipped_apps: list[str] = []

    failed_rules: list[str] = []

    # Rule 9 check: no app completed before is skipped/failed after
    for app in all_app_names:
        b_st = b_apps.get(app, {}).get("status")
        a_st = a_apps.get(app, {}).get("status")

        if b_st == "completed" and a_st != "completed":
            failed_rules.append(f"Rule 9 (no_completed_app_dropped): App '{app}' was completed before but is '{a_st}' after")

        if b_st == "completed" and a_st == "completed":
            completed_apps.append(app)
        else:
            skipped_apps.append(app)

    # Aggregate metrics across completed apps
    b_total_sampled = sum(b_apps[a].get("sampled", 0) for a in completed_apps)
    b_total_strict_hits = sum(b_apps[a].get("strict_hits", 0) for a in completed_apps)
    b_total_lenient_hits = sum(b_apps[a].get("lenient_hits", 0) for a in completed_apps)
    b_total_walked = sum(b_apps[a].get("walked", 0) for a in completed_apps)
    b_total_seen = sum(int(round(b_apps[a].get("recall_pct", 0.0) / 100.0 * b_apps[a].get("walked", 0))) for a in completed_apps)
    b_total_hallucinations = sum(
        sum(1 for c in b_apps[a].get("controls", []) if c.get("miss_reason") == "ORACLE_NONE" and c.get("source") != "ocr")
        for a in completed_apps
    )
    b_total_ram = sum(b_apps[a].get("ram_delta_mb", 0.0) for a in completed_apps)
    b_total_latency = sum(b_apps[a].get("latency_ms", 0.0) for a in completed_apps)

    a_total_sampled = sum(a_apps[a].get("sampled", 0) for a in completed_apps)
    a_total_strict_hits = sum(a_apps[a].get("strict_hits", 0) for a in completed_apps)
    a_total_lenient_hits = sum(a_apps[a].get("lenient_hits", 0) for a in completed_apps)
    a_total_walked = sum(a_apps[a].get("walked", 0) for a in completed_apps)
    a_total_seen = sum(int(round(a_apps[a].get("recall_pct", 0.0) / 100.0 * a_apps[a].get("walked", 0))) for a in completed_apps)
    a_total_hallucinations = sum(
        sum(1 for c in a_apps[a].get("controls", []) if c.get("miss_reason") == "ORACLE_NONE" and c.get("source") != "ocr")
        for a in completed_apps
    )
    a_total_ram = sum(a_apps[a].get("ram_delta_mb", 0.0) for a in completed_apps)
    a_total_latency = sum(a_apps[a].get("latency_ms", 0.0) for a in completed_apps)

    b_strict_pct = round((b_total_strict_hits / b_total_sampled * 100.0), 1) if b_total_sampled > 0 else 0.0
    a_strict_pct = round((a_total_strict_hits / a_total_sampled * 100.0), 1) if a_total_sampled > 0 else 0.0

    b_recall_pct = round((b_total_seen / b_total_walked * 100.0), 1) if b_total_walked > 0 else 0.0
    a_recall_pct = round((a_total_seen / a_total_walked * 100.0), 1) if a_total_walked > 0 else 0.0

    b_lenient_pct = round((b_total_lenient_hits / b_total_sampled * 100.0), 1) if b_total_sampled > 0 else 0.0
    a_lenient_pct = round((a_total_lenient_hits / a_total_sampled * 100.0), 1) if a_total_sampled > 0 else 0.0

    # Rule 1: total strict precision does not drop
    if a_strict_pct < b_strict_pct:
        failed_rules.append(f"Rule 1 (strict_precision_no_drop): Total strict precision dropped from {b_strict_pct}% to {a_strict_pct}% (delta: {round(a_strict_pct - b_strict_pct, 1)}%)")

    # Rule 2: total recall does not drop
    if a_recall_pct < b_recall_pct:
        failed_rules.append(f"Rule 2 (recall_no_drop): Total recall dropped from {b_recall_pct}% to {a_recall_pct}% (delta: {round(a_recall_pct - b_recall_pct, 1)}%)")

    # Rule 3: at least one rises by >= 5 percentage points
    strict_rise = a_strict_pct - b_strict_pct
    recall_rise = a_recall_pct - b_recall_pct
    if not (strict_rise >= 5.0 or recall_rise >= 5.0):
        failed_rules.append(f"Rule 3 (precision_or_recall_rise_5): Neither strict precision (+{strict_rise:.1f}%) nor recall (+{recall_rise:.1f}%) rose by >= 5.0 points")

    # Rule 4: hallucination_count after <= before
    if a_total_hallucinations > b_total_hallucinations:
        failed_rules.append(f"Rule 4 (hallucinations_no_increase): Hallucinations increased from {b_total_hallucinations} to {a_total_hallucinations}")

    # Per-app checks across completed apps
    for app in completed_apps:
        b_app = b_apps[app]
        a_app = a_apps[app]

        b_app_strict = b_app.get("strict_precision_pct", 0.0)
        a_app_strict = a_app.get("strict_precision_pct", 0.0)
        b_app_rec = b_app.get("recall_pct", 0.0)
        a_app_rec = a_app.get("recall_pct", 0.0)
        b_app_lat = b_app.get("latency_ms", 0.0)
        a_app_lat = a_app.get("latency_ms", 0.0)
        b_app_ram = b_app.get("ram_delta_mb", 0.0)
        a_app_ram = a_app.get("ram_delta_mb", 0.0)

        # Rule 5: no single app's strict precision falls by more than 3 points
        if b_app_strict - a_app_strict > 3.0:
            failed_rules.append(f"Rule 5 (no_app_strict_drop_gt_3): App '{app}' strict precision dropped {round(b_app_strict - a_app_strict, 1)} points ({b_app_strict}% -> {a_app_strict}%)")

        # Rule 6: no single app's recall falls by more than 3 points
        if b_app_rec - a_app_rec > 3.0:
            failed_rules.append(f"Rule 6 (no_app_recall_drop_gt_3): App '{app}' recall dropped {round(b_app_rec - a_app_rec, 1)} points ({b_app_rec}% -> {a_app_rec}%)")

        # Rule 7: latency_ms after <= 1.5 x before per app
        if b_app_lat > 0 and a_app_lat > 1.5 * b_app_lat:
            failed_rules.append(f"Rule 7 (latency_within_limit): App '{app}' latency {a_app_lat}ms exceeded 1.5x before ({b_app_lat}ms -> max allowed {round(1.5 * b_app_lat, 1)}ms)")

        # Rule 8 (per-app check): ram_delta after <= before + 30 MB
        if a_app_ram > b_app_ram + 30.0:
            failed_rules.append(f"Rule 8 (ram_delta_within_limit): App '{app}' RAM delta {a_app_ram}MB exceeded threshold (before: {b_app_ram}MB + 30MB = {b_app_ram + 30.0}MB)")

    # Rule 8 (total check): total ram_delta after <= before + 30 MB
    if a_total_ram > b_total_ram + 30.0:
        failed_rules.append(f"Rule 8 (ram_delta_within_limit): Total RAM delta {round(a_total_ram, 1)}MB exceeded threshold (before: {round(b_total_ram, 1)}MB + 30MB = {round(b_total_ram + 30.0, 1)}MB)")

    comparison_stats = {
        "completed_apps": completed_apps,
        "skipped_apps": skipped_apps,
        "before": {
            "strict_precision_pct": b_strict_pct,
            "recall_pct": b_recall_pct,
            "lenient_precision_pct": b_lenient_pct,
            "hallucination_count": b_total_hallucinations,
            "ram_delta_mb": round(b_total_ram, 2),
            "latency_ms": round(b_total_latency, 2),
            "ocr_status": before_data.get("totals", {}).get("ocr_status", "N/A"),
        },
        "after": {
            "strict_precision_pct": a_strict_pct,
            "recall_pct": a_recall_pct,
            "lenient_precision_pct": a_lenient_pct,
            "hallucination_count": a_total_hallucinations,
            "ram_delta_mb": round(a_total_ram, 2),
            "latency_ms": round(a_total_latency, 2),
            "ocr_status": after_data.get("totals", {}).get("ocr_status", "N/A"),
        },
    }

    verdict_passed = (len(failed_rules) == 0)
    return verdict_passed, failed_rules, comparison_stats


def print_comparison_table(before_data: dict[str, Any], after_data: dict[str, Any], stats: dict[str, Any]) -> None:
    b_apps = before_data.get("per_app", {})
    a_apps = after_data.get("per_app", {})
    completed = stats["completed_apps"]
    skipped = stats["skipped_apps"]

    print("\n" + "=" * 94)
    print(" GOKU EYE A/B BENCHMARK COMPARISON TABLE")
    print("=" * 94)
    header = f"{'Application / Metric':<28} | {'BEFORE':<18} | {'AFTER':<18} | {'DELTA':<18}"
    print(header)
    print("-" * 94)

    for app in completed:
        b_a = b_apps.get(app, {})
        a_a = a_apps.get(app, {})

        b_strict = b_a.get("strict_precision_pct", 0.0)
        a_strict = a_a.get("strict_precision_pct", 0.0)
        d_strict = a_strict - b_strict

        b_rec = b_a.get("recall_pct", 0.0)
        a_rec = a_a.get("recall_pct", 0.0)
        d_rec = a_rec - b_rec

        b_len = b_a.get("lenient_hits", 0) / max(1, b_a.get("sampled", 1)) * 100.0
        a_len = a_a.get("lenient_hits", 0) / max(1, a_a.get("sampled", 1)) * 100.0
        d_len = a_len - b_len

        b_lat = b_a.get("latency_ms", 0.0)
        a_lat = a_a.get("latency_ms", 0.0)
        d_lat = a_lat - b_lat

        b_ram = b_a.get("ram_delta_mb", 0.0)
        a_ram = a_a.get("ram_delta_mb", 0.0)
        d_ram = a_ram - b_ram

        b_hall = sum(1 for c in b_a.get("controls", []) if c.get("miss_reason") == "ORACLE_NONE" and c.get("source") != "ocr")
        a_hall = sum(1 for c in a_a.get("controls", []) if c.get("miss_reason") == "ORACLE_NONE" and c.get("source") != "ocr")
        d_hall = a_hall - b_hall

        print(f"[{app}]")
        print(f"  Strict Precision           | {b_strict:<17.1f}% | {a_strict:<17.1f}% | {d_strict:+17.1f}%")
        print(f"  Recall                     | {b_rec:<17.1f}% | {a_rec:<17.1f}% | {d_rec:+17.1f}%")
        print(f"  Lenient Precision (info)   | {b_len:<17.1f}% | {a_len:<17.1f}% | {d_len:+17.1f}%")
        print(f"  Latency                    | {b_lat:<15.1f} ms | {a_lat:<15.1f} ms | {d_lat:+15.1f} ms")
        print(f"  RAM Delta                  | {b_ram:<15.2f} MB | {a_ram:<15.2f} MB | {d_ram:+15.2f} MB")
        print(f"  Hallucinations             | {b_hall:<18} | {a_hall:<18} | {d_hall:+18}")

    if skipped:
        print("-" * 94)
        print(f"Excluded Apps (skipped in before or after): {', '.join(skipped)}")
        for app in skipped:
            b_st = b_apps.get(app, {}).get("status", "not_present")
            a_st = a_apps.get(app, {}).get("status", "not_present")
            print(f"  - {app}: before='{b_st}', after='{a_st}'")

    print("=" * 94)
    b_tot = stats["before"]
    a_tot = stats["after"]

    tot_d_strict = a_tot["strict_precision_pct"] - b_tot["strict_precision_pct"]
    tot_d_rec = a_tot["recall_pct"] - b_tot["recall_pct"]
    tot_d_len = a_tot["lenient_precision_pct"] - b_tot["lenient_precision_pct"]
    tot_d_lat = a_tot["latency_ms"] - b_tot["latency_ms"]
    tot_d_ram = a_tot["ram_delta_mb"] - b_tot["ram_delta_mb"]
    tot_d_hall = a_tot["hallucination_count"] - b_tot["hallucination_count"]

    print("[TOTALS across completed apps]")
    print(f"  Strict Precision           | {b_tot['strict_precision_pct']:<17.1f}% | {a_tot['strict_precision_pct']:<17.1f}% | {tot_d_strict:+17.1f}%")
    print(f"  Recall                     | {b_tot['recall_pct']:<17.1f}% | {a_tot['recall_pct']:<17.1f}% | {tot_d_rec:+17.1f}%")
    print(f"  Lenient Precision (info)   | {b_tot['lenient_precision_pct']:<17.1f}% | {a_tot['lenient_precision_pct']:<17.1f}% | {tot_d_len:+17.1f}%")
    print(f"  Latency (sum)              | {b_tot['latency_ms']:<15.1f} ms | {a_tot['latency_ms']:<15.1f} ms | {tot_d_lat:+15.1f} ms")
    print(f"  RAM Delta (sum)            | {b_tot['ram_delta_mb']:<15.2f} MB | {a_tot['ram_delta_mb']:<15.2f} MB | {tot_d_ram:+15.2f} MB")
    print(f"  Hallucinations             | {b_tot['hallucination_count']:<18} | {a_tot['hallucination_count']:<18} | {tot_d_hall:+18}")
    print(f"  OCR Status                 | {b_tot['ocr_status']:<18} | {a_tot['ocr_status']:<18} | {'N/A':<18}")
    print("=" * 94 + "\n")


def main():
    parser = argparse.ArgumentParser(description="GOKU Autonomous Desktop Agent — Eye A/B Comparison Tool")
    parser.add_argument("--before", type=str, default="reports/eye/before.json", help="Path to before benchmark JSON")
    parser.add_argument("--after", type=str, default="reports/eye/after.json", help="Path to after benchmark JSON")
    parser.add_argument("--check-kit", action="store_true", help="Verify frozen integrity of eye test kit files")
    args = parser.parse_args()

    if args.check_kit:
        ok = check_kit_hashes()
        sys.exit(0 if ok else 1)

    before_path = Path(args.before)
    after_path = Path(args.after)

    if not before_path.is_file():
        print(f"Error: Before file not found: {before_path}", file=sys.stderr)
        sys.exit(2)
    if not after_path.is_file():
        print(f"Error: After file not found: {after_path}", file=sys.stderr)
        sys.exit(2)

    try:
        before_data = json.loads(before_path.read_text(encoding="utf-8"))
        after_data = json.loads(after_path.read_text(encoding="utf-8"))
    except Exception as e:
        print(f"Error parsing JSON files: {e}", file=sys.stderr)
        sys.exit(2)

    # Validate preconditions (exit 2 on refusal)
    refusals = validate_comparison_preconditions(before_data, after_data)
    if refusals:
        print("\n" + "!" * 78, file=sys.stderr)
        print(" REFUSAL TO COMPARE (Incompatible benchmark runs):", file=sys.stderr)
        for r in refusals:
            print(f"   * {r}", file=sys.stderr)
        print("!" * 78 + "\n", file=sys.stderr)
        sys.exit(2)

    verdict_passed, failed_rules, stats = evaluate_verdict(before_data, after_data)
    print_comparison_table(before_data, after_data, stats)

    if verdict_passed:
        print("*" * 40)
        print(" VERDICT: ACCEPT")
        print(" All frozen criteria passed successfully.")
        print("*" * 40 + "\n")
        sys.exit(0)
    else:
        print("!" * 78)
        print(" VERDICT: REJECT")
        print(f" {len(failed_rules)} rule(s) failed:")
        for r in failed_rules:
            print(f"   [FAIL] {r}")
        print("!" * 78 + "\n")
        sys.exit(1)


if __name__ == "__main__":
    main()
