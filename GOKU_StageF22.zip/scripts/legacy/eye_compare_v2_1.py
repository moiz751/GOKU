"""
GOKU Autonomous Desktop Agent — Eye A/B Comparison Tool v2.
Compares before/after test reports and computes honest verdicts against frozen v2 criteria:
Medians, noise-tolerant spreads, and no-silent-deletions validation.
FROZEN FILE: Do not edit after creation.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import sys
from typing import Any

PROJECT_ROOT = Path(__file__).resolve().parent.parent


def compute_file_sha256(path: Path) -> str:
    if not path.is_file():
        return ""
    return hashlib.sha256(path.read_bytes()).hexdigest()


def check_kit_hashes(project_root: Path | None = None) -> bool:
    root = project_root or PROJECT_ROOT
    hash_file = root / "reports" / "eye" / "KIT_HASH.json"
    if not hash_file.is_file():
        print(f"MODIFIED: Kit hash file not found: {hash_file}")
        return False

    try:
        data = json.loads(hash_file.read_text(encoding="utf-8"))
    except Exception as e:
        print(f"MODIFIED: Failed to parse {hash_file}: {e}")
        return False

    expected_hashes = data.get("files", {})
    all_ok = True
    for rel_path, expected_hash in expected_hashes.items():
        actual_path = root / rel_path
        actual_hash = compute_file_sha256(actual_path)
        if actual_hash != expected_hash:
            print(f"MODIFIED: {rel_path} hash mismatch!\n  Expected: {expected_hash}\n  Actual:   {actual_hash}")
            all_ok = False

    if all_ok:
        print("OK: Kit integrity verified. All test files match frozen hashes.")
        return True
    return False


def validate_comparison_preconditions(before_data: dict[str, Any], after_data: dict[str, Any]) -> list[str]:
    """
    Checks refusal conditions:
    - schema_version mismatch (must be 2)
    - test_sha256 differs
    - scale_flag or resolution differ
    - engine_sha256 is identical
    Returns list of refusal reasons (empty if valid).
    """
    refusals = []

    b_schema = before_data.get("schema_version")
    a_schema = after_data.get("schema_version")
    if b_schema != 2 or a_schema != 2 or b_schema != a_schema:
        refusals.append(f"schema_version mismatch: before has {b_schema}, after has {a_schema} (expected 2)")

    b_test_sha = before_data.get("test_sha256", "")
    a_test_sha = after_data.get("test_sha256", "")
    if b_test_sha != a_test_sha or not b_test_sha:
        refusals.append(f"test_sha256 differs between files (before={b_test_sha[:10]}..., after={a_test_sha[:10]}...)")

    b_scale = before_data.get("scale_flag")
    a_scale = after_data.get("scale_flag")
    if b_scale != a_scale:
        refusals.append(f"scale_flag differs (before={b_scale}%, after={a_scale}%)")

    b_res = before_data.get("resolution", {})
    a_res = after_data.get("resolution", {})
    if b_res != a_res:
        refusals.append(f"resolution differs (before={b_res}, after={a_res})")

    b_engine = before_data.get("engine_sha256", "")
    a_engine = after_data.get("engine_sha256", "")
    if b_engine == a_engine and b_engine != "":
        refusals.append("engine_sha256 is identical between before and after files (nothing changed in tools/vision/)")

    return refusals


def load_allowed_removals(project_root: Path | None = None) -> set[str]:
    root = project_root or PROJECT_ROOT
    rem_file = root / "reports" / "eye" / "ALLOWED_REMOVALS.json"
    if rem_file.is_file():
        try:
            items = json.loads(rem_file.read_text(encoding="utf-8"))
            if isinstance(items, list):
                return {str(x).strip().lower() for x in items}
        except Exception:
            pass
    return set()


def evaluate_verdict_v2(
    before_data: dict[str, Any],
    after_data: dict[str, Any],
    project_root: Path | None = None,
) -> tuple[bool, list[str], dict[str, Any]]:
    """
    Evaluates before vs after results according to frozen v2 criteria:
    - Uses medians across runs.
    - A drop is real only if larger than the BEFORE file's own spread.
    - P8: No silent deletions of strict hits.
    Returns (verdict_passed, failed_rules, comparison_stats).
    """
    b_apps = before_data.get("per_app", {})
    a_apps = after_data.get("per_app", {})

    all_app_names = sorted(set(list(b_apps.keys()) + list(a_apps.keys())))
    completed_apps: list[str] = []
    skipped_apps: list[str] = []
    failed_rules: list[str] = []

    # Rule 9: no app that was completed/measurable before is dropped
    for app in all_app_names:
        b_st = b_apps.get(app, {}).get("status")
        a_st = a_apps.get(app, {}).get("status")

        if b_st in ("completed", "recall_unmeasurable") and a_st not in ("completed", "recall_unmeasurable"):
            failed_rules.append(f"Rule 9 (no_completed_app_dropped): App '{app}' was '{b_st}' before but is '{a_st}' after")

        if b_st in ("completed", "recall_unmeasurable") and a_st in ("completed", "recall_unmeasurable"):
            completed_apps.append(app)
        else:
            skipped_apps.append(app)

    # Medians and spreads across completed apps
    b_strict_meds = [b_apps[a]["median"]["strict_precision_pct"] for a in completed_apps if b_apps[a].get("median", {}).get("strict_precision_pct") is not None]
    a_strict_meds = [a_apps[a]["median"]["strict_precision_pct"] for a in completed_apps if a_apps[a].get("median", {}).get("strict_precision_pct") is not None]

    b_total_strict_med = round(float(sum(b_strict_meds) / len(b_strict_meds)), 1) if b_strict_meds else 0.0
    a_total_strict_med = round(float(sum(a_strict_meds) / len(a_strict_meds)), 1) if a_strict_meds else 0.0

    # Before total spread: average spread across apps
    b_strict_spreads = [b_apps[a].get("spread", {}).get("strict_precision_pct", 0.0) for a in completed_apps]
    b_total_strict_spread = round(float(sum(b_strict_spreads) / len(b_strict_spreads)), 1) if b_strict_spreads else 0.0

    b_rec_meds = [b_apps[a]["median"]["recall_pct"] for a in completed_apps if b_apps[a].get("median", {}).get("recall_pct") is not None]
    a_rec_meds = [a_apps[a]["median"]["recall_pct"] for a in completed_apps if a_apps[a].get("median", {}).get("recall_pct") is not None]

    b_total_rec_med = round(float(sum(b_rec_meds) / len(b_rec_meds)), 1) if b_rec_meds else None
    a_total_rec_med = round(float(sum(a_rec_meds) / len(a_rec_meds)), 1) if a_rec_meds else None

    b_rec_spreads = [b_apps[a].get("spread", {}).get("recall_pct", 0.0) for a in completed_apps if b_apps[a].get("median", {}).get("recall_pct") is not None]
    b_total_rec_spread = round(float(sum(b_rec_spreads) / len(b_rec_spreads)), 1) if b_rec_spreads else 0.0

    # Rule 1: total strict precision no drop (unless drop <= before spread)
    strict_drop = round(b_total_strict_med - a_total_strict_med, 1)
    if strict_drop > b_total_strict_spread:
        failed_rules.append(f"Rule 1 (strict_precision_no_drop): Total strict precision median dropped by {strict_drop}% ({b_total_strict_med}% -> {a_total_strict_med}%), exceeding before spread of {b_total_strict_spread}%")

    # Rule 2: total recall no drop (unless drop <= before spread)
    if b_total_rec_med is not None and a_total_rec_med is not None:
        rec_drop = round(b_total_rec_med - a_total_rec_med, 1)
        if rec_drop > b_total_rec_spread:
            failed_rules.append(f"Rule 2 (recall_no_drop): Total recall median dropped by {rec_drop}% ({b_total_rec_med}% -> {a_total_rec_med}%), exceeding before spread of {b_total_rec_spread}%")

    # Rule 3: at least one rises by >= 5 percentage points
    strict_rise = a_total_strict_med - b_total_strict_med
    rec_rise = (a_total_rec_med - b_total_rec_med) if (a_total_rec_med is not None and b_total_rec_med is not None) else 0.0
    if not (strict_rise >= 5.0 or rec_rise >= 5.0):
        failed_rules.append(f"Rule 3 (precision_or_recall_rise_5): Neither strict precision (+{strict_rise:.1f}%) nor recall (+{rec_rise:.1f}%) rose by >= 5.0 points")

    # Rule 4: hallucinations no increase
    b_hall = before_data.get("totals", {}).get("hallucination_count", 0)
    a_hall = after_data.get("totals", {}).get("hallucination_count", 0)
    if a_hall > b_hall:
        failed_rules.append(f"Rule 4 (hallucinations_no_increase): Hallucinations increased from {b_hall} to {a_hall}")

    # P8: No silent deletions check
    allowed_removals = load_allowed_removals(project_root)
    for app in completed_apps:
        b_runs = b_apps[app].get("runs", [])
        # Find all controls that were strict hits in before's runs
        before_strict_hit_names = set()
        for r in b_runs:
            for c in r.get("controls", []):
                if c.get("strict_hit") and c.get("name"):
                    before_strict_hit_names.add(c["name"].strip())

        # Collect full reported elements names from after
        after_all_elements = a_apps[app].get("all_elements", [])
        after_reported_names = {e.get("name", "").strip().lower() for e in after_all_elements if e.get("name")}
        # Also check all runs elements in after
        for r in a_apps[app].get("runs", []):
            for c in r.get("controls", []):
                if c.get("name"):
                    after_reported_names.add(c["name"].strip().lower())

        for name in sorted(before_strict_hit_names):
            if name.lower() not in after_reported_names:
                if name.lower() not in allowed_removals:
                    failed_rules.append(f"Rule P8 (no_silent_deletions): Control '{name}' (app: '{app}') was a strict hit before but is absent from after's reported elements list")

    # Per-app checks
    for app in completed_apps:
        b_a = b_apps[app]
        a_a = a_apps[app]

        b_app_strict = b_a.get("median", {}).get("strict_precision_pct", 0.0)
        a_app_strict = a_a.get("median", {}).get("strict_precision_pct", 0.0)
        b_app_strict_spread = b_a.get("spread", {}).get("strict_precision_pct", 0.0)

        # Rule 5: no single app's strict precision falls by more than 3 points (or within spread)
        app_strict_drop = round(b_app_strict - a_app_strict, 1)
        if app_strict_drop > 3.0 and app_strict_drop > b_app_strict_spread:
            failed_rules.append(f"Rule 5 (no_app_strict_drop_gt_3): App '{app}' strict precision dropped {app_strict_drop} points ({b_app_strict}% -> {a_app_strict}%), exceeding spread of {b_app_strict_spread}%")

        b_app_rec = b_a.get("median", {}).get("recall_pct")
        a_app_rec = a_a.get("median", {}).get("recall_pct")
        b_app_rec_spread = b_a.get("spread", {}).get("recall_pct", 0.0)

        # Rule 6: no single app's recall falls by more than 3 points (or within spread)
        if b_app_rec is not None and a_app_rec is not None:
            app_rec_drop = round(b_app_rec - a_app_rec, 1)
            if app_rec_drop > 3.0 and app_rec_drop > b_app_rec_spread:
                failed_rules.append(f"Rule 6 (no_app_recall_drop_gt_3): App '{app}' recall dropped {app_rec_drop} points ({b_app_rec}% -> {a_app_rec}%), exceeding spread of {b_app_rec_spread}%")

        b_app_lat = b_a.get("median", {}).get("latency_ms", 0.0)
        a_app_lat = a_a.get("median", {}).get("latency_ms", 0.0)
        # Rule 7: latency <= 1.5x before per app
        if b_app_lat > 0 and a_app_lat > 1.5 * b_app_lat:
            failed_rules.append(f"Rule 7 (latency_within_limit): App '{app}' latency {a_app_lat}ms exceeded 1.5x before ({b_app_lat}ms -> max {round(1.5 * b_app_lat, 1)}ms)")

        # Rule 8 (per-app RAM): ram_delta after <= before + 30 MB
        b_ram_max = max([r.get("ram_delta_mb", 0.0) for r in b_a.get("runs", [])] or [0.0])
        a_ram_max = max([r.get("ram_delta_mb", 0.0) for r in a_a.get("runs", [])] or [0.0])
        if a_ram_max > b_ram_max + 30.0:
            failed_rules.append(f"Rule 8 (ram_delta_within_limit): App '{app}' RAM delta {a_ram_max}MB exceeded threshold (before: {b_ram_max}MB + 30MB)")

    comparison_stats = {
        "completed_apps": completed_apps,
        "skipped_apps": skipped_apps,
        "before": {
            "strict_precision_pct": b_total_strict_med,
            "recall_pct": b_total_rec_med,
            "strict_spread": b_total_strict_spread,
            "recall_spread": b_total_rec_spread,
            "hallucination_count": b_hall,
            "ocr_status": before_data.get("totals", {}).get("ocr_status", "N/A"),
        },
        "after": {
            "strict_precision_pct": a_total_strict_med,
            "recall_pct": a_total_rec_med,
            "hallucination_count": a_hall,
            "ocr_status": after_data.get("totals", {}).get("ocr_status", "N/A"),
        },
    }

    verdict_passed = (len(failed_rules) == 0)
    return verdict_passed, failed_rules, comparison_stats


def print_comparison_table_v2(before_data: dict[str, Any], after_data: dict[str, Any], stats: dict[str, Any]) -> None:
    b_apps = before_data.get("per_app", {})
    a_apps = after_data.get("per_app", {})
    completed = stats["completed_apps"]
    skipped = stats["skipped_apps"]

    print("\n" + "=" * 98)
    print(" GOKU EYE A/B BENCHMARK COMPARISON TABLE v2 (MEDIANS & SPREAD)")
    print("=" * 98)
    header = f"{'Application / Metric':<30} | {'BEFORE (Med)':<18} | {'AFTER (Med)':<18} | {'DELTA':<18}"
    print(header)
    print("-" * 98)

    for app in completed:
        b_a = b_apps.get(app, {})
        a_a = a_apps.get(app, {})

        b_strict = b_a.get("median", {}).get("strict_precision_pct", 0.0)
        a_strict = a_a.get("median", {}).get("strict_precision_pct", 0.0)
        d_strict = a_strict - b_strict

        b_rec = b_a.get("median", {}).get("recall_pct")
        a_rec = a_a.get("median", {}).get("recall_pct")
        b_rec_str = f"{b_rec:.1f}%" if b_rec is not None else "N/A"
        a_rec_str = f"{a_rec:.1f}%" if a_rec is not None else "N/A"
        d_rec_str = f"{(a_rec - b_rec):+.1f}%" if (a_rec is not None and b_rec is not None) else "N/A"

        b_elem = b_a.get("median", {}).get("elements_reported", 0)
        a_elem = a_a.get("median", {}).get("elements_reported", 0)
        d_elem = a_elem - b_elem

        b_lat = b_a.get("median", {}).get("latency_ms", 0.0)
        a_lat = a_a.get("median", {}).get("latency_ms", 0.0)
        d_lat = a_lat - b_lat

        print(f"[{app}]")
        print(f"  Strict Precision           | {b_strict:<17.1f}% | {a_strict:<17.1f}% | {d_strict:+17.1f}%")
        print(f"  Recall                     | {b_rec_str:<18} | {a_rec_str:<18} | {d_rec_str:<18}")
        print(f"  Elements Reported          | {b_elem:<18} | {a_elem:<18} | {d_elem:+18}")
        print(f"  Latency                    | {b_lat:<15.1f} ms | {a_lat:<15.1f} ms | {d_lat:+15.1f} ms")

    if skipped:
        print("-" * 98)
        print(f"Excluded Apps (skipped in before or after): {', '.join(skipped)}")
        for app in skipped:
            b_st = b_apps.get(app, {}).get("status", "not_present")
            a_st = a_apps.get(app, {}).get("status", "not_present")
            print(f"  - {app}: before='{b_st}', after='{a_st}'")

    print("=" * 98)
    b_tot = stats["before"]
    a_tot = stats["after"]

    tot_d_strict = a_tot["strict_precision_pct"] - b_tot["strict_precision_pct"]
    tot_b_rec = b_tot["recall_pct"]
    tot_a_rec = a_tot["recall_pct"]
    tot_b_rec_str = f"{tot_b_rec:.1f}%" if tot_b_rec is not None else "N/A"
    tot_a_rec_str = f"{tot_a_rec:.1f}%" if tot_a_rec is not None else "N/A"
    tot_d_rec_str = f"{(tot_a_rec - tot_b_rec):+.1f}%" if (tot_a_rec is not None and tot_b_rec is not None) else "N/A"

    print("[TOTALS (Mean of Medians across measurable completed apps)]")
    print(f"  Strict Precision           | {b_tot['strict_precision_pct']:<17.1f}% | {a_tot['strict_precision_pct']:<17.1f}% | {tot_d_strict:+17.1f}%")
    print(f"  Recall                     | {tot_b_rec_str:<18} | {tot_a_rec_str:<18} | {tot_d_rec_str:<18}")
    print(f"  Hallucinations             | {b_tot['hallucination_count']:<18} | {a_tot['hallucination_count']:<18} | {a_tot['hallucination_count'] - b_tot['hallucination_count']:+18}")
    print(f"  OCR Status                 | {b_tot['ocr_status']:<18} | {a_tot['ocr_status']:<18} | {'N/A':<18}")
    print("=" * 98 + "\n")


def main():
    parser = argparse.ArgumentParser(description="GOKU Autonomous Desktop Agent — Eye A/B Comparison Tool v2")
    parser.add_argument("--before", type=str, default="reports/eye/before_v2.json", help="Path to before benchmark JSON")
    parser.add_argument("--after", type=str, default="reports/eye/after_v2.json", help="Path to after benchmark JSON")
    parser.add_argument("--check-kit", action="store_true", help="Verify frozen integrity of eye test kit files")
    args = parser.parse_args()

    if args.check_kit:
        ok = check_kit_hashes()
        sys.exit(0 if ok else 1)

    before_path = Path(args.before)
    after_path = Path(args.after)

    if not before_path.is_file():
        print(f"Error: Before file not found: {before_path}", file=sys.stderr)
        sys.exit(2)
    if not after_path.is_file():
        print(f"Error: After file not found: {after_path}", file=sys.stderr)
        sys.exit(2)

    try:
        before_data = json.loads(before_path.read_text(encoding="utf-8"))
        after_data = json.loads(after_path.read_text(encoding="utf-8"))
    except Exception as e:
        print(f"Error parsing JSON files: {e}", file=sys.stderr)
        sys.exit(2)

    refusals = validate_comparison_preconditions(before_data, after_data)
    if refusals:
        print("\n" + "!" * 82, file=sys.stderr)
        print(" REFUSAL TO COMPARE (Incompatible benchmark runs):", file=sys.stderr)
        for r in refusals:
            print(f"   * {r}", file=sys.stderr)
        print("!" * 82 + "\n", file=sys.stderr)
        sys.exit(2)

    verdict_passed, failed_rules, stats = evaluate_verdict_v2(before_data, after_data)
    print_comparison_table_v2(before_data, after_data, stats)

    if verdict_passed:
        print("*" * 40)
        print(" VERDICT: ACCEPT")
        print(" All frozen criteria passed successfully.")
        print("*" * 40 + "\n")
        sys.exit(0)
    else:
        print("!" * 82)
        print(" VERDICT: REJECT")
        print(f" {len(failed_rules)} rule(s) failed:")
        for r in failed_rules:
            print(f"   [FAIL] {r}")
        print("!" * 82 + "\n")
        sys.exit(1)


if __name__ == "__main__":
    main()
