"""Run on the target Windows laptop: python scripts/laptop_measure.py  -> evidence/measured/hardware.json"""
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from tools import win_measure
d = win_measure.measure_hardware(ROOT / "evidence" / "measured" / "hardware.json")
print(d)
