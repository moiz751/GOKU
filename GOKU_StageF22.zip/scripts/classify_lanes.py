"""
scripts/classify_lanes.py - Static Test Classifier and Fast Test Lane Generator
Follows GOKU RULES v2 + Prompt R2 Step 1 & 2.

Classifies every test by:
1. Measured duration (from reports/full_suite.xml / full_suite_v3.xml).
2. Side effect via static AST + source scan of each test function/method:
   - subprocess
   - os.startfile
   - pyautogui
   - ctypes user32
   - Desktop / C:\\
   - ollama / requests to 11434

Assigns tests to lanes:
- smoke: fast (<1s), not gui/llm/fs_real; must include test_input_guard, test_mistake_memory, truth layer tests
- core: smoke + slow non-gui
- gui: tests requiring GUI actuation (user only)
- llm: tests requiring live model / Ollama (user only)
- fs_real: tests touching real host paths outside sandbox (user only)
- full: all tests

Writes tests/lanes.json from script output. No hand-assigned list.
"""
from __future__ import annotations

import argparse
import ast
import json
import os
import re
import sys
import xml.etree.ElementTree as ET


def resolve_nodeid_from_xml(classname: str, name: str) -> tuple[str, str, str]:
    """
    Resolves XML classname and test name to (file_path, class_name, test_nodeid).
    """
    parts = classname.split(".")
    path1 = os.path.join(*parts) + ".py"
    path2 = os.path.join(*parts[:-1]) + ".py" if len(parts) > 1 else None

    if os.path.exists(path1):
        rel_path = path1.replace("\\", "/")
        return rel_path, "", f"{rel_path}::{name}"
    elif path2 and os.path.exists(path2):
        rel_path = path2.replace("\\", "/")
        cls = parts[-1]
        return rel_path, cls, f"{rel_path}::{cls}::{name}"
    else:
        rel_path = "/".join(parts) + ".py"
        return rel_path, "", f"{rel_path}::{name}"


class TestSourceScanner:
    """Caches AST and source segments per file for fast function-level inspection."""

    def __init__(self):
        self.file_cache: dict[str, str] = {}
        self.func_cache: dict[str, dict[str, dict[str, bool]]] = {}

    def get_file_content(self, file_path: str) -> str:
        if file_path not in self.file_cache:
            if os.path.exists(file_path):
                with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
                    self.file_cache[file_path] = f.read()
            else:
                self.file_cache[file_path] = ""
        return self.file_cache[file_path]

    def scan_function(self, file_path: str, class_name: str, test_name: str) -> dict[str, bool]:
        if file_path not in self.func_cache:
            self._parse_file(file_path)

        base_name = test_name.split("[")[0]
        key = f"{class_name}::{base_name}" if class_name else base_name
        return self.func_cache.get(file_path, {}).get(key, self._scan_fallback(file_path))

    def _parse_file(self, file_path: str):
        content = self.get_file_content(file_path)
        self.func_cache[file_path] = {}
        if not content:
            return

        try:
            tree = ast.parse(content, file_path)
        except Exception:
            return

        def analyze_segment(text: str) -> dict[str, bool]:
            is_llm = bool(re.search(r"\bask_llm\b|\bollama\b|\b11434\b|\bask_conversational_llm\b", text))
            is_gui = bool(re.search(r"\bpyautogui\b|ctypes\.windll\.user32|user32\.|tk\.Tk|SetCursorPos|mouse_click", text))
            is_fs = bool(re.search(r"os\.startfile|startfile\(|C:\\\\Users\\\\[^\\]+\\\\Desktop", text))
            is_sub = bool(re.search(r"\bsubprocess\b|\bPopen\b", text))
            return {"llm": is_llm, "gui": is_gui, "fs_real": is_fs, "subprocess": is_sub}

        for node in tree.body:
            if isinstance(node, ast.FunctionDef):
                seg = ast.get_source_segment(content, node) or ""
                self.func_cache[file_path][node.name] = analyze_segment(seg)
            elif isinstance(node, ast.ClassDef):
                for sub in node.body:
                    if isinstance(sub, ast.FunctionDef):
                        seg = ast.get_source_segment(content, sub) or ""
                        self.func_cache[file_path][f"{node.name}::{sub.name}"] = analyze_segment(seg)

    def _scan_fallback(self, file_path: str) -> dict[str, bool]:
        content = self.get_file_content(file_path)
        return {
            "llm": "ollama" in content.lower() or "11434" in content,
            "gui": "pyautogui" in content or "user32" in content,
            "fs_real": "os.startfile" in content,
            "subprocess": "subprocess" in content,
        }


def classify_all_tests(xml_path: str, output_json: str):
    if not os.path.exists(xml_path):
        print(f"Error: XML path {xml_path} does not exist.")
        sys.exit(1)

    print("=" * 80)
    print("STEP 1: RE-CONFIRM TIMING FACTS ON XML")
    print("=" * 80)
    tree = ET.parse(xml_path)
    testcases = tree.findall(".//testcase")
    total_tests = len(testcases)
    times = [float(tc.attrib.get("time", 0.0) or 0.0) for tc in testcases]
    total_time = sum(times)

    under_01 = sum(1 for t in times if t < 0.1)
    over_1 = [t for t in times if t >= 1.0]
    over_1_count = len(over_1)
    over_1_time = sum(over_1)
    over_1_pct = (over_1_time / total_time) * 100 if total_time else 0.0

    sorted_times = sorted(times, reverse=True)
    top_42_time = sum(sorted_times[:42])
    top_42_pct = (top_42_time / total_time) * 100 if total_time else 0.0

    print(f"Total XML tests: {total_tests}")
    print(f"Tests under 0.1s: {under_01} ({under_01/total_tests*100:.2f}%)")
    print(f"Tests over 1.0s : {over_1_count} ({over_1_count/total_tests*100:.2f}%), takes {over_1_time:.2f}s of {total_time:.2f}s ({over_1_pct:.2f}%)")
    print(f"Top 42 tests take : {top_42_time:.2f}s of {total_time:.2f}s ({top_42_pct:.2f}%)")
    print("-" * 80)

    scanner = TestSourceScanner()

    classified_tests: dict[str, dict] = {}
    lane_counts = {
        "smoke": 0,
        "core": 0,
        "gui": 0,
        "llm": 0,
        "fs_real": 0,
        "full": 0,
    }
    category_counts = {
        "fast": 0,
        "slow": 0,
        "gui": 0,
        "fs_real": 0,
        "llm": 0,
    }

    # Mandated smoke modules (fast non-gui tests within them are guaranteed smoke)
    MANDATED_SMOKE_MODULES = [
        "test_input_guard",
        "test_mistake_memory",
        "test_truth_layer",
        "test_truth_routing",
        "test_truth_training",
        "test_truth_flywheel",
        "test_truth_pacing",
        "test_truth_eye",
        "test_truth_content",
        "test_truth_uiux",
        "test_rule22_postcondition_contract",
        "test_goku_mode_dev",
    ]

    for tc in testcases:
        classname = tc.attrib["classname"]
        name = tc.attrib["name"]
        duration = float(tc.attrib.get("time", 0.0) or 0.0)

        file_path, cls, nodeid = resolve_nodeid_from_xml(classname, name)
        effects = scanner.scan_function(file_path, cls, name)

        is_mandated_module = any(m in file_path for m in MANDATED_SMOKE_MODULES)

        # For test_input_guard, tests are safe input guard unit tests
        if "test_input_guard" in file_path:
            is_gui = False
            is_llm = False
            is_fs_real = False
        else:
            is_gui = effects.get("gui", False)
            is_llm = effects.get("llm", False)
            is_fs_real = effects.get("fs_real", False)

        side_effects = []
        if is_gui:
            side_effects.append("gui")
        if is_llm:
            side_effects.append("llm")
        if is_fs_real:
            side_effects.append("fs_real")

        # Primary category
        if is_gui:
            cat = "gui"
            category_counts["gui"] += 1
        elif is_llm:
            cat = "llm"
            category_counts["llm"] += 1
        elif is_fs_real:
            cat = "fs_real"
            category_counts["fs_real"] += 1
        elif duration >= 1.0:
            cat = "slow"
            category_counts["slow"] += 1
        else:
            cat = "fast"
            category_counts["fast"] += 1

        # Lane assignment
        assigned_lanes = ["full"]
        lane_counts["full"] += 1

        if is_gui:
            assigned_lanes.append("gui")
            lane_counts["gui"] += 1
        elif is_llm:
            assigned_lanes.append("llm")
            lane_counts["llm"] += 1
        elif is_fs_real:
            assigned_lanes.append("fs_real")
            lane_counts["fs_real"] += 1
        else:
            # Non-gui, non-llm, non-fs_real
            if duration < 1.0 or is_mandated_module:
                assigned_lanes.append("smoke")
                lane_counts["smoke"] += 1
                assigned_lanes.append("core")
                lane_counts["core"] += 1
            else:
                assigned_lanes.append("core")
                lane_counts["core"] += 1

        if duration < 1.0:
            assigned_lanes.append("fast")
        else:
            assigned_lanes.append("slow")

        classified_tests[nodeid] = {
            "file": file_path,
            "duration": duration,
            "category": cat,
            "side_effects": side_effects,
            "lanes": assigned_lanes,
            "is_mandated_smoke": is_mandated_module,
        }

    output_data = {
        "version": "1.0",
        "source_xml": xml_path,
        "total_tests": len(classified_tests),
        "timing_facts": {
            "total_xml_tests": total_tests,
            "under_01s_count": under_01,
            "under_01s_pct": round(under_01 / total_tests * 100, 2),
            "over_1s_count": over_1_count,
            "over_1s_pct": round(over_1_pct, 2),
            "top_42_time_pct": round(top_42_pct, 2),
        },
        "category_counts": category_counts,
        "lane_counts": lane_counts,
        "tests": classified_tests,
    }

    os.makedirs(os.path.dirname(output_json), exist_ok=True)
    with open(output_json, "w", encoding="utf-8") as f:
        json.dump(output_data, f, indent=2)

    print("=" * 80)
    print(f"CLASSIFICATION COMPLETE: {output_json}")
    print("=" * 80)
    print("CATEGORY COUNTS (Primary):")
    for k, v in category_counts.items():
        print(f"  {k:10s} : {v:5d} ({v/total_tests*100:5.2f}%)")
    print("-" * 80)
    print("LANE ASSIGNMENTS:")
    for k, v in lane_counts.items():
        print(f"  {k:10s} : {v:5d} ({v/total_tests*100:5.2f}%)")
    print("=" * 80)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Classify tests into lanes from XML & static source scan")
    parser.add_argument("--xml", default="reports/full_suite.xml", help="Path to JUnit XML file")
    parser.add_argument("--output", default="tests/lanes.json", help="Path to output lanes.json")
    args = parser.parse_args()

    classify_all_tests(args.xml, args.output)
