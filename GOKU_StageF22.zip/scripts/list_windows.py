import ctypes
from ctypes import wintypes

user32 = ctypes.windll.user32
buf = ctypes.create_unicode_buffer(512)
cls = ctypes.create_unicode_buffer(256)

def enum(hwnd, _):
    if user32.IsWindowVisible(hwnd):
        user32.GetWindowTextW(hwnd, buf, 512)
        user32.GetClassNameW(hwnd, cls, 256)
        if buf.value and buf.value != "Default IME":
            print(f"HWND: {hwnd} | Class: {cls.value:<25} | Title: {buf.value}")
    return True

WNDENUMPROC = ctypes.WINFUNCTYPE(ctypes.c_bool, wintypes.HWND, wintypes.LPARAM)
user32.EnumWindows(WNDENUMPROC(enum), 0)
