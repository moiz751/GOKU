# scripts/run_states.ps1 - Interactive Step-by-Step State Probe Runner
# Follows GOKU RULES v2 + 16-26 (Prompt R1 Step 2, Task T1.10m A2).
#
# IMPORTANT: In compliance with Rule 16, this script must be executed
# in a STANDALONE PowerShell window by the human operator, NOT from the agent shell.

[CmdletBinding()]
param(
    [switch]$WhatIf
)

$ErrorActionPreference = "Stop"

Write-Host "==========================================================================" -ForegroundColor Cyan
Write-Host " GOKU RESOURCE BASELINE PROBE WIZARD (PROMPT R1 & T1.10m - STATES S0 to S4)" -ForegroundColor Cyan
Write-Host "==========================================================================" -ForegroundColor Cyan
Write-Host "This script measures physical RAM across 5 distinct system states."
Write-Host "S2/S3 use automated Ollama calls matching production options (ollama_options)."
Write-Host "Every number is measured via tools/ram_probe.py and written to reports/ram_<state>.json."
Write-Host ""

# -------------------------------------------------------------------------
# PRE-CHECK: Free Physical Memory (< 250 MB warning)
# -------------------------------------------------------------------------
$freePhysMemMb = 0.0
try {
    $osInfo = Get-CimInstance Win32_OperatingSystem -ErrorAction SilentlyContinue
    if ($osInfo) {
        $freePhysMemMb = [math]::Round($osInfo.FreePhysicalMemory / 1024, 2)
    }
} catch {
    $freePhysMemMb = 0.0
}

if ($freePhysMemMb -gt 0 -and $freePhysMemMb -lt 250.0) {
    Write-Host "==========================================================================" -ForegroundColor Red
    Write-Host " [WARNING] LOW PHYSICAL RAM DETECTED: $freePhysMemMb MB available (< 250 MB)" -ForegroundColor Red
    Write-Host "==========================================================================" -ForegroundColor Red
    Write-Host "Executing model inference under severe memory pressure risks freezing the system."
    Write-Host "Recommended: Close Antigravity IDE, Google Chrome, and heavy background apps first."
    Write-Host ""
    if (-not $WhatIf) {
        $userConfirm = Read-Host "Type 'YES' to proceed anyway, or press any other key / ENTER to exit safely"
        if ($userConfirm -ne "YES") {
            Write-Host "Exiting safely without touching anything." -ForegroundColor Yellow
            exit 0
        }
    }
} else {
    Write-Host "[PRE-CHECK] Available physical RAM: $freePhysMemMb MB (>= 250 MB threshold)." -ForegroundColor Green
}
Write-Host ""

# -------------------------------------------------------------------------
# WHAT-IF / DRY-RUN MODE
# -------------------------------------------------------------------------
if ($WhatIf) {
    Write-Host "==========================================================================" -ForegroundColor Cyan
    Write-Host " [WHAT-IF DRY RUN] GOKU RESOURCE BASELINE PROBE WIZARD" -ForegroundColor Cyan
    Write-Host "==========================================================================" -ForegroundColor Cyan
    Write-Host "Pre-check  : Detected FreePhysicalMemory = $freePhysMemMb MB (Pre-check guard: 250 MB)."
    Write-Host "Step 1 (S0): Would probe S0_idle_no_goku (baseline with no IDE, Chrome, or GOKU)."
    Write-Host "Step 2 (S1): Would probe S1_goku_loaded (router pre-imported, no model loaded)."
    Write-Host "Step 3 (S2): Would query production settings, POST automated warm-up to http://127.0.0.1:11434/api/generate"
    Write-Host "             with keep_alive='2m', then sample S2_model_loaded_idle (idle resident)."
    Write-Host "Step 4 (S3): Would launch background ram_probe (250 ms interval) while POSTing automated ~30 token"
    Write-Host "             generation request to capture peak working set for S3_model_inferring."
    Write-Host "Step 5 (S4): Would probe S4_with_chrome (S2 model resident + 1 Chrome window)."
    Write-Host "Final Step : Would compile docs/RESOURCE_BUDGET.json via python scripts/make_budget.py."
    Write-Host "==========================================================================" -ForegroundColor Cyan
    Write-Host "[WHAT-IF COMPLETE] Dry run executed successfully. Zero models, probes, or files modified." -ForegroundColor Green
    exit 0
}

# Ensure reports directory exists
if (-not (Test-Path "reports")) {
    New-Item -ItemType Directory -Path "reports" | Out-Null
}

# Fetch production options and model name from config.settings
Write-Host "[CONFIG] Querying production model configuration..." -ForegroundColor Cyan
$prodOptionsJson = python -c "from config.settings import ollama_options; import json; print(json.dumps(ollama_options(temperature=0.0, num_predict=60)))"
$modelName = (python -c "from config.settings import MODEL; print(MODEL)").Trim()
$optionsObj = $prodOptionsJson | ConvertFrom-Json

Write-Host "  -> Target Model      : $modelName"
Write-Host "  -> Production Options: $prodOptionsJson"
Write-Host ""

# Representative ~30 token prompt
$representativePrompt = "Explain in thirty words what a desktop assistant does and how it organizes system windows and files for users on Windows."

# Build automated payloads
$s2Payload = @{
    model = $modelName
    prompt = $representativePrompt
    stream = $false
    keep_alive = "2m"
    options = $optionsObj
}
$s2PayloadJson = $s2Payload | ConvertTo-Json -Depth 5

$s3Payload = @{
    model = $modelName
    prompt = $representativePrompt
    stream = $false
    keep_alive = "2m"
    options = $optionsObj
}
$s3PayloadJson = $s3Payload | ConvertTo-Json -Depth 5

# -------------------------------------------------------------------------
# STATE S0: Idle (No GOKU, No IDE, No Chrome)
# -------------------------------------------------------------------------
Write-Host "--------------------------------------------------------------------------" -ForegroundColor Yellow
Write-Host "[STEP 1/5] STATE S0: S0_idle_no_goku" -ForegroundColor Yellow
Write-Host "--------------------------------------------------------------------------" -ForegroundColor Yellow
Write-Host "INSTRUCTIONS FOR OPERATOR:" -ForegroundColor White
Write-Host "  1. Close Antigravity IDE / VS Code."
Write-Host "  2. Close Google Chrome."
Write-Host "  3. Stop Ollama daemon if running (taskkill /F /IM ollama.exe /IM ollama_llama_server.exe)."
Write-Host "  4. Ensure no background GOKU python processes are running."
Write-Host "  5. Press ENTER in this standalone terminal when ready to sample S0 baseline."
Read-Host "Press ENTER to probe S0_idle_no_goku"

python tools/ram_probe.py --state S0_idle_no_goku --samples 3 --interval 5
Write-Host "[DONE] S0_idle_no_goku recorded." -ForegroundColor Green
Write-Host ""

# -------------------------------------------------------------------------
# STATE S1: GOKU Python Loaded (Router imported, model NOT loaded)
# -------------------------------------------------------------------------
Write-Host "--------------------------------------------------------------------------" -ForegroundColor Yellow
Write-Host "[STEP 2/5] STATE S1: S1_goku_loaded" -ForegroundColor Yellow
Write-Host "--------------------------------------------------------------------------" -ForegroundColor Yellow
Write-Host "INSTRUCTIONS FOR OPERATOR:" -ForegroundColor White
Write-Host "  In this step, the probe automatically imports command_layer.router."
Write-Host "  No model weights will be loaded into Ollama."
Write-Host "  Keep IDE and Chrome closed for purest measurement."
Read-Host "Press ENTER to probe S1_goku_loaded"

python tools/ram_probe.py --state S1_goku_loaded --samples 3 --interval 5
Write-Host "[DONE] S1_goku_loaded recorded." -ForegroundColor Green
Write-Host ""

# -------------------------------------------------------------------------
# STATE S2: Model Loaded Idle (Automated warm-up call, keep_alive active)
# -------------------------------------------------------------------------
Write-Host "--------------------------------------------------------------------------" -ForegroundColor Yellow
Write-Host "[STEP 3/5] STATE S2: S2_model_loaded_idle" -ForegroundColor Yellow
Write-Host "--------------------------------------------------------------------------" -ForegroundColor Yellow
Write-Host "INSTRUCTIONS FOR OPERATOR:" -ForegroundColor White
Write-Host "  1. Ensure Ollama service is running ('ollama serve' or background daemon)."
Write-Host "  2. The wizard will automatically send an automated warm-up query to load '$modelName'"
Write-Host "     into memory with production options (num_batch=$($optionsObj.num_batch), ctx=$($optionsObj.num_ctx), keep_alive='2m')."
Write-Host "  3. Right after the warm-up call returns, S2_model_loaded_idle will be sampled."
Read-Host "Press ENTER to trigger automated warmup and probe S2_model_loaded_idle"

Write-Host "Sending automated warm-up call to http://127.0.0.1:11434/api/generate..." -ForegroundColor Cyan
try {
    $warmupResp = Invoke-RestMethod -Uri "http://127.0.0.1:11434/api/generate" -Method Post -ContentType "application/json" -Body $s2PayloadJson -TimeoutSec 60
    Write-Host "[OK] Warm-up complete. Model is resident in idle memory." -ForegroundColor Green
} catch {
    Write-Host "[ERROR] Warm-up call failed: $_" -ForegroundColor Red
    Write-Host "Please ensure Ollama service is running ('ollama serve') before continuing." -ForegroundColor Red
    exit 1
}

python tools/ram_probe.py --state S2_model_loaded_idle --samples 3 --interval 5
Write-Host "[DONE] S2_model_loaded_idle recorded." -ForegroundColor Green
Write-Host ""

# -------------------------------------------------------------------------
# STATE S3: Model Actively Inferring (Automated call + background 250ms probe)
# -------------------------------------------------------------------------
Write-Host "--------------------------------------------------------------------------" -ForegroundColor Yellow
Write-Host "[STEP 4/5] STATE S3: S3_model_inferring" -ForegroundColor Yellow
Write-Host "--------------------------------------------------------------------------" -ForegroundColor Yellow
Write-Host "INSTRUCTIONS FOR OPERATOR:" -ForegroundColor White
Write-Host "  The wizard will automatically trigger active token generation while sampling"
Write-Host "  tools/ram_probe.py every 250 ms in the background to capture peak inference memory."
Read-Host "Press ENTER to begin automated S3 peak generation and background probe"

Write-Host "Launching background memory probe (250 ms intervals) and sending generation POST..." -ForegroundColor Cyan

# Launch probe in background process sampling every 250ms
$probeProc = Start-Process -FilePath "python" -ArgumentList "tools/ram_probe.py --state S3_model_inferring --samples 10 --interval 0.25" -PassThru -NoNewWindow

# Simultaneously dispatch the generation request with production options
try {
    $inferResp = Invoke-RestMethod -Uri "http://127.0.0.1:11434/api/generate" -Method Post -ContentType "application/json" -Body $s3PayloadJson -TimeoutSec 60
    Write-Host "[OK] Generation request completed successfully." -ForegroundColor Green
} catch {
    Write-Host "[WARNING] Generation request encountered warning: $_" -ForegroundColor Yellow
}

# Wait for probe process to complete multi-sample snapshot
$probeProc.WaitForExit()
Write-Host "[DONE] S3_model_inferring recorded." -ForegroundColor Green
Write-Host ""

# -------------------------------------------------------------------------
# STATE S4: With Chrome (S2 Model resident + 1 Chrome Window)
# -------------------------------------------------------------------------
Write-Host "--------------------------------------------------------------------------" -ForegroundColor Yellow
Write-Host "[STEP 5/5] STATE S4: S4_with_chrome" -ForegroundColor Yellow
Write-Host "--------------------------------------------------------------------------" -ForegroundColor Yellow
Write-Host "INSTRUCTIONS FOR OPERATOR:" -ForegroundColor White
Write-Host "  1. Launch Google Chrome with a single standard tab (e.g. about:blank or google.com)."
Write-Host "  2. Model should still be resident in memory."
Write-Host "  3. Return here and press ENTER."
Read-Host "Press ENTER to probe S4_with_chrome"

python tools/ram_probe.py --state S4_with_chrome --samples 3 --interval 5
Write-Host "[DONE] S4_with_chrome recorded." -ForegroundColor Green
Write-Host ""

# -------------------------------------------------------------------------
# FINAL COMPILATION: Make Budget
# -------------------------------------------------------------------------
Write-Host "==========================================================================" -ForegroundColor Cyan
Write-Host " GENERATING RESOURCE BUDGET REPORT (docs/RESOURCE_BUDGET.md)" -ForegroundColor Cyan
Write-Host "==========================================================================" -ForegroundColor Cyan
python scripts/make_budget.py

Write-Host ""
Write-Host "[SUCCESS] All state files probed and docs/RESOURCE_BUDGET.md generated!" -ForegroundColor Green
