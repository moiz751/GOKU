@echo off
REM Dry run by default. To really install the light voice libraries:  RUN_INSTALL_OPTIONAL.bat --yes
cd /d "%~dp0"
python scripts\install_optional_repos.py --tier light %*
pause
